"""Archive one terminal native block without decoding samples or effects."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

ROOT = Path('/home/dev-user/ohm-loader-restack-20261024')
os.umask(0o077)
os.sched_setaffinity(0, set(range(24, 32)))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


owner_path = ROOT / 'records/confirmation-01-owner.terminal.json'
owner = json.loads(owner_path.read_bytes())
assert owner['job_sha256'] == 'eb9b56390213129a45a21f2e85864ed3e8ca2efd03d08ed3de7636252ee83802'
assert owner['state'] in ('complete', 'failed')
native_path = ROOT / 'records/confirmation-01.terminal.json'
native = json.loads(native_path.read_bytes()) if native_path.exists() else None
fixture = ROOT / 'work/loader-fixtures/uv-loader-restack'
baseline = json.loads((fixture / 'snapshots/baseline/manifest.json').read_bytes())
restored = native is not None and (native.get('restoration') or {}).get('variant') == 'baseline'
if restored:
    restoration = native['restoration']
    restored = (
        restoration.get('full_content_verification') is True
        and restoration['inventory_sha256'] == baseline['inventory_sha256']
        and restoration['cargo_sha256'] == baseline['cargo_sha256']
        and restoration['snapshot_manifest_sha256'] == sha(fixture / 'snapshots/baseline/manifest.json')
    )
status = {
    'owner_state': owner['state'],
    'owner_failure': owner['failure'],
    'native_state': native['state'] if native is not None else 'missing',
    'native_failure': native['failure'] if native is not None else None,
    'baseline_native_snapshot_restored': restored,
    'effects_decoded': False,
    'sample_files_decoded': False,
    'owner_terminal_sha256': sha(owner_path),
    'native_terminal_sha256': sha(native_path) if native_path.exists() else None,
}
status_path = ROOT / 'records/confirmation-01-operational-collection.json'
with status_path.open('x') as stream:
    json.dump(status, stream, indent=2)
    stream.write('\n')

paths = {owner_path, status_path}
if native_path.exists():
    paths.add(native_path)
output = ROOT / 'work/benchmark-results/loader-restack-confirmation-01'
if output.exists():
    paths.update(path for path in output.rglob('*') if path.is_file())
paths.update(path for path in (ROOT / 'records').glob('confirmation-01*') if path.is_file())
paths.update(path for path in (ROOT / 'logs').glob('confirmation-01-owner*') if path.is_file())
paths.update(path for path in (ROOT / 'work/benchmark').glob('*.py') if path.is_file())
for name in ('inputs-final-01.json', 'protocol-final-01.json', 'authority-01.template.json'):
    paths.add(ROOT / name)
for name in ('authority-01.approved.json', 'confirmation-01-owner.json', 'owner.py', 'exec_owner_02.py', 'collect_confirmation_remote_01.py'):
    paths.add(ROOT / 'incoming/controls' / name)
for name in ('fixture.json', 'paired-confirmation-01.json', 'journal.jsonl'):
    paths.add(fixture / name)
for arm in ('baseline', 'candidate'):
    for name in ('manifest.json', 'inventory.jsonl', 'runlist.json'):
        paths.add(fixture / 'snapshots' / arm / name)
rows = []
for path in sorted(paths):
    assert path.is_file() and not path.is_symlink(), path
    observed = path.stat()
    rows.append({'path': str(path.relative_to(ROOT)), 'bytes': observed.st_size,
                 'mode': stat.S_IMODE(observed.st_mode), 'sha256': sha(path)})
manifest = ROOT / 'records/confirmation-collection-01.manifest.json'
with manifest.open('x') as stream:
    json.dump({'files': rows}, stream, indent=2)
    stream.write('\n')
archive = ROOT / 'confirmation-collection-01.tar'
with tarfile.open(archive, 'x') as stream:
    for path in [*sorted(paths), manifest]:
        stream.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
subprocess.run(['/usr/bin/zstd', '-q', '-T2', '-3', str(archive)], check=True, stdin=subprocess.DEVNULL)
compressed = Path(str(archive) + '.zst')
receipt = {'path': str(compressed), 'bytes': compressed.stat().st_size, 'sha256': sha(compressed),
           'files': len(rows), 'manifest_sha256': sha(manifest), 'operational': status}
with (ROOT / 'records/confirmation-collection-01.receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
