"""Recheck all six unedited commands and the independently recorded reciprocal ELF proof."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROLE = 'tests/pip_install/main.rs'
H = ('7500331ff8d61491e37bf8f523286fe65310dea21707cecafc5186c2c8c347ce',
     'ec3b00978553c6050695daf162c2eadb8162fbcec1236b0e43e1a97248298c33')
HOUT = 'c8f52faa2c38d9b11c0e14b046bf3e00459054dc738a601eecd20b5e575fa232'
PROTOCOL = '78ed4359ebb7c01b0f30f8930a388c896062951bff5631b0d19b22336640d04f'
PACKET = 'cdd67c8caa1924d569577f989994c0f9612bc206ff040524dfc42a286ab3d5ff'
PROOF = 'a75b3acb6d0290967f8494f0f946c1b78ed02224716cdf3c9b6d6dd6abfb2d19'
STAGES = ('apply-compiler-A', 'ordinary-repeat-A', 'verify-repeat-A')


def digest(data): return hashlib.sha256(data).hexdigest()
def read(p): return json.loads(p.read_bytes())
def need(value, message):
    if not value: raise ValueError(message)
def utc(ns):
    return datetime.datetime.fromtimestamp(ns/1e9, datetime.timezone.utc).isoformat()


def audit(case, proof, cas=None):
    run=case/'physical'; outer=read(run/'outer-return.json'); intake=read(run/'intake.json'); worker=read(run/'worker-return.json')
    need(digest((case/'protocol.json').read_bytes())==PROTOCOL and digest((run/'outer-return.json').read_bytes())==HOUT and
         outer['outer']=={'session':82625,'chunk':'95d3a3','exit':1} and outer['host_released'] and
         not outer['remaining_workers'] and not outer['foreign'] and outer['worker_code']==worker['worker_exit']==worker['code']==1 and worker['success'] is None,
         'different return or worker outcome')
    for receipt,key in [('intake.json','intake_sha256'),('worker-return.json','worker_sha256')]:
        need(digest((run/receipt).read_bytes())==outer[key], 'unbound native return')
    fail=(run/'failure.log').read_text()
    need("archives['ZD']=warm('ZD',subjects)" in fail and "public==read(folder/'ordinary-repeat-A/all-products.json')" in fail,
         'a different gate failed')
    protocol=read(case/'protocol.json'); pbase=read(run/'baseline-A-forms.json')
    need(pbase['independent_arm']=='P' and 'exactly matching complete raw' in protocol['raw_A_policy'], 'different scientific rule')
    expected=set(protocol['expected_reported_test_roles']) | {'uv','uvx'}
    need(len(expected)==17 and set(pbase['roles'])==expected and set(pbase['roles'][ROLE]['class']['allowed'])==set(H), 'control forms')
    observations={};commands={};streams={};cas_records={}
    for arm in ('P','ZD'):
        root=run/('warm-'+arm);src=read(root/'source-A.json')
        need(src['form']=='A' and src['oid']==protocol['uv']['A'], 'unexpected edited or moved source')
        for stage in STAGES:
            place=root/stage;products=read(place/'all-products.json');cmd=read(place/'command.json');key=arm+'/'+stage
            need(set(products)==expected and cmd['source']==src and cmd['exit']==0 and cmd['end_ns']-cmd['start_ns']==cmd['elapsed_ns'] and
                 digest((place/'cargo.log').read_bytes())==cmd['log_sha256'], 'command or product provenance')
            stem=lambda role: role.replace(' ','_').replace('/','__')
            for role, val in products.items():
                for channel in ('stdout','stderr'):
                    raw=(place/'test-lists'/(stem(role)+'.'+channel)).read_bytes()
                    need(digest(raw)==val[channel+'_sha256'] and val['exit']==0,'output did not match: '+key+' '+role)
                    if (role,channel) in streams: need(raw==streams[(role,channel)],'a list/CLI stream changed')
                    else: streams[(role,channel)]=raw
            need(sum(v.get('tests',0) for v in products.values())==3298 and products[ROLE]['tests']==355,'changed test inventory')
            observations[key]=products
            commands[key]={'monotonic_start_ns':cmd['start_ns'],'monotonic_end_ns':cmd['end_ns'],'cargo_exit':cmd['exit'],'traced':cmd['traced'],
                          'actual_cargo_pid':cmd['pid'],'ordinary_argv':cmd['argv'],'cargo_package_messages':len(cmd['packages']),'changed_unit_stamps':len(cmd['changed_stamps']),
                          'command_sha256':digest((place/'command.json').read_bytes()),'source_sha256':src['sha256'],'all_products_sha256':digest((place/'all-products.json').read_bytes())}
        cas_records[arm]=read(root/'retained-products.json')[ROLE]
    need(commands['P/verify-repeat-A']['monotonic_end_ns']<pbase['monotonic_sealed_ns']<commands['ZD/apply-compiler-A']['monotonic_start_ns'],'P baseline was not fixed first')
    signed={(role, item['record']['sha256']) for role,item in pbase['roles'].items()}
    need(signed=={(role,row['sha256']) for role,row in observations['P/verify-repeat-A'].items()},'stock A roster differs')
    ref=observations['P/apply-compiler-A']; roles={}
    for role,base in ref.items():
        raw={k:p[role]['sha256'] for k,p in observations.items()}
        for key,p in observations.items():
            need({k:v for k,v in base.items() if k!='sha256'}=={k:v for k,v in p[role].items() if k!='sha256'},'a product field besides its digest changed')
            expected_hash=(H[1] if key=='ZD/verify-repeat-A' else H[0]) if role==ROLE else base['sha256']
            need(p[role]['sha256']==expected_hash,'unexpected ELF difference')
        roles[role]={'common_path':base['path'],'bytes':base['bytes'],'tests':base.get('tests'),'exit':base['exit'],'argv_tail':base['argv_tail'],
                     'stdout_sha256':base['stdout_sha256'],'stderr_sha256':base['stderr_sha256'],'raw_by_observation':raw if role==ROLE else {'all_six':base['sha256']}}
    known=read(proof);exact=known['full_file']['exact']
    need(known['role']==ROLE and exact['raw_sha256']==list(H) and exact['actual_byte_differences']==33 and exact['outside_ranges_differences']==0 and
         exact['ranges']==[[896,928,'GNU build-ID payload'],[138082152,138082153,'rodata.sh_entsize low byte']] and known['full_file']['pass'] and
         all(cas_records[a]['raw_sha256']==h and cas_records[a]['raw_bytes']==138084016 for a,h in zip(('P','ZD'),H)), 'mismatched retained image or reciprocal proof')
    if cas:
        # Hold the two original images only in memory and compare every byte outside the registered fields.
        images=[]
        for arm,h in zip(('P','ZD'),H):
            rec=cas_records[arm];blob=cas/(h+'.zst')
            need(blob.is_file() and not blob.is_symlink() and blob.stat().st_size==rec['compressed_bytes'] and digest(blob.read_bytes())==rec['compressed_sha256'],'compressed content')
            img=subprocess.check_output(['zstd','-dq','-c','--',str(blob)])
            need(len(img)==rec['raw_bytes'] and digest(img)==h,'raw content')
            images.append(img)
        a,b=images
        need(a[:896]==b[:896] and a[928:138082152]==b[928:138082152] and a[138082153:]==b[138082153:] and
             all(x!=y for x,y in zip(a[896:928],b[896:928])) and (a[138082152],b[138082152])==(0,8), 'unexplained raw byte')
        for val,img,h in zip(('0','8'),images,H):
            need(img[896:928].hex()==exact['left']['forms'][val]['gnu_build_id'] and h==exact['left']['forms'][val]['sha256'],'stored computed ID')
    absent=['baseline-B-forms.json','admission-P','admission-ZD','series.json','analysis.json','successful.json','score.json']
    need(all(not (run/x).exists() for x in absent) and not any(p.name.startswith(('r0','pair-','pilot')) for p in run.iterdir()),'later scientific rows exist')
    return {'excluded':True,'outer':outer['outer'],'outer_sha256':HOUT,'worker_sha256':outer['worker_sha256'],'protocol_sha256':PROTOCOL,'policy':protocol['raw_A_policy'],
            'start_utc':utc(intake['start_ns']),'end_utc':utc(worker['end_ns']),'all_commands_unscored':True,'B_admissions':0,'B_pilot':0,'held_out_pairs':0,'raw_family_p':1,
            'no_performance_estimate':True,'initial_A_role_count':len(roles),'A_test_lists':15,'A_cli_versions':2,'listed_tests':3298,'identical_stream_observations':len(streams)*len(observations),
            'same_arm_P_exact':True,'same_arm_ZD_exact':False,'only_differing_role':ROLE,'differing_product_record_field':'sha256','commands':commands,'roles':roles,
            'P_only_A_baseline_monotonic_ns':pbase['monotonic_sealed_ns'],'P_only_A_baseline_sha256':digest((run/'baseline-A-forms.json').read_bytes()),
            'fully_retained':cas_records,'proof':{'combined_packet_sha256':PACKET,'file':proof.name,'file_sha256':digest(proof.read_bytes()),'bytes':exact['bytes'],'actual_differences':33,
            'outside_ranges_differences':0,'ranges':exact['ranges'],'derived_0_and_8':exact['left']['forms']},
            'host_CAS_was_independently_rehashed_for_this_replay':bool(cas),'original_terminal_scientific_files_absent':absent}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('case',type=Path);parser.add_argument('proof',type=Path);parser.add_argument('--cas',type=Path);args=parser.parse_args()
    print(json.dumps(audit(args.case,args.proof,args.cas),indent=2,sort_keys=True))
