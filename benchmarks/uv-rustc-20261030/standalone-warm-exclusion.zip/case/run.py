"""Run and independently close the registered direct PR-base replication on the full package."""
import contextlib,importlib.util,json,os,subprocess,sys,time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
L=Path(__file__).resolve().parent;K=L.parent/'package-test';V3=L.parent/'package-test-v3';PREV=L.parent/'package-test-v2-direct-leaf';D=L.parent/'fresh-edit-trial'
def module(p,n):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
q=module(K/'run.py','frozen_package_experiment')
s=module(L/'score.py','direct_package_score')
v=q.v;m=q.m;bank=q.bank;pr=q.pr;arc=q.arc;need=v.need;read=v.read;write=v.write;sha=v.sha
G=1<<30;REG=L/'registration.json';OUT=L/'physical';RAM=s.RAM;CAS=RAM/'products';ACTIVE=RAM/'active';DOC=s.plan()
MAIN_REG='f407179ed32a9cb0ee90a4414c4ee29c7101fcdda8fdb3b00f8775fc6f9e4e47'
base_bridge=q.bridge
def independent(entry,*args):
    return subprocess.check_output(['/usr/bin/python3','-ISB',str(entry),*map(str,args)],text=True,timeout=300)
def verify():
    records=read(REG)
    need(independent(PREV/'run.py','verify').strip()==sha(PREV/'registration.json')==records['previous_direct_registration'],'different original direct operator')
    need(independent(V3/'run.py','verify').strip()==sha(V3/'registration.json')==records['combined_registration'],'changed effective C/CZD study')
    need(all(sha(L/k)==h for k,h in {**records['own'],**records['prior']}.items()) and sha(L/'protocol.json')==s.SCIENCE,'changed prospective source')
    from random import Random
    orders=[['P','ZD'] for _ in range(6)]+[['ZD','P'] for _ in range(6)]
    Random(DOC['order_seed']).shuffle(orders)
    need(DOC['pairs']==orders and all(orders!=read(x/'protocol.json')['pairs'] for x in (PREV,K/'direct-leaf')),'substituted paired schedule')
    return sha(REG)
def gate(existing=None):
    f=module(V3/'family.py','independent_new_package_family')
    z=json.loads(independent(V3/'run.py','family'))
    new=z['raw'];key=f.PRIMARY
    need(z['original_failed_p']==z['second_failed_p']==1 and new['counted_pairs']==12 and new['score'] is not None and
         new['score']['individual_gate'] and z['individual_scores'].get(key)==new['score'],'no eligible independent v3')
    previous=z['previous_closures'] if existing is None else existing['closure_digests']
    need(all(z['previous_closures'].get(k)==v for k,v in previous.items()),'changed original seven prerequisite closures')
    scores={k:r for k,r in z['individual_scores'].items() if k in previous or k==key}
    family=f.adjust(scores)
    for rejected in (f.ORIGINAL,f.PREVIOUS):
        need(family[rejected]['raw_p']==1 and family[rejected]['excluded'],'credited failed package')
    need(family[key]['confirmed'] and (existing is not None or z['holm10']==family),'combined package fell short of its actual Holm10')
    selected={'closure_digests':previous,'combined_score':new['score'],'decision':family,'combined_native_outer':sha(V3/'physical/outer-return.json'),
              'combined_scorer':sha(V3/'family.py'),'previous_failed_packages':DOC['previous_native_studies']}
    if existing is not None:need(selected==existing,'eligibility snapshot changed after intake')
    return selected

def bridge(path,digest):
    p=Path(path).resolve();main=V3/'physical/outer-return.json'
    need(p==main,'direct PR package requires the actual just-completed v3 combined outer')
    raw=json.loads(independent(V3/'run.py','closed',p,digest))
    host,actual=v.local_receipt(p.parent,digest)
    need(raw==actual,'physical reader disagrees')
    return host,actual
def native_inputs(subjects):
    return {'parent':subjects['P'],'candidate':subjects['ZD']}
def native_verify(subjects):
    f=OUT/'native';n=q.ready.native_gate
    binding=read(f/'subjects.json');need(binding['subjects']==native_inputs(subjects) and binding['registered']==sha(REG),'different P/ZD driver for native controls')
    with patch.object(v,'QA',f),patch.object(v,'BUILD',Path('/tmp')):
        results=n.qa.validate(f,binding['subjects'])
    for role in ('parent','candidate'):
        fp=f/role/'cargo-native/evidence/rows.json';r=read(fp)
        need([x['exit']==0 for x in r]==[True,True,True,False,False,False,True] and [x['printed'] for x in r if x['exit']==0]==['273\n','285\n','541\n','529\n'],'changed, missing, malformed or recovered real native input mishandled')
        results[role]['normal_cargo_sha256']=sha(fp)
    proof={'subjects_sha256':sha(f/'subjects.json'),'results':results,'code':0,'timed':False};need(proof==read(f/'verified.json'),'different native P/ZD evidence');return sha(f/'verified.json')
def native(subjects):
    n=q.ready.native_gate;f=OUT/'native';f.mkdir();sub=native_inputs(subjects);write(f/'subjects.json',{'subjects':sub,'registered':sha(REG)})
    with patch.object(n,'OUT',f),patch.object(n,'__file__',str(L/'run.py')),patch.object(v,'QA',f),patch.object(v,'BUILD',Path('/tmp')):
        res=n.direct(sub,'ZD')
    write(f/'verified.json',{'subjects_sha256':sha(f/'subjects.json'),'results':res,'code':0,'timed':False});return native_verify(subjects)
def native_inside(choice,role):
    n=q.ready.native_gate;f=OUT/'native'
    need(choice=='ZD' and role in ('parent','candidate') and os.path.samefile('/tmp/qa274',f/role) and os.statvfs('/').f_flag&os.ST_RDONLY,'wrong native controls namespace')
    with patch.object(n,'OUT',f),patch.object(v,'QA',f),patch.object(v,'BUILD',Path('/tmp')):
        n.qa.run_arm(role);n.cargo_fixture(role)
def warm(arm,subjects):
    folder=OUT/('warm-'+arm);folder.mkdir();q.identify();need(not ACTIVE.exists(),'occupied warm history')
    n=m.tree_size(m.DONOR,True)['unique_allocated_bytes'];m.bounds(max(n+(768<<20),13*G+(256<<20)))
    snapshot=bank.archive(m.DONOR,ACTIVE);incoming={'donor':str(m.DONOR),'source_identity':bank.identity(m.DONOR),'identity':bank.identity(ACTIVE),'state':snapshot}
    write(folder/'incoming.json',incoming);q.job(folder,subjects,arm,'warm',read(m.cold/'cold-A/census.json')['producers'])
    repeated=folder/'verify-repeat-A';public=q.keep(repeated,folder);need(public==read(folder/'ordinary-repeat-A/all-products.json') and not m.r.native.foreign(),'warm traced/ordinary or custody failure')
    inv=read(folder/'markers-after.json');markers={}
    for pkg,witness in read(K.parent/'six-units.json').items():
        paths=[p for p in inv['all_known_packages'][pkg] if '/'+witness['unit_hash']+'/' in p]
        need(len(paths)==1,'initial .d not in real full-package inventory: '+pkg);opaque=inv['observed'][paths[0]]['opaque'];expected=arm=='P' or pkg=='libm'
        if arm=='P' or pkg in ('libm','zeroize'):need(opaque is expected,'wrong directly admitted native guard disposition')
        markers[pkg]={'path':paths[0],'opaque':opaque,'predicted_opaque':expected}
    write(folder/'marker-proof.json',markers);size=m.tree_size(ACTIVE,True)['unique_allocated_bytes'];need(size<=13*G,'full warm A exceeds bound')
    archive=arc.pack(ACTIVE,RAM/(arm+'-never-B.tar.zst'),bank.snapshot,bank.identity,m.bounds);need(archive['original']==incoming['identity'],'wrong A source')
    archive['actual_slot_allocated']=size;write(folder/'checkpoint.json',archive);q.retire_active(folder,incoming['identity'],'never-B direct PR checkpoint independently compared to live source');return archive
def perform(subjects):
    native_digest=native(subjects);arms=('P','ZD');s.bind(OUT,emit=True)
    (OUT/'form-proofs').mkdir();(OUT/'form-proofs-A').mkdir()
    archives={'P':warm('P',subjects)}
    s.a_forms.reference(OUT,DOC,s.base.forms,create=True)
    archives['ZD']=warm('ZD',subjects)
    A=read(OUT/'warm-P/verify-repeat-A/all-products.json');need(s.a_forms.equal(A,read(OUT/'warm-ZD/verify-repeat-A/all-products.json'),DOC,s.base.forms),'different raw complete A outputs')
    allowance=max(2*G,2*sum(x['bytes'] for x in A.values())+(512<<20));size=max(r['actual_slot_allocated'] for r in archives.values())
    write(OUT/'complete-price.json',{'transient_link_allowance':allowance,'actual':{a:{'full':r['actual_slot_allocated'],'compressed':r['allocated']} for a,r in archives.items()},'already_charged_products':m.tree_size(CAS,True),'safe_current':m.bounds(size+allowance),'root_scratch_floor':m.FLOOR,'ram_floor':20*G,'shm_floor':6*G,'all_tmpfs_max':26*G})
    stamp=time.time_ns();admitted=[q.one('P','admission',OUT/'admission-P',subjects,archives['P'],stamp)]
    s.base.forms.baseline(OUT,DOC,baseline_arm='P',candidate_arm='ZD')
    admitted.append(q.one('ZD','admission',OUT/'admission-ZD',subjects,archives['ZD'],stamp))
    s.base.forms.validate_reference(OUT,DOC,baseline_arm='P',candidate_arm='ZD')
    need(s.base.forms.equal(admitted[0],admitted[1],DOC) and read(OUT/'admission-P/edit.json')['after']==read(OUT/'admission-ZD/edit.json')['after'],'different admitted B state')
    attempts=[];rows=[q.paired(seq,order,'timed',subjects,archives,attempts) for seq,order in enumerate(DOC['pairs'],1)]
    write(OUT/'series.json',{'pairs':rows,'exclusions':attempts});res=s.replay(OUT);write(OUT/'analysis.json',res)
    cas_index=saved_products(OUT,rows,durable=True);write(OUT/'cas-index.json',cas_index)
    q.identify();need(not ACTIVE.exists() and not m.r.native.foreign(),'occupied direct checkout');m.system_proof()
    for a,z in archives.items():
        p=Path(z['path']);need(p==RAM/(a+'-never-B.tar.zst') and bank.identity(p)==z['archive_identity'] and sha(p)==z['sha256'],'unowned A archive')
    for z in archives.values():Path(z['path']).unlink()
    write(OUT/'retired.json',{'archives':{a:{'sha256':w['sha256'],'identity':w['archive_identity'],'path':w['path']} for a,w in archives.items()},'absent':not ACTIVE.exists() and all(not Path(w['path']).exists() for w in archives.values()),'original_P':bank.identity(m.DONOR),'physical_cas':str(CAS),'all_programs_sha256':sha(OUT/'cas-index.json'),'native_controls_sha256':native_digest,'stock_A_reference_sha256':sha(OUT/'baseline-A-forms.json'),'stock_B_reference_sha256':sha(OUT/'baseline-B-forms.json'),'two_failed_packages':DOC['previous_native_studies']});return res
def saved_products(root,rows,durable):
    root=Path(root);cas={};observed={phase:{a:{} for a in ('P','ZD')} for phase in ('A','B')}
    folders=[('A',a,'warm-'+a) for a in ('P','ZD')]+[('B',a,'admission-'+a) for a in ('P','ZD')]
    folders += [('B',a,d) for pair in rows for a,d in zip(pair['order'],pair['dirs'])]
    for phase,arm,d in folders:
        refs=read(root/d/'retained-products.json')
        actual=read(root/d/('verify-repeat-A' if phase=='A' else 'B')/'all-products.json')
        s.base.forms.check(actual,DOC);need(set(refs)==set(actual),'incomplete retained package')
        for role,record in refs.items():
            h=record['raw_sha256'];need(h==actual[role]['sha256'] and record['raw_bytes']==actual[role]['bytes'] and
                 (h not in cas or cas[h]==record),'contradictory original raw/compressed product')
            cas[h]=record;observed[phase][arm].setdefault(role,set()).add(h)
    public={p:{a:{r:sorted(v) for r,v in roles.items()} for a,roles in arms.items()} for p,arms in observed.items()}
    if durable:
        for h,record in cas.items():
            path=CAS/(h+'.zst');need(path.is_file() and path.resolve()==path and sha(path)==record['compressed_sha256'] and
                 path.stat().st_size==record['compressed_bytes'] and arc.unpacked_sha(path)==h,'original raw or compressed program changed')
    return {'root':str(CAS),'files':cas,'all_raw_programs_kept':True,'actually_observed_by_phase_arm_role':public,
            'stock_A_reference_sha256':sha(root/'baseline-A-forms.json'),'stock_B_reference_sha256':sha(root/'baseline-B-forms.json'),
            'observed_A_nonidentical_pairs':{p.name:sha(p) for p in sorted((root/'form-proofs-A').glob('*.json'))},
            'observed_nonidentical_pairs':{p.name:sha(p) for p in sorted((root/'form-proofs').glob('*.json'))},
            'two_failed_packages':DOC['previous_native_studies']}
def start(p,h):
    # All aliases below live in this isolated interpreter. The original combined entry is immutable.
    need(os.environ.get('PACKAGE_TEST_V3_DIRECT_RELEASE')==sha(REG),'coordinator direct replication grant missing')
    genuine=q.ready;receiver=SimpleNamespace(select=lambda deep,_:genuine.leaf_subjects(deep),native_proof=genuine.native_proof,native_gate=genuine.native_gate)
    with patch.dict(os.environ,{'PACKAGE_TEST_RELEASE':sha(REG)}),patch.multiple(q,K=L,REG=REG,OUT=OUT,RAM=RAM,ACTIVE=ACTIVE,CAS=CAS,score=s,PLAN=DOC,verify=verify,bridge=bridge,primary=gate,perform=perform,ready=receiver):
        return q.start(p,h)
def closed(p,h):
    verify();p=Path(p).resolve();need(p==OUT/'outer-return.json','wrong direct PR-base package location');host,z=v.local_receipt(OUT,h)
    w=read(OUT/'worker-return.json');success=read(OUT/'successful.json');intake=read(OUT/'intake.json');retired=read(OUT/'retired.json')
    need(w['code']==w['worker_exit']==0 and w['owned_children_at_return']==[] and w['capacity']['guard_fault'] is None and w['success']==sha(OUT/'successful.json') and intake['boot']==z['boot'] and intake['locks']==w['locks']==z['locks'] and intake['start_ns']<w['end_ns'],'incomplete direct physical return')
    need(bridge(Path(intake['previous']),intake['previous_sha256'])[1]['outer']==intake['outer'] and gate(intake['primary'])==intake['primary'] and intake['registration']==success['registration']==sha(REG),'wrong separate eligibility/resource return')
    subjects=read(OUT/'subjects.json');need(subjects==q.ready.leaf_subjects(False) and success['subjects_sha256']==sha(OUT/'subjects.json') and native_verify(subjects['subjects'])==retired['native_controls_sha256'],'different true P/ZD subjects or native result')
    need(retired['absent'] and set(retired['archives'])=={'P','ZD'} and success['physical_custody_sha256']==sha(OUT/'retired.json') and success['cas_sha256']==retired['all_programs_sha256']==sha(OUT/'cas-index.json') and success['all_tests']==15 and success['all_ELF']==17 and success['scored_rows']==24 and success['pilot_only'] is False,'incomplete package outputs or A checkpoint return')
    s.bind(OUT)
    need(read(OUT/'cas-index.json')==saved_products(OUT,read(OUT/'series.json')['pairs'],durable=False) and
         all(retired[n]==sha(OUT/k) for n,k in [('stock_A_reference_sha256','baseline-A-forms.json'),('stock_B_reference_sha256','baseline-B-forms.json')]) and
         retired['two_failed_packages']==DOC['previous_native_studies'],'changed actual direct product witnesses')
    need(s.replay(OUT)==read(OUT/'analysis.json') and success['scorer_sha256']==sha(OUT/'analysis.json'),'unverified independent direct clock data');return host,z
def family():
    p=OUT/'outer-return.json';closed(p,sha(p));main=json.loads(independent(V3/'run.py','family'));result=s.replay(OUT);r=result['score']
    return {'primary_holm10_unchanged':read(OUT/'intake.json')['primary']['decision'],'at_reporting_holm10':main['holm10'],
            'excluded_original_p':1,'excluded_second_p':1,'gated_direct':result,'standalone_qualifies':r['individual_gate'] and r['p_against_2']['two_sided_p']<.05,
            'holm11_sensitivity':s.holm11(main['individual_scores'],r),'outer_sha256':sha(p),'pooled':False}
if __name__=='__main__':
    a=sys.argv[1:]
    if a==['verify']:print(verify())
    elif a==['family']:print(json.dumps(family(),sort_keys=True,indent=2))
    elif len(a)==3 and a[0]=='inside':native_inside(a[1],a[2])
    elif len(a)==3 and a[0]=='start':raise SystemExit(start(Path(a[1]),a[2]))
    elif len(a)==4 and a[0]=='close':v.code(v.UP.parent/'physical.py','direct_package_real_outer').close(OUT,*a[1:])
    elif len(a)==3 and a[0]=='closed':print(json.dumps(closed(Path(a[1]),a[2])[1]))
    else:raise ValueError('verify | start PRIOR_OUTER SHA | close SESSION CHUNK CODE | closed OUTER SHA | family')
