"""Detached Python 3.11+ reader for two authentic first-edit stock uvx builds."""
import argparse
import hashlib
import json
from pathlib import PurePosixPath as P
import re
import sys
import zipfile

REG='9d95000fdad9e7f718958712e44fc79eb41948ae37dcb24e2c27c06bf0497af5'
PLAN='9bb1db88447a953fb844ab60f18eea437997c3f33d27d0d898ab034a8db4b2e5'
COMMAND=['build','--locked','--offline','-j8','-p','uv','--bins']
STAGES=('cold-A','settle-A','unchanged-A','first-B')
def require(flag,why):
    if not flag:raise ValueError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def replay(read,externals=None):
    obj=lambda n:json.loads(read(n))
    digest=lambda n:sha(read(n))
    manifest=obj('SHA256.json')
    require(all(digest(k)==h for k,h in manifest.items()),'packet member changed')
    require(digest('original-registration.json')==REG and digest('workload.json')==PLAN,'changed native/registration inputs')
    reg=obj('original-registration.json')
    def locked(prefix,path):
        matches=[h for n,h in reg['files'].items() if n.endswith('/'+path)]
        require(matches==[digest(prefix)],'unregistered member '+prefix)
    locked('original-collector.py','distributed-production-uvx/run.py')
    p=obj('workload.json');s=p['original_edit'];pins=p['release_inputs'];series={};outs={}
    require(p['command']==['cargo',*COMMAND] and p['stages']==list(STAGES) and p['rows_per_shipped_release']==1 and p['scored_rows']==0 and s['source_path']=='crates/uv/src/bin/uvx.rs','different production command or edit population')
    for k in ('A','B'):
        source=read('edit/'+k+'.rs');locked('edit/'+k+'.rs','uvx-binary-edit/'+k+'.rs')
        require(hashlib.sha1(b'blob '+str(len(source)).encode()+b'\0'+source).hexdigest()==s[k+'_blob'] and sha(source)==s[k+'_sha256'],'bad raw upstream blob')
    upstream=obj('edit/upstream-commit.json');locked('edit/upstream-commit.json','uvx-binary-edit/upstream-commit.json')
    require(upstream['sha']==s['upstream_commit'] and [v['sha'] for v in upstream['parents']]==[s['upstream_parent']] and [(v['filename'],v['additions'],v['deletions'],v['sha']) for v in upstream['files']]==[(s['source_path'],5,13,s['B_blob'])],'different real forward edit')
    locked('edit/behavior-control.json','uvx-binary-edit/behavior-control.json');expected=obj('edit/behavior-control.json')['observed']['cases']
    require(set(expected)=={'uvx@fallback','uvx@pair','missing'} and [expected[k]['exit'] for k in ('uvx@fallback','uvx@pair','missing')]==[37,37,2],'wrong argv-through-sibling test')
    def terminal(pref,positive=True):
        o=obj(pref+'outer-return.json');w=obj(pref+'worker-return.json');i=obj(pref+'intake.json');triplet=o['outer']
        require(triplet['exit']==o['worker_code']==w['code']==w['worker_exit'] and (not positive or triplet['exit']==0) and type(triplet['session']) is int and re.fullmatch('[0-9a-f]{6}',triplet['chunk']) and o['host_released'] and o['foreign']==o['remaining_workers']==[] and o['worker_sha256']==digest(pref+'worker-return.json') and o['intake_sha256']==digest(pref+'intake.json') and o['locks']==w['locks']==i['locks'] and o['boot']==i['boot'] and w['end_ns']>i['start_ns'],'unauthenticated or incomplete physical closure '+pref)
        return i,w,o
    def edge(child,parent,raw):
        require(child['boot']==raw['boot'] and child['outer']==raw['outer'] and child['previous_sha256']==digest(parent+'outer-return.json'),'broken immediate physical lineage')
    _,_,fourteen=terminal('custody/fourteen/',False)
    rs,rw,ro=terminal('custody/restore/');edge(rs,'custody/fourteen/',fourteen);rz=obj('custody/restore/result.json');rb=obj('custody/restore/close-binding.json')
    require(rz['both_original_compressed_streams_restored'] and rz['original_v2_archives_deep'] and rz['external_backup_preserved'] and rw['result_sha256']==digest('custody/restore/result.json') and rb['outer_sha256']==digest('custody/restore/outer-return.json') and rb['triplet']==ro['outer'] and rb['four_return_sha256']==digest('custody/restore/four-return.json') and obj('custody/restore/four-return.json')['reacquired'],'prior two real archives not returned')
    by_release={};programs={};runtimes={}
    for release in ('18','20'):
        pre=release+'/';get=lambda n:obj(pre+n);h=lambda n:digest(pre+n);i,w,out=terminal(pre);outs[release]=out
        if externals:require(externals[release]==h('outer-return.json'),'external release outer disagrees')
        if release=='18':edge(i,'custody/restore/',ro)
        else:edge(i,'18/',outs['18'])
        sub=get('subject.json');pp=pins[release];actual={key:sub[k] for key,k in [('distribution','archive_sha256'),('rust','rust_source'),('cargo_source','cargo_source'),('rustc','rustc_sha256'),('driver','driver_sha256'),('cargo','cargo_sha256')]}
        require(all(pp[k]==value for k,value in actual.items()) and h('subject.json')==pp['member_pin'] and sub['release']==release and len(sub['files'])==67 and sub['files'][sub['driver']]['sha256']==sub['driver_sha256'],'different released toolchain')
        by_release[release]=sub;summary=get('summary.json');success=get('success.json');owned=get('ownership.json');ret=get('retired.json')
        require(summary['original_source']==s and success['release']==summary['release']==i['release']==release and success['registration']==i['registration']==REG and w['success']==h('success.json') and success['scored_rows']==w['scored_rows']==summary['scored_rows']==0 and summary['first_B_observations']==1 and set(success['files'])==set('summary.json subject.json restored.json retired.json cold-mapped-bins.json edit.json namespace.json ownership.json environment.json cargo-vV.txt rustc-vV.txt unchanged-A/retained.json first-B/retained.json'.split()) and all(h(k)==v for k,v in success['files'].items()) and owned['incoming_target_entries']==[] and ret['identity']==owned['slot'] and summary['official_archive_sha256']==actual['distribution'],'bad original success, ownership, or acquisition')
        m=w['capacity'];require(m['guard_fault'] is None and m['period_s']==.05 and m['opening']['actual_effective_shm']-m['minimum']['actual_effective_shm']<=p['new_slot_bytes'] and m['minimum']['root']>(122<<30)+(384<<20) and m['minimum']['scratch']>(122<<30)+(128<<20) and m['minimum']['ram']>20<<30 and m['minimum']['shm']>6<<30,'wrong working charge or physical floor')
        elapsed={};logs={};produced={};orig={};source_states={};last_end=0
        for stage in STAGES:
            root=stage+'/';cmd=get(root+'command.json');prod=get(root+'products.json');summary_stage=summary['stages'][stage];form='B' if stage=='first-B' else 'A';state=cmd['source'];source_states[stage]=state
            require(cmd['argv']==cmd['actual_argv'] and cmd['argv'][1:]==COMMAND and P(cmd['argv'][0]).parts[-3:]==('sdk','bin','cargo') and cmd['kind']==stage and cmd['exit']==0 and not cmd['traced'] and not cmd['fingerprint_diagnostics'] and not cmd['observer_faults'] and cmd['driver']==sub['driver_sha256'],'nonordinary compiler or command')
            require(state['oid']==s['uv_base'] and state['ref']=='refs/heads/feature-A' and state['edit']=='actual-uvx-production' and state['form']==form and state['blob']==s[form+'_blob'] and state['sha256']==s[form+'_sha256'] and state['path']==s['source_path'] and state['bytes']==len(read('edit/'+form+'.rs')),'wrong observed source')
            wall=cmd['end_ns']-cmd['start_ns'];require(cmd['start_ns']>=last_end and wall==cmd['elapsed_ns']==summary_stage['elapsed_ns'] and wall>0,'wrong monotonic clocks');last_end=cmd['end_ns'];elapsed[stage]=wall
            before,after=get(root+'stamps-before.json'),get(root+'stamps-after.json');changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k));pkgs=sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',read(pre+root+'cargo.log').decode(),re.M))
            require(cmd['changed_stamps']==changed==summary_stage['changed_stamps'] and cmd['packages']==pkgs==summary_stage['packages'] and h(root+'command.json')==summary_stage['command_sha256'] and h(root+'products.json')==summary_stage['products_sha256'] and h(root+'stamps-before.json')==cmd['stamps_before_sha256'] and h(root+'stamps-after.json')==cmd['stamps_after_sha256'] and h(root+'cargo.log')==cmd['log_sha256'],'wrong raw stamp or Cargo census')
            require(prod['argv_and_exit']==expected and set(prod['programs'])==set(prod['producer'])=={'uv','uvx'} and summary_stage['whole_programs']==prod['programs'],'wrong programs/observable argv')
            for role in ('uv','uvx'):
                output=prod['programs'][role];require(output['path']=='debug/'+role and output['bytes']>0 and re.fullmatch('[0-9a-f]{64}',output['sha256']) and re.fullmatch(r'debug/build/uv/[a-f0-9]{16}/out/'+role+r'(?:-[a-f0-9]{16})?',prod['producer'][role]) and read(pre+root+role+'-version.stdout').decode().strip()==prod['versions'][role] and read(pre+root+role+'-version.stderr')==b'','wrong producing unit, ELF facts or version')
            ver=get(root+'uv-detail.stdout');rev,short,day,tags=state['description'].split();tag,n,_=tags.rsplit('-',2)
            require(ver==prod['versions']['detail'] and ver['commit_info']=={'commit_hash':rev,'commit_date':day,'short_commit_hash':short,'last_tag':tag,'commits_since_last_tag':int(n)} and rev==s['uv_base'] and short in prod['versions']['uv'] and short in prod['versions']['uvx'],'different build version')
            logs[stage]={'packages':pkgs,'changed_stamps':len(changed)};produced[stage]=prod
            if stage in STAGES[-2:]:
                kept=get(root+'retained.json')
                require(set(kept)=={'uv','uvx'} and all(q['raw_bytes']==prod['programs'][k]['bytes'] and q['raw_sha256']==prod['programs'][k]['sha256'] and 0<q['compressed_bytes']<q['raw_bytes'] and re.fullmatch('[0-9a-f]{64}',q['compressed_sha256']) for k,q in kept.items()),'incomplete whole-file raw/compressed evidence')
                export=obj('export-verification.json')['releases'][release];require(export.get('independent_uncompressed_SHA_and_compressed_SHA_verified') is True and kept==export['retained'][stage],'different exterior full-byte replay')
        witness=get('cold-mapped-bins.json');cold=get('cold-A/command.json');dev,ino=sub['files'][sub['driver']]['device_inode'];dev_fields=[((dev>>8)&0xfff)|((dev>>32)&~0xfff),(dev&0xff)|((dev>>12)&~0xff)]
        allowed={'crates/uv/src/bin/uv.rs','crates/uv/src/bin/uvx.rs'};allowed.update({str(P(cold['argv'][0]).parents[2]/'source'/n) for n in list(allowed)})
        require(witness['cargo_pid']==cold['pid'] and witness['selected'] and all(x['session']==cold['pid'] and x['exe_device_inode']==sub['files']['bin/rustc']['device_inode'] and set(x['argv'])&allowed and '--test' not in x['argv'] and x['driver_mappings'] and all((e['dev'],e['inode'])==(dev_fields,ino) for e in x['driver_mappings']) and len(x['fds'])==2 and len(set(x['fds'].values()))==1 and next(iter(x['fds'].values())).startswith('pipe:[') for x in witness['selected']),'missing actual cold child driver mapping and two jobserver descriptors')
        a,b=(produced[v] for v in STAGES[-2:]);require(produced['settle-A']==a and a['producer']==b['producer'] and a['programs']['uv']==b['programs']['uv'] and a['programs']['uvx']['sha256']!=b['programs']['uvx']['sha256'] and a['versions']==b['versions'],'within-release raw files or observed behavior conflict')
        edit=get('edit.json');require(edit['before']==source_states['unchanged-A']==get('restored.json')['source'] and edit['after']==source_states['first-B'] and edit['git_numstat'].split()==['5','13',s['source_path']] and edit['closed_source_before_timer_ns']<=get('first-B/command.json')['start_ns'] and edit['after']['mtime_ns']>edit['before']['mtime_ns'] and logs['first-B']['changed_stamps'] and 'uv' in logs['first-B']['packages'],'changed or no-work first B')
        programs[release]={stage:produced[stage]['programs'] for stage in STAGES[-2:]};runtimes[release]={stage:[produced[stage]['versions'],produced[stage]['argv_and_exit']] for stage in STAGES[-2:]}
        series[release]={'ordinary_elapsed_ns':elapsed,'cargo':logs,'raw_programs':programs[release],'actual_outer':out['outer'],'outer_sha256':h('outer-return.json')}
    common={n:r['sha256'] for n,r in by_release['18']['files'].items() if by_release['20']['files'][n]['sha256']==r['sha256']}
    require(len(common)==5 and common==p['identical_sdk_member_bytes_across_releases'] and runtimes['18']==runtimes['20'],'different released shared-tool or program behavior')
    native=obj('export-verification.json')['native_compare'];require(native['scored_rows']==0 and native['single_observation_per_release'] and native['same_argv_and_runtime_versions'],'inconsistent physical export')
    for step in STAGES[-2:]:
        for release in series:require(native['release_context_seconds'][step][release]==series[release]['ordinary_elapsed_ns'][step]/1e9,'different independent physical clock')
        for role in ('uv','uvx'):
            x=native['cross_release_whole_ELF_comparison'][step][role];require(all(x[key]==programs[key][step][role] for key in series) and x['raw_equal']==(x['18']['sha256']==x['20']['sha256']),'different physical full-byte comparison')
    return {'releases':series,'single_18_over_20_descriptive_wall_ratio':{k:series['18']['ordinary_elapsed_ns'][k]/series['20']['ordinary_elapsed_ns'][k] for k in STAGES[-2:]},'cross_release_raw_equal':{k:{r:programs['18'][k][r]['sha256']==programs['20'][k][r]['sha256'] for r in ('uv','uvx')} for k in STAGES[-2:]},'same_forwarded_argv_and_versions':True,'scored_rows':0,'scope':'One ordinary first edit per complete shipped distribution. No confidence interval or isolated rustc effect.'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('archive',nargs='?',default=sys.argv[0]);ap.add_argument('--outer18');ap.add_argument('--outer20');args=ap.parse_args();require(bool(args.outer18)==bool(args.outer20),'supply both genuine outer hashes, or neither')
    with zipfile.ZipFile(args.archive) as z:
        names=z.namelist();require(len(names)==len(set(names)) and all(n and not P(n).is_absolute() and '..' not in P(n).parts for n in names),'duplicate or unsafe member');manifest=json.loads(z.read('SHA256.json'));require(set(names)==set(manifest)|{'SHA256.json'},'extra or missing member')
        print(json.dumps(replay(z.read,{'18':args.outer18,'20':args.outer20} if args.outer18 else None),indent=2,sort_keys=True))
if __name__=='__main__':main()
