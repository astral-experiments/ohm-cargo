"""Check what a real Unix uvx binary executes and which arguments it forwards."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ARGUMENTS = [b"--", b"", b"path with spaces", b"two\nlines", b"non-UTF8-\xff"]
COMPANION = b"""#!/usr/bin/python3 -ISB
import os, sys
words = [os.path.basename(os.fsencode(sys.argv[0]))] + [os.fsencode(s) for s in sys.argv[1:]]
sys.stdout.buffer.write(b'\\0'.join(words) + b'\\0')
raise SystemExit(37)
"""
ENV = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}


def observe(uvx, scratch):
    uvx, scratch = Path(uvx), Path(scratch)
    with uvx.open("rb") as f:
        binary = hashlib.file_digest(f, "sha256").hexdigest()
    cases = {}
    with tempfile.TemporaryDirectory(prefix="uvx-argv-", dir=scratch) as tmp:
        dest = Path(tmp)
        for name in ("uv", "uv@pair"):
            file = dest / name
            file.write_bytes(COMPANION)
            file.chmod(0o755)
        for name, expected in (("uvx@pair", "uv@pair"), ("uvx@fallback", "uv")):
            executable = dest / name
            shutil.copyfile(uvx, executable)
            executable.chmod(0o755)
            result = subprocess.run([os.fsencode(executable), *ARGUMENTS], cwd=dest, env=ENV,
                                    capture_output=True, timeout=15)
            wanted = b"\0".join([expected.encode(), b"tool", b"uvx", *ARGUMENTS]) + b"\0"
            if (result.returncode, result.stdout, result.stderr) != (37, wanted, b""):
                raise ValueError(f"{name} did not execute {expected} with the registered argument bytes")
            cases[name] = {"exit": result.returncode, "stdout_hex": result.stdout.hex(), "stderr": ""}
        (dest / "uv").unlink()
        result = subprocess.run([str(dest / "uvx@fallback")], cwd=dest, env=ENV,
                                capture_output=True, timeout=15)
        wanted = b"error: Could not find the `uv` binary at either of:\n  " + os.fsencode(dest / "uv@fallback") + b"\n  " + os.fsencode(dest / "uv") + b"\n"
        if (result.returncode, result.stdout, result.stderr) != (2, b"", wanted):
            raise ValueError("uvx did not identify its two missing companions")
        cases["missing"] = {"exit": 2, "stdout": "", "stderr": result.stderr.replace(os.fsencode(dest), b"{bin}").decode()}
    return {"binary_sha256": binary, "cases": cases}


if __name__ == "__main__":
    print(json.dumps(observe(sys.argv[1], sys.argv[2]), indent=2, sort_keys=True))
