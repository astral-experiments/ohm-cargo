"""One unwrapped first production uvx edit per complete shipped release, with separate new targets."""
import contextlib, hashlib, importlib.util, inspect, json, os, re, subprocess, sys, time, traceback
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;G=HERE.parent
def mod(n,p):
    sp=importlib.util.spec_from_file_location(n,p);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v);return v
base=mod('unchanged_shipped_package_context',G/'distributed-package/run.py')
bins=mod('actual_uvx_command_products',G/'production-uvx-bins/command.py')
m,r,o,v=base.m,base.r,base.o,base.v
need,read,write,sha=v.need,v.read,v.write,v.sha
REG=HERE/'registration.json';PLAN=HERE/'protocol.json';ARCH=G/'package-test-full-stack/tmpfs-price/after-pack-floor';F=G/'package-test-full-stack-after-uvx'
ARGS=['cargo','build','--locked','--offline','-j8','-p','uv','--bins']
NAME='actual-uvx-production';STAGES=base.STAGES
GIB=1<<30;PRECHARGE=17*GIB//2
def phys(rel):
    need(rel in ('18','20'),'unregistered release');return HERE/('physical-'+rel)
def ram(rel):
    phys(rel);return Path('/dev/shm/ohm-released-production-uvx-20261030-'+rel)
def fixed():
    g=read(REG);need(all(sha(Path(k))==h for k,h in g['files'].items()),'context inputs changed')
    metadata=bins.x.plan();needle=read(PLAN);need(bins.x.verify() and base.verify() and needle['original_edit']==metadata['source'] and ARGS==needle['command']==metadata['argv'] and needle['new_slot_bytes']==PRECHARGE and needle['rows_per_shipped_release']==1,'wrong uv/SDK inputs');return sha(REG)
def state(form):
    source=bins.x.plan()['source'];spec={'path':source['source_path'],'A':source['A_blob'],'B':source['B_blob']}
    with patch.object(m,'endpoint',lambda n:spec if n==NAME else None):return m.state(NAME,form)
def normal(folder,form,kind,subj):
    # Preserve the measured command body verbatim up to its actual successful child return.
    # The old function's next statement opens test executables, which this command does not build.
    original=base.study.c.normal;s=inspect.getsource(original);boundary='    files=r.publications(text);'
    need(s.count(boundary)==1 and s.count('>250*10**9')==1,'original ordinary Cargo observation changed')
    body=s[:s.index(boundary)]+'    return row\n'
    if kind=='cold-A':body=body.replace('>250*10**9','>900*10**9')
    scope=dict(original.__globals__);exec(compile(body,'<released ordinary bins command from frozen observer>','exec'),scope)
    source=bins.x.plan()['source'];ed={'path':source['source_path'],'A':source['A_blob'],'B':source['B_blob']}
    with patch.object(m,'endpoint',lambda n:ed if n==NAME else None),patch.object(r,'CMD',[str(r.SDK/'bin/cargo'),*ARGS[1:]]):
        return scope['normal'](folder,NAME,form,kind,subj)
def alias(target,name):
    public=bins.r.products.regular(target,'debug/'+name);choices=[]
    for path in sorted((target/'debug/build/uv').glob('*/out/'+name+'*')):
        if not re.fullmatch(re.escape(name)+r'(?:-[0-9a-f]{16})?',path.name):continue
        need(path.resolve()==path and re.fullmatch('[0-9a-f]{16}',path.parent.parent.name),'unexpected canonical unit output')
        if os.path.samefile(path,public) or (path.stat().st_size==public.stat().st_size and sha(path)==sha(public)):choices.append(path)
    need(len(choices)==1,'missing/ambiguous complete public-to-unit binary correspondence for '+name)
    return {'file':str(choices[0].relative_to(target))}
def apply_at(src,when):
    ed=bins.x.plan()['source'];before=state('A');p=src/ed['source_path']
    need(before['mtime_ns']<when<=time.time_ns() and sha(p)==ed['A_sha256'],'wrong pre-edit source or epoch')
    raw=(bins.x.SRC/'B.rs').read_bytes();need(hashlib.sha256(raw).hexdigest()==ed['B_sha256'],'not the exact upstream edit');p.write_bytes(raw);os.utime(p,ns=(when,when));after=state('B')
    diff=subprocess.check_output(['/usr/bin/git','-C',src,'diff','--numstat','--',ed['source_path']],env=o.environment(),text=True)
    need(diff.split()==['5','13',ed['source_path']] and after['mtime_ns']==when and after['sha256']==ed['B_sha256'],'more than the genuine single-file edit')
    return {'before':before,'after':after,'git_numstat':diff,'closed_source_before_timer_ns':time.monotonic_ns()}
def maps(witness,pid,subject):
    st=(r.SDK/subject['driver']).stat();ident=([os.major(st.st_dev),os.minor(st.st_dev)],st.st_ino)
    rows=[]
    for w in witness.rows.values():
        av=w['argv']
        inputs={'crates/uv/src/bin/uv.rs','crates/uv/src/bin/uvx.rs'}
        if not set(av)&(inputs|{str(r.SRC/n) for n in inputs}) or '--test' in av:continue
        if w['session']!=pid or w['exe_device_inode']!=subject['files']['bin/rustc']['device_inode']:continue
        if not w['driver_mappings'] or not all((d['dev'],d['inode'])==ident for d in w['driver_mappings']):continue
        if len(w['fds'])!=2 or len(set(w['fds'].values()))!=1 or not next(iter(w['fds'].values())).startswith('pipe:['):continue
        rows.append(w)
    need(rows,'empty passive cold witness of the real producing bin rustc/driver/shared Cargo jobserver');return rows
def inside(rel):
    dest,work=phys(rel),ram(rel);subject=read(dest/'subject.json');owner=read(dest/'ownership.json');env=o.environment()
    need(os.getuid()!=0 and os.sched_getaffinity(0)==set(range(16)) and not any(k in env for k in ('RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_LOG')) and not list(r.TARGET.iterdir()) and base.bank.identity(r.TARGET)==owner['target'] and base.bank.identity(r.SRC)==owner['source'],'incorrect new source/target/env/CPU')
    need(os.path.samefile(r.SDK,subject['sdk']) and os.statvfs(r.SDK).f_flag&os.ST_RDONLY and os.statvfs(o.VISIBLE/'cargo-home/registry').f_flag&os.ST_RDONLY and os.path.samefile(o.VISIBLE/'cargo-home/registry',o.OLD_HOME/'registry'),'wrong public release/registry attachment')
    for name in ('bin/rustc','bin/cargo',subject['driver']):need(base.bank.identity(r.SDK/name)==subject['files'][name]['device_inode'],'changed installed member')
    rr=subprocess.check_output([r.SDK/'bin/rustc','--print','sysroot'],cwd=r.SRC,env=env,text=True).strip();need(os.path.samefile(rr,r.SDK),'wrong resolved namespace sysroot')
    for name in ('cargo','rustc'):(dest/(name+'-vV.txt')).write_bytes(subprocess.check_output([r.SDK/'bin'/name,'-vV'],env=env,cwd=r.SRC,stderr=subprocess.STDOUT))
    write(dest/'environment.json',env)
    original=state('A');fp=r.SRC/original['path'];original_bytes=fp.read_bytes();at=fp.stat().st_atime_ns;frozen={n:sha(r.SRC/n) for n in base.MANIFESTS}
    try:
        for stage in STAGES:
            cut=stage=='first-B';form='B' if cut else 'A';c=stage=='cold-A'
            if cut:write(dest/'edit.json',apply_at(r.SRC,time.time_ns()))
            with (o.Witness(r.SDK/'bin/rustc',r.SDK/subject['driver'],r.TARGET) if c else contextlib.nullcontext()) as watch:
                row=normal(dest/stage,form,stage,subject)
            if c:write(dest/'cold-mapped-bins.json',{'cargo_pid':row['pid'],'selected':maps(watch,row['pid'],subject),'untimed_for_edit':True})
            d=dest/stage;owners={n:alias(r.TARGET,n) for n in ['uv','uvx']};product=bins.bins(d,{'map':owners},subject,state(form));write(d/'products.json',product)
            need(frozen=={n:sha(r.SRC/n) for n in base.MANIFESTS},'manifest or lock changed')
            if stage in ('unchanged-A','first-B'):
                stored={k:base.cas.keep(r.TARGET/rec['path'],work/'programs',rec,m.bounds) for k,rec in product['programs'].items()};write(d/'retained.json',stored)
        write(dest/'summary.json',summarize(dest,rel))
    finally:
        if fp.read_bytes()!=original_bytes:fp.write_bytes(original_bytes)
        os.utime(fp,ns=(at,original['mtime_ns']));need(state('A')==original and {n:sha(r.SRC/n) for n in base.MANIFESTS}==frozen,'did not restore exact isolated source');write(dest/'restored.json',{'source':original,'manifest':frozen})
def product_pair(unchanged,edited):
    for item in (unchanged,edited):
        need(set(item['programs'])=={'uv','uvx'} and set(item['producer'])=={'uv','uvx'} and item['argv_and_exit']==read(bins.x.SRC/'behavior-control.json')['observed']['cases'],'wrong products or real argv/exit')
    need(unchanged['producer']==edited['producer'] and unchanged['versions']==edited['versions'] and unchanged['programs']['uv']==edited['programs']['uv'] and unchanged['programs']['uvx']['sha256']!=edited['programs']['uvx']['sha256'],'unmodified uv changed, or edited uvx did not change')
def summarize(folder,rel):
    needle=read(PLAN);s=read(folder/'subject.json');ed=needle['original_edit'];rec={};products={}
    need(s==read(base.out(rel)/'subject.json') and len(s['files'])==67 and s['archive_sha256']==base.releases.PIN[rel][0],'different distributed release')
    for phase in STAGES:
        form='B' if phase=='first-B' else 'A';d=folder/phase;cmd=read(d/'command.json');p=read(d/'products.json')
        need(cmd['kind']==phase and cmd['argv']==cmd['actual_argv']==[str(r.SDK/'bin/cargo'),*ARGS[1:]] and cmd['exit']==0 and not cmd['traced'] and not cmd['fingerprint_diagnostics'] and not cmd['observer_faults'] and cmd['end_ns']-cmd['start_ns']==cmd['elapsed_ns']>0 and cmd['driver']==s['driver_sha256'],'incorrect ordinary Cargo invocation or elapsed')
        source=cmd['source'];need(source['oid']==m.A==ed['uv_base'] and source['form']==form and source['ref']=='refs/heads/feature-A' and source['blob']==ed[form+'_blob'] and source['sha256']==ed[form+'_sha256'] and source['path']==ed['source_path'],'incorrect source identity')
        log=(d/'cargo.log').read_bytes();a,b=[read(d/f) for f in ('stamps-before.json','stamps-after.json')]
        need(cmd['log_sha256']==sha(d/'cargo.log') and cmd['stamps_before_sha256']==sha(d/'stamps-before.json') and cmd['stamps_after_sha256']==sha(d/'stamps-after.json') and cmd['packages']==sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',log.decode(),re.M)) and cmd['changed_stamps']==sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)),'aggregate clock/stamps disagree with original files')
        need(p['argv_and_exit']==read(bins.x.SRC/'behavior-control.json')['observed']['cases'] and set(p['programs'])=={'uv','uvx'},'wrong command behavior')
        for n in ('uv','uvx'):
            q=p['programs'][n];need(q['path']=='debug/'+n and re.fullmatch(r'debug/build/uv/[a-f0-9]{16}/out/'+n+r'(-[a-f0-9]{16})?',p['producer'][n]) and q['bytes']>0 and re.fullmatch('[a-f0-9]{64}',q['sha256']) and (d/(n+'-version.stdout')).read_text().strip()==p['versions'][n] and (d/(n+'-version.stderr')).read_bytes()==b'','unexpected output or raw version')
        need(read(d/'uv-detail.stdout')==p['versions']['detail'],'uv version JSON disagrees');bins.r.verify_ver(source,p['versions'])
        if phase in STAGES[-2:]:
            keep=read(d/'retained.json');need(set(keep)=={'uv','uvx'} and all((keep[n]['raw_sha256'],keep[n]['raw_bytes'])==(v['sha256'],v['bytes']) for n,v in p['programs'].items()),'incomplete raw program retention')
        rec[phase]={'elapsed_ns':cmd['elapsed_ns'],'command_sha256':sha(d/'command.json'),'products_sha256':sha(d/'products.json'),'packages':cmd['packages'],'changed_stamps':cmd['changed_stamps'],'whole_programs':p['programs']};products[phase]=p
    need(products['settle-A']==products['unchanged-A'],'warm original binary bytes or behavior vary within one release')
    product_pair(products['unchanged-A'],products['first-B'])
    edit=read(folder/'edit.json');f=read(folder/'first-B/command.json');need(edit['before']==read(folder/'unchanged-A/command.json')['source'] and edit['after']==f['source'] and edit['git_numstat'].split()==['5','13',ed['source_path']] and edit['closed_source_before_timer_ns']<=f['start_ns'] and f['source']['mtime_ns']>edit['before']['mtime_ns'] and 'uv' in f['packages'] and f['changed_stamps'],'first genuine edit did not visibly rebuild')
    return {'release':rel,'stages':rec,'original_source':ed,'official_archive_sha256':s['archive_sha256'],'first_B_observations':1,'scored_rows':0,'same_release_A_repeat_both_whole_ELFs_exact':True,'edited_uvx_changed_untouched_uv_raw_identical':True,'production_argv_verified':True}
def prior(rel,path,h):
    need(path.is_absolute() and path==path.resolve() and sha(path)==h,'wrong incoming return')
    if rel=='20':return closed('18',path,h)
    expect=ARCH/'physical-restore/outer-return.json';need(rel=='18' and path==expect,'must follow the full archive restoration')
    def certified(program,*args):return json.loads(subprocess.check_output(['/usr/bin/python3','-ISB',program,*map(str,args)]))
    sealed=certified(ARCH/'material.py','closed',path,h);host,raw=v.local_receipt(path.parent,h)
    intake=read(path.parent/'intake.json');prev=F/'physical/outer-return.json';previous=read(prev)
    front_host,front_raw=v.local_receipt(prev.parent,sha(prev));need(front_raw==previous and previous['host_released'] and read(prev.parent/'intake.json')['registration']==sha(F/'registration.json'),'unrecognised returned #14 host')
    if previous['outer']['exit']==0:need(certified(F/'after-pack-floor/run.py','closed',prev,sha(prev))==previous,'unverified completed #14')
    need(sealed==raw and intake['previous']==str(prev) and intake['previous_sha256']==sha(prev) and intake['outer']==previous['outer'] and read(path.parent/'result.json')['both_original_compressed_streams_restored'] and read(path.parent/'result.json')['original_v2_archives_deep'],'the release context requires the returned #14 and the two original deep-read archives')
    return host,raw
def generation(pid):
    try:
        fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[-1].split();return None if fields[0] in ('Z','X') else int(fields[19])
    except (FileNotFoundError,ProcessLookupError):return None
def status(rel):
    d=phys(rel);res={'release':rel,'scored_rows':0,'validated_complete':False,'completed_cargo_observations':[]}
    if not d.exists():return dict(res,state='not started' if not ram(rel).exists() else 'unowned working path present')
    for stage in STAGES:
        file=d/stage/'command.json'
        if file.is_file():
            row=read(file);res['completed_cargo_observations'].append({'stage':stage,'exit':row['exit'],'source_blob':row['source']['blob'],'raw_sha256':sha(file)})
    raw=d/'outer-return.json'
    if raw.is_file():
        host,outer=v.local_receipt(d,sha(raw));r=read(d/'worker-return.json');need(outer['outer']['exit']==r['code'],'resource/worker disagreement')
        if r['code']==0:closed(rel,raw,sha(raw));return dict(res,state='completed',actual_outer=outer['outer'],validated_complete=True)
        return dict(res,state='returned interrupted or rejected',actual_outer=outer['outer'],reason=r['exception'],retained_working_slot=(ram(rel)/'working').exists())
    inc=d/'intake.json';w=d/'worker-return.json'
    if w.is_file():return dict(res,state='worker returned; genuine outer still required',worker_exit=read(w)['code'])
    if not inc.is_file():return dict(res,state='intake incomplete')
    actual=read(inc);live=generation(actual['pid'])==actual['worker_start_ticks']
    return dict(res,state='running' if live else 'interrupted without authentic physical return',worker_pid=actual['pid'])
def preflight(rel,with_prior=True):
    fixed();s=read(base.out(rel)/'subject.json');spec,arc,inv=base.releases.spec(rel)
    need(spec==Path(s['sdk']) and arc==Path(s['archive']) and len(inv)==len(s['files'])==67,'wrong SDK')
    for name,rec in s['files'].items():
        st=(spec/name).lstat();need(os.path.isfile(spec/name) and not (spec/name).is_symlink() and [st.st_dev,st.st_ino]==rec['device_inode'] and st.st_size==rec['bytes'] and (st.st_mode&0o7777)==rec['mode'],'changed distributed member metadata: '+name)
    areas=m.seed.available();limits={'root':m.FLOOR+(768<<20),'scratch':m.FLOOR+(128<<20),'ram':(20<<30)+PRECHARGE,'shm':(6<<30)+PRECHARGE}
    prev=(ARCH/'physical-restore' if rel=='18' else phys('18'))/'outer-return.json';ok=prev.is_file()
    predecessor=None
    if ok and with_prior:predecessor=prior(rel,prev,sha(prev))[1]['outer']
    donor=base.source_donor() if (m.DONOR/'source').is_dir() and (o.OLD_HOME/'registry').is_dir() else None
    return {'release':rel,'source_and_readonly_registry_identity':donor,'provenance_archive_sha256':s['archive_sha256'],'metadata_verified_members':67,'full_byte_check_at_native_intake':True,'prior':str(prev),'predecessor_present':ok,'authenticated_predecessor':predecessor,'fresh_physical_and_work_paths':not phys(rel).exists() and not ram(rel).exists(),'status':status(rel),'current_capacity':areas,'strict_intake_floors':limits,'current_surplus':{k:areas[k]-v for k,v in limits.items()},'meets_capacity':all(areas[k]>v for k,v in limits.items()),'read_only':True}
def meter_for(starting):
    spare=max(0,starting['shm']-6*GIB-PRECHARGE)
    def measured():
        av=m.seed.available();return dict(av,actual_effective_shm=av['shm'],shm=av['shm']-spare)
    return m.seed.RES.Meter(measured,m.FLOOR)
def start(rel,path,h):
    reg=fixed();need(os.environ.get('OHM_SHIPPED_UVX_BINS_CONTEXT')==reg+':'+rel,'explicit release/context is required')
    folder,work=phys(rel),ram(rel);host,previous=prior(rel,path,h)
    with host.exclusively():
        prior(rel,path,h);need(Path('/proc/1/comm').read_text().strip()=='systemd' and not r.native.foreign() and not folder.exists() and not work.exists(),'not a new quiet protected physical allocation')
        os.sched_setaffinity(0,range(16));check=preflight(rel,with_prior=False);need(check['fresh_physical_and_work_paths'] and check['meets_capacity'],'not a feasible new complete slot');opening=m.bounds(PRECHARGE);donor=base.source_donor();folder.mkdir(mode=0o700)
        write(folder/'intake.json',{'pid':os.getpid(),'worker_start_ticks':generation(os.getpid()),'start_ns':time.time_ns(),'boot':previous['boot'],'outer':previous['outer'],'previous':str(path),'previous_sha256':h,'locks':host.locks(),'registration':reg,'opening':opening,'preflight':check,'release':rel})
        code=1;exc=None;meter=None
        try:
            with meter_for(opening) as meter:
                sub=base.releases.verify(rel);need(sub==read(base.out(rel)/'subject.json'),'installed release changed since authenticated stock context');write(folder/'subject.json',sub)
                m.bounds(PRECHARGE);work.mkdir(mode=0o700);(work/'programs').mkdir(mode=0o700);slot=work/'working';slot.mkdir(mode=0o700)
                for k in ('home','tmp','cargo-home','target'):(slot/k).mkdir()
                (slot/'cargo-home/registry').mkdir();copy=base.bank.archive(m.DONOR/'source',slot/'source');ids={k:base.bank.identity(slot/k) for k in ('source','target','cargo-home','home','tmp')};need(not any((slot/'target').iterdir()),'target not fresh')
                write(folder/'ownership.json',{'slot':base.bank.identity(slot),**ids,'incoming_target_entries':[],'source_transfer':copy,'source_and_registry':donor,'programs':base.bank.identity(work/'programs')})
                argv=m.ns(slot,sub['sdk'],folder);cut=argv.index('--');argv[cut:cut]=['--bind',str(work/'programs'),str(work/'programs')];argv[-2:]=[str(HERE/'run.py'),'inside',rel];write(folder/'namespace.json',argv)
                with (folder/'worker.log').open('xb') as out:subprocess.run(argv,check=True,stdout=out,stderr=subprocess.STDOUT,timeout=1800)
                need(read(folder/'summary.json')==summarize(folder,rel) and read(folder/'restored.json')['source']['form']=='A' and base.source_donor()==donor and meter.start['actual_effective_shm']-meter.minimum['actual_effective_shm']<=PRECHARGE,'unverified complete output, unrecovered source, donor or working charge')
                for phase in STAGES[-2:]:
                    for program in read(folder/phase/'retained.json').values():
                        blob=work/'programs'/(program['raw_sha256']+'.zst');need(blob.stat().st_size==program['compressed_bytes'] and sha(blob)==program['compressed_sha256'] and base.cas.unpacked_sha(blob)==program['raw_sha256'],'raw bytes were not recovered before releasing working target')
                with patch.object(m,'RAM',work):base.study.erase(slot,read(folder/'ownership.json')['slot'],folder,'authenticated both complete production binaries and runtime effects in this release')
                need({p.name for p in work.iterdir()}=={'programs'},'unexpected retained path')
                files=['summary.json','subject.json','restored.json','retired.json','cold-mapped-bins.json','edit.json','namespace.json','ownership.json','environment.json','cargo-vV.txt','rustc-vV.txt',*(s+'/retained.json' for s in STAGES[-2:])]
                write(folder/'success.json',{'release':rel,'registration':reg,'scored_rows':0,'files':{k:sha(folder/k) for k in files},'CAS':str(work/'programs')});code=0
        except BaseException as err:exc=repr(err);raise
        finally:
            write(folder/'worker-return.json',{'code':code,'worker_exit':code,'end_ns':time.time_ns(),'locks':host.locks(),'success':sha(folder/'success.json') if code==0 else None,'exception':exc,'capacity':meter.result() if meter else None,'scored_rows':0})
def closed(rel,path,h):
    fixed();d=phys(rel);need(path==d/'outer-return.json','wrong physical return');host,z=v.local_receipt(d,h);old=read(d/'intake.json');_,w=prior(rel,Path(old['previous']),old['previous_sha256'])
    proof=read(d/'success.json');worker=read(d/'worker-return.json');need(z['outer']['exit']==worker['code']==worker['worker_exit']==0 and w['outer']==old['outer'] and z['boot']==w['boot']==old['boot'] and proof['registration']==old['registration']==sha(REG) and proof['release']==old['release']==rel and worker['success']==sha(d/'success.json') and proof['scored_rows']==0 and all(sha(d/k)==v for k,v in proof['files'].items()) and read(d/'summary.json')==summarize(d,rel),'incomplete released output')
    return host,z
def compare(deep):
    data={}
    for release in ('18','20'):
        f=phys(release);closed(release,f/'outer-return.json',sha(f/'outer-return.json'));data[release]=read(f/'summary.json')
        if deep:
            for phase in STAGES[-2:]:
                for q in read(f/phase/'retained.json').values():
                    file=ram(release)/'programs'/(q['raw_sha256']+'.zst');need(sha(file)==q['compressed_sha256'] and base.cas.unpacked_sha(file)==q['raw_sha256'],'stored raw bytes disagree')
    diff={}
    for ph in STAGES[-2:]:
        a,b=[read(phys(rel)/ph/'products.json') for rel in ('18','20')];need(a['versions']==b['versions'] and a['argv_and_exit']==b['argv_and_exit'],'different same-input runtime behavior across releases')
        diff[ph]={n:{'raw_equal':a['programs'][n]['sha256']==b['programs'][n]['sha256'],'18':a['programs'][n],'20':b['programs'][n]} for n in ('uv','uvx')}
    return {'single_18_over_20_descriptive_wall_ratio':{ph:data['18']['stages'][ph]['elapsed_ns']/data['20']['stages'][ph]['elapsed_ns'] for ph in STAGES[-2:]},'single_observation_per_release':True,'scored_rows':0,'release_context_seconds':{ph:{k:q['stages'][ph]['elapsed_ns']/1e9 for k,q in data.items()} for ph in STAGES[-2:]},'cross_release_whole_ELF_comparison':diff,'same_argv_and_runtime_versions':True,'interpretation':'One native run per release and source condition. The complete distributed Cargo/rustc/std stacks differ. No confidence interval or compiler-only estimate.'}
if __name__=='__main__':
    arg=sys.argv[1:]
    if arg==['verify']:print(fixed())
    elif len(arg)==2 and arg[0]=='preflight':print(json.dumps(preflight(arg[1]),indent=2))
    elif len(arg)==2 and arg[0]=='status':fixed();print(json.dumps(status(arg[1]),indent=2))
    elif len(arg)==2 and arg[0]=='inside':fixed();inside(arg[1])
    elif len(arg)==4 and arg[0]=='start':start(arg[1],Path(arg[2]).resolve(),arg[3])
    elif len(arg)==5 and arg[0]=='close':v.code(v.UP.parent/'physical.py','uvx_shipped_close').close(phys(arg[1]),*arg[2:])
    elif len(arg)==4 and arg[0]=='closed':print(json.dumps(closed(arg[1],Path(arg[2]).resolve(),arg[3])[1]))
    elif arg in (['compare'],['compare','--raw']):print(json.dumps(compare(len(arg)==2),indent=2))
    else:raise SystemExit('verify | preflight 18|20 | status 18|20 | start 18|20 PRIOR_OUTER SHA | close 18|20 SESSION CHUNK EXIT | closed 18|20 OWN_OUTER SHA | compare [--raw]')
