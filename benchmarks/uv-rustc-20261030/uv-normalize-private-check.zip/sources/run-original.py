"""One unscored -18 stock edit, plus an independently reset process attribution and clean caller."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import traceback

D=Path(__file__).resolve().parent; WORK=D.parents[1]; OLD=D.parent/'restore-hit-screen'; S=Path('/mnt/devbox-scratch/dev-user/ohm-uv-20261030-restore-hit-screen')
sys.path.insert(0,str(D))
from evidence import edit,header,need,read,sha,stamps,trace_units,write
OUT=D/'physical'; RAM=Path('/dev/shm/ohm-uv-normalize-fresh-check-20261030'); SDK=WORK/'upstream-monitor/toolchain18'
FILE=Path('crates/uv-normalize/src/lib.rs'); META=Path('debug/build/uv-normalize/47e7068e8a421246/out/libuv_normalize-47e7068e8a421246.rmeta')
UV_META=Path('debug/build/uv/0f93810b947feec2/out/libuv-0f93810b947feec2.rmeta')
SIDE=META.parent.parent/'fingerprint/lib-uv_normalize.public-api-hash'; TARGET=S/'target'; SOURCE=S/'source'; REPO=WORK/'uv'
ARGV=[str(SDK/'bin/cargo'),'check','--locked','--offline','-j4']; CMD=lambda *a: ['/usr/bin/python3','-ISB',str(D/'run.py'),*a]
PKG=D.parent/'guard-file-free-math-asm/package-test'; ED=PKG.parent/'fresh-edit-trial/endpoint-handoff.py'; PLAN=D/'registration.json'; G=2**30
DIGEST=lambda b:hashlib.sha256(b).hexdigest()

def identity(p):
    s=p.lstat();need(stat.S_ISDIR(s.st_mode) and not p.is_symlink() and s.st_uid==os.getuid(),'unexpected owned directory')
    return [s.st_dev,s.st_ino]

def verify():
    q=read(PLAN)
    for n,h in q['inputs'].items():need(sha(WORK/n)==h,'changed retained input '+n)
    return q

def authorities():
    sys.path.insert(0,str(D.parent/'branch-session-revisit/pr274-trials'))
    import intake as v
    v.system();host=v.code(v.UP.parent/'physical.py','normalize_physical_custody')
    return v,host

def preceding(p,digest):
    v,host=authorities();p=p.resolve()
    need(sha(p)==digest,'physical predecessor SHA')
    if p in (PKG/'physical/outer-return.json',PKG/'direct-leaf/physical/outer-return.json') or 'ordinary-modes' in p.parts:
        ans=subprocess.check_output(['/usr/bin/python3','-ISB',str(ED),'closed',str(p),digest],timeout=180)
        need(json.loads(ans)==read(p),'detached handoff mismatch')
    else:
        package=v.code(PKG/'run.py','normalize_prior_resource')
        package.verify();package.bridge(p,digest)
    return v.local_receipt(p.parent,digest)[1]

def free():
    return {k:shutil.disk_usage(p).free for k,p in {'root':WORK,'scratch':S,'ram':RAM.parent}.items()}

def bounds(growth=0):
    f=free();need(min(f['root'],f['scratch'])>=122*G and f['ram']>=2*G+growth,'root/scratch 122 GiB or tmpfs margin')
    mem=int(re.search(r'^MemAvailable:\s+(\d+) kB',Path('/proc/meminfo').read_text(),re.M)[1])*1024
    need(mem>=6*G+growth,'physical memory headroom')
    return f

def donor(q):
    for k,i in q['donor_directories'].items():need(identity(S/k)==i,'donor inode '+k)
    for k,h in q['donor_files'].items():need(sha(S/k)==h,'donor bytes '+k)
    return {k:identity(S/k) for k in q['donor_directories']}

def exact_sources(root,uv):
    files=set()
    with subprocess.Popen(['git','-C',str(REPO),'archive','--format=tar',uv],stdout=subprocess.PIPE) as p:
        with tarfile.open(fileobj=p.stdout,mode='r|') as tar:
            for ent in tar:
                rel=Path(ent.name);need(not rel.is_absolute() and '..' not in rel.parts,'archive entry')
                dst=root/rel
                if ent.isdir():continue
                files.add(rel)
                if ent.issym():need(dst.is_symlink() and os.readlink(dst)==ent.linkname,'source symlink mismatch')
                else:
                    need(ent.isfile() and not dst.is_symlink() and dst.is_file() and
                         bool(dst.stat().st_mode&0o111)==bool(ent.mode&0o111) and
                         sha(dst)==DIGEST(tar.extractfile(ent).read()),'source content/mode '+ent.name)
        need(p.wait()==0,'pinned git archive')
    actual={x.relative_to(root) for x in root.rglob('*') if x.is_symlink() or not x.is_dir()}
    # Cargo may put a separately owned build cache at its configured target, never inside source here.
    need(files==actual,'untracked or missing private source')
    return len(files)

def monitor(command,cwd,env,output,deadline):
    """Wait for this process group, checking the physical floors and foreign compiler roster."""
    v,host=authorities();need(not host.native.foreign(),'foreign compiler at entry')
    bounds();faults=[];done=threading.Event()
    with output.open('xb') as log:
        start=time.monotonic_ns();realtime=time.time_ns();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        def poll():
            os.sched_setaffinity(0,{29})
            while not done.wait(.35):
                try:
                    bounds();need(time.monotonic_ns()-start<=deadline*10**9,'command exceeded time budget')
                    outside=[]
                    for pid,name in host.native.foreign():
                        try:
                            if os.getsid(pid)!=child.pid:outside.append([pid,name])
                        except ProcessLookupError:pass
                    need(not outside,'unexpected guest workload '+repr(outside))
                except Exception as ex:
                    faults.append(str(ex))
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    return
        t=threading.Thread(target=poll);t.start()
        try:
            code=child.wait()
            end=time.monotonic_ns();end_real=time.time_ns();r1=resource.getrusage(resource.RUSAGE_CHILDREN)
        finally:done.set();t.join()
    rr={k:getattr(r1,k)-getattr(r0,k) for k in ('ru_utime','ru_stime','ru_minflt','ru_majflt','ru_nvcsw','ru_nivcsw')}
    result=dict(argv=command,cwd=str(cwd),pid=child.pid,exit=code,elapsed_ns=end-start,monotonic_ns=[start,end],
                realtime_ns=[realtime,end_real],rusage=rr,observer_faults=faults,log_sha256=sha(output))
    write(output.with_suffix('.json'),result);need(code==0 and not faults,'child failed or safety stop; preserved '+str(output))
    return result

def producer(folder,tag):
    meta=TARGET/META;data=meta.read_bytes();h=header(data);side=read(TARGET/SIDE)
    need(side=={'version':1,'value':h['public']},'Cargo sidecar differs from released metadata root')
    (folder/(tag+'.rmeta')).write_bytes(data);write(folder/(tag+'-metadata.json'),dict(**h,path=str(META),sidecar=side))
    return h

def inner(lane):
    q=verify();folder=OUT/lane;env=read(OLD/'physical/intake.json')['env']
    need(os.sched_getaffinity(0)==set(range(4)) and os.stat(SOURCE).st_dev==os.stat(RAM).st_dev,'private canonical view/affinity')
    data=(SOURCE/FILE).read_bytes();need(DIGEST(data)==q['source_A'],'source A')
    work=lambda name:folder/(name+'.log')
    def check(label,trace=False):
        before=stamps(TARGET);real=ARGV if not trace else ['/usr/bin/strace','-ff','-ttt','-v','-s','131072','-e','trace=execve,execveat,exit_group','-o',str(folder/'exec'),*ARGV]
        cmd=monitor(real,SOURCE,env,work(label),150);after=stamps(TARGET)
        changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
        packages=re.findall(r'^\s*(?:Compiling|Checking) (\S+)',work(label).read_text(),re.M)
        if label!='edited-B':need(not changed and not packages,'initial or final A/B is not Cargo-fresh')
        else:need(str(META.parent.parent/'fingerprint/invoked.timestamp') in changed and 'uv-normalize' in packages,'producer did not actually check')
        receipt={'all_stamps_before':before,'all_stamps_after':after,'changed_units':changed,'compiling_or_checking':packages,
                 'ordinary_argv':ARGV,'actual_argv':real,'clock_ns':cmd['elapsed_ns'],'trace':trace}
        if trace:
            receipt['rustc']=trace_units(folder.glob('exec.*'),SDK/'bin/rustc',TARGET,changed)
            ttl=[r for r in receipt['rustc'] if r['unit']]
            receipt['production_rustc_count']=len(ttl)
            receipt['all_rustc_count']=len(receipt['rustc'])
            receipt['per_unit_elapsed_ns']={r['stamp']:r['elapsed_ns'] for r in ttl}
            need(all(cmd['realtime_ns'][0]<=r['exec_realtime_ns']<=r['exit_realtime_ns']<=cmd['realtime_ns'][1] for r in receipt['rustc']),'process trace outside Cargo interval')
            selected=[r for r in receipt['rustc'] if r['crate']=='uv_normalize']
            need(len(selected)==1 and str(META.parent.parent/'fingerprint/invoked.timestamp')==selected[0]['stamp'] and
                 '-Zpublic-api-hash' in selected[0]['argv'] and '--emit=dep-info,metadata' in selected[0]['argv'],'wrong producer argv')
        write(folder/(label+'-units.json'),receipt);return receipt
    n=exact_sources(SOURCE,q['uv']);a=producer(folder,'A')
    need(a['raw_sha256']==q['donor_files']['target/'+str(META)],'different A')
    check('pristine-A');edited=edit(data);need(DIGEST(edited)==q['source_B'],'source B')
    try:
        (SOURCE/FILE).write_bytes(edited);stamp=read(OUT/'intake.json')['edit_mtime_ns'];os.utime(SOURCE/FILE,ns=(stamp,stamp))
        b=check('edited-B',trace=lane=='attribution');h=producer(folder,'B');check('fresh-B')
        if lane=='attribution':
            ex=SOURCE/'crates/uv-normalize/examples/observe_error.rs';need(not ex.exists(),'pre-existing caller')
            ex.parent.mkdir(exist_ok=True);ex.write_bytes((D/'caller.rs').read_bytes())
            tmp=S/'tmp/clean-caller-target';need(not tmp.exists(),'clean runtime discriminator must start empty')
            argv=[str(SDK/'bin/cargo'),'run','--locked','--offline','-j4','-p','uv-normalize','--example','observe_error']
            monitor(argv,SOURCE,dict(env,CARGO_TARGET_DIR=str(tmp)),work('clean-caller-B'),240)
            lines=work('clean-caller-B').read_text().splitlines()
            need(lines[-1]==q['runtime_B'] and q['runtime_A'] not in lines,'B linked caller used stale formatting')
        write(folder/'checked.json',{'source_files':n,'source_A':DIGEST(data),'source_B':DIGEST(edited),'A':a,'B':h,'changed_units':b['changed_units']})
    finally:(SOURCE/FILE).write_bytes(data)

def start(p,digest):
    need(os.getuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd','physical user/guest required')
    q=verify();need(os.environ.get('UV_NORMALIZE_DIAGNOSTIC_RELEASE')==sha(PLAN),'separate coordinator release')
    past=preceding(p,digest);v,host=authorities()
    with host.exclusively():
        need(not OUT.exists() and not RAM.exists(),'used diagnostic destination')
        need(set(range(4))<=os.sched_getaffinity(0),'CPU allowance')
        prior=donor(q);bounds(5*G)
        sizes={name:int(subprocess.check_output(['du','-sxB1',str(S/name)]).split()[0]) for name in ('source','home','target')}
        need(sum(sizes.values())<=3*G and not os.statvfs(RAM.parent).f_flag & (os.ST_NOEXEC|os.ST_RDONLY),'clone inputs exceed price or tmpfs cannot execute')
        OUT.mkdir();RAM.mkdir(mode=0o700)
        write(OUT/'intake.json',{'pid':os.getpid(),'previous':str(p.resolve()),'previous_sha256':digest,'outer':past['outer'],
               'registration_sha256':sha(PLAN),'copy_allocations':sizes,'donor':prior,'edit_mtime_ns':time.time_ns(),'free':free(),'tmpfs':identity(RAM)})
        code=1
        try:
            files={n:sha(SDK/n) for n in q['released_sdk']};need(files==q['released_sdk'],'changed released toolchain')
            runroot=RAM/'copy'
            for lane in ('ordinary','attribution'):
                bounds(5*G);folder=OUT/lane;folder.mkdir();runroot.mkdir(mode=0o700);rid=identity(runroot)
                for k in ('source','home','target'):subprocess.run(['cp','-a','--reflink=auto','--',str(S/k),str(runroot/k)],check=True)
                (runroot/'tmp').mkdir();need(all(identity(runroot/k)!=prior[k] for k in ('home','source','target')),'donor alias')
                write(folder/'copied.json',{'copy':rid,'top':{k:identity(runroot/k) for k in ('home','source','target')},'free':bounds(2*G)})
                argv=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--dev','/dev','--ro-bind','/dev/shm','/dev/shm','--proc','/proc']
                for k in ('source','target','home','tmp'):argv+=['--bind',str(runroot/k),str(S/k)]
                argv+=['--bind',str(OUT),str(OUT),'--',*CMD('inner',lane)]
                with (folder/'namespace.log').open('xb') as f:subprocess.run(['taskset','-c','0-3',*argv],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=550)
                need(identity(runroot)==rid and read(folder/'checked.json')['source_B']==q['source_B'] and not host.native.foreign(),'postflight/owned copy')
                shutil.rmtree(runroot);need(not runroot.exists(),'private release');write(folder/'returned.json',{'retired':rid,'protected':donor(q),'free':free()})
            x,y=[read(OUT/k/'checked.json')for k in ('ordinary','attribution')]
            need(x['changed_units']==y['changed_units'] and x['A']==y['A'] and all(x['B'][k]==y['B'][k]for k in ('private','public','crate','version')),'independent clone histories disagree')
            RAM.rmdir();write(OUT/'result.json',{'unscored':True,'changed_unit_count':len(x['changed_units']),'A':x['A'],'B':x['B'],
                   'untraced_seconds':read(OUT/'ordinary/edited-B.json')['elapsed_ns']/1e9,'traced_records_sha256':sha(OUT/'attribution/edited-B-units.json'),
                   'B_clean_caller':q['runtime_B'],'donor_after':donor(q),'physical_copies_retired':not RAM.exists()});code=0
        except BaseException:
            (OUT/'failure.txt').write_text(traceback.format_exc());raise
        finally:write(OUT/'worker-return.json',{'code':code,'pid':os.getpid(),'end_ns':time.time_ns(),'free':free(),'physical_copy_remaining':RAM.exists()})
    return code

if __name__=='__main__':
    a=sys.argv[1:]
    if a==['verify']: verify();print(sha(PLAN))
    elif len(a)==3 and a[0]=='start':raise SystemExit(start(Path(a[1]),a[2]))
    elif len(a)==4 and a[0]=='close':authorities()[1].close(OUT,*a[1:])
    elif len(a)==2 and a[0]=='inner' and a[1]in('ordinary','attribution'):inner(a[1])
    else:raise ValueError('verify | start PRIOR_OUTER SHA | close SESSION CHUNK EXIT')
