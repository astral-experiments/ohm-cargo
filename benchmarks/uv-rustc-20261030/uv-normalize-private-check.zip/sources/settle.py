"""Stock -18 descriptive two-copy check; preserves and releases the rejected copy first."""
import contextlib,hashlib,importlib.util,json,os,re,shutil,stat,subprocess,sys,time,traceback
from pathlib import Path
from unittest.mock import patch
R=Path(__file__).resolve().parent;D=R.parent;sys.path.insert(0,str(D))
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
n=load('original_stock_normalize',D/'run.py')
E=D.parent/'root-compiler-space-audit/stage0-pair';G=D.parent/'guard-file-free-math-asm';REG=R/'registration.json';OUT=R/'physical';RAM=Path('/dev/shm/ohm-uv-normalize-settled-check-20261030')
OLD=n.OUT;ORAM=n.RAM;IN=E/'physical/outer-return.json';PRE='99f42688ce0a2b93ca0f2d58ef5d3c607b330b191a598c7ba55b2c53134c8191';NEG='9c7523e457b5d99c9ac2bac4aba1c9818204b8b602dc42a41de0e2b63fa1468e'
need=n.need;read=n.read;sha=n.sha;write=n.write
RUN=Path('debug/build/uv-cli/d4c3a3c921c98f67/fingerprint/run-build-script-build-script-build.json')
def verify():
    q=read(REG);need(all(sha(Path(p))==h for p,h in q['inputs'].items()) and q['original_registration']==sha(n.PLAN) and q['negative']==NEG and q['predecessor']==PRE,'changed diagnostic source or prior')
    return n.verify()
def preceding(p,h):
    need(p==IN and h==PRE,'wrong real host owner')
    raw=subprocess.run(['/usr/bin/python3','-ISB',str(E/'operate.py'),'closed',str(p),h],capture_output=True,check=True,timeout=300)
    v,host=n.authorities();_,z=v.local_receipt(p.parent,h);need(json.loads(raw.stdout)==z and z['outer']=={'session':64310,'chunk':'43d64e','exit':0} and sha(OLD/'outer-return.json')==NEG,'bad actual maintenance return')
    return host,z
def tree(p):
    return {x.name:n.identity(x) for x in p.iterdir()}
def forensics():
    i=read(OLD/'intake.json');f=read(OLD/'ordinary/copied.json');p=ORAM/'copy';q=n.verify()
    need(n.identity(ORAM)==i['tmpfs'] and tree(ORAM)=={'copy':f['copy']} and set(tree(p))=={'source','target','home','tmp'} and all(n.identity(p/k)==v for k,v in f['top'].items()),'wrong rejected copy')
    a=read(n.TARGET/RUN);b=read(p/'target'/RUN);x=dict(a);y=dict(b);la=x.pop('local');lb=y.pop('local')
    need(x==y and la==[{'Precalculated':'1785347226.000000000s (README.md)'}] and lb==[{'Precalculated':'1785347226.000000000s (src/version.rs)'}],'unknown first-anchor change')
    stamp={}
    for rel in ('README.md','src/version.rs'):
        o=n.SOURCE/'crates/uv-cli'/rel;c=p/'source/crates/uv-cli'/rel
        need(o.stat().st_mtime_ns==c.stat().st_mtime_ns==1785347226000000000 and sha(o)==sha(c),'tied source changed');stamp[rel]={'mtime_ns':o.stat().st_mtime_ns,'sha256':sha(o)}
    need(sha(p/'source'/n.FILE)==q['source_A'] and (p/'target'/n.META).read_bytes()==(OLD/'ordinary/A.rmeta').read_bytes() and
         not(OLD/'ordinary/edited-B.json').exists() and read(OLD/'ordinary/pristine-A.json')['exit']==0,'original produced B or differing A')
    units=[]
    for donor in sorted(n.TARGET.glob('debug/build/*/*/fingerprint/invoked.timestamp')):
        rel=donor.relative_to(n.TARGET);copy=p/'target'/rel
        if copy.exists() and donor.stat().st_mtime_ns!=copy.stat().st_mtime_ns:units.append(str(rel))
    return {'copy':n.identity(p),'top':tree(p),'ram_identity':n.identity(ORAM),'donor':n.donor(q),'donor_script_fingerprint':a,'copy_script_fingerprint':b,'source_timestamp_tie':stamp,
            'original_A_listing':(OLD/'ordinary/pristine-A.log').read_text(),'different_invocation_stamps':units,'original_A':read(OLD/'ordinary/A-metadata.json'),'prior_observations':0}
def release_root(ram,ids,rid,top):
    copy=ram/'copy';need(n.identity(ram)==ids and tree(ram)=={'copy':rid} and n.identity(copy)==rid and tree(copy)==top and ram.parent==Path('/dev/shm') and not Path(ram).is_symlink(),'not unique owned copy')
    for k in ('home','source','target'):need(n.identity(copy/k)!=n.identity(n.S/k),'copy aliases genuine donor')
    mountpoints={line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()}
    need(not any(p==str(ram) or p.startswith(str(ram)+'/') for p in mountpoints),'nested mount in private copy')
    shutil.rmtree(copy);ram.rmdir();need(not ram.exists(),'private tmpfs remains')
def next_time(folder):
    x=read(folder/'pristine-A-units.json');cmd=read(folder/'pristine-A.json');need(not(x['changed_units'] or x['compiling_or_checking']) and cmd['exit']==0,'A was not a genuine no-work check')
    at=time.time_ns();prior=max(cmd['realtime_ns'][1],(n.SOURCE/n.FILE).stat().st_mtime_ns,*(v[1] for v in x['all_stamps_after'].values()))
    need(at>prior,'clock did not advance beyond strict A');write(folder/'edit-clock.json',{'mtime_ns':at,'latest_input_or_A_end_ns':prior});return at
def anchor_payload(folder,log,cmd,before,after):
    changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k));packages=re.findall(r'^\s*(?:Compiling|Checking) (\S+)',log.read_text(),re.M)
    x={'unscored':True,'ordinary_argv':n.ARGV,'all_stamps_before':before,'all_stamps_after':after,'changed_units':changed,'packages':packages,'exit':cmd['exit']}
    write(folder/'settle-A-units.json',x);need(set(packages)<={'uv-cli','uv','uv-dev'} and all(Path(s).parts[2] in {'uv-cli','uv','uv-dev'} for s in changed),'unexpected settling A roster')
def inner(lane):
    q=verify();folder=OUT/lane;env=read(n.OLD/'physical/intake.json')['env'];need(os.sched_getaffinity(0)==set(range(4)) and os.stat(n.SOURCE).st_dev==os.stat(RAM).st_dev,'private path or CPU')
    need(sha(n.SOURCE/n.FILE)==q['source_A'],'dirty original A');n.exact_sources(n.SOURCE,q['uv'])
    orig=n.producer(folder,'inherited-A');need(orig==read(OLD/'ordinary/A-metadata.json') or all(orig[k]==read(OLD/'ordinary/A-metadata.json')[k] for k in orig),'original raw A or private/public SVH changed')
    before=n.stamps(n.TARGET);log=folder/'settle-A.log';cmd=n.monitor(n.ARGV,n.SOURCE,env,log,150);anchor_payload(folder,log,cmd,before,n.stamps(n.TARGET))
    need(n.producer(folder,'settled-A')==orig,'settlement changed original producer')
    def get(p):
        a=read(p)
        if p==OUT/'intake.json':return dict(a,edit_mtime_ns=next_time(folder))
        return a
    with patch.multiple(n,OUT=OUT,RAM=RAM,read=get):n.inner(lane)
def owned_lane(host,lane,prior):
    n.bounds(5*n.G);sizes={k:int(subprocess.check_output(['du','-sxB1',str(n.S/k)]).split()[0]) for k in ('source','home','target')}
    need(sum(sizes.values())<=3*n.G and not os.statvfs(RAM.parent).f_flag & (os.ST_NOEXEC|os.ST_RDONLY),'priced copy too large or nonexecutable tmpfs')
    folder=OUT/lane;folder.mkdir();RAM.mkdir(mode=0o700);runroot=RAM/'copy';runroot.mkdir(mode=0o700);ids=n.identity(RAM);rid=n.identity(runroot)
    for k in ('source','home','target'):subprocess.run(['cp','-a','--reflink=auto','--',str(n.S/k),str(runroot/k)],check=True)
    (runroot/'tmp').mkdir();top=tree(runroot);need(not any(top[k]==prior[k] for k in prior),'donor alias')
    write(folder/'copied.json',{'copy':rid,'ram':ids,'top':top,'actual_donor_allocations':sizes,'free':n.bounds(2*n.G)})
    argv=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--dev','/dev','--ro-bind','/dev/shm','/dev/shm','--proc','/proc']
    for k in ('source','target','home','tmp'):argv+=['--bind',str(runroot/k),str(n.S/k)]
    argv+=['--bind',str(OUT),str(OUT),'--','/usr/bin/python3','-ISB',str(R/'return.py'),'inner',lane]
    with (folder/'namespace.log').open('xb') as f:r=subprocess.run(['taskset','-c','0-3',*argv],stdout=f,stderr=subprocess.STDOUT,timeout=650)
    need(not host.native.foreign(),'worker still active')
    if r.returncode:
        # Preserve the original stdout and the public producer, whether B was reached or not.
        out=runroot/'target'/n.META;d=out.read_bytes();need(len(d)<2**20,'unexpected producer output');(folder/'last.rmeta').write_bytes(d);write(folder/'inconclusive.json',{'inner_exit':r.returncode,'metadata':n.header(d),'B_command_observed':(folder/'edited-B.json').exists(),'completed':False})
    release_root(RAM,ids,rid,top);write(folder/'returned.json',{'retired':rid,'retained_donor':n.donor(n.verify()),'inner_exit':r.returncode});return r.returncode
def start(p,h):
    q=verify();need(os.environ.get('UV_NORMALIZE_SETTLED_RELEASE')==sha(REG),'distinct source grant required');host,z=preceding(p,h)
    with host.exclusively():
        _,z=preceding(p,h);need(Path('/proc/1/comm').read_text().strip()=='systemd' and os.getuid()==1000 and not host.native.foreign() and not OUT.exists() and not RAM.exists(),'physical slot unavailable')
        need(not(G/'package-test-full-stack/physical/intake.json').exists() and not(G/'production-uvx-bins/physical/intake.json').exists(),'newer host owner')
        prior=n.donor(q);n.bounds(5*n.G);OUT.mkdir(mode=0o700);w=1
        write(OUT/'intake.json',{'previous':str(p),'previous_sha256':h,'outer':z['outer'],'boot':z['boot'],'registration':sha(REG),'original_failed':NEG,'pid':os.getpid(),'start_ns':time.time_ns(),'locks':host.locks()})
        try:
            need({k:sha(n.SDK/k) for k in q['released_sdk']}==q['released_sdk'],'released SDK changed')
            old=forensics();need(old==read(R/'retained-first-anchor.json'),'first failed copy or underlying source/fingerprint changed');write(OUT/'first-anchor.json',old)
            release_root(ORAM,old['ram_identity'],old['copy'],old['top']);write(OUT/'first-return.json',{'original_excluded':NEG,'original_B_observations':0,'original_owned_copy_retired':old['copy'],'donor':n.donor(q),'free':n.free()})
            codes={}
            for lane in ('ordinary','attribution'):codes[lane]=owned_lane(host,lane,prior)
            ok=codes=={'ordinary':0,'attribution':0};science=None
            if ok:
                x,y=[read(OUT/k/'checked.json') for k in ('ordinary','attribution')]
                ok=x['changed_units']==y['changed_units'] and x['A']==y['A'] and all(x['B'][k]==y['B'][k] for k in ('private','public','crate','version'))
                if ok:science={'A':x['A'],'B':x['B'],'changed_units':x['changed_units'],'ordinary_unscored_seconds':read(OUT/'ordinary/edited-B.json')['elapsed_ns']/1e9,'traced_units_sha256':sha(OUT/'attribution/edited-B-units.json'),'B_fresh_clean_caller':q['runtime_B']}
            reasons={k:(OUT/k/'namespace.log').read_text()[-1800:] for k,v in codes.items() if v}
            if not ok and not reasons:reasons['comparison']='Independent clone changed-unit rosters or A/B private/public metadata identities disagreed.'
            write(OUT/'disposition.json',{'status':'completed descriptive diagnostic' if ok else 'inconclusive','reason':reasons,'original_excluded':NEG,'original_B_rows':0,'cohort_scores':0,'inner_return_codes':codes,'observation':science,'all_private_copies_released':not(RAM.exists() or ORAM.exists()),'protected':n.donor(q),'native_readers':host.native.foreign(),'free':n.free()});w=0
        except BaseException:(OUT/'failure.txt').write_text(traceback.format_exc());raise
        finally:write(OUT/'worker-return.json',{'code':w,'worker_exit':w,'end_ns':time.time_ns(),'pid':os.getpid(),'locks':host.locks(),'native_at_return':host.native.foreign(),'disposition_sha256':sha(OUT/'disposition.json') if (OUT/'disposition.json').exists() else None})
def closed(p,h):
    verify();need(p==OUT/'outer-return.json','wrong resource path');host,z=preceding(IN,PRE);v,_=n.authorities();_,a=v.local_receipt(OUT,h);i=read(OUT/'intake.json');w=read(OUT/'worker-return.json');d=read(OUT/'disposition.json')
    need(i['previous']==str(IN) and i['previous_sha256']==PRE and z['outer']==i['outer'] and i['boot']==a['boot']==z['boot'] and i['registration']==sha(REG) and i['locks']==w['locks']==a['locks'] and i['start_ns']<w['end_ns'] and w['native_at_return']==[] and not(d['native_readers'] or d['cohort_scores'] or d['original_B_rows']) and w['disposition_sha256']==sha(OUT/'disposition.json') and d['all_private_copies_released'] and d['original_excluded']==NEG and read(OUT/'first-return.json')['original_excluded']==NEG,'bad diagnostic disposition')
    return a
if __name__=='__main__':
    a=sys.argv[1:]
    if a==['verify']:verify();print(sha(REG))
    elif len(a)==2 and a[0]=='inner' and a[1] in ('ordinary','attribution'):inner(a[1])
    elif len(a)==3 and a[0]=='start':start(Path(a[1]).resolve(),a[2])
    elif len(a)==4 and a[0]=='close':n.authorities()[1].close(OUT,*a[1:])
    elif len(a)==3 and a[0]=='closed':print(json.dumps(closed(Path(a[1]).resolve(),a[2]),sort_keys=True))
    else:raise SystemExit('verify | start PREVIOUS SHA | close SESSION CHUNK EXIT | closed OWN_OUTER SHA')
