fn main() {
    let err = uv_normalize::PackageName::from_owned("!".to_owned()).unwrap_err();
    println!("{err}");
}
