"""Detached Python 3.11+ byte, process, unit-graph and public-observation reader."""
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));import evidence as e
need=e.need
GOOD='31c2d0425da15c652970eb79bcd79706810ba3b6e9a97cb21ecdb8ad1a3e4548'
BAD='9c7523e457b5d99c9ac2bac4aba1c9818204b8b602dc42a41de0e2b63fa1468e'
NO='2ba88da7c2a44be06da395390aefa8fc36778eb6387ba060219675671a54d29f'
def field_checks(path):
    c=e.read(path.with_suffix('.json'));log=path.with_suffix('.log')
    need(c['exit']==0 and c['observer_faults']==[] and e.sha(log)==c['log_sha256'] and c['elapsed_ns']==c['monotonic_ns'][1]-c['monotonic_ns'][0]>0 and c['realtime_ns'][0]<c['realtime_ns'][1],'unverified real command/clock')
    return c,log.read_text()
def replay(root):
    manifest=e.read(root/'SHA256.json');files={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256.json'}
    need(files==set(manifest) and all(e.sha(root/n)==d for n,d in manifest.items()),'packet file or content mismatch')
    q=e.read(root/'sources/registration.json');st=e.read(root/'sources/settled-registration.json');need(q['release']=='ohm-1.99.0-18' and q['uv']=='c22e6b71933443e9cd299d4b6ac8de035ed4825b' and q['rustc']=='a4fa11bcd38280639cb94daacc125472657db6c3' and q['ordinary'][1:]==['check','--locked','--offline','-j4'],'different workload')
    a=root/'sources/lib.A.rs';b=root/'sources/lib.B.rs';need(e.sha(a)==q['source_A'] and e.sha(b)==q['source_B'] and b.read_bytes()==e.edit(a.read_bytes()),'different private edit')
    r=root/'stock';orig=root/'first-anchor';i=e.read(r/'intake.json');w=e.read(r/'worker-return.json');out=e.read(r/'outer-return.json');d=e.read(r/'disposition.json')
    need(e.sha(r/'outer-return.json')==GOOD and out['outer']=={'session':73776,'chunk':'235482','exit':0} and out['intake_sha256']==e.sha(r/'intake.json') and out['worker_sha256']==e.sha(r/'worker-return.json') and out['host_released'] and not out['remaining_workers'] and not out['foreign'] and w['disposition_sha256']==e.sha(r/'disposition.json') and not w['native_at_return'],'missing successful native return')
    v=e.read(orig/'outer-return.json');n=e.read(root/'no-start/rejected-capacity.json');f=e.read(r/'first-anchor.json');old=e.read(orig/'worker-return.json');x=f['donor_script_fingerprint'].copy();y=f['copy_script_fingerprint'].copy()
    need(e.sha(orig/'outer-return.json')==BAD and v['outer']=={'session':2868,'chunk':'59881e','exit':1} and old['code']==1 and v['worker_sha256']==e.sha(orig/'worker-return.json') and v['intake_sha256']==e.sha(orig/'intake.json') and f['prior_observations']==0 and f['original_A_listing']==(orig/'ordinary/pristine-A.log').read_text() and 'initial or final A/B is not Cargo-fresh' in (orig/'ordinary/namespace.log').read_text(),'wrong first exclusion')
    need(x.pop('local')==[{'Precalculated':'1785347226.000000000s (README.md)'}] and y.pop('local')==[{'Precalculated':'1785347226.000000000s (src/version.rs)'}] and x==y and {p['mtime_ns'] for p in f['source_timestamp_tie'].values()}=={1785347226000000000},'unknown original false-dirty cause')
    need(e.sha(root/'no-start/rejected-capacity.json')==NO and n['outer']=={'session':12889,'chunk':'5f7524','exit':1} and n['native_process_sha256']==e.sha(root/'no-start/rejected-capacity-native.json') and not(n['physical_record_exists'] or n['new_private_clone_exists'] or n['scored_rows']) and n['original_stock_sha256']==BAD and n['previous_sha256']==e.sha(root/'no-start/prior-stage0-outer.json'),'wrong no-start')
    need(i['original_failed']==d['original_excluded']==st['negative']==BAD and i['previous_sha256']==e.sha(root/'no-start/next-storage-outer.json') and i['outer']==e.read(root/'no-start/next-storage-outer.json')['outer'] and i['registration']==e.sha(root/'sources/settled-registration.json') and st['original_registration']==e.sha(root/'sources/registration.json') and d['status']=='completed descriptive diagnostic' and not d['cohort_scores'] and not d['original_B_rows'] and d['all_private_copies_released'] and d['inner_return_codes']=={'ordinary':0,'attribution':0},'unexpected completion/disposition')
    selected=d['observation']['changed_units'];need(len(selected)==1 and selected[0].startswith('debug/build/uv-normalize/'),'wrong actual producer')
    cas=e.read(root/'metadata/paths.json')
    for logical,key in cas.items():
        loc=root/logical;meta=e.read(loc.with_name(loc.stem+'-metadata.json'));raw=(root/'metadata'/(key+'.rmeta')).read_bytes();actual=e.header(raw)
        need(actual['raw_sha256']==key and all(meta[k]==v for k,v in actual.items()) and meta['sidecar']=={'version':1,'value':actual['public']},'metadata parser or real Cargo sidecar mismatch')
    lanes={}
    for lane in ('ordinary','attribution'):
        p=r/lane;u=e.read(p/'checked.json');cl=e.read(p/'edit-clock.json')
        need(u['source_A']==q['source_A'] and u['source_B']==q['source_B'] and u['source_files']==1593 and cl['mtime_ns']>cl['latest_input_or_A_end_ns'] and u['changed_units']==selected,'incomplete source or edit')
        cmds={}
        for cmd in ('settle-A','pristine-A','edited-B','fresh-B'):
            c,l=field_checks(p/cmd);j=e.read(p/(cmd+'-units.json'));before=j['all_stamps_before'];after=j['all_stamps_after'];changed=sorted(k for k in before.keys()|after if before.get(k)!=after.get(k))
            packages=re.findall(r'^\s*(?:Compiling|Checking) (\S+)',l,re.M)
            need(changed==j['changed_units'] and packages==j.get('compiling_or_checking',j.get('packages')) and j['ordinary_argv']==q['ordinary'],'raw observed stamps/log disprove recorded roster')
            if cmd=='settle-A':need(set(packages)=={'uv-cli','uv','uv-dev'} and j['unscored'] and c['argv']==q['ordinary'],'unexpected settling work')
            elif cmd in ('pristine-A','fresh-B'):need(not(changed or packages) and c['argv']==q['ordinary'] and not j['trace'],'anchor was not genuinely fresh')
            else:
                need(len(packages)==35 and changed==selected and c['argv']==j['actual_argv'] and j['clock_ns']==c['elapsed_ns'] and j['trace']==(lane=='attribution'),'changed edited work')
                if lane=='ordinary':need(c['argv']==q['ordinary'],'ordinary command was instrumented')
                else:
                    need(c['argv'][-len(q['ordinary']):]==q['ordinary'] and c['argv'][0].endswith('strace') and e.sha(p/(cmd+'-units.json'))==d['observation']['traced_units_sha256'],'wrong raw attribution')
                    target=Path(c['cwd']).parent/'target';rustc=Path(q['ordinary'][0]).parent/'rustc';rr=e.trace_units(sorted(p.glob('exec.*')),rustc,target,changed)
                    need(rr==j['rustc'] and len(rr)==j['production_rustc_count']==j['all_rustc_count']==1 and rr[0]['crate']=='uv_normalize' and rr[0]['exit']==0 and '-Zpublic-api-hash' in rr[0]['argv'] and '--emit=dep-info,metadata' in rr[0]['argv'] and c['realtime_ns'][0]<=rr[0]['exec_realtime_ns']<rr[0]['exit_realtime_ns']<=c['realtime_ns'][1],'raw compiler exec/exit mismatch')
            cmds[cmd]={'elapsed_ns':c['elapsed_ns'],'changed':len(changed),'cargo_progress_packages':len(packages)}
        keys=lambda k:cas['stock/'+lane+'/'+k+'.rmeta']
        need(keys('inherited-A')==keys('settled-A')==keys('A')==cas['first-anchor/ordinary/A.rmeta'] and u['A']['raw_sha256']==keys('A') and u['B']['raw_sha256']==keys('B') and u['A']==d['observation']['A'] and u['B']==d['observation']['B'],'history/independent raw comparison failed')
        lanes[lane]=cmds
    caller,log=field_checks(r/'attribution/clean-caller-B')
    need(caller['argv'][1:]==['run','--locked','--offline','-j4','-p','uv-normalize','--example','observe_error'] and log.splitlines()[-1]==q['runtime_B']==d['observation']['B_fresh_clean_caller'] and q['runtime_A'] not in log.splitlines(),'clean caller did not report edited text')
    hd=d['observation'];need(hd['A']['public']==hd['B']['public'] and hd['A']['private']!=hd['B']['private'] and hd['A']['raw_sha256']!=hd['B']['raw_sha256'] and hd['ordinary_unscored_seconds']==lanes['ordinary']['edited-B']['elapsed_ns']/1e9,'altered hash or clocks')
    return {'stock_outer_sha256':GOOD,'unscored':True,'scored_rows':0,'true_producer_invocations_in_traced_copy':1,'downstream_rustc_invocations':0,'rustc_pid':rr[0]['pid'],'traced_rustc_elapsed_ns':rr[0]['elapsed_ns'],'ordinary_elapsed_ns':lanes['ordinary']['edited-B']['elapsed_ns'],'traced_cargo_elapsed_ns':lanes['attribution']['edited-B']['elapsed_ns'],'cargo_progress_packages_per_edit':35,'lanes':lanes,'producer':{t:hd[t] for t in ('A','B')},'clean_B_runtime':q['runtime_B'],'first_bad_anchor':v['outer'],'capacity_refusal':n['outer']}
if __name__=='__main__':print(json.dumps(replay(ROOT),indent=2,sort_keys=True))
