"""Read stock -18 metadata headers, unit stamps and the actual traced foreground lifetimes."""
import ast
import hashlib
import json
import re
from pathlib import Path

def need(ok, why):
    if not ok:
        raise ValueError(why)

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read(p):
    return json.loads(p.read_bytes())

def write(p, data):
    with p.open('x') as f:
        json.dump(data, f, sort_keys=True, indent=2)
        f.write('\n')

def header(raw):
    need(raw[:8] == b'rust\0\0\0\x0a' and raw.endswith(b'rust-end-file'), 'metadata format')
    root = int.from_bytes(raw[8:16], 'little')
    def string(i):
        n = raw[i]
        need(n < 128 and raw[i+1+n] == 0xc1, 'unexpected short symbol encoding')
        return raw[i+1:i+1+n].decode(), i+2+n
    version, _ = string(16)
    need('a4fa11bcd' in version and 'ohm-1.99.0-18' in version, 'wrong compiler')
    need(17 < root < len(raw)-35 and raw[root] == 0, 'root/target tag')
    triple, i = string(root+1)
    need(triple == 'x86_64-unknown-linux-gnu' and raw[i+32] == 0, 'target or crate-name encoding')
    name, _ = string(i+33)
    need(name == 'uv_normalize', 'wrong crate')
    return {'private':raw[i:i+16][::-1].hex(), 'public':raw[i+16:i+32][::-1].hex(),
            'crate':name, 'version':version, 'raw_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def edit(original):
    old = b'digit and may only contain -, _, ., and alphanumeric characters.'
    new = old.replace(b'contain', b'include')
    need(original.count(old)==1 and new not in original and len(old)==len(new), 'unexpected private Display implementation')
    return original.replace(old,new)

def stamps(target):
    return {p.relative_to(target).as_posix():[p.stat().st_ino,p.stat().st_mtime_ns]
            for pattern in ('debug/build/*/*/fingerprint/invoked.timestamp','debug/.fingerprint/*/invoked.timestamp')
            for p in target.glob(pattern)}

def number(arg, flag):
    return arg[arg.index(flag)+1]

def stamp_path(argv,target):
    out=Path(number(argv,'--out-dir'))
    need(out.is_relative_to(target) and out.name=='out', 'unexpected Cargo unit output directory')
    return (out.parent/'fingerprint/invoked.timestamp').relative_to(target).as_posix()

def trace_units(files, rustc, target, changed):
    rows=[]
    for p in sorted(files):
        start=0; args=None; end=None; exit_code=None
        for line in p.read_text().splitlines():
            # strace -ttt, one file per process/thread. Failed exec and libc exit_group are excluded.
            m=re.match(r'^(\d+)\.(\d+) execve\(("(?:[^"\\]|\\.)*"), (\[.*?\]), .+\)\s+= 0$',line)
            if m and ast.literal_eval(m[3])==str(rustc):
                need(args is None,'multiple compiler execs in one pid')
                args=ast.literal_eval(m[4]);start=int(m[1])*10**9+int(m[2].ljust(9,'0'))
                need(isinstance(args,list) and all(isinstance(x,str) for x in args) and args[0]==str(rustc),'incomplete compiler argv')
            n=re.match(r'^(\d+)\.(\d+) \+\+\+ exited with (\d+) \+\+\+$',line)
            if n:end=int(n[1])*10**9+int(n[2].ljust(9,'0'));exit_code=int(n[3])
        if args is None:continue
        need(end is not None and start<=end and exit_code==0,'incomplete real rustc foreground')
        unit='--crate-name' in args and not any(a.startswith('--print')for a in args)
        rows.append({'pid':int(p.suffix[1:]),'argv':args,'exec_realtime_ns':start,'exit_realtime_ns':end,
                     'elapsed_ns':end-start,'exit':exit_code,'unit':unit,'crate':number(args,'--crate-name')if unit else None,
                     'stamp':stamp_path(args,target)if unit else None, 'trace':p.name,'trace_sha256':sha(p)})
    selected=[x['stamp'] for x in rows if x['unit']]
    need(sorted(selected)==sorted(changed) and len(selected)==len(set(selected)),'traced rustc and complete changed-unit roster disagree')
    return rows
