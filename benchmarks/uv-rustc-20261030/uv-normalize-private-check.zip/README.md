# Does a private formatter edit make downstream crates recheck?

On Ohm `1.99.0-18`, a fresh, same-width change to `Display for InvalidNameError` in `uv-normalize` changed the diagnostic displayed by a clean caller. Both copies of ordinary workspace `cargo check --locked --offline -j4` updated only the producer’s invocation stamp. The process trace recorded one successful `rustc` for `uv_normalize` and zero downstream compilers, although Cargo printed 35 package names. The producer’s raw metadata and private crate hash changed. Its public crate hash and Cargo’s recorded public-hash sidecar agreed before and after. The unwrapped command took 0.993 seconds. This single descriptive observation closes the proposed downstream compiler-work opportunity for this edit.

## Replay the recorded result

Unzip into a fresh directory and run `python3 -ISB verify.py` with Python 3.11 or newer. The reader checks all supplied bytes, both raw metadata headers, the captured Cargo sidecar values, command clocks and logs, the complete before/after unit-stamp maps, all 43 strace streams, and the clean caller’s final line. The genuine output is `result.json` beside the ZIP in the source run. The 3.711-second traced Cargo command and its 0.372-second foreground compiler are observer diagnostics. The ordinary clock comes from a separate copy.

`first-anchor/` preserves an earlier run rejected before applying the source edit. The copied `uv-cli` directory contained two files tied for latest mtime. Cargo picked `src/version.rs` in the copy and `README.md` in the donor, making the first check dirty. `no-start/` records a later capacity refusal before creating a new copy or issuing a command. The completed experiment made two independent private copies, allowed one explicitly unscored settling check on each, then required a no-work A before changing the file. The empirical result uses only these latter histories. Every original, settling, edited and post-edit command is unscored. The clean separate example exercises the changed diagnostic through a linked caller.

## Try the production command on a new, independent checkout

Use an offline cache already populated for the pinned uv revision, the released Ohm −18 Cargo/rustc/sysroot on `PATH`, and new private `src` and `target` directories. The task used uv `c22e6b71933443e9cd299d4b6ac8de035ed4825b` and Rust `a4fa11bcd38280639cb94daacc125472657db6c3`. From an unpacked kit on Linux, for example,

```sh
kit=$PWD
git clone --no-hardlinks "$UV_CLONE" "$NEW/src"
git -C "$NEW/src" checkout --detach c22e6b71933443e9cd299d4b6ac8de035ed4825b
cd "$NEW/src"
export CARGO_TARGET_DIR="$NEW/target"
cargo check --locked --offline -j4
cargo check --locked --offline -j4
cmp crates/uv-normalize/src/lib.rs "$kit/sources/lib.A.rs"
cp "$kit/sources/lib.B.rs" crates/uv-normalize/src/lib.rs
cargo check --locked --offline -j4
cargo check --locked --offline -j4
mkdir -p crates/uv-normalize/examples
test ! -e crates/uv-normalize/examples/observe_error.rs
cp "$kit/sources/caller.rs" crates/uv-normalize/examples/observe_error.rs
CARGO_TARGET_DIR="$NEW/clean-caller-target" cargo run --locked --offline -j4 -p uv-normalize --example observe_error
```

Supply a fresh absolute `NEW`, existing absolute `UV_CLONE` and isolated populated `CARGO_HOME`. The repeated A/B check should perform no work. Cargo progress text alone cannot identify compiler invocations. For comparable instrumentation, inspect `stock/attribution/edited-B.json` for the exact strace options. A saved cache, absolute filesystem, fresh-clone order or host differs in an independent new run. This packet authenticates the original measurements without requiring that machine.
