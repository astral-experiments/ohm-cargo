# Reproduce the complete compiler change on the uv package

This independent comparison builds all uv test programs with P, the matched build of bare Ohm −20 source, and CZD, the same source plus the assembly recognition from #270 and #275. It removes the 62-line test added by uv #20770 from a private checkout at c22e6b71933443e9cd299d4b6ac8de035ed4825b. Both arms run the ordinary locked, offline package command against their own unchanged histories. The tool harness has 181 tests before the edit and 180 afterwards.

Use the 65-file Linux x86-64 SDKs from the matched binary kit or build the pinned source as described in REBUILD.md. Obtain a complete uv Git clone including the 0.12.0 tag, and a suitable populated offline Cargo registry. See PACKAGE.md for dependencies and the other two package comparisons. Run these commands from the extracted directory on an otherwise idle Linux host with ptrace access, strace at /usr/bin/strace, GNU cp, git, a system LLVM shared library exporting the BLAKE3 C implementation, and Python 3.11 or later.

~~~sh
sha256sum -c SHA256SUMS
sha256sum -c FULL-STACK-SHA256SUMS
python3 -ISB full_stack.py \
    --uv-clone /path/to/uv --cargo-home /path/to/populated-cargo-home \
    --control-sdk /path/to/matched/P --candidate-sdk /path/to/matched/CZD \
    --run /path/to/new-private-output
python3 -ISB full_stack_score.py /path/to/new-private-output
~~~

For locally built SDKs, pass --subjects /path/to/build/subjects.json. P and CZD must match across the other 64 SDK files and independently pass the existing source and native-assembly checks. The default per-target ceiling is 13 GiB. The output must be new, outside all inputs, with at least a 122 GiB floor plus room for two A histories, a fresh writable copy and retained program files. Local reproduction uses private ordinary filesystem copies, normal wait4 timing of unwrapped Cargo and a same-UID process sampler. Its second unchanged A pass and first B admission record per-process exec traces for each arm. All 24 timed Cargo calls run without strace. Their ordinary work, products, exit and wait4 clocks are checked separately. The original controlled-host study used compressed checkpoints under its separate memory and filesystem budgets.

P's first ordinary A repeat fixes the allowed raw images for each of 17 roles before the next P repeat or any CZD command. A separate first P edit fixes the B classes before the first CZD edit. Both actual files are required for each observed alternative, including when both timed arms report the same alternate. The harness recomputes the two complete Wild images and GNU build IDs and compares all remaining bytes. Each role's path, file size and observable behavior remain exact. The permitted difference is the 0/8 entry size in the unique eligible .rodata section header and the resulting GNU build ID. Other geometry uses the exact P bytes. Every observation retains all 15 literal test lists and both CLI versions.

The run has an unscored B admission for each compiler, then 12 independently registered pairs, six in each order, with no efficacy pilot. The scorer returns the raw nanoseconds, paired ratios, per-order medians, rank 3–10 interval, exact two-sided test against 2× and the separate Holm12 decision. By default each absent historical contrast contributes p=1. Optional --combined-run and --prior-guard-run arguments add independently replayed local endpoints. All three permanently excluded package attempts stay at p=1. The earlier check attempt stopped at admission and supplied no eligible statistic. The earlier C/CZD marginal result has its own Holm10 decision. An interrupted or inadmissible run retains its files and yields no full-stack statistic.

This kit adds one standalone route. The original C/CZD study and the original direct P/ZD study still use package_rerun.py with their prior ordinary/traced within-arm raw equality rule. The original P/ZD study stopped during its candidate A setup before any B pair. No previous performance observations supply a P/CZD row. Use python3 -ISB calibrate_trace.py /path/to/ohm-20-uv-package-test-v3-combined.zip to verify the exec decoder against the public 1,607-argument rustc and 607-argument Wild traces. Run python3 -ISB test_full_stack.py for a synthetic test of the new route. It uses script SDKs, a temporary Git repository and constructed ELF images.
