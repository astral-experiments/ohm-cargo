"""Run and retain a fresh P-to-CZD package comparison, independent of the original C/CZD and P/ZD studies."""
import argparse
import os
from pathlib import Path
import random
import shutil
import sys
import time
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import package_rerun as p
import full_stack_trace as trace
import package_process as process
from full_stack_elf import PhasePrograms
from common import allocated,copy,need,sha,write
from rerun import read,version_output

SCIENCE="c545177f4e5e2fb4284ce034187fa5d8b4619154a3d659f57fbdf2a589112cd1"
REGISTRATION="d9791f9e9fe4995725327c143032e699ac38e30913d7a50df8e6e4f5eae3d988"
SCOPE="P-to-CZD/package-test"
ARMS=("P","CZD")


def plan():
    src=HERE/"full-stack-original"
    need(sha(src/'protocol.json')==SCIENCE and sha(src/'registration.json')==REGISTRATION,"different native full-stack registration")
    doc=read(src/'protocol.json')
    order=[list(ARMS) for _ in range(6)]+[list(reversed(ARMS)) for _ in range(6)]
    random.Random(doc['order_seed']).shuffle(order)
    need(doc['name']==SCOPE and order==doc['pairs'] and len(doc['expected_reported_test_roles'])==15,"different registered workload")
    return doc


class Stack(p.Package):
    def __init__(self,args,workflow,doc):
        need(args.contrast=="CZD" and doc.get('name')==SCOPE,"unexpected full-stack arms")
        # Only constructor label selection differs. All SDK file checks subsequently use the true P/CZD names.
        with patch.object(p.original,"baseline",lambda candidate:"P"):
            super().__init__(args,workflow,doc)
        self.elf=PhasePrograms(self.root,write_proofs=True)
        self.references={}
        write(self.root/"full-stack-intake.json",{"scope":SCOPE,"scientific_sha256":SCIENCE,"registration_sha256":REGISTRATION,
              "true_arms":list(ARMS),"original_subjects_sha256":sha(args.subjects),"workload":"independent portable reproduction",
              "initial_history":"independent empty target per actual compiler","resource_policy":"cold targets kept on reviewer-selected filesystem"})

    def cargo(self,arm,edit,state,folder):
        if not trace.requested(folder):
            return super().cargo(arm,edit,state,folder)
        with trace.wrap(self.cmd,folder):
            result=super().cargo(arm,edit,state,folder)
        write(folder/"unscored-exec.json",trace.inventory(folder,self.root,arm,self.cmd,self.subjects[arm]["driver_sha256"]))
        return result

    def space(self,additional=0):
        super().space(additional)
        need(shutil.disk_usage('/').free>self.reserve,'root would breach its protected reserve')

    def seal(self,phase,products,directory):
        parent=self.root/'records'/p.NAME
        later=[parent/'A/P/verify-repeat',parent/'A/CZD/cold'] if phase=="A" else [parent/'admission/try-0/1-CZD']
        need(phase not in self.references and not any(path.exists() for path in later),"control class reached after a later command")
        reference=self.elf.freeze(products)
        stamp=self.seal_time()
        command=directory/'command.json'
        need(read(command)['end_ns']<stamp,"control command has not returned")
        write(parent/('control-forms-'+phase+'.json'),{"control":"P","state":phase,"source_command":sha(command),
              "monotonic_ns":stamp,"roles":reference})
        self.references[phase]=reference

    def prime(self,edit,arm):
        self.space(self.budget)
        self.select(arm)
        self.active.mkdir()
        for name in ("target","home","tmp","cargo-home"):
            (self.active/name).mkdir()
        self.config()
        copy(self.root/"source-template",self.src)
        logs=self.root/"records"/edit/"A"/arm
        versions={exe:version_output([self.sdk/"bin"/exe,"-vV"],self.env,self.src).decode() for exe in ("rustc","cargo")}
        need(p.original.check_versions(self.plan,self.subjects,versions),"different compiler or Cargo")
        self.cargo(arm,edit,"A",logs/"cold")
        work0,ordinary=self.cargo(arm,edit,"A",logs/"ordinary-repeat")
        if arm=="P":
            self.seal("A",ordinary["all_products"],logs/"ordinary-repeat")
        self.elf.accept("A",ordinary["all_products"],self.references["A"])
        work1,traced=self.cargo(arm,edit,"A",logs/"verify-repeat")
        self.elf.accept("A",traced["all_products"],self.references["A"])
        need(work0==work1 and self.same_products(ordinary,traced),"A work or registered program behavior did not settle")
        marker=p.markers(self.target,logs/"raw-depinfo")
        need(p.original.policy(arm,{k for k,r in marker["units"].items() if r["opaque"]}),"incorrect A native-input policy")
        seed=self.root/"seeds"/f"{edit}-{arm}"
        self.active.rename(seed)
        source=sha(seed/"source"/self.plan["endpoints"][edit]["path"])
        write(logs/"seed.json",{"arm":arm,"edit":edit,"seed":str(seed),"B_seen":False,"versions":versions,"markers":marker,
              "driver_sha256":self.subjects[arm]["driver_sha256"],"source_sha256":source,"repeat_sha256":sha(logs/"verify-repeat/products.json")})
        write(logs/"package-seed.json",{"identity":p.identity(seed),"allocated":allocated(seed),"A_only":True,"source":source,
              "driver_sha256":self.subjects[arm]['driver_sha256'],"source_template_sha256":sha(self.root/'sources/Cargo.lock')})
        self.space(allocated(seed))
        return traced

    def endpoint(self):
        edit=p.NAME
        originals=[self.prime(edit,arm) for arm in ARMS]
        need(self.same_products(*originals),"P/CZD A behavior differs")
        parent=self.root/"records"/edit
        admissions,ledger,exclusions={},[],[]
        for label,arms in [("admission",list(ARMS)),*((f"pair-{i:02d}",order) for i,order in enumerate(self.doc["pairs"],1))]:
            for attempt in range(3):
                stamp=time.time_ns()
                paths,products=[],[]
                for rank,arm in enumerate(arms):
                    path=f"{label}/try-{attempt}/{rank}-{arm}"
                    folder=parent/path
                    paths.append(path)
                    try:
                        work,out=self.trial(edit,arm,folder,stamp)
                    except process.Busy:
                        fault=read(folder/"excluded.json")
                        need(label!="admission" and fault["events"] and p.identity(self.active)==fault["active"] and
                             self.active==self.root/"active" and not self.active.is_symlink() and
                             all(not self.active.samefile(self.root/'seeds'/f"{edit}-{a}") for a in ARMS),"invalid foreign retry")
                        exclusions.append({"label":label,"attempt":attempt,"order":arms,"paths":paths.copy(),"proof_sha256":sha(folder/"excluded.json")})
                        write(folder/"attempt-excluded.json",exclusions[-1])
                        need(process.clear_existing(),"foreign native work remained")
                        shutil.rmtree(self.active)
                        break
                    if label=="admission" and arm=="P":
                        self.seal("B",out["all_products"],folder)
                    self.elf.accept("B",out["all_products"],self.references["B"])
                    if label=="admission":
                        admissions[arm]=work,out
                    else:
                        need(work==admissions[arm][0] and self.same_products(out,admissions[arm][1]),"different own-arm B proof")
                    products.append(out)
                else:
                    need(self.same_products(*products),"different edited programs or behavior")
                    ledger.append({"label":label,"attempt":attempt,"order":arms,"paths":paths})
                    break
            else:
                raise ValueError("three objectively contaminated attempts; partial records retained")
        write(parent/"closed.json",{"contrast":"CZD","control":"P","pilot":None,"continues":True,"scored_pairs":12,"ledger":ledger,"exclusions":exclusions})
        for arm in ARMS:
            seed=self.root/"seeds"/f"{edit}-{arm}"
            need(p.identity(seed)==read(parent/"A"/arm/"package-seed.json")["identity"] and not seed.is_symlink(),"incorrect disposable seed")
        for arm in ARMS:
            shutil.rmtree(self.root/"seeds"/f"{edit}-{arm}")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("uv-clone","cargo-home","control-sdk","candidate-sdk","run"):
        parser.add_argument("--"+name,type=Path,required=True)
    parser.add_argument("--subjects",type=Path,default=HERE/"subjects.json")
    parser.add_argument("--reserve-gib",type=int,default=122)
    parser.add_argument("--max-target-gib",type=int,default=13)
    args=parser.parse_args()
    args.contrast="CZD"
    need(args.reserve_gib>=122 and 1<=args.max_target_gib<=13,"reviewer reserve must be at least 122 GiB and each target at most 13 GiB")
    if read(args.subjects).get("provenance")!="independent-source-build":
        need(sha(args.subjects)==sha(HERE/"subjects.json"),"use the signed SDKs or independently checked source-build receipts")
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:16])
    runner=Stack(args,read(HERE/"workflow.json"),plan())
    runner.setup()
    runner.endpoint()
    write(runner.root/"complete.json",{"phase":SCOPE,"scientific_sha256":SCIENCE,"contrast":"CZD","portable":True,
          "closed_sha256":sha(runner.root/"records"/p.NAME/"closed.json")})
    print("Completed 12 independent pairs. Use full_stack_score.py to verify them.")


if __name__=="__main__":
    main()
