"""Replay complete ordinary P-to-CZD raw rows, true P-only classes and the independent twelve-way family."""
import argparse,json,os,re,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import full_stack as stack
import full_stack_trace as trace
from full_stack_elf import PhasePrograms
import package_rerun as p
import rerun as original
import registered_score
import package_score as prior
from package_score import check_markers
from common import need,sha
read=p.read

def raw(root,workflow=None,doc=None):
    published=workflow is None and doc is None
    root=Path(root);inp=read(root/'inputs.json');entry=read(root/'package-intake.json');done=read(root/'complete.json');candidate=inp['contrast'];base='P'
    need(candidate=='CZD','wrong complete-stack treatment');native=stack.plan();doc=doc or native;wf=workflow or read(HERE/'workflow.json');edit=p.NAME
    need(entry['tool_only_inputs_file_sha256']==sha(root/'inputs.json') and entry['combined_plan']==p.COMBINED and entry['direct_plan']==p.DIRECT and set(entry['all_roles'])==set(doc['expected_reported_test_roles']) and entry['contrast']==candidate,'different complete-package intake')
    extra=read(root/'full-stack-intake.json')
    need(extra['scope']==stack.SCOPE and extra['scientific_sha256']==stack.SCIENCE and extra['registration_sha256']==stack.REGISTRATION and extra['true_arms']==['P','CZD'] and set(inp['sdks'])=={'P','CZD'},'wrong native protocol or actual private SDK arms')
    compare=PhasePrograms(root)
    parent=root/'records'/edit;closed=read(parent/'closed.json');need(done['phase']==stack.SCOPE and closed['control']=='P' and done['portable'] and done['contrast']==candidate==closed['contrast'] and done['closed_sha256']==sha(parent/'closed.json') and done['scientific_sha256']==stack.SCIENCE,'unclosed or unknown direct comparison')
    need(inp['argv']==[str(Path(inp['root'])/'sdk/bin/cargo'),*doc['ordinary_argv'][1:]] and inp['workflow_sha256']==sha(HERE/'workflow.json'),'different ordinary Cargo command')
    maps=read(root/'sdk-manifests.json');prov=inp['subject_provenance'];a,b=maps[base],maps[candidate]
    if published:
        subjects_path=root/'source-build-proof/subjects.json' if prov.get('provenance')=='independent-source-build' else HERE/'subjects.json'
        need(sha(subjects_path)==extra['original_subjects_sha256'],'wrong SDK source qualification record')
        if prov.get('provenance')=='independent-source-build':
            from rebuild import verify_subjects
            need(verify_subjects(root/'source-build-proof/subjects.json',[base,candidate])==prov,'source-build receipts do not match the actual measured pair')
        else:need(prov==read(HERE/'subjects.json'),'SDK provenance differs from published binaries')
    diff=[k for k in a if a[k]!=b.get(k)];need(a.keys()==b.keys() and len(diff)==1 and re.fullmatch(r'lib/librustc_driver[^/]*\.so',diff[0]) and {k:w['sha256'] for k,w in a.items() if k!=diff[0]}==prov['common_members'],'wrong SDK comparison')
    for arm in (base,candidate):
        need(prov[arm]['tree']==wf['subject_source_trees'][arm] and prov[arm]['driver_sha256']==maps[arm][diff[0]]['sha256'],'changed release-source patch or compiler hash')
    sources={x:root/'sources'/('tool-test-'+x+'.rs') for x in ('A','B')};u=doc['uv']['edit']
    git=read(root/'package-source.json');need(git['HEAD']==wf['A']['commit'] and git['tree']==wf['A']['tree'] and git['parent']==wf['parent'] and git['ref']==doc['uv']['ref'] and git['source_blobs']=={s:u[s] for s in ('A','B')} and git['cargo_lock_sha256']==sha(root/'sources/Cargo.lock') and re.fullmatch('[a-f0-9]{40}',git['tag_0_12_0']),'different original Git checkout, tracked edit or Cargo.lock')
    from git_identity import verify_identity
    identity=verify_identity(read(root/'source-identity.json'),wf)
    need((git['local_core_abbrev'],git['description'],git['describe_always'],git['uv_build_script_log'])==(identity['local_core_abbrev'],identity['describe_tags_always'],identity['describe_always'],identity['uv_build_script_log']),'package and shared private Git identities disagree')
    if published:need(git['description']==wf['A']['git_description'].split()[-1],'different local release history')
    need(all(original.blob(src.read_bytes())==u[state] for state,src in sources.items()),'wrong literal tracked file bytes');known={}
    def row(folder,state,arm):
        x=read(folder/'command.json');f=folder/'cargo.log';txt=f.read_text(errors='replace');src=x['source'];programs=read(folder/'all-products.json');prod=read(folder/'products.json');roles=doc['expected_reported_test_roles']
        need(read(folder/'package-observation.json')=={n:sha(folder/n) for n in ('command.json','cargo.log','stamps-before.json','stamps-after.json','external-builds.json','all-products.json','products.json','public-paths.json','product-identities.json','self-version.stdout','self-version.stderr')},'changed raw foreground or external observation')
        need(src['state']==state and src['path']==u['path'] and src['blob']==u[state] and src['sha256']==sha(sources[state]),'different actual Git input')
        need(x['arm']==arm and x['endpoint']==edit and x['actual_argv']==inp['argv'] and x['exit']==0 and type(x['elapsed_ns']) is int and x['end_ns']-x['start_ns']==x['elapsed_ns']>0 and x['post_foreground']['remaining']==[] and x['post_foreground']['session']==x['pid'] and x['log_sha256']==sha(f),'altered foreground command, clock, real log or session')
        usage=x['rusage_wait4'];need(set(usage)=={'ru_utime','ru_stime','ru_minflt','ru_majflt','ru_nvcsw','ru_nivcsw','ru_inblock','ru_oublock','ru_maxrss'} and min(usage.values())>=0,'incomplete foreground resource record')
        before=read(folder/'stamps-before.json');after=read(folder/'stamps-after.json');need(x['packages']==sorted(re.findall(r'^\s*Compiling ([^\s]+)',txt,re.M)) and x['changed_stamps']==sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)),'dirty units differ from native log or stamps')
        ev=read(folder/'external-builds.json');need(ev['during_foreground']==[e for e in ev['unfiltered'] if x['start_ns']<=e['ns']<=x['end_ns']] and not ev['during_foreground'],'counted foreign activity')
        pairs=re.findall(r'^\s*Executable (.+?) \((.+)\)\s*$',txt,re.M);need(len(pairs)==len(set(k for k,_ in pairs))==15 and set(k for k,_ in pairs)==set(roles),'missing, duplicated or unexpected Cargo-reported executable')
        target=Path(inp['root'])/'active/target';sv=Path(inp['root'])/'active/source'
        reported={k:str(Path(os.path.normpath(sv/rawpath)).relative_to(target)) for k,rawpath in pairs};reported.update(uv='debug/uv',uvx='debug/uvx')
        paths=read(folder/'public-paths.json');need(set(paths)==set(programs)==set(reported) and prod['files']==paths and prod['all_products']==programs,'changed 17-product publication')
        ids=read(folder/'product-identities.json');need(set(ids)==set(paths) and len({tuple(v) for v in ids.values() if len(v)==2 and min(v)>0})==17,'shared or missing native output identity')
        for name,z in programs.items():
            rel=z['path'];h=z['sha256'];v=paths[name];need(rel==reported[name] and '..' not in Path(rel).parts and v=={k:z[k] for k in ('path','bytes','sha256')} and re.fullmatch('[a-f0-9]{64}',h),'unbound program path or hash')
            cas=root/'objects'/h
            if h not in known:
                need(cas.is_file() and not cas.is_symlink() and cas.stat().st_size==z['bytes']>0 and sha(cas)==h,'missing complete ELF or changed raw bytes')
                with cas.open('rb') as file:header=file.read(20)
                need(len(header)==20 and header[:7]==b'\x7fELF\x02\x01\x01' and header[16:18] in (b'\x02\0',b'\x03\0') and header[18:]==b'>\0','wrong saved x86-64 executable');known[h]=z['bytes']
            need(known[h]==z['bytes'],'changed size')
            pre=folder/'test-lists'/p.programs.role_file(name);stdout=Path(str(pre)+'.stdout');stderr=Path(str(pre)+'.stderr')
            need(z['exit']==0 and z['argv_tail']==(['--list'] if name in roles else ['--version']) and sha(stdout)==z['stdout_sha256'] and sha(stderr)==z['stderr_sha256'],'mismatched literal list/CLI execution')
            if name in roles:
                all_lines=stdout.read_text().splitlines();n=sum(l.endswith(': test') for l in all_lines);m=sum(l.endswith(': benchmark') for l in all_lines);footer=[l for l in all_lines if re.fullmatch(r'\d+ tests?, \d+ benchmarks?',l)]
                need(len(footer)==1 and [int(i) for i in re.findall(r'\d+',footer[0])]==[n,m] and (n,m)==(z['tests'],z['benchmarks']),'incomplete real harness listing')
        tool=programs[p.programs.TOOL];need((tool['stdout_sha256'],tool['tests'])==(u[state+'_list'],u[state+'_count']) and json.loads((folder/'self-version.stdout').read_bytes())==prod['self_version']==wf['A']['self_version'] and (folder/'test-lists/uv.stdout').read_text().strip()==prod['version']==wf['A']['version'],'changed Git identity or tool test inventory')
        if state=='B':
            w=read(folder/'edited-owner.json');need('uv' in x['packages'] and w['crate_root']=='crates/uv/tests/tool/main.rs' and w['depfiles'],'edited target did not execute')
            for k,h in w['depfiles'].items():
                path=Path(k);data=folder/'owner-depinfo'/h
                need(path.parts[:3]==('debug','build','uv') and str(path.parent.parent/'fingerprint/invoked.timestamp') in x['changed_stamps'] and sha(data)==h and w['crate_root'].encode() in data.read_bytes() and u['path'].encode() in data.read_bytes(),'wrong ordinary rebuilt unit')
        if trace.requested(folder):
            proof=trace.inventory(folder,root,arm,inp['argv'],prov[arm]['driver_sha256'])
            need(read(folder/'unscored-exec.json')==proof,'different unscored rustc, linker or genuine entry')
        else:need(not (folder/'unscored-exec.json').exists() and not (folder/'unscored-execs').exists(),'timed or ordinary row was traced')
        return x,programs
    seeds={};diagnostics={};A={};B={};ordinary_a={};a_times={}
    for arm in (base,candidate):
        d=parent/'A'/arm;z=read(d/'seed.json');receipt=read(d/'package-seed.json');seeds[arm]=receipt
        need(not z['B_seen'] and receipt['A_only'] and len(receipt['identity'])==2 and receipt['source']==z['source_sha256']==sha(sources['A']) and receipt['driver_sha256']==z['driver_sha256']==prov[arm]['driver_sha256'] and original.check_versions(wf,prov,z['versions']) and z['repeat_sha256']==sha(d/'verify-repeat/products.json'),'incomplete own-arm never-B seed')
        check_markers(d,z['markers'],arm);cold,_=row(d/'cold','A',arm);r1,outputs=row(d/'ordinary-repeat','A',arm);r2,A[arm]=row(d/'verify-repeat','A',arm)
        need(all(r1[k]==r2[k] for k in ('packages','changed_stamps')) and cold['end_ns']<r1['start_ns']<r1['end_ns']<r2['start_ns'], 'unsettled ordinary A work or wrong native order')
        ordinary_a[arm]=outputs
        a_times[arm]=(cold['start_ns'],r2['end_ns'])
        diagnostics[arm]={'cold_seconds':cold['elapsed_ns']/1e9,'ordinary_repeat_seconds':r1['elapsed_ns']/1e9,'prior_raw_sha256':sha(d/'seed.json'),'active_opaque_A':z['markers']['all_opaque_paths'],'A_checkpoint_allocated_bytes':receipt['allocated']}
    def reference(state, control_products, base_folder, next_folder):
        saved=read(parent/('control-forms-'+state+'.json'))
        first=base_folder/'command.json'
        need(saved['control']==base and saved['state']==state and saved['source_command']==sha(first)
             and read(first)['end_ns']<saved['monotonic_ns']<read(next_folder/'command.json')['start_ns']
             and saved['roles']==compare.freeze(control_products),'incorrect or late control-only ELF forms')
        return saved['roles']
    forms_a=reference('A',ordinary_a[base],parent/'A'/base/'ordinary-repeat',parent/'A'/base/'verify-repeat')
    need(a_times[base][1]<a_times[candidate][0], 'treatment began before the P-only warm history')
    for arm in (base,candidate):
        compare.accept('A',ordinary_a[arm],forms_a)
        compare.accept('A',A[arm],forms_a)
    need(compare.equal(A[base],A[candidate]) and seeds[base]['identity']!=seeds[candidate]['identity'],'mismatched A programs or shared private arm checkpoint')
    excludes=closed['exclusions'];ledger=closed['ledger'];rows=[];last=0;used=set();rosters={};pilot=None;resumed=True
    setup_order=[base,candidate];labels=[('admission',setup_order)];forms_b=read(parent/'control-forms-B.json')['roles']
    def read_b(folder,arm):
        x,programs=row(folder,'B',arm);origin=read(folder/'warm-origin.json');before=read(folder/'source-A.json')
        need(origin['never_primed_B'] and origin['driver_sha256']==prov[arm]['driver_sha256'] and origin['identity']==seeds[arm]['identity'] and origin['source_sha256']==before['sha256']==sha(sources['A']) and origin['seed_receipt_sha256']==sha(parent/'A'/arm/'package-seed.json') and before['blob']==u['A'] and before['mtime_ns']<x['source']['mtime_ns'],'incorrect target history or uncommitted edit')
        p.programs.phase_change(A[arm],programs,parent/'A'/arm/'verify-repeat',folder,doc)
        compare.accept('B',programs,forms_b)
        return x,programs
    def collect(label,order,record):
        nonlocal last
        attempt=record['attempt'];need(record['label']==label and record['order']==order and 0<=attempt<=2 and record['paths']==[f'{label}/try-{attempt}/{i}-{a}' for i,a in enumerate(order)] and set(record['paths']).isdisjoint(used),'changed randomized sequence or replayed row')
        used.update(record['paths']);tries=[v for v in excludes if v['label']==label];need([x['attempt'] for x in tries]==list(range(attempt)) and {p.name for p in (parent/label).iterdir()}=={f'try-{i}' for i in range(attempt+1)},'unexplained unreported attempt')
        for e in tries:
            need(label!='admission' and 1<=len(e['paths'])<=2 and e['order']==order and e['paths']==[f"{label}/try-{e['attempt']}/{j}-{a}" for j,a in enumerate(order[:len(e['paths'])])],'incorrect exclusion')
            exc=parent/e['paths'][-1];w=read(exc/'excluded.json');need(read(exc/'attempt-excluded.json')==e and sha(exc/'excluded.json')==e['proof_sha256'] and w['events'] and all(t['foreign'] and all(j['name'] in p.process.NAMES and j['pid']>0 and j['start_ticks']>0 for j in t['foreign']) for t in w['events']),'missing saved outside-process events')
            if w['reason']=='foreign-overlap':
                cmd=read(exc/'command.json');need(all(cmd['start_ns']<=v['ns']<=cmd['end_ns'] for v in w['events']) and sha(exc/'cargo.log')==cmd['log_sha256'],'no in-clock external activity')
            else:need(w['reason']=='foreign-before' and not (exc/'command.json').exists(),'incorrect pre-timer exclusion')
            for j,path in enumerate(e['paths'][:-1]):read_b(parent/path,order[j])
        values={};times=[];bundles=[];edits=[]
        for a,rel in zip(order,record['paths']):
            f=parent/rel;x,pub=read_b(f,a);times.append(x);bundles.append(pub);edits.append(x['source']['mtime_ns']);values[a]=x['elapsed_ns'];key=x['packages'],x['changed_stamps']
            if label=='admission':
                rosters[a]=key;B[a]=pub;mm=read(f/'markers.json');check_markers(f,mm,a);diagnostics[a].update(B_packages=key[0],B_changed_stamps=key[1],B_opaque=mm['all_opaque_paths'])
            need(key==rosters[a] and compare.equal(pub,B[a]),'different own-arm admitted B work or products')
        need(times[0]['start_ns']>last and times[0]['end_ns']<times[1]['start_ns'] and compare.equal(*bundles) and edits[0]==edits[1],'different native products, edit, or execution order')
        last=times[1]['end_ns'];return order[0],values[base],values[candidate]
    need(len(ledger)>=len(labels),'missing admission or pilot')
    for i,(label,order) in enumerate(labels):
        first,b,c=collect(label,order,ledger[i])
        if label=='admission':
            a,bdir=(parent/j for j in ledger[i]['paths'])
            ref=reference('B',B[base],a,bdir)
            need(ref==forms_b and a_times[candidate][1]<read(a/'command.json')['start_ns'],'wrong or premature P-only B admission')
        
    if resumed:
        need(len(ledger)==len(labels)+12,'requires twelve held-out pairs')
        for i,order in enumerate(doc['pairs'],1):rows.append(collect(f'pair-{i:02d}',order,ledger[len(labels)+i-1]))
    else:need(len(ledger)==len(labels),'ran after a failed excluded pilot')
    need(closed['pilot']==pilot and closed['continues'] is resumed and closed['scored_pairs']==len(rows) and {p.name for p in parent.glob('pair-*')}=={f'pair-{i:02d}' for i in range(1,len(rows)+1)} and all(x['label'] in {r['label'] for r in ledger} for x in excludes),'different pilot decision or unaccounted data')
    need(not (parent/'pilot').exists(),'unexpected unregistered efficacy pilot')
    return {'role':'independent-portable-reproduction','contrast':stack.SCOPE,'complete_sha256':sha(root/'complete.json'),'sdk_provenance':prov.get('provenance','original-qualified-sdk-bytes'),'diagnostics':diagnostics,'excluded_pilot_ns':pilot,'excluded_attempts':excludes,'pairs':len(rows),'raw_ns':[list(x) for x in rows],'summary':score_times(rows)}

def score_times(rows):
    need(len(rows)==12 and all(arm in stack.ARMS for arm,_,_ in rows),'incomplete or unrelated comparison')
    values=registered_score.score_times([('C' if first=='P' else 'CZD',base,treat) for first,base,treat in rows])
    values['P_seconds_median']=values.pop('C_seconds_median')
    values['CZD_seconds_median']=values.pop('candidate_seconds_median')
    strata=values['per_order_ratio_medians']
    values['per_order_ratio_medians']={'P-first':strata['C-first'],'CZD-first':strata['candidate-first']}
    return values

def family(stats):
    family=stack.plan()['family']
    labels=family['ordered_labels']
    forbidden=family['permanently_excluded']
    need(set(stats)<=set(labels)-set(forbidden) and 'CZD/check' not in stats,'no positive statistic exists for these original exclusions')
    raw={k:stats[k]['p_against_2']['two_sided_p'] if k in stats else 1. for k in labels}
    previous=0.
    out={}
    for i,k in enumerate(sorted(labels,key=lambda n:(raw[n],n))):
        need(0<=raw[k]<=1,'invalid p value')
        previous=max(previous,min(1.,(12-i)*raw[k]))
        out[k]={'raw_p':raw[k],'adjusted_p':previous,'complete':k in stats,'confirmed':bool(k in stats and stats[k]['individual_gate'] and previous<.05),'excluded':k in forbidden}
    return out


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('run',type=Path)
    ap.add_argument('--combined-run',type=Path,help='optional independently verified earlier C/CZD package reproduction')
    ap.add_argument('--prior-guard-run',type=Path,action='append',default=[],help='optional earlier full targeted local reproductions')
    args=ap.parse_args()
    res=raw(args.run)
    stats=prior.previous(args.prior_guard_run,read(HERE/'workflow.json'))
    if args.combined_run:
        earlier=prior.raw(args.combined_run)
        need(earlier['contrast']=='CZD' and args.combined_run.resolve()!=args.run.resolve(),'wrong separate marginal comparison')
        if earlier['summary']:stats[prior.COMBINED]=earlier['summary']
    stats[stack.SCOPE]=res['summary']
    print(json.dumps({'scope':'independent reviewer reproduction','full_stack':res,'holm12':family(stats),'absent_raw_p':1.,
                      'previous_primary_Holm10_decision_unchanged':True,'pooled':False},indent=2,sort_keys=True))
if __name__=='__main__':main()
