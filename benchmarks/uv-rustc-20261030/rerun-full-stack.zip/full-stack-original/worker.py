"""Use the ordinary package worker; keep the complete unedited control originals before the next compile."""
from copy import deepcopy
from pathlib import Path
import sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import evidence as e
w=e.module(e.G/'package-test/worker.py','normal_full_package')
arc=e.module(e.G/'package-test/checkpoint.py','unchanged_zstd_transport')
m=w.m;need=e.need;read=e.read;write=e.write


def checked_contour(result,roles,original):
    canonical=deepcopy(original(result))
    need(set(canonical['files'])==set(canonical['elf_sha256'])=={'uv','uvx','tool'},'missing selected role')
    for name,typ in [('uv','uv'),('uvx','uvx'),('tool',w.products.TOOL)]:
        ent=roles[typ];actual=canonical['elf_sha256'][name]
        need(actual in ent['class']['allowed'] and canonical['files'][name]['sha256']==actual, 'inadmissible original three-product hash')
        canonical['files'][name]['sha256']=canonical['elf_sha256'][name]=ent['class']['observed']
    return canonical


def main(args):
    action,name,arm,path,mtime=args;folder=Path(path);root=folder.parent
    need(arm in ('P','CZD') and name=='tool-test','wrong requested subject or edit')
    before=w.setup(action,folder)
    original=w.study.c.normal;raw_contour=w.study.contour
    def run(dest,*v,**kw):
        row,selected=original(dest,*v,**kw)
        if action=='warm' and dest.name in ('ordinary-repeat-A','verify-repeat-A'):
            items=read(dest/'all-products.json')
            if dest.name=='ordinary-repeat-A':
                pending=m.o.VISIBLE/'tmp/pre-trace-elf-cas-full-stack'
                pending.mkdir(mode=0o700)
                held={}
                for role,item in items.items():
                    file=m.r.TARGET/item['path'];need(file.resolve().is_relative_to(m.r.TARGET.resolve()),'foreign A file')
                    held[role]=arc.keep(file,pending,item,m.bounds)
                write(dest/'pre-trace-retained.json',held)
                if arm=='P':e.reference(root,'A',create=True,live=m.r.TARGET)
            e.membership(items,read(e.ref_path(root,'A')))
        return row,selected
    # Every returned selected value was cross-checked against the actual 17-role receipt.
    # Original contour keeps all its fields and roster equality; only these verified SHA keys are canonicalized.
    def shape(result):return checked_contour(result,read(e.ref_path(root,'A'))['roles'],raw_contour)
    with patch.object(w.study.c,'normal',run),patch.object(w.study,'contour',shape):
        w.study.inside(action,name,arm,folder,mtime)
    write(folder/'output-producers.json',before)


if __name__=='__main__':
    m.v.system();reg=read(ROOT/'registration.json');need(all(e.sha(ROOT/k)==v for k,v in reg['own'].items()) and sys.argv[1]=='inside','different worker source')
    main(sys.argv[2:])
