"""Read prior effects through the native programs that signed each original result."""
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import evidence as e

def evaluate():
    G=e.G;pub=e.module(G/'package-test/family.py','original_seven')
    q=pub.q;old=q.bridge;O=G/'ordinary-modes'
    ordinary={O/('physical-'+mode)/'retire/outer-return.json' for mode in ('check','build')}
    def proper(path,h):
        if path not in ordinary:return old(path,h)
        raw=json.loads(subprocess.check_output(['/usr/bin/python3','-ISB',str(O/'after-direct-warm/launch.py'),'closed',str(path),h],timeout=900))
        host,real=q.v.local_receipt(path.parent,h);e.need(real==raw,'changed original normal-mode return');return host,raw
    with patch.object(q,'bridge',proper):stats,closures=pub.original_scores()
    other=G/'package-test-v3';output=other/'physical/outer-return.json';h=e.sha(output)
    actual=json.loads(subprocess.check_output(['/usr/bin/python3','-ISB',str(other/'run.py'),'closed',str(output),h],timeout=900))
    e.need(actual==e.read(output),'different original marginal result')
    result=e.read(other/'physical/analysis.json')
    key='CZD/package-test-v3';closures[key]=h
    if result['score'] is not None:stats[key]=result['score']
    e.need(not set(e.plan()['family']['permanently_excluded']) & set(stats),'excluded statistic imported')
    return {'original_effects':stats,'actual_outers':closures}

if __name__=='__main__':print(json.dumps(evaluate(),sort_keys=True))
