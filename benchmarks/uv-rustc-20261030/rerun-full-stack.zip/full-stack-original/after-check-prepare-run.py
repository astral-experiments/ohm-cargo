"""Use the verified failed-check material closure, with zero credit, in the actual stock return chain."""
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
S=HERE.parent
spec=importlib.util.spec_from_file_location('registered_twelfth_contrast',S/'run.py')
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
r=original
REG=HERE/'registration.json'


def authority():
    record=r.read(REG)
    r.need(r.verify()==record['unchanged_science_worker'] and
           all(r.sha(HERE/k)==v for k,v in record['source_pins'].items()),
           'different compiler study or authenticated resource reader')
    return record


def diagnostic(path,h):
    plan=authority()
    r.need(Path(path)==r.HANDOFF and r.sha(path)==h,'requires the actual final private diagnostic')
    out=r.pure((HERE/plan['diagnostic_accessor']).resolve(),'closed',path,h)
    host,raw=r.host_tools.local_receipt(path.parent,h)
    r.need(out==raw,'different native outer and predecessor evidence')
    return host,raw


def alternate(operation,path=None,h=None):
    reg=authority();d=r.sha(REG);original_write=r.q.write
    def record(p,row):
        if p==r.OUT/'intake.json':row={**row,'host_after_check_registration_sha256':d}
        return original_write(p,row)
    with patch.object(r,'bridge',diagnostic):
        if operation=='start':
            with patch.object(r.q,'write',record):return r.start(path,h)
        if operation=='closed':
            host,raw=r.closed(path,h)
            r.need(r.read(r.OUT/'intake.json')['host_after_check_registration_sha256']==d,'wrong resource admission')
            return host,raw
        r.need(operation=='family','unknown phase')
        path=r.OUT/'outer-return.json';alternate('closed',path,r.sha(path))
        scores=r.pure(HERE/'earlier_effects.py');result=r.read(r.OUT/'analysis.json');values=dict(scores['original_effects'])
        r.need('CZD/check' not in values,'excluded failed prepare credited')
        values['P-to-CZD/package-test']=result['score']
        return {'actual_package_result':result,'twelve':r.sc.holm12(values),'earlier_outers':scores['actual_outers'],'own_outer_sha256':r.sha(path),'pooled':False}


if __name__=='__main__':
    args=sys.argv[1:]
    if args==['verify']:authority();print(r.sha(REG))
    elif args==['family']:print(json.dumps(alternate('family'),sort_keys=True))
    elif len(args)==3 and args[0] in ('closed','start'):
        value=alternate(args[0],Path(args[1]),args[2])
        if args[0]=='start':raise SystemExit(value)
        print(json.dumps(value[1],sort_keys=True))
    elif len(args)==4 and args[0]=='close':
        r.host_tools.code(r.host_tools.UP.parent/'physical.py','released_physical_outer').close(r.OUT,*args[1:])
    else:raise SystemExit('verify | start ABS_PREVIOUS SHA | close SESSION CHUNK CODE | closed ABS_OWN SHA | family')
