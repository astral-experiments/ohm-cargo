"""Freeze role-specific ELF classes from P and verify all later observations, including warm repeats."""
import hashlib
import importlib.util
import json
from pathlib import Path
import time

DIR = Path(__file__).resolve().parent
G = DIR.parent
INPUT = DIR / 'protocol.json'
SCIENCE = 'c545177f4e5e2fb4284ce034187fa5d8b4619154a3d659f57fbdf2a589112cd1'
RAM = Path('/dev/shm/ohm-20-guard-package-full-stack-20261030')
OUT = DIR / 'physical'


def module(file, name):
    spec = importlib.util.spec_from_file_location(name, file)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


engine = module(G / 'package-test-v3/replay.py', 'full_package_original_admission')
f = engine.forms
read, write, need, sha = f.read, f.write, f.need, f.sha


def plan():
    need(sha(INPUT) == SCIENCE, 'full stack protocol changed')
    return read(INPUT)


def phase_paths(root, phase):
    return (root/'warm-P/ordinary-repeat-A',root/'warm-P/source-A.json') if phase=='A' else (root/'admission-P/B',root/'admission-P/edit.json')


def ref_path(root, phase):
    return root/'warm-P/ordinary-repeat-A/p-only-classes.json' if phase=='A' else root/'baseline-B-forms.json'


def bind(root, *, emit=False, cas=None):
    root = Path(root).resolve()
    f.bind(root, RAM/'products' if root==OUT else cas, emit, native_tmp=RAM if root==OUT else None)


def reference(root, phase, *, create=False, deep=False, live=None):
    """The A writer can read the fresh P files in-place before rustc touches that target again."""
    need(phase in ('A','B') and (live is None or create and phase=='A'), 'unexpected P reference source')
    stage, source = phase_paths(root,phase)
    meta = stage/'all-products.json'
    retained = stage/'pre-trace-retained.json' if phase=='A' else stage.parent/'retained-products.json'
    inventory, material = read(meta),read(retained)
    f.check(inventory,plan())
    need(set(material)==set(inventory), 'missing original raw outputs')
    props = {'phase':phase,'independent_arm':'P','command_sha256':sha(stage/'command.json'),'source_sha256':sha(source),
             'raw_inventory_sha256':sha(meta),'retained_sha256':sha(retained)}
    path = ref_path(root,phase)
    record = dict(props,roles={}) if create else read(path)
    need(all(record[k]==v for k,v in props.items()), 'wrong source baseline')
    for role,row in inventory.items():
        h,n = row['sha256'],row['bytes']
        need(material[role]['raw_sha256']==h and material[role]['raw_bytes']==n, 'unbound raw program')
        if create or deep:
            if live is None:
                with f.unpack(h,n) as raw: choice=f.choices(raw,h)
            else:
                raw=live/row['path']
                need(raw.resolve().is_relative_to(live.resolve()) and raw.stat().st_size==n and sha(raw)==h, 'different current P executable')
                choice=f.choices(raw,h)
            item={'record':row,'class':choice}
            if create:record['roles'][role]=item
            else:need(record['roles'][role]==item,'P-derived complete file failed replay')
        item=record['roles'][role];cl=item['class']
        need(item['record']==row and cl['observed']==h and h in cl['allowed'], 'wrong P role or derived hash')
        if cl['policy']=='raw-identical-only':need(cl['allowed']==[h], 'unproved substitute')
        else:need(cl['policy']=='released-Wild-0-or-8' and sorted(d['sha256'] for d in cl['derived']['forms'].values())==cl['allowed'] and len(set(cl['allowed']))==2,'improper two-image class')
    need(set(record['roles'])==set(inventory),'wrong reference roles')
    blocked=[root/'warm-P/verify-repeat-A/command.json',root/'warm-CZD/apply-compiler-A/command.json'] if phase=='A' else [root/'admission-CZD/B/command.json']
    if create:
        need(not any(p.exists() for p in blocked), 'reference arrived after a later command')
        record['monotonic_sealed_ns']=time.monotonic_ns()
        write(path,record)
    cutoff=record['monotonic_sealed_ns']
    need(read(stage/'command.json')['end_ns']<cutoff and all(cutoff<read(p)['start_ns'] for p in blocked if p.exists()),'reference order violated')
    return record


def membership(items,reference_data):
    f.check(items,plan());need(set(items)==set(reference_data['roles']),'lost product role')
    for role,row in items.items():
        chosen=reference_data['roles'][role]
        need(f.metadata(row)==f.metadata(chosen['record']) and row['sha256'] in chosen['class']['allowed'],'unrecognized complete P output: '+role)


def equal(root,phase,left,right):
    reference_data=read(ref_path(root,phase))
    membership(left,reference_data);membership(right,reference_data)
    for role,row in reference_data['roles'].items():
        observed=row['class']['observed']
        if left[role]['sha256']==right[role]['sha256']==observed:continue
        a,b=row['class']['allowed']
        key=hashlib.sha256((phase+':'+role+':'+a+':'+b).encode()).hexdigest()
        dest=root/('form-proofs-'+phase)/(key+'.json')
        if key not in f.CHECKED:
            size=row['record']['bytes']
            with f.unpack(a,size) as x,f.unpack(b,size) as y:proof=f.exact(x,y,a,b)
            saved=json.loads(json.dumps({'role':role,'path':row['record']['path'],'bytes':size,'allowed_from_P':[a,b],'full_file':proof}))
            if not dest.exists() and f.EMIT:dest.parent.mkdir(exist_ok=True);write(dest,saved)
            need(read(dest)==saved,'two-way raw proof differs');f.CHECKED[key]=sha(dest)
        need(sha(dest)==f.CHECKED[key],'reciprocal proof changed')
    return True
