"""Replay every raw ordinary Cargo interval, restoration, program inventory and randomized pair."""
from pathlib import Path
import sys
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import evidence as e
need,read,sha=e.need,e.read,e.sha
SCIENCE=e.SCIENCE
ARMS=('P','CZD')


def bound_subject(folder,plan,arm):
    subject=read(folder/'subject.json')
    need(subject==read(folder.parent/'subjects.json')['subjects'][arm] and
         all(subject[k]==v for k,v in plan['subjects']['manifests'][arm].items()),'different returned compiler subject')

def row(folder,plan,arm,kind,admission=None):
    root=folder.parent;bound_subject(folder,plan,arm)
    with patch.object(e.engine.forms,'equal',lambda left,right,doc:e.equal(root,'B',left,right)):
        data=e.engine.row(folder,plan,arm,kind,admission)
    restore=read(folder/'incoming.json');checkpoint=read(root/('warm-'+arm)/'checkpoint.json')
    need(restore['manifest_sha256']==checkpoint['state']['manifest_sha256'] and restore['archive_sha256']==checkpoint['sha256'] and restore['identity']!=checkpoint['original'],'wrong independent A checkpoint')
    return data


def pair(root,rec,order,kind,plan):
    need(kind=='timed' and rec['order']==order and set(order)==set(ARMS) and len(rec['dirs'])==len(set(rec['dirs']))==2,'wrong two-arm pair')
    got=[row(root/d,plan,a,kind,root/('admission-'+a)) for d,a in zip(rec['dirs'],order)]
    need(e.equal(root,'B',got[0][1],got[1][1]) and got[0][2]['after']==got[1][2]['after'] and got[0][0]['end_ns']<got[1][0]['start_ns'],'paired products, input or temporal separation disagree')
    elapsed={a:data[0]['elapsed_ns'] for a,data in zip(order,got)}
    return order[0],elapsed['P'],elapsed['CZD']


def score_times(values):
    need(all(x in ARMS for x,_,_ in values),'unknown bench source')
    z=e.engine.score_engine().score_times([('C' if order=='P' else 'CZD',p,t) for order,p,t in values])
    z['P_seconds_median']=z.pop('C_seconds_median');z['CZD_seconds_median']=z.pop('candidate_seconds_median')
    by=z['per_order_ratio_medians'];z['per_order_ratio_medians']={'P-first':by['C-first'],'CZD-first':by['candidate-first']}
    return z


def warm_rows(root,arm,plan):
    folder=root/('warm-'+arm);bound_subject(folder,plan,arm);items=[]
    for stage,ret in [('ordinary-repeat-A','ordinary-repeat-A/pre-trace-retained.json'),('verify-repeat-A','retained-products.json')]:
        p=folder/stage;public=e.engine.product(p,plan);held=read(folder/ret)
        need(set(public)==set(held) and all(v['sha256']==held[k]['raw_sha256'] and v['bytes']==held[k]['raw_bytes'] for k,v in public.items()),'missing actual ordinary or traced A bytes')
        clock=read(p/'command.json');need(clock['exit']==0 and clock['argv'][1:]==plan['ordinary_argv'][1:] and clock['source']['oid']==plan['uv']['A'] and not clock['observer_faults'] and clock['driver']==plan['subjects']['manifests'][arm]['driver_sha256'] and clock['traced']==(stage=='verify-repeat-A') and clock['elapsed_ns']==clock['end_ns']-clock['start_ns']>0 and clock['log_sha256']==sha(p/'cargo.log'),'unproven true warm invocation')
        items.append((public,clock))
    need(items[0][1]['packages']==items[1][1]['packages'] and items[0][1]['changed_stamps']==items[1][1]['changed_stamps'] and items[0][1]['end_ns']<items[1][1]['start_ns'],'same-arm unedited work did not settle')
    e.equal(root,'A',items[0][0],items[1][0]);return items[-1][0]


def replay(root,deep_refs=True):
    root=Path(root).resolve();plan=e.plan()
    if e.f.ROOT!=root:e.bind(root)
    e.reference(root,'A',deep=deep_refs);e.reference(root,'B',deep=deep_refs)
    arows={};brows={}
    for arm in ARMS:
        warm=root/('warm-'+arm);check=read(warm/'checkpoint.json')
        need(check['original']==read(warm/'incoming.json')['identity']==read(warm/'retired.json')['id'] and check['archive_compared_with_live'],'unverified original A')
        arows[arm]=warm_rows(root,arm,plan);b=root/('admission-'+arm);_,brows[arm],_=row(b,plan,arm,'admission')
        e.engine.pr.phase_change(arows[arm],brows[arm],warm/'verify-repeat-A',b/'B',plan)
    e.equal(root,'A',*arows.values());e.equal(root,'B',*brows.values())
    series=read(root/'series.json');need(set(series)=={'pairs','exclusions'} and len(series['pairs'])==12,'requires all twelve new pairs without a pilot')
    positions=plan['pairs'];attempts=series['exclusions'];need(all(x['sequence'] in range(1,13) for x in attempts),'foreign outside an assigned pair')
    vals=[];last=0
    for seq,(r,order) in enumerate(zip(series['pairs'],positions),1):
        trial=r['attempt'];names=lambda i:[f'pair-{seq:02d}-try-{i}-{n}-{arm}' for n,arm in enumerate(order)]
        need(r['sequence']==seq and 0<=trial<=2 and r['dirs']==names(trial),'incomplete or substituted randomized pair')
        earlier=[x for x in attempts if x['sequence']==seq]
        need([x['attempt'] for x in earlier]==list(range(trial)),'unaccounted measured attempt')
        for x in earlier:
            need(x['at'] in names(x['attempt']) and x['order']==order,'false foreign exclusion')
            z=root/x['at']/'B';p=z/'foreign-before.json'
            if p.exists():need(bool(read(p)['foreign']),'empty foreign observation')
            else:
                faults=read(z/'command.json')['observer_faults'];need(bool(faults) and all(set(f)=={'foreign','free'} and f['foreign'] and min(f['free'].values())>122<<30 for f in faults),'non-foreign retry')
        vals.append(pair(root,r,order,'timed',plan));need(last<read(root/r['dirs'][0]/'B/command.json')['start_ns'],'out-of-sequence pair')
        last=read(root/r['dirs'][1]/'B/command.json')['end_ns']
    return {'pilot':None,'continues':True,'counted_pairs':12,'raw_P_CZD_ns':[list(x) for x in vals],'score':score_times(vals)}


def holm12(scores):
    settings=e.plan()['family'];labels=settings['ordered_labels'];excluded=settings['permanently_excluded']
    need(set(scores)<=set(labels)-set(excluded),'credit for a failed or undeclared experiment')
    p={k:scores[k]['p_against_2']['two_sided_p'] if k in scores else 1.0 for k in labels}
    result={};previous=0.
    for i,k in enumerate(sorted(labels,key=lambda n:(p[n],n))):
        need(0<=p[k]<=1,'invalid probability');previous=max(previous,min(1.,(12-i)*p[k]))
        result[k]={'raw_p':p[k],'adjusted_p':previous,'complete':k in scores,'confirmed':bool(k in scores and scores[k]['individual_gate'] and previous<.05),'excluded':k in excluded}
    return result
