"""One independently restored P/CZD full-package study. All actual launches require the coordinator."""
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import evidence as e
sc=e.module(HERE/'replay.py','full_stack_numerical')
q=e.module(e.G/'package-test/run.py','actual_package_command')
host_tools=q.v;m=q.m;bank=q.bank;arc=q.arc;need,read,write,sha=e.need,e.read,e.write,e.sha
REG=HERE/'registration.json';OUT=e.OUT;RAM=e.RAM;ACTIVE=RAM/'active';CAS=RAM/'products';GIB=1<<30
DIAG=e.G.parent/'private-normalize-fanout'
HANDOFF=DIAG/'physical/outer-return.json'
ARMS=('P','CZD')


def verify():
    host_tools.system();m.system();q.study.verify()
    plan=e.plan();reg=read(REG)
    need(all(sha(HERE/k)==v for k,v in reg['own'].items()) and all(sha(HERE/k)==v for k,v in reg['external'].items()) and
         all(sha(e.G/k)==v for k,v in plan['inputs'].items()),'changed resource or scientific source')
    orders=[list(ARMS) for _ in range(6)]+[list(reversed(ARMS)) for _ in range(6)]
    random.Random(plan['order_seed']).shuffle(orders)
    need(orders==plan['pairs'] and len(plan['family']['ordered_labels'])==12 and len(plan['family']['permanently_excluded'])==3,'changed independent schedule/family')
    return sha(REG)


def pure(entry,*args):
    val=subprocess.run(['/usr/bin/python3','-ISB',str(entry),*map(str,args)],capture_output=True,check=True,timeout=900)
    return json.loads(val.stdout)


def bridge(path,h):
    path=Path(path)
    need(path==HANDOFF and sha(path)==h,'expected the authentic stock diagnostic after ordinary and official stages')
    result=pure(DIAG/'return-after-ordinary.py','closed',path,h)
    hl,raw=host_tools.local_receipt(path.parent,h)
    need(raw==result,'diagnostic scientific reader and native return differ')
    return hl,raw


def earlier():
    excluded=e.G/'package-test-v3-direct-leaf'
    h=sha(excluded/'physical/outer-return.json')
    need(h==e.plan()['inputs']['package-test-v3-direct-leaf/physical/outer-return.json'] and read(excluded/'physical/outer-return.json')['outer']=={'session':82625,'chunk':'95d3a3','exit':1} and not (excluded/'physical/series.json').exists(),'the prior P/ZD attempt is permanently unscored')
    J=excluded/'failed-warm';jr=J/'physical/outer-return.json'
    need(pure(J/'return_resources.py','closed',jr,sha(jr))==read(jr),'previous material terms are open')
    return {'preceding_direct_failed_outer_sha256':h,'resolved_resource_only_sha256':sha(jr),'excluded_scientific_comparisons':e.plan()['family']['permanently_excluded'],'previous_endpoint_credited_p':1}


def natives(subjects, *, run=False):
    f=OUT/'native';ng=q.ready.native_gate;inputs={'parent':subjects['P'],'candidate':subjects['CZD']}
    if run:
        f.mkdir();write(f/'subjects.json',{'subjects':inputs,'registered':sha(REG)})
    need(read(f/'subjects.json')=={'subjects':inputs,'registered':sha(REG)},'different native control pair')
    with patch.object(ng,'OUT',f),patch.object(ng,'__file__',str(HERE/'run.py')),patch.object(host_tools,'QA',f),patch.object(host_tools,'BUILD',Path('/tmp')):
        res=ng.direct(inputs,'CZD') if run else ng.qa.validate(f,inputs)
    for role in ('parent','candidate'):
        path=f/role/'cargo-native/evidence/rows.json';rows=read(path)
        need([x['exit']==0 for x in rows]==[True,True,True,False,False,False,True] and [x['printed'] for x in rows if x['exit']==0]==['273\n','285\n','541\n','529\n'],'changed, missing or malformed assembly control failed')
        res[role]['normal_cargo_sha256']=sha(path)
    doc={'subjects_sha256':sha(f/'subjects.json'),'results':res,'code':0,'timed':False}
    if run:write(f/'verified.json',doc)
    need(read(f/'verified.json')==doc,'changed actual native-safety proof');return sha(f/'verified.json')


def native_inside(role):
    f=OUT/'native';ng=q.ready.native_gate
    need(role in ('parent','candidate') and os.path.samefile('/tmp/qa274',f/role) and os.statvfs('/').f_flag&os.ST_RDONLY,'not actual native safety namespace')
    with patch.object(ng,'OUT',f),patch.object(host_tools,'QA',f),patch.object(host_tools,'BUILD',Path('/tmp')):
        ng.qa.run_arm(role);ng.cargo_fixture(role)


def import_ordinary_copy(stage):
    """Move verified raw zstd frames off the disposable target before freezing its unaffected checkpoint."""
    data=read(stage/'pre-trace-retained.json');items=read(stage/'all-products.json');need(set(data)==set(items),'missing ordinary A bytes')
    scratch=ACTIVE/'tmp/pre-trace-elf-cas-full-stack'
    need(scratch.resolve()==scratch and not scratch.is_symlink() and scratch.is_dir() and scratch.stat().st_uid==os.getuid(),'unowned source capture')
    by={x['raw_sha256']:x for x in data.values()}
    need({p.name for p in scratch.iterdir()}=={h+'.zst' for h in by},'unexpected original outputs')
    for h,info in by.items():
        p=scratch/(h+'.zst');dst=CAS/p.name
        need(p.resolve()==p and p.is_file() and p.stat().st_uid==os.getuid() and p.stat().st_size==info['compressed_bytes'] and sha(p)==info['compressed_sha256'] and arc.unpacked_sha(p)==h,'unbound ordinary A archive')
        if not dst.exists():os.link(p,dst)
        need(dst.resolve()==dst and dst.is_file() and sha(dst)==info['compressed_sha256'] and arc.unpacked_sha(dst)==h,'additional A observation not independently retained')
    for p in scratch.iterdir():p.unlink()
    scratch.rmdir()


def warm(arm,subjects):
    folder=OUT/('warm-'+arm);folder.mkdir();q.identify();need(not ACTIVE.exists(),'live prior target')
    m.bounds(max(m.tree_size(m.DONOR,True)['unique_allocated_bytes']+(768<<20),13*GIB+(256<<20)))
    copied=bank.archive(m.DONOR,ACTIVE);incoming={'donor':str(m.DONOR),'source_identity':bank.identity(m.DONOR),'identity':bank.identity(ACTIVE),'state':copied}
    write(folder/'incoming.json',incoming)
    q.job(folder,subjects,arm,'warm',read(m.cold/'cold-A/census.json')['producers'])
    import_ordinary_copy(folder/'ordinary-repeat-A')
    q.keep(folder/'verify-repeat-A',folder)
    sc.warm_rows(OUT,arm,e.plan())
    need(not m.r.native.foreign(),'foreign compiler during unmeasured preparation')
    q.marker(folder,arm)
    size=m.tree_size(ACTIVE,True)['unique_allocated_bytes'];need(size<=13*GIB,'complete target exceeds original maximum')
    rec=arc.pack(ACTIVE,RAM/(arm+'-never-B.tar.zst'),bank.snapshot,bank.identity,m.bounds)
    need(rec['original']==incoming['identity'] and rec['archive_compared_with_live'],'wrong archive')
    rec['actual_slot_allocated']=size;write(folder/'checkpoint.json',rec)
    q.retire_active(folder,incoming['identity'],'full verified A checkpoint with all programs retained');return rec


def archives_and_programs(rows,deep):
    entries={};origins={}
    for arm in ARMS:
        warm=OUT/('warm-'+arm)
        for stage,rec in [('ordinary-repeat-A',warm/'ordinary-repeat-A/pre-trace-retained.json'),('verify-repeat-A',warm/'retained-products.json')]:
            origins[('A',arm,stage)]=(warm/stage,rec)
        path=OUT/('admission-'+arm);origins[('B',arm,'admission')]=(path/'B',path/'retained-products.json')
    for pair in rows:
        for arm,f in zip(pair['order'],pair['dirs']):
            path=OUT/f;origins[('B',arm,f)]=(path/'B',path/'retained-products.json')
    manifest={}
    for name,(p,held) in origins.items():
        raw=read(p/'all-products.json');prior=read(held);e.f.check(raw,e.plan())
        need(set(raw)==set(prior),'incomplete actual retained products')
        for role,x in prior.items():
            h=x['raw_sha256'];need(h==raw[role]['sha256'] and x['raw_bytes']==raw[role]['bytes'] and (h not in entries or entries[h]==x),'conflicting observations')
            entries[h]=x
        manifest['/'.join(name)]={'products_sha256':sha(p/'all-products.json'),'custody_sha256':sha(held)}
    if deep:
        for h,x in entries.items():
            p=CAS/(h+'.zst');need(p.resolve()==p and p.is_file() and p.stat().st_size==x['compressed_bytes'] and sha(p)==x['compressed_sha256'] and arc.unpacked_sha(p)==h,'lost retained unmodified raw program')
    return {'root':str(CAS),'files':entries,'inventories':manifest,'baseline_A':sha(e.ref_path(OUT,'A')),'baseline_B':sha(e.ref_path(OUT,'B')),
            'proofs':{phase:{p.name:sha(p) for p in sorted((OUT/('form-proofs-'+phase)).glob('*.json'))} for phase in ('A','B')}}


def perform(subjects):
    for arm in ARMS:
        need(all(subjects[arm][k]==v for k,v in e.plan()['subjects']['manifests'][arm].items()),'different complete matched subject')
    native=natives(subjects,run=True);e.bind(OUT,emit=True)
    for p in ('form-proofs-A','form-proofs-B'):(OUT/p).mkdir()
    first=warm('P',subjects);e.reference(OUT,'A',deep=True)
    second=warm('CZD',subjects);archives={'P':first,'CZD':second}
    aw={arm:read(OUT/('warm-'+arm)/'verify-repeat-A/all-products.json') for arm in ARMS}
    e.equal(OUT,'A',*aw.values());e.reference(OUT,'A')
    size=max(x['actual_slot_allocated'] for x in archives.values());transient=max(2*GIB,2*sum(r['bytes'] for r in aw['P'].values())+(512<<20))
    write(OUT/'complete-price.json',{'transient_link_allowance':transient,'actual':{a:{'full':v['actual_slot_allocated'],'compressed':v['allocated']} for a,v in archives.items()},'already_charged_products':m.tree_size(CAS,True),'safe_current':m.bounds(size+transient),'root_scratch_floor':m.FLOOR,'ram_floor':20*GIB,'shm_floor':6*GIB,'all_tmpfs_max':26*GIB})
    stamp=time.time_ns();p=q.one('P','admission',OUT/'admission-P',subjects,first,stamp);e.reference(OUT,'B',create=True)
    c=q.one('CZD','admission',OUT/'admission-CZD',subjects,second,stamp)
    e.reference(OUT,'B',deep=True);e.equal(OUT,'B',p,c)
    need(read(OUT/'admission-P/edit.json')['after']==read(OUT/'admission-CZD/edit.json')['after'],'different first source edit')
    excluded=[];rows=[q.paired(n,o,'timed',subjects,archives,excluded) for n,o in enumerate(e.plan()['pairs'],1)]
    write(OUT/'series.json',{'pairs':rows,'exclusions':excluded})
    res=sc.replay(OUT);write(OUT/'analysis.json',res)
    cas=archives_and_programs(rows,True);write(OUT/'cas-index.json',cas)
    q.identify();m.system_proof();need(not ACTIVE.exists() and not m.r.native.foreign(),'unowned or busy closed state')
    for arm,x in archives.items():
        path=Path(x['path']);need(path==RAM/(arm+'-never-B.tar.zst') and path.resolve()==path and bank.identity(path)==x['archive_identity'] and sha(path)==x['sha256'],'wrong private A archive')
    for x in archives.values():Path(x['path']).unlink()
    write(OUT/'retired.json',{'archives':{a:{'identity':v['archive_identity'],'sha256':v['sha256'],'path':v['path']} for a,v in archives.items()},'absent':all(not Path(v['path']).exists() for v in archives.values()) and not ACTIVE.exists(),'native_controls_sha256':native,'original_donor_identity':bank.identity(m.DONOR),'all_programs_sha256':sha(OUT/'cas-index.json')})
    return res


def start(path,h):
    reg=verify();need(os.environ.get('FULL_STACK_PACKAGE_RELEASE')==reg,'requires new distinct authority')
    with patch.dict(os.environ,{'PACKAGE_TEST_RELEASE':reg}),patch.multiple(q,K=HERE,OUT=OUT,RAM=RAM,CAS=CAS,ACTIVE=ACTIVE,REG=REG,PLAN=e.plan(),score=sc,verify=verify,bridge=bridge,primary=earlier,perform=perform):
        return q.start(path,h)


def closed(path,h):
    verify();need(path==OUT/'outer-return.json','wrong full-stack result');host,raw=host_tools.local_receipt(OUT,h)
    i=read(OUT/'intake.json');w=read(OUT/'worker-return.json');s=read(OUT/'successful.json');r=read(OUT/'retired.json')
    need(w['code']==w['worker_exit']==0 and w['owned_children_at_return']==[] and w['capacity']['guard_fault'] is None and i['locks']==w['locks']==raw['locks'] and i['boot']==raw['boot'] and i['start_ns']<w['end_ns'] and i['registration']==s['registration']==sha(REG),'unadmitted physical result')
    need(bridge(Path(i['previous']),i['previous_sha256'])[1]['outer']==i['outer'] and earlier()==i['primary'],'different prerequisite')
    need(w['success']==sha(OUT/'successful.json') and r['absent'] and set(r['archives'])==set(ARMS) and s['all_tests']==15 and s['all_ELF']==17 and s['scored_rows']==24 and s['pilot_only'] is False and s['physical_custody_sha256']==sha(OUT/'retired.json') and s['cas_sha256']==r['all_programs_sha256']==sha(OUT/'cas-index.json'),'incomplete coverage or private retirement')
    z=read(OUT/'subjects.json');need(z==q.ready.select(False,'CZD') and s['subjects_sha256']==sha(OUT/'subjects.json') and natives(z['subjects'])==r['native_controls_sha256'],'unverified matched SDKs')
    e.bind(OUT);res=sc.replay(OUT);need(s['scorer_sha256']==sha(OUT/'analysis.json') and res==read(OUT/'analysis.json') and read(OUT/'cas-index.json')==archives_and_programs(read(OUT/'series.json')['pairs'],False),'wrong score or custody')
    return host,raw


def family():
    p=OUT/'outer-return.json';closed(p,sha(p))
    released=pure(HERE/'previous.py')
    scores=dict(released['original_effects']);raw=read(OUT/'analysis.json')
    scores['P-to-CZD/package-test']=raw['score']
    return {'actual_package_result':raw,'twelve':sc.holm12(scores),'earlier_outers':released['actual_outers'],'own_outer_sha256':sha(p),'pooled':False}


if __name__=='__main__':
    args=sys.argv[1:]
    if args==['verify']:print(verify())
    elif args==['family']:print(json.dumps(family(),sort_keys=True))
    elif len(args)==3 and args[0]=='start':raise SystemExit(start(Path(args[1]),args[2]))
    elif len(args)==3 and args[0]=='closed':print(json.dumps(closed(Path(args[1]),args[2])[1],sort_keys=True))
    elif len(args)==3 and args[:2]==['inside','CZD']:native_inside(args[2])
    elif len(args)==4 and args[0]=='close':host_tools.code(host_tools.UP.parent/'physical.py','physical_returns').close(OUT,*args[1:])
    else:raise SystemExit('verify | start ABS_PREVIOUS SHA | close SESSION CHUNK CODE | closed ABS_OUTER SHA | family')
