"""Compare complete x86-64 programs against the two observed Wild .rodata encodings."""
import ctypes
import ctypes.util
from functools import lru_cache
import hashlib
import mmap
from pathlib import Path
import stat
import struct


def require(ok, message):
    if not ok:
        raise ValueError(message)


@lru_cache(maxsize=1)
def blake3():
    names = [ctypes.util.find_library("LLVM-" + str(v)) for v in (18, 19, 20, 21, 22)]
    names += ["/usr/lib/x86_64-linux-gnu/libLLVM.so.18.1", ctypes.util.find_library("LLVM")]
    for name in filter(None, names):
        try:
            lib = ctypes.CDLL(name)
            init, update, finish = (getattr(lib, "llvm_blake3_hasher_" + f)
                                    for f in ("init", "update", "finalize"))
        except (OSError, AttributeError):
            continue
        ptr, size = ctypes.c_void_p, ctypes.c_size_t
        init.argtypes, update.argtypes, finish.argtypes = [ptr], [ptr, ptr, size], [ptr, ptr, size]
        init.restype = update.restype = finish.restype = None

        def compute(buf, length):
            state = ctypes.create_string_buffer(4096)
            result = ctypes.create_string_buffer(32)
            init(state)
            update(state, buf, length)
            finish(state, result, 32)
            return result.raw

        require(compute(b"", 0).hex() == "af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262"
                and compute(b"abc", 3).hex() == "6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85",
                "LLVM BLAKE3 does not pass the reference vectors")
        return compute
    raise ValueError("install a system LLVM library exporting llvm_blake3_hasher_init to compare differing ELFs")


def fields(data):
    n = len(data)
    require(n >= 64 and data[:7] == b"\x7fELF\x02\x01\x01", "requires ELF64 little endian")
    typ, machine, version, entrypoint, ph, sh, cpu_flags, ehsize, phsize, phnum, shsize, shnum, strings = struct.unpack_from("<HHIQQQIHHHHHH", data, 16)
    require(typ == 3 and machine == 62 and version == 1 and entrypoint > 0 and cpu_flags == 0 and ehsize == 64 and phsize == 56
            and 0 < phnum < 65535 and shsize == 64 and 1 <= strings < shnum < 0xff00
            and 64 <= ph <= n - phnum * phsize and 64 <= sh <= n - shnum * shsize,
            "unexpected x86-64 executable tables")
    sections = [struct.unpack_from("<IIQQQQIIQQ", data, sh + i * shsize) for i in range(shnum)]
    s = sections[strings]
    require(s[1] == 3 and s[4] <= n - s[5], "bad section name table")
    table = data[s[4]:s[4]+s[5]]
    by_name = {}
    notes = []
    for i, section in enumerate(sections):
        start = section[0]
        end = table.find(b"\0", start)
        require(0 <= start < len(table) and end >= start and
                (section[1] == 8 or section[4] <= n - section[5]), "malformed section")
        name = table[start:end]
        if section[1] == 7:
            pos, stop = section[4], section[4]+section[5]
            require(section[5] <= 1 << 20, "oversized ELF note section")
            while pos < stop:
                require(pos + 12 <= stop, "short ELF note")
                namesz, descsz, typ = struct.unpack_from("<III", data, pos)
                start = pos + 12
                desc = start + ((namesz + 3) & ~3)
                end = desc + ((descsz + 3) & ~3)
                require(namesz > 0 and end <= stop and start+namesz <= stop, "invalid ELF note")
                if typ == 3 and data[start:start+namesz] == b"GNU\0":
                    notes.append((pos, desc, descsz))
                pos = end
        if name in (b".rodata", b".note.gnu.build-id"):
            require(name not in by_name, "ambiguous section name")
            by_name[name] = (i, section)
    require(len(by_name) == 2, "expected the Wild rodata and GNU build-id sections")
    index, ro = by_name[b".rodata"]
    _, note = by_name[b".note.gnu.build-id"]
    offset = note[4]
    require(ro[1] == 1 and ro[2] == 0x32 and ro[5] > 0 and ro[6:8] == (0, 0) and ro[8] > 0 and not ro[8] & (ro[8] - 1)
            and ro[4] % ro[8] == ro[3] % ro[8] == 0 and ro[9] in (0, 8)
            and note[1] == 7 and note[2] == 2 and note[5] == 48 and note[6:10] == (0, 0, 4, 0) and notes == [(offset, offset+16, 32)]
            and data[offset:offset+16] == struct.pack("<III4s", 4, 32, 3, b"GNU\0"),
            "unregistered section or GNU BLAKE3 note form")
    entry = sh + index * shsize + 56
    loads = [struct.unpack_from("<IIQQQQQQ", data, ph+i*phsize) for i in range(phnum)]
    require(all(p[2] <= n-p[5] for p in loads), "program segment exceeds the file")
    loads = [p for p in loads if p[0] == 1]
    require(loads and all(p[2] <= n - p[5] and (entry+8 <= p[2] or p[2]+p[5] <= entry)
                          for p in loads), "section width lies inside loadable bytes")
    def mapped(section):
        matches = [p for p in loads if p[2] <= section[4] and section[4]+section[5] <= p[2]+p[5]
                   and p[3] + section[4] - p[2] == section[3]]
        return len(matches) == 1 and matches[0][1] == 4
    require(mapped(ro) and mapped(note) and (offset+48 <= entry or entry+8 <= offset), "unexpected load layout")
    return entry, offset


def signature(path, digest):
    require(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), "expected retained ordinary file")
    with path.open("rb") as file, mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_COPY) as data:
        require(hashlib.sha256(data).hexdigest() == digest, "retained raw image does not match its receipt")
        entry, note = fields(data)
        width = struct.unpack_from("<Q", data, entry)[0]
        header = data[note:note+16]
        original_id = data[note+16:note+48]
        addr = ctypes.addressof(ctypes.c_char.from_buffer(data))
        result = []
        for value in (0, 8):
            struct.pack_into("<Q", data, entry, value)
            data[note:note+48] = bytes(48)
            ident = blake3()(addr, len(data))
            if value == width:
                require(original_id == ident, "original Wild GNU ID is not derived from the complete image")
            data[note:note+48] = header + ident
            result.append(hashlib.sha256(data).hexdigest())
        require(result[width//8] == digest and result[0] != result[1], "bad exact binary reconstruction")
        return tuple(result)


class Programs:
    def __init__(self, objects):
        self.objects = Path(objects)
        self.verified = {}

    def form(self, digest):
        require(len(digest) == 64 and all(c in "0123456789abcdef" for c in digest), "invalid raw SHA-256")
        if digest not in self.verified:
            self.verified[digest] = signature(self.objects / digest, digest)
        return self.verified[digest]

    def freeze(self, products):
        require(len(products) == 17, "expected all control executables")
        records = {}
        for name, row in products.items():
            digest = row["sha256"]
            path = self.objects / digest
            require(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), "missing control object")
            with path.open("rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as data:
                require(hashlib.sha256(data).hexdigest() == digest, "incorrect baseline content")
                try:
                    fields(data)
                except (ValueError, KeyError, UnicodeError):
                    forms = [digest]
                else:
                    forms = list(self.form(digest))
            records[name] = {"control":row,"allowed":sorted(forms)}
        return records

    def admitted(self, products, records):
        if products.keys() != records.keys():
            return False
        control = {name:record["control"] for name,record in records.items()}
        return (self.equal(products, control)
                and all(products[name]["sha256"] in record["allowed"] for name,record in records.items()))

    def equal(self, left, right):
        if left == right:
            return True
        if left.keys() != right.keys() or len(left) != 17:
            return False
        for name in left:
            a, b = dict(left[name]), dict(right[name])
            a_hash, b_hash = a.pop("sha256"), b.pop("sha256")
            if a != b:
                return False
            if a_hash != b_hash:
                pair = self.form(a_hash)
                if set(pair) != {a_hash, b_hash} or self.form(b_hash) != pair:
                    return False
        return True

    def bundles(self, left, right):
        a, b = dict(left), dict(right)
        pa, pb = a.pop("all_products"), b.pop("all_products")
        fa, fb = a.pop("files"), b.pop("files")
        for files, products in ((fa, pa), (fb, pb)):
            if files != {k: {field: row[field] for field in ("path", "bytes", "sha256")} for k,row in products.items()}:
                return False
        return a == b and self.equal(pa, pb)

