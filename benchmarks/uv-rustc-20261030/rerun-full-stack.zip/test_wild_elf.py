"""Exercise reciprocal ELF reconstruction and encodings that a package trial must reject."""
import hashlib
from pathlib import Path
import struct
import sys
import tempfile

sys.path.insert(0,str(Path(__file__).resolve().parent))
from wild_elf import Programs, blake3, signature


def image(width, byte=b"A", flags=0x32, load_length=512, corrupt_id=False):
    buf = bytearray(1536)
    buf[:16] = b"\x7fELF\x02\x01\x01" + bytes(9)
    struct.pack_into("<HHIQQQIHHHHHH", buf, 16, 3,62,1,400,64,768,0,64,56,1,64,5,4)
    struct.pack_into("<IIQQQQQQ",buf,64,1,4,0,0,0,load_length,load_length,4096)
    names=b"\0.note.gnu.build-id\0.rodata\0.text\0.shstrtab\0"
    buf[560:560+len(names)] = names
    for i, (name,typ,opts,offset,size,align,entsize) in enumerate((
        (b".note.gnu.build-id",7,2,256,48,4,0),
        (b".rodata",1,flags,352,24,8,width),
        (b".text",1,6,400,9,16,0),
        (b".shstrtab",3,0,560,len(names),1,0),
    ), 1):
        struct.pack_into("<IIQQQQIIQQ",buf,768+64*i,names.index(name),typ,opts,offset,offset,size,0,0,align,entsize)
    buf[352:376] = b"abcdef"*4
    buf[400:409] = byte*9
    result = blake3()(bytes(buf),len(buf))
    buf[256:304] = struct.pack("<III4s",4,32,3,b"GNU\0") + (bytes(32) if corrupt_id else result)
    return bytes(buf)


def refused(action):
    try:
        action()
    except (ValueError, OSError):
        return
    raise AssertionError("expected rejection")


def main():
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp)
        def put(buf):
            digest=hashlib.sha256(buf).hexdigest()
            (root/digest).write_bytes(buf)
            return digest
        left, right=(put(image(v)) for v in (0,8))
        pair=(left,right)
        assert signature(root/left,left) == signature(root/right,right) == pair
        compare=Programs(root)
        def roles(h):
            return {str(i):{"sha256":left if i else h,"path":str(i),"bytes":1536,"tests":0} for i in range(17)}
        assert compare.equal(roles(left),roles(right)) and compare.equal(roles(right),roles(left))
        diff=roles(right);diff["7"]["tests"]=1
        assert not compare.equal(roles(left),diff)
        diff=roles(right);diff.pop("15")
        assert not compare.equal(roles(left),diff)
        bad=put(image(8,byte=b"B"))
        assert not compare.equal(roles(left),roles(bad))
        for malformed in [image(16),image(8,flags=2),image(8,load_length=1450),image(8,corrupt_id=True)]:
            digest=put(malformed)
            refused(lambda:signature(root/digest,digest))
        refused(lambda:signature(root/right,left))
    print("Reciprocal ELFs, changed program/list/path, malformed section metadata, and incorrect build IDs checked.")


if __name__=="__main__":
    main()

