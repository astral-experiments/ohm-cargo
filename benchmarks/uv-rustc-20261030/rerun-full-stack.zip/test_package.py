"""Simulate both full package workflows with a real temporary Git repo and script SDKs."""
import argparse,copy,hashlib,json,os,shutil,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
import package_rerun as p
import package_score as scorer
import package_process as outside
from common import write,sha
from test_replay import executable
orig=p.original
def rejects(call):
    try:call()
    except (ValueError,FileNotFoundError):return
    raise AssertionError('accepted mutant')
def main(t):
    w=copy.deepcopy(p.read(H/'workflow.json'));repo=t/'input-uv';repo.mkdir();orig.git(repo,'init','-q','--template=','--initial-branch=test')
    (repo/'Cargo.lock').write_text('synthetic\n');(repo/'Cargo.toml').write_text('[workspace]\n')
    for fname,e in w['endpoints'].items():
        path=repo/e['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_text('B\n');e['B']=orig.blob(path.read_bytes())
    def commit(msg):
        orig.git(repo,'add','.');orig.git(repo,'-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm',msg);return orig.git(repo,'rev-parse','HEAD').decode().strip()
    w['parent']=commit('B');orig.git(repo,'tag','0.12.0')
    for e in w['endpoints'].values():
        path=repo/e['path'];path.write_text('A\n');e['A']=orig.blob(path.read_bytes())
    A=commit('A');w['A']['git_description']=orig.git(repo,'-c','core.abbrev=7','log','-1','--date=short','--abbrev=9','--format=%H %h %cd %(describe:tags)').decode().strip();w['A'].update(commit=A,tree=orig.git(repo,'rev-parse','HEAD^{tree}').decode().strip(),self_version={'test_head':A},version='tiny version')
    (repo/'user-untracked').write_text('keep');user=repo/w['endpoints']['settings']['path'];user.write_text('dirty caller bytes')
    cache=t/'cache';(cache/'registry').mkdir(parents=True);(cache/'registry/old').write_text('input');first=t/'sdk-C';dso=Path('lib/librustc_driver-test.so');(first/dso).parent.mkdir(parents=True);(first/dso).write_text('C')
    executable(first/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd','raise SystemExit(73)\n')
    executable(first/'bin/rustc','print('+repr(w['driver_version_prefix'])+',end="")\n')
    roles=p.science('CZD')['expected_reported_test_roles']
    fake=r'''import json,os,sys
from pathlib import Path
if sys.argv[1:]==['-vV']:
 print('commit-hash: CARGOREV');sys.exit()
assert sys.argv[1:]==COMMAND,sys.argv
sdk=Path(__file__).resolve().parents[1];arm=(sdk/'lib/librustc_driver-test.so').read_text();src=Path.cwd();t=Path(os.environ['CARGO_TARGET_DIR'])
state=(src/EDIT).read_text().strip()
if state=='B':
 assert not (t/'B-already').exists(),'reused B'
 (t/'B-already').touch()
for name in ['libm','zeroize','num-bigint','num-bigint-dig','rsa','secret-service','uv']:
 for key in (['id','extra'] if name=='zeroize' else ['id']):
  unit=t/'debug/build'/name/key
  out=unit/'out';out.mkdir(parents=True,exist_ok=True)
  opaque=(name=='libm' and arm in ['P','ZD']) or (name not in ['libm','uv'] and arm in ['P','C'])
  ingredients=('crates/uv/tests/tool/main.rs '+EDIT if name=='uv' else name)
  (out/(name+'.d')).write_text('target: '+ingredients+' '+('/dev/null/ohm-untracked-relink-inputs' if opaque else '/dev/null/ohm-recheck-dependent-links')+'\n')
  if opaque or (name=='uv' and state=='B'):
   fp=unit/'fingerprint';fp.mkdir(exist_ok=True);(fp/'invoked.timestamp').touch();print('    Compiling '+name+' v0')
for i,role in enumerate(ROLES+['uv','uvx']):
 rel='debug/'+role if role in ('uv','uvx') else 'debug/build/uv/id/out/program'+str(i)
 dst=t/rel;dst.parent.mkdir(exist_ok=True,parents=True)
 header=bytes.fromhex('7f454c46020101')+bytes(9)+bytes.fromhex('03003e00')
 dst.write_bytes(header+json.dumps([role,state if role=='tests/tool/main.rs' else 'both']).encode());dst.chmod(0o755)
 if role not in ('uv','uvx'):print(f'  Executable {role} ({dst})')
'''
    for raw,new in [('CARGOREV',w['cargo_commit']),('COMMAND',repr(p.science('CZD')['ordinary_argv'][1:])),('EDIT',repr(w['endpoints']['tool-test']['path'])),('ROLES',repr(roles))]:fake=fake.replace(raw,new)
    executable(first/'bin/cargo',fake)
    sdks={'C':first};sub={}
    for arm in ('P','ZD','CZD'):
        d=t/('sdk-'+arm);shutil.copytree(first,d);(d/dso).write_text(arm);sdks[arm]=d
    for arm,d in sdks.items():sub[arm]={'tree':w['subject_source_trees'][arm],'driver_sha256':sha(d/dso)}
    sub['common_members']={i.relative_to(first).as_posix():sha(i) for i in first.rglob('*') if i.is_file() and i.relative_to(first)!=dso};write(t/'test-subjects.json',sub)
    class NullObserver:
        def __init__(self):self.events=[]
        def __enter__(self):return self
        def __exit__(self,*a):pass
    def behavior(argv,**kwargs):
        name,state=json.loads(Path(argv[0]).read_bytes()[20:])
        if argv[1:]==['--list']:
            v=(H/'package-original'/('tool-'+state+'-list.txt')).read_bytes() if name=='tests/tool/main.rs' else b'one: test\n\n1 test, 0 benchmarks\n'
        elif argv[1:]==['--version']:v=b'tiny version\n'
        else:assert argv[1:]==['self','version','--output-format','json'];v=json.dumps(w['A']['self_version']).encode()
        return SimpleNamespace(returncode=0,stdout=v,stderr=b'')
    initial_time=[0,0];results={}
    actual = p.read(H/'package-original/direct-v3-excluded-warm-A.json')
    expected = actual['ordinary_17']
    changed = {**expected, actual['role']: actual['verify_difference']}
    allowed = {expected[actual['role']]['sha256'], changed[actual['role']]['sha256']}
    assert actual['P_only_control_seal_monotonic_ns'] < actual['first_ZD_start_monotonic_ns']
    assert allowed == set(actual['P_only_allowed_sha256']) and len(allowed) == 2
    work = {'packages':['uv'], 'changed_stamps':['uv/unit']}
    assert scorer.same_arm_warm_repeat(work, expected, work, expected)
    assert not scorer.same_arm_warm_repeat(work, expected, work, changed)
    assert not scorer.same_arm_warm_repeat(work, expected, {**work, 'changed_stamps':[]}, expected)
    with patch.object(p.Package,'observer',NullObserver),patch.object(p.Package,'execute',staticmethod(behavior)),patch.object(orig,'drain_session',lambda sid:{'session':sid,'remaining':[],'seconds':0,'observed':[]}):
        for lane,c in (('known-warm-exclusion','ZD'),('combined','CZD'),('leaf','ZD'),('pilot-stops','CZD')):
            before=orig.baseline(c);run=t/('run-'+lane);docs=copy.deepcopy(p.science(c));docs['uv']={**docs['uv'],'A':A,'edit':w['endpoints']['tool-test']}
            def clock():
                initial_time[0]+=1;active=run/'active/source'/w['endpoints']['tool-test']['path'];arm=(run/'sdk'/dso).read_text()
                add=300 if lane!='pilot-stops' and initial_time[0]%2==0 and arm==before and active.read_text().strip()=='B' else 100;initial_time[1]+=add;return initial_time[1]
            args=argparse.Namespace(contrast=c,run=run,uv_clone=repo,cargo_home=cache,control_sdk=sdks[before],candidate_sdk=sdks[c],subjects=t/'test-subjects.json',reserve_gib=0,max_target_gib=1)
            rep=p.Package(args,w,docs)
            rep.seal_time=lambda:initial_time[1]+1
            cog=rep.cargo
            calls=[]
            def cargo(arm,edit,state,folder):
                class Contaminated(NullObserver):
                    def __init__(self):self.events=[{'ns':1,'foreign':[{'pid':123,'start_ticks':456,'sid':789,'name':'rustc'}]}]
                kind=Contaminated if lane=='combined' and folder.parts[-3:-1]==('pair-03','try-0') and folder.name.startswith('1-') else NullObserver
                calls.append((arm,state,folder.name))
                with patch.object(rep,'observer',kind):
                    roster,bundle=cog(arm,edit,state,folder)
                if lane == 'known-warm-exclusion' and arm == 'ZD' and folder.name in ('ordinary-repeat','verify-repeat'):
                    raw = expected if folder.name == 'ordinary-repeat' else changed
                    files = {k:{field:row[field] for field in ('path','bytes','sha256')} for k,row in raw.items()}
                    bundle = {**bundle, 'all_products':raw, 'files':files}
                return roster,bundle
            with patch.object(orig.time,'monotonic_ns',clock),patch.object(rep,'cargo',cargo),patch.object(outside,'clear_existing',lambda:True):
                rep.setup()
                if lane == 'known-warm-exclusion':
                    def refuse_equivalence(first, second):
                        if first == second:
                            return True
                        assert first['all_products'] == expected and second['all_products'] == changed
                        assert calls == [(name,'A',step) for name in ('P','ZD') for step in ('cold','ordinary-repeat','verify-repeat')]
                        raise AssertionError('within-arm A validation called the permissive cross-arm comparator')
                    with patch.object(rep,'same_products',refuse_equivalence):
                        try:
                            rep.endpoint()
                        except ValueError as error:
                            assert str(error) == 'A products or compilation work did not settle', error
                        else:
                            raise AssertionError('admitted the known false warm repeat')
                    assert calls == [(arm,'A',step) for arm in ('P','ZD') for step in ('cold','ordinary-repeat','verify-repeat')]
                    assert not (run/'seeds/tool-test-ZD').exists() and not (run/'records/tool-test/admission').exists()
                    continue
                rep.endpoint()
            write(run/'complete.json',{'contrast':c,'phase':'package-test','portable':True,'scientific_sha256':p.COMBINED if c=='CZD' else p.DIRECT,'closed_sha256':sha(run/'records/tool-test/closed.json')});res=scorer.raw(run,w,docs)
            if lane=='pilot-stops':assert res['pairs']==0 and res['summary'] is None;continue
            f=run/'package-source.json';saved=f.read_bytes();bad=json.loads(saved);bad['describe_always']='bad';f.write_text(json.dumps(bad));rejects(lambda:scorer.raw(run,w,docs));f.write_bytes(saved)
            results[c]=res;assert len(res['excluded_attempts'])==(lane=='combined')
            assert res['pairs']==12 and res['summary']['individual_gate'] and (res['excluded_pilot_ns'] is None)==(c=='ZD')
            root=run/'records/tool-test';d=next((root/'pair-01/try-0').glob('0-*'))
            for path in [d/'all-products.json',d/'test-lists'/'tests__tool__main.rs.stdout',d/'cargo.log',d/'stamps-before.json',next((run/'objects').iterdir())]:
                raw=path.read_bytes();path.write_bytes(raw+b'bad' if path.suffix!='.json' else b'{}');rejects(lambda:scorer.raw(run,w,docs));path.write_bytes(raw)
            q=root/'closed.json';good=q.read_bytes();rec=p.read(q);rec['pilot']={'P':123,'ZD':1};q.write_text(json.dumps(rec));rejects(lambda:scorer.raw(run,w,docs));q.write_bytes(good)
            assert scorer.raw(run,w,docs)==res
    summary={k:results[a]['summary'] for k,a in [(scorer.COMBINED,'CZD'),('P-to-ZD/package-test','ZD')]}
    family=scorer.adjusted(scorer.FAMILY,{scorer.COMBINED:summary[scorer.COMBINED]})
    assert len(family)==10 and all(family[name]['raw_p']==1 for name in scorer.FAILED) and family[scorer.COMBINED]['confirmed']
    for name in scorer.FAILED:
        rejects(lambda:scorer.adjusted(scorer.FAMILY,{name:summary[scorer.COMBINED]}))
    assert scorer.adjusted((*scorer.FAMILY,'P-to-ZD/package-test'),summary)['P-to-ZD/package-test']['confirmed']
    assert user.read_text()=='dirty caller bytes' and (repo/'user-untracked').read_text()=='keep' and (cache/'registry/old').read_text()=='input' and all((root/dso).read_text()==arm for arm,root in sdks.items())
    sid=os.getsid(0);rows={99:(2,sid,11,'self',b'S'),100:(99,100,44,'cargo',b'R'),101:(100,100,45,'rustc',b'R'),102:(1,333,46,'rustc',b'S'),103:(1,555,47,'cargo',b'Z')};known={}
    assert [p['pid'] for p in outside.outside(rows,99,known)]==[102]
    rows.pop(100);rows[101]=(1,100,45,'rustc',b'R');assert [p['pid'] for p in outside.outside(rows,99,known)]==[102]
    return {'synthetic_only':True,'recorded_direct_A_mismatch_stops_before_B':True,'unscored_fixture_B_commands':0,'no_native_rust_cargo_or_linker':True,'temporary_git_and_actual_foreground_child_wait':True,'fake_compilers':list(sdks),'raw_ordinary_test_inventories':15,'raw_ELF_roles':17,'combined_pairs':12,'direct_pairs':12,'genuine_pinned_tool_test_inventories':[181,180],'independent_holdouts':True,'corruptions_rejected':['raw log','extra direct pilot','raw ELF','missing summary','wrong list','changed dirty roster'],'source_registry_SDK_user_state_preserved':True,'foreign_vs_owned_control':True,'one_evidenced_foreign_pair_replaced':True,'failed_pilot_retained_with_zero_samples':True}
if __name__=='__main__':
    with tempfile.TemporaryDirectory(prefix='offline-full-package-') as t:print(json.dumps(main(Path(t)),sort_keys=True,indent=2))
