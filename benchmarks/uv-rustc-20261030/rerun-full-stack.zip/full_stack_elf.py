"""Require the exact P-derived class and compare every other byte in observed alternatives."""
import hashlib
import mmap
from contextlib import ExitStack
from pathlib import Path
import wild_elf
from common import need, write
from rerun import read


class PhasePrograms(wild_elf.Programs):
    def __init__(self, root, *, write_proofs=False):
        super().__init__(root / "objects")
        self.root = root
        self.write_proofs = write_proofs
        self.checked = set()

    def accept(self, phase, products, reference):
        need(self.admitted(products, reference), "product, behavior or raw SHA not in the independent " + phase + " class")
        for role, observed in products.items():
            h = observed["sha256"]
            base = reference[role]["control"]["sha256"]
            if h == base or (phase,role,base,h) in self.checked:
                continue
            ordered = self.form(base)
            need(set(ordered) == {base,h} and ordered == self.form(h), "failed reciprocal complete-file reconstruction")
            with ExitStack() as stack:
                images = []
                for digest in ordered:
                    f = stack.enter_context((self.objects / digest).open("rb"))
                    images.append(stack.enter_context(mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)))
                a, b = images
                width, note = wild_elf.fields(a)
                need((width,note) == wild_elf.fields(b) and len(a) == len(b) == observed["bytes"] and
                     (a[width],b[width]) == (0,8), "different geometry or invalid observed widths")
                covered = sorted([(width,width+1),(note+16,note+48)])
                index = 0
                for first, end in covered + [(len(a),len(a))]:
                    for start in range(index, first, 1024*1024):
                        stop = min(start+1024*1024, first)
                        need(a[start:stop] == b[start:stop], "different bytes outside the registered fields")
                    index = end
                record = {"phase":phase,"role":role,"bytes":len(a),"P_raw_sha256":base,"observed_alternate_sha256":h,
                          "width_0_8_sha256":list(ordered),"recomputed_gnu_build_ids":[im[note+16:note+48].hex() for im in images],
                          "ranges":[list(pair) for pair in covered],"other_differing_bytes":0}
            label = hashlib.sha256((phase+"\0"+role+"\0"+base+"\0"+h).encode()).hexdigest()
            path = self.root / "full-stack-proofs" / phase / (label + ".json")
            if self.write_proofs and not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                write(path,record)
            need(read(path) == record, "detached reciprocal proof does not match the two complete ELF files")
            self.checked.add((phase,role,base,h))
