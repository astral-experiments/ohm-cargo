"""Check the portable exec decoder against three genuine public native process traces. No SDK needed."""
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from common import need, sha
from full_stack_trace import args_from

PACKET='cdd67c8caa1924d569577f989994c0f9612bc206ff040524dfc42a286ab3d5ff'

def calibration(path):
    need(sha(path)==PACKET,'wrong public C/CZD result packet')
    with ZipFile(path) as archive:
        layout=json.loads(archive.read('layout.json'))['files']
        def raw(name):
            entry=layout['phases/combined/admission-CZD/B/'+name]
            digest=entry
            b=archive.read('objects/'+digest)
            need(hashlib.sha256(b).hexdigest()==digest,'changed original native process receipt')
            return b
        expected=json.loads(raw('census.json'))['actual']
        cargo=json.loads(raw('command.json'))['argv']
        rows={}
        for role,pid,argv in [('cargo',2195906,cargo)]+[(r['role'],r['pid'],r['argv']) for r in expected]:
            original=raw('exec.'+str(pid));out=[v for line in original.decode().splitlines() if (v:=args_from(line)) is not None]
            need(len(out)==1 and out[0][0]==argv[0] and out[0][1]==argv,'actual executable or any argument differed')
            rows[role]={'pid':pid,'argc':len(argv),'raw_sha256':hashlib.sha256(original).hexdigest()}
        need({k:v['argc'] for k,v in rows.items()}=={'cargo':8,'compile':1607,'link':607},'different native roster')
        return {'original_packet_sha256':PACKET,'scope':'previously completed marginal control, exec parser calibration only','matching_complete_argv':rows}
if __name__=='__main__':
    print(json.dumps(calibration(Path(sys.argv[1])),indent=2))
