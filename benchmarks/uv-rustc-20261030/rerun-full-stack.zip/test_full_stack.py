"""Simulate both full package workflows with a real temporary Git repo and script SDKs."""
import argparse,copy,hashlib,json,os,shutil,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
import package_rerun as p
import package_score as scorer
import package_process as outside
from common import write,sha
from test_replay import executable
orig=p.original
def rejects(call):
    try:call()
    except (ValueError,FileNotFoundError):return
    raise AssertionError('accepted mutant')
import full_stack as stack
import full_stack_score as result

def main(t):
    w=copy.deepcopy(p.read(H/'workflow.json'));repo=t/'input-uv';repo.mkdir();orig.git(repo,'init','-q','--template=','--initial-branch=test')
    (repo/'Cargo.lock').write_text('synthetic\n');(repo/'Cargo.toml').write_text('[workspace]\n')
    for fname,e in w['endpoints'].items():
        path=repo/e['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_text('B\n');e['B']=orig.blob(path.read_bytes())
    def commit(msg):
        orig.git(repo,'add','.');orig.git(repo,'-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm',msg);return orig.git(repo,'rev-parse','HEAD').decode().strip()
    w['parent']=commit('B');orig.git(repo,'tag','0.12.0')
    for e in w['endpoints'].values():
        path=repo/e['path'];path.write_text('A\n');e['A']=orig.blob(path.read_bytes())
    A=commit('A');w['A']['git_description']=orig.git(repo,'-c','core.abbrev=7','log','-1','--date=short','--abbrev=9','--format=%H %h %cd %(describe:tags)').decode().strip();w['A'].update(commit=A,tree=orig.git(repo,'rev-parse','HEAD^{tree}').decode().strip(),self_version={'test_head':A},version='tiny version')
    (repo/'user-untracked').write_text('keep');user=repo/w['endpoints']['settings']['path'];user.write_text('dirty caller bytes')
    cache=t/'cache';(cache/'registry').mkdir(parents=True);(cache/'registry/old').write_text('input');first=t/'sdk-C';dso=Path('lib/librustc_driver-test.so');(first/dso).parent.mkdir(parents=True);(first/dso).write_text('C')
    executable(first/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd','raise SystemExit(73)\n')
    executable(first/'bin/rustc','print('+repr(w['driver_version_prefix'])+',end="")\n')
    roles=p.science('CZD')['expected_reported_test_roles']
    fake=r'''import json,os,sys
from pathlib import Path
if sys.argv[1:]==['-vV']:
 print('commit-hash: CARGOREV');sys.exit()
assert sys.argv[1:]==COMMAND,sys.argv
sdk=Path(__file__).resolve().parents[1];arm=(sdk/'lib/librustc_driver-test.so').read_text();src=Path.cwd();t=Path(os.environ['CARGO_TARGET_DIR'])
state=(src/EDIT).read_text().strip()
if state=='B':
 assert not (t/'B-already').exists(),'reused B'
 (t/'B-already').touch()
for name in ['libm','zeroize','num-bigint','num-bigint-dig','rsa','secret-service','uv']:
 for key in (['id','extra'] if name=='zeroize' else ['id']):
  unit=t/'debug/build'/name/key
  out=unit/'out';out.mkdir(parents=True,exist_ok=True)
  opaque=(name=='libm' and arm in ['P','ZD']) or (name not in ['libm','uv'] and arm in ['P','C'])
  ingredients=('crates/uv/tests/tool/main.rs '+EDIT if name=='uv' else name)
  (out/(name+'.d')).write_text('target: '+ingredients+' '+('/dev/null/ohm-untracked-relink-inputs' if opaque else '/dev/null/ohm-recheck-dependent-links')+'\n')
  if opaque or (name=='uv' and state=='B'):
   fp=unit/'fingerprint';fp.mkdir(exist_ok=True);(fp/'invoked.timestamp').touch();print('    Compiling '+name+' v0')
for i,role in enumerate(ROLES+['uv','uvx']):
 rel='debug/'+role if role in ('uv','uvx') else 'debug/build/uv/id/out/program'+str(i)
 dst=t/rel;dst.parent.mkdir(exist_ok=True,parents=True)
 header=bytes.fromhex('7f454c46020101')+bytes(9)+bytes.fromhex('03003e00')
 dst.write_bytes(header+json.dumps([role,state if role=='tests/tool/main.rs' else 'both']).encode());dst.chmod(0o755)
 if role not in ('uv','uvx'):print(f'  Executable {role} ({dst})')
'''
    for raw,new in [('CARGOREV',w['cargo_commit']),('COMMAND',repr(p.science('CZD')['ordinary_argv'][1:])),('EDIT',repr(w['endpoints']['tool-test']['path'])),('ROLES',repr(roles))]:fake=fake.replace(raw,new)
    import test_wild_elf
    payload=[test_wild_elf.image(width).hex() for width in (0,8)]
    base=fake.index(" dst.write_bytes(header+json.dumps")
    end=fake.index(" if role not in (",base)
    new=(
        " if role=='tests/pip_install/main.rs':\n"
        "  nth=t/'nA';n=int(nth.read_text()) if nth.exists() else 0\n"
        "  if state=='A':nth.write_text(str(n+1))\n"
        "  index=(n+int(arm=='CZD'))%2 if state=='A' else int((t/'alternate-b').exists() or arm=='CZD')\n"
        "  dst.write_bytes(bytes.fromhex("+repr(payload)+"[index]))\n"
        " else:\n"
        "  dst.write_bytes(header+json.dumps([role,state if role=='tests/tool/main.rs' else 'both']).encode())\n"
        " dst.chmod(0o755)\n")
    fake=fake[:base]+new+fake[end:]
    executable(first/'bin/cargo',fake)
    sdks={'C':first};sub={}
    for arm in ('P','ZD','CZD'):
        d=t/('sdk-'+arm);shutil.copytree(first,d);(d/dso).write_text(arm);sdks[arm]=d
    for arm,d in sdks.items():sub[arm]={'tree':w['subject_source_trees'][arm],'driver_sha256':sha(d/dso)}
    sub['common_members']={i.relative_to(first).as_posix():sha(i) for i in first.rglob('*') if i.is_file() and i.relative_to(first)!=dso};write(t/'test-subjects.json',sub)
    class NullObserver:
        def __init__(self):self.events=[]
        def __enter__(self):return self
        def __exit__(self,*a):pass
    def behavior(argv,**kwargs):
        raw=Path(argv[0]).read_bytes()
        name,state=('tests/pip_install/main.rs','both') if len(raw)==1536 else json.loads(raw[20:])
        if argv[1:]==['--list']:
            v=(H/'package-original'/('tool-'+state+'-list.txt')).read_bytes() if name=='tests/tool/main.rs' else b'one: test\n\n1 test, 0 benchmarks\n'
        elif argv[1:]==['--version']:v=b'tiny version\n'
        else:assert argv[1:]==['self','version','--output-format','json'];v=json.dumps(w['A']['self_version']).encode()
        return SimpleNamespace(returncode=0,stdout=v,stderr=b'')
    args=argparse.Namespace(contrast='CZD',run=t/'full-stack',uv_clone=repo,cargo_home=cache,control_sdk=sdks['P'],candidate_sdk=sdks['CZD'],subjects=t/'test-subjects.json',reserve_gib=0,max_target_gib=1)
    doc=copy.deepcopy(stack.plan());doc['uv']={**doc['uv'],'A':A,'edit':w['endpoints']['tool-test']}
    rep=stack.Stack(args,w,doc)
    now=[0]
    def clock():
        now[0]+=100
        return now[0]
    calls=[]
    actual=rep.cargo
    from contextlib import contextmanager
    import full_stack_trace as trace
    @contextmanager
    def mock_trace(argv,folder):
        yield
        # This constructed process witness belongs only to the synthetic script fixture.
        raw=folder/'unscored-execs';raw.mkdir()
        sdkdir=str(rep.sdk)
        for pid,exe,values in [(888000,argv[0],argv),(888001,sdkdir+'/bin/rustc',[sdkdir+'/bin/rustc','--crate-name','tool','--test','crates/uv/tests/tool/main.rs','-Zohm-check-relink-inputs']),(888002,sdkdir+'/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd',['ld.bfd','-o','test'])]:
            (raw/('exec.'+str(pid))).write_text('execve('+json.dumps(exe)+', '+json.dumps(values)+', 0x7ffc /* sanitized */) = 0\n')
    def capture(arm,edit,state,folder):
        calls.append([arm,state,folder.name])
        if (arm=='P' and folder.name=='verify-repeat') or arm=='CZD':
            assert 'A' in rep.references and (args.run/'records/tool-test/control-forms-A.json').is_file()
        if state=='B' and arm=='CZD': assert 'B' in rep.references
        if state=='B' and arm=='P' and 'pair-' in str(folder): (rep.target/'alternate-b').touch()
        return actual(arm,edit,state,folder)
    with patch.object(trace,'wrap',mock_trace),patch.object(p.Package,'observer',NullObserver),patch.object(p.Package,'execute',staticmethod(behavior)),patch.object(orig,'drain_session',lambda sid:{'session':sid,'remaining':[],'seconds':0,'observed':[]}),patch.object(rep,'cargo',capture),patch.object(orig.time,'monotonic_ns',clock):
        rep.seal_time=lambda:now[0]+1
        rep.setup();rep.endpoint()
    parent=args.run/'records/tool-test'
    write(args.run/'complete.json',{'contrast':'CZD','phase':stack.SCOPE,'portable':True,'scientific_sha256':stack.SCIENCE,'closed_sha256':sha(parent/'closed.json')})
    positive=result.raw(args.run,w,doc)
    assert positive['pairs']==12 and positive['excluded_pilot_ns'] is None and not positive['summary']['individual_gate']
    assert len(calls)==32 and sorted([n for a,s,n in calls if s=='A'])==sorted(['cold','ordinary-repeat','verify-repeat']*2)
    assert not (parent/'pilot').exists() and all((args.run/'full-stack-proofs'/s).is_dir() for s in ('A','B'))
    signed=[p.read(parent/('control-forms-'+s+'.json')) for s in ('A','B')]
    role='tests/pip_install/main.rs'
    assert all(len(s['roles'][role]['allowed'])==2 for s in signed)
    for arm in ('P','CZD'):
        dirs=[parent/'A'/arm/name/'all-products.json' for name in ('ordinary-repeat','verify-repeat')]
        assert set(p.read(f)[role]['sha256'] for f in dirs)==set(signed[0]['roles'][role]['allowed'])
    held=parent/'pair-01/try-0'
    programs=[p.read(f) for f in sorted(held.glob('*/all-products.json'))]
    assert len(programs)==2 and programs[0]==programs[1] and programs[0][role]['sha256']!=signed[1]['roles'][role]['control']['sha256']
    def mutate(path,fn):
        saved=path.read_bytes();rec=json.loads(saved);fn(rec);path.write_text(json.dumps(rec))
        try:rejects(lambda:result.raw(args.run,w,doc))
        finally:path.write_bytes(saved)
    mutate(parent/'control-forms-A.json',lambda x:x.update(monotonic_ns=p.read(parent/'A/P/verify-repeat/command.json')['end_ns']))
    mutate(parent/'control-forms-B.json',lambda x:x['roles'][role].update(allowed=[x['roles'][role]['control']['sha256']]))
    mutate(next((args.run/'full-stack-proofs/B').iterdir()),lambda x:x.update(other_differing_bytes=1))
    mutate(parent/'A/CZD/verify-repeat/all-products.json',lambda a:a[role].update(tests=2))
    (parent/'pilot').mkdir();rejects(lambda:result.raw(args.run,w,doc));(parent/'pilot').rmdir()
    # A third complete ELF with different text stays inadmissible even if both arms produced it.
    other=test_wild_elf.image(8,byte=b'B')
    h=hashlib.sha256(other).hexdigest();(args.run/'objects'/h).write_bytes(other)
    changed=copy.deepcopy(programs[0]);changed[role]['sha256']=h
    assert rep.elf.equal(changed,changed)
    rejects(lambda:rep.elf.accept('B',changed,signed[1]['roles']))
    assert result.raw(args.run,w,doc)==positive
    twelve=result.family({stack.SCOPE:positive['summary']})
    assert len(twelve)==12 and all(twelve[k]['raw_p']==1 for k in doc['family']['permanently_excluded'])
    rejects(lambda:result.family({'P-to-ZD/package-test':positive['summary']}))
    assert user.read_text()=='dirty caller bytes' and (repo/'user-untracked').read_text()=='keep' and (cache/'registry/old').read_text()=='input'
    return {'synthetic_only':True,'real_rust_compilations':0,'fake_foreground_commands':len(calls),'uncounted_A_and_admission':8,'synthetic_exec_witnesses':4,
        'counted_script_pairs':12,'efficacy_pilot':None,'genuine_uv_timing':False,'P_A_sealed_before_own_verify_and_CZD':True,
        'within_both_A_arms_alternates':True,'P_B_sealed_before_CZD_B':True,'same_nonreference_B_image_in_both_arms_verified_from_P':True,
        'rejected':['late baseline','P-only class corruption','changed test totals','forged reciprocal proof','third program matching only its peer','extra pilot','credit for rejected P/ZD'],
        'provenance':'local temporary Git fixture; artificial stdout, script timers and synthetic ELF64 images',
        'genuine_compiler_sdk_or_Cargo_invocations':0,'nonqualifying_fake_clock_accepted':True,'family_size':len(twelve)}
if __name__=='__main__':
    with tempfile.TemporaryDirectory(prefix='offline-p-czd-') as t:print(json.dumps(main(Path(t)),sort_keys=True,indent=2))
