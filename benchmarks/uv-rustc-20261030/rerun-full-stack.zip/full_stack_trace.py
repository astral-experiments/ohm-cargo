"""Trace only the four unscored compiler/ordinary-link admissions. Never wrap a timed Cargo command."""
import ast
import hashlib
import os
from pathlib import Path
import re
import subprocess
from contextlib import contextmanager
from unittest.mock import patch
from common import need,sha,write
from rerun import read


def requested(folder):
    return folder.name=="verify-repeat" or folder.parent.parent.name=="admission"


def args_from(line):
    if not line.startswith(("execve(","execveat(")) or not re.search(r"\)\s+= 0$",line):
        return None
    text=line[line.index("(")+1:]
    if line.startswith("execveat("):
        text=text[text.index(",")+1:].lstrip()
    m=re.match(r'''("(?:[^"\\]|\\.)*"), (\[)''',text)
    need(m is not None,"unknown successful exec syntax")
    start=m.start(2)
    quoted=escape=False
    for i,ch in enumerate(text[start+1:],start+1):
        if escape:escape=False
        elif quoted and ch=="\\":escape=True
        elif ch=='"':quoted=not quoted
        elif not quoted and ch=="]":break
    else:raise ValueError("unfinished exec argv")
    exe=ast.literal_eval(m.group(1))
    argv=ast.literal_eval(text[start:i+1])
    need(exe and isinstance(argv,list) and len(argv)>0 and all(isinstance(s,str) for s in argv),"truncated or unsupplied exec arguments")
    return exe,argv


def inventory(folder,root,arm,argv,driver):
    cmd=read(folder/'command.json')
    directory=folder/'unscored-execs'
    streams={};trees=[];cargo=[];rust=[];wild=[]
    bases={str(Path(argv[0]).parents[1]),str(Path(read(root/'inputs.json')['sdks'][arm]))}
    for path in sorted(directory.glob('exec.*')):
        pid=int(path.suffix[1:]);need(pid>0 and path.is_file() and not path.is_symlink(),'malformed per-process exec stream')
        streams[path.name]=sha(path)
        with path.open(errors='strict') as f:
            for line in f:
                row=args_from(line.strip())
                if row is None:continue
                exe,args=row
                if exe==argv[0] and args==argv:cargo.append(pid)
                elif Path(exe).name=='rustc' and '--crate-name' in args:
                    need(any(exe==b+'/bin/rustc' for b in bases),'compiler outside the selected SDK')
                    rust.append({'pid':pid,'exe':exe,'argv':args})
                elif '/wild-ld/' in exe:
                    need(any(exe.startswith(b+'/lib/rustlib/') for b in bases),'Wild outside the selected SDK')
                    wild.append({'pid':pid,'exe':exe,'argv':args})
                trees.append((pid,exe))
    need(len(cargo)==1 and streams and trees,'missing original ordinary Cargo entry')
    if cmd['source']['state']=='B':
        need(any('--test' in r['argv'] and 'crates/uv/tests/tool/main.rs' in r['argv'] and
                 '-Zohm-check-relink-inputs' in r['argv'] for r in rust) and wild,
             'actual edited owner and Wild link were not observed')
    elif cmd['packages']:
        need(rust,'warm compilation has no selected rustc')
    return {'scope':'unscored exec observation','arm':arm,'cargo_pid':cargo[0],'tracer_pid':cmd['pid'],
            'actual_cargo_argv':argv,'selected_driver_sha256':driver,'trace_sha256':streams,
            'rustc':rust,'wild':wild,'counted':False}


@contextmanager
def wrap(argv,folder,tracer='/usr/bin/strace'):
    original=subprocess.Popen
    seen=[]
    def launch(actual,*args,**kwargs):
        if list(actual)==list(argv):
            need(not seen,'multiple captures of the designated ordinary Cargo')
            trace=folder/'unscored-execs'
            trace.mkdir()
            seen.append(True)
            actual=[tracer,'-ff','-qq','-v','-s','2097152','-e','trace=execve,execveat','-o',str(trace/'exec'),'--',*argv]
        return original(actual,*args,**kwargs)
    with patch.object(subprocess,'Popen',launch):yield
    need(seen,'no true Cargo call reached the unscored exec tracer')
