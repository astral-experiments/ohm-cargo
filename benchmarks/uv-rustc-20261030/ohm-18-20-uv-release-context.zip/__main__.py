"""Replay the shipped -18 and -20 descriptive Cargo observations from this zip."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replay(read):
    obj = lambda name: json.loads(read(name))
    manifest = obj("SHA256.json")
    for name, digest in manifest.items():
        require(sha(read(name)) == digest, "packet digest mismatch: " + name)
    plan = obj("workload.json")
    releases = obj("release-pins.json")
    argv = ["test", "--locked", "--offline", "-j8", "-p", "uv", "--no-run"]
    stages = ("cold-A", "settle-A", "unchanged-A", "first-B")
    roles = set(plan["expected_reported_test_roles"]) | {"uv", "uvx"}
    require(len(roles) == 17 and plan["ordinary_argv"] == ["cargo", *argv], "different workload")
    results, observables = {}, {}
    for version in ("18", "20"):
        prefix = version + "/"
        get = lambda name: obj(prefix + name)
        digest = lambda name: sha(read(prefix + name))
        outer, worker, success = (get(name) for name in ("outer-return.json", "worker-return.json", "success.json"))
        require(outer["outer"]["exit"] == outer["worker_code"] == worker["worker_exit"] == worker["code"] == 0, "worker failed")
        require(outer["host_released"] and not outer["remaining_workers"] and not outer["foreign"], "host did not return cleanly")
        require(outer["worker_sha256"] == digest("worker-return.json") and outer["intake_sha256"] == digest("intake.json") and worker["success"] == digest("success.json"), "different receipts")
        subject, summary = get("subject.json"), get("context.json")
        require(subject["release"] == version and [subject[k] for k in ("archive_sha256","rust_source","cargo_source")] == releases[version], "wrong SDK")
        require(len(subject["files"]) == 67 and subject["files"][subject["driver"]]["sha256"] == subject["driver_sha256"], "wrong installed member inventory")
        require(success["release"] == version and success["subject_sha256"] == digest("subject.json") and success["context_sha256"] == digest("context.json"), "different SDK or summary")
        require(success["witness_sha256"] == digest("cold-mapped-tools.json") and success["source_sha256"] == digest("source-restored.json") and success["retired_sha256"] == digest("retired.json"), "missing live compiler or restored source")
        require(worker["scored_rows"] == success["scored_rows"] == summary["statistical_rows"] == summary["primary_family_credit"] == 0, "unexpected statistical credit")
        elapsed = {}
        raw_products = {}
        for stage in stages:
            base = stage + "/"
            command, items = get(base + "command.json"), get(base + "all-products.json")
            form = "B" if stage == "first-B" else "A"
            require(command["argv"] == command["actual_argv"] and command["argv"][1:] == argv and Path(command["argv"][0]).name == "cargo", "wrong Cargo command")
            require(command["driver"] == subject["driver_sha256"] and command["exit"] == 0 and not command["traced"] and not command["fingerprint_diagnostics"] and not command["observer_faults"], "invalid Cargo invocation")
            require(command["source"]["oid"] == plan["uv"]["A"] and command["source"]["form"] == form and command["source"]["blob"] == plan["uv"]["edit"][form], "wrong source")
            record = summary["stages"][stage]
            ns = command["end_ns"] - command["start_ns"]
            require(ns == record["nanoseconds"] == command["elapsed_ns"] and ns > 0 and record["command_sha256"] == digest(base + "command.json"), "invalid clock")
            require(record["products_sha256"] == digest(base + "all-products.json") and record["log_sha256"] == command["log_sha256"] == digest(base + "cargo.log") and set(items) == roles, "incorrect outputs")
            elapsed[stage] = ns
            inventory = {}
            for name, info in items.items():
                runtime = base + "test-lists/" + name.replace("/", "__").replace(" ", "_")
                stdout, stderr = read(prefix + runtime + ".stdout"), read(prefix + runtime + ".stderr")
                require(info["exit"] == 0 and sha(stdout) == info["stdout_sha256"] and sha(stderr) == info["stderr_sha256"], "missing runtime output")
                if name not in ("uv", "uvx"):
                    tests = [s for s in stdout.splitlines() if s.endswith(b": test")]
                    require(info["tests"] == len(tests) and info["argv_tail"] == ["--list"], "incorrect test list")
                inventory[name] = (stdout, stderr)
            if stage in ("unchanged-A", "first-B"):
                observables[version, stage] = inventory
                raw_products[stage] = {role: item["sha256"] for role, item in items.items()}
                kept = get(base + "retained.json")
                require(success["A_B_stores"][stage] == digest(base + "retained.json") and set(kept) == roles and all((kept[k]["raw_sha256"], kept[k]["raw_bytes"]) == (v["sha256"], v["bytes"]) for k,v in items.items()), "incomplete retained program ledger")
        a, b = observables[version, "unchanged-A"], observables[version, "first-B"]
        changed = [k for k in a if a[k] != b[k]]
        require(changed == ["tests/tool/main.rs"], "a different observable changed")
        a_names, b_names = (set(s[changed[0]][0].splitlines()) for s in (a,b))
        removed = [s.decode() for s in a_names - b_names if s.endswith(b": test")]
        require(removed == ["tool_list::tool_list_outdated_respects_configured_index: test"] == summary["removed_tool_tests"], "wrong test edit")
        changed_files = sorted(k for k in roles if raw_products["unchanged-A"][k] != raw_products["first-B"][k])
        require(changed_files == sorted(summary["A_to_B_raw_changes"]), "different program hash comparison")
        require(get("edit.json")["numstat"].split() == ["0", "62", "crates/uv/tests/tool/tool_list.rs"], "different edit")
        results[version] = {"nanoseconds": elapsed, "held_out_pairs": 0, "changed_program_hashes": changed_files}
    for stage in ("unchanged-A", "first-B"):
        require(observables["18",stage] == observables["20",stage], "shipped release behavior differs")
    intake = obj("20/intake.json")
    require(intake["previous_sha256"] == sha(read("18/outer-return.json")) and intake["outer"] == obj("18/outer-return.json")["outer"], "out-of-order release contexts")
    return {"releases":results, "programs_per_stage":len(roles), "test_lists_per_stage":15, "scope":"One first edit per released SDK. No paired statistical estimate."}


if __name__ == "__main__":
    name = sys.argv[1] if len(sys.argv) > 1 else sys.argv[0]
    with zipfile.ZipFile(name) as packet:
        print(json.dumps(replay(packet.read), indent=2, sort_keys=True))
