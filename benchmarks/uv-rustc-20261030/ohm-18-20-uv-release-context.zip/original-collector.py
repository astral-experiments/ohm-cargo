"""Descriptive, separately leased whole-package contexts with actual Ohm Linux releases."""
import contextlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
PKG = CASE / 'package-test'
FRESH = CASE / 'fresh-edit-trial'
sys.path[:0] = [str(HERE), str(FRESH)]
import releases
import study

m = study.m
v, r, o = m.v, m.r, m.o
need, read, write, sha = v.need, v.read, v.write, v.sha
bank = m.seed.BANKS
pkg = v.code(PKG / 'worker.py', 'released_package_worker')
cas = v.code(PKG / 'checkpoint.py', 'released_package_raw')
REG = HERE / 'registration.json'
STAGES = ('cold-A', 'settle-A', 'unchanged-A', 'first-B')
MANIFESTS = ('Cargo.lock', 'Cargo.toml', 'crates/uv/Cargo.toml')
TOOL = 'tool-test'
G = 1 << 30


def out(release):
    need(release in releases.PIN, 'unknown release')
    return HERE / ('physical-' + release)


def ram(release):
    return Path('/dev/shm/ohm-distributed-package-context-20261030-' + release)


def verify():
    reg = read(REG)
    need(all(sha(Path(k)) == h for k, h in reg['inputs'].items()), 'registered source or provenance changed')
    plan = read(PKG / 'protocol.json')
    need(plan['ordinary_argv'] == ['cargo','test','--locked','--offline','-j8','-p','uv','--no-run']
         and len(plan['expected_reported_test_roles']) == 15 and plan['uv']['A'] == m.A
         and plan['uv']['edit']['path'] == 'crates/uv/tests/tool/tool_list.rs' and m.FLOOR == 122*G,
         'different workload, product rule or reserve')
    return reg


def prior(path, digest):
    need(path == path.resolve() and path.name == 'outer-return.json' and sha(path) == digest, 'wrong physical predecessor')
    if path == out('18') / 'outer-return.json':
        return closed('18', path, digest)
    if path == CASE / 'remaining-tool-profile/physical/outer-return.json':
        return v.code(CASE / 'remaining-tool-profile/run.py','distributed_profile_previous').closed(path,digest)
    return v.code(CASE / 'remaining-tool-profile/run.py','distributed_series_previous').previous(path,digest)


def summarize(folder):
    records = {}
    for stage in STAGES:
        p = folder / stage
        cmd = read(p / 'command.json')
        products = read(p / 'all-products.json')
        need(cmd['argv'] == cmd['actual_argv'] == [str(r.SDK/'bin/cargo'), *pkg.PLAN['ordinary_argv'][1:]]
             and not cmd['traced'] and not cmd['fingerprint_diagnostics'] and not cmd['observer_faults']
             and cmd['exit'] == 0 and cmd['end_ns'] - cmd['start_ns'] == cmd['elapsed_ns'] > 0
             and cmd['log_sha256'] == sha(p/'cargo.log') and cmd['driver'] == read(folder/'subject.json')['driver_sha256'],
             'failed, instrumented, or substituted Cargo invocation')
        form = 'B' if stage == 'first-B' else 'A'
        st = cmd['source']
        need(st['oid'] == m.A and st['ref'] == pkg.PLAN['uv']['ref'] and st['form'] == form
             and st['blob'] == pkg.PLAN['uv']['edit'][form] and set(products) ==
             set(pkg.PLAN['expected_reported_test_roles']) | {'uv','uvx'}, 'source or product roster differs')
        for name, info in products.items():
            raw = p/'test-lists'/pkg.products.role_file(name)
            need(info['exit'] == 0 and info['stdout_sha256'] == sha(Path(str(raw)+'.stdout'))
                 and info['stderr_sha256'] == sha(Path(str(raw)+'.stderr')), 'runtime output missing')
        records[stage] = {'nanoseconds':cmd['elapsed_ns'], 'packages':cmd['packages'],
                          'changed_stamps':len(cmd['changed_stamps']), 'log_sha256':cmd['log_sha256'],
                          'command_sha256':sha(p/'command.json'), 'products_sha256':sha(p/'all-products.json')}
    forms = [read(folder/p/'all-products.json') for p in STAGES]
    for q in forms[:2]:
        need(all((q[k]['path'],q[k]['stdout_sha256'],q[k]['stderr_sha256']) ==
                 (forms[2][k]['path'],forms[2][k]['stdout_sha256'],forms[2][k]['stderr_sha256']) for k in q),
             'same-release original A behavior or paths changed')
    removed = pkg.products.phase_change(forms[2],forms[3],folder/'unchanged-A',folder/'first-B',pkg.PLAN)
    need(removed == ['tool_list::tool_list_outdated_respects_configured_index: test'], 'wrong real removed test')
    return {'stages':records, 'removed_tool_tests':removed, 'programs':17, 'test_lists':15,
            'A_repeat_raw_changes':[k for k in forms[1] if forms[1][k]['sha256'] != forms[2][k]['sha256']],
            'A_to_B_raw_changes':[k for k in forms[2] if forms[2][k]['sha256'] != forms[3][k]['sha256']],
            'statistical_rows':0, 'primary_family_credit':0}


def inside(release):
    folder, work = out(release), ram(release)
    subject, owned = read(folder/'subject.json'), read(folder/'ownership.json')
    env = o.environment()
    need(os.getuid() != 0 and set(os.sched_getaffinity(0)) == set(range(16))
         and not any(r.TARGET.iterdir()) and bank.identity(r.TARGET) == owned['target']
         and bank.identity(r.SRC) == owned['source'] and os.path.samefile(r.SDK,subject['sdk'])
         and os.statvfs(r.SDK).f_flag & os.ST_RDONLY and os.statvfs(o.VISIBLE/'cargo-home/registry').f_flag & os.ST_RDONLY
         and os.path.samefile(o.VISIBLE/'cargo-home/registry',o.OLD_HOME/'registry'), 'wrong fresh target, SDK, registry or machine')
    for rel in ('bin/rustc','bin/cargo',subject['driver']):
        need(bank.identity(r.SDK/rel) == subject['files'][rel]['device_inode'], 'namespace hides actual archive-verified member')
    root = subprocess.check_output([r.SDK/'bin/rustc','--print','sysroot'],env=env,cwd=r.SRC,text=True).strip()
    need(os.path.samefile(root,r.SDK),'rustc resolves a different sysroot')
    for tool in ('rustc','cargo'):
        (folder/(tool+'-vV.txt')).write_bytes(subprocess.check_output([r.SDK/'bin'/tool,'-vV'],cwd=r.SRC,env=env,stderr=subprocess.STDOUT))
    write(folder/'environment.json',env)
    write(folder/'input-producers.json',{})
    pkg.setup('warm',folder)
    original = m.state(TOOL,'A')
    file = r.SRC / original['path']
    raw, atime = file.read_bytes(), file.stat().st_atime_ns
    controls = {k:sha(r.SRC/k) for k in MANIFESTS}
    preserved = {}
    try:
        for stage in STAGES:
            form = 'B' if stage == 'first-B' else 'A'
            if form == 'B':
                edit = m.materialize_edit(TOOL,time.time_ns())
                diff = subprocess.check_output(['/usr/bin/git','-C',r.SRC,'diff','--numstat','--',original['path']],env=env,text=True)
                need(diff.split() == ['0','62',original['path']], 'did not make the genuine 62-line working-tree deletion')
                write(folder/'edit.json', {'states':edit,'numstat':diff,'manifests':controls})
            kind = 'unmeasured-apply' if stage == 'cold-A' else 'released-descriptive-'+stage
            cold = stage == 'cold-A'
            observer = o.Witness(r.SDK/'bin/rustc',r.SDK/subject['driver'],r.TARGET) if cold else contextlib.nullcontext()
            with observer as witness:
                cmd, unused = study.c.normal(folder/stage,TOOL,form,kind,subject)
            if cold:
                st = (r.SDK/subject['driver']).stat()
                driver_id = ([os.major(st.st_dev),os.minor(st.st_dev)],st.st_ino)
                matches = [w for w in witness.rows.values() if w['session'] == cmd['pid']
                           and w['exe_device_inode'] == subject['files']['bin/rustc']['device_inode']
                           and all((d['dev'],d['inode']) == driver_id for d in w['driver_mappings'])
                           and len(w['fds']) == 2 and len(set(w['fds'].values())) == 1
                           and next(iter(w['fds'].values())).startswith('pipe:[')]
                def own_tool(w):
                    argv = w['argv']
                    return '--crate-name' in argv and argv[argv.index('--crate-name')+1]=='tool' and '--test' in argv and 'crates/uv/tests/tool/main.rs' in argv
                chosen = [w for w in matches if own_tool(w)]
                need(chosen, 'excluded cold build lacks an actual jobserver/driver/tool-process observation')
                write(folder/'cold-mapped-tools.json',{'cargo_pid':cmd['pid'],'selected_tool':chosen,'other_matched_processes':len(matches)-len(chosen),
                      'probe':'passive cold-only samples. Timed unchanged-A and first-B have no process sampling.'})
            need({k:sha(r.SRC/k) for k in MANIFESTS} == controls, 'manifest or lock changed')
            if stage in ('unchanged-A','first-B'):
                inv = read(folder/stage/'all-products.json')
                preserved[stage] = {k:cas.keep(r.TARGET / x['path'],work/'programs',x,m.bounds) for k,x in inv.items()}
                write(folder/stage/'retained.json',preserved[stage])
        write(folder/'context.json',summarize(folder))
    finally:
        if file.read_bytes() != raw:
            file.write_bytes(raw)
        os.utime(file,ns=(atime,original['mtime_ns']))
        need(m.state(TOOL,'A') == original and controls == {k:sha(r.SRC/k) for k in MANIFESTS}, 'private source restoration failed')
        write(folder/'source-restored.json',{'source':original,'manifests':controls,'genuine_original_sha256':sha(file)})


def source_donor():
    known=read(m.cold/'owned.json')
    actual={'source':bank.identity(m.DONOR/'source'),'registry':bank.identity(o.OLD_HOME/'registry')}
    need(actual=={'source':known['template']['source'],'registry':known['shared_registry']},
         'different source donor or offline registry')
    return actual


def start(release,path,digest):
    verify()
    need(os.environ.get('OHM_DISTRIBUTED_PACKAGE_CONTEXT') == sha(REG), 'coordinator must explicitly select this descriptive study')
    folder,work = out(release),ram(release)
    host, previous = prior(path,digest)
    if release == '20':
        closed('18',out('18')/'outer-return.json',sha(out('18')/'outer-return.json'))
    with host.exclusively():
        prior(path,digest)
        need(Path('/proc/1/comm').read_text().strip() == 'systemd' and not r.native.foreign()
             and not folder.exists() and not work.exists(), 'physical, quiet, single-use release allocation required')
        os.sched_setaffinity(0,range(16))
        opening = m.bounds(13*G)
        donor = source_donor()
        folder.mkdir(mode=0o700)
        write(folder/'intake.json',{'pid':os.getpid(),'start_ns':time.time_ns(),'boot':previous['boot'],'outer':previous['outer'],
              'previous':str(path),'previous_sha256':digest,'locks':host.locks(),'registration':sha(REG),'opening':opening,'release':release})
        code,error,meter = 1,None,None
        try:
            with m.seed.RES.Meter(m.seed.available,m.FLOOR) as meter:
                subject = releases.verify(release)
                write(folder/'subject.json',subject)
                m.bounds(13*G)
                work.mkdir(mode=0o700)
                (work/'programs').mkdir(mode=0o700)
                slot = work/'working'
                slot.mkdir(mode=0o700)
                for n in ('home','tmp','target','cargo-home'):
                    (slot/n).mkdir()
                (slot/'cargo-home/registry').mkdir()
                source = bank.archive(m.DONOR/'source',slot/'source')
                record = {k:bank.identity(slot/k) for k in ('source','target','cargo-home','home','tmp')}
                write(folder/'ownership.json',{'slot':bank.identity(slot),**record,'source_transfer':source,
                      'immutable_registry':donor['registry'],'donor_source_only':donor['source'],
                      'incoming_target_entries':list((slot/'target').iterdir()),'raw_CAS':bank.identity(work/'programs')})
                cmd = m.ns(slot,subject['sdk'],folder)
                i = cmd.index('--')
                cmd[i:i] = ['--bind',str(work/'programs'),str(work/'programs')]
                cmd[-2:] = [str(HERE/'run.py'),'inside',release]
                write(folder/'namespace.json',cmd)
                with (folder/'worker.log').open('xb') as log:
                    subprocess.run(cmd,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
                need(read(folder/'context.json') == summarize(folder) and read(folder/'source-restored.json')['source']['form']=='A'
                     and source_donor() == donor,'failed release evidence, restoration or donor ownership')
                m.RAM = work
                study.erase(slot,read(folder/'ownership.json')['slot'],folder,'completed archive-verified distributed context with all 17 A/B ELFs independently recoverable')
                need(set(p.name for p in work.iterdir()) == {'programs'},'unexpected retained data')
                write(folder/'success.json',{'release':release,'context_sha256':sha(folder/'context.json'),
                      'registration':sha(REG),'subject_sha256':sha(folder/'subject.json'),'source_sha256':sha(folder/'source-restored.json'),
                      'retired_sha256':sha(folder/'retired.json'),'witness_sha256':sha(folder/'cold-mapped-tools.json'),'raw_program_store':str(work/'programs'),
                      'A_B_stores':{s:sha(folder/s/'retained.json') for s in STAGES[-2:]},'scored_rows':0})
                code = 0
        except BaseException as exc:
            code,error = 1,repr(exc)
            raise
        finally:
            write(folder/'worker-return.json',{'code':code,'worker_exit':code,'end_ns':time.time_ns(),'locks':host.locks(),
                  'success':sha(folder/'success.json') if code==0 else None,'exception':error,
                  'capacity':meter.result() if meter else None,'scored_rows':0})


def replay(release, deep=False):
    folder = out(release)
    closed(release,folder/'outer-return.json',sha(folder/'outer-return.json'))
    result = summarize(folder)
    need(result == read(folder/'context.json'), 'raw context replay differs')
    for k in STAGES[-2:]:
        inventory = read(folder/k/'all-products.json')
        proof = read(folder/k/'retained.json')
        need(proof.keys() == inventory.keys(), 'missing retained program')
        for role,p in proof.items():
            need((p['raw_sha256'],p['raw_bytes']) == (inventory[role]['sha256'],inventory[role]['bytes']), 'different retained product')
            if deep:
                blob = ram(release)/'programs'/(p['raw_sha256']+'.zst')
                need(blob.stat().st_size == p['compressed_bytes'] and sha(blob) == p['compressed_sha256']
                     and cas.unpacked_sha(blob) == p['raw_sha256'],'compressed product does not reconstruct')
    return result


def compare():
    results = {k:replay(k) for k in releases.PIN}
    for stage in STAGES[-2:]:
        roles=[]
        for k in releases.PIN:
            products=read(out(k)/stage/'all-products.json')
            roles.append({n:(s['stdout_sha256'],s['stderr_sha256']) for n,s in products.items()})
        need(roles[0] == roles[1],'released binaries have different observable CLI behavior or test inventories')
    return {'actual_seconds':{s:{k:results[k]['stages'][s]['nanoseconds']/1e9 for k in results} for s in STAGES[-2:]},
            'interpretation':'One first edit per complete shipped version. Independent cold targets, no within-release replication or confidence interval.'}


def closed(release,path,digest):
    verify()
    folder=out(release)
    need(path == folder/'outer-return.json','wrong released context')
    host,outer=v.local_receipt(folder,digest)
    s=read(folder/'success.json')
    need(read(folder/'worker-return.json')['success']==sha(folder/'success.json') and s['release']==release and
         s['context_sha256']==sha(folder/'context.json') and s['subject_sha256']==sha(folder/'subject.json') and
         s['registration']==sha(REG) and s['retired_sha256']==sha(folder/'retired.json') and
         s['source_sha256']==sha(folder/'source-restored.json') and s['scored_rows']==0 and
         s['witness_sha256']==sha(folder/'cold-mapped-tools.json') and
         all(s['A_B_stores'][k]==sha(folder/k/'retained.json') for k in STAGES[-2:]),'unverified released return')
    return host,outer


if __name__=='__main__':
    a=sys.argv[1:]
    if a==['verify']: print(sha(REG) if verify() else 'unreachable')
    elif a==['compare']: print(json.dumps(compare(),indent=2))
    elif a[:1]==['replay'] and (len(a)==2 or len(a)==3 and a[2]=='--raw'): print(json.dumps(replay(a[1],len(a)==3)))
    elif len(a)==2 and a[0]=='inside': inside(a[1])
    elif len(a)==4 and a[0]=='start': start(a[1],Path(a[2]).resolve(),a[3])
    elif len(a)==5 and a[0]=='close': v.code(v.UP.parent/'physical.py','distributed_package_close').close(out(a[1]),*a[2:])
    elif len(a)==4 and a[0]=='closed': print(json.dumps(closed(a[1],Path(a[2]).resolve(),a[3])[1]))
    else: raise SystemExit('verify | start 18|20 PREV SHA | close 18|20 SESSION CHUNK EXIT | closed 18|20 OWN_OUTER SHA')
