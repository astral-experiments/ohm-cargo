# First test build after editing uv on released Ohm

Run the downloaded packet with Python 3.11 or newer.

```sh
python3 -ISB ohm-18-20-uv-release-context.zip
```

Each shipped Linux SDK built the entire uv package from an empty target, warmed it twice, and ran the first ordinary `cargo test --locked --offline -j8 -p uv --no-run` after a 62-line integration-test deletion. One first edit per release supplies context for the separately replicated comparisons of Rust compiler patches.

The packet contains the original command clocks, source and SDK identities, Cargo logs, observable outputs of all 17 programs, and raw-file hash ledgers. The verifier compares all 15 test listings and both CLI version outputs between releases. Only the cold build used passive process sampling. All supplied measurements include the full Cargo process. The release archives and generated executable bytes are retained separately on the benchmark host.
