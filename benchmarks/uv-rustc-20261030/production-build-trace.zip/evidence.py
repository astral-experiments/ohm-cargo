"""Stream the genuine GNU archive and retain a role census directly from every successful exec."""
from pathlib import Path
import hashlib,json,re,struct
NONCE=re.compile(rb'(uv-[a-f0-9]{16}\.[a-z0-9]+\.)([a-z0-9]{7})(\.rcgu\.o)')
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(q,why):
    if not q:raise ValueError(why)
def archive(path):
    names=b'';members=[];whole=hashlib.sha256()
    with path.open('rb') as f:
        magic=f.read(8);need(magic==b'!<arch>\n','not GNU ar');whole.update(magic)
        while head:=f.read(60):
            need(len(head)==60 and head[58:]==b'`\n','invalid ar header');whole.update(head)
            size=int(head[48:58]);short=head[:16].rstrip();pos=f.tell();full=short.rstrip(b'/')
            if re.fullmatch(rb'/\d+',short):
                i=int(short[1:]);need(0<=i<len(names) and (i==0 or names[i-1:i]==b'\n'),'bad ar long name')
                j=names.index(b'/\n',i);full=names[i:j]
            elif short in (b'/',b'//'):full=short
            digest=hashlib.sha256();remaining=size;small=b'' if short in (b'//',b'lib.rmeta-link/') and size<4<<20 else None
            while remaining:
                data=f.read(min(remaining,1<<20));need(data,'short ar member');digest.update(data);whole.update(data);remaining-=len(data)
                if small is not None:small+=data
            pad=f.read(size%2);need(len(pad)==size%2,'short ar pad');whole.update(pad)
            if short==b'//':need(small is not None,'long names too large');names=small
            item={'index':len(members),'offset':pos,'name':full.decode(),'normalized_name':NONCE.sub(rb'\g<1>0000000\g<3>',full).decode(),
                  'header':head.hex(),'pad':pad.hex(),'bytes':size,'sha256':digest.hexdigest()}
            if small is not None:item['nonce_only_sha256']=sha(NONCE.sub(rb'\g<1>0000000\g<3>',small))
            members.append(item)
    return {'raw_sha256':whole.hexdigest(),'members':members}
def compare(x,y):
    u=x['members'];v=y['members']
    need(len(u)==len(v),'different member count')
    objs=[i for i,k in enumerate(u) if k['name'].endswith('.rcgu.o')]
    return {'members':len(u),'native_CGU_members':len(objs),'raw_identical_CGU_bodies':sum(u[i]['sha256']==v[i]['sha256'] for i in objs),
            'differing_raw_headers':[i for i in range(len(u)) if u[i]['header']!=v[i]['header']],
            'differing_name_after_fixed_nonce':[i for i in range(len(u)) if u[i]['normalized_name']!=v[i]['normalized_name']],
            'differing_padding':[i for i in range(len(u)) if u[i]['pad']!=v[i]['pad']],
            'differing_bodies':[{'index':i,'C_name':l['name'],'CZD_name':r['name'],'C_sha256':l['sha256'],'CZD_sha256':r['sha256'],
                                  'same_after_registered_nonce':l.get('nonce_only_sha256') is not None and l.get('nonce_only_sha256')==r.get('nonce_only_sha256')}
                                 for i,(l,r) in enumerate(zip(u,v,strict=True)) if l['sha256']!=r['sha256']]}
def census(index,cmd):
    events=index['events'];root=[p for p,_,e,a in events if e==a[0] and a==cmd]
    need(len(root)==1,'missing true ordinary command');root=root[0];parents={c:p for c,p,_ in index['forks']}
    sdk=Path(cmd[0]).parent;counts={};calls=[]
    for pid,line,exe,argv in events:
        chain=[pid]
        while chain[-1]!=root:
            p=parents[chain[-1]];need(p not in chain,'fork cycle');chain.append(p)
        name=Path(exe).name;counts[name]=1+counts.get(name,0)
        role={'pid':pid,'exe':exe,'argv_sha256':sha(json.dumps(argv,separators=(',',':')).encode()),'ancestry':chain,'line':line}
        if exe==str(sdk/'rustc'):
            role.update(crate=None if '--crate-name' not in argv else argv[argv.index('--crate-name')+1],
                        kind=None if '--crate-type' not in argv else argv[argv.index('--crate-type')+1],
                        rust_inputs=[x for x in argv if x.endswith(('.rs','.rlink'))],emit=[x for x in argv if x.startswith('--emit=')])
        calls.append(role)
    return {'counts_by_basename':counts,'calls':calls,'raw_trace_files':index['raw_trace_files'],'raw_trace_bytes':index['raw_trace_bytes'],
            'filenames_sha256_inventory':index['raw_filename_sha256_inventory']}
