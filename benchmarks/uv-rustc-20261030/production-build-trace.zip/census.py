"""Read each per-TID exec trace once. Preserve every successful executable argv and every SIGCHLD edge."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import re


def index(traces):
    events = []
    parents = []
    forks = []
    cwd = []
    hashes = {}
    sizes = 0
    count = 0
    decoder = json.JSONDecoder()
    for trace in sorted(traces.glob("exec.*")):
        pid = int(trace.suffix[1:])
        data = trace.read_bytes()
        hashes[trace.name] = hashlib.sha256(data).hexdigest()
        sizes += len(data)
        count += 1
        for number, line in enumerate(data.decode().splitlines(), 1):
            if re.match(r"^(?:clone3?|fork|vfork)\(|^<\.\.\. (?:clone3?|fork|vfork) resumed>", line):
                child = re.search(r" = (\d+)\s*$", line)
                if child and int(child[1]) > 0:
                    forks.append([int(child[1]),pid,number])
            elif line.startswith("chdir(") and line.rstrip().endswith("= 0"):
                path, _ = decoder.raw_decode(line[6:])
                cwd.append([pid,number,path])
            elif line.startswith("fchdir(") and line.rstrip().endswith("= 0"):
                path = re.match(r"fchdir\(\d+<([^>]+)>\)",line)
                if not path or not path[1].startswith("/"):
                    raise ValueError("cannot decode successful cold fchdir "+str(trace))
                cwd.append([pid,number,path[1]])
            elif line.startswith("--- SIGCHLD "):
                match = re.search(r"si_pid=(\d+)", line)
                if match:
                    parents.append([int(match[1]),pid])
            elif line.startswith("execveat(") and line.rstrip().endswith("= 0"):
                raise ValueError("unclassified successful execveat in "+str(trace))
            elif line.startswith("execve(") and line.rstrip().endswith("= 0"):
                exe, offset = decoder.raw_decode(line[7:])
                argv, _ = decoder.raw_decode(line[7+offset+2:])
                events.append([pid,number,exe,argv])
    if not events:
        raise ValueError("empty execution evidence")
    hashes_sha = hashlib.sha256(json.dumps(hashes, sort_keys=True,separators=(",",":")).encode()).hexdigest()
    return {"events":events,"parents":parents,"forks":forks,"cwd":cwd,"source":str(traces),"raw_trace_files":count,
            "raw_trace_bytes":sizes,"raw_filename_sha256_inventory":hashes_sha}


def main():
    here=Path(__file__).resolve().parent
    p=here.parent/'heldout-test-v2'
    h=Path(json.loads((p/'registration.json').read_bytes())['state'])
    f=here.parents[3]/'green-promotion/trial/physical/instructions-homebrew/cold'
    for name,path in [('q2-stock-build',h/'commands/stock-cold/H1/build'),('f2-cold-base',f/'base'),('f2-cold-candidate',f/'candidate')]:
        wanted=here/'inputs'/(name+'.json.gz')
        if wanted.exists():continue
        d=index(path)
        payload=gzip.compress(json.dumps(d,separators=(',',':')).encode(),compresslevel=2,mtime=0)
        wanted.write_bytes(payload)
        print(name,d['raw_trace_files'],d['raw_trace_bytes'],len(d['events']),len(payload),flush=True)


if __name__=='__main__':main()
