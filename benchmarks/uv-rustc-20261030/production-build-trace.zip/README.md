# Descriptive production edit after ordinary build preparation failed

Unzip this file, run `sha256sum -c SHA256SUMS`, then run `python3 -ISB replay.py > replay.json` and compare with `fanout.json`.

Both original warm Cargo histories failed their predeclared cross-compiler raw-public-output gate, with no pilot or timed pairs admitted. This separate operation performed one real first production settings edit per compiler, without drawing a timing comparison. The executable versions and raw product identities, complete per-process successful exec and Cargo logs, and original streamed library archive member ledgers are included. The full original histories and all actual first-edit program bytes are separately retained on the benchmark guest. The compact packet can independently replay the ledgers and raw process traces. It does not contain the original archive payloads or claim all metadata fields are semantically equivalent.
