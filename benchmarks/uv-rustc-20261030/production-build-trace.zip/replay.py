"""Offline replay. No compiler, registry, devbox filesystem or benchmark timing access."""
import hashlib,importlib.util,json,re,sys
from pathlib import Path
H=Path(__file__).resolve().parent
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def load(name):
    s=importlib.util.spec_from_file_location(name,H/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def need(v,msg):
    if not v:raise ValueError(msg)
def report(root):
    e=load('evidence');c=load('census');out=root/'physical';orig=root/'original';f=read(orig/'outer-return.json');z=read(out/'outer-return.json');w=read(out/'preserved.json')
    need(SHA(orig/'outer-return.json')=='3540770d8b3273343083553920a184ea95bc687eb3b3a65ff0eb5578648b0c8c' and f['outer']=={'session':88540,'chunk':'e8bec9','exit':1} and z['outer']['exit']==0
         and read(out/'intake.json')['previous_sha256']==SHA(orig/'outer-return.json') and read(out/'worker-return.json')['preserved_sha256']==SHA(out/'preserved.json')
         and w['timing_comparison'] is False and w['both_original_p']==1 and w['scored_pairs']==0,'wrong physical disposition or excluded cohort')
    need(SHA(orig/'source-A.rs')!=SHA(orig/'source-B.rs'),'identical edit')
    arms={};old=[]
    for a in ('C','CZD'):
        d=out/('diagnostic-'+a);b=d/'B';q=read(b/'command.json');warm=read(orig/('warm-'+a)/'products.json');ledger=w['diagnostics'][a]
        for filename in ('incoming.json','subject.json','namespace.json','A-rlib-members.json','B/command.json','B/products.json','B/native-census.json','retained.json','retired.json'):
            need(SHA(d/filename)==ledger[filename],'different diagnostic '+filename)
        need(q['exit']==0 and q['traced'] and q['argv'][1:]==['build','--locked','--offline','-j8','-p','uv'] and q['actual_argv'][-7:]==q['argv']
             and SHA(b/'cargo.stdout')==q['stdout_sha256'] and SHA(b/'cargo.stderr')==q['stderr_sha256'],'not the original ordinary build')
        for stage,rec in [('A',q['before_source']),('B',q['source'])]:
            need(rec['oid']=='c22e6b71933443e9cd299d4b6ac8de035ed4825b' and rec['form']==stage and rec['path']=='crates/uv/src/settings.rs'
                 and rec['sha256']==SHA(orig/('source-'+stage+'.rs')),'changed production edit')
        idx=c.index(b);proof=e.census(idx,q['argv']);record=read(b/'native-census.json');need(all(v==record[k] for k,v in proof.items()),'different successful executions')
        before=read(b/'stamps-before.json');after=read(b/'stamps-after.json');changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
        packages=sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',(b/'cargo.stderr').read_text(),re.M))
        need(changed==q['changed_stamps']==record['changed_stamps'] and packages==q['packages']==record['Cargo_messages'],'wrong Cargo evidence')
        inc=read(d/'incoming.json');need(inc['identity']==read(d/'retired.json')['identity'] and inc['source_archive_sha256']==w['original_archives'][a]['sha256'],'incorrect private restore')
        A=read(d/'A-rlib-members.json');old.append(A);product=read(b/'products.json');kept=read(d/'retained.json')
        need(A['raw_sha256']==warm['extra']['rlib']['raw']['sha256'] and len(A['members'])==260 and len(kept)==4,'incorrect archive reference')
        rows={**product['files'],'archive':product['extra']['rlib']['raw']}
        need(set(rows)==set(kept) and all(row['sha256']==kept[k]['raw_sha256'] and row['bytes']==kept[k]['raw_bytes'] for k,row in rows.items()),'different retained B products')
        for n in ('uv-version','uvx-version','uv-self-version'):
            need(not (b/(n+'.stderr')).read_bytes(),'CLI diagnostic')
        need((b/'uv-version.stdout').read_text().strip()==product['behavior']['uv'] and (b/'uvx-version.stdout').read_text().strip()==product['behavior']['uvx']
             and read(b/'uv-self-version.stdout')==product['behavior']['detail'],'different CLI version')
        arms[a]={'argv':q['argv'],'first_edit_package_messages':packages,'changed_Cargo_unit_stamps':changed,'total_fingerprint_stamps':[len(before),len(after)],
                 'first_edit_successful_execs':proof['counts_by_basename'],'compiler_calls':[x for x in proof['calls'] if 'crate' in x],
                 'raw_trace_files':proof['raw_trace_files'],'raw_trace_bytes':proof['raw_trace_bytes'],
                 'raw_trace_digests_sha256':proof['filenames_sha256_inventory'],'raw_public_products':rows,'behavior':product['behavior'],
                 'A_library_sha256':A['raw_sha256'],'A_standalone_metadata':warm['files']['libuv'],'driver_sha256':q['driver_sha256']}
    comparison=e.compare(*old);need(comparison==w['archive_comparison'],'changed original archive-member ledger')
    return {'ordinary_build_failure':f['outer'],'descriptive_material_return':z['outer'],'original_scored_pairs':0,'original_p':1,'timings_compared':False,
            'A_semantic_equality_asserted':False,'native_members_and_libraries':comparison,'descriptive_first_edit':arms}
if __name__=='__main__':print(json.dumps(report(Path(sys.argv[1]) if len(sys.argv)>1 else H),sort_keys=True,indent=2))
