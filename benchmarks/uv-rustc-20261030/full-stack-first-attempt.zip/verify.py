"""Reconstitute a compact returned P/CZD packet and rerun its original scientific reader."""
import argparse
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile
from unittest.mock import patch
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
F = 'package-test-full-stack'
SCOPE = 'P-to-CZD/package-test'
PUBLIC_PREVIOUS = 'cdd67c8caa1924d569577f989994c0f9612bc206ff040524dfc42a286ab3d5ff'
HEX = re.compile(r'[0-9a-f]{64}')
LIMIT = 320 << 20
BASE = {
    'trace-reader.py':'e7e4fa643971c671836067288221c7f78301a01e610bb469bdc3a2847241f1a5',
    'elf-tools/geometry.py':'058d14a228edf54dc43d1cee31fc0291a4d8327306edfdc610e5d7242840435f',
    'elf-tools/retain.py':'6d139e099791f0e9733bfe31729bd6509d15808aeb504cf573fa411a9d9ed5cb',
    'elf-tools/recover_forms.py':'97a85c095fb5f3a11ede523dd87e028e9e60fabd3ab2210b3e5d216e8decaa87',
    'package-test/products.py':'c944170557005488b70753c5200c9b3d589bf8adc8c423b87396a49c159f8a65',
    'package-test/original-score.py':'376a2dfb658cd1f087e1d96f46ea370077d37cc02fa51b135e8223d0c5e879f5',
    'package-test-v3/forms.py':'0ffaff84ae614d5a9706c03044e1a2439f9d9b2033e21e5bae7bcff552d0b39e',
    'package-test-v3/replay.py':'1f0773337251a96d74034cd6874569a0bec3c9767f6c8d873ff46c2e89e8cdc7',
    'elf_replay.py':'7458dcb10931757a71f54536f3de95b67cba13c89f5d26a37411ac1e9676e7bd'
}
OWN = {
    'protocol.json':'c545177f4e5e2fb4284ce034187fa5d8b4619154a3d659f57fbdf2a589112cd1',
    'registration.json':'d9791f9e9fe4995725327c143032e699ac38e30913d7a50df8e6e4f5eae3d988',
    'run.py':'75700f135feb5d7c5bf564833a85f9a93390e51982b42dc998b124f5e391351b',
    'replay.py':'3ce662996efa335eebcf13eeee2af8e6184b7e559f3059ac11ad96eca8a9b340',
    'evidence.py':'348ad01133d9b3d01f797f27210633fa85f74e405a3b15125d098c8741b96a48',
    'worker.py':'adcfb417775c8d471bc387611c039b4958104cc8c3827539d33a0b65aa89ff8f',
    'previous.py':'80eebd2eb9bf4dacf8d90db0de0ca5427290a28731aa24ee8d2877fc5ed2e3aa',
    'after-check-prepare/run.py':'d9172ab72e30d5ad73108dfed58ddd774aed607b2717194c79be959b34449741',
    'after-check-prepare/registration.json':'88bdb51bb454dca9bf52f112f0712a8b5fc9ca9587e384694faefac6266d293f',
    'after-check-prepare/earlier_effects.py':'d92245ec7a2739efe004a1eda99331b6ad424af7e9c563e31dbda97367da6a20'
}
HOST={
 'registration.json':'cc4006bc3add86c1d5baf1e72263a9ba36ee9715453bb936cc48850695bb38fe',
 'full.py':'f15afd74b6515bdc6a0ccc3439c8fbeb1c2124bd67a766a75c1ce9a4ecc53b70',
 'earlier_effects.py':'7d6f1e2ae4c4ccf5644c9356eb394bc67ed830b49bc3c11f1f2a915726cd04b6',
 'custody_88540.py':'8f7b14819ffb9ba3093018df4b5530fded29f0f8a2f11b000627e0207a6b8289'
}
PINS = {**BASE, **{'after-ordinary-failures/'+n:v for n,v in HOST.items()}, **{F+'/'+n:v for n,v in OWN.items()}}

def need(ok, message):
    if not ok: raise ValueError(message)

def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def digest(b):return hashlib.sha256(b).hexdigest()
def data(p):return json.loads(p.read_bytes())
def encoded(obj):return (json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
def module(p,n):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def outer(raw,expected):
    p=raw/'outer-return.json';o=data(p);w=data(raw/'worker-return.json');i=data(raw/'intake.json');t=o['outer']
    need(HEX.fullmatch(expected) and sha(p)==expected and o['worker_sha256']==sha(raw/'worker-return.json') and o['intake_sha256']==sha(raw/'intake.json'),'wrong detached physical custody')
    need(set(t)=={'session','chunk','exit'} and type(t['session'])==int and t['session']>0 and re.fullmatch('[0-9a-f]{6}',t['chunk']) and t['exit']==o['worker_code']==w['code']==w['worker_exit'],'inconsistent actual supervisor and worker')
    need(o['host_released'] is True and o['foreign']==o['remaining_workers']==w['owned_children_at_return']==[] and i['boot']==o['boot'] and o['locks']==i['locks']==w['locks'] and len(set(o['locks']))==2 and i['start_ns']<w['end_ns'],'host or worker not closed')
    need(i['registration']==OWN['registration.json'] and i['host_after_check_registration_sha256']==HOST['registration.json'],'different registered full-stack intake')
    return t,w

def safe(s):
    p=PurePosixPath(s);need(not p.is_absolute() and p.as_posix()==s and all(x not in ('','.','..') for x in p.parts) and '\\' not in s and '\0' not in s,'unsafe packet path');return p

def unpack(zip_path,root,reserve):
    with ZipFile(zip_path) as z:
        names=z.namelist();need(len(names)==len(set(names)) and 0<len(names)<30000,'duplicate or excessive ZIP entries')
        info=z.getinfo('layout.json');need(info.file_size<=8<<20,'oversize directory');layout=json.loads(z.read(info))
        need(layout['schema']==1 and layout['scope']==SCOPE,'wrong detached result scope')
        shared=set(layout['files'].values());need(all(HEX.fullmatch(x) for x in shared) and set(names)=={'layout.json','verify.py','README.md'}|{'objects/'+x for x in shared},'unbound archive entries')
        volume=sum(z.getinfo('objects/'+h).file_size for h in shared)
        need(volume<=LIMIT and shutil.disk_usage(root).free>=reserve+volume+(8<<20),'extract would exceed filesystem guard')
        blobs=root/'.objects';blobs.mkdir()
        for h in shared:
            i=z.getinfo('objects/'+h);need(i.file_size<=128<<20,'oversize object')
            b=z.read(i);need(digest(b)==h,'corrupt packet object');(blobs/h).write_bytes(b)
        for name,h in layout['files'].items():
            p=safe(name);need(p.parts and p.parts[0] in ('sources','physical','owner','previous'),'unexpected evidence path')
            if p.parts[0]=='sources':need('/'.join(p.parts[1:]) in PINS,'unregistered executable source')
            dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);os.link(blobs/h,dest)
        need(all(sha(root/'sources'/n)==h for n,h in PINS.items()),'registered source differs')

def readers(src):
    tools=module(src/'elf_replay.py','prior_verified_elf');forms=tools.scorer(src,src)
    with tools.relocated({src/'package-test-v3/forms.py':forms}):engine=module(src/'package-test-v3/replay.py','prior_exact_engine')
    with tools.relocated({src/'package-test-v3/replay.py':engine}):ev=module(src/F/'evidence.py','fresh_stack_evidence')
    with patch.dict(sys.modules,{'evidence':ev}):sc=module(src/F/'replay.py','fresh_stack_score')
    return tools,ev,sc

def inventories(raw,phase_rows,reference):
    files={};digests={};alt=set()
    for name,(row,receipt) in phase_rows.items():
        items=data(row/'all-products.json');held=data(receipt);need(set(items)==set(held)==set(reference['roles']),'incomplete program inventory')
        for role,item in items.items():
            record=held[role];h=record['raw_sha256']
            need(item['sha256']==h and item['bytes']==record['raw_bytes'] and 0<record['compressed_bytes']<=record['raw_bytes']+(1<<20) and HEX.fullmatch(record['compressed_sha256']) and (h not in files or files[h]==record),'conflicting program bytes')
            files[h]=record
            allowed=reference['roles'][role]['class'];need(h in allowed['allowed'],'unregistered phase or role binary')
            if h!=allowed['observed']:alt.add(role)
        digests[name]={'products_sha256':sha(row/'all-products.json'),'custody_sha256':sha(receipt)}
    return files,digests,alt

def science(src,raw,scratch,cas=None):
    tools,e,sc=readers(src);e.bind(raw,cas=cas);doc=data(raw/'series.json');index=data(raw/'cas-index.json')
    byphase={'A':{},'B':{}}
    for arm in sc.ARMS:
        warm=raw/('warm-'+arm)
        for tag,receipt in [('ordinary-repeat-A',warm/'ordinary-repeat-A/pre-trace-retained.json'),('verify-repeat-A',warm/'retained-products.json')]:byphase['A']['/'.join(('A',arm,tag))]=(warm/tag,receipt)
        b=raw/('admission-'+arm);byphase['B']['B/'+arm+'/admission']=(b/'B',b/'retained-products.json')
    for row in doc['pairs']:
        for arm,folder in zip(row['order'],row['dirs'],strict=True):
            p=raw/safe(folder);byphase['B']['B/'+arm+'/'+folder]=(p/'B',p/'retained-products.json')
    allfiles={};allmanifests={};summary={}
    for phase in ('A','B'):
        ref=e.reference(raw,phase,deep=False);need(index['baseline_'+phase]==sha(e.ref_path(raw,phase)),'substituted P reference')
        blobs,manifests,alternate=inventories(raw,byphase[phase],ref);need(all(h not in allfiles or allfiles[h]==rec for h,rec in blobs.items()),'conflicting phase payloads')
        allfiles.update(blobs);allmanifests.update(manifests)
        folder=raw/('form-proofs-'+phase);required={}
        for role in alternate:
            left,right=ref['roles'][role]['class']['allowed'];key=digest((phase+':'+role+':'+left+':'+right).encode());required[key+'.json']=role
        actual={p.name:sha(p) for p in folder.glob('*.json')};need(set(actual)==set(required) and actual==index['proofs'][phase],'extra or missing phase-specific reciprocal proof')
        neutral=scratch/phase/('form-proofs-A' if phase=='A' else 'form-proofs');neutral.mkdir(parents=True)
        for name,role in required.items():
            p=folder/name;q=data(p);a,b=ref['roles'][role]['class']['allowed'];need(q['role']==role and q['allowed_from_P']==[a,b],'wrong P-derived raw pair')
            if phase=='B':q['allowed_from_C']=q.pop('allowed_from_P')
            (neutral/(digest((role+':'+a+':'+b).encode())+'.json')).write_bytes(encoded(q))
            if cas is None:e.f.CHECKED[name[:-5]]=actual[name]
        tools.validate_saved(ref,neutral)
        summary[phase]={'roles':len(ref['roles']),'independent_arm':ref['independent_arm'],'reference_sha256':sha(e.ref_path(raw,phase)),'observed_unequal_roles':sorted(alternate),'proofs':actual}
    need(index['inventories']==allmanifests and index['files']==allfiles,'unbound CAS paths, files or inventory')
    if cas is not None:
        cas=Path(cas).resolve(strict=True)
        for v in allfiles.values():
            with tools.raw_file(cas,v,scratch):pass
    result=sc.replay(raw,deep_refs=cas is not None)
    need(result==data(raw/'analysis.json'),'original score disagrees with recorded analysis')
    return result,summary,sc

KNOWN_PRIOR={'CZD/tool-test':'7ff606beaa1baa3f72468bae2a7fc80fb2765cafbc54153352d2960011bcba9a','CZD/package-test-v3':'edfac39132b05b2b6754e7b2c5db25d52b6a041d4985c3b7a27f79596d92e05c'}
PERMANENT={
 'CZD/package-test':('package-test','54b63c7d83d84974a20bf7ba4cfde2b1b364d32cc16e81b8f68f3301e5b0ee8b',97456,'fc736b'),
 'CZD/package-test-v2':('package-test-v2','ddc11138b5c17e8eb8cb30554a10da47c7fb1821adec899a1c68ee99086c4617',34398,'7c4fc4'),
 'P-to-ZD/package-test':('package-test-v3-direct-leaf','c8f52faa2c38d9b11c0e14b046bf3e00459054dc738a601eecd20b5e575fa232',82625,'95d3a3')}
FAILED_ORDINARY={
 'build':{'outer':{'session':88540,'chunk':'e8bec9','exit':1},'sha256':'3540770d8b3273343083553920a184ea95bc687eb3b3a65ff0eb5578648b0c8c','scored_pairs':0,'decision_p':1},
 'check':{'outer':{'session':50690,'chunk':'04ad48','exit':1},'sha256':'4d8861b69b0998d69b4e02bffa7061893a7454ba55250f2f63f853464d34572b','scored_pairs':0,'decision_p':1}}
PUBLIC_INPUTS={
 'official/P-sdk.json':'2d574fd292b5b43b5332d40a8d145071445269a49652a30546db738b71cbabc7',
 'official/CZD-sdk.json':'4a63a75e64f0616601dd1b638d211e76ea980b802b22461593fd2ac097e4687b',
 'official/outer-return.json':'4739f51674f00a55ef7c1597ee0f125bccff62b6a447deacb8b85c51e446999b',
 'official/qualified.json':'1c44e8d91f45ceeae8ea8a8b7d046aa26dd80ec3694fb3eb6da719f2a1c3a826',
 'official/run-make-P.json':'fb14f42ceba3f73d8a6e7d44e597c8b7355dc8d64720b2cbca1624bab202764d',
 'official/run-make-CZD.json':'f6582cbee9697e241bf678aa1bbb266cf9c47668a5c0448e6506858d907eb36d',
 'edit/source-A.rs':'ea45d04a0fd3147952ca4fdca1142fe7f1b6781c2d697784fe306a27d3f32384',
 'edit/source-B.rs':'f27a6371bb2dbf93fee95958a21325798e7283eae9d8cbc8e686fb5f8ba8cd28'
}

def public_inputs(root):
    source=root/'sources'/F/'protocol.json';plan=data(source);base=root/'previous/public'
    need(all(sha(base/n)==h for n,h in PUBLIC_INPUTS.items()),'missing immutable SDK, official fixture or real source')
    stems={}
    for arm in ('P','CZD'):
        desc=plan['subjects']['manifests'][arm];manifest=data(base/'official'/(arm+'-sdk.json'));fixture=data(base/'official'/('run-make-'+arm+'.json'))
        files=manifest['files'];driver=manifest['driver'];need(len(files)==65 and files[driver]==desc['driver_sha256']==fixture['driver_sha256'] and files['bin/cargo']==desc['cargo_sha256'] and files['bin/rustc']==desc['launcher_sha256'] and fixture['exit']==0 and sha(base/'official'/(arm+'-sdk.json'))==desc['ready_sha256'],'selected SDK and native official fixture differ')
        stems[arm]={n:h for n,h in files.items() if n!=driver}
    need(stems['P']==stems['CZD'] and len(stems['P'])==64,'more than the source-matched driver differs')
    for phase in ('A','B'):
        b=(base/'edit'/('source-'+phase+'.rs')).read_bytes()
        need(hashlib.sha1(('blob '+str(len(b))).encode()+bytes(1)+b).hexdigest()==plan['uv']['edit'][phase],'different actual uv source change')

def older_outer(p,h,exitcode,trip=None):
    o=data(p/'outer-return.json');w=data(p/'worker-return.json')
    need(sha(p/'outer-return.json')==h and o['outer']['exit']==exitcode and (trip is None or o['outer']==trip) and o['worker_sha256']==sha(p/'worker-return.json') and o['intake_sha256']==sha(p/'intake.json') and o['host_released'] and not o['remaining_workers'] and not o['foreign'] and w['worker_exit']==exitcode,'changed historical resource closure')
    return w
def older_result(root,prior):
    scope=root/'previous';closures=prior['actual_outers'];known=KNOWN_PRIOR
    need(all(closures.get(k)==h for k,h in known.items()) and not ({'CZD/check','CZD/build',SCOPE}|set(PERMANENT))&set(closures),'missing known finished endpoint or new work attributed to a failure')
    out={}
    for k,h in closures.items():
        need(k in ('CZ/tool-test','CZ/settings','CZD/tool-test','CZD/settings','CZD/package-test-v3','P-to-ZD/tool-test'),'unrecognized earlier eligibility')
        p=scope/k.replace('/','--');w=older_outer(p,h,0);s=data(p/'successful.json')
        need(w['success']==sha(p/'successful.json'),'changed earlier signed result')
        if k=='CZD/package-test-v3':
            need(s['scorer_sha256']==sha(p/'analysis.json'),'changed historical matched package score')
            out[k]=data(p/'analysis.json')['score']
        else:
            label='physical-pairs' if k=='P-to-ZD/tool-test' else 'physical-pairs-'+k.replace('/','-')
            if label in s['outcome']['results']:out[k]=s['outcome']['results'][label]
    need(out==prior['original_effects'] and prior['failed_ordinary_prepares']==FAILED_ORDINARY,'previous scores do not originate from their own genuine signed closures')
    for k,(name,h,session,chunk) in PERMANENT.items():older_outer(scope/k.replace('/','--'),h,1,{'session':session,'chunk':chunk,'exit':1})
    for mode,r in FAILED_ORDINARY.items():older_outer(scope/('CZD--'+mode),r['sha256'],1,r['outer'])
    return out

def actual_native(raw,src):
    inputs=data(raw/'subjects.json')['subjects'];native=raw/'native'
    observed=data(native/'subjects.json');confirmed=data(native/'verified.json');ret=data(raw/'retired.json')
    need(observed=={'subjects':{'parent':inputs['P'],'candidate':inputs['CZD']},'registered':OWN['registration.json']} and confirmed['timed'] is False and confirmed['code']==0 and confirmed['subjects_sha256']==sha(native/'subjects.json') and ret['native_controls_sha256']==sha(native/'verified.json'),'unbound compiler or native input checks')
    reader=module(src/'trace-reader.py','raw_process_decoder');observations={}
    for leg,arm in [('parent','P'),('candidate','CZD')]:
        q=native/leg/'cargo-native/evidence/rows.json';rows=data(q)
        need([b['exit']==0 for b in rows]==[True,True,True,False,False,False,True] and [b['printed'] for b in rows if b['exit']==0]==['273\\n','285\\n','541\\n','529\\n'] and confirmed['results'][leg]['normal_cargo_sha256']==sha(q),'invalid changed/missing/malformed assembly or normal cargo controls')
        observations[arm]=actual_trace(raw/('admission-'+arm)/'B',reader)
    return observations

def actual_trace(b,reader):
    doc=data(b/'census.json');roles=data(b/'roles.json');mapping=data(b/'mapped-driver.json');seen=reader.index(b)
    need(doc['source_inventory']==seen['raw_filename_sha256_inventory'],'substituted original raw exec trace')
    events={(pid,exe,tuple(argv)) for pid,_,exe,argv in seen['events']};recorded=doc['actual']
    need(all((r['pid'],r['exe'],tuple(r['argv'])) in events for r in recorded),'actual PID, full argv or executable differs')
    compiled=[j for j in recorded if j['role']!='link'];hashes=sorted(digest(json.dumps(r['argv'],separators=(',',':')).encode()) for r in compiled)
    need(hashes==sorted(j['argv_sha256'] for j in roles['rustc']) and sorted([j['exe'],j['output']] for j in recorded if j['role']=='link')==roles['wild'] and mapping['exact_compiler_execs']==len(compiled) and mapping['actual_selected']>=1,'raw per-role argv/map disagreement')
    return {'rustc':len(compiled),'wild':len(roles['wild']),'trace_files':len(seen['raw_filename_sha256_inventory']),'full_argv_restored':True}

def audit(root,expected,scratch,cas=None):
    raw=root/'physical';trip,w=outer(raw,expected)
    intake=data(raw/'intake.json');prev=root/'owner/immediate-previous.json'
    need(sha(prev)==intake['previous_sha256'] and data(prev)['outer']==intake['outer'],'missing actual immediate host predecessor')
    if trip['exit']!=0:
        return {'outer':trip,'outer_sha256':expected,'eligible':False,'scored_pairs':0,'raw_completed_B_commands':sum(p.is_file() for p in raw.glob('*/B/command.json')),'series_present':(raw/'series.json').is_file(),'family_p':1,'basis':'unsuccessful real worker; no performance inference'}
    public_inputs(root)
    s=data(raw/'successful.json');ret=data(raw/'retired.json')
    need(w['success']==sha(raw/'successful.json') and s['registration']==OWN['registration.json'] and s['scorer_sha256']==sha(raw/'analysis.json') and s['all_tests']==15 and s['all_ELF']==17 and s['scored_rows']==24 and s['pilot_only'] is False and s['subjects_sha256']==sha(raw/'subjects.json') and s['physical_custody_sha256']==sha(raw/'retired.json') and s['cas_sha256']==ret['all_programs_sha256']==sha(raw/'cas-index.json') and ret['absent'] is True and set(ret['archives'])=={'P','CZD'},'unverified products or bank retirement')
    rosters=actual_native(raw,root/'sources')
    result,programs,sc=science(root/'sources',raw,scratch,cas)
    prior=data(root/'owner/earlier.json');family=data(root/'owner/family.json');previous_scores=older_result(root,prior)
    need('CZD/check' not in prior['original_effects'] and SCOPE not in prior['original_effects'] and
         family=={'actual_package_result':result,'twelve':sc.holm12({**previous_scores,SCOPE:result['score']}),'earlier_outers':prior['actual_outers'],'own_outer_sha256':expected,'pooled':False,'excluded_ordinary_prepares':FAILED_ORDINARY},'registered 12-way calculation or older separate studies disagree')
    return {'outer':trip,'outer_sha256':expected,'eligible':True,'counted_pairs':result['counted_pairs'],'raw_P_CZD_ns':result['raw_P_CZD_ns'],'score':result['score'],'holm12':family['twelve'],'programs':programs,'actual_admission_processes':rosters,'full_binaries_reread':cas is not None}

def run(packet,expected,scratch=None,elf_cas=None,reserve=0):
    scratch=Path(scratch or tempfile.gettempdir()).resolve(strict=True)
    with tempfile.TemporaryDirectory(prefix='stack-native-',dir=scratch) as t:
        root=Path(t)/'detached'/'packet';root.mkdir(parents=True);work=Path(t)/'temporary';work.mkdir()
        unpack(packet,root,reserve)
        if elf_cas is not None:
            idx=data(root/'physical/cas-index.json');bound=2*max(x['raw_bytes'] for x in idx['files'].values())+(256<<20)
            need(shutil.disk_usage(work).free>=reserve+bound,'insufficient temporary room to independently read two real full ELFs')
        old=tempfile.tempdir;tempfile.tempdir=str(work)
        try:return audit(root,expected,work,elf_cas)
        finally:tempfile.tempdir=old

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('packet',type=Path);p.add_argument('--outer',required=True);p.add_argument('--scratch',type=Path);p.add_argument('--elf-cas',type=Path);p.add_argument('--reserve-gib',type=int,default=0)
    args=p.parse_args();need(args.reserve_gib>=0,'invalid reserve')
    print(json.dumps(run(args.packet,args.outer,args.scratch,args.elf_cas,args.reserve_gib<<30),sort_keys=True,indent=2))
