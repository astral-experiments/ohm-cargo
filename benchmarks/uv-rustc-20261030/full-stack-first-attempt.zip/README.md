# Replaying the returned whole-stack packet

This program covers one native P→CZD full-package test following the fixed 62-line uv edit. Each arm has an independently restored warm A history. P is bare Ohm −20 compiler source. CZD contains Rust #270 and #275. Use the separately supplied compact packet and a trusted SHA-256 for its actual physical outer return. Extract verify.py from the authenticated packet into a fresh directory, then run the command below. It uses standard Python 3.11 or later for compact replay.

```sh
python3 -ISB verify.py whole-stack.zip --outer RETURN_SHA --scratch /path/to/scratch
```

The compact replay reconstitutes every saved program inventory and clock, then runs the owning unmodified native row and statistics code. It checks 17 programs, all 15 test catalogues, two CLI outputs, the actual B source edit, 24 first-edit intervals and both arm orders. It checks both independent P-only A/B form sets, complete observed per-role reciprocal proofs and the recorded hashes of raw compressed binaries. The three earlier rejected attempts receive p=1. It separately reruns Holm12 from this cohort and the frozen older score inputs attested by the exporter. Earlier studies keep their own sample cohorts and uncertainty. If the actual full-stack worker failed, this packet summarizes completed commands and custody and gives it zero scored pairs, even if some timed commands ran.

For a new, independent byte-for-byte reconstruction, supply `--elf-cas /path/to/products`, containing the complete recorded `<raw-sha256>.zst` files, and install `zstd` and an LLVM library exporting llvm_blake3_hasher_* (optionally set PACKAGE_REPLAY_LLVM). The native exporter also exercises the study owner's own deep physical eligibility reader. The compact packet omits the large programs. Without the CAS it authenticates the recorded reciprocal byte comparisons from the outer-bound receipts. New raw rehashes require those program files. Native Cargo/linker executables, SDKs and writable targets are excluded.

The local producer runs only after the coordinator supplies a closed outer SHA. It leaves the original records intact. A new output, staging disk and at least 122 GiB of remaining free space are required by default.

```sh
taskset -c 29 /usr/bin/python3 -ISB export.py --outer RETURN_SHA \
  --previous-combined /path/to/ohm-20-uv-package-test-v3-combined.zip \
  --scratch /path/to/scratch --destination /path/to/new/whole-stack.zip
```

The packet includes the exact two uv source files, all 65 SHA-256 entries per SDK, both official run-make receipts and their compiler qualification. Both SDK manifests differ only at the driver. The five earlier excluded scopes retain p=1. The failed ordinary check and build prepares contribute zero scored pairs. A completed 12-pair cohort can still miss the performance threshold.

The custodian runs export.py from its original native/ directory in the study workspace after the real physical outer is returned. Reviewers can run verify.py against the independently published ZIP and outer SHA from any directory without that workspace. Verify the published ZIP SHA before executing bundled Python. Compressed ELF payloads are external and optional for compact replay. No live workload or real new P/CZD result was used in the included synthetic controls.
