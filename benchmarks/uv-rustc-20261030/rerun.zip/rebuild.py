"""Build independent, source-verified Linux x86-64 Ohm drivers. Requires ordinary Rust bootstrap prerequisites."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SRC = HERE / "source"
sys.path[:0] = [str(HERE), str(SRC)]
from common import need, sha, write

def read(path): return json.loads(path.read_bytes())
from consumer_smoke import exercise

HOST = "x86_64-unknown-linux-gnu"
HOSTLIB = Path("lib/rustlib") / HOST / "lib"
PLAN = json.loads((SRC / "sources.json").read_bytes())


def git(tree, *args):
    return subprocess.check_output(["git","-c","core.hooksPath=/dev/null","-C",tree,*args], text=True).strip()


def tracked_tree(tree, commit, expected):
    need(git(tree,"rev-parse","HEAD") == commit and git(tree,"write-tree") == expected, "changed commit or index tree")
    git(tree,"diff","--quiet","--ignore-submodules=none")
    need(not git(tree,"ls-files","--others","--exclude-standard"), "additional untracked build inputs")


def select(tree, arm, spec=PLAN, patches=SRC):
    parent = spec["P"]
    git(tree,"restore","--source="+parent,"--staged","--worktree","--",
        *spec["subjects"]["C"]["files"].keys())
    tracked_tree(tree, parent, spec["tree"])
    if arm == "P":
        return spec["tree"]
    row = spec["subjects"][arm]
    patch = patches / row["patch"]
    need(sha(patch) == row["sha256"], "wrong source patch")
    git(tree,"apply","--index",str(patch))
    tracked_tree(tree, parent, row["tree"])
    for name, blob in row["files"].items():
        need(sha(tree / name) == blob["after_sha256"] and git(tree,"rev-parse",":"+name) == blob["after"],
             "changed patched source: "+name)
    return row["tree"]


def run(argv, work, env, log):
    with log.open("xb") as output:
        p = subprocess.run(argv,cwd=work,env=env,stdout=output,stderr=subprocess.STDOUT)
    row = {"argv":list(map(str,argv)), "exit":p.returncode,"log_sha256":sha(log)}
    write(log.with_suffix(".json"),row)
    if p.returncode:
        raise RuntimeError(f"command exited {p.returncode}; see {log}")
    return row


def copy_file(src, dst):
    need(src.is_file() and not dst.exists() and not dst.is_symlink(),"missing source or existing output: "+str(dst))
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)


def lookup_llvm(driver, built):
    deps = subprocess.check_output(["readelf","-d",driver],text=True)
    names = re.findall(r"\(NEEDED\).*?\[(libLLVM[^/\]]+)\]",deps)
    need(len(names)==1,"expected the one dynamically linked LLVM from this bootstrap")
    name = names[0]
    for parent in ("stage1/lib","llvm/lib","llvm/build/lib","ci-llvm/lib"):
        p = built / parent / name
        if p.is_file():
            return p,name
    raise FileNotFoundError(f"bootstrap did not put its dependent {name} in {built}")


def export(built, release, sdk, arm, parent, ref, spec=PLAN):
    stage = built/"stage1"
    (driver,) = (stage/"lib").glob("librustc_driver-*.so")
    dso = driver.relative_to(stage)
    sdk.mkdir()
    if arm=="P":
        copy_file(stage/"bin/rustc",sdk/"bin/rustc")
        copy_file(built/"stage1-tools-bin/cargo",sdk/"bin/cargo")
        lib,name = lookup_llvm(driver,built); copy_file(lib,sdk/"lib"/name)
        required = set(spec["std_stems"])
        selected={}
        for p in (stage/HOSTLIB).iterdir():
            stem=re.sub(r"-[0-9a-f]{16}(?=\.(?:rlib|rmeta|so)$)","-HASH",p.name)
            if stem in required:
                need(stem not in selected and p.stat().st_size>0, "ambiguous/empty target library")
                selected[stem]=p
        need(selected.keys()==required, "incomplete stage1 standard/test library")
        for p in selected.values():copy_file(p,sdk/HOSTLIB/p.name)
        for n,h in spec["stock_tools"].items():
            need(sha(release/n)==h,"unexpected published support file "+n)
            copy_file(release/n,sdk/n)
    else:
        need(sha(stage/"bin/rustc")==ref["bin/rustc"] and ref.get(str(dso))!=sha(driver)
             and (parent/dso).is_file(), "changed launcher, driver name or missing compiler change")
        for n,h in ref.items():
            if n!=str(dso):
                dest=sdk/n; dest.parent.mkdir(parents=True,exist_ok=True);os.link(parent/n,dest)
    copy_file(driver,sdk/dso)
    files={str(p.relative_to(sdk)):sha(p) for p in sdk.rglob("*") if p.is_file()}
    need(len(files)==65, "unexpected projected SDK shape")
    if arm!="P":
        need(files.keys()==ref.keys() and {n for n in files if files[n]!=ref[n]}=={str(dso)},"unexpected SDK change")
    return str(dso),files


def verify_subjects(path, arms):
    out=read(path)
    need(out["provenance"]=="independent-source-build" and out["source_parent"]==PLAN["P"]
         and out["submodule_gitlinks"]["src/tools/cargo"]==PLAN["cargo"] and out["submodule_gitlinks"]["src/llvm-project"]==PLAN["llvm"]
         and out["source_spec_sha256"]==sha(SRC/"sources.json") and out["config_sha256"]==sha(path.parent/"bootstrap.toml")
         and out["config_template_sha256"]==sha(SRC/"bootstrap.toml") and len(out["common_members"])==64,"independent build input mismatch")
    for name in sorted(set(arms)|{"P"}):
        rec=path.parent/"records"/name
        src=PLAN["subjects"].get(name)
        tree=PLAN["tree"] if name=="P" else src["tree"]
        need(sha(rec/"sdk.json")==out[name]["sdk_receipt_sha256"],"changed source-build SDK receipt")
        x=read(rec/"sdk.json");relative=x["driver"]
        need(x["source_tree"]==out[name]["tree"]==tree and x["source_parent"]==PLAN["P"] and x["arm"]==name and
             x["source_patch_sha256"]==(None if name=="P" else src["sha256"]) and
             x["versions"]==out["versions"] and x["files"][relative]==out[name]["driver_sha256"] and
             {k:v for k,v in x["files"].items() if k!=relative}==out["common_members"],"source, shared SDK, or runtime version changed")
        need(x["smoke_sha256"]==sha(rec/"smoke.json") and read(rec/"smoke.json")["verified"],"missing real test/proc-macro consumers")
        for op,field in (("build","build_sha256"),("native-guards","applicable_native_recipes_sha256")):
            z=read(rec/(op+".json"));argv=z["argv"]
            need(sha(rec/(op+".json"))==x[field] and z["exit"]==0 and z["log_sha256"]==sha(rec/(op+".log"))
                 and argv[1:4]==["-ISB","x.py","build" if op=="build" else "test"] and argv[4:6]==["--stage","1"],
                 "missing source-build output or native guards")
            if op=="native-guards":
                output=(rec/"native-guards.log").read_text(errors="replace")
                for case in ("ohm-checked-dep-info","ohm-relink-assembler-inputs"):
                    need(any(case in line and re.search(r"\.\.\.\s+ok\s*$",line) for line in output.splitlines()),"native test did not report a passing case: "+case)
                need("--force-rerun" in argv and argv[-2:]==["tests/run-make/ohm-checked-dep-info","tests/run-make/ohm-relink-assembler-inputs"],"different native correctness recipes")
    need(len({out[n]["driver_sha256"] for n in set(arms)|{"P"}})==len(set(arms)|{"P"}),"duplicate source-built drivers")
    return out


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--destination",type=Path,required=True,help="new private directory")
    ap.add_argument("--release-sdk",type=Path,required=True,help="installed, SHA-verified Ohm -18 x86-64 GNU SDK for its eight linker tools")
    ap.add_argument("--rust",default=PLAN["repository"],help="accessible repository URL or local Git clone containing pinned P")
    ap.add_argument("--arms",default="C,CZ,CZD,ZD",help="comma-separated optional arms; P and the common SDK are always built")
    ap.add_argument("--jobs",type=int,default=8)
    args=ap.parse_args()
    arms=("P",*args.arms.split(",")); root=args.destination.resolve(); release=args.release_sdk.resolve(strict=True)
    need(1<=args.jobs<=256 and len(set(arms))==len(arms) and all(a in PLAN["subjects"] for a in arms[1:]),"invalid arms/jobs")
    need(not root.exists() and not root.is_relative_to(release) and not release.is_relative_to(root),"use a new independent directory")
    if Path(args.rust).exists():
        source=Path(args.rust).resolve(strict=True)
        need(not root.is_relative_to(source) and not source.is_relative_to(root),"keep build outside input clone")
    for n,h in PLAN["stock_tools"].items():need(sha(release/n)==h,"wrong installed -18 support "+n)
    root.mkdir(parents=True,mode=0o700)
    tree=root/"rust"; build=root/"build"; sdks=root/"sdks"; records=root/"records"; sdks.mkdir(); records.mkdir()
    env={k:v for k,v in os.environ.items() if k not in {"CC","CXX","LD","LIBRARY_PATH","LD_LIBRARY_PATH","LD_PRELOAD","MAKEFLAGS"} and not k.startswith(("RUST","CARGO","LLVM","PYTHON"))}
    env.update(CARGO_HOME=str(root/"cargo-home"),CC="clang",CXX="clang++",LC_ALL="C",TERM="dumb",NO_COLOR="1",CARGO_TERM_COLOR="never",PYTHONDONTWRITEBYTECODE="1")
    subprocess.run(["git","clone","--no-local","--no-checkout","--",args.rust,tree],env=env,check=True)
    git(tree,"checkout","--detach",PLAN["P"])
    git(tree,"submodule","update","--init","--depth","1","--recursive","--","library/backtrace","src/tools/cargo","src/llvm-project")
    subs={}
    for n in ("library/backtrace","src/tools/cargo","src/llvm-project"):
        mode,kind,commit,_=git(tree,"ls-tree","HEAD",n).split()
        need(mode=="160000" and kind=="commit" and git(tree/n,"rev-parse","HEAD")==commit,"submodule mismatch")
        need(not git(tree/n,"status","--porcelain","--untracked-files=all"),"dirty bootstrap submodule")
        subs[n]=commit
    need(subs["src/tools/cargo"]==PLAN["cargo"] and subs["src/llvm-project"]==PLAN["llvm"],"wrong Cargo or LLVM")
    tracked_tree(tree,PLAN["P"],PLAN["tree"])
    cc=root/"bootstrap-cc"
    cc.write_text("#!/bin/sh\nexec /usr/bin/cc -B"+shlex.quote(str(release/"lib/rustlib"/HOST/"bin/gcc-ld")+"/")+" -fuse-ld=lld \"$@\"\n")
    cc.chmod(0o755)
    cfg=root/"bootstrap.toml"
    cfg.write_text((SRC/"bootstrap.toml").read_text()+"\n[target."+HOST+"]\nlinker = "+json.dumps(str(cc))+"\n")
    heads={"provenance":"independent-source-build","source_parent":PLAN["P"],"submodule_gitlinks":subs,
           "config_sha256":sha(cfg),"config_template_sha256":sha(SRC/"bootstrap.toml"),"source_spec_sha256":sha(SRC/"sources.json")}
    base=None
    for arm in arms:
        rec=records/arm;rec.mkdir()
        expected=select(tree,arm)
        argv=[sys.executable,"-ISB","x.py","build","--stage","1","--config",str(cfg),"--build-dir",str(build),"--host",HOST,"--target",HOST,"-j"+str(args.jobs)]
        run(argv+(["compiler/rustc","library","src/tools/cargo"] if arm=="P" else ["compiler/rustc"]),tree,env,rec/"build.log")
        # Recheck the applied source after Rust bootstrap and separately exercise the unmodified effective upstream run-make recipes.
        tracked_tree(tree,PLAN["P"],expected)
        test=argv.copy();test[3]="test";test.append("--force-rerun")
        run(test+["tests/run-make/ohm-checked-dep-info","tests/run-make/ohm-relink-assembler-inputs"],tree,env,rec/"native-guards.log")
        tracked_tree(tree,PLAN["P"],expected)
        sdk=sdks/arm; dso,files=export(build/HOST,release,sdk,arm,sdks/"P",base)
        if arm=="P":base=files
        use=dict(env,PATH=str(sdk/"bin")+":"+env["PATH"],RUSTC=str(sdk/"bin/rustc"))
        v={n:subprocess.check_output([sdk/"bin"/n,"-vV"],text=True,env=use) for n in ("rustc","cargo")}
        need("commit-hash: "+PLAN["P"] in v["rustc"] and "commit-hash: "+PLAN["cargo"] in v["cargo"]
             and "host: "+HOST in v["rustc"] and "release: 1.99.0-dev" in v["rustc"] and "LLVM version: 23.1." in v["rustc"],"wrong actual compiler/Cargo identity")
        need(subprocess.check_output([sdk/"bin/rustc","-Zohm-check-relink-inputs","--print=sysroot"],text=True,env=use).strip()==str(sdk),"missing native guard/relocation")
        smoke=exercise(sdk,use); write(rec/"smoke.json",smoke);need(smoke["verified"],"test and proc-macro SDK consumers failed")
        write(rec/"sdk.json",{"arm":arm,"source_tree":expected,"source_parent":PLAN["P"],"files":files,"driver":dso,"versions":v,
                 "source_patch_sha256":None if arm=="P" else PLAN["subjects"][arm]["sha256"],
                 "applicable_native_recipes_sha256":sha(rec/"native-guards.json"),"smoke_sha256":sha(rec/"smoke.json"),
                 "build_sha256":sha(rec/"build.json")})
        need(v==heads.setdefault("versions",v),"version changed between matched SDKs")
        heads[arm]={"tree":expected,"driver_sha256":files[dso],"sdk_receipt_sha256":sha(rec/"sdk.json")}
        common={n:h for n,h in files.items() if n!=dso}
        need(common==heads.setdefault("common_members",common),"common payload changed")
    need(len({heads[a]["driver_sha256"] for a in arms})==len(arms),"identical driver across unlike source trees")
    write(root/"subjects.json",heads)
    verify_subjects(root/"subjects.json", arms)
    print("Independent builds and native correctness checks passed. SDKs:",sdks,"; manifest:",root/"subjects.json")

if __name__=="__main__":main()
