"""Check the real repeated control product records and single-field negative controls."""
import copy
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
import pip_install_elf as rule


def baseline(name, checksum):
    data = (root / "package-original" / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == checksum
    return json.loads(data)


def bundle(records):
    return {"files": {k: {f: row[f] for f in ("bytes", "sha256", "path")} for k, row in records.items()},
            "all_products": records, "self_version": {"fixture": True}, "version": "fixture"}


if __name__ == "__main__":
    first = baseline("pip-install-admitted.json", "64fad776fd78e9d17a740dcb5a49d2627050fa8e1f0ccda7c68038ffa03f6a43")
    other = baseline("pip-install-repeat.json", "a08049aaf2507dec5bd004c3d91f328e63df19855361cd4bea3823825e196c8e")
    images = {first[rule.ROLE]["sha256"], other[rule.ROLE]["sha256"]}
    assert len(first) == 17 and images == {rule.FIRST, rule.SECOND}
    assert rule.matching_programs(first, other) and rule.matching_programs(other, first)
    assert rule.matching_bundles(bundle(first), bundle(other))
    for role, name, value in (
        (rule.ROLE, "sha256", "0" * 64),
        (rule.ROLE, "tests", 354), (rule.ROLE, "stdout_sha256", "0" * 64),
        (rule.ROLE, "path", "other"), (rule.ROLE, "bytes", rule.SIZE - 1),
        ("uv", "sha256", rule.SECOND),
    ):
        changed = copy.deepcopy(other)
        changed[role][name] = value
        assert not rule.matching_programs(first, changed)
        assert not rule.matching_bundles(bundle(first), bundle(changed))
    altered = bundle(other)
    altered["files"][rule.ROLE]["sha256"] = "f" * 64
    assert not rule.matching_bundles(bundle(first), altered)
    for filename in ("combined-v2.json", "direct-v2.json"):
        rule.verify_plan(json.loads((root / "package-original" / filename).read_bytes()))
    print("Verified the two observed control ELFs, both registered plans, and seven rejection controls.")

