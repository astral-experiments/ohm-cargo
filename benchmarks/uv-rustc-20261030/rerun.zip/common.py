"""Small common operations from the standalone uv branch replay."""
import hashlib, json, os, stat, subprocess


def need(ok, message):
    if not ok:
        raise ValueError(message)


def write(path, data):
    with path.open("x") as f:
        json.dump(data, f, sort_keys=True, indent=2)
        f.write("\n")


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def copy(src, dst):
    need(not dst.exists() and not dst.is_symlink(), f"copy destination exists: {dst}")
    subprocess.run(["cp", "-a", "--reflink=auto", "--", src, dst], check=True)


def allocated(root):
    data = subprocess.check_output(["du", "-s", "-B1", "--", root])
    return int(data.split(None, 1)[0])


def sdk_files(root):
    files = {}
    for p in root.rglob("*"):
        name = p.relative_to(root).as_posix()
        if p.is_symlink():
            link = os.readlink(p)
            need(not os.path.isabs(link) and p.resolve(strict=True).is_relative_to(root), f"external SDK symlink: {name}")
            files[name] = {"link": link}
        elif p.is_file():
            files[name] = {"sha256": sha(p), "mode": stat.S_IMODE(p.stat().st_mode)}
        else:
            need(p.is_dir(), f"unsupported SDK member: {name}")
    return files


def stamps(target):
    return {p.relative_to(target).as_posix(): p.stat().st_mtime_ns
            for p in (target / "debug/build").glob("*/*/fingerprint/invoked.timestamp")}


def version_output(cmd, env, cwd):
    return subprocess.check_output(cmd, cwd=cwd, env=env, stderr=subprocess.PIPE, timeout=45)
