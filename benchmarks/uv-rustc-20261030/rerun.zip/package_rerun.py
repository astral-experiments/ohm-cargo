"""Reproduce the package-wide fresh uncommitted edit with two source-matched Ohm SDKs."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import rerun as original
import package_products as programs
import package_process as process
from common import allocated,copy,need,sha,stamps,write
read=original.read
NAME='tool-test'
COMBINED='1fe2a1508760d467cf4416dfcdf0949f8fae12832123a38056e08bb16f86e35b'
DIRECT='ae661a3d7b705210839904227beb111d22cf388bf8ddd1cf4a414a6d7e9d6238'
def science(candidate):
    p=HERE/'package-original'/('combined.json' if candidate=='CZD' else 'direct.json')
    need(candidate in ('CZD','ZD') and sha(p)==(COMBINED if candidate=='CZD' else DIRECT),'different package trial')
    return read(p)
def markers(target,raw_dir=None):
    out={k:[] for k in sorted(original.KNOWN)};opaque=[]
    if raw_dir is not None:raw_dir.mkdir()
    for p in sorted((target/'debug/build').glob('*/*/out/*.d')):
        data=p.read_bytes();name=p.parent.parent.parent.name;rel=p.relative_to(target).as_posix();poison=original.POISON in data
        if poison:opaque.append(rel)
        if name not in out:continue
        digest=hashlib.sha256(data).hexdigest();out[name].append({'path':rel,'sha256':digest,'opaque':poison,'recheck_link':original.RECHECK in data})
        if raw_dir is not None and not(raw_dir/(digest+'.d')).exists():(raw_dir/(digest+'.d')).write_bytes(data)
    need(all(out.values()),'missing dependency unit for an observed assembler input')
    for pkg in ('zeroize','libm'):need(len({x['opaque'] for x in out[pkg]})==1,'ambiguous policy between active units of '+pkg)
    return {'units':{k:{'opaque':any(x['opaque'] for x in v),'variants':v} for k,v in out.items()},'all_opaque_paths':opaque}
def identity(p):
    st=p.stat();return [st.st_dev,st.st_ino]
class Package(original.Replay):
    execute=staticmethod(subprocess.run)
    observer=process.Observer
    def __init__(self,args,workflow,doc):
        self.doc=doc;self.budget=args.max_target_gib<<30
        w={**workflow,'command':doc['ordinary_argv'][1:]}
        super().__init__(args,w)
        if self.subjects.get('provenance')=='independent-source-build':
            proof=self.root/'source-build-proof';proof.mkdir();copy(args.subjects,proof/'subjects.json');copy(args.subjects.parent/'bootstrap.toml',proof/'bootstrap.toml')
            for arm in set(self.sdks)|{'P'}:
                dst=proof/'records'/arm;dst.mkdir(parents=True)
                for name in ('sdk.json','smoke.json','build.json','build.log','native-guards.json','native-guards.log'):
                    copy(args.subjects.parent/'records'/arm/name,dst/name)
        write(self.root/'package-intake.json',{'contrast':self.candidate,'normalized_argv':doc['ordinary_argv'],'combined_plan':COMBINED,'direct_plan':DIRECT,'incremental_storage_budget':self.budget,'tool_only_inputs_file_sha256':sha(self.root/'inputs.json'),'all_roles':doc['expected_reported_test_roles'],'cold_strategy':'each compiler creates its own ordinary fully cold A, then settles with two repeats','portable_same_uid_external_monitor_period_s':.20})
    def setup(self):
        super().setup();source=self.root/'source-template';rel=self.plan['endpoints'][NAME]['path']
        def git(*args):return original.git(source,*args).decode().strip()
        identity=original.read(self.root/'source-identity.json')
        write(self.root/'package-source.json',{'HEAD':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parent':git('rev-parse','HEAD^'),'ref':git('symbolic-ref','HEAD'),'tag_0_12_0':git('rev-parse','refs/tags/0.12.0^{commit}'),'local_core_abbrev':identity['local_core_abbrev'],'description':identity['describe_tags_always'],'describe_always':identity['describe_always'],'uv_build_script_log':identity['uv_build_script_log'],'source_blobs':{'A':git('rev-parse','HEAD:'+rel),'B':git('rev-parse','HEAD^:'+rel)},'cargo_lock_sha256':sha(self.root/'sources/Cargo.lock')})
    def products(self,folder,edit,state,text):
        raw=programs.capture(folder,self.src,self.target,self.doc['expected_reported_test_roles'],self.env,invoke=self.execute)
        write(folder/'product-identities.json',{k:identity(self.target/v['path']) for k,v in raw.items()})
        objroot=self.root/'objects';files={}
        for name,x in raw.items():
            p=self.target/x['path'];h=x['sha256'];dst=objroot/h
            if not dst.exists():
                self.space(x['bytes']);copy(p,dst);need(sha(dst)==h,'retained complete ELF differs')
            files[name]={key:x[key] for key in ('path','sha256','bytes')}
        report=self.execute([str(self.target/files['uv']['path']),'self','version','--output-format','json'],cwd=self.src,env=self.env,capture_output=True,timeout=45)
        (folder/'self-version.stdout').write_bytes(report.stdout);(folder/'self-version.stderr').write_bytes(report.stderr)
        need(report.returncode==0 and json.loads(report.stdout)==self.plan['A']['self_version'],'wrong actual uv build source')
        version=(folder/'test-lists/uv.stdout').read_text().strip();need(version==self.plan['A']['version'],'wrong uv version')
        t=self.doc['uv']['edit'];tool=raw[programs.TOOL];need(tool['tests']==t[state+'_count'] and tool['stdout_sha256']==t[state+'_list'],'wrong real test remove/add')
        write(folder/'public-paths.json',files)
        return {'files':files,'all_products':raw,'self_version':json.loads(report.stdout),'version':version}
    def cargo(self,arm,edit,state,folder):
        warm=self.root/'seeds'/f'{edit}-{arm}';roster=stamps(self.target)
        if state=='B':
            need(not self.active.samefile(warm) and not self.target.samefile(warm/'target'),'shared writable history')
        obs=self.observer()
        with obs:
            if obs.events:
                folder.mkdir(parents=True);write(folder/'excluded.json',{'reason':'foreign-before','events':obs.events.copy(),'active':identity(self.active)});raise process.Busy(str(folder))
            result=super().cargo(arm,edit,state,folder)
        after=stamps(self.target);write(folder/'stamps-before.json',roster);write(folder/'stamps-after.json',after)
        cmd=read(folder/'command.json');need(cmd['changed_stamps']==sorted(k for k in roster.keys()|after.keys() if roster.get(k)!=after.get(k)),'dirty compiler proof changed')
        events=[e for e in obs.events if cmd['start_ns']<=e['ns']<=cmd['end_ns']];write(folder/'external-builds.json',{'unfiltered':obs.events,'during_foreground':events,'period_s':.2,'same_uid_only':True})
        write(folder/'package-observation.json',{n:sha(folder/n) for n in ('command.json','cargo.log','stamps-before.json','stamps-after.json','external-builds.json','all-products.json','products.json','public-paths.json','product-identities.json','self-version.stdout','self-version.stderr')})
        if events:
            write(folder/'excluded.json',{'reason':'foreign-overlap','events':events,'active':identity(self.active)});raise process.Busy(str(folder))
        if state=='B' and folder.parent.parent.name=='admission':
            record=markers(self.target,folder/'raw-depinfo');need(original.policy(arm,{name for name,r in record['units'].items() if r['opaque']}),'unexpected native inputs after the real edit')
            write(folder/'markers.json',record)
        size=allocated(self.target);need(size<=self.budget,'actual target exceeded --max-target-gib')
        return result
    def prime(self,edit,arm):
        self.space(self.budget)
        with patch.object(original,'markers',markers):product=super().prime(edit,arm)
        folder=self.root/'records'/edit/'A'/arm;seed=self.root/'seeds'/f'{edit}-{arm}'
        write(folder/'package-seed.json',{'identity':identity(seed),'allocated':allocated(seed),'A_only':True,'source':read(folder/'seed.json')['source_sha256'],'driver_sha256':self.subjects[arm]['driver_sha256'],'source_template_sha256':sha(self.root/'sources/Cargo.lock')})
        return product
    def trial(self,edit,arm,folder,stamp):
        root=self.root/'records'/edit/'A'/arm;warm=read(root/'package-seed.json');seed=self.root/'seeds'/f'{edit}-{arm}'
        need(identity(seed)==warm['identity'] and sha(seed/'source/Cargo.lock')==warm['source_template_sha256'],'warm donor changed')
        pub=read(root/'verify-repeat/all-products.json');need(len(pub)==17,'earlier unpriced publications')
        cost=max(2<<30,2*sum(x['bytes'] for x in pub.values())+(512<<20));self.space(warm['allocated']+cost)
        with patch.object(original,'markers',markers):value=super().trial(edit,arm,folder,stamp)
        programs.phase_change(pub,value[1]['all_products'],root/'verify-repeat',folder,self.doc)
        write(folder/'warm-origin.json',{'identity':warm['identity'],'source_sha256':warm['source'],'seed_receipt_sha256':sha(root/'package-seed.json'),'driver_sha256':self.subjects[arm]['driver_sha256'],'never_primed_B':True})
        return value
    def endpoint(self):
        armset=[self.control,self.candidate];edit=NAME;doc=self.doc
        originals={a:self.prime(edit,a) for a in armset};need(originals[armset[0]]==originals[armset[1]],'different 17 A programs or behavior')
        parent=self.root/'records'/edit;admissions={};exclusions=[];ledger=[]
        def pair(label,arms):
            for attempt in range(3):
                stamp=time.time_ns();paths=[];values={};public=[]
                for i,arm in enumerate(arms):
                    rel=f'{label}/try-{attempt}/{i}-{arm}';folder=parent/rel;paths.append(rel)
                    try:roster,outputs=self.trial(edit,arm,folder,stamp)
                    except process.Busy:
                        proof=read(folder/'excluded.json')
                        need(label!='admission' and proof['events'] and identity(self.active)==proof['active'] and self.active==self.root/'active' and not self.active.is_symlink() and all(not self.active.samefile(self.root/'seeds'/f'{edit}-{x}') for x in armset),'invalid retry or unowned material')
                        exclusions.append({'label':label,'attempt':attempt,'order':arms,'paths':paths.copy(),'proof_sha256':sha(folder/'excluded.json')})
                        write(folder/'attempt-excluded.json',exclusions[-1])
                        need(process.clear_existing(),'foreign native build remained for 90s');shutil.rmtree(self.active);break
                    if label=='admission':admissions[arm]=(roster,outputs)
                    else:need((roster,outputs)==admissions[arm],'edited products or dirty work differ from own admission')
                    public.append(outputs);values[arm]=read(folder/'command.json')['elapsed_ns']
                else:
                    need(public[0]==public[1],'different 17 actual B programs, lists or versions between compilers')
                    ledger.append({'label':label,'attempt':attempt,'order':arms,'paths':paths});return values
            raise ValueError('three objectively contaminated attempts; retained earlier evidence')
        pair('admission',armset)
        pilot=None;continued=True
        if self.candidate=='CZD':
            p=pair('pilot',doc['pilot_order']);pilot=p;continued=5*p[self.control]>=9*p[self.candidate]
        if continued:
            for i,arms in enumerate(doc['pairs'],1):pair(f'pair-{i:02d}',arms)
        write(parent/'closed.json',{'contrast':self.candidate,'control':self.control,'pilot':pilot,'continues':continued,'scored_pairs':12 if continued else 0,'ledger':ledger,'exclusions':exclusions})
        for a in armset:
            seed=self.root/'seeds'/f'{edit}-{a}';need(identity(seed)==read(parent/'A'/a/'package-seed.json')['identity'] and not seed.is_symlink(),'different private checkpoint')
        for a in armset:shutil.rmtree(self.root/'seeds'/f'{edit}-{a}')
def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('uv-clone','cargo-home','control-sdk','candidate-sdk','run'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--contrast',required=True,choices=['CZD','ZD']);p.add_argument('--subjects',type=Path,default=HERE/'subjects.json')
    p.add_argument('--reserve-gib',type=int,default=10);p.add_argument('--max-target-gib',type=int,default=16)
    p.add_argument('--combined-run',type=Path,help='verified independent package-wide C/CZD result required for ZD')
    p.add_argument('--prior-guard-run',type=Path,action='append',default=[],help='previous verified targeted portable runs included in the eight-way eligibility')
    args=p.parse_args();need(args.reserve_gib>=1 and args.max_target_gib>=1,'positive storage bounds required')
    if read(args.subjects).get('provenance')!='independent-source-build':need(sha(args.subjects)==sha(HERE/'subjects.json'),'use the checked original compiler SHA or independently verified source rebuild receipt')
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:16]);doc=science(args.contrast);wf=read(HERE/'workflow.json')
    import package_score as score
    if args.contrast=='ZD':need(args.combined_run is not None,'direct confirmation needs a qualifying combined full-package result');elig=score.eligibility(args.combined_run,args.prior_guard_run)
    else:need(not args.combined_run and not args.prior_guard_run,'prior evidence is only used at direct selection');elig=None
    runner=Package(args,wf,doc)
    if elig:write(runner.root/'package-eligibility.json',elig)
    runner.setup();runner.endpoint();write(runner.root/'complete.json',{'contrast':runner.candidate,'phase':'package-test','scientific_sha256':DIRECT if runner.candidate=='ZD' else COMBINED,'closed_sha256':sha(runner.root/'records'/NAME/'closed.json'),'portable':True})
    print('Completed. Run package_score.py on this directory for raw verification and statistics.')
if __name__=='__main__':main()
