"""Git identity used by the private checkout and uv's version build script."""
from common import need

A = "c22e6b71933443e9cd299d4b6ac8de035ed4825b"
RELEASE = "b88d7c5c46cbe3c9896544f10255f85a8f0a8a5e"
FORMAT = "%H %h %cd %(describe:tags)"

def verify_identity(record, plan):
    a = plan["A"]
    need(record["commit"] == a["commit"] and record["tree"] == a["tree"] and
         record["parent"] == plan["parent"] and record["ref"] == "refs/heads/feature-A",
         "wrong private Git checkout")
    need(record["local_core_abbrev"] == "7" and record["describe_always"] == a["commit"][:7] and
         record["describe_tags_always"] == a["git_description"].split()[-1] and
         record["uv_build_script_log"] == a["git_description"], "Git descriptions differ from the registered source")
    if a["commit"] == A:
        need(record["release_tag_target"] == RELEASE and record["release_tag_type"] == "commit",
             "different or non-lightweight 0.12.0 tag")
    return record

def private_identity(repo, plan, git):
    def get(*args):
        return git(repo, *args).decode().strip()

    get("config", "--local", "core.abbrev", "7")
    return verify_identity({
        "commit": get("rev-parse", "HEAD"), "tree": get("rev-parse", "HEAD^{tree}"),
        "parent": get("rev-parse", "HEAD^"), "ref": get("symbolic-ref", "HEAD"),
        "release_tag_target": get("rev-parse", "refs/tags/0.12.0^{commit}"),
        "release_tag_type": get("cat-file", "-t", "refs/tags/0.12.0"),
        "local_core_abbrev": get("config", "--local", "--get", "core.abbrev"),
        "describe_always": get("describe", "--always"),
        "describe_tags_always": get("describe", "--tags", "--always"),
        "uv_build_script_log": get("log", "-1", "--date=short", "--abbrev=9", "--format="+FORMAT),
    }, plan)
