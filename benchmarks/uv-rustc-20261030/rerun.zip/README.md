# Reproduce an ordinary fresh uv edit with two matched Ohm compilers

This runs the first ordinary Cargo command after a real uncommitted edit. The uv checkout stays on `c22e6b71933443e9cd299d4b6ac8de035ed4825b` throughout. Each edit replaces one current file with its exact contents from parent `ddc1deb0c9f088ee0d6f4086110c0dd159849726`. Setup reads Git objects from the supplied clone. Uncommitted user changes are left alone. [uv change #20770](https://github.com/astral-sh/uv/pull/20770)

| Endpoint | Only modified file | Tests in the selected executable, before → after |
|---|---|---|
| `tool-test` | `crates/uv/tests/tool/tool_list.rs` | 181 → 180 |
| `settings` | `crates/uv/src/settings.rs` | 181 → 181 |

## Choose your compiler inputs

For the authenticated binary kit, unpack its matched SDKs and original `subjects.json` and use them in the command below. For an independent source build, see [REBUILD.md](REBUILD.md). That route starts from the actual Rust/Cargo/LLVM revisions, applies the included patches, builds its own toolchain, runs the two native guard suites and supplies its own checked manifest. It includes the standalone P/ZD comparison and its seven-hypothesis decision.

## Requirements and invocation

Use x86-64 Linux, Python 3.11+, Git, GNU cp/du, a native host build environment for the pinned uv checkout, an already populated matching Cargo registry, and the complete matched SDKs. No package installation occurs. The private Cargo home copies the registry and any simple registry source mappings. Registry credentials, absolute source replacements and build overrides belong outside the supplied cache. A separate directory is required for each contrast. A run keeps two complete A trees, one working copy, the complete executable content store and one copy each of the Cargo registry, private SDK and Git template. On a filesystem without reflinks, allow at least three full allocated warm trees in addition to that material and the chosen reserve. The program checks measured sizes before copying checkpoints. Cold Cargo itself can grow while running.

```sh
sha256sum -c SHA256SUMS
python3 -ISB rerun.py --uv-clone /src/uv --cargo-home /cache/uv-cargo \
  --control-sdk /sdk/C --candidate-sdk /sdk/CZD --contrast CZD \
  --subjects subjects.json --run /bench/fresh-CZD
python3 -ISB score.py /bench/fresh-CZD
```

Run the same command in another new directory with `--candidate-sdk /sdk/CZ --contrast CZ` to measure that comparison. Pass both result directories to `score.py` to evaluate the four planned hypotheses together. `--edit tool-test` or `--edit settings` selects one named endpoint. Omitted endpoints retain p=1 in the family. A systematic replication should include both edits and report stopped pilots as well as completed endpoints. `--reserve-gib` sets the local pre-copy reserve, 10 GiB by default.

All SDK paths, bytes and modes must match between arms apart from the single rustc driver. The 64 shared file hashes and two distinct, source-bound driver hashes are checked against the supplied `subjects.json`. This includes Cargo, rustc's launcher, Wild, LLVM, the standard library and test harness. The driver itself reports the unchanged upstream compiler version, so its displayed version alone cannot identify the patch. The public compiler sources and exact tree identities are in [SOURCE.md](SOURCE.md). The original-binary binder makes `subjects.json` from successfully returned build/QA receipts. Independent builds have their own source/QA records.

## What runs

The foreground command in both arms is exactly:

```sh
cargo test --locked --offline -j8 -p uv --test tool --no-run
```

The runner creates and cold-builds a fresh source and target for each compiler and edit. It then makes two untouched A repeats and verifies that they agree on compiled packages, updated Cargo unit stamps, public executable bytes and behavior. A legitimately still-dirty control stays dirty. The runner parks that A tree before introducing any edit. Every admission, excluded pilot and scored invocation starts from a separate writable copy of its own arm's original A. Both arms see the same symbolic ref, HEAD, user edit, edit timestamp and absolute source, target, SDK, Cargo home and temporary paths. Prior B results never seed a subsequent B.

One unscored B command per arm admits the expected work and products. Every other B command must match its own arm's admission. The tester runs the named test executable with `--list`, executes both uv version interfaces, checks those outputs against the fixed revision and saves the original bytes of the three public ELF files (`tool`, `uv` and `uvx`). The two arms must produce identical public paths, file sizes, bytes, test lists and Git version information. Hashing, cloning, file editing, behavioral checks and selecting the driver occur outside the timer.

The timer spans spawning the ordinary Cargo foreground process through its return. Outside the timer the runner waits for the launched session to have no live processes. Each row saves Cargo's unchanged output and native exit status, explicit argv, nanosecond start and end, package/stamp roster and Linux `wait4` usage, including user/system CPU, faults, context switches, block I/O and peak RSS. Full source bytes and executable objects are deduplicated by SHA-256. The original dep-info of all six known packages is retained from A verification and B admission.

Each edit has one excluded pilot pair. A ratio below 1.8 stops that endpoint. Otherwise the runner uses exactly its registered 12 held-out pairs, six in each arm order. The outcome is C elapsed divided by patched elapsed, with no pooling. `score.py` verifies every original log and every retained executable before calling the same numerical functions as the registered scorer. They report paired medians, both order strata, order statistics 3 and 10 and exact two-sided sign tests centered at 1× and 2×. A 2× claim requires the lower statistic and both order medians to reach 2×, the individual sign gate, and Holm-adjusted p below .05 among the four named edit/patch combinations. No pilot time enters the estimate.

## Differences from the original host

This is a fresh-host replication. The original experiment starts each arm from a verified common P workload, applies the assigned compiler and settles A. This smaller two-SDK replay cold-seeds A with its assigned compiler directly. Its admissions are ordinary Cargo runs. The original host also maps actual compiler/DSO/frontend/linker invocations during an unscored strace admission, verifies jobserver permits, uses a read-only mount namespace, watches for outside work and enforces two 122-GiB physical reserves. This runner records ordinary Cargo evidence and does not recreate those machine controls. It stops on an error and never replaces a timed pair. Both approaches retain real Cargo's normal dependency checks. Use an idle host, stable local storage, and 16 comparable allowed CPUs for the closest replication. The runner takes the first 16 CPUs already admitted by the OS and records the actual set. A smaller allowed set changes the execution conditions.

`python3 -ISB test_replay.py` exercises the entire setup, reset, admission, scoring and negative checks in a tiny temporary Git repository with fake SDK commands. No Rust compiler runs. `registered_score.py` is the original scorer for a detached copy of the study's returned raw phase directories. `score.py` reads this standalone runner's own raw directory format.

## Private checkout identity

Both runners set `core.abbrev=7` in their private source template and verify two real Git commands before building. At the pinned HEAD, `git describe --always` must return `c22e6b7` and `git describe --tags --always` must return `0.12.0-9-gc22e6b7`. The build script uses a separate nine-character short commit hash. Each runner writes the full result to `source-identity.json` and its offline scorer checks it. To verify independently with existing Git objects and no Cargo, run `python3 -ISB test_git_identity.py /path/to/uv`. The source clone must contain the genuine lightweight 0.12.0 tag.
