"""Relocatable independent bin/CLI clock, 12 balanced pairs, exact median/sign tests and four-way Holm."""
import argparse,hashlib,json,math,re,statistics
from pathlib import Path

def need(v,why):
    if not v:raise ValueError(why)
def load(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sign(ratios,cut):
    lo=sum(x<cut for x in ratios);hi=sum(x>cut for x in ratios);n=lo+hi
    return {'below':lo,'above':hi,'ties':len(ratios)-n,'two_sided_p':min(1.,2*sum(math.comb(n,k) for k in range(min(lo,hi)+1))/2**n) if n else 1.}
def score_times(rows):
    need(len(rows)==12 and sum(first=='C' for first,b,c in rows)==6 and all(b>0 and c>0 for _,b,c in rows),'need twelve balanced genuine pair intervals')
    values=[b/c for _,b,c in rows];rank=sorted(values)
    strata={'C-first':statistics.median([b/c for f,b,c in rows if f=='C']),'candidate-first':statistics.median([b/c for f,b,c in rows if f!='C'])}
    return {'pairs':12,'C_seconds_median':statistics.median(b for _,b,c in rows)/1e9,'candidate_seconds_median':statistics.median(c for _,b,c in rows)/1e9,
            'paired_seconds_saved_median':statistics.median((b-c)/1e9 for _,b,c in rows),'ratio_median':statistics.median(values),'rank_3_to_10':[rank[2],rank[9]],'exact_median_interval_coverage':1-2*sum(math.comb(12,i) for i in range(3))/2**12,
            'per_order_ratio_medians':strata,'p_against_1':sign(values,1),'p_against_2':sign(values,2),'raw_ratio':values,'individual_gate':rank[2]>=2 and min(strata.values())>=2 and sign(values,2)['two_sided_p']<.05}
def holm(results):
    names=[c+'/'+e for c in ('CZ','CZD') for e in ('tool-test','settings')];need(set(results)<=set(names),'unknown family entry')
    p={n:results[n]['p_against_2']['two_sided_p'] if n in results else 1. for n in names};adj={};prior=0
    for rank,n in enumerate(sorted(names,key=lambda x:(p[x],x))):
        prior=max(prior,min(1,(len(names)-rank)*p[n]));adj[n]=prior
    return {n:{'raw_p':p[n],'holm_p':adj[n],'complete':n in results,'confirmed':n in results and results[n]['individual_gate'] and adj[n]<.05} for n in names}
def inputs(root,phase):
    outer,worker,intake=[load(root/f) for f in ('outer-return.json','worker-return.json','intake.json')]
    need(outer['outer']['session']>0 and re.fullmatch('[a-f0-9]{6}',outer['outer']['chunk']) and outer['outer']['exit']==outer['worker_code']==worker['code']==worker['worker_exit']==0 and outer['host_released'] and outer['remaining_workers']==outer['foreign']==[] and outer['worker_sha256']==sha(root/'worker-return.json') and outer['intake_sha256']==sha(root/'intake.json') and outer['locks']==worker['locks']==intake['locks'] and len(set(outer['locks']))==2 and outer['boot']==intake['boot'] and worker['success']==sha(root/'successful.json') and worker['capacity']['guard_fault'] is None,'not a genuinely successful returned scope')
    subjects=load(root/'subjects.json')['subjects'];a=load(root/'admissions/ready.json')
    need(phase['registration']==intake['registration'] and phase['subjects']==sha(root/'subjects.json') and phase['admissions_sha256']==sha(root/'admissions/ready.json') and set(a['arms'])=={'C',phase['candidate']},'wrong returned preparations')
    for label,info in a['arms'].items():
        rd=root/'admissions'/label
        need(all(n==Path(n).name and sha(rd/n)==h for n,h in info['files'].items()) and load(rd/'subject.json')==subjects[label] and info['driver_sha256']==subjects[label]['driver_sha256'],'not the admitted source-built driver')
        q=load(rd/'command.json');roles=load(rd/'roles.json');observed=load(rd/'census.json');actual=load(rd/'mapped-driver.json')
        need(q['traced'] and q['exit']==0 and q['observer_faults']==[] and len(observed['actual'])>=len(roles['rustc'])>0 and actual['actual_selected']>=1 and all(j['guard'] is True for j in roles['rustc'] if j['workspace_source'] and not j['link_only'] and not j['name'].startswith('build_script_')),'missing real edited ownership')
    for form,h in a['source_blobs'].items():
        need(form in ('A','B') and sha(root/'admissions'/('source-'+form+'.rs'))==h,'source payload corruption')
    need(set(a['source_blobs'])=={'A','B'},'both real source blobs required')
    return subjects,a
def replay(root,plan,extra):
    phase=load(root/'successful.json');out=phase['outcome'];c=phase['candidate'];name=phase['edit'];e=plan['endpoints'][name]
    need(c in ('CZ','CZD') and phase['phase'] in ('pilot','pairs'),'wrong review scope')
    subjects,adm=inputs(root,phase)
    for form in ('A','B'):
        raw=(root/'admissions'/('source-'+form+'.rs')).read_bytes()
        need(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==e[form],'source is not the original real Git file')
    leave=c=='CZ';tab=e if leave else extra['schedules'][name];expected=[tab['pilot_order']] if phase['phase']=='pilot' else tab['pairs']
    need(len(out['completed_pairs'])==len(expected) and out['scored_rows']==(0 if len(expected)==1 else 24),'short or partial series');rows=[];previous=0;anchor=None;baseroster={};src=None
    for i,(assigned,obs) in enumerate(zip(expected,out['completed_pairs'],strict=True)):
        need(len(assigned)==2 and set(assigned)=={'C',c} and obs['index']==i and obs['order']==assigned and 0<=obs['attempt']<=2 and len(obs['dirs'])==2,'changed assignment')
        excluded=[j for j in out['exclusions'] if j['pair']==i];need(sorted(j['attempt'] for j in excluded)==list(range(obs['attempt'])),'undocumented replacement')
        for j in excluded:
            f=root/j['at'];need(j['order']==assigned and load(f/'foreign-excluded.json')==j,'different excluded attempt');pre=f/'B/foreign-before.json'
            records=[load(pre)] if pre.exists() else load(f/'B/command.json')['observer_faults']
            need(records and all(z.get('foreign') and min(z['free'].values())>122<<30 and 'timeout' not in z for z in records),'exclusion was not observed foreign work')
        clocks={};source=None
        for rank,a in enumerate(assigned):
            dirname=f'p{i:02d}-a{obs["attempt"]}-{rank}-{a}';need(obs['dirs'][rank]==dirname,'different arm directory')
            d=root/dirname;b=d/'B';x=load(d/'result.json');clock=load(b/'command.json');product=load(b/'products.json');paths=load(b/'public-paths.json');edit=load(d/'edit.json');incoming=load(d/'incoming.json')
            need(load(d/'subject.json')==subjects[a] and x['driver']==clock['driver']==adm['arms'][a]['driver_sha256'] and incoming['source_identity']==adm['arms'][a]['source_identity'] and incoming['state']['manifest_sha256']==adm['arms'][a]['A_manifest'],'different compiler driver or A checkpoint')
            stamps0=load(b/'stamps-before.json');stamps1=load(b/'stamps-after.json')
            need(clock['stamps_before_sha256']==sha(b/'stamps-before.json') and clock['stamps_after_sha256']==sha(b/'stamps-after.json') and clock['changed_stamps']==sorted(k for k in stamps0.keys()|stamps1.keys() if stamps0.get(k)!=stamps1.get(k)) and clock['packages']==sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',(b/'cargo.log').read_text(),re.M)),'changed units do not match raw Cargo/stamp records')
            admitted=load(root/'admissions'/a/'command.json')
            need(clock['argv']==admitted['argv'] and all(clock[k]==admitted[k] for k in ('packages','changed_stamps')) and product==load(root/'admissions'/a/'products.json') and paths==load(root/'admissions'/a/'public-paths.json'),'different admitted command, roles or raw ELF')
            need(load(d/'retired.json')['identity']==incoming['identity'] and incoming['no_writable_inode_shared'] and incoming['source_identity']!=incoming['identity'] and x['arm']==a and x['edit']==name and x['command_sha256']==sha(b/'command.json') and x['products_sha256']==sha(b/'products.json') and x['paths_sha256']==sha(b/'public-paths.json') and x['edit_sha256']==sha(d/'edit.json'),'raw clock/output/source or physical copy substituted')
            need(clock['argv']==clock['actual_argv'] and clock['argv'][1:]==plan['ordinary_argv'] and clock['argv'][0].endswith('/sdk/bin/cargo') and not clock['traced'] and not clock['fingerprint_diagnostics'] and clock['exit']==0 and clock['observer_faults']==[] and clock['log_sha256']==sha(b/'cargo.log') and previous<clock['start_ns']<clock['end_ns'] and clock['end_ns']-clock['start_ns']==clock['elapsed_ns']==x['elapsed_ns'],'not the genuine ordinary complete command')
            previous=clock['end_ns'];clocks[a]=clock['elapsed_ns'];need(edit['before']['form']=='A' and edit['before']['blob']==e['A'] and edit['before']['sha256']==adm['source_blobs']['A'] and edit['after']['sha256']==adm['source_blobs']['B'] and edit['after']['form']=='B' and edit['after']['blob']==e['B'] and edit['after']['path']==e['path'] and edit['after']['oid']==plan['source_A'] and edit['after']==clock['source'] and clock['source']['sha256']==x['source_sha256'],'different edited workspace')
            if source is not None:need(source==edit['after'],'pair received different edit or mtime')
            source=edit['after'];signature=(source['oid'],source['ref'],source['path'],source['sha256'],source['blob'])
            if src is not None:need(signature==src,'edit varied over pairs')
            src=signature;need(set(paths)=={'tool','uv','uvx'} and {k:v['sha256'] for k,v in paths.items()}==product['elf_sha256'] and sha(b/'list.txt')==product['list_sha256']==e['B_list'] and len([x for x in (b/'list.txt').read_text().splitlines() if x.endswith(': test')])==e['B_count'],'wrong product or test inventory')
            if anchor is not None:need(anchor==product,'public raw ELFs, version or list differed')
            anchor=product;roster=[clock['changed_stamps'],clock['packages']]
            if a in baseroster:need(baseroster[a]==roster,'workload drifted within compiler arm')
            baseroster[a]=roster
        rows.append((assigned[0],clocks['C'],clocks[c]))
    if phase['phase']=='pilot':return {'pilot':True,'scored_rows':0,'ordinary_seconds':[rows[0][1]/1e9,rows[0][2]/1e9],'ratio':rows[0][1]/rows[0][2],'continues':rows[0][1]/rows[0][2]>=1.8}
    return score_times(rows)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--plan',type=Path,default=Path(__file__).with_name('protocol.json'));ap.add_argument('--extra',type=Path,default=Path(__file__).with_name('four-endpoints.json'));a=ap.parse_args();print(json.dumps(replay(a.root,load(a.plan),load(a.extra)),indent=2,sort_keys=True))
