# Rerun the full uv package after one real test edit

On Linux x86-64, the two compilers run this command from the same private workspace spelling.

```sh
cargo test --locked --offline -j8 -p uv --no-run
```

The new clone sets `core.abbrev=7` locally so its ordinary Git description matches `0.12.0-9-gc22e6b7`. The caller’s Git configuration stays untouched. The private branch remains at `c22e6b71933443e9cd299d4b6ac8de035ed4825b` throughout. The one edit restores `crates/uv/tests/tool/tool_list.rs` to its contents in parent `ddc1deb0c9f088ee0d6f4086110c0dd159849726`. It removes the 62-line test added in uv #20770. The actual test disappears from `--list` as `tool_list::tool_list_outdated_respects_configured_index`. The other source files, branch, Git version and Cargo.lock stay at the first revision. Both file blobs, the two actual tool listings and the exact execution orders are pinned in `package-original/`.

Use Python 3.11+, Git, GNU cp, a shared LLVM 18–22 library exporting the BLAKE3 C API, a quiet Linux x86-64 machine and an offline registry already populated for this uv revision. Make the original clone (including its `0.12.0` tag and this revision's history), the registry and both SDKs available as readable inputs. The runner creates a new `--run` directory outside these inputs. It fetches only from the local clone and gives both compilers the same private source, target, SDK and Cargo-home paths.

**Choose the compilers.** C contains the math-assembly recognition from Ohm Rust #270 on the released −20 Rust source. CZD adds the zeroization comment and the register-only x86-64 division forms. The direct repeat uses released-source P and the standalone P+ZD leaf. All members outside the single compiler driver must match within each pair, including Cargo, Wild, LLVM, target std and rustc launcher. The supplied `subjects.json` verifies the exact five original rebuilt SDK identities, each distinct from an independent source rebuild. Use the corresponding published binary bundle, or follow `REBUILD.md` and pass your generated `--subjects /path/to/independently-built-subjects.json` to each run. Keep the Cargo/LLVM/std choices matched. A vanilla distribution with another driver or release profile will fail the original-subject check.

```sh
sha256sum -c SHA256SUMS
/usr/bin/python3 -ISB test_package.py  # tiny script-backed Git/Cargo fixture; no native Rust build

/usr/bin/python3 -ISB package_rerun.py \
  --contrast CZD --control-sdk /opt/ohm/C --candidate-sdk /opt/ohm/CZD \
  --uv-clone /code/uv --cargo-home /cache/cargo --run /bench/uv-package-combined

/usr/bin/python3 -ISB package_score.py --combined /bench/uv-package-combined
```

Run the separate P/ZD comparison after the new combined result qualifies against 2× with a ten-comparison Holm adjustment. P uses the unmodified compiler source shipped in Ohm −20. ZD adds the two forms directly to that source. Supply each completed targeted run using `--prior-guard-run /path/to/targeted-run` for both direct collection and final scoring. Missing comparisons and both previously stopped full-package experiments receive p = 1.

```sh
/usr/bin/python3 -ISB package_rerun.py \
  --contrast ZD --control-sdk /opt/ohm/P --candidate-sdk /opt/ohm/ZD \
  --uv-clone /code/uv --cargo-home /cache/cargo \
  --combined-run /bench/uv-package-combined --run /bench/uv-package-direct

/usr/bin/python3 -ISB package_score.py \
  --combined /bench/uv-package-combined --direct /bench/uv-package-direct
```

**What is measured.** Each compiler cold-builds the unedited full package in its own new target and repeats twice to verify the settled program bytes, work and branch version. This reviewer route uses independent cold starts. The original guest runner starts from its independently authenticated single-tool P donor and expands the full package before creating arm-specific, B-never-primed checkpoints. The reviewer route uses ordinary GNU `cp -a --reflink=auto` to restore each arm's checkpoint at the same canonical name before the one-file edit. Each pair applies the same input and mtime to both private copies. Elapsed time spans only ordinary unwrapped Cargo, from process launch to foreground return. Checkpoint creation/copy, source verification, session drain, all full-file hashes, listings, resource guard checks and retained copy verification are outside the clock.

The combined run starts with two fresh admissions and an excluded pilot. A pilot of at least 1.8× opens 12 new paired measurements, six in each order. The run requires an exact paired lower confidence bound above 2×, a median above 2× in each order, and the registered sign and Holm tests. The independent P/ZD comparison has its own balanced 12-pair schedule and no pilot. Its eleven-comparison analysis keeps the two stopped package experiments at p = 1.

The control first records the 17 complete B executables and their behavior. Before the candidate sees B, it derives the two permitted full-file checksums for every eligible Wild-linked program. The two encodings use 0 and 8 for one entry width in the section header of a final x86-64 PIE. The full GNU build ID must agree with BLAKE3 of the original file with its complete 48-byte note cleared. Where two raw files differ, the verifier reconstructs both complete checksums in both directions. The section width lies outside all loadable segments. The build ID and section metadata remain externally observable. Other ELF forms require exact equality. Every run also checks all 15 test listings, each CLI version, the exact one-test edit, the compiler invocations and all remaining file bytes. Run `python3 -ISB test_wild_elf.py` for the verifier’s positive and negative controls.

`records/tool-test/{A,admission,pilot,pair-*}/` retains the unfiltered Cargo log, argv, source blob and mtime, every child resource delta from `wait4`, process-session drain, both complete fingerprint snapshots, all test listings, raw native-input dep-info, emitted product paths and digests. `objects/<sha256>` holds each distinct full output byte stream. The package replay hashes each distinct retained ELF independently. The observer samples visible same-user competing build tools every 200 ms, includes all its observed events, and can exclude a whole pair with recorded foreign activity only. It permits at most two replacement attempts, and retains the original attempts including any completed first arm. Foreground errors, wrong outputs, changed work, missing ownership and a different edit abort with their evidence. This portable observer cannot establish cross-user quiescence or detect sub-interval jobs. The original guest's host lease, two physical locks and external custody receipts remain specific to that machine.

**Space and environment.** Use a new, empty working path on a fast volume. On a filesystem without reflinks, an upper estimate for the working set is three fully warmed targets (two immutable inputs and one writable copy), the private registry, one SDK, the distinct raw A/B ELF collection, Git sources and link transients. The real single-tool warm target was around 3.9 GB per arm; the full-package target must be measured locally. Default limits are `--max-target-gib 16` per target and `--reserve-gib 10` free above the requested allocation estimates. These configurable reviewer limits differ from the preregistered physical guest reserves. The runner checks the actual A allocation and all 17 product sizes before each restore and bounds the final target after each command. A dedicated volume comfortably above the estimate or a native quota protects against transient unexpected allocations. Cold build costs, OS scheduling and backing-filesystem characteristics are machine-specific. Record the machine and filesystem when sharing results.

`README.md`, `REBUILD.md`, `SOURCE.md` and `source-observations.json` are the original single-tool/rebuild evidence. They describe the exact source patches and native assembler forms, including the downstream codegen-unit symbols. `package-original/targeted-SHA256SUMS` preserves the earlier packet's complete file list and hashes. This archive adds a reproducible experiment. Its offline smoke output is synthetic and does not estimate a speedup.

## Private checkout identity

Both runners set `core.abbrev=7` in their private source template and verify two real Git commands before building. At the pinned HEAD, `git describe --always` must return `c22e6b7` and `git describe --tags --always` must return `0.12.0-9-gc22e6b7`. The build script uses a separate nine-character short commit hash. Each runner writes the full result to `source-identity.json` and its offline scorer checks it. To verify independently with existing Git objects and no Cargo, run `python3 -ISB test_git_identity.py /path/to/uv`. The source clone must contain the genuine lightweight 0.12.0 tag.
