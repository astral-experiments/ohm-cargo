"""Capture the complete Cargo publication stream and raw behavior of all test programs."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

TOOL = 'tests/tool/main.rs'

def need(ok,msg):
    if not ok: raise ValueError(msg)

def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def load(path): return json.loads(Path(path).read_bytes())

def write(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,sort_keys=True,indent=2); f.write('\n')

def role_file(name): return name.replace('/','__').replace(' ','_')

def publications(text, source, target, roles):
    paths={}
    for line in text.splitlines():
        if not line.lstrip().startswith('Executable '): continue
        match=re.fullmatch(r'\s*Executable (.+?) \((.+)\)\s*',line)
        need(match is not None,'unparsed Cargo publication: '+line)
        name,filename=match.groups()
        need(name not in paths,'duplicate Cargo publication: '+name)
        program=(source/filename).resolve(strict=True)
        need(program.is_relative_to(target) and program.is_file(),'foreign Cargo output: '+line)
        paths[name]=program
    need(set(paths)==set(roles),f'actual Cargo targets {sorted(paths)} differ from {sorted(roles)}')
    for name in ('uv','uvx'):
        alias=target/'debug'/name
        need(alias.is_file() and alias.resolve().is_relative_to(target),'missing/local binary alias '+name)
        paths[name]=alias
    need(len({(p.stat().st_dev,p.stat().st_ino) for p in paths.values()})==len(paths),'two different program labels alias an inode')
    return paths

def capture(dest,source,target,roles,environment,invoke=subprocess.run):
    paths=publications((dest/'cargo.log').read_text(),source,target,roles)
    inventories=dest/'test-lists';inventories.mkdir()
    report={}
    for role,path in sorted(paths.items()):
        with path.open('rb') as f: header=f.read(20)
        need(len(header)==20 and header[:7]==b'\x7fELF\x02\x01\x01' and header[16:18] in (b'\x02\x00',b'\x03\x00') and header[18:20]==b'\x3e\x00',f'wrong x86_64 program: {role}')
        flags=['--list'] if role in roles else ['--version']
        proc=invoke([str(path),*flags],cwd=source,env=environment,capture_output=True,timeout=60)
        stem=inventories/role_file(role)
        out=Path(str(stem)+'.stdout');err=Path(str(stem)+'.stderr')
        out.write_bytes(proc.stdout);err.write_bytes(proc.stderr)
        need(proc.returncode==0,'program failed '+role)
        rows={'path':path.relative_to(target).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path),'stdout_sha256':sha(out),'stderr_sha256':sha(err),'exit':proc.returncode,'argv_tail':flags}
        if flags==['--list']:
            lines=proc.stdout.decode().splitlines()
            end=[x for x in lines if re.fullmatch(r'\d+ tests?, \d+ benchmarks?',x)]
            n=sum(s.endswith(': test') for s in lines);bench=sum(s.endswith(': benchmark') for s in lines)
            need(len(end)==1 and list(map(int,re.findall(r'\d+',end[0])))==[n,bench],f'incomplete --list for {role}')
            rows.update(tests=n,benchmarks=bench)
        report[role]=rows
    write(dest/'all-products.json',report)
    return report

def phase_change(a,b,aroot,broot,plan):
    need(a.keys()==b.keys(),'cross-form role names')
    for role in a:
        need(a[role]['path']==b[role]['path'],'changed published program path '+role)
        if role!=TOOL:
            need(a[role]['stdout_sha256']==b[role]['stdout_sha256'] and a[role]['stderr_sha256']==b[role]['stderr_sha256'],'unchanged CLI/list changed for '+role)
    t=plan['uv']['edit'];sa=a[TOOL];sb=b[TOOL]
    need((sa['stdout_sha256'],sa['tests'],sb['stdout_sha256'],sb['tests'])==(t['A_list'],t['A_count'],t['B_list'],t['B_count']),'wrong tool test inventory or size')
    def tests(folder): return {l for l in (folder/'test-lists'/(role_file(TOOL)+'.stdout')).read_text().splitlines() if l.endswith(': test')}
    old,new=tests(aroot),tests(broot)
    need(len(old-new)==1 and not new-old and sa['sha256']!=sb['sha256'],'registered edit must remove exactly one actual test and change its ELF')
    return sorted(old-new)
