"""Identify concurrent native build processes without collecting command lines or environment values."""
import os,threading,time
from pathlib import Path
NAMES={'cargo','rustc','rustdoc','wild','wild-ld','ld.bfd','ld.lld','collect2','cc1','cc1plus','clang','clang++','gcc','g++','as'}
class Busy(Exception): pass
def current_processes():
    result={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            uid=p.parent.stat().st_uid
            if uid!=os.getuid(): continue
            val=p.read_bytes();a,val=val.rsplit(b') ',1);name=a.partition(b' (')[2].decode(errors='replace');v=val.split()
            result[int(p.parent.name)]=(int(v[1]),int(v[3]),int(v[19]),name,v[0])
        except (FileNotFoundError,ProcessLookupError):continue
    return result
def outside(rows,me,known):
    owned={me};todo=set(rows)
    while todo:
        newer={p for p in todo if rows[p][0] in owned}
        if not newer:break
        owned.update(newer);todo-=newer
    for p in owned:
        if p in rows:
            # Cargo starts in a distinct session. Remember that session's exact process generation.
            sid=rows[p][1]
            if sid!=os.getsid(0) and sid in rows:
                known[sid]=rows[sid][2]
    foreign=[]
    for p,(_,sid,start,name,state) in rows.items():
        if p in owned or state in (b'Z',b'X') or name not in NAMES:continue
        if sid in known and (sid not in rows or known[sid]==rows[sid][2]):continue
        foreign.append({'pid':p,'start_ticks':start,'sid':sid,'name':name})
    return sorted(foreign,key=lambda x:x['pid'])
class Observer:
    def __init__(self):
        self.events=[];self.known={};self.stop=threading.Event();self.error=None
    def scan(self):
        when=time.monotonic_ns();found=outside(current_processes(),os.getpid(),self.known)
        if found:self.events.append({'ns':when,'foreign':found})
        return found
    def __enter__(self):
        self.scan()
        def run():
            try:
                while not self.stop.wait(.20): self.scan()
            except BaseException as e:self.error=repr(e)
        self.thread=threading.Thread(target=run,daemon=True);self.thread.start();return self
    def __exit__(self,*args):
        self.stop.set();self.thread.join();self.scan()
        if self.error:raise RuntimeError(self.error)
def clear_existing():
    end=time.monotonic()+90
    while outside(current_processes(),os.getpid(),{}):
        if time.monotonic()>=end:return False
        time.sleep(.5)
    return True
