"""Project the actually returned bootstrap evidence into the small portable driver manifest."""
import argparse
import json
import sys
from pathlib import Path

D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
from common import need, sha, write


def bind(closure, products, plan):
    need(closure["qualified"] is True and closure["outer"]["exit"] == 0 and closure["real_uv_samples"] == 0,
         "a real successful compiler/QA job is required")
    arms = {"C", "CZ"} | ({"CZD"} if closure["optional_CZD_sha256"] else set())
    all_arms = set(closure["sdk_receipts"])
    need(set(products) in (arms,all_arms) and all_arms in (arms, {"P","C","CZ","CZD","ZD"}), "missing or unqualified compiler")
    if all_arms != arms:
        need(all(set(closure[k]) == all_arms for k in ("drivers","source_sha256","sdk_manifest_paths","official_recipes"))
             and len(set(closure["drivers"].values())) == 5 and closure["export_outer"]["exit"] == 0
             and closure["actual_matrix_rows"] > 0 and closure["original_failed_outer_sha256"] ==
             "6c6efb0a2e8b9ec0a16b05c77de90a42d4e866b11508a0a5ae9ecb749afa4e0d",
             "incomplete recovered compiler/QA chain")
    out = {"provenance":"original-qualified-sdk-bytes", "bootstrap_outer": closure["outer"], "bootstrap_outer_sha256": closure["outer_sha256"],
           "worker_sha256": closure["worker_sha256"], "mandatory_sha256": closure["mandatory_sha256"],
           "optional_CZD_sha256": closure["optional_CZD_sha256"]}
    if all_arms != arms:
        out["original_failed_outer_sha256"] = closure["original_failed_outer_sha256"]
        out["export_outer_sha256"] = closure["export_outer_sha256"]
    for arm in sorted(products):
        receipt = products[arm]
        p = json.loads(receipt.read_bytes())
        driver = p["driver"]
        source = closure.get("source_sha256",{}).get(arm,p.get("source_sha256"))
        need(sha(receipt) == closure["sdk_receipts"][arm] and closure["drivers"][arm] == p["files"][driver],
             "unbound driver or SDK receipt")
        if arm=="P":
            tree=plan["subject_source_trees"]["P"]
            need(p["source"]==plan["rust_source_parent"] and p["stage"]==1 and source, "incorrect parent SDK/compile evidence")
        else:
            tree=p["source_tree"]
            need(tree==plan["subject_source_trees"][arm] and p["base"]==plan["rust_source_parent"] and
                 p["driver_sha256"]==p["files"][driver] and source==p["source_sha256"], "unbound source/driver pair")
        need(len(p["files"]) == 65 and p["version"] == plan["driver_version_prefix"] and
             "commit-hash: "+plan["cargo_commit"] in p["cargo_version"], "different reference SDK")
        shared = {name: h for name,h in p["files"].items() if name != driver}
        need(shared == out.setdefault("common_members", shared), "unmatched common member")
        out[arm] = {"driver_sha256": p["files"][driver], "source_sha256": source,
                    "sdk_receipt_sha256": sha(receipt), "tree": tree}
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--closed", required=True, type=Path)
    p.add_argument("--products", type=Path, help="optional relocated directory with <arm>/sdk.json")
    p.add_argument("--output", required=True, type=Path)
    a = p.parse_args()
    c = json.loads(a.closed.read_bytes())
    arms = set(c["sdk_receipts"]) & {"P", "C", "CZ", "CZD", "ZD"}
    inputs = {arm: a.products / arm / "sdk.json" if a.products else Path(c["sdk_manifest_paths"][arm]) for arm in arms}
    write(a.output, bind(c, inputs, json.loads((D / "workflow.json").read_bytes())))
