"""Synthetic producer-schema controls only. The temporary objects are not released SDKs."""
import copy
import json
import hashlib
import sys
import tempfile
from pathlib import Path

D=Path(__file__).resolve().parent
sys.path.insert(0,str(D))
from bind_subjects import bind
from common import need,sha,write
from rerun import read

def main():
    plan=read(D/"workflow.json");digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
    with tempfile.TemporaryDirectory(prefix="synthetic-paired-bind-") as w:
        r=Path(w);ds="lib/librustc_driver-test.so";p={};drivers={};receipts={}
        for arm in ("C","CZ","CZD"):
            files={str(i):digest(str(i)) for i in range(64)}
            files[ds]=drivers[arm]=digest(arm)
            doc={"source_tree":plan["subject_source_trees"][arm],"base":plan["rust_source_parent"],
                 "driver_sha256":drivers[arm],"files":files,"driver":ds,"version":plan["driver_version_prefix"],
                 "cargo_version":"commit-hash: "+plan["cargo_commit"],"source_sha256":digest("source-"+arm)}
            f=r/(arm+".json");write(f,doc);p[arm]=f;receipts[arm]=sha(f)
        c={"qualified":True,"real_uv_samples":0,"outer":{"exit":0},"optional_CZD_sha256":digest("optional"),
           "sdk_receipts":receipts,"drivers":drivers,"outer_sha256":digest("return"),"worker_sha256":digest("worker"),"mandatory_sha256":digest("QA")}
        assert bind(c,p,plan)["CZD"]["driver_sha256"]==drivers["CZD"]
        full=copy.deepcopy(c)
        for arm in ("P","ZD"):
            full["sdk_receipts"][arm]=digest("sdk-"+arm);full["drivers"][arm]=digest("dso-"+arm)
        names=full["sdk_receipts"].keys()
        full.update(source_sha256={k:digest("source-"+k) for k in names},sdk_manifest_paths={k:k for k in names},
                    official_recipes={k:digest("QA-"+k) for k in names},export_outer={"exit":0},
                    export_outer_sha256=digest("export-return"),actual_matrix_rows=113,
                    original_failed_outer_sha256="6c6efb0a2e8b9ec0a16b05c77de90a42d4e866b11508a0a5ae9ecb749afa4e0d")
        assert bind(full,p,plan)["export_outer_sha256"]==full["export_outer_sha256"]
        every=dict(p)
        for arm in ("P","ZD"):
            doc=copy.deepcopy(json.loads(p["CZD"].read_bytes()))
            doc["files"][doc["driver"]]=full["drivers"][arm]
            if arm=="P":
                doc["source"]=plan["rust_source_parent"];doc["stage"]=1
                for k in ("base","source_tree","driver_sha256","source_sha256"):doc.pop(k,None)
            else:
                doc.update(source_tree=plan["subject_source_trees"][arm],driver_sha256=full["drivers"][arm],source_sha256=full["source_sha256"][arm])
            f=r/(arm+".json");write(f,doc);every[arm]=f;full["sdk_receipts"][arm]=sha(f)
        binder=bind(full,every,plan)
        assert binder["P"]["tree"]==plan["subject_source_trees"]["P"] and binder["ZD"]["driver_sha256"]==full["drivers"]["ZD"]

        for key in ("failed","missing","wrong-source","bad-sha"):
            bad=copy.deepcopy(c)
            if key=="failed":bad["outer"]["exit"]=1
            if key=="missing":bad["optional_CZD_sha256"]=None
            if key=="wrong-source":bad["drivers"]["C"]="0"*64
            if key=="bad-sha":bad["sdk_receipts"]["CZ"]="0"*64
            try:bind(bad,p,plan)
            except ValueError:continue
            raise AssertionError(key)
        del c["sdk_receipts"]["CZD"];c["optional_CZD_sha256"]=None
        assert "CZD" not in bind(c,{k:v for k,v in p.items() if k!="CZD"},plan)
    print("PASS synthetic binder: mandatory and optional complete SDKs, failed and incomplete sources/returns rejected")
if __name__=="__main__":main()
