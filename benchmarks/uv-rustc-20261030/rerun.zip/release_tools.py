"""Materialize only the eight fixed, SHA-verified host linker helpers from the released Ohm archive."""
import argparse
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import need,sha
PLAN=json.loads((Path(__file__).resolve().parent/"source/sources.json").read_bytes())

def install(archive,dest,plan=PLAN):
    need(not dest.exists() and sha(archive)==plan["release_sha256"],"wrong release archive or existing directory")
    dest.mkdir(mode=0o700,parents=True)
    with tarfile.open(archive,"r:*") as t:
        members=t.getmembers()
        for rel,required in plan["stock_tools"].items():
            needle=PurePosixPath(rel)
            need(not needle.is_absolute() and ".." not in needle.parts and rel.startswith("lib/rustlib/"),"invalid support path")
            matches=[m for m in members if (m.name==rel or m.name.endswith("/"+rel)) and (m.isreg() or m.islnk() or m.issym())]
            need(len(matches)==1,"missing or ambiguous support member "+rel)
            source=t.extractfile(matches[0]);need(source is not None,"no support-file data")
            out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True)
            with source,out.open("xb") as f:
                while data:=source.read(1024*1024):f.write(data)
            need(sha(out)==required,"wrong release support bytes "+rel);out.chmod(0o755)
    return dest

if __name__=="__main__":
    a=argparse.ArgumentParser(description=__doc__);a.add_argument("archive",type=Path);a.add_argument("destination",type=Path)
    o=a.parse_args();print(install(o.archive,o.destination))
