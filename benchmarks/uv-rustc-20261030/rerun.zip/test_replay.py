"""Tiny fake SDK and private Git repo. No real Rust/Cargo processes, native measurements or retained fake rows."""
import argparse
import copy
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
import rerun as r
import score as s
from common import need, sha, write


def executable(p, body):
    p.parent.mkdir(exist_ok=True, parents=True)
    p.write_text("#!/usr/bin/python3\n" + body)
    p.chmod(0o755)


def one(temp):
    base = temp / "original"
    base.mkdir()
    plan = copy.deepcopy(r.read(D / "workflow.json"))
    def commit(label):
        r.git(base, "add", ".")
        r.git(base, "-c", "user.name=Fiber", "-c", "user.email=fixture@invalid.example",
              "commit", "-qm", label)
        return r.git(base, "rev-parse", "HEAD").decode().strip()
    r.git(base, "init", "-q", "--template=", "--initial-branch=fixture")
    (base / "Cargo.lock").write_text("# fixture\n")
    (base / "Cargo.toml").write_text("[workspace]\n")
    for edit, p in plan["endpoints"].items():
        p["path"] = f"src/{edit}.rs"
        src = base / p["path"]
        src.parent.mkdir(exist_ok=True)
        src.write_text("B\n")
        p["B"] = r.blob(src.read_bytes())
    plan["parent"] = commit("prior")
    r.git(base, "tag", "0.12.0")
    for p in plan["endpoints"].values():
        src = base / p["path"]
        src.write_text("A\n")
        p["A"] = r.blob(src.read_bytes())
    A = commit("A integration")
    plan["A"]["git_description"] = r.git(base,"-c","core.abbrev=7","log","-1","--date=short","--abbrev=9","--format=%H %h %cd %(describe:tags)").decode().strip()
    plan["A"].update(commit=A, tree=r.git(base,"rev-parse","HEAD^{tree}").decode().strip(),
                     self_version={"fixture_commit": A}, version="synthetic fixture")
    # Leave the caller's actual checkout dirty. The replay must read the pinned Git objects only.
    (base / "src/settings.rs").write_text("unrelated dirty user input\n")
    (base / "do-not-read").write_bytes(b"user data")
    lists = {"A": b"old: test\nnew: test\n", "B": b"old: test\n"}
    for edit, p in plan["endpoints"].items():
        for state in ("A","B"):
            text = lists["B" if edit=="tool-test" and state=="B" else "A"]
            p[state+"_count"], p[state+"_list"] = len(text.splitlines()), hashlib.sha256(text).hexdigest()
    cache = temp / "original-cache"
    (cache / "registry").mkdir(parents=True)
    (cache / "registry/inert").write_text("private registry input")
    sdk = temp / "sdk-C"
    dso = Path("lib/librustc_driver-fixture.so")
    (sdk / dso).parent.mkdir(parents=True)
    (sdk / dso).write_text("C")
    executable(sdk / "lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd", "raise SystemExit(81)\n")
    executable(sdk / "bin/rustc", "print("+repr(plan["driver_version_prefix"])+", end='')\n")
    body = '''import json,os,sys
from pathlib import Path
if sys.argv[1:]==["-vV"]:
    print("commit-hash: CARGO_ID");sys.exit()
assert sys.argv[1:]==COMMAND
a=Path(__file__).resolve().parents[1].joinpath("DSO").read_text()
t=Path(os.environ["CARGO_TARGET_DIR"])
src=Path.cwd()/"src"
tool_b=(src/"tool-test.rs").read_text().strip()=="B"
settings_b=(src/"settings.rs").read_text().strip()=="B"
if tool_b or settings_b:
    seen=t/"B-seen"; assert not seen.exists(), "caller reused a B cache"; seen.touch()
    unit=t/"debug/build/uv/id"; f=unit/"fingerprint";f.mkdir(exist_ok=True,parents=True);(f/"invoked.timestamp").touch()
    d=unit/"out";d.mkdir(exist_ok=True)
    (d/"fixture.d").write_text("tool: "+("crates/uv/tests/tool/main.rs src/tool-test.rs" if tool_b else "crates/uv/src/lib.rs src/settings.rs"))
    print("  Compiling uv v0")
for pkg in ("libm","zeroize","num-bigint","num-bigint-dig","rsa","secret-service"):
    unit=t/"debug/build"/pkg/"id"; d=unit/"out";d.mkdir(exist_ok=True,parents=True)
    opaque=(a in ("P","ZD") and pkg=="libm") or (a in ("P","C") and pkg in ("zeroize","rsa","num-bigint-dig")) or (a in ("P","C","CZ") and pkg in ("num-bigint","secret-service"))
    (d/(pkg+".d")).write_text("unit: "+("/dev/null/ohm-untracked-relink-inputs" if opaque else "/dev/null/ohm-recheck-dependent-links")+"\\n")
    if opaque:
        f=unit/"fingerprint";f.mkdir(exist_ok=True);(f/"invoked.timestamp").touch();print("  Compiling "+pkg+" v0")
def emit(p,s):
    p.parent.mkdir(exist_ok=True,parents=True);p.write_text("#!/usr/bin/python3\\n"+s);p.chmod(0o755)
tool=t/"debug/build/uv/id/out/tool-0123456789abcdef"
emit(tool, "print("+repr("old: test" if tool_b else "old: test\\nnew: test")+")\\n")
v=repr(INFO);body="import sys\\nif sys.argv[1:]==['--version']: print('synthetic fixture')\\nelse: print("+repr(json.dumps(INFO))+")\\n"
emit(t/"debug/uv",body+("# changed settings\\n" if settings_b else ""));emit(t/"debug/uvx",body)
print(f"  Executable tests/tool/main.rs ({tool})")
'''
    body = body.replace("CARGO_ID",plan["cargo_commit"]).replace("COMMAND",repr(plan["command"])).replace("DSO",str(dso)).replace("INFO",repr(plan["A"]["self_version"]))
    executable(sdk / "bin/cargo", body)
    candidate = temp / "sdk-CZD"
    shutil.copytree(sdk,candidate)
    (candidate / dso).write_text("CZD")
    subjects = {arm: {"tree": plan["subject_source_trees"][arm], "driver_sha256": sha(directory/dso)}
                for arm, directory in (("C",sdk),("CZD",candidate))}
    subjects["common_members"] = {p.relative_to(sdk).as_posix(): sha(p) for p in sdk.rglob("*")
                                   if p.is_file() and p.relative_to(sdk) != dso}
    write(temp / "subjects.json", subjects)
    # Fixed fake wall clocks in an isolated test. No speed inference from Python processes.
    original_elf, original_ns = r.ELF, r.time.monotonic_ns
    r.ELF = b"#!"
    counter = [0, 0]
    run = temp / "private-replay"
    def clock():
        counter[0] += 1
        working = run / "active/source/src/tool-test.rs"
        base_edit = (run/"sdk"/dso).read_text()=="C" and working.read_bytes()==b"B\n"
        counter[1] += 300 if counter[0]%2==0 and base_edit else 100
        return counter[1]
    r.time.monotonic_ns = clock
    try:
        args = argparse.Namespace(contrast="CZD", run=run, uv_clone=base, cargo_home=cache, control_sdk=sdk,
                                  candidate_sdk=candidate, subjects=temp/"subjects.json", reserve_gib=0)
        rep = r.Replay(args, plan)
        rep.setup()
        for edit in ("tool-test","settings"):
            rep.endpoint(edit)
        write(run/"complete.json",{"contrast":"CZD","edits":["tool-test","settings"],"workflow_sha256":sha(D/"workflow.json")})
        cells = s.one_run(run,plan)
        out = s.family(cells)
        assert cells["CZD/tool-test"]["pairs"]==12 and out["CZD/tool-test"]["confirmed"]
        assert cells["CZD/settings"]["pairs"]==0 and not out["CZD/settings"]["confirmed"]
        assert out["CZ/tool-test"]["raw_p"]==1 and out["CZD/tool-test"]["holm_p"]==4*2/4096
        assert (base/"src/settings.rs").read_text()=="unrelated dirty user input\n" and (base/"do-not-read").is_file()
        assert (sdk/dso).read_text()=="C" and (candidate/dso).read_text()=="CZD" and (cache/"registry/inert").read_text()=="private registry input"
        def rejects(fn):
            try: fn()
            except (ValueError, FileNotFoundError): return
            raise AssertionError("accepted a deliberately corrupt result")
        paths=sorted((run/"records/tool-test/pair-00").iterdir())
        p=paths[0]/"command.json"; raw=p.read_bytes();obj=json.loads(raw);obj["actual_argv"].append("--ignored");p.write_text(json.dumps(obj));rejects(lambda:s.one_run(run,plan));p.write_bytes(raw)
        p=paths[0]/"list.txt";raw=p.read_bytes();p.write_bytes(b"false: test\n");rejects(lambda:s.one_run(run,plan));p.write_bytes(raw)
        p=next((run/"objects").iterdir()); raw=p.read_bytes();p.write_bytes(b"x"*len(raw));rejects(lambda:s.one_run(run,plan));p.write_bytes(raw)
        paths[0].rename(paths[0].with_name("wrong-order"));rejects(lambda:s.one_run(run,plan));paths[0].with_name("wrong-order").rename(paths[0])
        f=run/"source-identity.json";saved=f.read_bytes();bad=json.loads(saved);bad["describe_always"]="bad";f.write_text(json.dumps(bad));rejects(lambda:s.one_run(run,plan));f.write_bytes(saved)
        assert s.one_run(run,plan)==cells
        require=s.leaf_eligibility([run],[],plan)
        assert require["qualifies"] and set(require["combined_scores"])=={"CZD/tool-test"}
        rejects(lambda:s.leaf_eligibility([],[],plan))
        control=temp/"sdk-P";leaf=temp/"sdk-ZD"
        for root,arm in ((control,"P"),(leaf,"ZD")):
            shutil.copytree(sdk,root);(root/dso).write_text(arm)
            subjects[arm]={"tree":plan["subject_source_trees"][arm],"driver_sha256":sha(root/dso)}
        write(temp/"leaf-subjects.json",subjects)
        run=temp/"leaf-run"
        args=argparse.Namespace(contrast="ZD",run=run,uv_clone=base,cargo_home=cache,control_sdk=control,
                                candidate_sdk=leaf,subjects=temp/"leaf-subjects.json",reserve_gib=0)
        rep=r.Replay(args,plan);write(run/"leaf-eligibility.json",require)
        rep.setup();rep.endpoint("tool-test")
        write(run/"complete.json",{"contrast":"ZD","edits":["tool-test"],"workflow_sha256":sha(D/"workflow.json")})
        measured=s.one_run(run,plan)
        direct=measured["ZD/tool-test"]
        assert direct["pairs"]==12 and direct["summary"]["P_seconds_median"]>0 and not direct["summary"]["individual_gate"]
        assert direct["summary"]["per_order_ratio_medians"]=={"P-first":1,"candidate-first":1}
        result=s.session_holm(cells|measured)
        assert len(result)==7 and result["CZD/tool-test"]["holm_p"]==7*2/4096 and not result["ZD/tool-test"]["confirmed"]
        assert (control/dso).read_text()=="P" and (leaf/dso).read_text()=="ZD"
    finally:
        r.ELF, r.time.monotonic_ns = original_elf, original_ns


if __name__=="__main__":
    with tempfile.TemporaryDirectory(prefix="synthetic-guard-review-") as tmp:
        one(Path(tmp))
    print("PASS synthetic only: two real Git states, 12 fake combined pairs / pilot stop, twelve independent null P→ZD pairs, raw content/clock/argv/order corruption, exact four/seven Holm families. No Rust or Cargo invocation.")
