"""Rerun one source-verified compiler contrast on fresh uncommitted uv edits. Python 3.11+."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import tomllib
from pathlib import Path
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from git_identity import private_identity
from common import allocated, copy, need, sdk_files, sha, stamps, version_output, write

ELF = b"\x7fELF"
KNOWN = {"libm", "zeroize", "num-bigint", "num-bigint-dig", "rsa", "secret-service"}
POISON = b"/dev/null/ohm-untracked-relink-inputs"
RECHECK = b"/dev/null/ohm-recheck-dependent-links"


def read(path):
    return json.loads(path.read_bytes())


def blob(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def git(path, *args):
    env = {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "GIT_CONFIG_NOSYSTEM": "1",
           "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0", "GIT_NO_LAZY_FETCH": "1",
           "GIT_ALLOW_PROTOCOL": "file"}
    return subprocess.check_output(["git", "-C", path, "-c", "core.hooksPath=/dev/null", *args], env=env)


def baseline(candidate):
    return "P" if candidate == "ZD" else "C"

def policy(arm, opaque):
    return ("libm" in opaque) == (arm in ("P","ZD")) and ("zeroize" in opaque) == (arm in ("P","C"))

def check_versions(plan, subjects, actual):
    if subjects.get("provenance") == "independent-source-build":
        return (actual == subjects["versions"] and subjects["source_parent"] == plan["rust_source_parent"]
                and subjects["source_spec_sha256"] == sha(HERE/"source/sources.json")
                and "commit-hash: "+plan["rust_source_parent"] in actual["rustc"]
                and "commit-hash: "+plan["cargo_commit"] in actual["cargo"])
    return (actual["rustc"].splitlines()[:7] == plan["driver_version_prefix"].splitlines()[:7]
            and "commit-hash: "+plan["cargo_commit"] in actual["cargo"])

def schedule(plan, edit, candidate):
    if candidate == "ZD":
        need(edit == "tool-test","the independent leaf only registered the integration edit")
        f = HERE/"source/direct-leaf-plan.json"
        need(sha(f)==plan["direct_leaf_registration_sha256"],"changed independent leaf order")
        orders=[[x,"ZD" if x=="P" else "P"] for x in read(f)["first_in_pair"]]
        return {"pilot_order":orders[0],"pairs":orders}
    return plan["endpoints"][edit] if candidate == "CZ" else plan["CZD_schedules"][edit]

def drain_session(session):
    start = time.monotonic()
    seen = set()
    while True:
        live = []
        for p in Path("/proc").glob("[0-9]*/stat"):
            try:
                fields = p.read_bytes().rsplit(b") ", 1)[1].split()
            except (FileNotFoundError, ProcessLookupError):
                continue
            if int(fields[3]) == session and fields[0] not in (b"Z", b"X"):
                live.append((int(p.parent.name), int(fields[19])))
        seen.update(live)
        if not live or time.monotonic()-start > 15:
            return {"session": session, "observed": sorted(seen), "remaining": live, "seconds": time.monotonic()-start}
        time.sleep(.02)

def registry_configuration(path):
    cfg = tomllib.loads(path.read_text())
    need(set(cfg) <= {"source", "registries", "net"} and set(cfg.get("net", {})) <= {"offline", "retry"},
         f"registry remapping only in {path}")
    for s in cfg.get("source", {}).values():
        need(set(s) <= {"registry", "replace-with"}, "external path, Git registry or unknown source setting")
    for s in cfg.get("registries", {}).values():
        need(set(s) <= {"index", "protocol"}, "credentials or custom registry provider")
    for table in ("source", "registries"):
        for s in cfg.get(table, {}).values():
            for key in ("index", "registry"):
                if key in s:
                    url = urlsplit(s[key].removeprefix("sparse+"))
                    need(url.scheme in ("http", "https") and not (url.username or url.password or url.query),
                         "supply a public registry URL with no credentials or query parameters")


def markers(target, raw_dir=None):
    records, opaque = {}, []
    if raw_dir is not None:
        raw_dir.mkdir()
    for p in sorted((target / "debug/build").glob("*/*/out/*.d")):
        name = p.parent.parent.parent.name
        data = p.read_bytes()
        if POISON in data:
            opaque.append(p.relative_to(target).as_posix())
        if name in KNOWN:
            need(name not in records, f"ambiguous native output for {name}")
            records[name] = {"path": p.relative_to(target).as_posix(), "sha256": hashlib.sha256(data).hexdigest(),
                             "opaque": POISON in data, "recheck_link": RECHECK in data}
            if raw_dir is not None:
                (raw_dir / (name+".d")).write_bytes(data)
    need(records.keys() == KNOWN, "missing target units or different Cargo output layout")
    return {"units": records, "all_opaque_paths": opaque}


class Replay:
    def __init__(self, args, plan):
        self.plan, self.candidate = plan, args.contrast
        self.control = baseline(args.contrast)
        self.root = args.run.resolve()
        self.clone, self.cache = args.uv_clone.resolve(strict=True), args.cargo_home.resolve(strict=True)
        self.sdks = {self.control: args.control_sdk.resolve(strict=True), self.candidate: args.candidate_sdk.resolve(strict=True)}
        inputs = [self.clone, self.cache, *self.sdks.values()]
        need(not self.root.exists() and all(not self.root.is_relative_to(p) and not p.is_relative_to(self.root) for p in inputs),
             "use a new directory outside all supplied inputs")
        self.root.mkdir(parents=True, mode=0o700)
        inherited = [p for parent in (self.root, *self.root.parents) for name in ("config", "config.toml")
                     if (p := parent / ".cargo" / name).is_file()]
        for p in inherited:
            registry_configuration(p)
        self.active, self.sdk = self.root / "active", self.root / "sdk"
        self.src, self.target = self.active / "source", self.active / "target"
        self.reserve = args.reserve_gib * 2**30
        self.subjects = read(args.subjects)
        if self.subjects.get("provenance")=="independent-source-build":
            from rebuild import verify_subjects
            verify_subjects(args.subjects, self.sdks)
        self.env = {"PATH": f"{self.sdk}/bin:/usr/bin:/bin", "CARGO_HOME": str(self.active / "cargo-home"),
                    "HOME": str(self.active / "home"), "TMPDIR": str(self.active / "tmp"),
                    "CARGO_TARGET_DIR": str(self.target), "CARGO_NET_OFFLINE": "true", "CARGO_TERM_COLOR": "never",
                    "RUSTC": str(self.sdk / "bin/rustc"), "LC_ALL": "C.UTF-8", "TZ": "UTC",
                    "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0",
                    "GIT_ALLOW_PROTOCOL": "file", "GIT_NO_LAZY_FETCH": "1"}
        self.cmd = [str(self.sdk / "bin/cargo"), *self.plan["command"]]
        for name in ("sources", "seeds", "records", "objects"):
            (self.root / name).mkdir()
        self.cores = sorted(os.sched_getaffinity(0))
        write(self.root / "inputs.json", {"contrast": self.candidate, "argv": self.cmd, "affinity": self.cores,
              "reserve_bytes": self.reserve, "untracked_sources_read": False, "root": str(self.root),
              "source": str(self.clone), "sdks": {a: str(p) for a, p in self.sdks.items()},
              "inherited_registry_config_sha256": {str(p): sha(p) for p in inherited},
              "subject_provenance": self.subjects, "workflow_sha256": sha(HERE / "workflow.json"),
              "clock": "CLOCK_MONOTONIC, immediately before Popen through wait4 of ordinary Cargo"})

    def space(self, additional=0):
        need(shutil.disk_usage(self.root).free > self.reserve + additional, "insufficient private replay space")

    def setup(self):
        maps = {arm: sdk_files(path) for arm, path in self.sdks.items()}
        a, b = maps[self.control], maps[self.candidate]
        diffs = [p for p in a if a[p] != b.get(p)]
        need(a.keys() == b.keys() and len(diffs) == 1 and re.fullmatch(r"lib/librustc_driver[^/]*\.so", diffs[0]),
             "SDKs must differ only in one rustc driver")
        self.driver = diffs[0]
        common = {name: entry.get("sha256") for name, entry in a.items() if name != self.driver}
        need(common == self.subjects["common_members"] and None not in common.values(), "unattested SDK member")
        for arm, files in maps.items():
            expected = self.subjects[arm]
            need(expected["tree"] == self.plan["subject_source_trees"][arm] and
                 expected["driver_sha256"] == files[self.driver]["sha256"], f"unattested {arm} compiler")
        need("bin/cargo" in a and "bin/rustc" in a and any(p.endswith("/wild-ld/ld.bfd") for p in a), "SDK tools")
        write(self.root / "sdk-manifests.json", maps)
        self.space(allocated(self.sdks[self.control]) + allocated(self.cache / "registry"))
        copy(self.sdks[self.control], self.sdk)
        registry = self.root / "registry"
        copy((self.cache / "registry").resolve(strict=True), registry)
        need(all(p.resolve().is_relative_to(registry) for p in registry.rglob("*") if p.is_symlink()),
             "private registry links outside the replay")
        template = self.root / "source-template"
        template.mkdir()
        git(template, "init", "-q", "--template=", "--initial-branch=seed")
        A = self.plan["A"]["commit"]
        git(template, "-c", "protocol.file.allow=always", "fetch", "-q", "--no-tags", str(self.clone),
            f"{A}:refs/heads/feature-A", "refs/tags/0.12.0:refs/tags/0.12.0")
        git(template, "switch", "-q", "feature-A")
        write(self.root / "source-identity.json", private_identity(template, self.plan, git))
        need(git(template, "rev-parse", "HEAD^{tree}").decode().strip() == self.plan["A"]["tree"] and
             git(template, "rev-parse", "HEAD^").decode().strip() == self.plan["parent"], "wrong uv history")
        for edit, e in self.plan["endpoints"].items():
            for state, commit in (("A", A), ("B", self.plan["parent"])):
                data = git(template, "show", f"{commit}:{e['path']}")
                need(blob(data) == e[state], "wrong file or Git blob")
                (self.root / "sources" / f"{edit}-{state}.rs").write_bytes(data)
        copy(template / "Cargo.lock", self.root / "sources/Cargo.lock")

    def select(self, arm):
        p = self.sdk / self.driver
        if sha(p) != self.subjects[arm]["driver_sha256"]:
            tmp = p.with_suffix(".next")
            copy(self.sdks[arm] / self.driver, tmp)
            os.replace(tmp, p)
        need(sha(p) == self.subjects[arm]["driver_sha256"], "failed driver selection")

    def config(self):
        home = self.active / "cargo-home"
        (home / "registry").symlink_to(self.root / "registry", target_is_directory=True)
        configs = [self.cache / n for n in ("config.toml", "config") if (self.cache / n).exists()]
        need(len(configs) <= 1, "ambiguous input Cargo configuration")
        if configs:
            registry_configuration(configs[0])
            copy(configs[0], home / "config.toml")

    def source(self, edit, state):
        e = self.plan["endpoints"][edit]
        p = self.src / e["path"]
        need(git(self.src, "rev-parse", "HEAD").decode().strip() == self.plan["A"]["commit"] and
             git(self.src, "symbolic-ref", "--short", "HEAD").strip() == b"feature-A", "changed Git revision or ref")
        expected = b"" if state == "A" else (" M " + e["path"] + "\0").encode()
        need(git(self.src, "status", "--porcelain=v1", "-z", "--untracked-files=all") == expected and
             blob(p.read_bytes()) == e[state] and sha(self.src / "Cargo.lock") == sha(self.root / "sources/Cargo.lock"),
             "unexpected edit, untracked file or lockfile")
        return {"path": e["path"], "state": state, "blob": e[state], "sha256": sha(p), "mtime_ns": p.stat().st_mtime_ns}

    def products(self, folder, edit, state, text):
        hits = re.findall(r"(?m)^\s*Executable .*? \(([^\r\n]+)\)\s*$", text)
        need(len(hits) == 1, "Cargo did not name exactly one test executable")
        test = Path(hits[0])
        if not test.is_absolute():
            test = self.src / test
        paths = {"tool": test, "uv": self.target / "debug/uv", "uvx": self.target / "debug/uvx"}
        evidence = {}
        for k, p in paths.items():
            p = p.resolve(strict=True)
            with p.open("rb") as f:
                need(p.is_relative_to(self.target) and f.read(len(ELF)) == ELF and os.access(p, os.X_OK), "non-native or unrelated output")
            h = sha(p)
            obj = self.root / "objects" / h
            if not obj.exists():
                self.space(p.stat().st_size)
                copy(p, obj)
                need(sha(obj) == h, "retained output copy differs")
            evidence[k] = {"path": str(p.relative_to(self.target)), "bytes": p.stat().st_size, "sha256": h}
        data = version_output([test, "--list"], self.env, self.src)
        (folder / "list.txt").write_bytes(data)
        e = self.plan["endpoints"][edit]
        need(sha(folder / "list.txt") == e[state+"_list"] and sum(s.endswith(b": test") for s in data.splitlines()) == e[state+"_count"], "wrong actual test inventory")
        info = json.loads(version_output([paths["uv"], "self", "version", "--output-format", "json"], self.env, self.src))
        version = version_output([paths["uv"], "--version"], self.env, self.src).decode().strip()
        need(info == self.plan["A"]["self_version"] and version == self.plan["A"]["version"], "wrong actual A revision/version")
        write(folder / "public-paths.json", evidence)
        return {"files": evidence, "list_sha256": sha(folder / "list.txt"), "self_version": info, "version": version}

    def cargo(self, arm, edit, state, folder):
        folder.mkdir(parents=True)
        source = self.source(edit, state)
        before = stamps(self.target)
        self.space()
        with (folder / "cargo.log").open("xb") as log:
            start = time.monotonic_ns()
            p = subprocess.Popen(self.cmd, cwd=self.src, env=self.env, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
            _, status, ru = os.wait4(p.pid, 0)
            end = time.monotonic_ns()
            p.returncode = os.waitstatus_to_exitcode(status)
        drained = drain_session(p.pid)
        text = (folder / "cargo.log").read_text(errors="replace")
        after = stamps(self.target)
        record = {"arm": arm, "endpoint": edit, "source": source, "actual_argv": self.cmd, "pid": p.pid,
                  "start_ns": start, "end_ns": end, "elapsed_ns": end-start, "exit": p.returncode,
                  "post_foreground": drained,
                  "packages": sorted(re.findall(r"(?m)^\s*Compiling ([^\s]+)", text)),
                  "changed_stamps": sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k)),
                  "rusage_wait4": {k: getattr(ru, k) for k in ("ru_utime", "ru_stime", "ru_minflt", "ru_majflt", "ru_nvcsw", "ru_nivcsw", "ru_inblock", "ru_oublock", "ru_maxrss")},
                  "log_sha256": sha(folder / "cargo.log")}
        write(folder / "command.json", record)
        need(p.returncode == 0 and not drained["remaining"], f"Cargo failed or a child remained; evidence in {folder}")
        if state == "B":
            owner = "crates/uv/tests/tool/main.rs" if edit == "tool-test" else "crates/uv/src/lib.rs"
            folder.joinpath("owner-depinfo").mkdir()
            witnesses = {}
            for stamp in record["changed_stamps"]:
                unit = (self.target / stamp).parent.parent
                if unit.parent.name != "uv":
                    continue
                for dep in (unit / "out").glob("*.d"):
                    raw = dep.read_bytes()
                    if owner.encode() in raw and source["path"].encode() in raw:
                        key = dep.relative_to(self.target).as_posix()
                        h = hashlib.sha256(raw).hexdigest()
                        (folder / "owner-depinfo" / h).write_bytes(raw)
                        witnesses[key] = h
            write(folder / "edited-owner.json", {"crate_root": owner, "depfiles": witnesses})
            need("uv" in record["packages"] and witnesses, "edited uv compilation absent from ordinary Cargo evidence")
        product = self.products(folder, edit, state, text)
        write(folder / "products.json", product)
        need(self.source(edit, state) == source, "source changed during Cargo")
        return (record["packages"], record["changed_stamps"]), product

    def same_products(self, left, right):
        return left == right

    def prime(self, edit, arm):
        self.select(arm)
        self.active.mkdir()
        for name in ("target", "home", "tmp", "cargo-home"):
            (self.active / name).mkdir()
        self.config()
        copy(self.root / "source-template", self.src)
        logs = self.root / "records" / edit / "A" / arm
        versions = {exe: version_output([self.sdk / "bin" / exe, "-vV"], self.env, self.src).decode() for exe in ("rustc", "cargo")}
        need(check_versions(self.plan,self.subjects,versions), "different compiler family or Cargo")
        # Cold A plus two natural repeats. Some control compilers genuinely keep rebuilding at A.
        self.cargo(arm, edit, "A", logs / "cold")
        repeat = self.cargo(arm, edit, "A", logs / "ordinary-repeat")
        verified = self.cargo(arm, edit, "A", logs / "verify-repeat")
        need(repeat[0] == verified[0] and self.same_products(repeat[1], verified[1]), "A products or compilation work did not settle")
        marker = markers(self.target, logs / "raw-depinfo")
        need(policy(arm,{p for p,r in marker["units"].items() if r["opaque"]}),
             "actual A dep-info does not exhibit the assigned compiler policy")
        seed = self.root / "seeds" / f"{edit}-{arm}"
        self.active.rename(seed)
        write(logs / "seed.json", {"arm": arm, "edit": edit, "seed": str(seed), "B_seen": False,
              "versions": versions, "markers": marker, "driver_sha256": self.subjects[arm]["driver_sha256"],
              "source_sha256": sha(seed / "source" / self.plan["endpoints"][edit]["path"]),
              "repeat_sha256": sha(logs / "verify-repeat/products.json")})
        self.space(allocated(seed))
        return verified[1]

    def trial(self, edit, arm, folder, stamp):
        self.select(arm)
        seed = self.root / "seeds" / f"{edit}-{arm}"
        self.space(allocated(seed))
        copy(seed, self.active)
        git(self.src, "update-index", "--really-refresh")
        expected = self.source(edit, "A")
        p = self.src / expected["path"]
        need(not p.samefile(seed / "source" / expected["path"]) and expected["mtime_ns"] < stamp <= time.time_ns(), "shared or stale source")
        p.write_bytes((self.root / "sources" / f"{edit}-B.rs").read_bytes())
        os.utime(p, ns=(stamp, stamp))
        result = self.cargo(arm, edit, "B", folder)
        if folder.parent.name == "admission":
            write(folder / "markers.json", markers(self.target, folder / "raw-depinfo"))
        need(p.stat().st_mtime_ns == stamp and sha(seed / "source" / expected["path"]) == expected["sha256"],
             "seed mutated or filesystem cannot preserve paired edit mtime")
        write(folder / "source-A.json", expected)
        # The root and all mutable inputs were created by this process. A failed cell remains intact.
        shutil.rmtree(self.active)
        return result

    def endpoint(self, edit):
        order = schedule(self.plan, edit, self.candidate)
        original = [self.prime(edit, a) for a in order["pilot_order"]]
        need(original[0] == original[1], "A byte/behavior mismatch across compilers")
        admitted = {}
        def pair(label, arms):
            stamp, times, products = time.time_ns(), {}, []
            for rank, arm in enumerate(arms):
                folder = self.root / "records" / edit / label / f"{rank}-{arm}"
                observed, product = self.trial(edit, arm, folder, stamp)
                if label == "admission":
                    admitted[arm] = observed, product
                    write(folder / "normalized-roster.json", list(observed))
                else:
                    need((observed, product) == admitted[arm], "different work or output from own-arm admission")
                products.append(product)
                times[arm] = read(folder / "command.json")["elapsed_ns"]
            need(products[0] == products[1], "different native outputs or behavior between matched compilers")
            return times
        pair("admission", order["pilot_order"])
        pilot = pair("pilot", order["pilot_order"])
        continued = self.candidate == "ZD" or 5 * pilot[self.control] >= 9 * pilot[self.candidate]
        if continued:
            for i, arms in enumerate(order["pairs"]):
                pair(f"pair-{i:02d}", arms)
        write(self.root / "records" / edit / "closed.json",
              {"edit": edit, "contrast": self.candidate, "pilot_continues": continued, "pairs": 12 if continued else 0})
        for a in order["pilot_order"]:
            shutil.rmtree(self.root / "seeds" / f"{edit}-{a}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("uv-clone", "control-sdk", "candidate-sdk", "cargo-home", "run"):
        p.add_argument("--"+name, type=Path, required=True)
    p.add_argument("--subjects", type=Path, default=HERE / "subjects.json",
                   help="attested per-driver SHA-256 and shared SDK members (default: adjacent subjects.json)")
    p.add_argument("--contrast", choices=["CZ", "CZD", "ZD"], required=True)
    p.add_argument("--edit", choices=["tool-test", "settings", "both"], default="both")
    p.add_argument("--qualified-run", action="append", type=Path,default=[],help="completed portable combined-guard run(s), for a preregistered P-to-ZD follow-up")
    p.add_argument("--qualified-native", nargs=2, metavar=("PILOT","PAIRS"),action="append",type=Path,default=[],
                   help="alternative published raw C-to-CZD native pilot and pairs directories from the same completed edit")
    p.add_argument("--reserve-gib", type=int, default=10)
    a = p.parse_args()
    need(a.reserve_gib >= 1, "positive disk reserve required")
    cpus = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, cpus[:16])
    w = read(HERE / "workflow.json")
    if a.contrast == "ZD":
        from score import leaf_eligibility
        need(a.edit in ("tool-test","both"),"no separately registered leaf settings endpoint")
        eligibility=leaf_eligibility(a.qualified_run,a.qualified_native,w)
    else:
        need(not a.qualified_run and not a.qualified_native,"separate prior evidence is used only for the standalone leaf")
    r = Replay(a, w)
    if a.contrast=="ZD":write(r.root/"leaf-eligibility.json",eligibility)
    r.setup()
    edits = ("tool-test",) if a.contrast=="ZD" else (("tool-test", "settings") if a.edit == "both" else (a.edit,))
    for edit in edits:
        r.endpoint(edit)
    write(r.root / "complete.json", {"contrast": r.candidate, "edits": list(edits), "workflow_sha256": sha(HERE / "workflow.json")})
    print("Completed. Run score.py with this directory and any independently completed other contrast.")


if __name__ == "__main__":
    main()
