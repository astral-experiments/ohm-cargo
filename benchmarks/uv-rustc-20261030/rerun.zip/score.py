"""Independently verify raw portable runs and apply the registered four-hypothesis Holm family."""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rerun import KNOWN, POISON, RECHECK, baseline, check_versions, policy, blob, read, schedule
from git_identity import verify_identity
from common import need, sha
from registered_score import score_times, holm


def one_run(root, plan):
    verify_identity(read(root / "source-identity.json"), plan)
    end, inp = read(root / "complete.json"), read(root / "inputs.json")
    candidate = inp["contrast"]
    control = baseline(candidate)
    need(candidate in ("CZ", "CZD", "ZD") and end["contrast"] == candidate and end["workflow_sha256"] ==
         inp["workflow_sha256"] == sha(HERE / "workflow.json"), "wrong completed study or workflow")
    need(inp["argv"] == [str(Path(inp["root"]) / "sdk/bin/cargo"), *plan["command"]], "changed Cargo command")
    maps = read(root / "sdk-manifests.json")
    a, b = maps[control], maps[candidate]
    dsos = [p for p in a if a[p] != b.get(p)]
    need(a.keys() == b.keys() and len(dsos) == 1 and re.fullmatch(r"lib/librustc_driver[^/]*\.so", dsos[0]),
         "unmatched recorded SDKs")
    need({k: v.get("sha256") for k,v in a.items() if k != dsos[0]} == inp["subject_provenance"]["common_members"],
         "common SDK differs from the source-bound subjects")
    for arm in maps:
        s = inp["subject_provenance"][arm]
        need(s["driver_sha256"] == maps[arm][dsos[0]]["sha256"] and s["tree"] == plan["subject_source_trees"][arm],
             "compiler does not match sources")
    checked = set()
    def marker_rows(folder, receipt):
        units = receipt["units"]
        need(units.keys() == KNOWN, "missing known native assembly package")
        for pkg, unit in units.items():
            path = folder / "raw-depinfo" / (pkg+".d")
            data = path.read_bytes()
            need(sha(path) == unit["sha256"] and (POISON in data) == unit["opaque"] and
                 (RECHECK in data) == unit["recheck_link"], "dep-info evidence differs")
        return sorted(p for p in units if units[p]["opaque"])
    def row(folder, edit, state, arm):
        cmd = read(folder / "command.json")
        prod = read(folder / "products.json")
        e = plan["endpoints"][edit]
        f = root / "sources" / f"{edit}-{state}.rs"
        source = cmd["source"]
        need(source["state"] == state and source["path"] == e["path"] and source["blob"] == e[state] == blob(f.read_bytes())
             and source["sha256"] == sha(f), "wrong source bytes")
        need((cmd["arm"], cmd["endpoint"]) == (arm, edit) and cmd["actual_argv"] == inp["argv"] and cmd["exit"] == 0
             and isinstance(cmd["elapsed_ns"], int) and cmd["elapsed_ns"] == cmd["end_ns"]-cmd["start_ns"] > 0
             and cmd["log_sha256"] == sha(folder / "cargo.log") and cmd["post_foreground"]["remaining"] == []
             and cmd["post_foreground"]["session"] == cmd["pid"], "invalid Cargo clock, output log or foreground return")
        roles = sorted(re.findall(r"(?m)^\s*Compiling ([^\s]+)", (folder / "cargo.log").read_text(errors="replace")))
        need(roles == cmd["packages"] and all(v >= 0 for v in cmd["rusage_wait4"].values()), "raw packages/resources")
        if state == "B":
            owner = read(folder / "edited-owner.json")
            expected = "crates/uv/tests/tool/main.rs" if edit == "tool-test" else "crates/uv/src/lib.rs"
            need("uv" in roles and owner["crate_root"] == expected and owner["depfiles"], "missing edited owner")
            for key,h in owner["depfiles"].items():
                path = Path(key)
                need(path.parts[:3] == ("debug","build","uv") and len(path.parts) == 6 and
                     str(path.parent.parent / "fingerprint/invoked.timestamp") in cmd["changed_stamps"]
                     and re.fullmatch("[a-f0-9]{64}", h), "wrong rebuilt owner")
                f = folder / "owner-depinfo" / h
                need(sha(f) == h and expected.encode() in (raw := f.read_bytes()) and e["path"].encode() in raw,
                     "edited source absent from emitted dep-info")
        listing = (folder / "list.txt").read_bytes()
        need(prod["list_sha256"] == e[state+"_list"] == sha(folder / "list.txt") and
             sum(s.endswith(b": test") for s in listing.splitlines()) == e[state+"_count"], "wrong test inventory")
        need(prod["self_version"] == plan["A"]["self_version"] and prod["version"] == plan["A"]["version"], "version mismatch")
        files = read(folder / "public-paths.json")
        need(files == prod["files"] and files.keys() == {"tool", "uv", "uvx"}, "output role mismatch")
        for v in files.values():
            h = v["sha256"]
            need(re.fullmatch("[a-f0-9]{64}", h) is not None, "invalid output digest")
            f = root / "objects" / h
            need(f.stat().st_size == v["bytes"] > 0 and (h in checked or sha(f) == h), "retained output does not match")
            checked.add(h)
        return cmd, prod
    results = {}
    for edit in end["edits"]:
        parent = root / "records" / edit
        o, rule = schedule(plan, edit, candidate), read(parent / "closed.json")
        need(rule["edit"] == edit and rule["contrast"] == candidate, "cell/closure mismatch")
        anchors, diagnostics = [], {}
        for arm in o["pilot_order"]:
            d = parent / "A" / arm
            seed = read(d / "seed.json")
            need(check_versions(plan,inp["subject_provenance"],seed["versions"]), "actual runtime versions differ")
            need(seed["B_seen"] is False and seed["driver_sha256"] == maps[arm][dsos[0]]["sha256"], "wrong seed")
            need(seed["repeat_sha256"] == sha(d / "verify-repeat/products.json") and seed["source_sha256"] ==
                 sha(root / "sources" / f"{edit}-A.rs"), "missing independent A history")
            cold, _ = row(d / "cold", edit, "A", arm)
            x, y = row(d / "ordinary-repeat", edit, "A", arm), row(d / "verify-repeat", edit, "A", arm)
            need(x[1] == y[1] and all(x[0][k] == y[0][k] for k in ("packages", "changed_stamps")), "unsettled A")
            anchors.append(y[1])
            opaque = marker_rows(d, seed["markers"])
            need(policy(arm,opaque), "unexpected compiler policy")
            diagnostics[arm] = {"cold_A_ns": cold["elapsed_ns"], "ordinary_A_repeat_ns": x[0]["elapsed_ns"],
                                "unmeasured_verification_ns": y[0]["elapsed_ns"], "A_opaque_packages_among_six": opaque}
        need(anchors[0] == anchors[1], "independently prepared A programs differ")
        admissions = {}
        def pair(label, order):
            data, products, mtimes = {}, [], []
            d = parent / label
            need({p.name for p in d.iterdir()} == {f"{i}-{arm}" for i, arm in enumerate(order)}, "extra/missing arm or changed order")
            for i, arm in enumerate(order):
                folder = d / f"{i}-{arm}"
                c, p = row(folder, edit, "B", arm)
                before = read(folder / "source-A.json")
                need(before["blob"] == plan["endpoints"][edit]["A"] and before["sha256"] ==
                     sha(root / "sources" / f"{edit}-A.rs") and before["mtime_ns"] < c["source"]["mtime_ns"], "wrong preimage")
                mtimes.append(c["source"]["mtime_ns"])
                key = c["packages"], c["changed_stamps"], p
                if label == "admission":
                    admissions[arm] = key
                    diagnostics[arm]["B_opaque_packages_among_six"] = marker_rows(folder, read(folder / "markers.json"))
                    diagnostics[arm]["B_packages"] = c["packages"]
                    diagnostics[arm]["B_changed_stamps"] = c["changed_stamps"]
                need(key == admissions[arm], "changed the admitted work or products")
                data[arm] = c["elapsed_ns"]
                products.append(p)
            need(products[0] == products[1] and mtimes[0] == mtimes[1], "different programs or edits in pair")
            return (order[0], data[control], data[candidate])
        pair("admission", o["pilot_order"])
        _, base, cand = pair("pilot", o["pilot_order"])
        passed = candidate == "ZD" or 5*base >= 9*cand
        need(rule["pilot_continues"] is passed and rule["pairs"] == (12 if passed else 0), "invalid pilot decision")
        names = {f"pair-{i:02d}" for i in range(rule["pairs"])}
        need({p.name for p in parent.glob("pair-*")} == names, "missing, extra or post-stop measured rows")
        out = {"edit": edit, "contrast": candidate, "compiler_provenance":inp["subject_provenance"].get("provenance","original-qualified-sdk-bytes"), "excluded_pilot_ns": {control: base, candidate: cand},
               "excluded_pilot_ratio": base/cand, "pilot_continues": passed, "pairs": rule["pairs"],
               "off_clock_diagnostics": diagnostics}
        if passed:
            orders = o["pairs"]
            need(len(orders) == 12 and sum(p[0] == control for p in orders) == 6, "unbalanced plan")
            samples = [pair(f"pair-{i:02d}", p) for i,p in enumerate(orders)]
            out["paired_nanoseconds"] = [{"first": first, control: b, candidate: k}
                                          for first,b,k in samples]
            if candidate=="ZD":
                import registered_leaf_score
                need(sha(HERE/"registered_leaf_score.py")=="f8fa01da1480aa859e293c04a97bc80700ef0460418f09d858be0af2c0e914e9","wrong original independent leaf scorer")
                out["summary"]=registered_leaf_score.score_times(samples)
            else:
                out["summary"]=score_times(samples)
            if candidate=="ZD":
                need(edit=="tool-test" and (root/"leaf-eligibility.json").is_file(),"missing independent leaf prerequisite")
                proof=read(root/"leaf-eligibility.json")
                need(proof["qualifies"] and any(r["confirmed"] for r in holm(proof["combined_scores"]).values()),"ineligible leaf")
        results[f"{candidate}/{edit}"] = out
    return results


def family(cells):
    return holm({k: v["summary"] for k,v in cells.items() if "summary" in v and not k.startswith("ZD/")})


def leaf_eligibility(portable, native, plan):
    rows, proofs = {}, []
    for path in portable:
        cells=one_run(path,plan)
        for key,cell in cells.items():
            if key.startswith("CZD/") and "summary" in cell:
                need(key not in rows,"duplicate qualifying cell")
                rows[key]=cell["summary"]
        proofs.append({"format":"portable","complete_sha256":sha(path/"complete.json")})
    if native:
        from registered_score import replay
        original=HERE/"original"
        p=original/"protocol.json";e=original/"four-endpoints.json"
        need(sha(p)==plan["source_science_sha256"] and sha(e)==plan["four_contrast_family_sha256"],"different official schedules")
        for pilot,pairs in native:
            a,b=read(pilot/"successful.json"),read(pairs/"successful.json")
            key="CZD/"+a["edit"]
            need(a["candidate"]==b["candidate"]=="CZD" and a["edit"]==b["edit"] and
                 a["phase"]=="pilot" and b["phase"]=="pairs" and key not in rows,"wrong qualifying phases")
            need(replay(pilot,read(p),read(e))["continues"],"stopped original pilot")
            rows[key]=replay(pairs,read(p),read(e))
            proofs.append({"format":"registered-native","pilot_outer_sha256":sha(pilot/"outer-return.json"),
                           "pairs_outer_sha256":sha(pairs/"outer-return.json")})
    need(rows and any(row["confirmed"] for row in holm(rows).values()),"no confirmed combined-guard cell")
    return {"qualifies":True,"combined_scores":rows,"replayed":proofs}

def session_holm(cells):
    keys=[c+"/"+e for c in ("CZ","CZD") for e in ("settings","tool-test")]
    keys+=["CZD/settings-check","CZD/settings-build","ZD/tool-test"]
    p={k:cells.get(k,{}).get("summary",{}).get("p_against_2",{}).get("two_sided_p",1.) for k in keys}
    output={};prev=0
    for i,k in enumerate(sorted(keys,key=lambda k:(p[k],k))):
        prev=max(prev,min(1.,(len(p)-i)*p[k]))
        output[k]={"raw_p":p[k],"holm_p":prev,"complete":k in cells and "summary" in cells[k],
                   "confirmed":prev<.05 and cells.get(k,{}).get("summary",{}).get("individual_gate",False)}
    return output


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("run", nargs="+", type=Path)
    args = p.parse_args()
    plan = read(HERE / "workflow.json")
    cells = {}
    for root in args.run:
        new = one_run(root, plan)
        need(not new.keys() & cells.keys(), "duplicate endpoints")
        cells.update(new)
    print(json.dumps({"independent_endpoints": cells, "holm_family": family(cells), "cross_study_holm_seven":session_holm(cells)}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
