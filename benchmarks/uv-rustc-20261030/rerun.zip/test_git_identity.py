"""Independently run and verify the two Git identity readers without compiling uv."""
import argparse
import copy
import json
from pathlib import Path
import sys
import tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from rerun import git
from common import need
from git_identity import private_identity,verify_identity

def run(source):
    wf=json.loads((HERE/'workflow.json').read_bytes())
    probe=lambda *args:git(source,*args).decode().strip()
    objects=probe('rev-parse','--path-format=absolute','--git-path','objects')
    a=wf['A']['commit'];tag=probe('rev-parse','refs/tags/0.12.0')
    with tempfile.TemporaryDirectory(prefix='ohm-git-describe-check-') as tmp:
        repo=Path(tmp)
        git(repo,'init','-q','--template=','--initial-branch=feature-A')
        (repo/'.git/objects/info/alternates').write_text(objects+'\n')
        git(repo,'update-ref','refs/heads/feature-A',a)
        git(repo,'update-ref','refs/tags/0.12.0',tag)
        git(repo,'config','--local','core.abbrev','12')
        wrong=git(repo,'describe','--tags','--always').decode().strip()
        saved=private_identity(repo,wf,git)
        need(wrong != saved['describe_tags_always'],'abbreviation negative control')
        for key in ('local_core_abbrev','describe_always','describe_tags_always','uv_build_script_log','release_tag_target','release_tag_type'):
            bad=copy.deepcopy(saved);bad[key]='wrong'
            try:verify_identity(bad,wf)
            except ValueError:continue
            raise ValueError('accepted corrupt '+key)
        return {'actual_source':saved,'negative_core_abbrev_12_description':wrong,'corrupt_receipts_rejected':6}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('existing_uv_clone',type=Path)
    print(json.dumps(run(parser.parse_args().existing_uv_clone.resolve()),sort_keys=True,indent=2))
