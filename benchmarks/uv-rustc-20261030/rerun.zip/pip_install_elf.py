"""Compare complete uv test products with the two independently verified pip_install encodings."""
import hashlib

ROLE = "tests/pip_install/main.rs"
PUBLISHED_PATH = "debug/build/uv/57d835e9b74c3ddf/out/pip_install-57d835e9b74c3ddf"
SIZE = 138084016
FIRST = "7500331ff8d61491e37bf8f523286fe65310dea21707cecafc5186c2c8c347ce"
SECOND = "ec3b00978553c6050695daf162c2eadb8162fbcec1236b0e43e1a97248298c33"
LIST_SHA = "094b917fe35de46c4567254cd9181ece1e75e5becc4338257cad3603c6197427"
EMPTY_SHA = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
MASKED_SHA = "52ea86b5fd72bf64e343e622eecdbf4adf457ac67aaf050b26dc9e5fbc5161e0"


def verify_plan(plan):
    expected = {"path": PUBLISHED_PATH, "bytes": SIZE, "stdout_sha256": LIST_SHA,
                "stderr_sha256": EMPTY_SHA, "exit": 0, "argv_tail": ["--list"], "tests": 355, "benchmarks": 0}
    if (set(plan["pip_install_forms"]) != {FIRST, SECOND} or plan["pip_install_exact"] != expected
            or plan["pip_install_mask_sha256"] != MASKED_SHA):
        raise ValueError("different fixed pip_install calibration")


def verify_observed_bytes(path, observed_sha):
    if observed_sha not in (FIRST, SECOND):
        return
    masked = hashlib.sha256()
    offset = 0
    with path.open("rb") as f:
        while chunk := f.read(1 << 20):
            part = bytearray(chunk)
            for position, length in ((896, 32), (138082152, 8)):
                start, end = max(offset, position), min(offset + len(part), position + length)
                if start < end:
                    part[start-offset:end-offset] = bytes(end - start)
            masked.update(part)
            offset += len(part)
    if offset != SIZE or masked.hexdigest() != MASKED_SHA:
        raise ValueError("unverified bytes outside the fixed two ELF fields")


def matching_programs(left, right):
    if left == right:
        return True
    if left.keys() != right.keys() or len(left) != 17 or ROLE not in left:
        return False
    if any(left[k] != right[k] for k in left if k != ROLE):
        return False
    first, second = dict(left[ROLE]), dict(right[ROLE])
    hashes = (first.pop("sha256"), second.pop("sha256"))
    return (
        set(hashes) == {FIRST, SECOND}
        and first == second
        and first["path"] == PUBLISHED_PATH and first["bytes"] == SIZE
        and first["stdout_sha256"] == LIST_SHA
        and first["stderr_sha256"] == EMPTY_SHA
        and first["exit"] == 0 and first["argv_tail"] == ["--list"]
        and first["tests"] == 355 and first["benchmarks"] == 0
    )


def matching_bundles(left, right):
    if left == right:
        return True
    first, second = dict(left), dict(right)
    a, b = first.pop("all_products"), second.pop("all_products")
    af, bf = first.pop("files"), second.pop("files")
    if first != second or not matching_programs(a, b):
        return False
    for files, programs in ((af, a), (bf, b)):
        if files != {name: {k: row[k] for k in ("path", "bytes", "sha256")} for name, row in programs.items()}:
            return False
    return True

