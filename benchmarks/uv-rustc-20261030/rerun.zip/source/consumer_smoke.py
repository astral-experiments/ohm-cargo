import hashlib, subprocess, tempfile
from pathlib import Path


def exercise(sdk, env):
    rs = sdk / "bin/rustc"
    env = dict(env, LD_LIBRARY_PATH=str(sdk/"lib"))
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="upstream274-test-") as private:
        root = Path(private)
        macro = root/"gate_macro.rs"
        test = root/"actual_test.rs"
        macro.write_text('extern crate proc_macro;\nuse proc_macro::TokenStream;\n#[proc_macro]\npub fn four(_: TokenStream) -> TokenStream { "4u32".parse().unwrap() }\n')
        test.write_text('#[test]\nfn full_std_and_host_proc_macro() { assert_eq!(gate_macro::four!(), 4u32); }\n')
        commands = [[rs, "--edition=2021", "--crate-name", "gate_macro", "--crate-type=proc-macro",
                     macro, "-o",root/"libgate_macro.so"],
                    [rs, "--edition=2021", "--test", test, "--extern","gate_macro="+str(root/"libgate_macro.so"),
                     "-o",root/"actual_test"],
                    [root/"actual_test","--list"],[root/"actual_test","--exact","full_std_and_host_proc_macro"]]
        rows = []
        for cmd in commands:
            q = subprocess.run(cmd,cwd=root,env=env,capture_output=True)
            rows.append({"argv":list(map(str,cmd)),"exit":q.returncode,"stdout":q.stdout.decode(errors="replace"),
                         "stderr":q.stderr.decode(errors="replace")})
            if q.returncode:
                break
        good = len(rows)==4 and all(r["exit"]==0 for r in rows) and "full_std_and_host_proc_macro: test" in rows[2]["stdout"] and "1 passed; 0 failed" in rows[3]["stdout"]
        return {"source_sha256": {s.name:hashlib.sha256(s.read_bytes()).hexdigest() for s in [macro,test]},
                "commands":rows,"verified":good}

