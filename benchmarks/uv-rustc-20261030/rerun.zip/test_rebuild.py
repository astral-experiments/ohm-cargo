"""Verify the four real source projections and SDK/data controls without running any Rust tool."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import io,tarfile
from unittest.mock import patch

THIS=Path(__file__).resolve().parent
sys.path.insert(0,str(THIS))
import rebuild as r
import release_tools
from common import need,sha,write


def oid(kind,data):
    return hashlib.sha1(kind+b" "+str(len(data)).encode()+b"\0"+data).hexdigest()


def tree_id(entries):
    return oid(b"tree",b"".join(format(e["mode"],"o").encode()+b" "+os.fsencode(e["name"])+b"\0"+bytes.fromhex(e["oid"]) for e in entries))


def merkle(objects, blobs):
    tree={}
    for name,obj in sorted(objects.items(),key=lambda z:-len(z[0])):
        assert tree_id(obj["entries"])==obj["oid"]
        new=copy.deepcopy(obj["entries"])
        for e in new:
            path=(name+"/" if name else "")+e["name"]
            if path in blobs:e["oid"]=blobs[path]
            elif path in tree:e["oid"]=tree[path]
        tree[name]=tree_id(new)
    return tree[""]


def rejects(func):
    try:func()
    except (ValueError,FileNotFoundError,subprocess.CalledProcessError):return
    raise AssertionError("accepted a deliberate mismatch")


def sources(tmp):
    trees=r.read(r.SRC/"parent-trees.json")
    assert merkle(trees,{})==r.PLAN["tree"]
    prior=r.SRC/"parent"
    source=tmp/"rust";shutil.copytree(prior,source)
    r.git(source,"init","--quiet","--template=");r.git(source,"add",".")
    r.git(source,"-c","user.name=offline-fixture","-c","user.email=fixture@example.invalid","commit","-qm","parent")
    local=copy.deepcopy(r.PLAN);local["P"]=r.git(source,"rev-parse","HEAD");local["tree"]=r.git(source,"write-tree")
    for arm,row in r.PLAN["subjects"].items():
        r.git(source,"restore","--source=HEAD","--worktree","--staged","--",".")
        patchfile=r.SRC/row["patch"]
        assert sha(patchfile)==row["sha256"]
        r.git(source,"apply","--index",str(patchfile));after={}
        for name,x in row["files"].items():
            assert sha(prior/name)==x["before_sha256"] and oid(b"blob",(prior/name).read_bytes())==x["before"]
            after[name]=oid(b"blob",(source/name).read_bytes())
            assert after[name]==x["after"] and sha(source/name)==x["after_sha256"]
        assert merkle(trees,after)==row["tree"]
        bad=dict(after);bad[next(iter(bad))]="0"*40
        assert merkle(trees,bad)!=row["tree"]
        local["subjects"][arm]["tree"]=r.git(source,"write-tree")
    for arm in ("P","C","CZ","CZD","ZD"):
        actual=r.select(source,arm,local)
        assert actual==(local["tree"] if arm=="P" else local["subjects"][arm]["tree"])
    broken=copy.deepcopy(local);broken["subjects"]["C"]["tree"]="0"*40
    rejects(lambda:r.select(source,"C",broken))
    broken=copy.deepcopy(local);broken["subjects"]["C"]["sha256"]="0"*64
    rejects(lambda:r.select(source,"C",broken))
    extra=source/"unexpected-source";extra.touch()
    rejects(lambda:r.select(source,"P",local));extra.unlink()


def projection(tmp):
    b=tmp/"mini-build";st=b/"stage1";release=tmp/"release"
    a=tmp/"P";z=tmp/"ZD"
    def file(path,data):
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    launcher=st/"bin/rustc";file(launcher,b"fake launcher")
    driver=st/"lib/librustc_driver-00000.so";file(driver,b"fake parent driver")
    llvm=st/"lib/libLLVM-fixture.so";file(llvm,b"fake LLVM")
    file(b/"stage1-tools-bin/cargo",b"fake Cargo")
    spec=copy.deepcopy(r.PLAN)
    for name in spec["stock_tools"]:
        file(release/name,name.encode());spec["stock_tools"][name]=sha(release/name)
    for n in spec["std_stems"]:file(st/r.HOSTLIB/n.replace("-HASH","-0123456789abcdef"),n.encode())
    file(st/r.HOSTLIB/"libprofiler_builtins-a0b1c2d3e4f50607.rlib",b"legitimate extra optional std file")
    with patch.object(r,"lookup_llvm",return_value=(llvm,llvm.name)):
        dso,parent=r.export(b,release,a,"P",None,None,spec)
        assert len(parent)==65 and sha(a/dso)==sha(driver)
        file(driver,b"fake changed driver")
        _,cand=r.export(b,release,z,"ZD",a,parent,spec)
        assert [n for n in parent if parent[n]!=cand[n]]==[dso]
        for n in parent:
            assert (a/n).samefile(z/n)==(n!=dso)
        file(launcher,b"fake incorrect launcher")
        rejects(lambda:r.export(b,release,tmp/"bad","ZD",a,parent,spec))
        member=next((st/r.HOSTLIB).glob("libtest-*.rlib"));member.unlink()
        rejects(lambda:r.export(b,release,tmp/"bad-std","P",None,None,spec))


def release(tmp):
    names=["lib/rustlib/host/bin/"+n for n in ("tool","same")]
    raw=b"fake release helper"
    tar=tmp/"mini.tar.gz"
    with tarfile.open(tar,"w:gz") as t:
        a=tarfile.TarInfo("pkg/tools/"+names[0]);a.size=len(raw);t.addfile(a,io.BytesIO(raw))
        b=tarfile.TarInfo("pkg/tools/"+names[1]);b.type=tarfile.LNKTYPE;b.linkname=a.name;t.addfile(b)
    plan={"release_sha256":sha(tar),"stock_tools":{n:hashlib.sha256(raw).hexdigest() for n in names}}
    out=release_tools.install(tar,tmp/"helpers",plan)
    assert all((out/n).read_bytes()==raw and os.access(out/n,os.X_OK) for n in names)
    bad=copy.deepcopy(plan);bad["stock_tools"][names[0]]="0"*64
    rejects(lambda:release_tools.install(tar,tmp/"bad-tools",bad))
    bad=copy.deepcopy(plan);bad["release_sha256"]="0"*64
    rejects(lambda:release_tools.install(tar,tmp/"bad-tar",bad))


def proofs(tmp):
    rdir=tmp/"independent";rdir.mkdir()
    cfg=rdir/"bootstrap.toml";cfg.write_text((r.SRC/"bootstrap.toml").read_text())
    pool={"lib/member-"+str(i):hashlib.sha256(str(i).encode()).hexdigest() for i in range(64)}
    tools={"cargo":"commit-hash: "+r.PLAN["cargo"],"rustc":"commit-hash: "+r.PLAN["P"]}
    registry={"provenance":"independent-source-build","source_parent":r.PLAN["P"],
              "submodule_gitlinks":{"src/tools/cargo":r.PLAN["cargo"],"src/llvm-project":r.PLAN["llvm"]},
              "source_spec_sha256":sha(r.SRC/"sources.json"),"config_sha256":sha(cfg),"config_template_sha256":sha(r.SRC/"bootstrap.toml"),
              "versions":tools,"common_members":pool}
    for a in ("P","CZD"):
        rec=rdir/"records"/a;rec.mkdir(parents=True)
        expected=r.PLAN["tree"] if a=="P" else r.PLAN["subjects"][a]["tree"]
        dso="lib/librustc_driver-synthetic-only.so";driver=hashlib.sha256(a.encode()).hexdigest()
        sdk={"arm":a,"source_tree":expected,"source_parent":r.PLAN["P"],"versions":tools,"driver":dso,"files":pool|{dso:driver},
             "source_patch_sha256":None if a=="P" else r.PLAN["subjects"][a]["sha256"]}
        write(rec/"smoke.json",{"verified":True});sdk["smoke_sha256"]=sha(rec/"smoke.json")
        for op,field in (("build","build_sha256"),("native-guards","applicable_native_recipes_sha256")):
            tests=["tests/run-make/ohm-checked-dep-info","tests/run-make/ohm-relink-assembler-inputs"]
            log=rec/(op+".log");log.write_text("".join("test [run-make] "+t+" ... ok\n" for t in tests))
            argv=["/usr/bin/python3","-ISB","x.py","build" if op=="build" else "test","--stage","1"]
            argv+=(["compiler/rustc"] if op=="build" else ["--force-rerun",*tests])
            write(rec/(op+".json"),{"argv":argv,"exit":0,"log_sha256":sha(log)})
            sdk[field]=sha(rec/(op+".json"))
        write(rec/"sdk.json",sdk);registry[a]={"tree":expected,"driver_sha256":driver,"sdk_receipt_sha256":sha(rec/"sdk.json")}
    path=rdir/"subjects.json";write(path,registry);assert r.verify_subjects(path,["CZD"])==registry
    qa=rdir/"records/CZD/native-guards.log";qa.write_text("0 tests passed")
    rejects(lambda:r.verify_subjects(path,["CZD"]))
    cfg.write_text("different config")
    rejects(lambda:r.verify_subjects(path,["CZD"]))


if __name__=="__main__":
    with tempfile.TemporaryDirectory(prefix="portable-asm-source-controls-") as t:
        root=Path(t);sources(root);projection(root);release(root);proofs(root)
    print("PASS: real P/C/CZ/CZD/ZD Merkle tree IDs, all original and derived source blobs, actual git apply/select, additive and changed-source rejection, verified archive tool extraction and corruption, 65-file fixture export and distinct-driver-only/hardlink checks. No compiler ran.")
