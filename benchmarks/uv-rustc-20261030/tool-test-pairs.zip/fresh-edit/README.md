# Fresh-edit Cargo trial

With Python 3.11 or newer, extract the ZIP and run `python3 -IB fresh-edit/verify.py`. The verifier needs the Python standard library and the extracted files. `fresh-edit/result.json` contains the same score. Verify the SHA-256 of the complete ZIP against the separate publication receipt before extraction.

Each measured interval covers the first ordinary foreground Cargo command after writing one genuine file change under the same Git commit. All arm preparations used independent copies of the same starting state. The raw records give the source hashes and timestamps, commands, start and end times, Cargo stderr, changed unit stamps, executable hashes, CLI version and test inventory. The separate traced admissions record the actual compiled units, mapped driver and native inputs. Their clocks are excluded from the paired result.

The original registered scorer recomputes all 12 pair ratios, seconds saved, both orders, a distribution-free median interval and the exact sign tests against 1× and 2×. A combined-guard pilot has zero scored rows. An endpoint can stop there under its registered screen. The independent P versus ZD comparison proceeds directly to its 12 held-out pairs. A claim across multiple workflows requires the registered family adjustment, including missing endpoints at p=1. This archive reconstructs its own endpoint.

The local experiment retains full compiled programs and training targets separately. This portable packet contains product identities, raw clock and process evidence, and the return receipts that authenticated the tested SDKs. It does not contain the five SDKs or the compiled uv binaries.
