"""Replay a returned fresh-edit experiment without a Rust compiler or the original filesystem."""
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path


PINS = {
    'protocol.json': 'e136b86c65044528494919ce17d59bacac5120bcff93c0e09bf5e1f4ce38e2bd',
    'four-endpoints.json': 'c0b6dec18e8b888f87cd9cd15b7ffc811377486fd9d48eb3a51ff357ff0b6adf',
    'direct-leaf-plan.json': '6fa8ea728044fdaf4c3f2116cde762fb0615b9c5be79dbae9ac3ecb66f2dc41a',
    'score.py': '376a2dfb658cd1f087e1d96f46ea370077d37cc02fa51b135e8223d0c5e879f5',
    'leaf_score.py': 'f8fa01da1480aa859e293c04a97bc80700ef0460418f09d858be0af2c0e914e9',
}
REGISTERED = {
    'combined': 'd84bae4eb2d9b7071c72ef16fa80e3a9dc66fd6e6abc37943cdb780a70a1ae0a',
    'direct': 'c0ce6e4f5d738da620a325b5c270f81ffb5bb0ef6c7fd71631a0e9012d80a486',
}
OFFICIAL_RETURN = '4739f51674f00a55ef7c1597ee0f125bccff62b6a447deacb8b85c51e446999b'


def require(condition, why):
    if not condition:
        raise ValueError(why)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def regular_files(root):
    for path in root.rglob('*'):
        require(not path.is_symlink() and (path.is_dir() or path.is_file()), 'invalid packet member')
        if path.is_file():
            yield path


def checksums(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in regular_files(root) if p != root/'SHA256.json'}


def load_scorer(path):
    spec = importlib.util.spec_from_file_location('original_frozen_scorer', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def phase_bound(root, name, registered, arm, edit):
    location = root/'phases'/name
    outer, worker, intake, successful = [
        read(location/file) for file in ('outer-return.json','worker-return.json','intake.json','successful.json')
    ]
    triplet = outer['outer']
    require(triplet['session'] > 0 and re.fullmatch('[0-9a-f]{6}', triplet['chunk']) and
            triplet['exit'] == outer['worker_code'] == worker['code'] == worker['worker_exit'] == 0 and
            outer['host_released'] is True and outer['remaining_workers'] == outer['foreign'] == [] and
            len(outer['locks']) == len(set(outer['locks'])) == 2 and
            outer['locks'] == intake['locks'] == worker['locks'] and outer['boot'] == intake['boot'] and
            worker['capacity']['guard_fault'] is None, 'failed or incomplete return ' + name)
    require(sha(location/'intake.json') == outer['intake_sha256'] and
            sha(location/'worker-return.json') == outer['worker_sha256'] and
            sha(location/'successful.json') == worker['success'] and
            sha(location/'subjects.json') == successful['subjects'] and
            successful['registration'] == intake['registration'] == registered and
            (successful['phase'],successful['candidate'],successful['edit']) == (name,arm,edit),
            'changed returned phase, sources, study or owner ' + name)
    return location, successful['outcome']


def replay(root):
    require(read(root/'SHA256.json') == checksums(root), 'payload inventory or hash mismatch')
    for name, digest in PINS.items():
        require(sha(root/'science'/name) == digest, 'changed preregistered input ' + name)
    manifest = read(root/'endpoint.json')
    arm, edit = manifest['candidate'], manifest['edit']
    require(arm in ('CZ','CZD','ZD') and edit in ('tool-test','settings') and (arm != 'ZD' or edit == 'tool-test'),
            'unregistered endpoint')
    mode = 'direct' if arm == 'ZD' else 'combined'
    registration = REGISTERED[mode]
    require(sha(root/'science'/('registration-'+mode+'.json')) == registration, 'wrong scientific registration')
    source = root/'evidence'
    require(sha(source/'official-outer-return.json') == OFFICIAL_RETURN, 'wrong actual qualified compiler group')
    outer = read(source/'official-outer-return.json')
    require(outer['worker_sha256'] == sha(source/'official-worker-return.json') and
            read(source/'official-worker-return.json')['qualified'] == sha(source/'official-qualified.json'),
            'lost five actual official fixture returns')
    official = read(source/'official-qualified.json')
    prior = official['prior_evidence']
    require(official['qualified'] and official['uv_samples'] == 0 and prior['matrix_rows'] == 99 and
            set(official['official']) == {'P','C','CZ','CZD','ZD'}, 'changed native-input fixture set')
    for label, digest in official['official'].items():
        actual = source/('run-make-'+label+'.json')
        require(sha(actual) == digest and read(actual)['exit'] == 0, 'missing original Rust recipe ' + label)
    prep, starting = phase_bound(root, 'prepare', registration, arm, edit)
    retired, closing = phase_bound(root, 'retire', registration, arm, edit)
    for label, subject in read(prep/'subjects.json')['subjects'].items():
        manifest_file = source/('sdk-'+label+'.json')
        sdk = read(manifest_file)
        driver = sdk['driver']
        require(sha(manifest_file) == subject['ready_sha256'] == prior['manifests'][label] and
                sdk['files'][driver] == subject['driver_sha256'] == prior['drivers'][label] and
                subject['source_sha256'] == prior['source'][label] and
                sdk['files']['bin/cargo'] == subject['cargo_sha256'] and
                sdk['files']['bin/rustc'] == subject['launcher_sha256'] and len(sdk['files']) == 65,
                'substituted SDK or scientific source ' + label)
    require(closing['preserved_CAS'] and set(closing['released_private_checkpoints']) == set(starting['arm_checkpoints']),
            'different owned targets or evidence not preserved')
    scorer = load_scorer(root/'science'/('leaf_score.py' if mode == 'direct' else 'score.py'))
    plan = read(root/'science'/'protocol.json')
    extra = read(root/'science'/('direct-leaf-plan.json' if mode == 'direct' else 'four-endpoints.json'))
    phases = ['pairs'] if mode == 'direct' else ['pilot']
    reports = {}
    names = manifest['original_phase_names']
    for phase in phases:
        directory, _ = phase_bound(root, phase, registration, arm, edit)
        admission = read(directory/'admissions'/'ready.json')
        require(admission['original_prepare_outer'] == sha(prep/'outer-return.json') and
                admission['original_prepare_completion'] == sha(prep/'successful.json'), 'different original preparation')
        source_sha = sha(directory/'subjects.json')
        require(source_sha == sha(prep/'subjects.json') == sha(retired/'subjects.json'), 'subjects changed between phases')
        for label, record in admission['arms'].items():
            base = prep/('admission-'+label)
            checkpoint = starting['arm_checkpoints'][label]
            require(checkpoint['identity'] == record['source_identity'] and
                    checkpoint['state']['manifest_sha256'] == record['A_manifest'], 'different A target')
            for name, digest in record['files'].items():
                path = base/name if name in ('edit.json','incoming.json','result.json','subject.json') else base/'B'/name
                require(Path(name).name == name and sha(path) == digest, 'uncalibrated admission ' + name)
            retained = read(base/'retained-products.json')
            products = read(base/'B'/'products.json')['elf_sha256']
            require(set(retained) == set(products) == {'uv','uvx','tool'} and
                    all(retained[k]['sha256'] == value and retained[k]['bytes'] > 0 for k,value in products.items()),
                    'changed retained executable inventory')
        reports[phase] = scorer.replay(directory, plan, extra)
        require(closing['genuine_outer'][names[phase]] == sha(directory/'outer-return.json') and
                closing['results'][names[phase]] == reports[phase], 'retirement disagrees with detached clocks')
        if phase == 'pilot' and reports[phase]['continues']:
            phases.append('pairs')
    require(set(closing['results']) == {names[p] for p in phases} == set(closing['genuine_outer']),
            'extra, omitted or uncompleted measurement')
    result = {'candidate':arm, 'reference':'P' if mode == 'direct' else 'C', 'edit':edit, 'phase_results':reports,
              'complete_held_out_pairs':reports.get('pairs',{}).get('pairs',0),
              'interpretation':'A pilot is descriptive and excluded. Family-wide confirmation requires the other registered endpoints.'}
    if (root/'result.json').exists():
        require(result == read(root/'result.json'), 'published score differs from the replay')
    return result


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    print(json.dumps(replay(Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent),
                     indent=2, sort_keys=True))
