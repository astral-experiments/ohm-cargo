"""Exercise the production-binary receiver without running Cargo, rustc or Wild."""
import argparse,copy,hashlib,json,shutil,sys,tempfile
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import after48597 as m,production_score_after_48597 as n,production_score as sc
from test_production_packet import example,put,zipped
from test_production import reject
def stage(path,ds):
    for name,v in ds.items():
        dest=path/name;dest.parent.mkdir(parents=True,exist_ok=True)
        if isinstance(v,bytes):dest.write_bytes(v)
        else:shutil.copyfile(v,dest)
def run(actual=None):
    authority=HERE/'production-calibration/failed-full-48597';reg=m.authority(authority/'failed48597');record,pi,po,b=m.bind(authority/'failed48597')
    need=m.need;need(record['P_cargo_A']==3 and record['B_observations']==record['scored_pairs']==0 and po['outer']==m.TRIP,'bad authentic conformance control')
    results=[]
    with tempfile.TemporaryDirectory(prefix='mock-uvx-after-48597-') as t:
        t=Path(t)
        for y in (True,False):
            dest=t/str(y);dest.mkdir();r,h,cas=example(dest,y);d=r/'physical';hist=authority/'failed48597';shutil.copytree(hist,r/'failed48597');shutil.copytree(authority/'host',r/'host')
            def prev(n):return hist/'pins'/reg['pins']['../../package-test-full-stack/physical/'+n]
            for name in ('intake.json','worker-return.json','outer-return.json'):shutil.copyfile(prev(name),r/'predecessor'/name)
            w0=sc.read(prev('worker-return.json'));q=record['P_checkpoint'];arch=q['archive_identity'];held={v['raw_sha256']:v for v in record['P_products'].values()}
            fake={'owner':{'registered':m.SCIENCE,'plan':m.POLICY},'archive_identity':[*arch,q['bytes'],101,102,q['allocated']],'program_identities':{h:[arch[0],arch[1]+j+10000,v['compressed_bytes'],101,102,4096] for j,(h,v) in enumerate(held.items())},'donor_identity':b['source_identity'],'no_retirement_or_copy':True,'no_live_working_target':True}
            i=sc.read(d/'intake.json');i.update(locks=po['locks'],boot=po['boot'],start_ns=w0['end_ns']+1000000,previous_sha256=m.NEG,outer=m.TRIP,failed_full_handoff_registration_sha256=m.REG,failed_full_outer_sha256=m.NEG,retained_full_P=fake,failed_full_disposition_sha256=m.digest(record));put(d/'intake.json',i)
            succ=sc.read(d/'successful.json');succ['retained_full_P_sha256']=m.digest(fake);put(d/'successful.json',succ)
            w=sc.read(d/'worker-return.json');w.update(locks=i['locks'],end_ns=i['start_ns']+1000000,success=sc.sha(d/'successful.json'));put(d/'worker-return.json',w)
            o=sc.read(d/'outer-return.json');o.update(locks=i['locks'],boot=i['boot'],worker_sha256=sc.sha(d/'worker-return.json'),intake_sha256=sc.sha(d/'intake.json'));put(d/'outer-return.json',o);h=sc.sha(d/'outer-return.json')
            # The native #13 outcome and the earlier p array in this fixture are explicitly synthetic.
            # Actual pack/replay independently authenticates all older successful source receipts via older_result.
            scores={};prior={'actual_outers':{},'failed_ordinary_prepares':{},'original_effects':scores};put(r/'failed48597/earlier.json',prior)
            earlier={'actual_package_result':None,'twelve':m.twelve(scores,sc.read(hist/'pins'/m.POLICY)['family']),'earlier_outers':{},'own_outer_sha256':m.NEG,'pooled':False,'excluded_ordinary_prepares':{},'excluded_full_package':record}
            a=sc.read(r/'family.json');a.update(own_outer_sha256=h,native_outer=o['outer'],original_twelve=earlier,thirteen=sc.engine().holm13(earlier,a['outcome'],sc.plan()));a['thirteen'][m.LABEL]['excluded']=True;put(r/'family.json',a)
            old=m.pp.original()
            with patch.object(old,'older_result',return_value=scores),patch.object(m.pp,'original',return_value=old):
                f=dest/'mock-native.zip';zipped(r,f);out=n.run(f,h,dest,None,cas);need(out['credited_pairs']==(12 if y else 0) and out['decision']['confirmed'] is y and out['thirteen'][m.LABEL]['excluded'] and out['thirteen'][m.LABEL]['raw_p']==1 and out['actual_elf_bytes_independently_reread'],'mock case')
                if y:
                    bad=copy.deepcopy(i);bad['retained_full_P']['archive_identity'][1]+=2;reject(lambda:m.owner(bad,record,b))
                    bad=copy.deepcopy(i);bad['retained_full_P']['donor_identity']=[1,2];reject(lambda:m.owner(bad,record,b))
                    bad=copy.deepcopy(i);bad['failed_full_disposition_sha256']='0'*64;reject(lambda:m.owner(bad,record,b))
                    bad=copy.deepcopy(a);bad['original_twelve']['twelve'][m.LABEL]['complete']=True;put(r/'family.json',bad);reject(lambda:n.audit(r,h));put(r/'family.json',a)
                    bad=copy.deepcopy(a);bad['thirteen'][m.LABEL]['excluded']=False;put(r/'family.json',bad);reject(lambda:n.audit(r,h));put(r/'family.json',a)
                    w.update(code=1,worker_exit=1,success=None);put(d/'worker-return.json',w);o['outer']['exit']=o['worker_code']=1;o['worker_sha256']=sc.sha(d/'worker-return.json');put(d/'outer-return.json',o);(d/'failure.log').write_text('synthetic emergency reserve');out2=n.audit(r,sc.sha(d/'outer-return.json'));need(out2['credited_pairs']==0 and out2['decision_p']==1,'false credit on newer failure')
                results.append([out['credited_pairs'],out['decision']['confirmed']])
    return {'synthetic_production_cases':results,'synthetic_failed_13_p':1,'historical_owner':m.TRIP,'verified_before_scoring':{'actual_12th_p':1,'actual_12th_CZD_A':0,'actual_12th_B':0,'actual_P_A':3,'programs':17},'rejects':['moved archive','changed donor','substituted raw exclusion','missing 13-table exclusion','fabricated 12th result'],'earlier_completed_effects_mocked_only_in_this_test':True,'real_compilers_or_links':0}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
