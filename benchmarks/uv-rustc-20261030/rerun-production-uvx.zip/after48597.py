"""Verify the excluded full-package resource return and independently reproduce its place in the family."""
import hashlib,json,re,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_host as host,production_previous as pp
from common import need
from production_score import plan,read,sha
REG='88a902281627f39373767e77d5d6268c236fc0ea5bcb2086769cf5487575d734'
NEG='463d220c5529aa264083970ce619a4c7be3d28f93404ee9e6b922b9354a447ce'
FAIL_ZIP='2ab8f5e107026f964fb724312e1e12ec14d3b04b494dc8bd33dcaef57e130b1c'
STOCK='31c2d0425da15c652970eb79bcd79706810ba3b6e9a97cb21ecdb8ad1a3e4548'
SCIENCE='d9791f9e9fe4995725327c143032e699ac38e30913d7a50df8e6e4f5eae3d988'
BINS='56a3208b66bd9f47c37a64356c1eb6e4bd296955ab9685077ff5f00bf3c29518'
POLICY='c545177f4e5e2fb4284ce034187fa5d8b4619154a3d659f57fbdf2a589112cd1'
TRIP={'session':48597,'chunk':'5e7240','exit':1}
LABEL='P-to-CZD/package-test'
def digest(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def authority(R):
    q=read(R/'registration.json');need(sha(R/'registration.json')==REG and q['actual_previous']==NEG and q['bins_science']==BINS and q['full_stack_science']==SCIENCE and q['p']==1 and q['permanent_excluded_endpoint']==LABEL,'wrong parent resource authority')
    for h in q['pins'].values():need(re.fullmatch('[0-9a-f]{64}',h) and sha(R/'pins'/h)==h,'resource or scientific source changed')
    return q
def bind(R):
    q=authority(R);pins=q['pins']
    def path(n):return R/'pins'/pins['../../package-test-full-stack/physical/'+n]
    def get(n):return read(path(n))
    i=get('intake.json');o=get('outer-return.json');w=get('worker-return.json');end=w['capacity']['ending']
    need(sha(path('outer-return.json'))==NEG and o['outer']==TRIP and o['worker_sha256']==sha(path('worker-return.json')) and o['intake_sha256']==sha(path('intake.json')) and w['worker_exit']==w['code']==1 and w['success'] is None and w['owned_children_at_return']==o['remaining_workers']==o['foreign']==[] and o['host_released'] and i['previous_sha256']==STOCK,'the actual first package failure was not retained')
    fail=path('failure.log').read_text();need("second=warm('CZD',subjects)" in fail and '13*GIB+(256<<20)' in fail and fail.rstrip().endswith('ValueError: private live reserve or estimated copy exceeds allowance') and end['shm']<((19<<30)+(256<<20)),'wrong cause for exclusion')
    A=get('warm-P/source-A.json');check=get('warm-P/checkpoint.json');before=get('warm-P/incoming.json');ret=get('warm-P/retired.json');forms=get('warm-P/ordinary-repeat-A/p-only-classes.json');products=get('warm-P/retained-products.json')
    need(A['form']=='A' and A==get('warm-P/inner-return.json')['final_source'] and check['original']==ret['id']==before['identity'] and check['archive_compared_with_live'] and ret['before']['unique_allocated_bytes']==check['state']['allocated_unique']==check['actual_slot_allocated'],'different archived P checkpoint')
    need(get('warm-P/ordinary-repeat-A/all-products.json')==get('warm-P/verify-repeat-A/all-products.json') and get('warm-P/ordinary-repeat-A/pre-trace-retained.json')==products and len(forms['roles'])==len(products)==17 and forms['independent_arm']=='P' and forms['command_sha256']==sha(path('warm-P/ordinary-repeat-A/command.json')) and forms['retained_sha256']==sha(path('warm-P/ordinary-repeat-A/pre-trace-retained.json')) and forms['raw_inventory_sha256']==sha(path('warm-P/ordinary-repeat-A/all-products.json')),'wrong pre-candidate class or P inventory')
    for tag,traced in [('apply-compiler-A',True),('ordinary-repeat-A',False),('verify-repeat-A',True)]:
        v=get('warm-P/'+tag+'/command.json');need(v['exit']==0 and v['traced'] is traced and v['argv'][1:]==['test','--locked','--offline','-j8','-p','uv','--no-run'],'wrong unscored P warm')
    binary_path=Path(check['path'])
    record={'outer_sha256':NEG,'outer':TRIP,'previous_stock_sha256':STOCK,'registered_host':i['stock_capacity_handoff_registration_sha256'],'outcome':'unscored capacity rejection before first CZD A preparation','eligible_p':1,'P_cargo_A':3,'CZD_cargo_A':0,'B_observations':0,'scored_pairs':0,'native_qa_sha256':sha(path('native/verified.json')),'P_checkpoint':check,'P_only_A_sha256':sha(path('warm-P/ordinary-repeat-A/p-only-classes.json')),'P_products':products,'retired_P_target':ret['id'],'capacity_ending':end,'full_warm_required_shm':(19<<30)+(256<<20),'retained_paths':{'archive':str(binary_path),'programs':str(binary_path.parent/'products')}}
    return record,i,o,before
def owner(i,record,before):
    own=i['retained_full_P'];arch=own['archive_identity'];cp=record['P_checkpoint'];items={v['raw_sha256']:v for v in record['P_products'].values()};ids=own['program_identities']
    need(i['failed_full_handoff_registration_sha256']==REG and i['failed_full_outer_sha256']==i['previous_sha256']==NEG and i['failed_full_disposition_sha256']==digest(record) and own['no_live_working_target'] and own['no_retirement_or_copy'] and own['owner']['registered']==SCIENCE and own['owner']['plan']==POLICY and len(arch)==6 and arch[:2]==cp['archive_identity'] and arch[2]==cp['bytes'] and arch[-1]==cp['allocated'] and own['donor_identity']==before['source_identity'] and set(ids)==set(items) and all(len(t)==6 and t[2]==items[h]['compressed_bytes'] and t[0]==arch[0] for h,t in ids.items()) and len({tuple(t[:2]) for t in [arch,*ids.values()]})==18,'altered saved P archive/CAS or false failed-return admission')
def controls(root,i,previous_packet,scratch):
    record,pi,po,b=bind(root/'failed48597');owner(i,record,b)
    need(po==read(root/'predecessor/outer-return.json') and pi==read(root/'predecessor/intake.json') and po['outer']==i['outer'] and i['boot']==po['boot'] and i['locks']==po['locks'] and i['start_ns']>=read(root/'predecessor/worker-return.json')['end_ns'],'disjoint boot/leases or overlap with failed package')
    host.recorded(root/'host',pi,'full')
    if previous_packet is not None:
        need(sha(previous_packet)==FAIL_ZIP,'different archived failed full-package attempt')
        x=pp.run(previous_packet,NEG,scratch);need(x['family_p']==1 and not x['eligible'] and x['scored_pairs']==x['raw_completed_B_commands']==0,'failed first package received credit')
    return record
def twelve(effects,settings):
    names=settings['ordered_labels'];excluded=settings['permanently_excluded'];need(LABEL in names and len(names)==len(set(names))==12 and LABEL not in effects and set(effects)<=set(names)-set(excluded),'failed, missing or undeclared input')
    raw={k:effects[k]['p_against_2']['two_sided_p'] if k in effects else 1.0 for k in names};res={};prev=0.
    for j,k in enumerate(sorted(names,key=lambda n:(raw[n],n))):
        need(0<=raw[k]<=1,'invalid p');prev=max(prev,min(1.,(12-j)*raw[k]));res[k]={'raw_p':raw[k],'adjusted_p':prev,'complete':k in effects,'confirmed':bool(k in effects and effects[k]['individual_gate'] and prev<.05),'excluded':k in excluded or k==LABEL}
    return res
def earlier(root,record,family):
    R=root/'failed48597';v=pp.original();prior=read(R/'earlier.json');scores=v.older_result(R,prior);p=read(R/'pins'/POLICY)
    need(family=={'actual_package_result':None,'twelve':twelve(scores,p['family']),'earlier_outers':prior['actual_outers'],'own_outer_sha256':NEG,'pooled':False,'excluded_ordinary_prepares':prior['failed_ordinary_prepares'],'excluded_full_package':record},'earlier genuine effects or fixed twelve-way family changed')
def scope_files(X,i):
    d=X/'after-full-capacity';reg=read(d/'registration.json');need(sha(d/'registration.json')==REG,'different custody repair');files={'failed48597/registration.json':d/'registration.json'}
    for name,h in reg['pins'].items():
        f=(d/name).resolve(strict=True);need(f.is_relative_to(X.parent.resolve()) and f.is_file() and not f.is_symlink() and f.stat().st_size<2<<20 and sha(f)==h,'changed registered evidence');files['failed48597/pins/'+h]=f
    pi=read(X.parent/'package-test-full-stack/physical/intake.json')
    for n,f in host.build(X.parent,pi).items():files['host/'+n]=f
    return files
def previous_effects(X,family):
    d=X.parent;v=pp.original()
    from unittest.mock import patch
    source=d/'portable-package-full-stack/native/export.py'
    need(sha(source)=='d5bac1513d86f55283da3e9f1161833b8061f7859562a1570e5f7b9b3de0b334','changed previous evidence collector')
    with patch.dict(sys.modules,{'verify':v}):export=pp.mod('pinned_twelve_export',source)
    earliest={'actual_outers':family['earlier_outers'],'original_effects':{},'failed_ordinary_prepares':family['excluded_ordinary_prepares']}
    files={};export.add_earlier(files,earliest)
    for label in earliest['actual_outers']:
        key='previous/'+label.replace('/','--')+'/';receipt=read(files[key+'successful.json'])
        if label=='CZD/package-test-v3':score=read(files[key+'analysis.json'])['score']
        else:
            study='physical-pairs' if label=='P-to-ZD/tool-test' else 'physical-pairs-'+label.replace('/','-')
            score=receipt['outcome']['results'].get(study)
        if score is not None:earliest['original_effects'][label]=score
    return {'failed48597/'+n:x for n,x in files.items()}|{'failed48597/earlier.json':v.encoded(earliest)}
