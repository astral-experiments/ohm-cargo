"""Bring the existing compact twelve-way replay/export across the one material-only custody repair."""
import argparse,importlib.util,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_host as host
def mod(name,path):
    z=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(z);z.loader.exec_module(m);return m
def original():
    v=mod('unaltered_previous_full_scorer',HERE/'production_prior.py');v.need(v.sha(HERE/'production_prior.py')=='9f434e212f29543bd45558b355ae7ecf59e473c8ca7f3f386dc6c933b1f9c787','changed twelve-way replay');return v
def run(packet,expected,scratch=None,elf_cas=None,reserve=0):
    v=original();audit=v.audit
    def checked(root,h,work,cas=None):
        i=v.data(root/'physical/intake.json')
        if 'stock_disposition_registration_sha256' in i:host.recorded(root/'owner/stock-2868',i,'full')
        else:v.need(Path(i['previous']).as_posix().endswith('/private-normalize-fanout/physical/outer-return.json'),'unrecognized stock custody')
        return audit(root,h,work,cas)
    with patch.object(v,'audit',checked):return v.run(packet,expected,scratch,elf_cas,reserve)
def export(D,expected,previous,destination,scratch,elf_cas=None,reserve=122<<30):
    D=Path(D).resolve(strict=True);S=D/'package-test-full-stack';V=D/'portable-package-full-stack/native';v=original()
    v.need(v.sha(V/'verify.py')==v.sha(HERE/'production_prior.py') and v.sha(V/'export.py')=='d5bac1513d86f55283da3e9f1161833b8061f7859562a1570e5f7b9b3de0b334','wrong existing native exporter')
    with patch.dict(sys.modules,{'verify':v}):e=mod('original_twelve_exporter',V/'export.py')
    raw=S/'physical';outer,w=v.outer(raw,expected);i=v.data(raw/'intake.json');files=e.sources(previous)
    for name,f in host.build(D,i).items():files['owner/stock-2868/'+name]=f
    f=Path(i['previous']);v.need(f.resolve()==D.parent/'private-normalize-fanout/failed-first-anchor/physical/outer-return.json' and v.sha(f)==i['previous_sha256'],'different actual stock disposition')
    files['owner/immediate-previous.json']=f
    if not w['code']:
        family=e.effect([host.selected(D,i,'full'),'family']);earlier=e.effect([D/'after-ordinary-failures/earlier_effects.py'])
        v.need(family['own_outer_sha256']==expected and family['earlier_outers']==earlier['actual_outers'],'different previous family')
        e.add_earlier(files,earlier);files.update(e.all_observations(raw));files['owner/family.json']=v.encoded(family);files['owner/earlier.json']=v.encoded(earlier)
    else:files.update(e.denied_observations(raw))
    destination=Path(destination).resolve();scratch=Path(scratch).resolve(strict=True);v.need(not destination.exists() and reserve>=0 and all(shutil.disk_usage(f).free>=reserve+(128<<20) for f in (scratch,destination.parent)),'not enough space')
    with tempfile.TemporaryDirectory(dir=destination.parent,prefix='.stack-custody-export-') as tmp:
        new=Path(tmp)/'result.zip';e.packet(files,new);proof=run(new,expected,scratch,elf_cas,reserve);v.need(proof['eligible']==(outer['exit']==0) and shutil.disk_usage(destination.parent).free>=reserve,'different scientific disposition');os.link(new,destination)
    return {'packet':str(destination),'sha256':v.sha(destination),'bytes':destination.stat().st_size,'outer':outer,'independent_replay':proof}
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);cmd=a.add_subparsers(dest='op',required=True);x=cmd.add_parser('export');x.add_argument('--study-parent',required=True,type=Path);x.add_argument('--previous-combined',required=True,type=Path);x.add_argument('--out',type=Path,required=True);x.add_argument('--reserve-gib',type=int,default=122)
    y=cmd.add_parser('replay');y.add_argument('packet',type=Path)
    for k in (x,y):k.add_argument('--outer',required=True);k.add_argument('--scratch',required=True,type=Path);k.add_argument('--elf-cas',type=Path)
    q=a.parse_args();v=export(q.study_parent,q.outer,q.previous_combined,q.out,q.scratch,q.elf_cas,q.reserve_gib<<30) if q.op=='export' else run(q.packet,q.outer,q.scratch,q.elf_cas)
    print(json.dumps(v,indent=2,sort_keys=True))
