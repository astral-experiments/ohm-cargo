"""Synthetic native custody controls. The resources, clock values and outer triplets below are fixtures."""
import hashlib,json,shutil,sys,tempfile,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_host as host, production_capacity as cap,production_previous as pp
import test_resource2868 as base
def put(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
def fake_storage(C,stage):
    core=host.read(C/'exdev-reg.json');boot=stage['boot'];locks=stage['locks'];four=core['four_locks'];E=C/'material'
    pr=host.sha(C/'exdev-primary.json');sec=host.sha(C/'exdev-secondary.json');ex=host.sha(C/'exdev-reg.json')
    rows={x['rel']:x for p in ('exdev-primary.json','exdev-secondary.json') for x in host.read(C/p)['result']['accepted']};used=[];size=0
    for n,v in rows.items():
        if size>=13*(1<<28):break
        used.append(n);size+=v['private_bytes']
    need=host.need;need(size>=3<<30,'registered dry proofs lack minimum tranche')
    plan={'selected':used,'reader':{'synthetic':True},'donors':{n:rows[n]['sha256'] for n in used},'confirmed_private_bytes':size,'independent_source_leases':len(used),'victim_leases':len(used)};put(E/'journal/before.json',plan)
    disposition={'retired':used,'proven_private_bytes':size,'reader_control':plan['reader'],'journal_sha256':host.sha(E/'journal/before.json'),'source_names_unchanged':True,'write_leases_closed':True}
    res={'registration':ex,'proof_sha256':pr,'second_proof_sha256':sec,'disposition':disposition,'all_remaining_relative_names_unmodified_by_this_operator':True,'benchmark_authorized':False};put(E/'result.json',res)
    inp={'registration':ex,'capacity_rejected':cap.STOP,'previous_sha256':host.STORAGE,'outer':stage['outer'],'boot':boot,'locks':locks,'all_four_locks':four,'proof_sha256':pr,'second_proof_sha256':sec,'start_ns':100,'pid':799};put(E/'intake.json',inp)
    w={'worker_exit':0,'code':0,'locks':locks,'all_four_locks':four,'end_ns':200,'native_at_return':[],'result_sha256':host.sha(E/'result.json'),'pid':799};put(E/'worker-return.json',w)
    o={'outer':{'session':12890,'chunk':'0abced','exit':0},'worker_code':0,'host_released':True,'foreign':[],'remaining_workers':[],'worker_sha256':host.sha(E/'worker-return.json'),'intake_sha256':host.sha(E/'intake.json'),'locks':locks,'boot':boot};put(E/'outer-return.json',o)
    put(E/'returned-four-locks.json',{'outer':o['outer'],'all_four_locks_reacquired':True,'locks':four,'boot':boot,'worker_sha256':o['worker_sha256'],'time_ns':300})
    return o
def synthetic_prior(tmp,H,inc,material):
    v=pp.original();files={};mp=host.read(HERE/'production-calibration/capacity-authority/twelve-source-map.json')
    for n,h in v.PINS.items():
        f=HERE/mp[h];assert host.sha(f)==h;files['sources/'+n]=f.read_bytes()
    for f in H.rglob('*'):
        if f.is_file():files['owner/stock-2868/'+f.relative_to(H).as_posix()]=f.read_bytes()
    files['owner/immediate-previous.json']=(H/'actual/outer-return.json').read_bytes()
    boot=material['boot'];locks=material['locks'];intake=dict(inc,registration=v.OWN['registration.json'],host_after_check_registration_sha256=v.HOST['registration.json'],boot=boot,locks=locks,start_ns=5000)
    worker={'code':1,'worker_exit':1,'owned_children_at_return':[],'locks':locks,'end_ns':6000};b=v.encoded
    outer={'outer':{'session':12990,'chunk':'abddda','exit':1},'worker_code':1,'boot':boot,'locks':locks,'host_released':True,'foreign':[],'remaining_workers':[],'intake_sha256':v.digest(b(intake)),'worker_sha256':v.digest(b(worker))}
    files.update({'physical/intake.json':b(intake),'physical/worker-return.json':b(worker),'physical/outer-return.json':b(outer),'physical/failure.log':b'synthetic denial\n'})
    layout={n:v.digest(x) for n,x in files.items()};z=tmp/'failed-twelve.zip'
    with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as writer:
        writer.writestr('layout.json',b({'schema':1,'scope':v.SCOPE,'files':layout}));writer.writestr('verify.py',(HERE/'production_prior.py').read_bytes());writer.writestr('README.md','Synthetic resource regression only.\n')
        for h in set(layout.values()):writer.writestr('objects/'+h,files[next(n for n in files if layout[n]==h)])
    ret=pp.run(z,v.digest(b(outer)),tmp);assert ret['eligible'] is False and ret['family_p']==1 and ret['scored_pairs']==0;return ret
def main():
    with tempfile.TemporaryDirectory() as t:
        t=Path(t);base.run(t);H=t/'proof';C=H/'capacity';shutil.copytree(HERE/'production-calibration/capacity-authority',C)
        stage=host.read(H/'pins'/host.STORAGE);E=fake_storage(C,stage);Q=H/'actual';qin=host.read(Q/'intake.json');qin.update(previous_sha256=host.sha(C/'material/outer-return.json'),outer=E['outer'])
        qin['previous']=host.read(C/'stock-bridge.json')['allowed_positive'];fp=host.read(Q/'first-return.json');fp['original_owned_copy_retired']=host.read(C/'stock-first-anchor.json')['copy'];put(Q/'first-return.json',fp)
        (C/'material-stock').mkdir();shutil.copyfile(C/'stock-first-anchor.json',C/'material-stock/first-anchor.json');put(Q/'intake.json',qin);mat=host.read(Q/'outer-return.json');mat.update(intake_sha256=host.sha(Q/'intake.json'));put(Q/'outer-return.json',mat)
        incoming={'previous':'/synthetic/private-normalize-fanout/failed-first-anchor/physical/outer-return.json','previous_sha256':host.sha(Q/'outer-return.json'),'outer':mat['outer'],'stock_capacity_handoff_registration_sha256':cap.NEW,'stock_no_start_outer_sha256':cap.STOP,'stock_disposition_registration_sha256':host.REG,'excluded_stock_outer_sha256':host.STOCK}
        assert host.recorded(H,incoming,'full')['cohort_scores']==0 and host.recorded(H,incoming,'bins')['original_B_rows']==0
        result=synthetic_prior(t,H,incoming,mat);rejected=[]
        for label,path,field,value in [('fresh credit for refused original',C/'noreturn.json','scored_rows',1),('foreign compiler at retirement',C/'material/outer-return.json','foreign',['bogus']),('failed receipt presented as storage success',C/'material/worker-return.json','code',1),('donor reader not closed',C/'material/returned-four-locks.json','all_four_locks_reacquired',False)]:
            raw=path.read_bytes();v=host.read(path);v[field]=value;put(path,v)
            try:host.recorded(H,incoming,'full')
            except (ValueError,AssertionError,KeyError):rejected.append(label)
            else:raise AssertionError('accepted '+label)
            path.write_bytes(raw)
        assert len(rejected)==4
        print(json.dumps({'synthetic':True,'real_compilers_launched':0,'real_performance_observations':0,'integrated_excluded_twelve_p':result['family_p'],'synthetic_failed_twelve_rows':result['scored_pairs'],'material_admission_zero_credit':True,'rejected':rejected},sort_keys=True))
if __name__=='__main__':main()
