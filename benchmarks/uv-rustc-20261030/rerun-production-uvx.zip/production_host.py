"""Authenticate the material-only stock-2868 handoff separately from both scientific studies."""
import hashlib,json,re,subprocess
from pathlib import Path
REG='7d9110c0076940a3e25a302495e8fe6d81da450459fc1f5c087371684a55c5cd'
STOCK='9c7523e457b5d99c9ac2bac4aba1c9818204b8b602dc42a41de0e2b63fa1468e'
STORAGE='99f42688ce0a2b93ca0f2d58ef5d3c607b330b191a598c7ba55b2c53134c8191'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,m):
    if not x:raise ValueError(m)
def pinned_sources(D):
    p=D/'after-stock-2868/registration.json';need(sha(p)==REG,'unregistered resource bridge')
    reg=read(p);rows={'registration.json':p}
    for rel,h in reg['pins'].items():
        f=(p.parent/rel).resolve(strict=True);need(f.is_relative_to(D.parent.resolve()) and sha(f)==h,'changed pinned host evidence');rows['pins/'+h]=f
    return reg,rows
def selected(D,i,kind):
    if set(('stock_capacity_handoff_registration_sha256','stock_no_start_outer_sha256'))&i.keys():
        import production_capacity as capacity
        capacity.marks(i)
        return D/'after-stock-2868/after-capacity'/(kind+'.py')
    return D/'after-stock-2868'/(kind+'.py')
def build(D,i):
    reg,rows=pinned_sources(D);need(i['stock_disposition_registration_sha256']==REG and i['excluded_stock_outer_sha256']==STOCK,'native collector did not use this typed handoff')
    q=D.parent/'private-normalize-fanout/failed-first-anchor/physical'
    for n in ('intake.json','worker-return.json','outer-return.json','first-return.json','disposition.json'):rows['actual/'+n]=q/n
    if 'stock_capacity_handoff_registration_sha256' in i or 'stock_no_start_outer_sha256' in i:
        import production_capacity as capacity
        rows.update({'capacity/'+name:file for name,file in capacity.build(D,i).items()})
    return rows
def recorded(root,i,kind):
    reg=read(root/'registration.json');need(sha(root/'registration.json')==REG and i['stock_disposition_registration_sha256']==REG and i['excluded_stock_outer_sha256']==STOCK,'unregistered stock disposition')
    for key,h in reg['pins'].items():need(re.fullmatch('[0-9a-f]{64}',h) and sha(root/'pins'/h)==h,'changed pinned source/failure')
    def before(ending):
        picks=[v for k,v in reg['pins'].items() if k.endswith(ending)];need(len(picks)==1,'ambiguous old path');return read(root/'pins'/picks[0])
    known=reg['failed_stock'];need(known['old_stock_remains_excluded'] and known['sha256']==STOCK and known['stage0_return_sha256']==STORAGE and known['edited_commands']==known['scored_pairs']==0 and not known['scientific_result'],'wrong old stock scope')
    actual=root/'actual';s=read(actual/'intake.json');w=read(actual/'worker-return.json');o=read(actual/'outer-return.json');d=read(actual/'disposition.json');old=before('/root-compiler-space-audit/stage0-pair/physical/outer-return.json')
    want=STORAGE;expected_registration=reg['new_material_registration_sha256']
    if 'stock_capacity_handoff_registration_sha256' in i or 'stock_no_start_outer_sha256' in i:
        import production_capacity as capacity
        old,want,expected_registration=capacity.recorded(root/'capacity',i,old,s)
    need(o['outer']['exit']==o['worker_code']==w['worker_exit']==0 and w['code']==0 and o['host_released'] is True and o['remaining_workers']==o['foreign']==w['native_at_return']==[] and
          s['outer']==old['outer'] and s['previous_sha256']==want and o['intake_sha256']==sha(actual/'intake.json') and o['worker_sha256']==sha(actual/'worker-return.json') and
          o['boot']==s['boot']==old['boot'] and s['locks']==w['locks']==o['locks']==old['locks'] and s['start_ns']<w['end_ns'] and
          s['original_failed']==STOCK and s['registration']==expected_registration and w['disposition_sha256']==sha(actual/'disposition.json') and
          d['status'] in ('completed descriptive diagnostic','inconclusive') and (d['status']=='completed descriptive diagnostic')==(d['observation'] is not None) and d['all_private_copies_released'] and d['native_readers']==[] and
          d['original_B_rows']==d['cohort_scores']==read(actual/'first-return.json')['original_B_observations']==0 and d['original_excluded']==read(actual/'first-return.json')['original_excluded']==STOCK,'invalid release of failed unscored stock resources')
    if kind=='full':need(i['previous_sha256']==sha(actual/'outer-return.json') and i['outer']==o['outer'],'different material predecessor')
    else:need(kind=='bins','unknown native comparison')
    return {'original_stock_succeeded':False,'original_B_rows':0,'material_outer':o['outer'],'material_sha256':sha(actual/'outer-return.json'),'cohort_scores':0}
