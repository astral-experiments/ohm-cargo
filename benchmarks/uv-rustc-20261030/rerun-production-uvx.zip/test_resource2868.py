"""Synthetic dispositions and adversarial source/resource records. No compiler or study data."""
import copy,hashlib,json,shutil,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_host as h
import production_git as g
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def run(tmp):
    root=tmp/'proof';shutil.copytree(HERE/'production-calibration/resource-authority',root)
    reg=h.read(root/'registration.json');aa=root/'actual';aa.mkdir()
    old=h.read(root/'pins'/h.STORAGE);ns=2001;locks=old['locks'];boot=old['boot']
    mat={'previous_sha256':h.STORAGE,'outer':old['outer'],'boot':boot,'locks':locks,'start_ns':ns,'registration':reg['new_material_registration_sha256'],'original_failed':h.STOCK}
    observed={'original_excluded':h.STOCK,'original_B_observations':0};write(aa/'first-return.json',observed);write(aa/'intake.json',mat)
    di={'status':'inconclusive','all_private_copies_released':True,'native_readers':[],'original_B_rows':0,'cohort_scores':0,'original_excluded':h.STOCK,'observation':None};write(aa/'disposition.json',di)
    w={'code':0,'worker_exit':0,'locks':locks,'end_ns':ns+1,'native_at_return':[],'disposition_sha256':h.sha(aa/'disposition.json')};write(aa/'worker-return.json',w)
    o={'outer':{'session':888,'chunk':'c0ffee','exit':0},'locks':locks,'boot':boot,'worker_code':0,'host_released':True,'remaining_workers':[],'foreign':[],'intake_sha256':h.sha(aa/'intake.json'),'worker_sha256':h.sha(aa/'worker-return.json')};write(aa/'outer-return.json',o)
    incoming={'stock_disposition_registration_sha256':h.REG,'excluded_stock_outer_sha256':h.STOCK,'previous_sha256':h.sha(aa/'outer-return.json'),'outer':o['outer']}
    assert h.recorded(root,incoming,'full')['original_B_rows']==0 and h.recorded(root,incoming,'bins')['cohort_scores']==0
    bad=[]
    def rejects(label,fn):
        try:fn()
        except (ValueError,KeyError,AssertionError):bad.append(label)
        else:raise AssertionError('wrongly accepted '+label)
    rejects('old resource treated as scientific',lambda:h.recorded(root,dict(incoming,excluded_stock_outer_sha256='0'*64),'full'))
    rejects('detached material from different immediate predecessor',lambda:h.recorded(root,dict(incoming,previous_sha256=h.STORAGE),'full'))
    write(aa/'disposition.json',dict(di,cohort_scores=1));rejects('positive score for failed stock',lambda:h.recorded(root,incoming,'bins'));write(aa/'disposition.json',di)
    path=h.read(HERE/'production-original/guard-file-free-math-asm/production-uvx-bins/protocol.json')
    z=h.read(HERE/'production-calibration/source-git.json');data={n:(HERE/'production-original/uvx-binary-edit'/(n+'.rs')).read_bytes() for n in ('A','B')}
    assert set(g.verify(z,path,data))=={'A','B'};alt=copy.deepcopy(z);first=next(iter(alt['trees'].values()));first[0]['mode']='100600'
    rejects('forged Git tree entry',lambda:g.verify(alt,path,data));rejects('other post-edit bytes',lambda:g.verify(z,path,dict(data,B=data['A'])))
    return {'synthetic_material':True,'real_prior_registrations_verified':True,'source_Git_role_count':2,'rejected':bad,'native_performance':False}
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:print(json.dumps(run(Path(tmp)),sort_keys=True))
