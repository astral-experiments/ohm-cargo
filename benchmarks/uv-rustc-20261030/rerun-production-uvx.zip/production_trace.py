"""Capture the two real public programs, their source owners, raw exec arguments and selected compiler."""
import hashlib,json,os,threading,time
from pathlib import Path
from common import need,sha,write
from full_stack_trace import args_from

def real_rust(args):
    return '--crate-name' in args and any(v=='--emit' or v.startswith('--emit=') for v in args) and not any(v=='--print' or v.startswith('--print=') for v in args)

def trace_rows(folder,argv,sdk):
    rows=[];paths=sorted(folder.glob('exec.*'));cargo=[];rust=[];wild=[]
    for path in paths:
        pid=int(path.suffix[1:])
        for line in path.read_text().splitlines():
            event=args_from(line.strip())
            if event is None:continue
            exe,args=event;rows.append((pid,exe,args))
            if args==argv and exe==argv[0]:cargo.append(pid)
            if Path(exe).name=='rustc' and real_rust(args):
                need(Path(exe).samefile(sdk/'bin/rustc'),'unexpected compiler')
                rust.append((pid,exe,args))
            if '/wild-ld/' in exe:
                need(Path(exe).resolve().is_relative_to(sdk.resolve()),'unexpected Wild')
                wild.append((pid,exe,args))
    need(len(cargo)==1 and len(rows)>0,'missing or repeated top-level Cargo')
    return rust,wild,{p.name:sha(p) for p in paths}

def argument(args,flag):
    found=[args[i+1] for i,x in enumerate(args[:-1]) if x==flag]+[x[len(flag)+1:] for x in args if x.startswith(flag+'=')]
    need(len(found)==1,'missing/ambiguous '+flag)
    return found[0]

def owner_paths(rust,wild,target,required):
    result={};jobs=[];links=[]
    for pid,exe,args in wild:
        outputs=[args[i+1] for i,a in enumerate(args[:-1]) if a=='-o']
        if len(outputs)==1:links.append([exe,outputs[0]])
    for pid,exe,args in rust:
        source=next((x for x in args if x in ('crates/uv/src/bin/uv.rs','crates/uv/src/bin/uvx.rs')),None)
        name=argument(args,'--crate-name');guard='-Zohm-check-relink-inputs' in args
        jobs.append({'pid':pid,'exe':exe,'argv':args,'input':source,'guard':guard,'link_only':'-Zlink-only' in args,
                     'argv_sha256':hashlib.sha256(json.dumps(args,separators=(',',':')).encode()).hexdigest()})
        if source is None:continue
        need(name==Path(source).stem and name not in result and '--test' not in args and 'link' in argument(args,'--emit').split(','),'unexpected owning binary rustc')
        output=(Path(argument(args,'--out-dir'))/name).resolve(strict=True)
        need(output.is_relative_to(target.resolve()) and any(Path(p).resolve()==output for _,p in links),'no actual Wild output match')
        result[name]=str(output.relative_to(target.resolve()))
    need(required<=set(result),'missing required actual binary owner')
    return result,jobs,sorted(links)

class DriverMaps:
    def __init__(self,sdk,driver):
        self.exe=(sdk/'bin/rustc').stat();self.driver=(sdk/driver).stat();self.stop=threading.Event();self.rows={};self.sid=None;self.error=None
    def start(self,sid):
        self.sid=sid
        def observe():
            try:
                while not self.stop.is_set():
                    for p in Path('/proc').glob('[0-9]*/stat'):
                        try:
                            vals=p.read_bytes().rsplit(b') ',1)[1].split()
                            if int(vals[3])!=self.sid:continue
                            proc=p.parent;pid=int(proc.name)
                            if str(pid) in self.rows:continue
                            e=(proc/'exe').stat()
                            if (e.st_dev,e.st_ino)!=(self.exe.st_dev,self.exe.st_ino):continue
                            for row in (proc/'maps').read_text().splitlines():
                                fields=row.split(None,5)
                                if len(fields)<6 or 'librustc_driver' not in fields[5]:continue
                                major,minor=(int(x,16) for x in fields[3].split(':'))
                                if (os.makedev(major,minor),int(fields[4]))==(self.driver.st_dev,self.driver.st_ino):
                                    self.rows[str(pid)]={'start_ticks':int(vals[19]),'driver_dev':self.driver.st_dev,'driver_ino':self.driver.st_ino};break
                        except (FileNotFoundError,ProcessLookupError):continue
                    self.stop.wait(.01)
            except Exception as e:self.error=repr(e)
        self.thread=threading.Thread(target=observe,daemon=True);self.thread.start()
    def finish(self):
        self.stop.set();self.thread.join();need(not self.error,'could not authenticate the selected process: '+str(self.error))
        return self.rows
