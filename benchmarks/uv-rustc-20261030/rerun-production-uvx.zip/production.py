"""Fresh C/CZD run of uv #22742 on the two installed production binaries."""
import argparse,copy,hashlib,json,os,re,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import package_process as proc
import rerun as old
import production_banks as banks
import production_trace as trace
from common import allocated,need,sha,stamps,write
from production_score import engine,ARMS,NAME,original,plan,source_path,validate_behavior

class Guard(proc.Observer):
    def __init__(self,runner):
        super().__init__();self.runner=runner;self.child=None;self.limit=time.monotonic()+1800
    def scan(self):
        if threading.current_thread() is not threading.main_thread() and self.runner.watch_cpu is not None:os.sched_setaffinity(0,{self.runner.watch_cpu})
        events=super().scan()
        try:self.runner.space()
        except ValueError as failure:self.events.append({'ns':time.monotonic_ns(),'space':str(failure)})
        child=self.child
        if child is not None and child.poll() is None and (self.events or time.monotonic()>self.limit):
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        return events

def heading(o):return [o['packages'],o['changed_stamps']]
def safe_file(root,relative):
    file=root/relative;resolved=file.resolve(strict=True)
    need(resolved.is_relative_to(root.resolve()) and resolved.is_file() and os.access(file,os.X_OK),'unexpected executable output')
    return file

def proof_sources(clone,src):
    s=src['source'];path=s['source_path'];b=s['upstream_commit'];a=s['upstream_parent']
    from production_git import verify
    proof=json.loads((HERE/'production-calibration/source-git.json').read_bytes())
    data={k:source_path(k+'.rs').read_bytes() for k in ('A','B')}
    verify(proof,src,data)
    need(old.git(clone,'show',s['uv_base']+':'+path)==data['A'],'benchmark checkout is missing the original source')
    for form,commit in (('A',a),('B',b)):
        q=subprocess.run(['git','-C',str(clone),'cat-file','--batch-check=%(objecttype)'],input=commit.encode()+bytes([10]),capture_output=True,check=True,env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'file'})
        status=q.stdout.decode().strip()
        if status=='commit':
            need(old.git(clone,'show',commit+':'+path)==data[form],'local Git object conflicts with authenticated source')
        else:
            need(status==commit+' missing','unexpected local Git object')
    return {k:hashlib.sha256(v).hexdigest() for k,v in data.items()}

class Runner(old.Replay):
    def __init__(self,args,workflow,p):
        self.spec=p;self.watch_cpu=args.watch_cpu;self.budget=args.max_target_gib*(1<<30)
        work=copy.deepcopy(workflow);work['endpoints']={};work['command']=p['argv'][1:]
        super().__init__(args,work)
        self.sdk=self.root/'visible/sdk';self.sdk.parent.mkdir()
        self.env['PATH']=str(self.sdk/'bin')+':/usr/bin:/bin';self.env['RUSTC']=str(self.sdk/'bin/rustc')
        self.cmd=[str(self.sdk/'bin/cargo'),*p['argv'][1:]];self.owners={};self.archives={};self.libs={}
        snap=old.read(self.root/'inputs.json');snap.update(argv=self.cmd,clock='CLOCK_MONOTONIC immediately before Popen through direct child.wait');(self.root/'inputs.json').write_text(json.dumps(snap,sort_keys=True,indent=2)+'\n')
        self.uv_source=p['source']['source_path'];self.physical=self.root/'production-physical';self.physical.mkdir()
    def space(self,additional=0):
        need(min(shutil.disk_usage('/').free,shutil.disk_usage(self.root).free)>self.reserve and shutil.disk_usage(self.root).free>self.reserve+additional,'private disk floor')
    def setup(self):
        proof_sources(self.clone,self.spec);super().setup()
        e=self.spec['source'];self.plan['endpoints'][NAME]={'path':e['source_path'],'A':e['A_blob'],'B':e['B_blob']}
        for arm in ARMS:
            subject=self.spec['subjects'][arm]
            need(self.subjects[arm]['tree']==subject['source'] and (self.subjects.get('provenance')=='independent-source-build' or self.subjects[arm]['driver_sha256']==subject['driver_sha256']),'incorrect compiler source')
        shutil.copyfile(source_path('edit.json'),self.root/'sources/upstream-edit.json')
        for form in ('A','B'):shutil.copyfile(source_path(form+'.rs'),self.root/'sources'/('uvx-'+form+'.rs'))
        write(self.root/'production-intake.json',{'scope':NAME,'protocol_sha256':sha(original('protocol.json')),'absolute_argv':self.cmd,
              'sdk_manifests_sha256':sha(self.root/'sdk-manifests.json'),'source_identity_sha256':sha(self.root/'source-identity.json'),
              'independent_archives':True,'fresh_cold_command':self.cmd[:-1],'watch_cpu':self.watch_cpu})
    def state(self,phase):
        state=self.source(NAME,phase)
        return {**state,'oid':self.spec['source']['uv_base'],'ref':'refs/heads/feature-A','form':phase,'lock_sha256':sha(self.src/'Cargo.lock')}
    def outputs(self,folder,arm):
        oracle=__import__('production_score').behavior()
        programs={};versions={}
        for name in ('uv','uvx'):
            path=safe_file(self.target,'debug/'+name);owner=safe_file(self.target,self.owners[arm][name])
            with path.open('rb') as f:need(f.read(len(ELF))==ELF,'not a native executable')
            h=sha(path);need(os.path.samefile(path,owner) or sha(owner)==h,'public file differs from owning rustc')
            programs[name]={'path':'debug/'+name,'sha256':h,'bytes':path.stat().st_size}
            obj=self.root/'objects'/h
            if not obj.exists():
                self.space(path.stat().st_size);old.copy(path,obj);need(sha(obj)==h,'object copy failure')
            q=subprocess.run([str(path),'--version'],cwd=self.src,env=self.env,capture_output=True,timeout=30)
            (folder/(name+'-version.stdout')).write_bytes(q.stdout);(folder/(name+'-version.stderr')).write_bytes(q.stderr)
            need(q.returncode==0 and not q.stderr,'version failed');versions[name]=q.stdout.decode().strip()
        q=subprocess.run([self.target/'debug/uv','self','version','--output-format','json'],cwd=self.src,env=self.env,capture_output=True,timeout=30)
        (folder/'uv-detail.stdout').write_bytes(q.stdout);need(q.returncode==0 and not q.stderr,'detailed version failed')
        versions['detail']=json.loads(q.stdout);base=self.plan['A']
        need(versions=={'detail':base['self_version'],'uv':base['version'],'uvx':base['version'].replace('uv ','uvx ',1)},'different CLI identity')
        cases=oracle.observe(self.target/'debug/uvx',self.active/'tmp')
        need(cases['binary_sha256']==programs['uvx']['sha256'],'behavior from different binary');validate_behavior(cases['cases'])
        return {'programs':programs,'versions':versions,'producer':self.owners[arm],'argv_and_exit':cases['cases']}
    def once(self,folder,arm,phase,epoch=0,*,traced=False,seed=False):
        folder.mkdir(parents=True);before_source=self.state('A');need((phase=='B')==bool(epoch),'wrong phase')
        if epoch:need(before_source['mtime_ns']<epoch<=time.time_ns(),'stale edit time')
        before=stamps(self.target);write(folder/'stamps-before.json',before)
        ordinary=self.cmd[:-1] if seed else self.cmd;argv=list(ordinary);maps=None
        if traced:
            argv=['/usr/bin/strace','-ff','-qq','-y','-s','131072','-e','trace=execve,execveat,clone,clone3,fork,vfork,chdir,fchdir','-o',str(folder/'exec'),*argv]
            maps=trace.DriverMaps(self.sdk,self.driver)
        payload=(self.root/'sources/uvx-B.rs').read_bytes();dest=self.src/self.uv_source
        self.space();need(allocated(self.target)<=self.budget,'target cap before command')
        with Guard(self) as guard,(folder/'cargo.stdout').open('xb') as out,(folder/'cargo.stderr').open('xb') as err:
            need(not guard.events,'foreign compiler before command')
            if epoch:
                dest.write_bytes(payload);os.utime(dest,ns=(epoch,epoch))
            applied=time.monotonic_ns() if epoch else None
            start=time.monotonic_ns();child=subprocess.Popen(argv,cwd=self.src,env=self.env,stdout=out,stderr=err,start_new_session=True)
            guard.child=child;guard.limit=time.monotonic()+(1800 if seed else 300)
            if maps:maps.start(child.pid)
            try:code=child.wait();end=time.monotonic_ns()
            finally:
                if maps:seen=maps.finish()
        state=self.state(phase);after=stamps(self.target);write(folder/'stamps-after.json',after)
        need((not epoch or state['mtime_ns']==epoch) and allocated(self.target)<=self.budget,'mtime or target cap')
        raw={n:sha(folder/n) for n in ('stamps-before.json','stamps-after.json','cargo.stdout','cargo.stderr')}
        row={'arm':arm,'phase':phase,'source':state,'before_source':before_source,'argv':ordinary,'actual_argv':argv,
            'driver_sha256':self.subjects[arm]['driver_sha256'],'traced':traced,'after_write_close_ns':applied,'pid':child.pid,'exit':code,'start_ns':start,'end_ns':end,'elapsed_ns':end-start,
            'observer_faults':guard.events,'raw':raw,'packages':sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',(folder/'cargo.stderr').read_text(),re.M)),
            'changed_stamps':sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))}
        write(folder/'command.json',row)
        need(code==0 and not guard.events and not old.drain_session(child.pid)['remaining'] and not (folder/'cargo.stdout').stat().st_size,'command or resource check failed')
        if traced:
            rust,wild,streams=trace.trace_rows(folder,ordinary,self.sdk)
            required={'uv','uvx'} if seed and arm not in self.owners else {'uvx'} if phase=='B' else set()
            owners,jobs,links=trace.owner_paths(rust,wild,self.target,required)
            write(folder/'trace-inventory.json',streams)
            if seed and arm not in self.libs:
                libs=[a for _,_,a in rust if 'crates/uv/src/lib.rs' in a and trace.argument(a,'--crate-name')=='uv']
                need(len(libs)==1,'missing or duplicate actual library producer')
                a=libs[0];outdir=Path(trace.argument(a,'--out-dir'));suffix=[k.split('=',1)[1] for k in a if k.startswith(('extra-filename=','-Cextra-filename='))]
                need(len(suffix)==1,'missing library output disambiguator')
                self.libs[arm]={k:str((outdir/('libuv'+suffix[0]+ext)).relative_to(self.target)) for k,ext in [('file','.rmeta'),('archive','.rlib')]}
            if arm not in self.owners:self.owners[arm]=owners
            need(all(self.owners[arm].get(k)==v for k,v in owners.items()),'different producing paths')
            if phase=='B':
                chosen=[j for j in jobs if j['input']==self.uv_source]
                need(all(j['guard'] for j in jobs) and len(chosen)==1 and chosen[0]['guard'] and not chosen[0]['link_only'] and str(chosen[0]['pid']) in seen,'missing guarded, driver-mapped uvx owner')
            write(folder/'roles.json',{'rustc':jobs,'wild':links})
            write(folder/'census.json',{'actual':[{'role':'compile','native_guard':j['guard'],**j} for j in jobs],
                  'raw_wild':[{'pid':pid,'exe':exe,'argv':a} for pid,exe,a in wild],'trace_sha256':streams})
            write(folder/'raw-mapped-drivers.json',seen);write(folder/'mapped-driver.json',{'actual_selected':len(seen),'driver_sha256':row['driver_sha256']})
        output=self.outputs(folder,arm);write(folder/'products.json',output)
        if traced and phase=='B':write(folder/'retained.json',{k:{'raw_sha256':v['sha256'],'bytes':v['bytes']} for k,v in output['programs'].items()})
        library={}
        for kind,rel in self.libs[arm].items():
            file=self.target/rel;need(file.resolve(strict=True).is_relative_to(self.target.resolve()) and file.is_file(),'wrong owning library')
            library[kind]={'path':rel,'device_inode':banks.identity(file),'bytes':file.stat().st_size,'sha256':sha(file) if traced else None}
        write(folder/'library.json',library);write(folder/'attestation.json',engine().x.attest(folder,traced))
        return row,output
    def prime(self,arm):
        self.select(arm);self.active.mkdir()
        for n in ('target','home','tmp','cargo-home'):(self.active/n).mkdir()
        self.config();old.copy(self.root/'source-template',self.src)
        versions={k:old.version_output([self.sdk/'bin'/k,'-vV'],self.env,self.src).decode() for k in ('cargo','rustc')}
        need(old.check_versions(self.plan,self.subjects,versions),'wrong compiler/tool versions')
        logs=self.root/'warm'/arm;previous=None
        for n in ('cold','repeat','lastA'):
            row,products=self.once(logs/n,arm,'A',traced=n!='repeat',seed=True)
            if n=='lastA':need(previous==(heading(row),products),'ordinary and traced own A do not agree')
            previous=heading(row),products
        self.space(2*allocated(self.active)+(256<<20));ledger=logs/'manifest.jsonl.gz'
        a=banks.archive(self.active,self.root/'seeds'/(arm+'.tar.zst'),ledger);check=self.root/'archive-proof'
        incoming=banks.restore(a,check);need(incoming['identity']!=banks.identity(self.active),'restore aliases the A input')
        shutil.rmtree(check);shutil.rmtree(self.active);self.archives[arm]=a;write(logs/'seed.json',a)
        return products

ELF=b'\x7fELF\x02\x01\x01'


def run_round(run,label,order,primers,gold=None):
    p=run.spec;out=run.physical/label;out.mkdir();slots={}
    remaining=sum(a['state']['allocated_unique'] for a in run.archives.values());run.space(remaining+(512<<20))
    for arm in ARMS:
        folder=out/arm;folder.mkdir();slot=run.root/('slot-'+arm)
        a=run.archives[arm];receipt=banks.restore(a,slot)
        need(receipt['identity']!=a['original'] and receipt['identity'] not in [s[1]['identity'] for s in slots.values()],'restorations are not independent')
        write(folder/'incoming.json',receipt);slots[arm]=(slot,receipt)
    products={};controls={a:{} for a in ARMS};clocks={}
    for phase,sequence in [('A',primers),('B',order)]:
        epoch=0
        if phase=='B':
            epoch=time.time_ns()
            write(out/'order.json',{'primer_order':primers,'B_order':order,'B_mtime_ns':epoch})
        for arm in sequence:
            slot,receipt=slots[arm];need(not run.active.exists() and banks.identity(slot)==receipt['identity'],'active bank mismatch')
            run.select(arm);slot.rename(run.active)
            try:
                row,prod=run.once(out/arm/phase,arm,phase,epoch,traced=label=='admission' and phase=='B')
                need(prod==products.setdefault(phase,prod),'two independent arms produced different raw programs or behavior')
                if gold:need(prod==gold['products'][phase] and heading(row)==gold['controls'][arm][phase],'changed own-arm roster or admitted outputs')
                controls[arm][phase]=heading(row)
                if phase=='B':clocks[arm]=row['elapsed_ns']
            finally:
                if run.active.exists() and banks.identity(run.active)==receipt['identity']:run.active.rename(slot)
    engine().compatible(products['A'],products['B'])
    for arm,(slot,receipt) in slots.items():
        need(banks.identity(slot)==receipt['identity'] and slot.parent==run.root and not slot.is_symlink() and
             banks.identity(Path(run.archives[arm]['path']))==run.archives[arm]['archive_identity'],'retirement identity mismatch')
        shutil.rmtree(slot);write(out/arm/'retired.json',{'identity':receipt['identity'],'absent':not slot.exists()})
    return {'products':products,'controls':controls,'clocks':clocks}

def endpoint(run):
    a=[run.prime(arm) for arm in ARMS];need(a[0]==a[1],'different native binary outcomes across the two A histories')
    p=run.spec
    write(run.root/'locally-reconstructed-checkpoints.json',run.archives)
    gold=run_round(run,'admission',p['admission_order'],p['admission_order'])
    pilot=run_round(run,'pilot',p['pilot_order'],p['pilot_primers'],gold)
    passes=pilot['clocks']['C']/pilot['clocks']['CZD']>=p['pilot_minimum']
    if passes:
        for idx,(order,prime) in enumerate(zip(p['pairs'],p['primers'],strict=True)):run_round(run,f'pair-{idx:02d}',order,prime,gold)
    from production_score import local_replay
    result=local_replay(run.root);need(result['counted_pairs']==(12 if passes else 0),'incorrect score scope')
    write(run.root/'complete.json',{'study':NAME,'pilot_passed':passes,'counted_pairs':result['counted_pairs'],'retained_checkpoints':run.archives,'qualifying_without_family':bool(result['score'] and result['score']['individual_gate'])})
    return result

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    for name in ('uv-clone','control-sdk','candidate-sdk','cargo-home','run'):cli.add_argument('--'+name,type=Path,required=True)
    cli.add_argument('--subjects',type=Path,default=HERE/'subjects.json');cli.add_argument('--reserve-gib',type=int,default=122)
    cli.add_argument('--max-target-gib',type=int,default=13);args=cli.parse_args()
    if old.read(args.subjects).get('provenance')!='independent-source-build':need(sha(args.subjects)==sha(HERE/'subjects.json'),'unknown SDK attestation')
    need(args.reserve_gib>=122 and 1<=args.max_target_gib<=13,'unsafe reserve/checkpoint bounds')
    available=sorted(os.sched_getaffinity(0));need(len(available)>=17,'need 16 workload CPUs plus a distinct observer CPU');args.watch_cpu=available[-1]
    os.sched_setaffinity(0,available[:16]);args.contrast='CZD'
    r=Runner(args,old.read(HERE/'workflow.json'),plan())
    try:r.setup();result=endpoint(r)
    except Exception as e:
        write(r.root/'failed.json',{'study':NAME,'error':repr(e),'scored_pairs':0,'family_p':1,'retained_private_work':True})
        raise
    print(json.dumps({'unscored_pilot':result['excluded_pilot'],'counted_pairs':result['counted_pairs'],'score':result['score']},indent=2))
if __name__=='__main__':main()
