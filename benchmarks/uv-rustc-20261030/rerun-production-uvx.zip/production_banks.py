"""Bounded private checkpoints. Fresh reviewers reconstruct ordinary A from an empty target."""
import gzip,hashlib,json,os,stat,subprocess
from pathlib import Path
from common import allocated,need,sha

def identity(p):
    s=p.stat();return [s.st_dev,s.st_ino]

def inventory(root,log=None):
    digest=hashlib.sha256();seen={};count=0;size=0;out=gzip.open(log,'xb',compresslevel=1) if log else None
    try:
        for p in sorted([root,*root.rglob('*')]):
            s=p.lstat();name=p.relative_to(root).as_posix();kind=stat.S_IFMT(s.st_mode);extra=None
            if kind==stat.S_IFREG:
                key=s.st_dev,s.st_ino
                if key in seen:extra=['hardlink',seen[key]]
                else:seen[key]=name;extra=['bytes',s.st_size,sha(p)];size+=s.st_size
            elif kind==stat.S_IFLNK:extra=os.readlink(p)
            else:need(kind==stat.S_IFDIR,'unexpected file in private checkpoint')
            row=json.dumps([name,kind,stat.S_IMODE(s.st_mode),s.st_mtime_ns,extra],separators=(',',':'),ensure_ascii=True).encode()+b'\n'
            digest.update(row);count+=1
            if out:out.write(row)
    finally:
        if out:out.close()
    return {'manifest_sha256':digest.hexdigest(),'nodes':count,'logical_unique':size,'unique_files':len(seen),'allocated_unique':allocated(root)}

def content(record):return {k:v for k,v in record.items() if k!='allocated_unique'}

def archive(root,dest,ledger):
    need(not dest.exists() and not dest.is_symlink(),'new checkpoint required')
    manifest=inventory(root,ledger);ident=identity(root)
    subprocess.run(['tar','--format=pax','--xattrs','--use-compress-program=zstd -1 -T1','-cf',str(dest),'-C',str(root),'.'],check=True)
    return {'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'archive_identity':identity(dest),'original':ident,'state':manifest,'ledger_sha256':sha(ledger)}

def restore(a,dest):
    src=Path(a['path']);need(not dest.exists() and not dest.is_symlink() and identity(src)==a['archive_identity'] and sha(src)==a['sha256'],'changed private A archive')
    dest.mkdir();subprocess.run(['tar','--xattrs','--no-same-owner','--use-compress-program=zstd -T1','-xf',str(src),'-C',str(dest)],check=True)
    state=inventory(dest);need(content(state)==content(a['state']),'restored bytes, links, modes or timestamps differ')
    return {'identity':identity(dest),'archive_sha256':a['sha256'],'manifest_sha256':state['manifest_sha256']}
