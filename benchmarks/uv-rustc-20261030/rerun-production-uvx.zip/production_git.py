"""Verify both complete Git commits, tree chains and blob identities without a remote."""
import hashlib, json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PATH='crates/uv/src/bin/uvx.rs'
def ghid(kind,raw):
    return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def rawtree(rows):
    entry=lambda r:r['path'].encode()+ (b'/' if r['type']=='tree' else b'')
    return b''.join(r['mode'].lstrip('0').encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha']) for r in sorted(rows,key=entry))
def verify(proof,plan,dat):
    assert proof['repo']=='astral-sh/uv' and proof['path']==PATH==plan['source']['source_path'] and set(proof['roles'])=={'A','B'}
    out={}
    for name,key in (('A','upstream_parent'),('B','upstream_commit')):
        rec=proof['roles'][name]; commit=bytes.fromhex(rec['raw_commit_hex']);sha=plan['source'][key]
        assert ghid('commit',commit)==rec['sha']==sha
        first=commit.split(b'\n',1)[0]; assert first.startswith(b'tree '); step=first[5:].decode()
        for depth,component in enumerate(PATH.split('/')):
            rows=proof['trees'][step];assert ghid('tree',rawtree(rows))==step
            match=[r for r in rows if r['path']==component];assert len(match)==1 and (match[0]['type'],match[0]['mode'])==(('blob','100644') if depth==4 else ('tree','040000'))
            step=match[0]['sha']
        assert step==plan['source'][name+'_blob']==ghid('blob',dat[name])
        out[name]={'commit':sha,'blob':step,'file_sha256':hashlib.sha256(dat[name]).hexdigest()}
    steps={role:bytes.fromhex(proof['roles'][role]['raw_commit_hex']).splitlines()[0][5:].decode() for role in ('A','B')}
    for component in PATH.split('/'):
        trees=[{r['path']:(r['mode'],r['type'],r['sha']) for r in proof['trees'][steps[k]]} for k in ('A','B')]
        l,r=trees;old=l.pop(component);new=r.pop(component)
        assert l==r and old[:2]==new[:2], 'upstream changed another path or mode'
        steps=dict(A=old[2],B=new[2])
    import difflib
    delta=difflib.SequenceMatcher(None,dat['A'].splitlines(keepends=True),dat['B'].splitlines(keepends=True),autojunk=False).get_opcodes()
    assert sum(j-i for op,i,j,_a,_b in delta if op in ('replace','delete'))==plan['source']['deleted'] and sum(b-a for op,_i,_j,a,b in delta if op in ('replace','insert'))==plan['source']['added']
    assert b'parent '+out['A']['commit'].encode()+b'\n' in bytes.fromhex(proof['roles']['B']['raw_commit_hex'])
    return out
def main():
    z=HERE/'production-calibration';p=json.loads((HERE/'production-original/guard-file-free-math-asm/production-uvx-bins/protocol.json').read_text())
    print(json.dumps(verify(json.loads((z/'source-git.json').read_text()),p,{k:(HERE/'production-original/uvx-binary-edit'/(k+'.rs')).read_bytes() for k in ('A','B')}),sort_keys=True))
if __name__=='__main__':main()
