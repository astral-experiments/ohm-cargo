# Building both uv binaries after a production edit

This study uses the five added and thirteen removed lines from [uv #22742](https://github.com/astral-sh/uv/pull/22742). Both versions build and run `uv` and `uvx` at uv commit `c22e6b71933443e9cd299d4b6ac8de035ed4825b`. The working-tree edit changes only `crates/uv/src/bin/uvx.rs`. The runner verifies both blob IDs, the upstream commit and its parent, the base tree, Git identity, version and lockfile.

C is the Ohm −20 source with the math-assembly change from Rust #270. CZD adds the two assembly classifications in Rust #275. Their matched Linux SDKs differ in one Rust driver among 65 files. A result here compares these compilers. The public programs are compared byte-for-byte. Library metadata and the rlib have separate observational records.

## Fresh run

Use a private Linux x86-64 machine with GNU tar, cp, zstd, strace, Git, Python 3.11+ and an isolated 16-CPU workload plus another available observer CPU. The program refuses foreign compiler activity and leaves at least 122 GiB free on both its working filesystem and the root filesystem. Each target is capped at 13 GiB. Additional space is required for two simultaneous restored banks, private registry, compressed checkpoints and retained binaries. Give the tool a **new** result path on a filesystem supporting hardlinks and nanosecond mtimes. The two existing SDKs and the supplied Cargo registry are read-only inputs. See `README.md` and `REBUILD.md` in the existing reviewer kit for building or installing the matched SDKs and preparing the offline Cargo registry.

```sh
python3 -ISB calibrate_production_argv.py
python3 -ISB test_production.py
python3 -ISB test_production_packet.py
python3 -ISB production.py --uv-clone /path/to/uv --cargo-home /path/to/offline-cargo-home \
  --control-sdk /path/to/matched/C --candidate-sdk /path/to/matched/CZD \
  --run /path/to/new-private-production-run
python3 -ISB production_score.py /path/to/new-private-production-run
```

The uv clone must contain the complete fixed commit/tag history for `c22e6b7` and the upstream change `801cb856` with parent `deba0cbd`. For an older or shallow clone, obtain that upstream commit and its parent before the offline run. The reviewer does not fetch history during a measured command. Keep the default `subjects.json` for the provided binaries. For private source builds, pass the corresponding source-build subjects manifest with `--subjects`. It authenticates the independently rebuilt pair and its matched common files.

Each arm constructs its own A history from empty using the original implicit `cargo build --locked --offline -j8 -p uv` cold, normal repeat and final traced A. At each new round it independently restores both checkpoints and runs the explicit, unwrapped `cargo build --locked --offline -j8 -p uv --bins` on A in each arm. Only after both A commands finish does it assign a common timestamp, write B and immediately run the first explicit `--bins` command on each arm in the registered order. The two admission B commands use strace to prove the guarded uvx rustc, its mapped driver and its owning Wild link. Pilot and scored B clocks use direct Cargo. All output checks, A primers, restoration and tracing are outside those clocks. The portable run recreates private A archives on the reviewer’s host. Their bytes and absolute paths depend on that environment.

Each A/B round verifies both complete public binaries, their owning files, both version outputs and the detailed Git version. It tests `uvx@pair` finding its matched sibling and falling back to `uv`, including an empty, multiline, space-containing and non-UTF-8 argument and exit code 37. Removing the fallback must produce the original missing-binary error and exit 2. The unchanged `uv` must keep its SHA. The edited `uvx` must change and match the other arm on the same source.

The pilot is excluded from estimation. Below 1.8×, the study stops with zero scored pairs. Otherwise it runs all 12 registered pairs with separately balanced primer and B orders, uses the native paired scorer and keeps the 2× decision separate from the earlier twelve comparisons. A failed admission or interrupted job retains its evidence and has zero credit. To reproduce the preceding fixed comparisons in a local 13-way decision, provide their separate native full-stack packet with `production_score.py RUN --previous-packet FILE --previous-outer TRUSTED_SHA --scratch EXISTING_DIR`. Without it, the standalone report explicitly assigns p=1 to the unprovided comparisons. Synthetic controls never report measured rustc improvements.

## Native evidence

Once the native producer has really returned, its owner can export the genuine compact packet with `production_export.py`. Supply the actual coordinator outer SHA and an existing scratch directory. The exporter checks the registered consumer and worker before reading the native results. It then constructs a capped deduplicated ZIP, extracts it fresh and recomputes the included clocks, product checks and 13-way correction. A failed receipt reports zero credited pairs and p=1. Read the compact evidence without either SDK:

```sh
python3 -ISB production_native_score.py /path/to/production-native.zip \
  --outer TRUSTED_PRODUCTION_OUTER_SHA --packet-sha256 PUBLISHED_PACKET_SHA --scratch /path/to/existing/temp
```

The compact ZIP contains raw stdout/stderr and arguments, producer/driver witnesses, all timings and correctness receipts, both matched SDK manifests, the Git/source/behavior records and identities for the three distinct retained executables. To check the full bytes, add `--elf-cas /path/to/the/three-compressed-native-programs`. To independently replay the earlier data feeding Holm13, add `--previous-packet /path/to/the-authenticated-twelve-way-result.zip`. Otherwise the report labels the earlier twelve inputs as recorded by their own native source. The strict failed ordinary-build endpoint retains p=1. This distinct two-binary forward edit has its own observation and threshold.

The two native comparisons use a separate resource handoff after the excluded unedited stock attempt. The full-stack study remains the twelfth comparison, and the production edit is the thirteenth. The stage0 storage return and the follow-on diagnostic carry zero statistical weight. On the owner host, use the following after the respective genuine returns. Both destinations must be new files.

```sh
python3 -ISB production_previous.py export --study-parent /path/to/guard-file-free-math-asm \
  --previous-combined /path/to/ohm-20-uv-package-test-v3-combined.zip --outer TWELFTH_OUTER_SHA \
  --out /path/to/new-twelve.zip --scratch /path/to/temp
python3 -ISB production_export.py --native-root /path/to/guard-file-free-math-asm/production-uvx-bins \
  --outer THIRTEENTH_OUTER_SHA --previous-packet /path/to/new-twelve.zip \
  --out /path/to/new-production.zip --scratch /path/to/temp
```

The source witness recomputes both upstream Git commit IDs, all tree IDs along the five-component file path, and the actual old and new blobs. The reviewer clone must contain the benchmark checkout c22e6b7. Any locally present upstream commit is also checked. `python3 -ISB production_git.py` verifies the bundled commit and tree objects offline.

### Native resource handoff after the capacity refusal

The initial stock diagnostic exited before its first edited command. The subsequent capacity check stopped before it created a worker record or a new target. The native packet retains both outcomes at zero statistical credit. Its revised storage and diagnostic receipts establish when the hardware was released for the twelfth and thirteenth comparisons.

Use the same export and replay commands above for the replacement native handoff. The source edit, normal Cargo commands, paired orders and scorer remain as registered. Run `python3 -ISB test_capacity.py` to replay the source-bound synthetic storage and excluded-trial controls.
