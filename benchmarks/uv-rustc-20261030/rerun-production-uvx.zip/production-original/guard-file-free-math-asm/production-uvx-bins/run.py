"""Independently restore and benchmark the two ordinary public binaries."""
import ctypes,os,subprocess,sys,time,traceback
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
analysis=x.mod('forward_uvx_native_replay',HERE/'replay.py')
J=x.mod('original_build_archive_custody',x.G/'ordinary-modes/failed-build/return.py');r=J.r;m=r.m
arc=x.mod('verified_checkpoint_transports',x.G/'package-test/checkpoint.py')
ready=r.v.code(x.G/'fresh-edit-trial/ready.py','bins_actual_sdk_intake')
physical=r.v.code(r.v.UP.parent/'physical.py','bins_actual_outer')
P=x.PHYSICAL;RAM=x.RAM;CAS=RAM/'programs';S=x.G/'package-test-full-stack/physical';U=x.G/'after-ordinary-failures/full.py';write=r.write

def saved(script,*args):
    import json
    return json.loads(subprocess.check_output(['/usr/bin/python3','-ISB',str(script),*map(str,args)]))
def previous(path,h):
    path=Path(path).resolve();x.need(path==S/'outer-return.json' and x.sha(path)==h,'requires genuine completed twelfth physical endpoint')
    q=saved(U,'closed',path,h);host,raw=r.v.local_receipt(S,h);x.need(q==raw,'wrong independently returned custody');return host,raw
def work(folder,slot,arm,phase,stamp,traced):
    folder.mkdir();subj=x.plan()['subjects'][arm];ns=m.ns(slot,subj['sdk'],folder)
    x.need(ns[-4:]==['/usr/bin/python3','-ISB',str(r.T/'study.py'),'inside'],'original namespace changed')
    args=ns[:-2]+[str(HERE/'command.py'),arm,phase,str(stamp),str(folder),str(int(traced))]
    write(folder/'namespace.json',{'argv':args,'slot':str(slot),'slot_identity':r.bank.identity(slot),'visible':str(m.o.VISIBLE),'sdk':subj['sdk']})
    with (folder/'worker.log').open('xb') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=440,check=True)
    return x.load(folder/'products.json')
def restore(folder,slot,a,cp,p):
    x.need(cp['archive']==p['archives'][a] and J.archive_id(cp,a)['dev_ino']==cp['identity'],'original A archive or owner changed')
    q=arc.restore(cp['archive'],slot,r.bank.snapshot,r.bank.identity,m.bounds);write(folder/'incoming.json',q)
def collect(label,order,primers,cps,p,gold=None):
    d=P/label;d.mkdir();m.bounds(x.archive_price(p));slots={a:RAM/(label+'-'+a) for a in x.ARMS};ids={}
    for a in primers:
        apr=d/a;apr.mkdir();restore(apr,slots[a],a,cps[a],p);ids[a]=r.bank.identity(slots[a])
    states={};seen={}
    for phase,seq in [('A',primers),('B',order)]:
        stamp=time.time_ns() if phase=='B' else 0
        if stamp:write(d/'order.json',{'primer_order':primers,'B_order':order,'B_mtime_ns':stamp,'label':label})
        for a in seq:
            f=d/a/phase;prod=work(f,slots[a],a,phase,stamp,gold is None and phase=='B')
            if gold is None:
                write(f/'retained.json',{n:arc.keep(slots[a]/'target'/v['path'],CAS,v,m.bounds) for n,v in prod['programs'].items()})
            cmd,pr=analysis.record(f,a,phase,p,gold is None and phase=='B')
            if gold:x.need(gold['controls'][a][phase]==analysis.roster(cmd) and gold['products'][phase]==pr,'admitted programs, work or behavior drifted')
            if phase in states:x.need(states[phase]==pr,'cross-arm public --bins result differs')
            else:states[phase]=pr
            if phase=='B':analysis.compatible(states['A'],pr)
            seen[a,phase]=x.sha(f/'products.json')
    # Recheck saved products before releasing the only writable copies. A failure retains both.
    for a in x.ARMS:
        x.need(all(x.sha(d/a/k/'products.json')==seen[a,k] for k in ('A','B')),'pre-retire evidence mismatch')
    with patch.object(m,'RAM',RAM):
        for a in x.ARMS:r.study.erase(slots[a],ids[a],d/a,'complete two-binary evidence verified; immutable original A remains')
    return analysis.round(d,order,primers,p,gold)
def proofs(cps):
    return {a:J.archive_id(cps[a],a) for a in x.ARMS}
def keepers(outcome,deep):
    expect={y['sha256']:y for prod in outcome['public_programs'].values() for y in prod['programs'].values()}
    x.need(len(expect)==3 and {f.name for f in CAS.iterdir()}=={h+'.zst' for h in expect},'not exactly the two uvx images and unchanged uv')
    kept={}
    for phase in ('A','B'):
        for a in x.ARMS:
            q=x.load(P/'admission'/a/phase/'retained.json')
            for role,y in outcome['public_programs'][phase]['programs'].items():
                v=q[role];h=y['sha256'];f=CAS/(h+'.zst')
                x.need(v['raw_sha256']==h and v['raw_bytes']==y['bytes'] and f.is_file() and not f.is_symlink() and
                       f.stat().st_size==v['compressed_bytes'] and (f.stat().st_mode&0o777)==0o400 and
                       (h not in kept or kept[h]==v),'misbound actual accepted program')
                if h not in kept:
                    x.need(x.sha(f)==v['compressed_sha256'] and (not deep or arc.unpacked_sha(f)==h),'changed retained executable')
                    kept[h]=v
    return kept
def perform(cps,p):
    original=proofs(cps);write(P/'original-archives.json',original)
    gold=collect('admission',p['admission_order'],p['admission_order'],cps,p);write(P/'admission-summary.json',gold)
    pilot=collect('pilot',p['pilot_order'],p['pilot_primers'],cps,p,gold);cl=pilot['clocks']
    if cl['C']/cl['CZD']>=p['pilot_minimum']:
        for i,(order,pre) in enumerate(zip(p['pairs'],p['primers'],strict=True)):collect(f'pair-{i:02d}',order,pre,cps,p,gold)
    val=analysis.study(P,p);write(P/'analysis.json',val);write(P/'cas-index.json',keepers(val,True))
    x.need(proofs(cps)==original and {f.name for f in RAM.iterdir()}=={'owner.json','programs'} and
           all(x.sha(Path(q['path']))==q['sha256'] for q in original.values()),'original archive bytes or private targets changed')
    write(P/'resources-returned.json',{'originals':original,'owner':x.load(RAM/'owner.json'),'all_private_slots_retired':True,'final_capacity':m.bounds(),'new_archives':0,'cas_sha256':x.sha(P/'cas-index.json')})
    return val

def start(path,h):
    reg=x.verify();x.need(os.environ.get('OHM_UVX_BINS_RELEASE')==reg,'independent physical release required');host,outer=previous(path,h);p=x.plan()
    with host.exclusively():
        x.need(previous(path,h)[1]==outer and not host.native.foreign() and not P.exists() and not RAM.exists(),'busy, stale or already used study')
        _,_,cps=J.facts();m.bounds(x.archive_price(p));m.system_proof();r.study.qa_authority('CZD')
        for a in ('CZ','CZD'):ready.native_proof(a)
        subjects=ready.select(True,'CZD');x.need(all(p['subjects'][a]==subjects['subjects'][a] for a in x.ARMS),'different matched SDKs')
        P.mkdir();os.sched_setaffinity(0,range(16));write(P/'subjects.json',subjects)
        write(P/'intake.json',{'phase':'production-uvx-bins','registration':reg,'previous':str(Path(path).resolve()),'previous_sha256':h,'outer':outer['outer'],'boot':outer['boot'],'locks':host.locks(),'pid':os.getpid(),'start_ns':time.time_ns()})
        x.need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'cannot own native descendants');meter=m.seed.RES.Meter(m.seed.available,m.FLOOR);code=1
        try:
            with meter:
                RAM.mkdir(mode=0o700);CAS.mkdir(mode=0o700);write(RAM/'owner.json',{'uid':os.getuid(),'identity':r.bank.identity(RAM),'registration':reg})
                outcome=perform(cps,p);write(P/'successful.json',{'registered':reg,'analysis_sha256':x.sha(P/'analysis.json'),'resources_sha256':x.sha(P/'resources-returned.json'),'subjects_sha256':x.sha(P/'subjects.json'),'rows':outcome['scored_rows']});code=0
        except BaseException:
            code=1
            (P/'failure.log').write_text(traceback.format_exc());raise
        finally:
            if code:m.seed.RES.stop_owned(os.getpid())
            until=time.monotonic()+6
            while True:
                while True:
                    try:pid,_=os.waitpid(-1,os.WNOHANG)
                    except ChildProcessError:break
                    if not pid:break
                children=sorted(m.seed.RES.descendants(os.getpid()))
                if not children or time.monotonic()>=until:break
                time.sleep(.03)
            if children or meter.result()['guard_fault'] is not None:code=1
            write(P/'worker-return.json',{'owned_children_at_return':children,'code':code,'worker_exit':code,'end_ns':time.time_ns(),'locks':host.locks(),'success':x.sha(P/'successful.json') if not code else None,'capacity':meter.result()})
            x.need(code==0,'physical worker ended without a valid complete result')
def closed(path,h):
    reg=x.verify();p=x.plan();x.need(Path(path).resolve()==P/'outer-return.json','wrong native result');_,o=r.v.local_receipt(P,h)
    i=x.load(P/'intake.json');w=x.load(P/'worker-return.json');s=x.load(P/'successful.json');res=x.load(P/'resources-returned.json')
    x.need(i['registration']==s['registered']==reg and i['locks']==w['locks']==o['locks'] and i['boot']==o['boot'] and w['owned_children_at_return']==[] and
           w['code']==w['worker_exit']==0 and w['success']==x.sha(P/'successful.json') and not w['capacity']['guard_fault'] and i['start_ns']<w['end_ns'] and
           previous(Path(i['previous']),i['previous_sha256'])[1]['outer']==i['outer'] and s['subjects_sha256']==x.sha(P/'subjects.json') and
           all(x.load(P/'subjects.json')['subjects'][a]==p['subjects'][a] for a in x.ARMS),'false survey closure or timing admission')
    val=analysis.study(P,p);x.need(val==x.load(P/'analysis.json') and s['rows']==val['scored_rows'] and s['analysis_sha256']==x.sha(P/'analysis.json') and
           s['resources_sha256']==x.sha(P/'resources-returned.json') and res['all_private_slots_retired'] and res['cas_sha256']==x.sha(P/'cas-index.json') and
           keepers(val,False)==x.load(P/'cas-index.json') and res['originals']==x.load(P/'original-archives.json') and
           all(res['originals'][a]['sha256']==p['archives'][a]['sha256'] for a in x.ARMS),'incorrect analyzed or retained scope')
    return o
def family():
    o=closed(P/'outer-return.json',x.sha(P/'outer-return.json'));prev=saved(U,'family');outcome=analysis.study(P,x.plan())
    return {'original_twelve':prev,'thirteen':analysis.holm13(prev,outcome,x.plan()),'outcome':outcome,'native_outer':o['outer'],'own_outer_sha256':x.sha(P/'outer-return.json'),'pooled':False}
if __name__=='__main__':
    import json
    a=sys.argv[1:]
    if a==['verify']:out={'registration':x.verify(),'opening_extra_bytes':x.archive_price(x.plan())}
    elif len(a)==3 and a[0]=='start':out=start(a[1],a[2])
    elif len(a)==4 and a[0]=='close':out=physical.close(P,*a[1:])
    elif len(a)==3 and a[0]=='closed':out=closed(a[1],a[2])
    elif a==['family']:out=family()
    else:raise SystemExit('verify | start PRIOR SHA | close SESSION CHUNK CODE | closed RETURN SHA | family')
    print(json.dumps(out,sort_keys=True))
