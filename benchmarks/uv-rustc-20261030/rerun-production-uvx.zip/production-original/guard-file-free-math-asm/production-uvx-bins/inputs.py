"""Pinned scientific inputs and unmodified -20 build checkpoint identities."""
import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parent;G=HERE.parent;SRC=G.parent/'uvx-binary-edit';PLAN=HERE/'protocol.json';REG=HERE/'registration.json'
PHYSICAL=HERE/'physical'; RAM=Path('/dev/shm/ohm-production-uvx-bins-20261030')
ARMS=('C','CZD');SCOPE='CZD/uvx-production-bins';MIB=1<<20;GIB=1<<30
def load(p):return json.loads(Path(p).read_bytes())
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def need(ok,why):
    if not ok:raise ValueError(why)
def mod(name,p):
    sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
def plan():
    need(sha(PLAN)=='c78a32dadca41d03150602c14bb4c6fba7f1a07d03ee70e2f64d0aab06500247','changed scientific protocol')
    return load(PLAN)
def verify():
    p=plan();reg=load(REG)
    need(all(sha(G.parent/path)==h for path,h in p['inputs'].items()) and all(sha(HERE/k)==v for k,v in reg['sources'].items()) and all(sha(G.parent/k)==v for k,v in reg['external_sources'].items()),'registered input changed')
    source=p['source'];upstream=load(SRC/'upstream-commit.json')
    need(upstream['sha']==source['upstream_commit'] and [q['sha'] for q in upstream['parents']]==[source['upstream_parent']] and
         [(f['filename'],f['additions'],f['deletions'],f['sha']) for f in upstream['files']]==[(source['source_path'],5,13,source['B_blob'])],'not the single-file upstream production change')
    need(len(p['pairs'])==len(p['primers'])==12 and all(v.count(list(ARMS))==v.count(list(reversed(ARMS)))==6 for v in (p['pairs'],p['primers'])),'invalid balanced allocation')
    for form in ('A','B'):
        blob=(SRC/(form+'.rs')).read_bytes();header=b'blob '+str(len(blob)).encode()+b'\0'
        need(hashlib.sha1(header+blob).hexdigest()==p['source'][form+'_blob'] and hashlib.sha256(blob).hexdigest()==p['source'][form+'_sha256'],'wrong real production edit')
    return sha(REG)
def role_state(r,form):
    x=plan()['source'];ed={'path':x['source_path'],'A':x['A_blob'],'B':x['B_blob']}
    with patch.object(r.m,'endpoint',lambda n:ed if n=='uvx-production' else None):
        return r.m.state('uvx-production',form)
def archive_price(p):
    # Two writable targets coexist to keep exactly the same honest post-primer source time.
    full=sum(p['archives'][a]['state']['allocated_unique'] for a in ARMS)
    return full+max(768*MIB,full//10)+(512*MIB)+(256*MIB)

def attest(directory,traced):
    files=['command.json','products.json','library.json']
    if traced:files.extend(['census.json','roles.json','raw-mapped-drivers.json','mapped-driver.json','trace-inventory.json'])
    return {n:sha(directory/n) for n in files}
