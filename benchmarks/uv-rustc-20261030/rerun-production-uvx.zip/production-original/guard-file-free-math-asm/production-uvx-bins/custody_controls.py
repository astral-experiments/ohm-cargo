"""Run the actual two-layer admit, start, standard outer read and positive/negative family dispatch on fixtures."""
import contextlib,copy,os,sys,tempfile,types
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
c=x.mod('actual_uvx_fixture_for_receipts',HERE/'controls.py');n=c.n
class Host:
    held=False
    native=types.SimpleNamespace(foreign=lambda:[])
    @contextlib.contextmanager
    def exclusively(self):
        if self.held:raise AssertionError()
        self.held=True
        try:yield
        finally:self.held=False
    def locks(self):return ['synthetic-lock-one','synthetic-lock-two']
class Meter(contextlib.nullcontext):
    def __init__(self,*args):super().__init__(self)
    def result(self):return {'guard_fault':None}
def one(root,ratio):
    host=Host();last=root/'full';last.mkdir();prior=last/'outer-return.json';c.put(prior,{'outer':{'session':5,'chunk':'abc123','exit':0},'boot':'synthetic-prior'})
    pred=x.sha(prior);p=copy.deepcopy(x.plan());S=root/'study';S.mkdir();c.fixture(S,ratio);out=root/'physical';ram=root/'ram';cas=ram/'programs'
    for arm in x.ARMS:
        f=S/(arm+'-surrogate-archive');p['archives'][arm].update(path=str(f),sha256=x.sha(f),archive_identity=n.r.bank.identity(f))
    accesses=[];reg='synthetic-physical-only'
    def saved(script,*args):
        if args==('family',):
            return {'twelve':{label:{'complete':False,'confirmed':False,'raw_p':1.} for label in p['family']['ordered_labels'][:-1]}}
        accesses.append(host.held);q=x.load(prior);x.need(args[0]=='closed' and args[1]==prior and pred==args[2],'wrong actual predecessor call');return q
    def copy_evidence(cp,p):
        for f in (S/'physical').iterdir():f.rename(out/f.name)
        for f in (S/'ram/programs').iterdir():f.rename(cas/f.name)
        return x.load(out/'analysis.json')
    def read_outer(folder,h):
        f=folder/'outer-return.json';x.need(x.sha(f)==h,'wrong synthetic outer hash');return host,x.load(f)
    no=types.SimpleNamespace(prctl=lambda *a:0)
    with contextlib.ExitStack() as st:
        for obj,kw in [(n,dict(P=out,RAM=ram,CAS=cas,S=last,saved=saved,perform=copy_evidence)),(n.x,dict(verify=lambda:reg,plan=lambda:p)),(n.J,dict(facts=lambda:(host,{},{}))),(n.r.v,dict(local_receipt=read_outer)),(n.r.study,dict(qa_authority=lambda *a:None)),(n.ready,dict(native_proof=lambda *a:None,select=lambda *a:{'subjects':p['subjects']})),(n.m,dict(bounds=lambda *a:{},system_proof=lambda:None)),(n.m.seed.RES,dict(Meter=Meter,descendants=lambda *a:[])),(n.os,dict(sched_setaffinity=lambda *a:None)),(n.ctypes,dict(CDLL=lambda *a,**kw:no))]:st.enter_context(patch.multiple(obj,**kw))
        c.denied(lambda:n.previous(last/'wrong.json',pred));c.denied(lambda:n.previous(prior,'0'*64))
        st.enter_context(patch.dict(os.environ,{'OHM_UVX_BINS_RELEASE':reg}));n.start(prior,pred);x.need(accesses==[False,True],'host predecessor not verified twice')
        i=x.load(out/'intake.json');wr=x.load(out/'worker-return.json');q={'outer':{'session':6,'chunk':'123abc','exit':0},'boot':i['boot'],'locks':wr['locks'],'host_released':True,'remaining_workers':[],'foreign':[],'worker_sha256':x.sha(out/'worker-return.json'),'intake_sha256':x.sha(out/'intake.json')}
        ox=out/'outer-return.json';c.put(ox,q);x.need(n.closed(ox,x.sha(ox))==q and n.family()['thirteen'][x.SCOPE]['confirmed']==(ratio>=2),'whole-return or family projection rejected')
        success=out/'successful.json';old=success.read_bytes();v=x.load(success);v['rows']=42;c.put(success,v);c.denied(lambda:n.closed(ox,x.sha(ox)));success.write_bytes(old)
        return {'exit':wr['code'],'scored_rows':x.load(success)['rows'],'admissions_before_under_lease':accesses[:2],'included_in_own_new_family':n.family()['thirteen'][x.SCOPE]['complete']}
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        t=Path(tmp);(t/'p').mkdir();(t/'s').mkdir()
        import json
        print(json.dumps({'complete':one(t/'p',3.1),'stopped':one(t/'s',1.45),'real_locks_or_Cargo':False},indent=2,sort_keys=True))
