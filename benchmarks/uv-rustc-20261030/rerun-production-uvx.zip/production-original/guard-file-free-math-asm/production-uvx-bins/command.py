"""One real unwrapped --bins invocation, or an explicitly excluded traced B admission."""
import contextlib,hashlib,os,re,signal,subprocess,sys,threading,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
r=x.mod('proven_ordinary_cargo_observer',x.G/'ordinary-modes/runner.py');o=r.o;m=r.m
oracle=x.mod('actual_upstream_uvx_argv_oracle',x.SRC/'behavior.py');need=x.need

def bins(folder,archive,subject,form):
    target=r.r.TARGET;env=o.environment();programs={};paths={}
    for name in ('uv','uvx'):
        root=r.products.regular(target,'debug/'+name);owner=r.products.regular(target,archive['map'][name]['file'])
        with root.open('rb') as f:need(f.read(7)==b'\x7fELF\x02\x01\x01' and os.access(root,os.X_OK),'not an actual runnable ELF')
        info=r.products.record(target,root)
        need(os.path.samefile(root,owner) or x.sha(owner)==info['sha256'],'public output differs from verified owning unit')
        programs[name]=info;paths[name]=str(owner.relative_to(target))
    versions={}
    for name in ('uv','uvx'):
        q=subprocess.run([target/'debug'/name,'--version'],env=env,cwd=r.r.SRC,capture_output=True,timeout=15)
        (folder/(name+'-version.stdout')).write_bytes(q.stdout);(folder/(name+'-version.stderr')).write_bytes(q.stderr)
        need(q.returncode==0 and not q.stderr,'failed real sibling --version');versions[name]=q.stdout.decode().strip()
    q=subprocess.run([target/'debug/uv','self','version','--output-format','json'],env=env,cwd=r.r.SRC,capture_output=True,timeout=15)
    need(q.returncode==0 and not q.stderr,'actual uv self version failed');(folder/'uv-detail.stdout').write_bytes(q.stdout);versions['detail']=r.json.loads(q.stdout)
    r.verify_ver(form,versions);behavior=oracle.observe(target/'debug/uvx',r.r.SRC.parent/'tmp')
    need(behavior['binary_sha256']==programs['uvx']['sha256'] and behavior['cases']==x.load(x.SRC/'behavior-control.json')['observed']['cases'],'different real argv, exit or binary')
    return {'programs':programs,'producer':paths,'versions':versions,'argv_and_exit':behavior['cases']}

def compile_once(folder,arm,which,epoch,trace):
    folder=Path(folder);p=x.plan();subject=p['subjects'][arm];env=o.environment();rr=r.r
    need(which in ('A','B') and (not trace or which=='B') and set(os.sched_getaffinity(0))==set(range(16)) and
         all(k not in env for k in ('RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_LOG')),'incorrect measured command or scope')
    need(all(os.statvfs(k).f_flag&os.ST_RDONLY for k in ('/',rr.SDK,o.VISIBLE/'cargo-home/registry')) and
         all(not os.statvfs(k).f_flag&os.ST_RDONLY for k in (folder,rr.SRC,rr.TARGET)) and x.sha(rr.SDK/subject['driver'])==subject['driver_sha256'] and
         x.sha(rr.SDK/'bin/rustc')==subject['launcher_sha256'] and x.sha(rr.SDK/'bin/cargo')==subject['cargo_sha256'],'unexpected tool or writable mount')
    subprocess.run(['/usr/bin/git','-C',rr.SRC,'update-index','--really-refresh'],env=env,capture_output=True,check=True)
    dep=r.read(x.G/'ordinary-modes/physical-build/prepare'/('warm-'+arm)/'warm.json');before_source=x.role_state(r,'A');rr.CMD=[str(rr.SDK/'bin/cargo'),*p['argv'][1:]]
    argv=list(rr.CMD);before=rr.stamps();r.write(folder/'stamps-before.json',before);original=x.SRC/'B.rs';payload=original.read_bytes();dest=rr.SRC/p['source']['source_path']
    need((which=='B')==(epoch>0) and (not epoch or before_source['mtime_ns']<epoch<=time.time_ns()),'source edit time is not fresh')
    rr.reserve();need(not rr.native.foreign(),'foreign compiler at entry')
    if trace:argv=['/usr/bin/strace','-ff','-qq','-y','-s','131072','-e','trace=execve,execveat,clone,clone3,fork,vfork,chdir,fchdir','-o',str(folder/'exec'),*argv]
    witness=o.Witness(rr.SDK/'bin/rustc',rr.SDK/subject['driver'],rr.TARGET) if trace else contextlib.nullcontext()
    with witness as watch,(folder/'cargo.stdout').open('xb') as stream,(folder/'cargo.stderr').open('xb') as err:
        if which=='B':
            with dest.open('wb') as f:f.write(payload)
            os.utime(dest,ns=(epoch,epoch))
        applied=time.monotonic_ns() if which=='B' else None;start=time.monotonic_ns()
        proc=subprocess.Popen(argv,cwd=rr.SRC,env=env,stdout=stream,stderr=err,start_new_session=True)
        stop=threading.Event();fault=[]
        def guard():
            os.sched_setaffinity(0,{29})
            while not stop.wait(.35):
                others=[(pid,n) for pid,n in rr.native.foreign() if rr.proc_session(pid) not in (None,proc.pid)];free=rr.free()
                if others or min(free.values())<=m.FLOOR or time.monotonic_ns()-start>300*10**9:
                    fault.append({'foreign':others,'free':free,'at_ns':time.monotonic_ns()})
                    try:os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    return
        thread=threading.Thread(target=guard,daemon=True);thread.start()
        try:rc=proc.wait();end=time.monotonic_ns()
        finally:stop.set();thread.join()
    after=rr.stamps();r.write(folder/'stamps-after.json',after);st=x.role_state(r,which);log=(folder/'cargo.stderr').read_text()
    row={'arm':arm,'phase':which,'source':st,'before_source':before_source,'argv':rr.CMD,'actual_argv':argv,'traced':trace,'after_write_close_ns':applied,'start_ns':start,'end_ns':end,'elapsed_ns':end-start,'exit':rc,'pid':proc.pid,
         'driver_sha256':subject['driver_sha256'],'packages':sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',log,re.M)),
         'changed_stamps':sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)),'observer_faults':fault,
         'raw':{n:x.sha(folder/n) for n in ('stamps-before.json','stamps-after.json','cargo.stdout','cargo.stderr')}}
    r.write(folder/'command.json',row);need(rc==0 and not fault and not rr.native.foreign() and not (folder/'cargo.stdout').stat().st_size and
         st['blob']==p['source'][which+'_blob'] and st['sha256']==p['source'][which+'_sha256'] and (not epoch or st['mtime_ns']==epoch),'command failed or wrong source')
    if trace:
        raw=o.parse(folder,dep['producers'],False);roles=o.source_roles(raw);r.write(folder/'census.json',raw);r.write(folder/'roles.json',roles);r.write(folder/'raw-mapped-drivers.json',watch.rows)
        mapped=r.products.owner_map(raw['actual'],'build',rr.TARGET,require_all=False)
        need('uvx' in mapped and all(v==dep['map'][k] for k,v in mapped.items()),'wrong compiled program identity')
        uvx=[z for z in raw['actual'] if z['role']=='compile' and p['source']['source_path'] in z['argv']]
        proof=r.base.verify_mapper(folder,watch,raw,proc.pid);r.write(folder/'mapped-driver.json',proof);r.write(folder/'trace-inventory.json',{f.name:x.sha(f) for f in sorted(folder.glob('exec.*'))})
        need(proof['actual_selected']>=1 and all(z['native_guard'] for z in raw['actual'] if z['role']=='compile'),'unguarded actual compiler')
        need(len(uvx)==1 and uvx[0]['native_guard'] and str(uvx[0]['pid']) in watch.rows and
             any(z['role']=='link' and Path(z['output'])==rr.TARGET/mapped['uvx']['file'] for z in raw['actual']),'missing actual guarded source compile, matching driver or owning Wild link')
    r.write(folder/'products.json',bins(folder,dep,subject,st))
    libs={}
    for field in ('file','archive'):
        rel=dep['map']['libuv'][field];file=r.products.regular(rr.TARGET,rel);stat=file.stat()
        libs[field]={'path':rel,'bytes':stat.st_size,'device_inode':[stat.st_dev,stat.st_ino],'sha256':x.sha(file) if trace else None}
    r.write(folder/'library.json',libs);r.write(folder/'attestation.json',x.attest(folder,trace))
if __name__=='__main__':
    a=sys.argv[1:];x.verify();need(len(a)==5 and a[0] in x.ARMS and a[1] in ('A','B') and a[4] in ('0','1'),'invalid private invocation')
    compile_once(Path(a[3]),a[0],a[1],int(a[2]),a[4]=='1')
