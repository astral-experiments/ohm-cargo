"""Exercise native orchestration and scoring with small invented files, using no Cargo or host lease."""
import contextlib,copy,json,os,sys,tempfile
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
n=x.mod('bins_native_test',HERE/'run.py');a=n.analysis;W=x.G/'ordinary-modes/physical-build/prepare/warm-C';WR=W/'lastA'
Q=x.load(WR/'census.json');w=x.load(W/'warm.json');role=w['map'];fr=x.plan()['source']['source_path']
CX=next(z for z in Q['actual'] if z['role']=='compile' and fr in z['argv']);WX=next(z for z in Q['actual'] if z['role']=='link' and z['output'].endswith('/'+role['uvx']['file']))
R=x.load(WR/'roles.json');M=x.load(WR/'raw-mapped-drivers.json');V=x.load(WR/'products.json')['behavior'];E=x.load(x.SRC/'behavior-control.json')['observed']['cases']
def put(p,z):p.write_text(json.dumps(z,sort_keys=True)+'\n')
def denied(f):
    try:f()
    except (ValueError,FileNotFoundError):return
    raise AssertionError('accepted corruption')
def fixture(root,ratio):
    p=copy.deepcopy(x.plan());out=root/'physical';ram=root/'ram';out.mkdir();ram.mkdir();cas=ram/'programs';cas.mkdir();put(ram/'owner.json',{'fixture':True})
    ids={};times=[1000000000000];counts={'restores':0,'primers':0,'edited':0,'traced':0}
    for arm in x.ARMS:
        f=root/(arm+'-surrogate-archive');f.write_text('synthetic A '+arm);rec=p['archives'][arm];rec.update(path=str(f),sha256=x.sha(f),archive_identity=n.r.bank.identity(f));ids[arm]={'path':str(f),'sha256':rec['sha256']}
    def restore(d,slot,arm,cp,p):
        counts['restores']+=1;slot.mkdir();(slot/'target/debug').mkdir(parents=True);z=p['archives'][arm]
        put(d/'incoming.json',{'manifest_sha256':z['state']['manifest_sha256'],'archive_sha256':z['sha256'],'identity':n.r.bank.identity(slot),'state':z['state']})
    def work(d,slot,arm,phase,epoch,trace):
        d.mkdir();counts['primers' if phase=='A' else 'edited']+=1;counts['traced']+=trace
        orig=dict(w['source'],edit='uvx-production',path=fr,blob=p['source']['A_blob'],sha256=p['source']['A_sha256'],mtime_ns=1560000000);s=dict(orig,form=phase,blob=p['source'][phase+'_blob'],sha256=p['source'][phase+'_sha256'],mtime_ns=epoch or orig['mtime_ns']);files={}
        for k in ('uv','uvx'):
            f=slot/'target/debug'/k;f.write_bytes((k+('-'+phase if k=='uvx' else '')).encode());files[k]={'path':'debug/'+k,'bytes':f.stat().st_size,'sha256':x.sha(f)}
            (d/(k+'-version.stdout')).write_text(V[k]+'\n');(d/(k+'-version.stderr')).write_bytes(b'')
        put(d/'uv-detail.stdout',V['detail']);put(d/'stamps-before.json',{'common':1});put(d/'stamps-after.json',{'common':1,arm:2});(d/'cargo.stdout').write_bytes(b'');(d/'cargo.stderr').write_text(' Compiling uv v0.12\n')
        raw={k:x.sha(d/k) for k in ('cargo.stdout','cargo.stderr','stamps-before.json','stamps-after.json')};cmd=['/toy/visible/sdk/bin/cargo',*p['argv'][1:]];start=times[0]+1;dt=(int(1000000*ratio) if arm=='C' else 1000000) if phase=='B' else 10;end=start+dt;times[0]=end+1000
        put(d/'command.json',{'arm':arm,'phase':phase,'packages':['uv'],'changed_stamps':[arm],'source':s,'before_source':orig,'argv':cmd,'actual_argv':(['/usr/bin/strace'] if trace else [])+cmd,'driver_sha256':p['subjects'][arm]['driver_sha256'],'traced':trace,'after_write_close_ns':start-1 if phase=='B' else None,'start_ns':start,'end_ns':end,'elapsed_ns':dt,'pid':73,'exit':0,'observer_faults':[],'raw':raw})
        prod={'programs':files,'producer':{k:role[k]['file'] for k in files},'versions':V,'argv_and_exit':E};put(d/'products.json',prod)
        if trace:
            put(d/'census.json',{'actual':[CX,WX]});put(d/'roles.json',R);put(d/'raw-mapped-drivers.json',{str(CX['pid']):M[str(CX['pid'])]});put(d/'mapped-driver.json',{'actual_selected':1})
            (d/'exec.73').write_text('synthetic control with independently checked historical argv');put(d/'trace-inventory.json',{'exec.73':x.sha(d/'exec.73')})
        put(d/'library.json',{key:{'path':role['libuv'][key],'bytes':42,'device_inode':[42,3],'sha256':'a'*64 if trace else None} for key in ('file','archive')});put(d/'attestation.json',x.attest(d,trace))
        return prod
    def keep(path,folder,info,b):
        dest=folder/(info['sha256']+'.zst')
        if not dest.exists():dest.write_bytes(path.read_bytes());dest.chmod(0o400)
        return {'raw_sha256':x.sha(dest),'raw_bytes':dest.stat().st_size,'compressed_bytes':dest.stat().st_size,'compressed_sha256':x.sha(dest)}
    with contextlib.ExitStack() as st:
        for obj,kw in [(n,dict(P=out,RAM=ram,CAS=cas,work=work,restore=restore,proofs=lambda cp:ids)),(n.arc,dict(keep=keep,unpacked_sha=x.sha)),(n.m,dict(bounds=lambda *args:{'synthetic':True})),(n.r.r.native,dict(foreign=lambda:[]))]:st.enter_context(patch.multiple(obj,**kw))
        val=n.perform(dict.fromkeys(x.ARMS),p);x.need(val==a.study(out,p)==x.load(out/'analysis.json'),'JSON replay changed')
        base={'twelve':{k:{'complete':False,'confirmed':False,'raw_p':1.} for k in p['family']['ordered_labels'][:-1]}}
        fam=a.holm13(base,val,p);x.need(val['counted_pairs']==(12 if ratio>=1.8 else 0) and fam[x.SCOPE]['confirmed']==(ratio>=2),'reporting/screen gate failed')
        if ratio>2:
            for rel,mut in [('pair-00/order.json',lambda z:z.update(B_order=['CZD','C'])),('pair-02/C/B/command.json',lambda z:z.update(elapsed_ns=1)),('pair-02/CZD/A/command.json',lambda z:z.update(driver_sha256='0'*64)),('pair-03/C/B/products.json',lambda z:z['programs']['uv'].update(sha256='f'*64)),('pair-04/C/B/products.json',lambda z:z['argv_and_exit']['uvx@pair'].update(stdout_hex='00')),('pair-05/C/B/command.json',lambda z:z['source'].update(mtime_ns=0)),('pair-06/C/incoming.json',lambda z:z.update(archive_sha256=p['archives']['CZD']['sha256'])),('pair-07/C/retired.json',lambda z:z.update(identity=[42,42])),('admission/C/B/raw-mapped-drivers.json',lambda z:z.clear()),('admission/C/B/trace-inventory.json',lambda z:z.clear())]:
                f=out/rel;original=f.read_bytes();z=json.loads(original);mut(z);put(f,z);denied(lambda:a.study(out,p));f.write_bytes(original)
        return {'counts':counts,'pairs':val['counted_pairs'],'pilot_qualifies':val['excluded_pilot']['continues'],'holm13':fam[x.SCOPE]}
def main():
    x.need(n.r.products.owner_map(Q['actual'],'build',n.r.r.TARGET,require_all=False)['uvx']==role['uvx'] and str(CX['pid']) in M and CX['native_guard'],'actual prior uvx source, guard and owner failed')
    with tempfile.TemporaryDirectory() as tmp:
        t=Path(tmp);(t/'p').mkdir();(t/'n').mkdir()
        print(json.dumps({'actual_earlier_C_uvx_pid':CX['pid'],'actual_earlier_C_uvx_argv_sha256':next(z['argv_sha256'] for z in R['rustc'] if z['name']=='uvx'),'positive':fixture(t/'p',3.1),'screen':fixture(t/'n',1.45),'rejected_corruptions':10,'native_Cargo_commands':0},indent=2,sort_keys=True))
if __name__=='__main__':main()
