"""Exercise the actual single-command dispatch with a stopped process stand-in."""
import copy,contextlib,hashlib,json,os,sys,tempfile,time,types
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
c=x.mod('forward_compiler_actual_command',HERE/'command.py');r=c.r;W=x.G/'ordinary-modes/physical-build/prepare/warm-C/lastA';known=x.load(W/'census.json')
class Watch(contextlib.nullcontext):
    def __init__(self,*args):super().__init__(self);self.rows=x.load(W/'raw-mapped-drivers.json')
def exercise(tmp,phase,trace):
    p=copy.deepcopy(x.plan());src=tmp/'src';sdk=tmp/'sdk';out=tmp/'out';out.mkdir();src.mkdir();sdk.mkdir()
    dest=src/p['source']['source_path'];dest.parent.mkdir(parents=True);dest.write_bytes((x.SRC/'A.rs').read_bytes());os.utime(dest,ns=(100000000,100000000))
    subj=p['subjects']['C']
    for rel,key in ((subj['driver'],'driver_sha256'),('bin/rustc','launcher_sha256'),('bin/cargo','cargo_sha256')):
        f=sdk/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('synthetic '+rel);subj[key]=x.sha(f)
    epoch=time.time_ns() if phase=='B' else 0;seen=[]
    def form(rr,k):
        x.need(dest.read_bytes()==(x.SRC/(k+'.rs')).read_bytes(),'incorrect source bytes at process boundary')
        return {'form':k,'blob':p['source'][k+'_blob'],'sha256':x.sha(dest),'mtime_ns':dest.stat().st_mtime_ns}
    class Process:
        pid=9999
        def __init__(self,args,**kw):
            seen.append(list(args));file=form(r,phase);x.need(not epoch or file['mtime_ns']==epoch,'B not applied before Cargo');kw['stderr'].write(b' Compiling uv v0.12\n')
        def wait(self):return 0
    def statv(path):return types.SimpleNamespace(f_flag=os.ST_RDONLY if str(path) in ['/',str(sdk),str(c.o.VISIBLE/'cargo-home/registry')] else 0)
    prod={'synthetic':True}
    with contextlib.ExitStack() as st:
        bindings=[(c.x,dict(role_state=form,plan=lambda:p)),(c,dict(bins=lambda *a:prod)),(r.r,dict(SRC=src,SDK=sdk,reserve=lambda:None,stamps=lambda:{})),(r.r.native,dict(foreign=lambda:[])),(c.o,dict(environment=lambda:{},Witness=Watch,parse=lambda *z:known)),(r.products,dict(regular=lambda root,rel:dest)),(r.base,dict(verify_mapper=lambda *z:{'actual_selected':len(z[1].rows)})),(c.os,dict(statvfs=statv,sched_getaffinity=lambda p:set(range(16)),sched_setaffinity=lambda *p:None)),(c.subprocess,dict(Popen=Process,run=lambda *a,**kw:types.SimpleNamespace(returncode=0)))]
        for o,kw in bindings:st.enter_context(patch.multiple(o,**kw))
        c.compile_once(out,'C',phase,epoch,trace);q=x.load(out/'command.json')
        x.need(len(seen)==1 and q['actual_argv']==seen[0] and q['source']['form']==phase and q['exit']==0 and q['traced']==trace and (seen[0][0]=='/usr/bin/strace')==trace and q['argv']==[str(sdk/'bin/cargo'),*p['argv'][1:]] and x.load(out/'products.json')==prod,'incorrect controller path')
        if trace:x.need((out/'census.json').exists() and (out/'mapped-driver.json').exists(),'no diagnostic')
        return {'phase':phase,'traced':trace,'closed_processes':len(seen),'edited_mtime_verified':bool(epoch)}
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);m=[]
        for i,z in enumerate([('A',False),('B',True),('B',False)]):
            g=d/str(i);g.mkdir();m.append(exercise(g,*z))
        print(json.dumps({'native_processes':0,'actual_python_dispatch':m},sort_keys=True,indent=2))
