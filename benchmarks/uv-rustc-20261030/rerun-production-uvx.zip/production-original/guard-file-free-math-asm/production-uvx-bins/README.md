# Rebuilding uv and uvx after a real uvx argument-handling change

This prospective thirteenth comparison asks whether changing only the production uvx front end can halve the ordinary two-binary build. C includes the existing upstream #270 math assembly rules. CZD adds the #275 register-barrier comment and register-division rules. Both are rebuilt on the same Ohm −20 compiler source and use matched Cargo, standard library and Wild.

The checkout is uv c22e6b71933443e9cd299d4b6ac8de035ed4825b. Its uvx.rs exactly matches the parent’s file in uv [PR #22742](https://github.com/astral-sh/uv/pull/22742). That PR changed only how uvx constructs the arguments it passes to uv. We apply its entire one-file change to the private checkout and keep its Git revision, branch, other files, lockfile and features fixed. The guard is active in both arms.

Each arm in each round independently restores its own existing cold-built A archive and runs unwrapped `cargo build --locked --offline -j8 -p uv --bins` once before editing. Both primers finish before we assign the two edits an identical, genuinely newer mtime. The foreground interval runs from just after writing the file until ordinary Cargo returns. Preparation, the retained program checks, diagnostic tracing, and the real sibling/argv probes occur outside that interval.

The first round identifies the actual compiler and Wild process for uvx on both arms. Its B commands have tracing enabled. The second round is one excluded ordinary pair. A ratio below 1.8 stops the endpoint with zero scored pairs. Otherwise the study runs all twelve new pairs in the frozen balanced order. The source scorer requires the lower end of its exact 3rd-to-10th order interval and both order-specific median ratios to reach 2, together with a two-sided signed test against 2. The thirteenth comparison must also pass the Holm-adjusted 0.05 cut. The published twelve-way decision stays separate. Both earlier ordinary prepare failures have p=1 in both families.

All corresponding public uv and uvx executables must match byte for byte, by size and complete SHA-256, throughout. uv must stay unchanged across the edit and uvx must change. Each observed path is tied to its producing unit. The original full images are retained in a content-addressed compressed store. We record both real versions. A separate uvx check exercises sibling selection, fallback, empty/spaced/newline/non-UTF-8 arguments, child exit 37 and missing siblings. Library/archive sizes are separate diagnostics, with hashes in the two traced B admissions. Any operational, product or roster mismatch excludes the entire endpoint, with all available evidence retained.

## Running the registered host study

The physical coordinator supplies the actual successful 12th endpoint outer receipt after the two official release contexts and the stock −18 diagnostic. The preceding negative native receipts retain their original status. A future intervening maintenance or failed-scope disposition requires its own authenticated input.

```sh
G=work/round18-rustc/guard-file-free-math-asm
X=$G/production-uvx-bins
F=$G/package-test-full-stack/physical/outer-return.json
/usr/bin/python3 -ISB "$X/run.py" verify
OHM_UVX_BINS_RELEASE="$(sha256sum "$X/registration.json" | cut -d' ' -f1)" \
  /usr/bin/python3 -ISB "$X/run.py" start "$(realpath "$F")" "$actual_previous_sha256"
/usr/bin/python3 -ISB "$X/run.py" close "$real_outer_session" "$real_final_chunk" "$real_exit"
/usr/bin/python3 -ISB "$X/run.py" closed "$(realpath "$X/physical/outer-return.json")" "$actual_new_sha256"
/usr/bin/python3 -ISB "$X/run.py" family
```

The two existing compressed A histories stay in place. Their restored sizes total 7,441,768,448 bytes. The opening check requires 9,052,381,184 additional bytes beyond the 6-GiB tmpfs and 20-GiB system-RAM reserves. Both disks retain the original 122-GiB floor and guard margins. Only the two working histories of one round exist simultaneously. Their namespace, owner, contents, modes, times and hardlink topology are checked on restore, and each is retired after its products and raw measurements are checked. No new A archives are written.

The three `*controls.py` entries use temporary invented samples and the saved process census. They exercise normal, traced and screen-out dispatch, both arms’ restoration, the full 12-pair case, physical start/close data contracts, and corruptions of clocks, source, products and ownership. These controls run independently of any physical benchmark outcome.
