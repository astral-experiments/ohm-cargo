"""Calibrate complete-argument decoding on two previously observed ordinary build processes."""
import hashlib,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from full_stack_trace import args_from
from production_score import original,plan,read,sha
from common import need
def calibrate():
    t=HERE/'production-calibration';q=read(t/'description.json');need(q['historical_census_sha256']=='70a98de00c0fbd037490dfcaeca610211af4ddd87736bf3db7d9ce05f0779e25','unknown old census')
    jobs=[]
    for role,n,h in [('compile',1468,'302e7560c58beb51e3c736623b0042d393ad95ce71e51f2ad3c7ffa46b7e132f'),('link',144,'209e53f83b2a3480a4be2b5c2e07283141f4e9b4fb9dec1b845fd4f732c67cb0')]:
        row=q['actual'][role];p=t/('exec.'+str(row['pid']));need(sha(p)==h,'historical raw stream changed')
        result=[args_from(l.strip()) for l in p.read_text().splitlines()]
        need(result.count((row['exe'],row['argv']))==1 and len(row['argv'])==n,'decoded arguments disagree with original census');jobs.append(row['argv'])
    compiler,linker=jobs;need('crates/uv/src/bin/uvx.rs' in compiler and '-Zohm-check-relink-inputs' in compiler and
        str(Path(compiler[compiler.index('--out-dir')+1])/'uvx')==linker[linker.index('-o')+1],'source producer != actual native link')
    return {'historical_ordinary_build_check_only':True,'argv_entries':list(map(len,jobs)),'exact_actual_calls':2,'physical_endpoint_rows':0,'SHA256':[sha(t/('exec.'+str(q['actual'][k]['pid']))) for k in ('compile','link')]}
if __name__=='__main__':print(json.dumps(calibrate(),sort_keys=True))
