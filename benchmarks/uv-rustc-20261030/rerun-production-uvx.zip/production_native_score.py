"""Replay a compact native result from an independently trusted real supervisor SHA."""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from production_score import ARMS, NAME, SCIENCE, engine, module, original, plan, read, sha, validate_behavior
from common import need

REG='56a3208b66bd9f47c37a64356c1eb6e4bd296955ab9685077ff5f00bf3c29518'
LIMIT=256<<20;MEMBER=16<<20
def digest(b):return hashlib.sha256(b).hexdigest()
def pathok(n):
    p=PurePosixPath(n)
    need(n and str(p)==n and not p.is_absolute() and '..' not in p.parts and '\\' not in n and '\x00' not in n,'invalid packet path')
def extraction(packet,root):
    with zipfile.ZipFile(packet) as z:
        names=z.namelist();need(len(set(names))==len(names)<=50000 and 'layout.json' in names,'invalid ZIP inventory')
        infos=z.infolist();need(all(i.file_size<=MEMBER and not i.is_dir() for i in infos) and sum(i.file_size for i in infos)<=LIMIT,'packet exceeds limits')
        index=json.loads(z.read('layout.json'));need(index['format']=='production-uvx-native-v1' and len(index['files'])<=50000,'unknown packet')
        table=index['files'];need({f'objects/{h}' for h in table.values()}|{'layout.json'}==set(names),'inexact content index')
        need(sum(z.getinfo('objects/'+h).file_size for h in table.values())<=LIMIT,'expanded evidence exceeds limit')
        for n,h in table.items():
            pathok(n);need(re.fullmatch('[0-9a-f]{64}',h),'invalid digest')
            b=z.read('objects/'+h);need(digest(b)==h,'raw member changed');f=root/n;f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes(b)
def custody(root,expected):
    p=root/'outer-return.json';need(re.fullmatch('[0-9a-f]{64}',expected) and sha(p)==expected,'different trusted outer')
    o=read(p);w=read(root/'worker-return.json');i=read(root/'intake.json');real=o['outer']
    need(i['phase']=='production-uvx-bins' and i['registration']==REG and o['host_released'] is True and o['remaining_workers']==[] and
         o['intake_sha256']==sha(root/'intake.json') and o['worker_sha256']==sha(root/'worker-return.json') and
         len(set(o['locks']))==2 and i['locks']==w['locks']==o['locks'] and i['boot']==o['boot'] and i['start_ns']<w['end_ns'] and
         re.fullmatch('[0-9a-f]{6}',real['chunk']) and isinstance(real['session'],int) and real['session']>0 and
         real['exit']==o['worker_code']==w['code']==w['worker_exit'] and w['owned_children_at_return']==[],'unverified physical return')
    return o,w,i
def validate_sources(root,p):
    need(sha(root/'source/registration.json')==REG and sha(root/'source/protocol.json')==SCIENCE,'different native source or schedule')
    for n,h in read(root/'source/registration.json')['sources'].items():
        pathok(n);need(sha(root/'source'/n)==h,'registered native evidence source changed')
    for n,h in read(root/'source/registration.json')['external_sources'].items():
        if n.endswith('/fresh-edit-trial/score.py'):need(sha(root/'source/score.py')==h,'changed raw scorer')
    for n in ('command.py','run.py','replay.py','inputs.py'):
        need(sha(root/'source'/n)==sha(original(n)),'different registered worker/analysis')
    manifests={}
    for arm in ARMS:
        f=root/'official'/(arm+'-sdk.json');sub=p['subjects'][arm]
        need(sha(f)==sub['ready_sha256'],'changed actual SDK receipt')
        manifest=read(f);members=manifest['files'];driver=manifest['driver']
        need(len(members)==65 and members[driver]==sub['driver_sha256'] and members['bin/cargo']==sub['cargo_sha256'] and members['bin/rustc']==sub['launcher_sha256'],'wrong SDK membership')
        manifests[arm]={n:h for n,h in members.items() if n!=driver}
    need(manifests['C']==manifests['CZD'],'other physical SDK members changed')
    for n,h in p['inputs'].items():
        pathok(n);need(sha(root/'inputs'/n)==h,'registered prior observation, SDK or source changed')
def compare_trace(d,row,prod,streams=None):
    from full_stack_trace import args_from
    from production_trace import real_rust
    raw=read(d/'census.json');streams=streams if streams is not None else read(d/'trace-inventory.json');need(streams=={f.name:sha(f) for f in sorted(d.glob('exec.*'))} and streams,'absent raw exec provenance')
    actual={};top=[]
    for n in streams:
        pid=int(n.split('.')[1])
        for line in (d/n).read_text().splitlines():
            q=args_from(line.strip())
            if q is None:continue
            exe,argv=q
            if argv==row['argv'] and exe==argv[0]:top.append(pid)
            if (Path(exe).name=='rustc' and real_rust(argv)) or ('/wild-ld/' in exe and '-o' in argv):
                actual.setdefault((pid,exe,tuple(argv)),0);actual[(pid,exe,tuple(argv))]+=1
    need(len(top)==1,'missing or duplicated root Cargo exec')
    # An OS-level configure or print probe is retained but is not a source-producing rustc/wild job.
    declared=[z for z in raw['actual'] if z['role'] in ('compile','link') and ((Path(z['exe']).name=='rustc' and real_rust(z['argv'])) or ('/wild-ld/' in z['exe'] and '-o' in z['argv']))]
    need(actual=={(z['pid'],z['exe'],tuple(z['argv'])):1 for z in declared},'raw rustc or Wild argv differs from the native census')
    own=[z for z in declared if z['role']=='compile' and plan()['source']['source_path'] in z['argv']]
    need(len(own)==1 and '-Zohm-check-relink-inputs' in own[0]['argv'] and '--test' not in own[0]['argv'] and
         str(own[0]['pid']) in read(d/'raw-mapped-drivers.json') and any(z['role']=='link' and z['argv'][z['argv'].index('-o')+1].endswith('/'+prod['producer']['uvx']) for z in declared),'wrong binary-producing driver/link')
def cas_objects(folder,idx,public,cas=None):
    raw={}
    for phase in ('A','B'):
        for arm in ARMS:
            keep=read(folder/'admission'/arm/phase/'retained.json');need(set(keep)=={'uv','uvx'},'different retained programs')
            for name,pr in public[phase]['programs'].items():
                q=keep[name];h=pr['sha256'];need(q['raw_sha256']==h and q['raw_bytes']==pr['bytes'] and idx.get(h)==q and q['compressed_bytes']>0 and re.fullmatch('[0-9a-f]{64}',q['compressed_sha256']),'wrong retained program or compressed binding')
                raw[h]=q
    need(len(raw)==3 and idx==raw,'incomplete independently retained archive')
    if cas is not None:
        for h,q in raw.items():
            f=Path(cas)/(h+'.zst');need(not f.is_symlink() and f.is_file() and f.stat().st_size==q['compressed_bytes'] and sha(f)==q['compressed_sha256'],'missing or changed supplied compressed ELF')
            v=hashlib.sha256();n=0
            with subprocess.Popen(['zstd','-qdc','--',str(f)],stdout=subprocess.PIPE) as dec:
                for b in iter(lambda:dec.stdout.read(1<<20),b''):
                    n+=len(b);need(n<=q['raw_bytes'],'decompressed ELF exceeded bound');v.update(b)
                need(dec.wait()==0 and n==q['raw_bytes'] and v.hexdigest()==h,'full ELF byte digest mismatch')
    return sorted(raw)
def audit(root,expected,previous_packet=None,cas=None,scratch=None):
    p=plan();validate_sources(root,p);folder=root/'physical';o,w,i=custody(folder,expected)
    prev=root/'predecessor';need(sha(prev/'outer-return.json')==i['previous_sha256'],'different real previous return')
    po=read(prev/'outer-return.json');need(po['outer']==i['outer'] and po['boot']==i['boot'] and po['host_released'] and not po['remaining_workers'] and po['outer']['exit']==0 and
         po['worker_sha256']==sha(prev/'worker-return.json') and po['intake_sha256']==sha(prev/'intake.json'),'previous host closure is not authentic')
    if 'stock_disposition_registration_sha256' in i:
        import production_host as host
        resource=host.recorded(root/'host',i,'bins')
        pred=read(prev/'intake.json')
        if 'stock_capacity_handoff_registration_sha256' in i or 'stock_no_start_outer_sha256' in i:
            import production_capacity as capacity
            capacity.marks(pred);need(pred['previous_sha256']==resource['material_sha256'] and pred['outer']==resource['material_outer'],'different complete prior material disposition')

        need(pred['stock_disposition_registration_sha256']==i['stock_disposition_registration_sha256'] and pred['excluded_stock_outer_sha256']==i['excluded_stock_outer_sha256'],'preceding full comparison used a different host authority')
    if w['code']:
        need(w.get('success') is None,'conflicting success on failed worker')
        return {'scope':NAME,'native_outer':o['outer'],'closed':False,'eligible':False,'credited_pairs':0,'decision_p':1.,'failure_log':(folder/'failure.log').is_file(),'own_outer_sha256':expected}
    success=read(folder/'successful.json');res=read(folder/'resources-returned.json');prevterms=read(root/'family.json')
    for n,key,parent in [('successful.json','success',w),('analysis.json','analysis_sha256',success),('resources-returned.json','resources_sha256',success),('subjects.json','subjects_sha256',success),('cas-index.json','cas_sha256',res)]:
        need(sha(folder/n)==parent[key],'unbound successful native closure')
    need(o['foreign']==[] and not w['capacity']['guard_fault'] and res['all_private_slots_retired'] and res['new_archives']==0 and
         success['registered']==res['owner']['registration']==REG and read(folder/'original-archives.json')==res['originals'] and all(res['originals'][a]['sha256']==p['archives'][a]['sha256'] for a in ARMS),'invalid success/retirement')
    subjects=read(folder/'subjects.json')['subjects']
    need(all(subjects[a]==p['subjects'][a] for a in ARMS),'different actual matched subjects')
    doc=engine().study(folder,p);need(doc==read(folder/'analysis.json')==prevterms['outcome'] and success['rows']==doc['scored_rows'],'original raw scorer disagrees')
    for q in doc['public_programs'].values():validate_behavior(q['argv_and_exit'])
    for a in ARMS:
        f=folder/'admission'/a/'B';compare_trace(f,read(f/'command.json'),doc['public_programs']['B'])
    kept=cas_objects(folder,read(folder/'cas-index.json'),doc['public_programs'],cas)
    family=prevterms['original_twelve'];need(family['own_outer_sha256']==i['previous_sha256'] and not family['pooled'],'wrong previous decision')
    if previous_packet:
        from production_score import prior_family
        independent,_=prior_family(previous_packet,i['previous_sha256'],scratch);need(independent['twelve']==family['twelve'],'earlier raw packet disagrees with native Holm12')
    proper=engine().holm13(family,doc,p)
    need(proper==prevterms['thirteen'] and prevterms['native_outer']==o['outer'] and prevterms['own_outer_sha256']==expected and not prevterms['pooled'],'13-way correction not reproduced')
    return {'scope':NAME,'native_outer':o['outer'],'closed':True,'eligible':doc['counted_pairs']==12,'credited_pairs':doc['counted_pairs'],'raw_rows':doc['raw_rows'],'excluded_pilot':doc['excluded_pilot'],'score':doc['score'],'decision':proper[NAME],'thirteen':proper,'earlier_evidence':'detached preceding 12 reverified' if previous_packet else 'owner-reported 12 p-values; preceding raw packet optional','retained_public_sha256':kept,'actual_elf_bytes_independently_reread':cas is not None,'own_outer_sha256':expected}
def run(packet,expected,scratch=None,previous_packet=None,cas=None):
    base=Path(scratch or tempfile.gettempdir()).resolve(strict=True);need(shutil.disk_usage(base).free>=LIMIT+(64<<20),'insufficient temporary replay space')
    with tempfile.TemporaryDirectory(prefix='uvx-native-proof-',dir=base) as work:
        root=Path(work)/'extraction';root.mkdir();extraction(packet,root);return audit(root,expected,previous_packet,cas,base)
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('packet',type=Path);a.add_argument('--outer',required=True);a.add_argument('--packet-sha256');a.add_argument('--previous-packet',type=Path);a.add_argument('--elf-cas',type=Path);a.add_argument('--scratch',type=Path);q=a.parse_args()
    if q.packet_sha256:need(sha(q.packet)==q.packet_sha256,'different published ZIP digest')
    print(json.dumps(run(q.packet,q.outer,q.scratch,q.previous_packet,q.elf_cas),indent=2,sort_keys=True))
