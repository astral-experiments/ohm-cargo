"""Export only a genuinely returned native production study, with no benchmark locks or mutations."""
import argparse,hashlib,json,os,re,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_native_score as n
from production_score import ARMS, original, plan, read, sha

def dump(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def make(path,files):
    table={};hashes={}
    for name,v in files.items():
        n.pathok(name)
        if isinstance(v,Path):n.need(not v.is_symlink() and v.is_file() and v.stat().st_size<=n.MEMBER,'invalid or oversized proof file');v=v.read_bytes()
        n.need(len(v)<=n.MEMBER and name not in table,'invalid input member')
        h=hashlib.sha256(v).hexdigest();table[name]=h;hashes.setdefault(h,v)
    n.need(sum(len(hashes[h]) for h in table.values())<=n.LIMIT,'oversize expanded evidence')
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('layout.json',dump({'format':'production-uvx-native-v1','files':table}))
        for h in sorted(hashes):z.writestr('objects/'+h,hashes[h])
    n.need(path.stat().st_size<90<<20,'compact evidence exceeds 90 MiB cap')
def export(scope,expected,dest,scratch,previous=None,cas=None,reserve=0):
    scope=Path(scope).resolve(strict=True);p=plan();physical=scope/'physical';n.need(scope.name=='production-uvx-bins' and sha(scope/'registration.json')==n.REG,'unknown registered native root')
    o,w,i=n.custody(physical,expected);prior=Path(i['previous']).resolve(strict=True)
    n.need(prior==scope.parent/'package-test-full-stack/physical/outer-return.json' and sha(prior)==i['previous_sha256'],'unexpected predecessor')
    dest=Path(dest).resolve();scratch=Path(scratch).resolve(strict=True);n.need(not dest.exists() and dest.parent.is_dir() and reserve>=0 and
         shutil.disk_usage(dest.parent).free>=reserve+(90<<20) and shutil.disk_usage(scratch).free>=reserve+n.LIMIT+(100<<20),'destination exists or insufficient space')
    files={};reg=read(scope/'registration.json')
    for name,h in reg['sources'].items():
        f=scope/name;n.need(sha(f)==h,'changed registered source');files['source/'+name]=f
    files['source/registration.json']=scope/'registration.json';files['source/score.py']=scope.parent/'fresh-edit-trial/score.py'
    for name,h in p['inputs'].items():
        n.pathok(name);f=scope.parent.parent/name;n.need(sha(f)==h,'prior intake no longer matches');files['inputs/'+name]=f
    files['official/C-sdk.json']=scope.parent/'bootstrap/physical-v2/C/sdk.json'
    files['official/CZD-sdk.json']=scope.parent/'bootstrap/subject-recovery/physical-qa/CZD/sdk.json'
    for child in ('outer-return.json','worker-return.json','intake.json'):files['predecessor/'+child]=prior.parent/child
    for f in sorted(physical.rglob('*')):
        if f.is_dir() and not f.is_symlink():continue
        rel=f.relative_to(physical)
        n.need(len(rel.parts)<=4 and not f.is_symlink() and (f.suffix in ('.json','.stdout','.stderr','.log') or re.fullmatch(r'exec\.\d+',f.name)),'unrecognized physical experiment output: '+str(rel))
        files['physical/'+rel.as_posix()]=f
    import production_host as host
    enhanced='stock_disposition_registration_sha256' in i
    if enhanced:
        for n0,f in host.build(scope.parent,i).items():files['host/'+n0]=f
    selector=host.selected(scope.parent,i,'bins') if enhanced else scope/'run.py'
    if not w['code']:
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
        actual=json.loads(subprocess.check_output(['/usr/bin/python3','-ISB',str(selector),'family'],env=env));n.need(actual['own_outer_sha256']==expected and actual['native_outer']==o['outer'],'owner did not verify this exact terminal');files['family.json']=dump(actual)
    with tempfile.TemporaryDirectory(prefix='.uvx-export-',dir=dest.parent) as tmp:
        new=Path(tmp)/'result.zip';make(new,files);proof=n.run(new,expected,scratch,previous,cas)
        n.need(shutil.disk_usage(dest.parent).free>=reserve and shutil.disk_usage(scratch).free>=reserve,'reserve consumed');os.link(new,dest)
    return {'packet':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest),'input_files':len(files),'verification':proof}
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--native-root',required=True,type=Path);a.add_argument('--outer',required=True);a.add_argument('--out',required=True,type=Path);a.add_argument('--scratch',type=Path,required=True);a.add_argument('--previous-packet',type=Path);a.add_argument('--elf-cas',type=Path);a.add_argument('--reserve-gib',type=int,default=122);q=a.parse_args()
    print(json.dumps(export(q.native_root,q.outer,q.out,q.scratch,q.previous_packet,q.elf_cas,q.reserve_gib<<30),sort_keys=True,indent=2))
