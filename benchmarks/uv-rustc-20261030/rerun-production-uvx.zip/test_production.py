"""Small offline controls. Python stubs and a simulated Cargo child generate no benchmark numbers."""
import json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production as run
import production_score as score
from common import need,sha,write

def stub(p,s):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():p.unlink()
    p.write_text('#!/usr/bin/python3 -ISB\n'+s);p.chmod(0o755)

class FakeGuard:
    def __init__(self,runner):self.events=[]
    def __enter__(self):return self
    def __exit__(self,*a):pass

class FakeMaps:
    def __init__(self,*a):pass
    def start(self,p):pass
    def finish(self):return {'702':{'start_ticks':7,'driver_dev':1,'driver_ino':2},'703':{'start_ticks':8,'driver_dev':1,'driver_ino':2}}

def simulate(root,pass_pilot):
    root.mkdir();f=run.Runner.__new__(run.Runner);f.root=root;f.spec=score.plan();f.plan=run.old.read(HERE/'workflow.json');f.sdk=root/'visible/sdk';f.driver=f.spec['subjects']['C']['driver']
    f.physical=root/'production-physical';f.active=root/'active';f.src=f.active/'source';f.target=f.active/'target';f.reserve=0;f.budget=1<<30;f.env={'PATH':'/usr/bin:/bin','LC_ALL':'C'}
    f.subjects=run.old.read(HERE/'subjects.json');f.uv_source=f.spec['source']['source_path'];f.owners={};f.archives={};f.libs={};f.watch_cpu=None;f.space=lambda *args:None
    for n in ('records','sources','seeds','objects','source-template','registry','warm','production-physical'):(root/n).mkdir()
    source=root/'source-template'/f.uv_source;source.parent.mkdir(parents=True);source.write_bytes(score.source_path('A.rs').read_bytes())
    os.utime(source,ns=(1500000000000000000,1500000000000000000));(root/'sources/uvx-B.rs').write_bytes(score.source_path('B.rs').read_bytes())
    (root/'sources/Cargo.lock').write_bytes(b'synthetic lock\n');f.config=lambda:None
    f.cmd=[str(f.sdk/'bin/cargo'),*f.spec['argv'][1:]]
    for n in ('bin/rustc','bin/cargo',f.driver,'lib/rustlib/x/bin/wild-ld/ld.bfd'):
        file=f.sdk/n;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(b'fixture only, not executable')
    def select(arm):f.current=arm
    f.select=select
    def state(phase):
        path=f.src/f.uv_source;b=path.read_bytes();need(b==score.source_path(phase+'.rs').read_bytes(),'test source')
        return {'state':phase,'form':phase,'oid':f.spec['source']['uv_base'],'ref':'refs/heads/feature-A','path':f.uv_source,'blob':run.old.blob(b),'sha256':sha(path),'mtime_ns':path.stat().st_mtime_ns,'lock_sha256':sha(root/'sources/Cargo.lock')}
    f.state=state
    schema={a:{n:{'sha256':h,'mode':493} for n,h in f.subjects['common_members'].items()} | {f.driver:{'sha256':f.subjects[a]['driver_sha256'],'mode':493}} for a in score.ARMS}
    write(root/'sdk-manifests.json',schema);write(root/'source-identity.json',{'synthetic':True})
    write(root/'inputs.json',{'subject_provenance':f.subjects})
    write(root/'production-intake.json',{'scope':score.NAME,'protocol_sha256':score.SCIENCE,'absolute_argv':f.cmd,'source_identity_sha256':sha(root/'source-identity.json'),'sdk_manifests_sha256':sha(root/'sdk-manifests.json')})
    p0=subprocess.Popen;clock=[1000];launched=[]
    class Clock:
        time_ns=staticmethod(time.time_ns);monotonic=staticmethod(time.monotonic)
        @staticmethod
        def monotonic_ns():clock[0]+=1;return clock[0]
    class Child:
        pid=700
        def wait(self):return 0
        def poll(self):return 0
    def command(args,*p,**kw):
        if not isinstance(args,list) or not all(isinstance(a,str) for a in args) or not (args[:2]==f.cmd[:2] or args[:1]==['/usr/bin/strace']):return p0(args,*p,**kw)
        traced=args[0]=='/usr/bin/strace';ordinary=args[args.index(str(f.sdk/'bin/cargo')):];phase='A' if (f.src/f.uv_source).read_bytes()==source.read_bytes() else 'B'
        need(ordinary in (f.cmd,f.cmd[:-1]) and (phase=='A' or ordinary==f.cmd),'unexpected fake invocation')
        launched.append([f.current,phase,traced,ordinary[-1]])
        clock[0]+=((310 if pass_pilot else 115) if f.current=='C' and phase=='B' else 100)
        outdir=f.target/'debug';outdir.mkdir(parents=True,exist_ok=True);ver=f.plan['A']['version'];detail=f.plan['A']['self_version']
        uv='import json,sys\nprint('+repr(ver)+' if sys.argv[1:]==["--version"] else json.dumps('+repr(detail)+'))\n'
        uvx='''import os,sys
from pathlib import Path
me=Path(sys.argv[0]); pos=me.name[3:];first=me.with_name('uv'+pos);second=me.with_name('uv')
if me.name=='uvx' and sys.argv[1:]==['--version']:
    print(VERSION);sys.exit(0)
for p in (first,second):
    if p.exists():os.execv(p,[str(p),'tool','uvx',*sys.argv[1:]])
sys.stderr.write('error: Could not find the `uv` binary at either of:\\n  '+str(first)+'\\n  '+str(second)+'\\n');sys.exit(2)
'''.replace('VERSION',repr(ver.replace('uv ','uvx ',1)))+'# '+phase+'\n'
        rows=[(701,f.cmd[0],ordinary)]
        libdir=outdir/'build/uv/lib/out';libdir.mkdir(parents=True,exist_ok=True)
        for ext in ('.rlib','.rmeta'):(libdir/('libuv-abc'+ext)).write_bytes(b'illustrative library')
        if phase=='A':
            exe=str(f.sdk/'bin/rustc');rows.append((710,exe,[exe,'--crate-name','uv','crates/uv/src/lib.rs','--emit=dep-info,metadata,link','--out-dir',str(libdir),'-C','extra-filename=-abc','-Zohm-check-relink-inputs']))
        for name,body,pid in [('uv',uv,703),('uvx',uvx,702)]:
            owner=outdir/'build/uv'/('u'+name)/'out'/name;stub(owner,body);link=outdir/name
            if link.exists():link.unlink()
            os.link(owner,link)
            compiler=str(f.sdk/'bin/rustc');wild=str(f.sdk/'lib/rustlib/x/bin/wild-ld/ld.bfd')
            if phase=='A' or name=='uvx':
                rows.extend([(pid,compiler,[compiler,'--crate-name',name,'crates/uv/src/bin/'+name+'.rs','--emit=dep-info,link','--out-dir',str(owner.parent),'-Zohm-check-relink-inputs']),
                             (pid+100,wild,[wild,'-o',str(owner),'file.o'])])
        if phase=='B':
            stamp=outdir/'build/uv/uuvx/fingerprint/invoked.timestamp';stamp.parent.mkdir(exist_ok=True);stamp.touch()
            kw['stderr'].write(b'   Compiling uv v0.12.0\n');kw['stderr'].flush()
        if traced:
            dest=Path(args[args.index('-o')+1])
            for pid,exe,a in rows:(dest.parent/(dest.name+'.'+str(pid))).write_text('execve('+json.dumps(exe)+', '+json.dumps(a)+', []) = 0\n')
        return Child()
    def versions(args,*a,**kw):return f.spec['subjects'][f.current][Path(args[0]).name+'_version'].encode()
    with patch.object(run.subprocess,'Popen',command),patch.object(run,'Guard',FakeGuard),patch.object(run.trace,'DriverMaps',FakeMaps),patch.object(run.old,'drain_session',lambda p:{'remaining':[]}),patch.object(run.old,'version_output',versions),patch.object(run,'time',Clock),patch.object(run,'ELF',b'#!'):
        result=run.endpoint(f)
    counted=12 if pass_pilot else 0
    assert result['counted_pairs']==counted and result['excluded_pilot']['continues']==pass_pilot
    assert sum(1 for _,phase,traced,last in launched if phase=='B' and not traced)==2+2*counted
    assert sum(1 for _,phase,traced,last in launched if phase=='B' and traced)==2
    assert all(last=='--bins' for _,phase,_,last in launched if phase=='B')
    return result

def reject(fn):
    try:fn()
    except (ValueError,KeyError,OSError):return
    raise AssertionError('invalid evidence accepted')

def main():
    with tempfile.TemporaryDirectory() as path:
        t=Path(path);root=t/'pass';passed=simulate(root,True);stopped=simulate(t/'stop',False)
        assert passed['score']['individual_gate'] and stopped['score'] is None
        previous,_=score.prior_family(None,None,None);assert score.engine().holm13(previous,passed,score.plan())[score.NAME]['confirmed']
        for part,field,mut in [('pair-00/C/B/products.json','programs',lambda x:x['uv'].update(sha256='0'*64)),
                              ('pair-00/CZD/B/products.json','argv_and_exit',lambda x:x['missing'].update(stderr='changed')),
                              ('pair-00/C/B/command.json','argv',lambda a:a.pop()),
                              ('pair-00/order.json','primer_order',lambda a:a.reverse()),
                              ('admission/C/B/census.json','actual',lambda a:a[0]['argv'].append('--test'))]:
            p=root/'production-physical'/part;raw=p.read_bytes();v=json.loads(raw);mut(v[field]);p.write_text(json.dumps(v));reject(lambda:score.local_replay(root));p.write_bytes(raw)
        obj=next((root/'objects').iterdir());raw=obj.read_bytes();obj.write_bytes(b'bad');reject(lambda:score.local_replay(root));obj.write_bytes(raw)
        wrong=t/'wrong';stub(wrong,'import sys\nsys.exit(37)\n');reject(lambda:score.behavior().observe(wrong,t))
        assert score.local_replay(root)['counted_pairs']==12
    print(json.dumps({'synthetic':True,'real_compilers_or_cargo_launched':0,'timed_row_dispatch':24,'A_primers_in_scored_rounds':24,'pilot_stop_counted':0,
          'two_byte_distinct_uvx_inputs':True,'genuine_behavior_oracle_on_python_fixture':True,'normal_and_traced_dispatch':True,
          'negative':['uv bytes','argv/missing message','wrong command','wrong primer order','trace mismatch','corrupt CAS','wrong behavior binary'],'original_native_science_replayed':True},sort_keys=True))
if __name__=='__main__':main()
