"""Exercise the native ZIP reader on wholly synthetic, completed, screened-out and failed workers."""
import copy, json, shutil, sys, tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import production_native_score as n, production_export as e, production_score as sc
from test_production import simulate,reject

def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(e.dump(v))
def example(top,passed):
    local=top/'local';doc=simulate(local,passed);p=sc.plan();r=top/'result';d=r/'physical';shutil.copytree(local/'production-physical',d);root=HERE/'production-calibration/frozen-references'
    for k in ('inputs','official'):shutil.copytree(root/k,r/k)
    shutil.copytree(sc.NATIVE,r/'source');shutil.copyfile(sc.BASE/'guard-file-free-math-asm/fresh-edit-trial/score.py',r/'source/score.py')
    # The archive, driver, source and comparator identities are the real frozen constants; these events and clocks are simulated.
    for f in d.glob('*/*/incoming.json'):
        a=f.parent.name;q=sc.read(f);q['archive_sha256']=p['archives'][a]['sha256'];q['manifest_sha256']=p['archives'][a]['state']['manifest_sha256'];put(f,q)
    cas=top/'cas';cas.mkdir();idx={}
    import subprocess
    for a in sc.ARMS:
        for form in ('A','B'):
            f=d/'admission'/a/form;want=sc.read(f/'products.json')['programs'];kept={}
            for name,v in want.items():
                h=v['sha256'];raw=local/'objects'/h;z=cas/(h+'.zst')
                if h not in idx:
                    subprocess.run(['zstd','-q','-o',str(z),'--',str(raw)],check=True)
                    idx[h]={'raw_sha256':h,'raw_bytes':raw.stat().st_size,'compressed_bytes':z.stat().st_size,'compressed_sha256':sc.sha(z)}
                kept[name]=idx[h]
            put(f/'retained.json',kept)
            if form=='B':
                c=sc.read(f/'census.json');c['actual'] += [{'role':'link','output':z['argv'][z['argv'].index('-o')+1],**z} for z in c.pop('raw_wild')];put(f/'census.json',c)
                put(f/'attestation.json',sc.engine().x.attest(f,True))
    doc=sc.engine().study(d,p);put(d/'analysis.json',doc);put(d/'cas-index.json',idx)
    original={a:{'sha256':p['archives'][a]['sha256']} for a in sc.ARMS};put(d/'original-archives.json',original)
    put(d/'resources-returned.json',{'all_private_slots_retired':True,'new_archives':0,'owner':{'registration':n.REG},'originals':original,'cas_sha256':sc.sha(d/'cas-index.json')});put(d/'subjects.json',{'subjects':p['subjects']})
    put(d/'successful.json',{'registered':n.REG,'rows':doc['scored_rows'],'analysis_sha256':sc.sha(d/'analysis.json'),'resources_sha256':sc.sha(d/'resources-returned.json'),'subjects_sha256':sc.sha(d/'subjects.json')})
    pre=r/'predecessor';locks=['fake-experiment-lock','fake-shared-lock'];put(pre/'intake.json',{'testing':True});put(pre/'worker-return.json',{'testing':True});old={'outer':{'session':12,'chunk':'000012','exit':0},'host_released':True,'remaining_workers':[],'worker_sha256':sc.sha(pre/'worker-return.json'),'intake_sha256':sc.sha(pre/'intake.json'),'boot':'synthetic'}
    put(pre/'outer-return.json',old);ph=sc.sha(pre/'outer-return.json')
    i={'phase':'production-uvx-bins','registration':n.REG,'previous_sha256':ph,'outer':old['outer'],'boot':'synthetic','locks':locks,'start_ns':1};put(d/'intake.json',i)
    w={'locks':locks,'owned_children_at_return':[],'end_ns':10,'code':0,'worker_exit':0,'success':sc.sha(d/'successful.json'),'capacity':{'guard_fault':None}};put(d/'worker-return.json',w)
    real={'outer':{'session':13,'chunk':'000013','exit':0},'worker_sha256':sc.sha(d/'worker-return.json'),'intake_sha256':sc.sha(d/'intake.json'),'host_released':True,'remaining_workers':[],'foreign':[],'locks':locks,'boot':'synthetic','worker_code':0};put(d/'outer-return.json',real);h=sc.sha(d/'outer-return.json')
    previous,_=sc.prior_family(None,None,None);previous.update(own_outer_sha256=ph,pooled=False)
    put(r/'family.json',{'original_twelve':previous,'outcome':doc,'thirteen':sc.engine().holm13(previous,doc,p),'own_outer_sha256':h,'native_outer':real['outer'],'pooled':False})
    return r,h,cas
def zipped(r,out):e.make(out,{p.relative_to(r).as_posix():p for p in r.rglob('*') if p.is_file()})
def main():
    with tempfile.TemporaryDirectory() as t:
        t=Path(t)
        for yes in (True,False):
            w=t/str(yes);w.mkdir();r,h,cas=example(w,yes);z=w/'native.zip';zipped(r,z);proof=n.run(z,h,w,None,cas);assert proof['credited_pairs']==(12 if yes else 0) and proof['decision']['confirmed']==yes and proof['actual_elf_bytes_independently_reread']
            if not yes:continue
            q=r/'physical/admission/C/B/census.json';raw=q.read_bytes();v=sc.read(q);v['actual'][0]['argv'][0]+='other';put(q,v)
            reject(lambda:n.audit(r,h));q.write_bytes(raw)
            selected=next(cas.glob('*.zst'));b=selected.read_bytes();selected.write_bytes(b'bad');reject(lambda:n.run(z,h,w,None,cas));selected.write_bytes(b)
            q=r/'family.json';raw=q.read_bytes();v=sc.read(q);v['thirteen'][sc.NAME]['adjusted_p']=1.;put(q,v);reject(lambda:n.audit(r,h));q.write_bytes(raw)
            q=r/'physical/worker-return.json';v=sc.read(q);v.update(code=1,worker_exit=1,success=None);put(q,v);out=r/'physical/outer-return.json';o=sc.read(out);o['outer']['exit']=1;o['worker_sha256']=sc.sha(q);o['worker_code']=1;put(out,o);(r/'physical/failure.log').write_text('synthetic rejection');fail=n.audit(r,sc.sha(out));assert fail['credited_pairs']==0 and fail['decision_p']==1
    print(json.dumps({'synthetic':True,'full_counted_pairs':12,'screened_out_pairs':0,'failed_pairs':0,'real_compilers_launched':0,'decoded_all_three_mock_programs':True,'rejected':['raw argv tamper','corrupt compressed retained object','tampered Holm13']},sort_keys=True))
if __name__=='__main__':main()
