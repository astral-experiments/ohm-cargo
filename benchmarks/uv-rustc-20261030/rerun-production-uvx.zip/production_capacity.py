"""Verify only the named no-start and the intervening duplicate-resource return."""
import hashlib,json,re
from pathlib import Path
from production_host import REG as ORIGINAL,STOCK,STORAGE,read,sha,need
NEW='af749d8f542a5f1e6a0fc312b260066e1b6db468e8c0e71703731e9e3c5b1396'
STOP='2ba88da7c2a44be06da395390aefa8fc36778eb6387ba060219675671a54d29f'
QPATH='private-normalize-fanout/failed-first-anchor'
EPATH='root-compiler-space-audit/exdev-slice'
def marks(i):
    need(i.get('stock_capacity_handoff_registration_sha256')==NEW and i.get('stock_no_start_outer_sha256')==STOP and i['stock_disposition_registration_sha256']==ORIGINAL and i['excluded_stock_outer_sha256']==STOCK,'different registered capacity or initial denial')
def static(D):
    A=D/'after-stock-2868/after-capacity';q=read(A/'registration.json')
    need(sha(A/'registration.json')==NEW and q['original_handoff']==ORIGINAL,'capacity registration does not extend original custody')
    rows={'registration.json':A/'registration.json'}
    for rel,h in q['pins'].items():
        f=(A/rel).resolve(strict=True);need(f.is_relative_to(D.parent.resolve()) and f.is_file() and not f.is_symlink() and f.stat().st_size<2<<20 and sha(f)==h,'changed or oversized registered capacity input')
        rows['pins/'+h]=f
    for n,f in {'noreturn.json':D.parent/QPATH/'rejected-capacity.json','stock-bridge.json':D.parent/QPATH/'after-exdev-registration.json','stock-first-anchor.json':D.parent/QPATH/'retained-first-anchor.json','exdev-reg.json':D.parent/EPATH/'registration.json','exdev-primary.json':D.parent/EPATH/'proof.json','exdev-secondary.json':D.parent/EPATH/'second-proof.json','exdev-selection.json':D.parent/EPATH/'selection.json','exdev-selection-2.json':D.parent/EPATH/'second-selection.json'}.items():rows[n]=f
    return q,rows
def build(D,i):
    marks(i);_,rows=static(D);E=D.parent/EPATH/'physical'
    for n in ('outer-return.json','worker-return.json','intake.json','returned-four-locks.json','result.json','journal/before.json'):
        f=E/n;need(f.is_file() and f.stat().st_size<2<<20,'missing or oversized completed storage receipt');rows['material/'+n]=f
    rows['material-stock/first-anchor.json']=D.parent/QPATH/'physical/first-anchor.json'
    return rows
def recorded(r,i,previous,stock):
    marks(i);q=read(r/'registration.json');need(sha(r/'registration.json')==NEW and q['original_handoff']==ORIGINAL,'unregistered authority')
    for h in q['pins'].values():need(re.fullmatch('[0-9a-f]{64}',h) and sha(r/'pins'/h)==h,'changed registered capacity evidence')
    d=read(r/'noreturn.json');need(sha(r/'noreturn.json')==STOP and d['outer']=={'session':12889,'chunk':'5f7524','exit':1} and d['close_exit']==1 and not d['physical_record_exists'] and not d['new_private_clone_exists'] and d['scored_rows']==0 and d['original_stock_sha256']==STOCK and d['previous_sha256']==STORAGE and d['previous_outer']==previous['outer'] and d['free_followup']['root']<d['registered_floor_bytes']==122*(1<<30),'wrong capacity no-start')
    original_anchor=read(r/'stock-first-anchor.json');observed_anchor=read(r/'material-stock/first-anchor.json')
    need(sha(r/'stock-first-anchor.json')==d['retained_first_anchor_sha256'] and observed_anchor==original_anchor and read(r.parent/'actual/first-return.json')['original_owned_copy_retired']==original_anchor['copy'],'original failed copy did not match its prior forensic seal')
    return material(r,q,previous,stock)

def material(r,authority,previous,stock):
    E=r/'material';i=read(E/'intake.json');w=read(E/'worker-return.json');o=read(E/'outer-return.json')
    e=read(r/'exdev-reg.json');t=read(E/'result.json');j=read(E/'journal/before.json');four=read(E/'returned-four-locks.json');a=t['disposition'];locks=e['four_locks']
    need(sha(r/'exdev-reg.json')=='2aa00024af7883db367dd8f34b2299bc21d574896c9abdf6ca7ba328b6e64d85' and i['registration']==t['registration']==sha(r/'exdev-reg.json') and e['no_start']==i['capacity_rejected']==STOP and e['predecessor']==STORAGE and not e['benchmarks_authorized'],'wrong registered EXDEV source or zero-credit scope')
    need(i['outer']==previous['outer'] and i['previous_sha256']==STORAGE and i['boot']==o['boot']==four['boot']==previous['boot'] and i['locks']==w['locks']==o['locks']==previous['locks'] and len(locks)==4 and set(i['locks'])<=set(locks) and i['all_four_locks']==w['all_four_locks']==four['locks']==locks and four['all_four_locks_reacquired'] is True,'wrong boot/predecessor or storage lock ownership')
    need(o['outer']==four['outer'] and type(o['outer']['session'])==int and o['outer']['session']>0 and re.fullmatch('[0-9a-f]{6}',o['outer']['chunk']) and o['outer']['exit']==o['worker_code']==w['worker_exit']==w['code']==0 and o['host_released'] is True and not (o['foreign'] or o['remaining_workers'] or w['native_at_return']) and i['start_ns']<w['end_ns']<=four['time_ns'] and
         o['intake_sha256']==sha(E/'intake.json') and o['worker_sha256']==four['worker_sha256']==sha(E/'worker-return.json') and w['result_sha256']==sha(E/'result.json') and a['journal_sha256']==sha(E/'journal/before.json'),'missing positive authenticated storage outcome')
    need(i['proof_sha256']==t['proof_sha256']==sha(r/'exdev-primary.json') and i['second_proof_sha256']==t['second_proof_sha256']==sha(r/'exdev-secondary.json') and
         e['selection']==sha(r/'exdev-selection.json') and e['first_proof']==sha(r/'exdev-primary.json') and read(r/'exdev-secondary.json')['selection_sha256']==sha(r/'exdev-selection-2.json') and
         t['all_remaining_relative_names_unmodified_by_this_operator'] and not t['benchmark_authorized'] and a['source_names_unchanged'] and a['write_leases_closed'] and a['retired']==j['selected'] and j['reader']==a['reader_control'],'unbound original inputs or storage disposition')
    eligible={}
    for reports,selection in [('exdev-primary.json','exdev-selection.json'),('exdev-secondary.json','exdev-selection-2.json')]:
        v=read(r/reports);z=read(r/selection);by={row['rel']:row for row in z['selected']};checked=v['result']
        need(v['capacity_no_start']==STOP and v['incoming']==STORAGE and v['boot']==i['boot'] and v['retired_bytes']==0 and not v['native_grant'] and checked['byte_compared'] and checked['raw_reads_per_accepted_file']==2,'wrong preflight proof or timing scope')
        for row in checked['accepted']:
            n=row['rel'];origin=by[n];need(n not in eligible and row['sha256']==origin['original'][8] and row['private_bytes']==origin['victim']['blocks'],'ambiguous or unbound source copy');eligible[n]=row
    used=j['selected'];need(len(set(used))==len(used)==j['independent_source_leases']==j['victim_leases'] and all(n in eligible for n in used) and j['donors']=={n:eligible[n]['sha256'] for n in used} and sum(eligible[n]['private_bytes'] for n in used)==a['proven_private_bytes']==j['confirmed_private_bytes']>=3<<30,'source/copy identities, private blocks or exact number of leases differs')
    need(stock['previous_sha256']==sha(E/'outer-return.json') and stock['outer']==o['outer'] and stock['boot']==o['boot'] and stock['start_ns']>=w['end_ns'] and stock['original_failed']==STOCK,'stock diagnostic did not follow this EXDEV endpoint')
    return o,sha(E/'outer-return.json'),stock_registration(r,stock,authority)


def stock_registration(r,stock,authority):
    q=read(r/'stock-bridge.json');digest=sha(r/'stock-bridge.json')
    need(digest=='a06429d20a4a6462bf48243bc2794eede0de6c608b1b7fc7f160439fb5812685' and digest in authority['pins'].values() and sha(r/'exdev-reg.json') in authority['pins'].values() and q['capacity_no_start']==STOP and q['allowed_positive']==stock['previous'] and q['first_stock_registration']=='05f30ab758d4305bc3729a8f4d5867d87923350c25d8d0bba2a475e35465d0f5' and q['zero_quantitative_claims'],'different subsequent stock source, prior, or disposition scope')
    return q['first_stock_registration']
