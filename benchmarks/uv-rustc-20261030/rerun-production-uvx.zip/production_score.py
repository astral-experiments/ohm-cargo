"""Independently reconstitute the scored production observations and their separate 13-way decision."""
import argparse,copy,hashlib,importlib.util,json,re,sys
from functools import lru_cache
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from common import need,sha
from rerun import read
BASE=HERE/'production-original'
NATIVE=BASE/'guard-file-free-math-asm/production-uvx-bins'
SCIENCE='c78a32dadca41d03150602c14bb4c6fba7f1a07d03ee70e2f64d0aab06500247'
NAME='CZD/uvx-production-bins';ARMS=('C','CZD')
def original(n):return NATIVE/n
def source_path(n):return BASE/'uvx-binary-edit'/n
def module(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
@lru_cache
def engine():
    reg=original('registration.json');need(sha(reg)=='56a3208b66bd9f47c37a64356c1eb6e4bd296955ab9685077ff5f00bf3c29518','unknown native registration')
    registration=read(reg)
    for n in ('replay.py','inputs.py','command.py','run.py'):need(sha(original(n))==registration['sources'][n],'changed native source')
    score=BASE/'guard-file-free-math-asm/fresh-edit-trial/score.py';need(sha(score)=='376a2dfb658cd1f087e1d96f46ea370077d37cc02fa51b135e8223d0c5e879f5','changed fixed paired scorer')
    return module('original_production_science',original('replay.py'))
@lru_cache
def behavior():return module('original_production_argv_oracle',source_path('behavior.py'))
def validate_behavior(cases):
    need(cases==read(source_path('behavior-control.json'))['observed']['cases'],'unexpected argv bytes, exit, stderr or missing sibling diagnostic')
def plan():
    need(sha(original('protocol.json'))==SCIENCE,'different production protocol')
    p=read(original('protocol.json'))
    for n in ('A.rs','B.rs','behavior.py','behavior-control.json','upstream-commit.json','edit.json'):
        need(sha(source_path(n))==p['inputs']['uvx-binary-edit/'+n],'changed source or tested behavior')
    for arm in ARMS:need(p['subjects'][arm]['file_count']==65,'wrong driver binding')
    need(len(p['pairs'])==len(p['primers'])==12 and p['group']==NAME and p['argv']==['cargo','build','--locked','--offline','-j8','-p','uv','--bins'],'wrong native study')
    return p
def public_argv(row,cmd):
    need(row['argv']==cmd,'substituted Cargo command')
def local_replay(root,reread_bins=True):
    root=Path(root);p=copy.deepcopy(plan());inputs=read(root/'production-intake.json');schema=read(root/'sdk-manifests.json')
    need(inputs['protocol_sha256']==SCIENCE and inputs['sdk_manifests_sha256']==sha(root/'sdk-manifests.json') and inputs['source_identity_sha256']==sha(root/'source-identity.json'),'unknown private source or SDK')
    old=read(root/'inputs.json');sub=old['subject_provenance'];need(set(schema)==set(ARMS),'different SDK arm set')
    left,right=(schema[a] for a in ARMS);different=[n for n in left if left[n]!=right.get(n)]
    need(set(left)==set(right) and len(different)==1 and re.fullmatch('lib/librustc_driver[^/]*\\.so',different[0]),'not a driver-only SDK pair')
    for arm in ARMS:
        need(sub[arm]['tree']==p['subjects'][arm]['source'] and sub[arm]['driver_sha256']==schema[arm][different[0]]['sha256'],'wrong SDK/tree')
        if sub.get('provenance')!='independent-source-build':
            need(sub==read(HERE/'subjects.json') and len(schema[arm])==65,'unknown official compiler')
        need({n:v['sha256'] for n,v in schema[arm].items() if n!=different[0]}==sub['common_members'],'source declaration disagrees with complete common SDK map')
        p['subjects'][arm]['driver_sha256']=sub[arm]['driver_sha256']
    cmd=inputs['absolute_argv'];need(cmd[1:]==p['argv'][1:] and cmd[0].endswith('/visible/sdk/bin/cargo'),'not the registered native command')
    p['archives']=read(root/'locally-reconstructed-checkpoints.json')
    for arm in ARMS:
        a=p['archives'][arm];warm=root/'warm'/arm
        need(a==read(warm/'seed.json') and a['ledger_sha256']==sha(warm/'manifest.jsonl.gz'),'unknown seed')
        for k in ('cold','repeat','lastA'):
            r=read(warm/k/'command.json');need(r['traced']==(k!='repeat') and r['argv']==cmd[:-1] and r['phase']=='A' and r['driver_sha256']==sub[arm]['driver_sha256'] and r['exit']==0 and not r['observer_faults'],'incorrect pre-existing A history')
        need(read(warm/'repeat/products.json')==read(warm/'lastA/products.json'),'ordinary A and traced A differ')
    doc=engine().study(root/'production-physical',p)
    seen={}
    for phase,prod in doc['public_programs'].items():
        validate_behavior(prod['argv_and_exit'])
        for n,pr in prod['programs'].items():
            file=root/'objects'/pr['sha256']
            if reread_bins and pr['sha256'] not in seen:
                need(file.is_file() and file.stat().st_size==pr['bytes'] and sha(file)==pr['sha256'],'changed retained public bytes')
            seen[pr['sha256']]=pr['bytes']
    count=doc['counted_pairs']
    for subfolder in ['admission','pilot',*(f'pair-{i:02d}' for i in range(count))]:
        for arm in ARMS:
            for phase in ('A','B'):
                d=root/'production-physical'/subfolder/arm/phase;r=read(d/'command.json');public_argv(r,cmd)
                if subfolder=='admission' and phase=='B':verify_trace(d,r,doc['public_programs']['B'])
    return doc
def verify_trace(d,row,products):
    from full_stack_trace import args_from
    from production_trace import real_rust
    c=read(d/'census.json');traces={p.name:sha(p) for p in d.glob('exec.*')};need(c['trace_sha256']==traces and traces,'different retained genuine strace')
    top=[];jobs=[];links=[]
    for path in sorted(d.glob('exec.*')):
        pid=int(path.suffix[1:])
        for line in path.read_text().splitlines():
            event=args_from(line.strip())
            if event is None:continue
            exe,args=event
            if args==row['argv'] and exe==args[0]:top.append(pid)
            if Path(exe).name=='rustc' and real_rust(args):jobs.append([pid,exe,args])
            if '/wild-ld/' in exe:links.append([pid,exe,args])
    need(len(top)==1 and jobs==[[a[k] for k in ('pid','exe','argv')] for a in c['actual']] and links==[[a[k] for k in ('pid','exe','argv')] for a in c['raw_wild']],'unrestored complete native argv')
    s=plan()['source']['source_path'];own=[a for a in c['actual'] if s in a['argv']]
    need(len(own)==1 and '-Zohm-check-relink-inputs' in own[0]['argv'] and '--test' not in own[0]['argv'] and str(own[0]['pid']) in read(d/'raw-mapped-drivers.json') and
         any('-o' in a and a[a.index('-o')+1].endswith('/'+products['producer']['uvx']) for _,_,a in links),'wrong mapped binary or real link')
def prior_family(packet,outer,tmp):
    p=plan();names=p['family']['ordered_labels'][:-1];permanent=p['family']['permanently_excluded']
    if packet is None:
        need(outer is None,'missing supplied earlier packet')
        return {'twelve':{n:{'raw_p':1.,'adjusted_p':1.,'complete':False,'confirmed':False,'excluded':n in permanent} for n in names}},'unprovided outcomes assigned p=1'
    need(outer and re.fullmatch('[0-9a-f]{64}',outer),'supply the independently trusted previous outer SHA')
    cert=module('previous_twelve_with_custody',HERE/'production_previous.py').run(packet,outer,tmp)
    need(cert['eligible'] and set(cert['holm12'])==set(names),'preceding native family is not authenticated')
    return {'twelve':cert['holm12']},outer
def main():
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('run',type=Path);cli.add_argument('--previous-packet',type=Path)
    cli.add_argument('--previous-outer');cli.add_argument('--scratch',type=Path);args=cli.parse_args()
    root=args.run;need(not (root/'failed.json').exists() and (root/'complete.json').is_file(),'failed or unclosed scope; zero credited pairs')
    doc=local_replay(root);closed=read(root/'complete.json')
    need(closed['study']==NAME and closed['counted_pairs']==doc['counted_pairs'] and closed['pilot_passed']==doc['excluded_pilot']['continues'],'different terminal')
    previous,evidence=prior_family(args.previous_packet,args.previous_outer,args.scratch)
    print(json.dumps({'scope':NAME,'previous':evidence,'outcome':doc,'thirteen':engine().holm13(previous,doc,plan())},sort_keys=True,indent=2))
if __name__=='__main__':main()
