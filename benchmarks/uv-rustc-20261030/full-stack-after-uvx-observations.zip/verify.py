#!/usr/bin/env python3
"""Verify a closed #14 native packet and recompute all eligible observations."""
import argparse
import ast
from contextlib import contextmanager
import hashlib
import io
import json
from pathlib import Path
import random
import re
import types
from unittest.mock import patch
from zipfile import ZipFile

LABEL = 'P-to-CZD/package-test-capacity'
PRIOR_LABEL = 'P-to-CZD/package-test'
REG = 'ffea2a95ec890dbdbfdaa6c90f6a672ba44f2023c9dc9e52ccabdc64d8ac423d'
SCI = '1328f629afc4776b8fc3a55cd2c590e40f90f5cf4eddbdb0c241cddf23d62621'
PUB = 'bac6e783130f95c0ac78b3255f468a0fddbcc4fb'
PACK_REG = '93470c447c9fdb969a3f033eda2839be7f4587643d8ce6b96ef9ea9759cc5f0f'
OLD_READER = '9f434e212f29543bd45558b355ae7ecf59e473c8ca7f3f386dc6c933b1f9c787'
MATH = '69b79786258098636ed8444d8b9c693ae1de1d890024742b6d5dc8cf9b8e1d7b'
H12 = '463d220c5529aa264083970ce619a4c7be3d28f93404ee9e6b922b9354a447ce'
H13 = 'e5a71756f357aa1d2ed49690abd935a09e7ac899cf1718f5b4d02604b9cebc26'
H13F = '90f7db50244a870e8adc9f939a481714de769eec38b35424f804bad6c5bf87e9'
Z12 = '2ab8f5e107026f964fb724312e1e12ec14d3b04b494dc8bd33dcaef57e130b1c'
Z13 = 'bcffde0aed9a5d35b4f16b141bc965fb83f0671bd5d59ad039d518127168ab5f'
EXTRA = {'older-reader.py':OLD_READER, 'fourteen/registration.json':REG, 'fourteen/protocol.json':SCI,
         'fourteen/run.py':'b60e1f1b44a48e46afc90e67f634b6e8f3e3705ed1832b74afad04f3df7629e8',
         'fourteen/replay.py':'6f61f611c9729b429fed9f11a5cea4632b46d82fee86a4398ce17d8e071da7e0',
         'fourteen/controls.py':'dcdac82e61ff4950490beb49967de638edba501c436ffec9ee376076911b8bc3',
         'fourteen/controls.json':'800c14685c2c425913b21ca295106a3768fa9e7dfb0c258d1c442345862a40de',
         'fourteen/PROTOCOL.md':'f92a91ea5b786167b4ca1c82a9e8cd99907779f3e84c4ae72aeb6a9501f58958',
         'fourteen/published.json':'e8740aebf8ff7164e0a86427c6a3d2a64a82fbc3adcbe205e53525ef26beb887',
         'material/registration.json':PACK_REG, 'material/material.py':'87bf9fea2cdaa4e5527484670cf98b25ed58ad4e21c1e6b7dec9c0fd3f9f26c0',
         'material/park_inputs.py':'3db657b6df08f95388cb68a11b1f97f9a2ae2416b8273a672c98c0c28fe5966e','production-math.py':MATH}
FAILED_PACK = '1fa4204da40254ae2004de2d9f5f8bb05c8e25d30ee67014ee60515c3d4ab190'
RESUMED = 'a93d97e0627492259ae098e893692b85e1772b5f7af523776e1fadfffa3a747a'
HOST = 'd968853b72eae72d37e64ef8a1139e6792e917bdabb0ac81a43c97269695b633'
EXTRA.update({'material-resume/registration.json':RESUMED,
              'material-resume/material.py':'82dd246ef32c0faab28038284a04ad897cc47bb806840d19b4ac88c81fe8da6a',
              'material-resume/relief.py':'f292000c1f907a696ba18b85fb65526f6228c17f19bb91e7f62d4651b412e521',
              'material-resume/recover-files.py':'86bda7e5f716d5cf5a68560b08ed931e0546e762e9a6b5cbac29051b12b3c1b2',
              'host-correction/registration.json':HOST,
              'host-correction/run.py':'ad0fe367f90fb86b718cdd42e83475fa79b6da2c0f4d852fd9ffadd0a7fd0a06',
              'host-correction/controls.json':'4630881266c6208192cb236e2fcd52367793c8c3c41616fc68e0c4c0fb191304'})
CLOSED_MATERIAL = ('43223cf2f8b0903e144ed1eb7df31edda0daa710e51687d305b864a3ee5bb565','267a7436c424763213335a4e30f7122512b1f0fcb2e51023cc7d3bd0f214ec8a')
GIB = 1 << 30
def need(ok,msg):
    if not ok: raise ValueError(msg)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def canonical(x):return digest(json.dumps(x,sort_keys=True,separators=(',',':')).encode())
def trip(session,chunk,code):return {'session':session,'chunk':chunk,'exit':code}
def engine(packet):
    # The only loaded bootstrap code is the exact previously released reader.
    with ZipFile(packet) as z:
        name='objects/'+OLD_READER
        need(z.getinfo(name).file_size<128<<10,'oversize original result reader')
        raw=z.read(name)
    need(digest(raw)==OLD_READER,'unrecognized original result reader')
    mod=types.ModuleType('pinned_original_package_reader');mod.__file__=str(Path(__file__).resolve())
    exec(compile(raw,'original-package-verifier','exec'),mod.__dict__)
    return mod

def nested(z,files,name):
    h=files[name];member=z.getinfo('objects/'+h)
    need(member.file_size<=20<<20 and re.fullmatch('[0-9a-f]{64}',h),'oversize historical record')
    b=z.read(member);need(digest(b)==h,'historical record differs')
    return json.loads(b)

def previous(root):
    """Decode the actual #12 P-only return and the independent returned #13."""
    prev=root/'previous';f12=prev/'control-attempt.zip';f13=prev/'production-result.zip'
    need(sha(f12)==Z12 and sha(f13)==Z13 and sha(prev/'production-family.json')==H13F,'unrecognized earlier result')
    family=read(prev/'production-family.json')
    with ZipFile(f12) as z:
        files=json.loads(z.read('layout.json'))['files']
        o12=nested(z,files,'physical/outer-return.json');w12=nested(z,files,'physical/worker-return.json')
        cp=nested(z,files,'physical/warm-P/checkpoint.json')
        ref=nested(z,files,'physical/warm-P/ordinary-repeat-A/p-only-classes.json')
        warm={k.removeprefix('physical/warm-P/'):h for k,h in files.items() if k.startswith('physical/warm-P/')}
        need(files['physical/outer-return.json']==H12 and o12['outer']==trip(48597,'5e7240',1) and o12['host_released'] and
             o12['worker_sha256']==files['physical/worker-return.json'] and w12['code']==w12['worker_exit']==1 and w12['success'] is None and
             not any('/B/command.json' in k or k.startswith('physical/warm-CZD/') or k in ('physical/series.json','physical/analysis.json') for k in files) and
             len(warm)==5337 and len(ref['roles'])==17 and ref['independent_arm']=='P' and ref['phase']=='A','earlier attempt is not the exact completed P-only A')
    with ZipFile(f13) as z:
        files=json.loads(z.read('layout.json'))['files']
        o=nested(z,files,'physical/outer-return.json');w=nested(z,files,'physical/worker-return.json')
        intro=nested(z,files,'physical/intake.json');s=nested(z,files,'physical/successful.json')
        banks=nested(z,files,'physical/resources-returned.json')['originals']
        need(files['physical/outer-return.json']==H13 and o['outer']==trip(36405,'f68c80',0) and
             o['worker_sha256']==files['physical/worker-return.json'] and o['intake_sha256']==files['physical/intake.json'] and
             w['code']==w['worker_exit']==0 and s['analysis_sha256']==files['physical/analysis.json'] and
             family==nested(z,files,'family.json') and family['outcome']==nested(z,files,'physical/analysis.json') and
             family['own_outer_sha256']==H13 and family['native_outer']==o['outer'] and not family['pooled'] and
             family['outcome']['counted_pairs']==12,'earlier production score or physical return differs')
    old=family['original_twelve']['excluded_full_package']
    need(old['outer_sha256']==H12 and old['P_only_A_sha256']==warm['ordinary-repeat-A/p-only-classes.json'] and
         old['P_checkpoint']==cp and old['eligible_p']==1 and old['scored_pairs']==old['B_observations']==old['CZD_cargo_A']==0 and
         family['thirteen'][PRIOR_LABEL]['raw_p']==1 and not family['thirteen'][PRIOR_LABEL]['complete'] and
         len(intro['retained_full_P']['program_identities'])==17,'source and prior family disagree')
    return {'family':family,'outer':o,'warm':warm,'evidence':old,'owner':intro['retained_full_P'],'banks':banks}

def lease(raw,h,reg):
    o=read(raw/'outer-return.json');i=read(raw/'intake.json');w=read(raw/'worker-return.json');t=o['outer']
    need(re.fullmatch('[0-9a-f]{64}',h) and sha(raw/'outer-return.json')==h and
         o['worker_sha256']==sha(raw/'worker-return.json') and o['intake_sha256']==sha(raw/'intake.json'),'detached outer or worker differs')
    need(set(t)=={'session','chunk','exit'} and type(t['session'])==int and t['session']>0 and re.fullmatch('[0-9a-f]{6}',t['chunk']) and
         type(t['exit'])==int and t['exit']==o['worker_code']==w['code']==w['worker_exit'] and
         o['host_released'] is True and o['foreign']==o['remaining_workers']==w['owned_children_at_return']==[] and
         i['boot']==o['boot'] and i['locks']==o['locks']==w['locks'] and len(set(o['locks']))==2 and
         i['registration']==reg and i['start_ns']<w['end_ns'],'unreturned host, different scope or inconsistent actual process')
    return o,i,w

def transition(intro,prior,h,suffix):
    need(intro['previous'].endswith('/'+suffix+'/outer-return.json') and intro['previous_sha256']==h and
         intro['outer']==prior['outer'] and intro['boot']==prior['boot'] and prior['host_released'] and prior['outer']['exit']==0,
         'not the genuine immediate predecessor')

def four(raw,h,reg):
    o,i,w=lease(raw,h,reg);held=read(raw/'four-return.json')
    need(w['native_permission'] is False and held['locks']==i['all_four_locks'] and len(set(held['locks']))==4 and
         set(i['locks']).issubset(held['locks']) and held['reacquired'] and held['prior_worker_retired'] and held['foreign']==[] and
         read(raw/'close-binding.json')=={'outer_sha256':h,'four_return_sha256':sha(raw/'four-return.json'),'triplet':o['outer']},
         'incomplete four-lock material receipt')
    return o,i,w

def failed_pack(raw,prior):
    o,i,w=four(raw,FAILED_PACK,PACK_REG)
    transition(i,prior['outer'],H13,'production-uvx-bins/physical')
    need(o['outer']==trip(54596,'3ff10d',1) and w['result_sha256'] is None and not (raw/'result.json').exists() and
         (raw/'failure.log').read_text().rstrip().endswith('ValueError: insufficient real per-device/anonymous-memory floor verified backup'),
         'earlier pack did not actually stop before parking')
    return o,i,w

def material(root,prior,after):
    before=root/'owner/failed-pack';pack=root/'owner/physical-pack';park=root/'owner/physical-park'
    failed,fi,fw=failed_pack(before,prior)
    ph=sha(pack/'outer-return.json');qh=sha(park/'outer-return.json')
    need((ph,qh)==CLOSED_MATERIAL,'unexpected recovered physical material returns')
    po,pi,pw=four(pack,ph,RESUMED);qo,qi,qw=four(park,qh,RESUMED)
    for folder,outer,worker in ((pack,po,pw),(park,qo,qw)):
        need(outer['outer']['exit']==0 and worker['result_sha256']==sha(folder/'result.json'),'recovery failed or material result changed')
    need(pi['previous'].endswith('/package-test-full-stack/tmpfs-price/physical-pack/outer-return.json') and
         pi['previous_sha256']==FAILED_PACK and pi['outer']==failed['outer'] and pi['boot']==failed['boot'] and
         fw['end_ns']<=pi['start_ns'],'wrong actual negative-to-positive repair')
    transition(qi,po,ph,'package-test-full-stack/tmpfs-price/after-pack-floor/physical-pack')
    transition(after,qo,qh,'package-test-full-stack/tmpfs-price/after-pack-floor/physical-park')
    need(pw['end_ns']<=qi['start_ns'] and qw['end_ns']<=after['start_ns'],'overlapping native intervals')
    reg=read(root/'sources/material/registration.json');repair=read(root/'sources/material-resume/registration.json')
    hreg=read(root/'sources/host-correction/registration.json');manifest=read(before/'transport.json')
    need(repair['original_registration']==PACK_REG and repair['negative']==FAILED_PACK and hreg['original']==REG and
         hreg['resumed_material_registration_sha256']==RESUMED and hreg['excluded_material_outer_sha256']==FAILED_PACK,
         'wrong sealed repair chain')
    packed=read(pack/'result.json');parked=read(park/'result.json')
    need(packed['original_failed_pack']==FAILED_PACK and packed['verified_twice'] and packed['source_unchanged'] and
         packed['tmpfs_material_bytes_released']==0 and not packed['native_permission'] and
         packed['manifest']==parked['manifest']==sha(before/'transport.json') and manifest['standalone'] and
         packed['original_witnesses']=={'full_reconstruction_sha256':sha(before/'first.json'),'direct_original_cmp_sha256':sha(before/'second.json'),'manifest':sha(before/'transport.json')} and
         packed['fresh_reconstruction_sha256']==sha(pack/'fresh-source-reconstruction.json') and packed['fresh_reconstruction']==read(pack/'fresh-source-reconstruction.json') and
         packed['external_parts']==manifest['parts'] and manifest['format']==1 and
         {k:v['sha256'] for k,v in manifest['originals'].items()}==reg['hashes'] and
         {k:v['identity'] for k,v in manifest['originals'].items()}==packed['source'] and
         {k:v['path'] for k,v in manifest['originals'].items()}==reg['paths'] and
         reg['hashes']['P']==prior['evidence']['P_checkpoint']['sha256'],'different protected or reconstructed input')
    order=manifest['order'];lengths=manifest['raw_lengths'];stored=manifest['stored'];parts=manifest['parts']
    used=set().union(*[set(row) for row in order.values()])
    need(set(order)=={'C','CZD'} and manifest['number_of_anchor_chunks']==0 and used==set(stored)==set(lengths) and len(parts)==2 and
         all(re.fullmatch('[0-9a-f]{64}',h) and type(lengths[h])==int and lengths[h]>0 for h in used) and
         all(0<=part<2 and start>=0 and count>0 and start+count<=parts[part]['bytes'] for part,start,count in stored.values()) and
         all(sum(lengths[h] for h in row)==manifest['tar_length'][k] for k,row in order.items()),
         'incomplete reconstruction map or out-of-bounds compressed chunk')
    rr=packed['root_relief'];end=packed['end']
    need(end['root']>reg['reserves'][0]+128*(1<<20) and end['scratch']>reg['reserves'][1] and
         packed['post_restore']['restore_intake_rechecks_6GiB_floor_plus_64MiB_and_actual_missing_allocation'] and
         packed['post_restore']['conditional_tmpfs_after_archive_return_if_fresh_CZD_archive_also_survives']>6*GIB+64*(1<<20),'registered resource floor missing')
    if rr['skipped_because_already_above']:
        need(rr['selected']==[] and rr['blocks']==0,'unnecessary archival intervention')
    else:
        m=read(pack/'restoration-manifest.json');j=read(pack/'journal/before.json');d=rr['root_proof']
        need(rr['restore_manifest']==sha(pack/'restoration-manifest.json') and rr['minimum_proven_bytes']==rr['blocks']==d['proven_private_bytes']==j['confirmed_private_bytes']<=320*(1<<20) and
             d['retired']==j['selected']==rr['selected']==[x['rel'] for x in m['selected']] and len(set(rr['selected']))==len(rr['selected']) and
             d['journal_sha256']==sha(pack/'journal/before.json') and d['source_names_unchanged'] and d['write_leases_closed'] and
             rr['end_root']>rr['target'],'unproven prior archive relief')
    source=packed['source'];a=read(before/'first.json');b=read(before/'second.json')
    need(set(a)==set(b)==set(parked['parked'])=={'C','CZD'} and packed['protected']==parked['protected'] and
         packed['protected']['P']==prior['owner'] and packed['protected']['bins']==prior['banks'] and
         parked['source_inodes_preserved'] and parked['restore_required'] and parked['journal']==sha(park/'journal.json'),
         'unreported mutation or wrong materials')
    need(source['P'][:6]==prior['owner']['archive_identity'] and parked['first_unchanged_scientific_return']==H12 and
         parked['verified_original_bytes']==reg['hashes'] and parked['raw_original_allocation']==reg['release_bytes']==3777794048 and
         parked['net_effective_tmpfs_bytes']==parked['ending']['shm']-parked['opening']['shm']>=3*GIB,
         'different resource outcome or lost protected control')
    for arm in ('C','CZD'):
        s=source[arm];parkrec=read(park/(arm+'-parked.json'));intent=read(park/(arm+'-intent.json'))
        need(all(packed['fresh_reconstruction'][arm][key]==a[arm][key] for key in ('bytes','sha256')) and a[arm]['sha256']==b[arm]['sha256']==reg['hashes'][arm] and a[arm]['bytes']==b[arm]['bytes']==s[2] and
             'sha256' in a[arm]['method'].lower() and 'GNU cmp' in b[arm]['method'] and
             intent['source']==s and intent['durable_manifest']==packed['manifest'] and
             parkrec==parked['parked'][arm] and parkrec['prior']==s and parkrec['released_bytes']==s[5] and
             parkrec['same_inode'][:2]==s[:2] and parkrec['same_inode'][2]==parkrec['same_inode'][5]==0,'lost full-byte proof or original inode for '+arm)
    return {'original_pack_failure':failed['outer'],'original_pack_failure_sha256':FAILED_PACK,'optional_duplicate_bytes_released':rr['blocks'],'pack_outer_sha256':ph,'pack_outer':po['outer'],'park_outer_sha256':qh,'park_outer':qo['outer'],
            'original_control_sha256':reg['hashes']['P'],'verified_old_archives':reg['hashes'],'temporary_bytes_released':parked['net_effective_tmpfs_bytes'],
            'original_inodes_retained':True,'full_local_transport_payloads_in_packet':False}

def plan(src):
    doc=read(src/'fourteen/protocol.json');old=read(src/'package-test-full-stack/protocol.json')
    orders=[['P','CZD'] for _ in range(6)]+[['CZD','P'] for _ in range(6)]
    random.Random(doc['order_seed']).shuffle(orders)
    need(sha(src/'fourteen/protocol.json')==SCI and doc['base_study_sha256']==sha(src/'package-test-full-stack/protocol.json') and
         all(doc[k]==old[k] for k in ('ordinary_argv','uv','subjects','expected_reported_test_roles')) and
         doc['pairs']==orders!=old['pairs'] and not doc['efficacy_pilot'] and
         len(set(doc['family']['ordered_labels']))==14 and doc['family']['ordered_labels'][-1]==LABEL,'changed registered schedule, subjects or endpoint')
    return {**old,**doc}

def rank(src,doc,prev,result):
    # Evaluate exactly the dependency-free function used by the effective native scorer.
    p=src/'production-math.py';need(sha(p)==MATH,'unregistered statistical code')
    fs=[n for n in ast.parse(p.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='holm13']
    need(len(fs)==1,'absent original adjustment');scope={'x':types.SimpleNamespace(need=need)}
    exec(compile(ast.Module(body=fs,type_ignores=[]),str(p),'exec'),scope)
    before=prev['thirteen'];need(set(before)==set(doc['family']['ordered_labels'][:-1]) and
        before[PRIOR_LABEL]['excluded'] and before[PRIOR_LABEL]['raw_p']==1 and not before[PRIOR_LABEL]['complete'] and
        not prev['pooled'] and (result is None or result['counted_pairs']==12),'incompatible earlier family or partial new rows')
    return scope['holm13']({'twelve':before},{'score':result['score'] if result else None},{'group':LABEL,'family':doc['family']})

def adoption(raw,prior):
    old=prior['evidence'];adopted=read(raw/'adopted-P.json');cp=read(raw/'warm-P/checkpoint.json')
    names={str(f.relative_to(raw/'warm-P')):sha(f) for f in (raw/'warm-P').rglob('*') if f.is_file()}
    need(names==prior['warm'] and adopted['verbatim_evidence_manifest']==canonical(names) and
         adopted['P_A_reference_sha256']==old['P_only_A_sha256'] and adopted['archive_sha256']==old['P_checkpoint']['sha256'] and
         adopted['excluded_outer_sha256']==H12 and adopted['original_owner']==prior['owner'] and old['P_checkpoint']==cp and
         adopted['source_warm'].endswith('/package-test-full-stack/physical/warm-P') and
         adopted['independently_copied_programs']==17 and adopted['new_or_old_B_rows_reused']==0,'unverified or nonidentical P adoption')
    return adopted

@contextmanager
def observation_reader(v,doc):
    original=v.readers
    def updated(src):
        tools,e,sc=original(src)
        e.plan=lambda:doc
        sc.SCIENCE=SCI
        return tools,e,sc
    with patch.object(v,'readers',updated):
        yield

def actual_native(v,raw,src):
    inputs=read(raw/'subjects.json')['subjects'];native=raw/'native';confirmed=read(native/'verified.json')
    need(read(native/'subjects.json')=={'subjects':{'parent':inputs['P'],'candidate':inputs['CZD']},'registered':REG} and
         confirmed['timed'] is False and confirmed['code']==0 and confirmed['subjects_sha256']==sha(native/'subjects.json') and
         read(raw/'retired.json')['native_controls_sha256']==sha(native/'verified.json'),'unbound native or compiler check')
    reader=v.module(src/'trace-reader.py','native_fourteen_exec_decoder');out={}
    # Real executed programs print one LF. Old detached verifier expected the two literal
    # characters backslash and n in this one readback; native gates and scores use the raw bytes.
    outputs=['273\n','285\n','541\n','529\n']
    for leg,arm in [('parent','P'),('candidate','CZD')]:
        p=native/leg/'cargo-native/evidence/rows.json';rows=read(p)
        need([r['exit']==0 for r in rows]==[True,True,True,False,False,False,True] and
             [r['printed'] for r in rows if r['exit']==0]==outputs and confirmed['results'][leg]['normal_cargo_sha256']==sha(p),
             'changed, missing, malformed or normal native assembly control failed')
        out[arm]=v.actual_trace(raw/('admission-'+arm)/'B',reader)
    return out

def capacity(raw,cp,c):
    price=read(raw/'complete-price.json');safe=price['safe_current'];programs=read(raw/'warm-P/verify-repeat-A/all-products.json')
    extra=max(2*GIB,2*sum(x['bytes'] for x in programs.values())+(512<<20));hi=max(cp['actual_slot_allocated'],c['actual_slot_allocated'])
    need(price['root_scratch_floor']==122*GIB and price['ram_floor']==20*GIB and price['shm_floor']==6*GIB and price['all_tmpfs_max']==26*GIB and
         price['actual']=={k:{'full':v['actual_slot_allocated'],'compressed':v['allocated']} for k,v in [('P',cp),('CZD',c)]} and
         price['transient_link_allowance']==extra and price['already_charged_products']['unique_allocated_bytes']>0 and
         safe['root']>122*GIB+(768<<20) and safe['scratch']>122*GIB+(128<<20) and safe['ram']>20*GIB+hi+extra and
         safe['shm']>6*GIB+hi+extra and safe['shm']==min(safe['shm_actual_free'],32*GIB-safe['shm_total_used']),
         'measured active-bank price, RAM disk or ext4 floors disagree')
    return price

def decode_result(v,root,expected,scratch,cas,prior,route):
    raw=root/'physical';src=root/'sources';doc=plan(src)
    o,i,w=lease(raw,expected,REG);old=prior['evidence']
    scientific={'excluded_full_stack_outer_sha256':H12,'excluded_full_stack_p':1,'returned_uvx_outer_sha256':H13,
                'returned_uvx_family_sha256':H13F,'published_protocol_commit':PUB,'published_protocol_sha256':SCI,
                'material_registration_sha256':PACK_REG,'restored_P_checkpoint_sha256':old['P_checkpoint']['sha256'],
                'P_only_A_reference_sha256':old['P_only_A_sha256'],'effective_material_registration_sha256':RESUMED,
                'material_original_failed_outer_sha256':FAILED_PACK,'material_handoff_registration_sha256':HOST}
    need(i['phase']=='package-test' and i['primary']==scientific,'wrong science or control authority')
    base={'outer':o['outer'],'outer_sha256':expected,'material_handoff':route,'earlier_thirteen_outer_sha256':H13,
          'earlier_failed_full_stack_outer_sha256':H12,'original_failed_contrast_p':1,'pooled':False}
    if o['outer']['exit']!=0:
        need(w['success'] is None and not (root/'owner/family.json').exists(),'stopped worker carries a positive claim')
        return {**base,'eligible':False,'counted_pairs':0,'raw_P_CZD_ns':[],'score':None,'family_p':1,
                'holm14':rank(src,doc,prior['family'],None),'raw_completed_B_commands':sum(f.is_file() for f in raw.glob('*/B/command.json')),
                'series_file_present':(raw/'series.json').is_file(),'basis':'The returned worker failed. All partial observations are excluded.'}
    success=read(raw/'successful.json');ret=read(raw/'retired.json');adopted=adoption(raw,prior)
    c=read(raw/'warm-CZD/checkpoint.json');cp=read(raw/'warm-P/checkpoint.json')
    need(w['capacity']['guard_fault'] is None and w['success']==sha(raw/'successful.json') and success['registration']==REG and
         success['physical_custody_sha256']==sha(raw/'retired.json') and success['scorer_sha256']==sha(raw/'analysis.json') and
         success['cas_sha256']==ret['all_programs_sha256']==sha(raw/'cas-index.json') and success['scored_rows']==24 and
         not success['pilot_only'] and success['all_tests']==15 and success['all_ELF']==17 and
         success['subjects_sha256']==sha(raw/'subjects.json') and ret['no_active_target'] and
         ret['adopted_P_sha256']==sha(raw/'adopted-P.json') and ret['protected_control']==adopted['original_owner'] and
         ret['CZD']=={'path':'/dev/shm/ohm20-whole-package-fourteen-20261030/CZD-never-B.tar.zst','sha256':c['sha256'],
                     'identity':c['archive_identity'],'new_archive_absent':True} and cp['archive_identity']!=c['archive_identity'],
         'incomplete independent arms, CAS or candidate retirement')
    need(not any(raw.glob('pilot*')),'unexpected pilot')
    price=capacity(raw,cp,c);v.public_inputs(root)
    rosters=actual_native(v,raw,src)
    with observation_reader(v,doc):
        result,programs,_=v.science(src,raw,scratch,cas)
    family=rank(src,doc,prior['family'],result)
    need(read(root/'owner/family.json')=={'original_thirteen':prior['family'],'fourteen':family,'actual_package_result':result,
            'own_outer_sha256':expected,'pooled':False},'recomputed 14-way result differs from native family')
    return {**base,'eligible':True,'counted_pairs':result['counted_pairs'],'raw_P_CZD_ns':result['raw_P_CZD_ns'],'score':result['score'],
            'holm14':family,'native_capacity':price,'programs':programs,'actual_admission_processes':rosters,'full_binaries_reread':cas is not None}

def run(packet,expected,scratch=None,elf_cas=None,reserve=0):
    v=engine(packet);v.PINS.update(EXTRA);v.SCOPE=LABEL
    def audit(root,expected,work,cas):
        prior=previous(root);intro=read(root/'physical/intake.json')
        route=material(root,prior,intro)
        return decode_result(v,root,expected,work,cas,prior,route)
    v.audit=audit
    if elf_cas is not None:
        # A stopped phase may lack a CAS index; its analysis always contains zero eligible clocks.
        with ZipFile(packet) as z:
            layout=z.getinfo('layout.json');need(layout.file_size<=8<<20,'oversize directory')
            h=json.loads(z.read(layout))['files']['physical/outer-return.json'];need(h==expected,'wrong outer')
            rec=z.getinfo('objects/'+h);need(rec.file_size<=1<<20,'oversize outer');b=z.read(rec)
            need(digest(b)==h,'corrupt outer')
            if json.loads(b)['outer']['exit']!=0:elf_cas=None
    return v.run(packet,expected,scratch,elf_cas,reserve)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('packet',type=Path);ap.add_argument('--outer',required=True)
    ap.add_argument('--scratch',type=Path);ap.add_argument('--elf-cas',type=Path);ap.add_argument('--reserve-gib',type=int,default=0)
    args=ap.parse_args()
    print(json.dumps(run(args.packet,args.outer,args.scratch,args.elf_cas,args.reserve_gib<<30),indent=2,sort_keys=True))
