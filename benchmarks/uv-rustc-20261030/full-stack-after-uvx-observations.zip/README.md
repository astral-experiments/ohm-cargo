# Replay the returned fourteenth uv comparison

This packet compares two matched −20 source builds. P is the bare parent, and CZD applies the two proposed compiler changes #270 and #275. It measures the first ordinary `cargo test --locked --offline -j8 -p uv --no-run` after the registered one-file tool test edit. The independent production `uvx` binary experiment is comparison 13. Its observations remain in their own study.

Extract the top-level verifier, then give it the SHA-256 of the genuine native outer from the accompanying report.

```sh
unzip -p native-fourteen.zip verify.py > verify-fourteen.py
python3 -ISB verify-fourteen.py native-fourteen.zip --outer ACTUAL_NATIVE_OUTER_SHA256
```

The standard-library reader checks the returned worker and all source hashes before executing any bundled scientific reader. It verifies both earlier published packets and the protected original P files, checks the material handoff, then reconstructs the elapsed intervals, the two execution orders, program inventories, control-only ELF references and the fourteen-comparison Holm result. A returned failure yields an empty scored sample and a p-value of 1. The 15 literal test listings, two executable version outputs, ELFs' full SHA-256s, actual process roles and command lines accompany completed observations.

The two proposed changes ran in matched source-built SDKs. See the published release context separately for measurements on distributed binaries.

The material record preserves the earlier failed backup, both recorded byte reconstructions, the successful independent recheck, and the four-lock handoff for the two parked inputs. The verifier decodes all three returns and the chunk offsets independently.

The executable payloads and checkpoint archives are held separately. The compact replay checks the recorded two-way ELF proofs and publishes their exact input identities. Supply the retained compressed ELF directory as `--elf-cas /path/to/products` to independently decompress and recheck the full binaries and derived image classes. Full replay needs zstd, BLAKE3 and room for two of the largest images. The storage manifests, original double-reconstruction records and their subsequent verification are included. The full backup payloads remain in the retained archive. The protocol and the earlier genuine result packets are embedded as content-addressed objects listed in `layout.json`.
