# Recheck the full-package result

This packet contains the observed complete-command clocks, job argv, mapped compiler identities, counts, Cargo output, 15 test lists and two CLI results. The compiled programs are identified by SHA-256. Run these commands from a clean extraction with Python 3.11 or later. Substitute the published outer SHA.

    python3 -ISB verify.py --expected-outer SHA
    python3 -ISB verify.py --expected-outer SHA --extract-raw new-study-tree

The one compact file contains the control-established full-file hashes, exact reciprocal comparison and original byte-level classification for each differing role. Its ordinary replay authenticates those receipts and independently rescores the unchanged preregistered clocks. The earlier package attempts both contribute p=1 and zero usable pairs. The combined ten-endpoint comparison and the independent direct PR comparison with an eleven-endpoint sensitivity correction are separate.

To verify from original bytes, supply the recorded compressed CAS for each scope, a directory with room for the two largest uncompressed programs, zstd, and a system libLLVM that exports llvm_blake3_hasher_init/update/finalize. Set PACKAGE_REPLAY_LLVM to an explicit compatible library if needed. This step rechecks both SHA-256s, verifies both complete GNU build IDs, and checks every original byte outside the sole declared section-header and ID fields. A raw SHA difference remains visible in the ELF section table and GNU ID. No test count or payload change is accepted.

    python3 -ISB verify.py --expected-outer SHA --scratch /space/temporary --elf-cas combined=/path/to/compressed-programs
    python3 -ISB copy_elf.py . combined SHA /path/to/compressed-programs /fresh/external-destination --scratch /space/temporary --reserve-gib 122.75

The separate optional copying command checks capacity first, checks each new file, and writes its terminal receipt only after a complete independent replay. No raw compiler SDK or multi-gigabyte ELF corpus is embedded in the compact packet.
