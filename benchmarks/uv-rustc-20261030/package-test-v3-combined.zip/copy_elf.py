"""Explicit optional durable copy of verified compressed images. No implicit export or deletion."""
import argparse
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
import tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import verify as v

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('packet',type=Path);a.add_argument('scope',choices=['combined','direct']);a.add_argument('expected_outer')
    a.add_argument('existing_cas',type=Path);a.add_argument('fresh_destination',type=Path)
    a.add_argument('--reserve-gib',type=float,required=True);a.add_argument('--scratch',type=Path,required=True)
    o=a.parse_args();dst=o.fresh_destination.resolve();cas=o.existing_cas.resolve(strict=True)
    v.need(not dst.exists() and dst.parent.is_dir() and o.reserve_gib>=0,'new output and nonnegative reserve required')
    with tempfile.TemporaryDirectory(dir=o.scratch) as temp:
        raw=Path(temp)/'raw';v.check(o.packet,raw,o.expected_outer,scratch=o.scratch)
        phase=raw/'phases'/o.scope;i=v.read(phase/'cas-index.json')['files']
        size=sum(x['compressed_bytes'] for x in i.values());margin=int(o.reserve_gib*(1<<30))
        v.need(shutil.disk_usage(dst.parent).free>=size+margin+(16<<20),'would cross the explicit destination reserve')
        dst.mkdir(mode=0o700)
        for h,x in sorted(i.items()):
            p=cas/(h+'.zst');dest=dst/p.name
            v.need(p.resolve()==p and p.is_file() and p.stat().st_size==x['compressed_bytes'] and shutil.disk_usage(dst).free>=p.stat().st_size+margin,'raw CAS missing or destination reserve consumed')
            with p.open('rb') as src,dest.open('xb') as out:
                shutil.copyfileobj(src,out,1<<20);out.flush();os.fsync(out.fileno())
            v.need(v.e.sha(dest)==x['compressed_sha256'],'compressed source changed')
        result=v.e.deep(v.e.scorer(raw,raw),phase,dst,o.scratch,['B'] if o.scope=='combined' else ['A','B'])
        receipt={'scope':o.scope,'complete':True,'outer_sha256':o.expected_outer,'files':len(i),'bytes':size,'detached_replay':result}
        with (dst/'copied-and-replayed.json').open('x') as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write('\n')
        print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
