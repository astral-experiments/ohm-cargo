"""Verify and rescore a relocated complete-package evidence packet with stdlib Python."""
import argparse
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import statistics
import tempfile

K = 'package-test-v3'
L = 'package-test-v3-direct-leaf'
F = 'package-test/results-packet/failed-elf-forensics'
ORIGINAL_WARM = {'P': {'checkpoint_sha256': 'ea0ddf268b66ab285a593666c30a6fccfc705af7a651669f3885108b2f979655', 'settled_output_receipt_sha256': 'b6209016a2b0ae31035d3358d23a3f4acba71a055a6268666af557ee6bbbb2c0', 'original_cas_receipt_sha256': '8eefd0da46fd16edc8676da51e97c0063873d8780440eabb00dcf050bab7ae05'}, 'C': {'checkpoint_sha256': 'a0221a04339aca50a65516a50431c3d51923fcb2f30770203e76b83727c9c1c0', 'settled_output_receipt_sha256': 'b6209016a2b0ae31035d3358d23a3f4acba71a055a6268666af557ee6bbbb2c0', 'original_cas_receipt_sha256': '8eefd0da46fd16edc8676da51e97c0063873d8780440eabb00dcf050bab7ae05'}, 'CZD': {'checkpoint_sha256': '13749c3166ac6221a9d39856f81771aebbbfccd18f3a4204cdf0b14a0b70b950', 'settled_output_receipt_sha256': 'b6209016a2b0ae31035d3358d23a3f4acba71a055a6268666af557ee6bbbb2c0', 'original_cas_receipt_sha256': '8eefd0da46fd16edc8676da51e97c0063873d8780440eabb00dcf050bab7ae05'}}
CENSUS_SHA = 'e7e4fa643971c671836067288221c7f78301a01e610bb469bdc3a2847241f1a5'
PINS = {'package-test/products.py': 'c944170557005488b70753c5200c9b3d589bf8adc8c423b87396a49c159f8a65', 'package-test/original-score.py': '376a2dfb658cd1f087e1d96f46ea370077d37cc02fa51b135e8223d0c5e879f5', 'package-test/protocol.json': '1fe2a1508760d467cf4416dfcdf0949f8fae12832123a38056e08bb16f86e35b', 'package-test/family.py': '06ae3b970cf9b3bf0d93e704c0732a7de1a0947d8ce917c922035bb8fd3d74ba', 'package-test/registration.json': 'f407179ed32a9cb0ee90a4414c4ee29c7101fcdda8fdb3b00f8775fc6f9e4e47', 'package-test-v2/registration.json': 'f4c0751e7f1ced673189f6e0e358169bd0261db08961a58a1a6f3c5d959a97d0', 'package-test-v2/protocol.json': '5e26ceeab9cb84ef0db0f77b78117f736029e5ab8f091f12bfba1777838085f9', 'package-test-v2/forms.py': '42fd001b725ca859e7a5b579e6e3943146a8823323c719726ed80adda97d5bf9', 'package-test-v2/replay.py': '48380376e77bdd04bc860366ffd56d651c3f5fde61e281187b906482b191134c', 'package-test-v2/family.py': 'cb908e8d51f92f2859fbc53a310eb888f2a753161787e2638622e8cf717bd7dd', 'package-test-v2-direct-leaf/registration.json': '7e49f3ef173a0fa3441bed12775345b5288a9aa54f575a5d33f5082236c2fa60', 'package-test-v2-direct-leaf/protocol.json': '00ac2aab67c0c1a0002b3a263358a29a565c4c05e678e6ed1a37a4f33149da8c', 'package-test-v2-direct-leaf/score.py': 'e0a373e1d076b92d083179fd0d818bf33c3f9faae8f4c87f46874ec653fd7fd5', 'fresh-edit-trial/direct-leaf/leaf_score.py': 'f8fa01da1480aa859e293c04a97bc80700ef0460418f09d858be0af2c0e914e9', 'package-test/results-packet/failed-elf-forensics/evidence.json': 'eb2bb0456a62ee363486b9de38fc1e83c7534fc51124f9a5079f138fca11fcd7', 'package-test/results-packet/failed-elf-forensics/closed.py': '1f33d763e6b1718a782521b6a17fe1910737ce8a96f9d09b2903451ac4ee3d3a'}
OFFICIAL = '4739f51674f00a55ef7c1597ee0f125bccff62b6a447deacb8b85c51e446999b'
ARMS = {'combined': ('C', 'CZD'), 'direct': ('P', 'ZD')}

F2 = 'package-test-v2/results-packet/failed-admission-forensics'
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import elf_replay as e
HERE=Path(__file__).resolve().parent
PINS.update(json.loads((HERE/'pinned.json').read_bytes()))
ARM_PINS=json.loads((HERE/'leaf-pins.json').read_bytes()) if (HERE/'leaf-pins.json').is_file() else {}
def dataname(original):
    p=Path(original)
    parts=p.parts
    if 'guard-file-free-math-asm' in parts:
        return '/'.join(parts[parts.index('guard-file-free-math-asm')+1:])
    if p.name=='forms.py' and p.parent.name=='heldout-test-v6-stock-wild':return 'elf-tools/geometry.py'
    if p.name in ('retain.py','recover_forms.py','blake-stream'):return 'elf-tools/'+p.name
    return 'registered-external/'+p.name

def need(x, msg):
    if not x:
        raise ValueError(msg)

def read(p):
    return json.loads(Path(p).read_bytes())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def module(p, name):
    s = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m

def safe(s):
    p = PurePosixPath(s)
    need(isinstance(s, str) and p.parts and str(p) == s and not p.is_absolute()
         and '..' not in p.parts and '\\' not in s, 'unsafe archive member')
    return p

def regular(p):
    need(p.is_file() and not p.is_symlink(), 'missing or nonregular ' + str(p))
    return p

def materialize(packet, dest):
    layout = read(regular(packet/'layout.json'))
    need(layout['schema'] == 1 and set(layout['files']) >= (set(PINS) | (set(ARM_PINS) if layout['scope']=='direct' else set())), 'missing registration')
    objects = packet/'objects'
    need(objects.is_dir() and not objects.is_symlink(), 'invalid object directory')
    store = {f.name for f in objects.iterdir()}
    need(set(layout['files'].values()) == store and len(store) <= 30000, 'changed logical/object set')
    for h in store:
        need(bool(re.fullmatch('[a-f0-9]{64}', h)) and sha(regular(objects/h)) == h,
             'changed retained evidence object')
    need(not dest.exists(), 'reconstruction directory exists')
    dest.mkdir()
    for name, h in layout['files'].items():
        path = dest/safe(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(objects/h, path)
        except OSError as error:
            if error.errno != errno.EXDEV:raise
            shutil.copyfile(objects/h,path)
    return layout

def outer(d, expected=None):
    o = read(d/'outer-return.json')
    w = read(d/'worker-return.json')
    i = read(d/'intake.json')
    t = o['outer']
    need(isinstance(t['session'], int) and t['session'] > 0
         and re.fullmatch('[a-f0-9]{6}', t['chunk'])
         and t['exit'] == o['worker_code'] == w['code'] == w['worker_exit'] == 0
         and o['remaining_workers'] == o['foreign'] == [] and o['host_released']
         and o['boot'] == i['boot'] and len(set(o['locks'])) == 2 and o['locks'] == i['locks']
         and o['intake_sha256'] == sha(d/'intake.json')
         and o['worker_sha256'] == sha(d/'worker-return.json')
         and (expected is None or sha(d/'outer-return.json') == expected), 'unauthenticated outer or worker')
    return i, w

def certified(d):
    i, w = outer(d)
    need(w['success'] == sha(d/'successful.json'), 'substituted worker evidence')
    return i, read(d/'successful.json')

def official(root):
    d = root/'official'
    need(sha(d/'outer-return.json') == OFFICIAL, 'wrong actual SDK QA return')
    o = read(d/'outer-return.json')
    need(o['outer']['exit'] == o['worker_code'] == 0 and o['host_released'] and
         o['worker_sha256'] == sha(d/'worker-return.json'), 'bad SDK return')
    w = read(d/'worker-return.json')
    q = read(d/'qualified.json')
    need(w['qualified'] == sha(d/'qualified.json') and q['qualified'], 'bad SDK qualification')
    proof = q['prior_evidence']
    out = {}
    for a in ('P','C','CZ','CZD','ZD'):
        p = d/(a+'-sdk.json')
        m = read(p)
        need(sha(p) == proof['manifests'][a] and m['files'][m['driver']] == proof['drivers'][a],
             'different matched SDK or driver')
        f = d/('run-make-'+a+'.json')
        recipe = read(f)
        need(sha(f) == q['official'][a] and recipe['exit'] == 0 and recipe['driver_sha256'] == proof['drivers'][a], 'different compiler in native QA')
        out[a] = m['files'][m['driver']]
    return out

def check_order(series, orders):
    expected = set()
    for r, order in zip(series, orders, strict=True):
        seq, attempt = r['sequence'], r['attempt']
        names = [f'pair-{seq:02d}-try-{attempt}-{i}-{a}' for i, a in enumerate(order)]
        need(r['dirs'] == names and r['order'] == order and not (set(names) & expected),
             'substituted assignment directory')
        expected.update(names)

def compact_roster(root, arm, trace_reader):
    b = root/('admission-'+arm)/'B'
    roles = read(b/'roles.json')
    witness = read(b/'mapped-driver.json')
    census = read(b/'census.json')
    raw = trace_reader.index(b)
    need(census['source_inventory'] == raw['raw_filename_sha256_inventory'],
         'different raw exec trace file inventory')
    events = {(pid,exe,tuple(argv)) for pid,_,exe,argv in raw['events']}
    actual = census['actual']
    need(all((j['pid'],j['exe'],tuple(j['argv'])) in events for j in actual),
         'wrong PID, executable or argv in diagnostic roster')
    compiled = [j for j in actual if j['role'] != 'link']
    hashes = sorted(hashlib.sha256(json.dumps(j['argv'], separators=(',',':')).encode()).hexdigest()
                    for j in compiled)
    need(hashes == sorted(j['argv_sha256'] for j in roles['rustc'])
         and sorted([j['exe'], j['output']] for j in actual if j['role'] == 'link') == roles['wild']
         and witness['exact_compiler_execs'] == len(compiled) and witness['actual_selected'] >= 1,
         'diagnostic roles disagree with actual rustc/linker calls and mapped driver')
    clock = read(b/'command.json')
    return {'rustc':len(compiled),'linker':len(roles['wild']),'mapped':witness['actual_selected'],
            'packages':clock['packages'],'changed_stamps':clock['changed_stamps']}

def cas(root, folders):
    idx = read(root/'cas-index.json')['files']
    need(idx and all(re.fullmatch('[0-9a-f]{64}',k) and v['raw_sha256'] == k
                     and re.fullmatch('[0-9a-f]{64}',v['compressed_sha256'])
                     and v['raw_bytes'] > 0 and v['compressed_bytes'] > 0
                     for k,v in idx.items()), 'invalid saved CAS identities')
    paths = {}
    for folder in folders:
        products = read(folder/'all-products.json')
        need(len(products) == 17, 'incomplete raw product set')
        if folder.name != 'apply-compiler-A':
            need(all(x['sha256'] in idx and idx[x['sha256']]['raw_bytes'] == x['bytes']
                     for x in products.values()), 'settled program absent from retained CAS')
        p = folder.parent/'retained-products.json'
        if p.exists() and folder.name != 'apply-compiler-A':
            stored = read(p)
            need(set(stored) == set(products) and all(stored[n] == idx[v['sha256']]
                 for n,v in products.items()), 'changed retained product or compressed CAS identity')
        paths[str(folder.relative_to(root))] = {
            k:{'sha256':v['sha256'],'bytes':v['bytes'],'behavior_sha256':v['stdout_sha256'],
               'exit':v['exit'],'tests':v.get('tests')} for k,v in products.items()}
    return paths

def direct_guards(root,stage,drivers):
    import ast
    from types import SimpleNamespace
    p=root/'validation/native_qa.py'
    need(sha(p)=='a8700612d6e589847f268f3be898766a0914d5f461f244be94e2ea8798d6f25b','changed original assembler regression reader')
    body=ast.parse(p.read_text()).body
    constants=[i for i in body if isinstance(i,ast.Assign) and len(i.targets)==1 and isinstance(i.targets[0],ast.Name) and i.targets[0].id=='FIXED']
    validators=[i for i in body if isinstance(i,ast.FunctionDef) and i.name=='validate']
    need(len(constants)==len(validators)==1,'ambiguous original validator')
    env={'v':SimpleNamespace(need=need,read=read,sha=sha)}
    exec(compile(ast.Module(constants+validators,type_ignores=[]),str(p),'exec'),env)
    f=stage/'native';b=read(f/'subjects.json');j=read(f/'verified.json')
    need(b['registered']==sha(root/L/'registration.json') and
         all(b['subjects'][r]['driver_sha256']==drivers[a] for r,a in [('parent','P'),('candidate','ZD')]),'wrong direct guard subjects')
    result=env['validate'](f,b['subjects'])
    for a in ('parent','candidate'):
        records=f/a/'cargo-native/evidence/rows.json';rows=read(records)
        need([r['exit']==0 for r in rows]==[True,True,True,False,False,False,True] and
             [r['printed'] for r in rows if r['exit']==0]==['273\n','285\n','541\n','529\n'],'changed ordinary Cargo assembler outcome')
        result[a]['normal_cargo_sha256']=sha(records)
    need(j=={'subjects_sha256':sha(f/'subjects.json'),'results':result,'code':0,'timed':False} and
         read(stage/'retired.json')['native_controls_sha256']==sha(f/'verified.json'),'native test return changed')
    return result

def phase(root, scope, science, runner, drivers, source, traces):
    directory = root/'phases'/scope
    intake, terminal = certified(directory)
    need(terminal['scorer_sha256'] == sha(directory/'analysis.json') and
         terminal['cas_sha256'] == sha(directory/'cas-index.json') and
         terminal['physical_custody_sha256'] == sha(directory/'retired.json'), 'wrong analysis/CAS/retirement')
    reg = sha(root/science/'registration.json')
    ret = read(directory/'retired.json')
    w = read(directory/'worker-return.json')
    need(intake['registration'] == terminal['registration'] == reg and
         w['owned_children_at_return'] == [] and w['capacity']['guard_fault'] is None and
         w['locks'] == intake['locks'] and w['end_ns'] > intake['start_ns'] and
         terminal['subjects_sha256'] == sha(directory/'subjects.json') and ret['absent'] and
         terminal['all_tests'] == 15 and terminal['all_ELF'] == 17 and
         terminal['cas_sha256'] == ret['all_programs_sha256'], 'incomplete registered native result')
    result = runner.replay(directory)
    need(terminal['scored_rows'] == 2*result['counted_pairs'] and terminal['pilot_only'] == (not result['continues']),
         'pilot or scored rows incorrectly labelled')
    need(result == read(directory/'analysis.json'), 'computed result differs from the retained analysis')
    plan = read(root/science/'protocol.json')
    raw = read(directory/'series.json')
    records = ([raw['pilot']] if scope == 'combined' else []) + raw['pairs']
    orders = ([plan['pilot_order']] if scope == 'combined' else []) + plan['pairs'][:len(raw['pairs'])]
    check_order(records,orders)
    seqs = {r['sequence'] for r in records}
    need(all(q['sequence'] in seqs for q in raw['exclusions']), 'extra unassigned exclusions')
    arms = ARMS[scope]
    program_dirs = [directory/n/'B' for r in records for n in r['dirs']]
    rosters = {}
    for a in arms:
        adm = directory/('admission-'+a)
        sub = read(adm/'subject.json')
        edit = read(adm/'edit.json')
        need(sub['driver_sha256'] == drivers[a] and edit['before']['sha256'] == source['A']
             and edit['after']['sha256'] == source['B'], 'unmatched compiler or source')
        rosters[a] = compact_roster(directory, a, traces)
        program_dirs.append(adm/'B')
    warm_retained={}
    for a in (('P','C','CZD') if scope=='combined' else arms):
        warm=directory/('warm-'+a)
        if scope=='combined':
            adopted=read(warm/'adopted.json')
            need(adopted['arm']==a and adopted['old_unscored_A_only'] and
                 all(sha(regular(warm/safe(n)))==h for n,h in adopted['files'].items()),'modified adopted A manifest')
            f=warm/'verify-repeat-A';images=runner.product(f,plan);index=read(warm/'retained-products.json')
            need(set(index)==set(images) and all(index[k]['raw_sha256']==z['sha256'] and index[k]['raw_bytes']==z['bytes'] for k,z in images.items()),'original A CAS no longer identifies all programs')
            fixed=ORIGINAL_WARM[a]
            need(sha(f/'all-products.json')==fixed['settled_output_receipt_sha256'] and sha(warm/'checkpoint.json')==fixed['checkpoint_sha256'] and sha(warm/'retained-products.json')==fixed['original_cas_receipt_sha256'],'unbound original A checkpoint/CAS')
            if a in plan['seeds']:need(all(plan['seeds'][a][k]==fixed[k] for k in ('settled_output_receipt_sha256','checkpoint_sha256')),'different admitted arm')
            warm_retained[str(f.relative_to(directory))]={k:{'sha256':z['sha256'],'bytes':z['bytes'],'behavior_sha256':z['stdout_sha256'],'exit':z['exit'],'tests':z.get('tests')} for k,z in images.items()}
        else:
            for nm in ('apply-compiler-A','ordinary-repeat-A','verify-repeat-A'):
                f=warm/nm;need(f.is_dir(),'missing genuine direct P/ZD A visit')
                runner.base.product(f,plan)
                need(read(f/'command.json')['driver']==drivers[a],'wrong directly warmed subject')
                program_dirs.append(f)
    all_programs={**cas(directory,program_dirs),**warm_retained}
    index=read(directory/'cas-index.json')
    kinds=['B'] if scope=='combined' else ['A','B']
    expected_cas=set();expected_role_forms={}
    memberships={}
    for kind in kinds:
        ref=read(directory/f'baseline-{kind}-forms.json')
        observed=directory/('form-proofs' if kind=='B' else 'form-proofs-A')
        proofs=e.compact(None,directory,kind)
        recorded={p.name:sha(p) for p in sorted(observed.glob('*.json'))}
        name=f'stock_{kind}_reference_sha256'
        idx_key='observed_nonidentical_pairs' if kind=='B' else 'observed_A_nonidentical_pairs'
        need(index[name]==ret[name]==sha(directory/f'baseline-{kind}-forms.json') and index[idx_key]==recorded,'raw phase proof index changed')
        in_phase=[f for f in program_dirs if (f.name=='B')==(kind=='B') and f.name!='apply-compiler-A']
        observed_roles={r:set() for r in ref['roles']}
        for f in in_phase:
            for role,rec in read(f/'all-products.json').items():observed_roles[role].add(rec['sha256'])
        need(all(hashes<=set(ref['roles'][r]['class']['allowed']) for r,hashes in observed_roles.items()),'raw form was not preauthorized by the independent control')
        expected_keys=set()
        for r,hs in observed_roles.items():
            refraw=ref['roles'][r]['class']['observed']
            for h in hs-{refraw}:
                key=hashlib.sha256((r+':'+':'.join(sorted([h,refraw]))).encode()).hexdigest()
                need(key in proofs,'missing independent whole-file two-way proof for an observed alternate')
        expected_keys={hashlib.sha256((r+':'+':'.join(sorted((h,ref['roles'][r]['class']['observed'])))).encode()).hexdigest()
            for r,hs in observed_roles.items() for h in hs if h!=ref['roles'][r]['class']['observed']}
        need(set(proofs)==expected_keys,'unobserved alternative was presented as a true reciprocal proof')
        expected_cas.update(h for hs in observed_roles.values() for h in hs)
        if scope=='direct':
            expected_role_forms[kind]={}
            for arm in arms:
                fs=[f for f in in_phase if (f.parent.name=='admission-'+arm or f.parent.name=='warm-'+arm or f.parent.name.endswith('-'+arm))]
                expected_role_forms[kind][arm]={r:sorted({read(f/'all-products.json')[r]['sha256'] for f in fs}) for r in ref['roles']}
        memberships[kind]={'baseline_sha256':sha(directory/f'baseline-{kind}-forms.json'),'independent_control':ref['independent_arm'],
            'raw_controls':{r:x['class']['observed'] for r,x in ref['roles'].items()},'observed_forms':{r:sorted(h) for r,h in observed_roles.items()},
            'reciprocal_files':{read(p)['role']:{'sha256':sha(p),'raw':read(p)['allowed_from_P' if kind=='A' else 'allowed_from_C'],'bytes':read(p)['bytes'],
                  'changed_bytes':read(p)['full_file']['exact']['actual_byte_differences'],'outside_ranges':0} for p in sorted(observed.glob('*.json'))}}
    need(set(index['files'])==expected_cas,'unobserved raw programs added to the accepted CAS or missing physical program')
    checkpoints=None
    if scope=='direct':
        need(index['actually_observed_by_phase_arm_role']==expected_role_forms,'original direct A/B arm/role index differs from the raw records')
        checker=module(root/L/'deferred-evidence/checkpoints.py','independent_arm_restoration')
        checkpoints=checker.audit(directory,plan['pairs'])
    return {'result':result,'direct_restoration':checkpoints,'direct_native':direct_guards(root,directory,drivers) if scope=='direct' else None,'unscored_pilot_order':plan.get('pilot_order') if scope=='combined' else None,
            'measured_orders':[r['order'] for r in raw['pairs']],'diagnostic_rosters':rosters,'program_inventories':all_programs,
            'elf_forms':memberships,'boot':intake['boot'],'native_start_ns':intake['start_ns'],'native_end_ns':w['end_ns'],'real_outer':read(directory/'outer-return.json')['outer'],'outer_sha256':sha(directory/'outer-return.json')}

def readers(root,scope,physical_source=None):
    src=physical_source or root
    f=e.scorer(root,src)
    original_validate=f.validate_reference
    def compact_reference(root,plan,deep=False,baseline_arm='C',candidate_arm='CZD'):
        e.compact(f,Path(root),'B')
        return original_validate(root,plan,False,baseline_arm,candidate_arm)
    f.validate_reference=compact_reference
    def compact_bind(directory,cas=None,emit=False,native_tmp=None):
        root_dir=Path(directory).resolve()
        f.ROOT=root_dir;f.CAS=Path(cas) if cas else root_dir/'elf-cas';f.EMIT=False;f.NATIVE_TMP=None
        f.CHECKED.clear();f.CHECKED.update(e.compact(f,root_dir,'B'))
    f.bind=compact_bind
    with e.relocated({src/K/'forms.py':f}):
        main=module(src/K/'replay.py','package_score')
    direct=None
    if scope=='direct':
        with e.relocated({src/K/'replay.py':main,src/K/'forms.py':f}):
            direct=module(src/L/'score.py','direct_package_score')
        a=direct.a_forms
        ref=a.reference;equal=a.equal
        def ref_a(root,plan,forms,*,create=False,deep=False):
            need(not create,'detached replay cannot create candidate eligibility')
            e.compact(forms,Path(root),'A')
            return ref(root,plan,forms,create=False,deep=False)
        def equal_a(left,right,plan,forms):
            from contextlib import contextmanager
            from unittest.mock import patch
            idx=read(forms.ROOT/'cas-index.json')['files'];proofs={}
            for p in (forms.ROOT/'form-proofs-A').glob('*.json'):
                q=read(p);key=tuple(q['allowed_from_P'])
                need(key not in proofs or proofs[key]==q['full_file'],'conflicting byte proofs for identical raw pair')
                proofs[key]=q['full_file']
            @contextmanager
            def cached(h,size):
                need(idx[h]['raw_sha256']==h and idx[h]['raw_bytes']==size,'unbound independent A input')
                yield h
            def exact(x,y,left,right):
                need((x,y)==(left,right),'wrong reciprocal raw A')
                return proofs[(left,right)]
            with patch.object(forms,'unpack',cached),patch.object(forms,'exact',exact):return equal(left,right,plan,forms)
        a.reference=ref_a;a.equal=equal_a
    return main,direct

def substantive(root, scope):
    need(scope in ARMS, 'unknown package scope')
    for path,h in {**PINS,**(ARM_PINS if scope=='direct' else {})}.items():
        need(sha(regular(root/path))==h,'changed original registration or scorer '+path)
    for absname,h in read(root/K/'registration.json')['sources'].items():
        need(sha(regular(root/dataname(absname)))==h,'registered scientific source changed: '+str(absname))
    main,direct=readers(root,scope)
    drivers = official(root)
    source = {}
    plan = read(root/K/'protocol.json')
    for form in ('A','B'):
        f = root/'edit'/('source-'+form+'.rs')
        need(blob(f.read_bytes()) == plan['uv']['edit'][form], 'different real Git source')
        source[form] = sha(f)
    need(sha(root/'trace-reader.py') == CENSUS_SHA, 'different original trace decoder')
    traces = module(root/'trace-reader.py','frozen_census')
    out = {'combined':phase(root,'combined',K,main,drivers,source,traces)}
    if scope == 'direct':
        out['direct'] = phase(root,'direct',L,direct,drivers,source,traces)
    forensic=module(root/F/'closed.py','reuse_only_raw_control_proof').closed()
    need(forensic['admitted_original_series'] is False and forensic['two_way_single_field_reconstruction'],'did not preserve original finite exclusion')
    fr=read(root/'family.json')
    second=module(root/F2/'closed.py','preserve_second_raw_rejection').closed()
    need(second['zero_pilots'] and second['scored_rows']==0 and second['two_way_single_field_reconstruction'] and second['independent_same_C_images'],'lost second failed intake')
    f=module(root/K/'family.py','pinned_ten_family')
    need(fr['original_failed_p']==fr['second_failed_p']==1 and set(fr['previous_closures'])<=set(f.NAMES[:7]),'unknown prior gate or original failure given credit')
    scores={}
    for name,h in fr['previous_closures'].items():
        p=root/'finite-family'/safe(name.replace('/','--'))
        outer(p,h);_,captured=certified(p);oc=captured['outcome']
        if 'results' in oc:
            matches=[v for v in oc['results'].values() if isinstance(v,dict) and v.get('pairs')==12]
            need(len(matches)<=1,'ambiguous certified prior score');r=matches[0] if matches else None
        else:r=oc.get('pairs')
        if r is not None:
            vals=r['raw_ratio'];sign=main.score_engine().sign(vals,2)
            need(len(vals)==12 and r['p_against_2']==sign and r['ratio_median']==statistics.median(vals) and
                 r['individual_gate']==(sorted(vals)[2]>=2 and min(r['per_order_ratio_medians'].values())>=2 and sign['two_sided_p']<.05),'wrong preceding study score')
            scores[name]=r
    result=out['combined']['result']
    if result['score'] is not None:scores[f.PRIMARY]=result['score']
    nine=f.adjust(scores);need(fr['raw']==result and fr['individual_scores']==scores and fr['holm10']==nine and fr['holm11_sensitivity']==f.adjust(scores,True),'combined score or correction differs')
    direct_score=None
    if scope=='direct':
        entry=read(root/'phases/direct/intake.json')['primary'];prev=entry['closure_digests']
        need(all(fr['previous_closures'].get(k)==h for k,h in prev.items()),'materialized prior closure changed')
        initial={k:r for k,r in scores.items() if k in prev or k==f.PRIMARY}
        decision=f.adjust(initial)
        need(entry['decision']==decision and decision[f.PRIMARY]['confirmed'] and result['counted_pairs']==12 and result['score']['individual_gate'] and entry['combined_score']==result['score'] and entry['combined_native_outer']==out['combined']['outer_sha256'] and entry['combined_scorer']==sha(root/K/'family.py') and entry['previous_failed_packages']==read(root/K/'protocol.json')['previous_native_studies'],'direct lacked actual new Holm10 at intake')
        direct_score=out['direct']['result']['score']
    with_direct=dict(scores)
    if direct_score is not None:with_direct[f.DIRECT]=direct_score
    return {'schema':3,'scope':scope,'outcomes':out,'holm10':nine,'holm11_sensitivity':f.adjust(with_direct,True),
            'excluded':{f.ORIGINAL:forensic,f.PREVIOUS:second},'failed_p':{f.ORIGINAL:1,f.PREVIOUS:1},
            'matched_driver_sha256':drivers,'source_sha256':source}


def check(packet, persist=None, expected_outer=None, *, elf_cas=None, scratch=None):
    packet = Path(packet)
    with tempfile.TemporaryDirectory(prefix='package-score-',dir=scratch) as tmp:
        dest = Path(persist).resolve() if persist else Path(tmp)/'raw'
        layout = materialize(packet,dest)
        result = substantive(dest,layout['scope'])
        need(result == read(packet/'result.json'),'detached output differs from exported score')
        if elf_cas:
            science=e.scorer(dest,dest)
            need(scratch is not None,'supply a scratch directory for at most two uncompressed images')
            for phase,cas in elf_cas.items():
                need(phase in result['outcomes'],'wrong raw-corpus scope')
                e.deep(science,dest/'phases'/phase,cas,scratch,['A','B'] if phase=='direct' else ['B'])
        sections = result['outcomes']
        need(expected_outer is None or sections[layout['scope']]['outer_sha256'] == expected_outer,
             'wrong expected native outer')
        return result

def main():
    a = argparse.ArgumentParser()
    a.add_argument('packet',nargs='?',type=Path,default=Path(__file__).resolve().parent)
    a.add_argument('--extract-raw',type=Path,help='also retain the reconstructed raw study tree at a new path')
    a.add_argument('--expected-outer',help='require the effective native outer SHA published alongside this result')
    a.add_argument('--elf-cas',action='append',default=[],metavar='SCOPE=/path/to/products',help='independently rehash/decompress originals and rederive both complete-file alternatives')
    a.add_argument('--scratch',type=Path,help='temporary root on a volume with room for two uncompressed ELFs')
    opts=a.parse_args()
    answer=check(opts.packet,opts.extract_raw,opts.expected_outer,elf_cas=dict(x.split("=",1) for x in opts.elf_cas),scratch=opts.scratch)
    for k in answer['outcomes'].values(): k.pop('program_inventories')
    print(json.dumps(answer,indent=2,sort_keys=True))
if __name__ == '__main__':main()
