"""Relocate original ELF/scoring sources. Compact replay verifies signed full-file proofs; --elf-cas recomputes them."""
from contextlib import contextmanager
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

HEX = re.compile('[0-9a-f]{64}')
def need(ok,why):
    if not ok:raise ValueError(why)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

class _Existing:
    def __init__(self,m):self.m=m
    def create_module(self,_):return self.m
    def exec_module(self,_):pass

@contextmanager
def relocated(entries):
    """Substitute only authenticated dependency locations while executing the original scoring files."""
    original=importlib.util.spec_from_file_location
    entries={Path(k).resolve():v for k,v in entries.items()}
    def spec(name,path,*a,**kw):
        obj=entries.get(Path(path).resolve())
        if obj is None:return original(name,path,*a,**kw)
        return importlib.util.spec_from_loader(name,_Existing(obj))
    with patch.object(importlib.util,'spec_from_file_location',spec):yield

def llvm_primitive():
    names=([os.environ['PACKAGE_REPLAY_LLVM']] if 'PACKAGE_REPLAY_LLVM' in os.environ else [])
    names += ['libLLVM.so.18.1', 'libLLVM.so'] + [f'libLLVM-{v}.so.1' for v in range(22,14,-1)]
    lib=None
    for n in filter(None,names):
        try:
            l=ctypes.CDLL(n)
            if hasattr(l,'llvm_blake3_hasher_finalize'):lib=l;break
        except OSError:continue
    need(lib is not None,'deep replay requires LLVM with exported llvm_blake3_hasher_* (set PACKAGE_REPLAY_LLVM)')
    ptr=ctypes.c_void_p;size=ctypes.c_size_t
    init,update,final=[getattr(lib,'llvm_blake3_hasher_'+k) for k in ('init','update','finalize')]
    init.argtypes=[ptr];update.argtypes=[ptr,ptr,size];final.argtypes=[ptr,ptr,size]
    init.restype=update.restype=final.restype=None
    def calc(data):
        result=ctypes.create_string_buffer(32);state=ctypes.create_string_buffer(4096)
        handle=ctypes.c_char.from_buffer(data) if len(data) else ctypes.c_char()
        init(state);update(state,ctypes.byref(handle),len(data));final(state,result,32)
        return result.raw.hex()
    need(calc(bytearray())=='af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262'
         and calc(bytearray(b'abc'))=='6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85','BLAKE3 reference vectors failed')
    return calc

def validate_saved(classed,proofs):
    entries=classed['roles']
    for role,entry in entries.items():
        rec,cls=entry['record'],entry['class']
        h=rec['sha256'];need(HEX.fullmatch(h) and cls['observed']==h,'control/executable hash changed')
        if cls['policy']=='raw-identical-only':
            need(cls['allowed']==[h],'unknown raw-only alternate');continue
        g=cls['geometry'];f=cls['derived'];et=g['rodata_entsize'];n=g['build_id_offset'];offset=g['rodata_entsize_offset']
        ids=f['forms'];allowed=sorted(o['sha256'] for o in ids.values())
        need(cls['policy']=='released-Wild-0-or-8' and set(ids)=={'0','8'} and len(set(allowed))==2 and
             allowed==cls['allowed'] and all(HEX.fullmatch(o['gnu_build_id']) and HEX.fullmatch(o['sha256']) for o in ids.values()) and
             et in (0,8) and ids[str(et)]['sha256']==h and f['actual_sha256']==h and f['actual_entsize']==et and
             f['bytes']==rec['bytes'] and n==f['gnu_build_id_start'] and n+32==f['gnu_build_id_end'] and offset==f['rodata_entsize_offset']
             and g['machine']==62 and g['type']==3 and g['rodata_header'][1:3]==[1,0x32] and g['read_only_load'][:2]==[1,4]
             and g['rodata_header'][-1]==et and 16<=n<n+32<=rec['bytes'] and 0<=offset<=rec['bytes']-8,
             'malformed independently sealed Wild alternatives for '+role)
    checked={}
    for p in sorted(proofs.glob('*.json')):
        q=load(p);role=q['role'];rec=entries[role]['record'];cls=entries[role]['class'];a,b=cls['allowed']
        key=hashlib.sha256((role+':'+a+':'+b).encode()).hexdigest();z=q['full_file'];v=z['exact']
        need(p.name==key+'.json' and q['bytes']==rec['bytes'] and q['path']==rec['path'] and
             q['allowed_from_P' if proofs.name=='form-proofs-A' else 'allowed_from_C']==[a,b] and z['pass'] and [z['left'],z['right']]==[a,b] and
             v['raw_sha256']==[a,b] and v['two_form_exact'] and not v['identical'] and v['bytes']==rec['bytes']
             and 1<=v['actual_byte_differences']<=33 and v['outside_ranges_differences']==0,'incorrect retained reciprocal proof')
        paired=list(zip(z['geometry'],(v['left'],v['right']),(a,b),strict=True))
        for g,f,h in paired:
            need(f['actual_sha256']==h==f['forms'][str(g['rodata_entsize'])]['sha256'] and f['actual_entsize']==g['rodata_entsize']
                 and f['forms']==cls['derived']['forms'] and all(g[k]==cls['geometry'][k] for k in
                 ('rodata_entsize_offset','build_id_offset','build_id_bytes','read_only_load','type','machine')) and
                 g['rodata_header'][:-1]==cls['geometry']['rodata_header'][:-1],'reciprocal raw ID/geometry changed')
        need({g['rodata_entsize'] for g,_,_ in paired}=={0,8} and
             sorted((a,b) for a,b,_ in v['ranges'])==sorted(((n:=cls['geometry']['build_id_offset'],n+32),(e:=cls['geometry']['rodata_entsize_offset'],e+1))),
             'reciprocal field positions changed')
        checked[key]=sha(p)
    return checked

def sources(data_root):
    tools=data_root/'elf-tools'
    geometry=load_module(tools/'geometry.py','q6_raw_geometry')
    retain=load_module(tools/'retain.py','original_retained_compare')
    oracle=load_module(tools/'recover_forms.py','original_rebuild_wild')
    primitive=None
    def digest_cmd(args,*,input,stdout,check):
        nonlocal primitive
        need(args==[str(oracle.here/'blake-stream')] and stdout==subprocess.PIPE and check is True,'unexpected oracle request')
        if primitive is None:primitive=llvm_primitive()
        return SimpleNamespace(stdout=primitive(input).encode())
    oracle.subprocess=SimpleNamespace(run=digest_cmd,PIPE=subprocess.PIPE)
    retain.oracle=lambda:oracle
    return geometry,retain

def scorer(raw,source_root):
    mods=source_root/'package-test-v3'
    geom,retain=sources(raw)
    native_base=mods.resolve().parents[1]/'lookup-cache/on-138/profile-mode-recovery'
    with relocated({native_base/'heldout-test-v6-stock-wild/forms.py':geom,native_base/'elf-forensics/retain.py':retain}):
        forms=load_module(mods/'forms.py','original_v3_forms')
    return forms

def compact(forms,root,kind='B'):
    """The true owner replays a cold CAS. A compact run authenticates the signed prior whole-file comparison."""
    ref=load(root/f'baseline-{kind}-forms.json')
    proofs=root/('form-proofs' if kind=='B' else 'form-proofs-A')
    return validate_saved(ref,proofs)

@contextmanager
def raw_file(cas,entry,scratch):
    h=entry['raw_sha256'];size=entry['raw_bytes'];need(HEX.fullmatch(h) and 0<size<=1<<30,'invalid raw size or digest')
    src=cas/(h+'.zst');s=src.lstat();need(stat.S_ISREG(s.st_mode) and src.resolve()==src and s.st_size==entry['compressed_bytes'] and sha(src)==entry['compressed_sha256'],'compressed raw image changed')
    with tempfile.TemporaryDirectory(dir=scratch,prefix='one-elf-') as t:
        path=Path(t)/h;actual=hashlib.sha256();count=0
        with subprocess.Popen(['zstd','-dq','-c','--',str(src)],stdout=subprocess.PIPE) as proc:
            with path.open('xb') as f:
                while data:=proc.stdout.read(1024*1024):
                    count+=len(data)
                    if count>size:proc.kill();raise ValueError('unexpected decompressed length')
                    f.write(data);actual.update(data)
            need(proc.wait()==0 and count==size and actual.hexdigest()==h,'decompressed raw image differs')
        need(src.stat().st_mtime_ns==s.st_mtime_ns and src.stat().st_ino==s.st_ino,'CAS file changed during reading')
        yield path

def deep(forms,root,cas,scratch,kinds):
    cas=Path(cas).resolve(strict=True);scratch=Path(scratch).resolve(strict=True)
    index=load(root/'cas-index.json')['files'];required=set()
    for kind in kinds:
        table=load(root/f'baseline-{kind}-forms.json')['roles'];base=root/('form-proofs' if kind=='B' else 'form-proofs-A')
        compact(forms,root,kind)
        max_item=max(v['record']['bytes'] for v in table.values())
        need(shutil.disk_usage(scratch).free>2*max_item+(256<<20),'insufficient temporary room for two uncompressed images')
        for role,obj in table.items():
            h=obj['record']['sha256'];required.add(h)
            with raw_file(cas,index[h],scratch) as p:
                need(forms.choices(p,h)==obj['class'],'independent exact rebuild did not reproduce '+role)
        for p in sorted(base.glob('*.json')):
            q=load(p);x,y=q['allowed_from_P' if kind=='A' else 'allowed_from_C'];required.update((x,y))
            with raw_file(cas,index[x],scratch) as a,raw_file(cas,index[y],scratch) as b:
                actual=forms.exact(a,b,x,y)
            need(json.loads(json.dumps(actual))==q['full_file'],'independent reciprocal complete-file comparison failed: '+q['role'])
    return {'complete':True,'kinds':list(kinds),'unique_raw_programs_rechecked':len(required),'total_unique_bytes':sum(index[k]['raw_bytes'] for k in required)}
