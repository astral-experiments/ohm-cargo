# One descriptive production settings edit on each matched compiler

Unzip in a new directory. From that directory run:

```sh
sha256sum -c SHA256SUMS
python3 -ISB describe.py physical > replay.json
cmp replay.json fanout.json
```

The raw trace records cover the entire ordinary Cargo invocation. The two recorded unscored builds each compiled just the uv library and its uv and uvx binaries in metadata-only mode. The earlier failed check benchmark carries zero pairs and p=1. Its warm library metadata differed. Both descriptive checks exited successfully before their diagnostic reader stopped on its cold-build requirement for a linker; the separately planned same-compiler B repeats therefore did not run.

metadata20.json is a structural analysis of the two earlier retained rmetas. root-metadata-list-cross-read.json records four real metadata-list reads. Their raw metadata files are identified by SHA-256 in metadata20.json and preserved outside this trace packet. Neither record establishes full metadata equality. The scientific screen uses raw equality.
