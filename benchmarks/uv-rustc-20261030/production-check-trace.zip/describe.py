"""Replay the two excluded descriptive checks from their complete strace and Cargo receipts."""
import argparse,hashlib,json,re
from pathlib import Path

ARM=('C','CZD')
ROLES={'53f598d9e9d08d6f':('uv','lib','crates/uv/src/lib.rs'),
       'b7930034503c9ff7':('uv','bin','crates/uv/src/bin/uv.rs'),
       'c5cb457bc33fc3b8':('uvx','bin','crates/uv/src/bin/uvx.rs')}
SRC=[('A','b2d774d9aceb2d39b7803eac4b3c6df7616f3b36','d0c1f7a550fd5a044e8cefaa7d7f5c4fb1282ea18030646de284f8d1c62b4ff6'),
     ('B','521d85a7905db07a59f44d004985ae8d133a1180','d7f68916bb2396ab7019fd3e47993f1185334ed55a0c1c095a07b9c7c04a8940')]
SHA=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def need(test,why):
    if not test:raise ValueError(why)
def arm(root,a):
    d=root/('diagnostic-'+a);b=d/'B';q=read(b/'command.json');disp=read(d/'disposition.json')
    need(q['exit']==0 and q['traced'] and q['arm']==a and not q['observer_faults']
         and disp['excluded'] and not disp['matched_own_repeat'] and disp['scored_rows']==0
         and not (d/'unchanged-B').exists(),'failed command or unexpected own-B repeat')
    need((d/'worker.log').read_text().rstrip().endswith('ValueError: missing actual cold Cargo, rustc or Wild'),'unexpected classifier error')
    for key,(stage,blob,h) in zip(('before_source','source'),SRC,strict=True):
        s=q[key];need(s['oid']=='c22e6b71933443e9cd299d4b6ac8de035ed4825b' and s['form']==stage and s['blob']==blob and s['sha256']==h and s['path']=='crates/uv/src/settings.rs','unexpected source')
    before=read(b/'stamps-before.json');after=read(b/'stamps-after.json')
    changed=sorted(k for k in before if before[k]!=after[k]);expected=sorted('debug/build/uv/'+x+'/fingerprint/invoked.timestamp' for x in ROLES)
    need(before.keys()==after.keys() and changed==sorted(q['changed_stamps'])==expected,'wrong modified Cargo unit set')
    log=(b/'cargo.stderr').read_bytes()
    need(SHA(log)==q['stderr_sha256'] and SHA((b/'cargo.stdout').read_bytes())==q['stdout_sha256']
         and re.findall(r'^\s*(?:Compiling|Checking) (\S+)',log.decode(),re.M)==q['packages']==['uv'],'different Cargo package ledger')
    parent={};exits=set();events=[];hashes={};decoder=json.JSONDecoder()
    for p in sorted(b.glob('exec.*')):
        pid=int(p.suffix[1:]);raw=p.read_bytes();hashes[p.name]=SHA(raw)
        for line in raw.decode().splitlines():
            if line.startswith(('clone(','clone3(','fork(','vfork(')):
                match=re.search(r' = ([1-9]\d*)$',line)
                if match:
                    child=int(match[1]);need(child not in parent,'duplicate child');parent[child]=pid
            if line.startswith('--- SIGCHLD ') and 'si_code=CLD_EXITED' in line and 'si_status=0,' in line:
                exits.add(int(re.search(r'si_pid=(\d+)',line)[1]))
            if line.startswith(('execve(','execveat(')) and line.rstrip().endswith('= 0'):
                need(line.startswith('execve('),'unknown successful exec');exe,n=decoder.raw_decode(line[7:])
                args,_=decoder.raw_decode(line[7+n+2:]);need(exe==args[0],'renamed argv0');events.append((pid,exe,args))
    root_calls=[e for e in events if e[2]==q['argv']]
    need(len(root_calls)==1 and q['actual_argv'][-7:]==q['argv'] and q['argv'][1:]==['check','--locked','--offline','-j8','-p','uv'],'not the exact native Cargo command')
    rootpid,exe,_=root_calls[0];sdk=Path(exe).parent;seen={}
    for pid,exe,args in events:
        if pid==rootpid:continue
        need(exe==str(sdk/'rustc') and pid in exits,'unknown successful program or compiler without successful wait status')
        ancestry=[pid]
        while ancestry[-1]!=rootpid:
            child=parent[ancestry[-1]];need(child not in ancestry,'cycle');ancestry.append(child)
        path=Path(args[args.index('--out-dir')+1]);key=path.parent.name;need(key not in seen and key in ROLES,'unknown or duplicate output')
        name,kind,source=ROLES[key]
        need(args[args.index('--crate-name')+1]==name and args[args.index('--crate-type')+1]==kind
             and [t for t in args if t.endswith('.rs')]==[source]
             and [t for t in args if t.startswith('--emit')]==['--emit=dep-info,metadata'],'different rustc invocation')
        seen[key]={'crate_name':name,'crate_type':kind,'source':source,'emit':'dep-info,metadata',
                   'pid':pid,'Cargo_ancestry':ancestry,'full_argv_sha256':SHA(json.dumps(args,separators=(',',':')).encode())}
    need(set(seen)==set(ROLES) and len(events)==4 and len(hashes)==len(parent)+1,'incomplete process census')
    side=disp['A_public_sidecar']
    need(side['present'] and side['matches_rustc_public'] and side['decoded']=={'version':1,'value':'39781a9f856cb75ef466c5dcf6cf8c2a'},'different public API sidecar')
    return {'driver_sha256':q['driver_sha256'],'Cargo_pid':rootpid,'Cargo_argv':q['argv'],'source':q['source'],'exit':q['exit'],
            'successful_execs':{'cargo':1,'rustc':len(seen),'linker':0,'other':0},'compiler_units':seen,'Cargo_packages':q['packages'],
            'all_stamp_count':len(before),'changed_stamps':changed,'raw_trace_files':hashes,'A_public_sidecar':side,'same_compiler_B_repeats':0}
def report(data):
    h=data/'outer-return.json';o=read(h)
    need(SHA(h.read_bytes())=='b800726e87d62056f4a055cd5dcc90f20e1e2358ae4cb877721696842ec64d61'
         and o['outer']=={'session':38456,'chunk':'cb2c7c','exit':0} and not o['remaining_workers'] and not o['foreign'],'wrong physical resource return')
    return {'resource_outer':o['outer'],'original_failed_prepare_outer_sha256':'4d8861b69b0998d69b4e02bffa7061893a7454ba55250f2f63f853464d34572b',
            'original_scored_pairs':0,'original_p':1,'timings_compared':False,'traces':{a:arm(data,a) for a in ARM},
            'observer_error':'The existing dirty-cold classifier requires a Wild exec. All three real rustc commands in each check emitted metadata only; no linker was invoked.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('physical',type=Path,nargs='?',default=Path(__file__).resolve().parents[1]/'physical')
    print(json.dumps(report(p.parse_args().physical),indent=2,sort_keys=True))
