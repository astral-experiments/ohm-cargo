# Reproduce the 14th comparison from fresh targets

Use Linux x86-64 with an otherwise idle CPU set, Python 3.11 or newer, `strace`, GNU `cp`, Git, a system LLVM library exporting BLAKE3, the two complete matched 65-file SDKs and an offline Cargo registry populated for the pinned uv checkout. Keep at least 122 GiB available beyond the two full A histories, one active target and the retained programs. The embedded `REBUILD.md` covers rebuilding the two drivers. The bare P compiler and CZD differ only in the compiler driver. CZD adds the proposed changes from Ohm Rust #270 and #275.

Extract `fourteen-reviewer.zip` into an empty directory. First verify the archive contents and the 14th comparison’s separate schedule. The self-test exercises a temporary Git repository, script SDKs, ELF fixtures and 12 synthetic pairs.

~~~sh
sha256sum -c FOURTEEN-SHA256SUMS
python3 -ISB fresh.py verify
python3 -ISB test_fourteen.py
~~~

Supply a complete uv Git clone containing commit `c22e6b71933443e9cd299d4b6ac8de035ed4825b` and the 0.12.0 tag. The workflow changes just the 62-line addition to `crates/uv/tests/tool/tool_list.rs` from uv #20770. It verifies the source blobs and that the test count drops from 181 to 180. The command is `cargo test --locked --offline -j8 -p uv --no-run`.

~~~sh
python3 -ISB fresh.py run \
  --uv-clone /path/to/uv --cargo-home /path/to/populated-cargo-home \
  --control-sdk /path/to/matched/P --candidate-sdk /path/to/matched/CZD \
  --run /path/to/new-private-run
python3 -ISB fresh.py score /path/to/new-private-run > independent-result.json
~~~

For locally built SDKs, add `--subjects /path/to/build/subjects.json`. The source and 65-file metadata must pass the included original SDK qualification. The input checkout and offline registry are copied. Every edited invocation starts by restoring the relevant arm’s unedited A checkpoint. The portable run builds both A histories from cold private targets on the reviewer’s filesystem. The controlled-host run reused the verified, never-edited P checkpoint from a stopped earlier attempt and built CZD's separately on tmpfs. Setup clocks, storage and unscored traced admissions are retained outside the measured intervals.

The first ordinary P A program set defines the allowed A forms before the second P repeat and all candidate outputs. The first P B defines the edited classes before CZD sees B. Both phases check all 17 complete program images, both CLI versions and 15 literal test inventories. A differing pair must reconstruct exactly in both directions from its observed images, including the entire Wild build ID. Each reported pair has two unwrapped foreground clocks. Both orders have six observations. The preregistered decision requires both order medians and the third-smallest paired ratio to reach 2, followed by the exact sign test against 2 and Holm correction across 14 comparisons.

The reviewer score reports its own raw times, ratios, medians and rank interval. Its 14-way calculation uses the authenticated 13 earlier decisions carried in the archive. An earlier failed attempt contributes p=1. Its historical observations enter only the multiple-comparison correction. No local output from an incomplete run supplies a new statistic. `fresh.py` selects the 14th schedule explicitly. `full_stack.py` in this archive is the original 12th workflow and reproduces its different assignments.
