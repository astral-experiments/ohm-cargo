"""Standalone analysis of raw clocks, products, stamp changes, source states and assigned orders."""
import json,re,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import inputs as x
sc=x.mod('registered_ordinary_two_x_score',x.G/'fresh-edit-trial/score.py')
def roster(row):return [row['packages'],row['changed_stamps']]
def record(d,arm,phase,p,trace):
    x.need(x.attest(d,trace)==x.load(d/'attestation.json'),'raw command or process/product evidence changed')
    library=x.load(d/'library.json');x.need(set(library)=={'file','archive'} and all(z['bytes']>=0 and len(z['device_inode'])==2 and
         (re.fullmatch('[0-9a-f]{64}',z['sha256'] or '') if trace else z['sha256'] is None) for z in library.values()),'missing separate library observation')
    r=x.load(d/'command.json');prod=x.load(d/'products.json');s=r['source'];before=x.load(d/'stamps-before.json');after=x.load(d/'stamps-after.json')
    x.need(r['arm']==arm and r['phase']==phase and r['source']['form']==phase and r['before_source']['form']=='A' and
           r['before_source']['blob']==p['source']['A_blob'] and s['oid']==p['source']['uv_base'] and s['path']==p['source']['source_path'] and
           s['ref']=='refs/heads/feature-A' and s['blob']==p['source'][phase+'_blob'] and s['sha256']==p['source'][phase+'_sha256'] and
           r['driver_sha256']==p['subjects'][arm]['driver_sha256'] and r['traced']==trace and r['exit']==0 and not r['observer_faults'] and
           r['argv'][1:]==p['argv'][1:] and r['argv'][0].endswith('/visible/sdk/bin/cargo') and
           r['argv']==(r['actual_argv'][-len(r['argv']):] if trace else r['actual_argv']) and
           (not trace or r['actual_argv'][0]=='/usr/bin/strace') and (r['after_write_close_ns'] is None if phase=='A' else r['after_write_close_ns']<=r['start_ns']) and r['end_ns']-r['start_ns']==r['elapsed_ns']>0,'different source, tool, timer, or process')
    x.need(all(x.sha(d/k)==h for k,h in r['raw'].items()) and set(r['raw'])=={'stamps-before.json','stamps-after.json','cargo.stdout','cargo.stderr'} and
           not (d/'cargo.stdout').stat().st_size and r['packages']==sorted(re.findall(r'^\s*(?:Compiling|Checking)\s+(\S+)',(d/'cargo.stderr').read_text(),re.M)) and
           r['changed_stamps']==sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)),'different stdout, stderr or dirty units')
    x.need(set(prod['programs'])=={'uv','uvx'} and all(z['path']=='debug/'+n and z['bytes']>0 and re.fullmatch('[0-9a-f]{64}',z['sha256']) for n,z in prod['programs'].items()) and
           prod['argv_and_exit']==x.load(x.SRC/'behavior-control.json')['observed']['cases'] and [prod['argv_and_exit'][k]['exit'] for k in ('uvx@pair','uvx@fallback','missing')]==[37,37,2] and
           all((d/(k+'-version.stdout')).read_text().strip()==prod['versions'][k] and not (d/(k+'-version.stderr')).stat().st_size for k in ('uv','uvx')) and
           x.load(d/'uv-detail.stdout')==prod['versions']['detail'] and prod['versions']['detail']['commit_info']['commit_hash']==s['oid'],'observable public artifacts or behavior changed')
    return r,prod
def compatible(A,B):
    x.need(A['programs']['uv']==B['programs']['uv'] and A['programs']['uvx']['sha256']!=B['programs']['uvx']['sha256'] and
           all(A[k]==B[k] for k in ('producer','versions','argv_and_exit')),'wrong binary changed, or a behavior changed')
def round(folder,order,pre,p,gold=None):
    stamp=x.load(folder/'order.json');x.need(stamp['B_order']==order and stamp['primer_order']==pre,'assignment changed')
    admitted=gold is None;clocks=[];p0=0;controls={};products={};identities=set();sources=[];selected=[]
    for phase,seq in [('A',pre),('B',order)]:
        for arm in seq:
            d=folder/arm/phase;r,prod=record(d,arm,phase,p,admitted and phase=='B')
            x.need(p0<r['start_ns'] and (phase=='A' or r['source']['mtime_ns']==stamp['B_mtime_ns']),'overlapping commands or changed B mtime');p0=r['end_ns']
            if phase=='A':
                q=x.load(d.parent/'incoming.json');a=p['archives'][arm];ids=tuple(q['identity'])
                x.need(q['manifest_sha256']==a['state']['manifest_sha256'] and q['archive_sha256']==a['sha256'] and ids!=tuple(a['archive_identity']) and ids not in identities,'wrong original A');identities.add(ids)
                x.need(x.load(d.parent/'retired.json')['identity']==list(ids),'private restoration not closed')
            if gold:x.need(gold['controls'][arm][phase]==roster(r) and gold['products'][phase]==prod,'different prior, dirty work, binary, execution or source')
            if phase in products:x.need(prod==products[phase],'different raw programs between arms')
            else:products[phase]=prod
            controls.setdefault(arm,{})[phase]=roster(r)
            if phase=='B':clocks.append((arm,r['elapsed_ns']));sources.append(r['source'])
            if admitted and phase=='B':
                proof=x.load(d/'mapped-driver.json');jobs=x.load(d/'roles.json');raw=x.load(d/'census.json');seen=x.load(d/'raw-mapped-drivers.json')
                traces=x.load(d/'trace-inventory.json');x.need(traces and traces=={f.name:x.sha(f) for f in sorted(d.glob('exec.*'))},'raw executed-process traces missing or changed')
                chosen=[z for z in raw['actual'] if z['role']=='compile' and p['source']['source_path'] in z['argv']]
                x.need(proof['actual_selected']>=1 and len(chosen)==1 and str(chosen[0]['pid']) in seen and chosen[0]['native_guard'] and
                       any(j['input']==p['source']['source_path'] and j['guard'] and not j['link_only'] for j in jobs['rustc']) and
                       any(k[1].endswith('/'+prod['producer']['uvx']) for k in jobs['wild']) and
                       x.load(d/'retained.json')['uvx']['raw_sha256']==prod['programs']['uvx']['sha256'],'unproved edited source or actual linker')
                selected.append(chosen[0]['argv'])
    if admitted:x.need(len(selected)==2 and selected[0]==selected[1],'different selected uvx compiler argv')
    compatible(products['A'],products['B']);x.need(sources[0]==sources[1],'distinct paired source fields')
    return {'controls':controls,'products':products,'clocks':dict(clocks),'last_ns':p0,'first_ns':x.load(folder/pre[0]/'A/command.json')['start_ns']}
def study(root,p):
    root=Path(root);a=round(root/'admission',p['admission_order'],p['admission_order'],p)
    pilot=round(root/'pilot',p['pilot_order'],p['pilot_primers'],p,a);x.need(a['last_ns']<pilot['first_ns'],'pilot overlaps admission');cl=pilot['clocks'];ratio=cl['C']/cl['CZD']
    values=[];last=pilot['last_ns']
    if ratio>=p['pilot_minimum']:
        for i,(order,prime) in enumerate(zip(p['pairs'],p['primers'],strict=True)):
            q=round(root/f'pair-{i:02d}',order,prime,p,a);x.need(last<q['first_ns'],'nonchronological pair');last=q['last_ns'];v=q['clocks'];values.append((order[0],v['C'],v['CZD']))
    x.need({f.name for f in root.glob('pair-*')}=={f'pair-{i:02d}' for i in range(len(values))},'extra or incomplete pairs')
    return {'admission_rosters':a['controls'],'public_programs':a['products'],'excluded_pilot':{'ratio':ratio,'clocks_ns':cl,'continues':ratio>=p['pilot_minimum']},'counted_pairs':len(values),'score':sc.score_times(values) if values else None,'scored_rows':len(values)*2,'raw_rows':[list(v) for v in values]}
def holm13(base,outcome,p):
    before=base['twelve'];names=p['family']['ordered_labels'];label=p['group'];x.need(set(before)==set(names)-{label},'incomplete earlier family')
    raw={n:z['raw_p'] for n,z in before.items()};new=outcome['score'];raw[label]=new['p_against_2']['two_sided_p'] if new else 1.;result={};prior=0.
    for i,n in enumerate(sorted(names,key=lambda n:(raw[n],n))):
        # Adding a comparison cannot decrease any earlier Holm adjusted p-value.
        prev=before.get(n);prior=max(prior,min(1.,(len(names)-i)*raw[n]));complete=prev['complete'] if prev is not None else new is not None
        gate=prev['confirmed'] if prev is not None else bool(new and new['individual_gate'])
        result[n]={'raw_p':raw[n],'adjusted_p':prior,'complete':complete,'confirmed':bool(complete and gate and prior<.05),'excluded':n in p['family']['permanently_excluded']}
    x.need(all(result[k]['raw_p']==1 and not result[k]['complete'] for k in p['family']['permanently_excluded']),'credited an excluded experiment')
    return result
