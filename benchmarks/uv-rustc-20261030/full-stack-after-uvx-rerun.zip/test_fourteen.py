"""Run the original complete synthetic package fixture under the actual fourteenth order and proof."""
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import fresh

def main():
    with fresh.configured() as (stack,scorer,doc,prior):
        # The immutable fixture hardcodes its old 12-label family size only once.
        path=HERE/'test_full_stack.py'
        text=path.read_text()
        before='assert len(twelve)==12 and all(twelve[k]'
        fresh.need(text.count(before)==1,'different inherited full-lifecycle test')
        module={'__file__':str(path),'__name__':'synthetic_fourteenth_full_package'}
        exec(compile(text.replace(before,'assert len(twelve)==14 and all(twelve[k]'),str(path),'exec'),module)
        captured={}
        def rank(scores):
            fresh.need(set(scores)=={fresh.NAME},'this distinct fixture supplies only its own new statistics')
            result=fresh.family(doc,prior,scores[fresh.NAME]);captured['family']=result;return result
        check=scorer.raw
        def observed(*args,**kwargs):
            value=check(*args,**kwargs)
            fresh.need([row[0] for row in value['raw_ns']]==fresh.order_witness(doc),'used old order')
            captured['observed']=value
            return value
        with tempfile.TemporaryDirectory(prefix='fourteen-offline-control-') as tmp,patch.object(scorer,'family',rank),patch.object(scorer,'raw',observed):
            result=module['main'](Path(tmp))
        fresh.need(captured['observed']['pairs']==12 and len(captured['family'])==14 and
                   captured['family']['P-to-CZD/package-test']['excluded'] and captured['family']['P-to-CZD/package-test']['raw_p']==1,
                   'incomplete new or credited failed series')
        return {**result,'order':fresh.order_witness(doc),'old_scope_remains_excluded':True,
                'source_sha256':fresh.SCIENCE,'source_commit':fresh.PUBLISHED,'prior_13_family_sha256':fresh.FAMILY}
if __name__=='__main__':print(json.dumps(main(),sort_keys=True,indent=2))
