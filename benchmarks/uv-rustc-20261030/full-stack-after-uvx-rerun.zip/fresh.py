"""Run or verify an independent, cold-seeded reproduction of the fourteenth package comparison."""
import ast
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import random
import sys
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SRC = HERE/'fourteen-original'
SCIENCE = '1328f629afc4776b8fc3a55cd2c590e40f90f5cf4eddbdb0c241cddf23d62621'
RELEASE = 'ffea2a95ec890dbdbfdaa6c90f6a672ba44f2023c9dc9e52ccabdc64d8ac423d'
FAMILY = '90f7db50244a870e8adc9f939a481714de769eec38b35424f804bad6c5bf87e9'
NAME = 'P-to-CZD/package-test-capacity'
PUBLISHED = 'bac6e783130f95c0ac78b3255f468a0fddbcc4fb'
BASE_MANIFEST = '1dcc9c6801453863c490f7840d9188ab12a4ff4d13eb8e000f92d24436857d59'

def need(condition, reason):
    if not condition:
        raise ValueError(reason)

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def trusted():
    """Verify the complete original kit and the actual published input before importing its runner."""
    need(sha(SRC/'inherited-files.json') == BASE_MANIFEST, 'wrong inherited source manifest')
    parents = read(SRC/'inherited-files.json')
    need(len(parents)==81 and all(sha(HERE/p)==h for p,h in parents.items()), 'old standalone runner or its inputs changed')
    need(sha(SRC/'protocol.json')==SCIENCE and sha(SRC/'registration.json')==RELEASE and
         sha(SRC/'production-family.json')==FAMILY, 'wrong prospective definition, operational registration or signed prior family')
    reg = read(SRC/'registration.json')
    pub = read(SRC/'remote-retry-protocol.json')
    doc = read(SRC/'protocol.json')
    need(pub['commit']==PUBLISHED and pub['remote_files']['full-stack-after-uvx-protocol.json']['sha256']==reg['science']==SCIENCE and
         reg['production_family_sha256']==FAMILY and reg['files']['../production-uvx-bins/replay.py']==sha(SRC/'thirteen-math.py'),
         'wrong published source or original numerical formula')
    prior = read(SRC/'production-family.json')
    names = doc['family']['ordered_labels']
    need(prior['own_outer_sha256']==reg['production_outer_sha256'] and prior['native_outer']=={'session':36405,'chunk':'f68c80','exit':0} and
         not prior['pooled'] and set(names[:-1])==set(prior['thirteen']) and len(names)==14 and names[-1]==NAME and
         all(prior['thirteen'][k]['raw_p']==1 and not prior['thirteen'][k]['complete'] for k in doc['family']['permanently_excluded']),
         'different earlier experiments, exclusions or permissions')
    return doc, prior

@contextmanager
def configured():
    doc, prior=trusted()
    sys.path.insert(0,str(HERE))
    import full_stack as stack
    import full_stack_score as numerical
    original=stack.plan()
    pairs=[['P','CZD'] for _ in range(6)]+[['CZD','P'] for _ in range(6)]
    random.Random(doc['order_seed']).shuffle(pairs)
    need(doc['base_study_sha256']==stack.SCIENCE and doc['scope']==NAME and doc['pairs']==pairs and pairs!=original['pairs'] and
         not doc['efficacy_pilot'] and all(doc[k]==original[k] for k in ('uv','ordinary_argv','subjects','expected_reported_test_roles')),
         'different edit, normal job, compiler, programs or order')
    resolved={**original,**doc,'name':NAME}
    # The inherited reader supplies the complete native protocol when verifying real SDKs.
    with patch.multiple(stack,plan=lambda:resolved,SCOPE=NAME,SCIENCE=SCIENCE,REGISTRATION=RELEASE):
        yield stack,numerical,resolved,prior

def family(doc, prior, result):
    """Apply the original general Holm function to the existing 13 cases and this separate reproduction."""
    source=SRC/'thirteen-math.py'
    functions=[n for n in ast.parse(source.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='holm13']
    need(len(functions)==1,'registered correction missing')
    scope={'x':SimpleNamespace(need=need)}
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),scope)
    return scope['holm13']({'twelve':prior['thirteen']},{'score':result},{'family':doc['family'],'group':NAME})

def order_witness(doc):
    return [arm[0] for arm in doc['pairs']]

def main():
    if len(sys.argv)<2 or sys.argv[1] not in ('verify','run','score'):
        raise SystemExit('fresh.py verify | run --uv-clone ... --cargo-home ... --control-sdk ... --candidate-sdk ... --run ... | score RUN')
    command=sys.argv.pop(1)
    with configured() as (stack,numerical,doc,prior):
        if command=='verify' and len(sys.argv)==1:
            ans={'science_sha256':SCIENCE,'registration_sha256':RELEASE,'source_commit':PUBLISHED,'control':'P','candidate':'CZD',
                 'ordinary_argv':doc['ordinary_argv'],'comparison':NAME,'first_arm':order_witness(doc),'score_family':14,'efficacy_pilot':False}
        elif command=='run':
            with patch.object(stack,'print',lambda *_:print('Completed the independent reproduction. Use fresh.py score RUN.'),create=True):
                stack.main()
            return
        elif command=='score' and len(sys.argv)==2:
            raw=numerical.raw(Path(sys.argv[1]).resolve())
            need(raw['pairs']==12 and [row[0] for row in raw['raw_ns']]==order_witness(doc),'missing true independently restored arms')
            ans={'scope':'fresh independent reproduction with the original 13 comparison inputs','new':raw,
                 'fourteen':family(doc,prior,raw['summary']),'prior_scientific_returns_sha256':FAMILY,'pooled':False}
        else:
            raise SystemExit('unexpected reviewer arguments')
        print(json.dumps(ans,sort_keys=True,indent=2))

if __name__=='__main__':main()
