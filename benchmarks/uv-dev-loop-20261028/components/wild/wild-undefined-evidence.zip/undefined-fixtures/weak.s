.global _start
.weak missing_symbol
_start:
  movabs $missing_symbol, %rax
  ret
