import json, subprocess,sys
from pathlib import Path
d=Path(__file__).resolve().parent
w=d.parents[1]
def run(name,binary):
 for case,inputs,opts,code,diagnostic in [
  ('error',['strong'],[],1,'Undefined symbol'),
  ('warning',['strong'],['--warn-unresolved-symbols'],0,'Undefined symbol'),
  ('ignore',['strong'],['--unresolved-symbols=ignore-all'],0,None),
  ('ignore-objects',['strong'],['--unresolved-symbols=ignore-in-object-files'],0,None),
  ('weak',['weak'],[],0,None),
  ('defined-absolute',['abs','abs-def'],[],0,None),
 ]:
  out=d/'out'
  p=subprocess.run([binary,'--threads=1','--no-fork','--entry=_start','-o',str(out),*opts,*[str(d/f'{i}.o') for i in inputs]],capture_output=True)
  (d/f'{name}-{case}.log').write_bytes(p.stderr)
  assert p.returncode==code,(case,binary,p.returncode,p.stderr)
  assert (b'Undefined symbol' in p.stderr) == (diagnostic is not None),(case,p.stderr)
  if not code: (d/f'{name}-{case}.bin').write_bytes(out.read_bytes())
  if name!='base':
   assert p.stderr==(d/f'base-{case}.log').read_bytes(),(case,p.stderr)
   if not code: assert out.read_bytes()==(d/f'base-{case}.bin').read_bytes(),case
  print(case,code)
run(*sys.argv[1:])
