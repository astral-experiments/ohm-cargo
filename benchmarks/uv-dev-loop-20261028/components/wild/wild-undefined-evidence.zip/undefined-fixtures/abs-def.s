.global absolute_symbol
.set absolute_symbol, 42
