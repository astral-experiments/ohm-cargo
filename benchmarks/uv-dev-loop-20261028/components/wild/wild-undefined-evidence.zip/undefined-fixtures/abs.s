.global _start
_start:
  movabs $absolute_symbol, %rax
  ret
