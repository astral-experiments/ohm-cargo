.global _start
_start:
  call missing_symbol
  ret
