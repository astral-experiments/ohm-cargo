"""Run balanced ABBA blocks; each pair rebuilds exactly the same edited source."""
import argparse,csv,json,os,random,subprocess
from pathlib import Path

ap=argparse.ArgumentParser(); ap.add_argument('--label',default='undefined'); ap.add_argument('--blocks',type=int,default=4); ap.add_argument('--serial',action='store_true'); ap.add_argument('--seed',type=int,default=17851)
ap.add_argument('--run-id',default='');ap.add_argument('--block-offset',type=int,default=0)
args=ap.parse_args()
if args.run_id=='-holdout':
 args.blocks=8
 args.block_offset=4
 args.seed=381443
n=Path(__file__).resolve().parent;p=n.parent;w=p.parent
output=n/f"paired-{args.label}-{'serial' if args.serial else 'normal'}";output=output.with_name(output.name+args.run_id);output.mkdir(exist_ok=True)
orders=[0,1]*(args.blocks//2+1);orders=orders[:args.blocks];random.Random(args.seed).shuffle(orders)
expected={'uv','uvx','uv-23905aefc33b1c4d','uv-c84366b26c530121','uvx-141090d4fffe584e'}
with (output/'samples.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['block','position','source','arm','unit','threads','instructions']);f.flush()
 for block,first in enumerate(orders,start=args.block_offset):
  arms=['baseline',args.label];second=1-first
  for pos,arm in enumerate(arms[j] for j in (first,second,second,first)):
   edit=subprocess.check_output([str(n/'toggle')],text=True).strip()
   name=f'{block}-{pos}-{arm}-{edit}';d=output/name;d.mkdir()
   env={**os.environ,'PATH':f"{n/'tool'}:{os.environ['PATH']}",'OHM_PRIVATE_WILD':str(w/'bin'/f'wild-{arm}'),'OHM_WILD_LOG':str(d),'OHM_WILD_COUNT':'1'}
   if args.serial:env['OHM_WILD_SERIAL']='1'
   log=output/f'{name}.log'
   with log.open('w') as stream:subprocess.run([str(p/'run'),'test','--no-run'],env=env,stdout=stream,stderr=stream,check=True)
   assert 'Finished ' in log.read_text(),log
   units=set();total=0
   for file in sorted(d.glob('*.outpath')):
    unit=Path(file.read_text().strip()).name
    assert unit not in units;units.add(unit)
    result=json.loads(file.with_suffix('.log').read_text().rsplit('DynamoRIO ',1)[1])
    count=result['instructions'];total+=count
    writer.writerow([block,pos,edit,arm,unit,len(result['threads'])-1,count])
   assert units==expected,(units,name)
   writer.writerow([block,pos,edit,arm,'TOTAL','',total]);f.flush()
   print(block,pos,edit,arm,total,flush=True)
