import argparse,csv,hashlib,itertools,json,math,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('directory');ap.add_argument('--complete',action='store_true');args=ap.parse_args();directory=Path(args.directory)
rows=list(csv.DictReader((directory/'samples.csv').open()));blocks={}
for r in rows:
 if r['unit']=='TOTAL': blocks.setdefault(int(r['block']),{})[int(r['position'])]=(r['arm'],r['source'],int(r['instructions']))
plan=json.loads((p/'fresh-confirmatory-plan.json').read_text())
if args.complete: assert len(blocks)==plan['blocks'] and all(len(bs)==4 for bs in blocks.values())
out=[]
for block,b in sorted(blocks.items()):
 if len(b)!=4:continue
 assert len(set((a,e) for a,e,_ in b.values()))==4
 order=''.join('A' if b[i][0]=='baseline' else 'B' for i in range(4))
 if 'confirmatory' in directory.name: assert order==plan['order_by_block'][block]
 a=sum(v for k,e,v in b.values() if k=='baseline');c=sum(v for k,e,v in b.values() if k=='undefined')
 out.append({'block':block,'order':order,'baseline_instructions':a,'candidate_instructions':c,'gain':1-c/a})
gs=[b['gain'] for b in out];n=len(gs);wins=sum(g>0 for g in gs);nz=sum(g!=0 for g in gs)
result={'blocks':out,'complete_blocks':n,'wins':wins,'median_percent':100*statistics.median(gs) if n else None,'min_percent':100*min(gs) if n else None,'max_percent':100*max(gs) if n else None,'two_sided_sign_p':min(1,2*sum(math.comb(nz,j) for j in range(min(wins,nz-wins)+1))/2**nz),'link_processes':sum(r['unit']!='TOTAL' for r in rows),'commands':sum(r['unit']=='TOTAL' for r in rows)}
if args.complete:
 with (directory/'block-results.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=out[0]);w.writeheader();w.writerows(out)
 (directory/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
