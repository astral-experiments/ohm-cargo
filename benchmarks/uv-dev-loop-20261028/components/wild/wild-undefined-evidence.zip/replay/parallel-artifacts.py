import csv,hashlib,mmap,os,struct,subprocess
from pathlib import Path
d=Path(__file__).resolve().parent;p=d.parent;w=p.parent
def hashes(path):
 with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_COPY) as m:
  raw=hashlib.sha256(m).hexdigest()
  hdr=struct.unpack_from('<HHIQQQIHHHHHH',m,16)
  off,sz,n,names=hdr[5],hdr[10],hdr[11],hdr[12]
  namestart=struct.unpack_from('<Q',m,off+sz*names+24)[0]
  ent=None
  for i in range(n):
   sh=off+sz*i;nameoff=namestart+struct.unpack_from('<I',m,sh)[0]; name=m[nameoff:m.find(b'\x00',nameoff)]
   if name==b'.rodata': ent=struct.unpack_from('<Q',m,sh+56)[0];m[sh+56:sh+64]=bytes(8)
   if name==b'.note.gnu.build-id':
    addr,size=struct.unpack_from('<QQ',m,sh+24)
    namesize,descsize,typ=struct.unpack_from('<III',m,addr)
    assert typ==3 and m[addr+12:addr+12+namesize]==b'GNU\0'
    desc=addr+12+(namesize+3)//4*4
    m[desc:desc+descsize]=bytes(descsize)
  assert ent is not None
  return raw,hashlib.sha256(m).hexdigest(),ent
with (d/'parallel-artifacts.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow(['capture','round','arm','sha256','normalized_sha256','rodata_entsize'])
 for i in [3,2,0]:
  expected=hashes(d/f'source-{i}')
  wr.writerow([i,-1,'serial-baseline',*expected])
  for j in range(3):
   for arm in ['baseline','undefined'] if j%2==0 else ['undefined','baseline']:
    target=d/f'parallel-{i}-{arm}'
    cmd=[str(p/'captured/inputs'/str(i)/'run-with'),str(w/'bin'/f'wild-{arm}'),'--','--dynamic-linker','/lib64/ld-linux-x86-64.so.2','--no-fork']
    subprocess.run(cmd,env={**os.environ,'OUT':str(target)},check=True)
    hh=hashes(target);wr.writerow([i,j,arm,*hh]);f.flush()
    assert hh[1]==expected[1],(i,j,arm,expected,hh)
