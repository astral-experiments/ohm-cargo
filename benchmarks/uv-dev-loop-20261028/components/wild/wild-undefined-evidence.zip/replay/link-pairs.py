import argparse,csv,hashlib,json,os,random,re,subprocess,time
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('--label',required=True)
ap.add_argument('--capture',type=int,required=True)
ap.add_argument('--pairs',type=int,required=True)
ap.add_argument('--threads',type=int,default=1)
ap.add_argument('--seed',type=int,default=143871)
args=ap.parse_args()
d=Path(__file__).resolve().parent;p=d.parent;w=p.parent
label=args.label; i=args.capture
path=d/f'paired-{label}-{i}-{args.threads}'
path.mkdir(exist_ok=True)
target=d/f'paired-out-{label}-{i}-{args.threads}'
seed=args.seed+i
ref=(d/f'source-{i}').read_bytes()
expected=hashlib.sha256(ref).digest()
arms=['baseline','candidate']
orders=([0,1]*((args.pairs+1)//2))[:args.pairs]
random.Random(seed).shuffle(orders)
with (path/'samples.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['pair','position','arm','instructions','sha256']);f.flush()
 for pair,first in enumerate(orders):
  for pos,arm in enumerate([arms[first],arms[1-first]]):
   binary=w/'bin'/('wild-baseline' if arm=='baseline' else f'wild-{label}')
   cmd=[str(p/'captured/inputs'/str(i)/'run-with'),'python','-B',str(w/'dynamorio/count.py'),'--',str(binary),'--','--dynamic-linker','/lib64/ld-linux-x86-64.so.2','--no-fork']
   if args.threads:cmd.append(f'--threads={args.threads}')
   log=path/f'{pair}-{pos}-{arm}.log'
   with log.open('w') as l:
    subprocess.run(cmd,env={**os.environ,'OUT':str(target)},stdout=l,stderr=l,check=True)
   count=json.loads(re.findall(r'DynamoRIO (.+)$',log.read_text(),re.M)[-1])['instructions']
   with target.open('rb') as fd:digest=hashlib.file_digest(fd,'sha256').digest()
   assert digest==expected,(target,arm,digest.hex(),expected.hex())
   writer.writerow([pair,pos,arm,count,digest.hex()]);f.flush()
   print(i,pair,arm,count,flush=True)
