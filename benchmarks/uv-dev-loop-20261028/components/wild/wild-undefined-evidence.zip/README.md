# Reproduce the Wild relocation diagnostic measurement

The baseline is Wild 0.11.0 at `e856d81f6683cad80b9fe0ebf1a0c3c403c6fe11`. Both the upstream tag and the `charlie/wild-0-11-base` branch of `astral-sh/ohm-wild` point there. The compiler used to build both linker binaries was Rust 1.99.1 (`58cf8f9c3`). Build with `cargo build --release --locked -p wild-linker -j8`, save `target/release/wild`, apply `wild-undefined-report.patch`, then build and save the candidate with the same command.

Check out uv at `c22e6b71933443e9cd299d4b6ac8de035ed4825b`. Use Ohm 1.99.0-17 cargo and rustc (cargo at `a0c7d08c898d3fdff992f2f431dec57d2486add2`, rustc at `bfa236f639034f61ec884c15bd1f4e0b75e508ac`). Seed a private target directory by running `cargo test --no-run --locked --offline -j16` from the workspace root with all dependencies fetched. In the scratch checkout of uv, reverse the two equivalent boolean clauses in `crates/uv/src/install_source.rs` from `component == cellar && next == formula` to `next == formula && component == cellar`. Run the same command with `WILD_SAVE_BASE=/absolute/path/to/captured/inputs`. This edit triggers four cache-based relinks and a regular unit-test link.

Wild emits a `run-with` script and a copy of each link's inputs. Use each script's “Original output file” comment to identify the desired link. Capture indexes are assigned as link processes start and may vary. Here capture 3 is the 319,109,224-byte uv executable needed by integration tests, capture 0 the uv library's test harness, and capture 2 the uv binary's test harness. Replay with the original interpreter path, which Wild otherwise rewrites to an absolute path in the saved inputs.

```sh
OUT=/absolute/path/to/result /absolute/path/to/capture/run-with \
    /absolute/path/to/wild -- --dynamic-linker /lib64/ld-linux-x86-64.so.2 \
    --no-fork --threads=1
```

The `--` separates the process command from additional linker flags. To count instructions, pass DynamoRIO 11.3.0-1's instruction counter or Valgrind 3.22's Callgrind before the linker executable. The Callgrind command is shown below.

```sh
OUT=/absolute/path/to/result /absolute/path/to/capture/run-with \
    valgrind --tool=callgrind --callgrind-out-file=/absolute/path/to/result.cg \
    /absolute/path/to/wild -- --dynamic-linker /lib64/ld-linux-x86-64.so.2 \
    --no-fork --threads=1
```

For the paired DynamoRIO measurements, balance baseline-first and candidate-first orders. Hash each result against the single-thread baseline before recording the count. The actual command measurement instead toggles the equivalent edit before every normal `cargo test --no-run --locked --offline -j16`. A private cc wrapper replaces just the bundled Wild directory in the original `-B` argument. Its linker shim launches the selected binary under DynamoRIO with `--no-fork` and preserves the GNU jobserver file descriptors. After a separate four-block exploratory cohort, eight balanced ABBA/BAAB blocks match both linker binaries on each of the two source states. The fresh cohort uses seed 274997 in the order ABBA, BAAB, ABBA, ABBA, BAAB, BAAB, ABBA, BAAB. For each block, sum the two command totals per arm and compute one minus the candidate sum divided by the baseline sum. Apply the two-sided sign test only to these eight block effects. Sum all threads of the five observed Wild processes, checking that the same five targets appear each time. The aggregate measures linker work performed by the real Cargo command.

The replay raw counts are in `replay/paired-undefined-3-1/samples.csv`, `replay/paired-undefined-0-1/samples.csv`, and `replay/paired-undefined-2-1/samples.csv`. The real-command samples and observed thread counts are in `native-instrument/paired-undefined-normal-confirmatory/samples.csv`. The earlier exploratory cohort is in `native-instrument/paired-undefined-normal/samples.csv`. Native default-thread replay checks are in `replay/parallel-artifacts.csv`. The six ELF scenarios in `undefined-fixtures/check.py` check both exit status and identical diagnostics, and compare produced executables byte for byte.
