# CI formatter verification

The released private Ohm Rust fork runs `./x fmt --check` with rustfmt from `nightly-2026-07-19` and the top-level `rustfmt.toml`. The equivalently rooted isolated fixture here ran the release's actual bootstrap `./x fmt --check --all` using that exact nightly formatter, the original rustfmt.toml and frozen `library/std/src/path.rs`. Its root and library Cargo manifests supplied local placeholder workspaces for bootstrap's metadata query. The CI formatter arguments, Rust code, configuration and file pathname stayed identical.

The 149-file fixture passes (`x-format-frozen.log`). A deliberate extra space in the helper declaration was detected at this same path (`x-format-probe.log`). The original guarded source was restored, hashed and checked again. This verifies the layout of the proposed change. Full-repo tidy and downstream compiler tests run separately in GitHub Actions.

| Input | Value |
| --- | --- |
| Ohm Rust commit | `bfa236f639034f61ec884c15bd1f4e0b75e508ac` |
| Formatter | `rustfmt 1.9.0-nightly (eff8269f79 2026-07-18)` |
| CI formatter archive SHA-256 | `dd37b359e3a7cf43bbc089adb8b973ec8b7ba8acc81d5f43d4e0f972db065176` |
| CI compiler runtime archive SHA-256 | `90bab80040b8a12418699e285f44296b89baf4dc2e7f36f54482bc94a17d71f2` |
| Repository `rustfmt.toml` SHA-256 | `38cce677828e31bf19a88925388eb05611271012c4d6076d0d8ea6e8a54ad1ab` |
| Guarded path.rs SHA-256 | `2a7b704c60ddf54ac1d9f82a9a50aa3edefe4a0e04b0f8fd3531a1d565b1f444` |
