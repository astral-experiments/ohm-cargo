use std::{ffi::OsStr, os::unix::ffi::OsStrExt, path::{Components, Path}};

fn assert_order(a: &[u8], b: &[u8]) {
    use std::convert::identity;
    let p = Path::new(OsStr::from_bytes(a));
    let q = Path::new(OsStr::from_bytes(b));
    let check_components = |x: Components<'_>, y: Components<'_>| {
        let expected = Iterator::cmp(x.clone().map(identity), y.clone().map(identity));
        assert_eq!(Ord::cmp(&x, &y), expected, "component order: {a:?}, {b:?}");
        expected
    };
    let (mut x, mut y) = (p.components(), q.components());
    assert_eq!(p.cmp(q), check_components(x.clone(), y.clone()), "path order: {a:?}, {b:?}");
    x.next();
    check_components(x.clone(), y.clone());
    y.next();
    check_components(x.clone(), y.clone());
    x.next_back(); y.next_back();
    check_components(x, y);
}

#[test]
fn exhaustive_path_spellings() {
    let mut paths = vec![Vec::new()];
    let mut start = 0;
    for _ in 0..4 {
        let end = paths.len();
        for n in start..end { for c in [b'/', b'.', b'a', 0xff] { let mut next = paths[n].clone(); next.push(c); paths.push(next); } }
        start = end;
    }
    for a in &paths { for b in &paths { assert_order(a,b); } }
    for base in [b"ab/cdef/ghij/.././klmno///".as_slice(), b"/abcdefg//../hijk/./lmnopqr.", b"/\xff\x80/.././/\x00b/../zzz"] {
        for i in 0..=base.len() { for j in 0..=base.len() { assert_order(&base[..i], &base[..j]); } }
    }
}

#[test]
fn word_boundaries_with_all_bit_positions() {
    let input = (0..128).map(|i| if i % 7 == 0 { b'/' } else { 37u8.wrapping_mul(i) }).collect::<Vec<_>>();
    let mut right = [0u8;128];
    for a_offset in 0..16 { for b_offset in 0..16 {
        for n in [0,1,4,7,8,9,15,16,17,31,32,33,63,64,65] {
            let a = &input[a_offset..a_offset+n];
            let b = &mut right[b_offset..b_offset+n];
            b.copy_from_slice(a);
            assert_order(a,b);
            for first in 0..n { for bit in 0..8 {
                b[first] ^= 1<<bit;
                if first+1<n { b[first+1] ^= 0xff; }
                assert_order(a,b);
                if first+1<n { b[first+1] ^= 0xff; }
                b[first] ^= 1<<bit;
            } }
        }
    } }
}

#[test]
fn captured_uv_btree_pairs() {
    let paths: Vec<_> = include_bytes!("../paths.dat").split(|&c| c==b'\n').collect();
    for pair in include_bytes!("../pairs.bin").chunks_exact(4) {
        let index = |a,b| usize::from(u16::from_le_bytes([a,b]));
        assert_order(paths[index(pair[0],pair[1])], paths[index(pair[2],pair[3])]);
    }
}
