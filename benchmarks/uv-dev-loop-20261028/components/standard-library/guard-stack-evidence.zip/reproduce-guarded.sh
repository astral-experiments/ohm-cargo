#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 4 ]]; then
    printf 'usage: %s CARGO_REPO RELEASED_OHM_SYSROOT NEW_SCRATCH GUARDED_PATCH\n' "$0" >&2
    exit 2
fi
repository=$(realpath "$1")
toolchain=$(realpath "$2")
patch_file=$(realpath "$4")
[[ ! -e "$3" ]] || { printf 'scratch path already exists\n' >&2; exit 2; }
mkdir -p "$3"
lab=$(cd "$3" && pwd -P)
release_cargo=a0c7d08c898d3fdff992f2f431dec57d2486add2
release_rust=bfa236f639034f61ec884c15bd1f4e0b75e508ac
host=x86_64-unknown-linux-gnu
mkdir -p "$lab"/{cargo-src,bin,logs,cargo-home}
[[ $("$toolchain/bin/rustc" -Vv) == *"$release_rust"* ]]
[[ $("$toolchain/bin/cargo" -Vv) == *"$release_cargo"* ]]
printf '%s  %s\n' ff2dcc74dfc56fb366422c29de08dc1baae4ec4efc91171069358b838177b795 "$patch_file" | sha256sum -c -
git -C "$repository" archive "$release_cargo" | tar -xf - -C "$lab/cargo-src"
git -C "$repository" show -s --format='%H%n%h%n%cs' --abbrev=9 "$release_cargo" > "$lab/cargo-src/git-commit-info"
cp -a "$toolchain/lib/rustlib/src/rust/library" "$lab/library"
export CARGO_HOME="$lab/cargo-home" CARGO_TARGET_DIR="$lab/target"
export RUSTC="$toolchain/bin/rustc" RUSTDOC="$toolchain/bin/rustdoc" PATH="$toolchain/bin:$PATH"
export __CARGO_TESTS_ONLY_SRC_ROOT="$lab/library"
export CARGO_PROFILE_RELEASE_LTO=thin CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_OPT_LEVEL=3
export CARGO_PROFILE_RELEASE_INCREMENTAL=false CARGO_PROFILE_RELEASE_DEBUG=false CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS=false CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS=false
export LIBZ_SYS_STATIC=1 CARGO_TERM_COLOR=never CFG_RELEASE=1.99.0-dev CFG_RELEASE_CHANNEL=dev CFG_VER_DESCRIPTION=ohm-1.99.0-17
for variant in base guard; do
    opts=()
    if [[ $variant == guard ]]; then
        mv "$lab/target" "$lab/preserved-baseline-target"
        (cd "$lab" && patch --forward --fuzz=0 -p1 < "$patch_file")
        opts+=(--offline)
    fi
    cd "$lab/cargo-src"
    "$toolchain/bin/cargo" -Zohm-defaults=no -Zbuild-std build --target "$host" --release --locked --bin cargo --features ohm-defaults,all-static -j6 -vv "${opts[@]}" > "$lab/logs/$variant.build.log" 2>&1
    cp "$lab/target/$host/release/cargo" "$lab/bin/$variant"
    "$lab/bin/$variant" -Vv > "$lab/logs/$variant.version"
    ldd "$lab/bin/$variant" > "$lab/logs/$variant.ldd"
    libs=("$lab/target/$host/release/build/std"/*/out/libstd-*.rlib)
    [[ ${#libs[@]} == 1 && -f ${libs[0]} ]]
    cp "${libs[0]}" "$lab/bin/$variant-libstd.rlib"
done
for suffix in '' -libstd.rlib; do
    if cmp -s "$lab/bin/base$suffix" "$lab/bin/guard$suffix"; then
        printf 'identical artifacts: %s\n' "$suffix" >&2; exit 1
    fi
done
(cd "$lab/bin" && sha256sum base guard base-libstd.rlib guard-libstd.rlib) | tee "$lab/logs/SHA256SUMS"
