# Ohm `std::path::compare_components` experiment

The published Linux Cargo executable defines `std::path::compare_components` and embeds `/rustc/bfa236f639034f61ec884c15bd1f4e0b75e508ac/library/std/src/path.rs`. Its dynamic dependencies are `libgcc_s`, `libm`, `libc` and the loader. The distributed `path.rs` content has the same Git blob hash as the compiler revision, `be216d87f324116320faa7f0111526dfdb285433`. The release bootstrap builds a stage-2 distribution, uses its stage-1 compiler and in-tree target std to build Cargo, and statically links std into Cargo. [Release bootstrap](https://github.com/astral-sh/ohm/blob/fdf90406638cacb725178ee17e67957f7bd662ca/release/bootstrap.toml#L1), [bootstrap Cargo tool build](https://github.com/astral-sh/ohm-rust/blob/bfa236f639034f61ec884c15bd1f4e0b75e508ac/src/bootstrap/src/core/build_steps/tool.rs#L849-L863), [tool sysroot selection](https://github.com/astral-sh/ohm-rust/blob/bfa236f639034f61ec884c15bd1f4e0b75e508ac/src/bootstrap/src/core/builder/cargo.rs#L715-L728).

The shared-prefix fast path came from [rust-lang/rust#86898](https://github.com/rust-lang/rust/pull/86898). The open `Components` refactor splits prefixed and prefixless path handling and revises adjacent Unix comparison logic. At its screened head `c3ba843afa772f5add708aa8ab16ad6641dc8df1`, both paths still use scalar comparison and mention a vectorizable first difference as future work. Any upstream rebase would need to adapt the call site to those separate implementations. [Prefixless refactor](https://github.com/rust-lang/rust/blob/c3ba843afa772f5add708aa8ab16ad6641dc8df1/library/std/src/sys/path/nonprefixed_paths.rs#L377-L403), [prefixed refactor](https://github.com/rust-lang/rust/blob/c3ba843afa772f5add708aa8ab16ad6641dc8df1/library/std/src/sys/path/prefixed_paths.rs#L366-L378).

`std-path-mismatch.patch` replaces the raw byte scan. Equal native-word-sized chunks skip several bytes at once. For an unequal chunk, `usize::from_le_bytes` maps the first input byte to the least-significant byte on every target. The XOR therefore has its first nonzero byte at `trailing_zeros() / 8` on little- and big-endian machines. Shared tails smaller than a word retain bytewise comparison. The helper returns exactly the prior `Option<usize>`, including `None` when either slice is a byte prefix of the other. `as_chunks` creates byte arrays with alignment 1 and the code uses no unsafe operations. Backtracking and the final normalized component comparison keep their original code.

## Isolated instruction counts

`prepare.py` reads 74 real warm uv output `.d` files. Their 9,586 inputs comprise 535 distinct path spellings. Since the files already sort the paths and cannot reveal the original insertion sequence, the screen uses a fixed shuffle of each root's inputs. `screen capture` inserts those inputs into Rust's `BTreeSet`, delegates ordering to `Path::cmp`, and records 93,550 comparison operand pairs. The 1st, 50th and 99th percentiles of shared byte prefix are 86, 88 and 113. `sources.sha256`, `paths.dat`, `roots.dat` and `pairs.bin` freeze the inputs and comparison schedule.

`count.py` runs Cachegrind with collection disabled during input preparation and enabled only inside the loop over the raw mismatch operation. The loop checksum consumes the result, and the executable and loop trip counts stay identical between implementations. The table shows `Ir` for each of the three counterbalanced pairs, which gave identical counts within each variant. The benchmark records work done on these comparison operands. The complete Cargo workloads are measured separately.

| Input | Comparisons | Scalar `Ir` | Word `Ir` | Change |
| --- | ---: | ---: | ---: | ---: |
| uv BTree pairs | 93,550 | 71,642,090 | 10,666,478 | −85.111% |
| 14 short path spellings, all pairs | 98,000 | 2,400,553 | 2,347,051 | −2.229% |
| Long paths differing at byte zero | 96,000 | 2,411,303 | 2,506,551 | +3.950% |
| Equal long paths, disjoint allocations | 96,000 | 89,039,303 | 14,448,051 | −83.773% |

The byte-zero control pays 0.992 additional instructions per comparison. `screen verify` checks 359,934 exact results covering every pair of byte strings of length 0 through 5 from a three-symbol alphabet, lengths around word boundaries at all combinations of address offsets 0–15, unequal lengths and every captured uv pair. The `qa` integration suite also checks the public `Path` and partially consumed `Components` ordering against the independent elementwise `Iterator::cmp`. It includes non-UTF-8 paths, normalization spellings and changes to every bit of the first differing byte followed by another differing byte.

From the chat directory, the reproduction commands are

```sh
python3 work/path-compare/prepare.py
cc -O2 -Iwork/profiler/usr/include -c work/path-compare/scope.c -o work/path-compare/scope.o
work/toolchain/bin/rustc --edition=2024 -Copt-level=3 -Ccodegen-units=1 -Cdebuginfo=1 \
  -C link-arg=work/path-compare/scope.o work/path-compare/screen.rs -o work/path-compare/screen
(cd work/path-compare && ./screen capture && ./screen verify)
python3 work/path-compare/count.py
```

## Complete public `Path::cmp`

These matched fixture executables link the actual std rlibs emitted by the separate cold Cargo source builds. Per-variant counts and comparison checksums were identical in three counterbalanced pairs per control.

| Input | Baseline `Ir` | Native word `Ir` | Change |
| --- | ---: | ---: | ---: |
| uv BTree pairs | 93,965,037 | 50,440,427 | −46.320% |
| 14 short spellings | 27,271,048 | 28,053,548 | +2.869% |
| Long inputs differing at byte zero | 30,375,798 | 30,567,798 | +0.632% |
| Equal long paths | 74,393,298 | 21,760,548 | −70.749% |

The short control pays 7.985 additional instructions per comparison and the byte-zero control pays 2. These rows include the full normalization and fallback behavior, which changes the measured cost relative to the isolated mismatch scan.

## Matched Cargo binaries

`build/cargo-src` is an initially pristine export of the released Ohm Cargo revision `a0c7d08c898d3fdff992f2f431dec57d2486add2`, with the same distribution version stamp on both binaries. `build/library` is a private copy of the published rust-src component. All 3,608 files initially match. `build/build-one.sh` invokes the published Cargo and rustc with `-Zbuild-std`, explicit host target, ThinLTO, one codegen unit, optimization level 3, `ohm-defaults,all-static`, and `LIBZ_SYS_STATIC=1`. The build uses six jobs, the same source path and target directory on both sides, and the initial attempt can populate its private registry from the normal mirror. The patched build requires offline resolution. These repro builds omit the official release's Cargo PGO profile. Cargo reads the provided std workspace and its lockfile through `__CARGO_TESTS_ONLY_SRC_ROOT`. [Override implementation](https://github.com/astral-sh/ohm-cargo/blob/a0c7d08c898d3fdff992f2f431dec57d2486add2/src/compiler/standard_lib.rs#L220-L238).

```sh
bash work/path-compare/build/build-one.sh base
mv work/path-compare/build/target work/path-compare/build/preserved-baseline-target
(cd work/path-compare/build && patch --forward --fuzz=0 -p1 < ../std-path-mismatch.patch)
bash work/path-compare/build/build-one.sh word
bash work/path-compare/build/qa-word.sh
```

Each side must start from an empty target at the same pathname. The first patch-only incremental trial returned a byte-identical binary in four seconds. Cargo deliberately excludes a std unit's package-local sources from its persistent dep-info. The cold rustc depfile contained `std/src/path.rs`, but Cargo’s filtered `dep-lib-std` omitted it. The discarded attempt is stored under `build/rejected-warm-target`. [Unit classification](https://github.com/astral-sh/ohm-cargo/blob/a0c7d08c898d3fdff992f2f431dec57d2486add2/src/compiler/unit.rs#L164-L166), [dep-info filtering](https://github.com/astral-sh/ohm-cargo/blob/a0c7d08c898d3fdff992f2f431dec57d2486add2/src/compiler/fingerprint/dep_info.rs#L346-L351).

`build/logs` records exact Cargo arguments, verbose compiler invocations, output hashes, vendored library versions and dynamic linkage. `source-identities.py` checks that the Cargo source tree is unchanged and only `std/src/path.rs` differs across the copied library trees. `full-compile.py` extracts the exact target `std` extern and library search paths from the real build log and also links the standalone fixture to each corresponding target std. `full-count.py` compares the exported public `Path::cmp` implementation on the same inputs as the isolated scan. All reported fixture runs use the host’s x86-64 Linux compiler and runtime.
