# Matched guarded std plus the five Cargo changes

The released Ohm rustc and Cargo run all three builds from the same Cargo source, std source and target directory pathnames. The baseline and guarded std builds each start from an empty target. The combined build keeps the guarded std and native dependencies and recompiles Cargo at the same source path with its five published changes. All binaries carry the release's frozen `git-commit-info` for comparable output and benchmark cache behavior.

`build/logs/guard-stack.published.tsv` lists the exact published PR heads, Git trees and verified parent chain from `a0c7d08c898d3fdff992f2f431dec57d2486add2` through `94c95d6b8ef97b0e63e04b250bc88d1a388a31af`. The final tree is `c9bc2498e72cba046f6d6c75996be717b37f7c57`. The combined Cargo patch changes seven files and has SHA-256 `a287c4d2cb0eb4bf63cc30674515331ec9186f4c98b070ffa58e0b0a85602c09`. The single std source patch has SHA-256 `ff2dcc74dfc56fb366422c29de08dc1baae4ec4efc91171069358b838177b795`.

```sh
bash reproduce-guarded.sh CARGO_REPO RELEASED_OHM_SYSROOT FRESH_SCRATCH std-path-mismatch-guarded.patch
bash reproduce-guard-stack.sh CARGO_REPO RELEASED_OHM_SYSROOT FRESH_SCRATCH
```

The first script requires the released Ohm `rust-src` component. The second also requires all five published Git commits locally. `build/start-stack.sh` and `build/stack-sources.py` record the research run. They compare the whole exported tree against a Git archive, including symlink spellings, and verify the exact target `--extern std` rlib from both new Cargo compiler invocations against the preserved guarded archive. The Rust standard library source manifest, all toolchain flags, version and shared-library names are also matched. These scripts build only the tool binaries. Aggregate workspace measurements can then compare `bin/base`, `bin/guard` and `bin/guard-stack` on uv.

| Binary | Research build seconds | SHA-256 |
| --- | ---: | --- |
| `base` | 600 | `744843355906004af366ca616a31bde4d79bced59e00355b71eadd7b4257d00c` |
| `guard` | 581 | `4621266004b9034450137495686fdac378f6aca727d7b621ef9fd85cd558746e` |
| `guard-stack` | 482 | `42b0c136d6adf60c8bda017451dc847722db0d2304a10af1e3dcf19585e07d52` |

The validated frozen guarded std archive has SHA-256 `0b15493f53b9f418cc600693080190caa971990e9fe877366bfb93e18b543a20` in both `guard` and `guard-stack`. The public-API fixture can run on either side of the matched std pair without rebuilding Cargo. After building the pair, run the following with a C compiler and Valgrind's Cachegrind headers installed.

```sh
python3 reproduce-path-fixture.py RELEASED_OHM_SYSROOT FRESH_SCRATCH NEW_MEASUREMENT_DIRECTORY
```

For an unpacked Valgrind, use `--valgrind PATH --valgrind-lib LIBDIR --include INCLUDEDIR`. The portable runner compiled fresh test executables against the archives identified by Cargo's actual `--extern std` argument. Its 56 samples exactly reproduced every recorded baseline and guarded total across all eight controls on this host. `portable-fixture-run/pairs.csv` retains the actual observations.
