from pathlib import Path
import shlex, shutil, subprocess, sys
p=Path(__file__).resolve().parent; outer=p.parent; code=(outer/'full.rs').read_text(); anchor='    match args[1].as_str() {'
new='''    let short_related: &[&[u8]] = &[b"a", b"aa", b"a/b", b"a/c", b"a/.", b"a/..", b"ab", b"abc", b"abcd", b"a/b.rs", b"a/c.rs", b"a/d/mod"];
    let medium: &[&[u8]] = &[b"src/lib.rs", b"src/main.rs", b"src/bin/uv.rs", b"src/lib/mod.rs", b"src/lib/test.rs", b"tests/lib.rs", b"tests/main.rs", b"crates/uv/src", b"crates/uv/src/lib.rs", b"Cargo.toml", b"Cargo.lock", b".cargo/config", b"LICENSE", b"README.md", b"/usr/bin/env", b"/usr/bin/bash", b"/tmp/uv/build"];
    let copied_short: Vec<_> = short.iter().map(|s| s.to_vec()).collect();
    let early_paths: Vec<_> = (0..128u8).map(|i| { let mut p = vec![b'a';96 + usize::from(i)%37]; p[0]=b'/'; p[1]=i; p }).collect();
    match args[1].as_str() {
        "short-related" => { for &a in short_related { for &b in short_related { data.push((a,b)); } } },
        "short-equal" => { for (&a,b) in short.iter().zip(&copied_short) { data.push((a,b)); } },
        "medium" => { for &a in medium { for &b in medium { data.push((a,b)); } } },
        "byte-one" => { for i in 0..early_paths.len() { data.push((&early_paths[i], &early_paths[(i+1)%early_paths.len()])); } },'''
assert code.count(anchor)==1;source=outer/'extra.rs';source.write_text(code.replace(anchor,new))
link=p/'control-link';link.mkdir(exist_ok=True)
for variant in sys.argv[1:]:
    cmd=shlex.split((p/f'logs/{variant}.fixture-command').read_text());
    for i,arg in enumerate(cmd):
        if arg.startswith('noprelude,nounused:std='):
            dst=link/Path(arg.split('=',1)[1]).name;shutil.copyfile(p/f'bin/libstd-{variant}.rlib',dst);cmd[i]=arg.split('=',1)[0]+'='+str(dst)
        if arg==str(outer/'full.rs'):cmd[i]=str(source)
    cmd[cmd.index('-o')+1]=str(p/f'bin/extra-{variant}');subprocess.run(cmd,cwd=outer,check=True)
