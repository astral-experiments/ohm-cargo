from pathlib import Path
import os, shlex, shutil, subprocess, sys, hashlib
p=Path(__file__).resolve().parent; outer=p.parent; main=outer/'build'; oldtarget=main/'target'; frozen=main/'rejected-warm-target/preserved-baseline-target'; lib=p/'library'; variant=sys.argv[1]
# Regenerate the entire one changed file from the packaged source at one fixed
# pathname for every variant. Only dependency artifacts come from the preserved
# target. Neither scratch sources nor outputs of the real Cargo builds change.
original=(outer.parent/'toolchain/lib/rustlib/src/rust/library/std/src/path.rs').read_bytes()
src=lib/'std/src/path.rs'; src.write_bytes(original)
if variant!='base':
 subprocess.run(['patch','--batch','--forward','--fuzz=0','-p1'],input=(outer/'std-path-mismatch.patch').read_bytes(),cwd=p,check=True,stdout=subprocess.DEVNULL)
 s=src.read_text(); anchor='    let (left_words, left_tail) = left[..len].as_chunks::<WORD>();'; assert s.count(anchor)==1
 if variant in ('guard','guard0'):
  add='''    if len < WORD {
        return left.iter().zip(right).position(|(a, b)| a != b);
    }
'''
  if variant=='guard0': add+='''    if left[0] != right[0] {
        return Some(0);
    }
'''
  s=s.replace(anchor,add+anchor); src.write_text(s)
 elif variant in ('first','manual','manual0'):
  if variant=='first':
   add="""    if len == 0 {
        return None;
    }
    if left[0] != right[0] {
        return Some(0);
    }
"""
  else:
   add="""    if len < WORD {
        for (i, (a, b)) in left.iter().zip(right).enumerate() {
            if a != b {
                return Some(i);
            }
        }
        return None;
    }
"""
   if variant=='manual0': add+="""    if left[0] != right[0] {
        return Some(0);
    }
"""
  s=s.replace(anchor,add+anchor); src.write_text(s)
 elif variant in ('tail','split'):
  if variant=='tail':
   add="""    if len == 0 {
        return None;
    }
    if left[0] != right[0] {
        return Some(0);
    }
"""
   s=s.replace(anchor,add+anchor).replace('    left_tail.iter().zip(right_tail).position(|(a, b)| a != b).map(|i| tail_start + i)',"""    for (i, (a, b)) in left_tail.iter().zip(right_tail).enumerate() {
        if a != b {
            return Some(tail_start + i);
        }
    }
    None""")
  else:
   a=s.index('fn first_byte_mismatch(');z=s.index('\n\nfn compare_components(',a)
   s=s[:a]+"""fn first_byte_mismatch(mut left: &[u8], mut right: &[u8]) -> Option<usize> {
    const WORD: usize = size_of::<usize>();
    let mut offset = 0;
    while let (Some((a, a_rest)), Some((b, b_rest))) =
        (left.split_first_chunk::<WORD>(), right.split_first_chunk::<WORD>())
    {
        let different = usize::from_le_bytes(*a) ^ usize::from_le_bytes(*b);
        if different != 0 {
            return Some(offset + different.trailing_zeros() as usize / 8);
        }
        offset += WORD;
        left = a_rest;
        right = b_rest;
    }
    for (i, (a, b)) in left.iter().zip(right).enumerate() {
        if a != b {
            return Some(offset + i);
        }
    }
    None
}"""+s[z:]
  src.write_text(s)
 elif variant!='word': raise ValueError(variant)
(p/'sources').mkdir(exist_ok=True)
(p/f'sources/{variant}.rs').write_bytes(src.read_bytes())
if '--source-only' in sys.argv[2:]: sys.exit(0)
# Preserve rustc stage, standard-library config, native search paths, crate
# metadata, and every dependency argument of Cargo's real std invocation.
for line in (main/'logs/base.build.log').open():
 if line.startswith('     Running `') and ' --crate-name std ' in line and ' --crate-type rlib ' in line and ' --target x86_64-unknown-linux-gnu ' in line:
  args=shlex.split(line.strip()[len('Running `'):-1]);break
else: raise ValueError('no std invocation')
change=lambda s:s.replace(str(oldtarget)+'/',str(frozen)+'/').replace(str(main/'library')+'/',str(lib)+'/')
args=[change(v) for v in args]; env=dict(os.environ)
while args and '=' in args[0] and not args[0].startswith('/'):
 k,v=args.pop(0).split('=',1);env[k]=v
assert args[0].endswith('/bin/rustc'),args[:2];args[args.index('--out-dir')+1]=str(p/'out')
(p/f'logs/{variant}.std-command').write_text(shlex.join(args)+'\n');
keep_vars=('CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','OUT_DIR','RUSTC_BOOTSTRAP');(p/f'logs/{variant}.std-environment').write_text(''.join(f'{k}={env[k]}\n' for k in keep_vars if k in env))
with (p/f'logs/{variant}.std-build.log').open('w') as f: subprocess.run(args,env=env,cwd=lib/'std',stdout=f,stderr=subprocess.STDOUT,check=True)
rlib,=list((p/'out').glob('libstd-*.rlib')); shutil.copy2(rlib,p/f'bin/libstd-{variant}.rlib')
# The fixture executable must statically select this std even though the other
# transitive dependencies originate in the trusted baseline target layout.
fcmd=shlex.split((main/'logs/base.full-fixture-command').read_text()); fcmd=[change(v) for v in fcmd]
for i,v in enumerate(fcmd):
 if v.startswith('noprelude,nounused:std='): fcmd[i]=v.split('=',1)[0]+'='+str(rlib)
fcmd[fcmd.index('-o')+1]=str(p/f'bin/{variant}');(p/f'logs/{variant}.fixture-command').write_text(shlex.join(fcmd)+'\n');subprocess.run(fcmd,cwd=outer,check=True)
print(variant,'std',hashlib.sha256(rlib.read_bytes()).hexdigest(),'fixture',hashlib.sha256((p/f'bin/{variant}').read_bytes()).hexdigest(),flush=True)
