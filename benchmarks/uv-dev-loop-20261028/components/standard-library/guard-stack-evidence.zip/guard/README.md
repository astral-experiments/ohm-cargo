# Guarded native-word comparison

The frozen implementation is `../std-path-mismatch-guarded.patch`. The native-word implementation initially saved 46.32% of instructions over the complete public `Path::cmp` comparisons on the uv fixture. Mixed short paths added 2.87% and paths differing at byte zero added 0.63%. We tested scalar fallbacks independently in a second std source copy using the exact same Rust compiler, target dependencies, C instrumentation shim and `Path::cmp` calls. The base and unguarded second-copy totals reproduced the corresponding first-copy totals exactly on all four original inputs.

The selected implementation handles a short input with a scalar loop. On longer inputs it first detects a mismatch in byte zero, then compares native words and scans the remaining tail. The simpler first-byte-only fallback remained positive on mixed short inputs but added 2.84% on related short inputs and 5.91% on equal short inputs. The split-first-chunk variant reduced the uv improvement to 39.20% and added work on mixed short inputs. `frozen.json` records the source hashes, measurements and raw data filenames for the selected `manual0` implementation.

| Complete `Path::cmp` control | Ir change vs released source |
| --- | ---: |
| uv BTree comparison pairs | −45.64% |
| Mixed short paths | −1.29% |
| Long paths differing at byte zero | −2.21% |
| Equal long paths | −69.85% |
| Related short paths | −1.79% |
| Equal short paths | −10.49% |
| Medium file spellings | −2.62% |
| Long paths differing in byte one | +0.21% |

The byte-one control adds three instructions per comparison. Three rotation-balanced rounds covered the original inputs and four covered the additional inputs. Each variant produced identical instruction totals on every repeat of a control. Each implementation produced the same ordering checksum. The independent scalar oracle agreed on 359,934 first-mismatch results for the selected code.

`build.py` reruns the actual rustc invocation for the standard library and links the fixture to that std. `count.py` scopes Cachegrind collection to calls of `Path::cmp`. `extra-compile.py` adds the related/equal short paths, medium spellings and input pairs differing at byte one. These scripts use the archived baseline dependencies of the main Cargo build. `../reproduce-guarded.sh` provides a standalone clean Cargo-pair build for the frozen patch, with all four arguments supplied by the caller.
