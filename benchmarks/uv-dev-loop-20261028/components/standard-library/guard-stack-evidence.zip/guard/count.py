from pathlib import Path
import csv, os, re, subprocess, sys
p=Path(__file__).resolve().parent; outer=p.parent; profiler=outer.parent/'profiler/usr'; variants=sys.argv[1:] or ['base','word','guard']; filename='-'.join(variants); outdir=p/'raw'/filename; outdir.mkdir(parents=True,exist_ok=True)
env=os.environ|{'VALGRIND_LIB':str(profiler/'libexec/valgrind')}
with (p/f'counts-{filename}.csv').open('w') as out:
    w=csv.writer(out);w.writerow(['workload','round','position','variant','pairs','reps','checksum','Ir'])
    controls=[('uv-tree',1),('short',500),('disjoint',750),('same',750)]
    if all(v.startswith('extra-') for v in variants): controls=[('short-related',650),('short-equal',6600),('medium',325),('byte-one',750)]
    for name,reps in controls:
        for i in range(len(variants)):
            checks=[]
            for slot,v in enumerate(variants[i:]+variants[:i],1):
                case=f'{name}-{i+1}-{slot}-{v}';cg=outdir/(case+'.cg');log=outdir/(case+'.log')
                cmd=[str(profiler/'bin/valgrind'),'--tool=cachegrind','--instr-at-start=no','--cache-sim=no','--branch-sim=no','--trace-children=no','--cachegrind-out-file='+str(cg),str(p/'bin'/v),'full',name,str(reps)]
                result=subprocess.run(cmd,cwd=outer,env=env,check=True,text=True,capture_output=True);log.write_text(result.stdout+result.stderr)
                n,r,total=map(int,re.fullmatch(r'pairs (\d+) reps (\d+) checksum (\d+)\n',result.stdout).groups());ir=int(re.search(r'^summary: (\d+)\s*$',cg.read_text(),re.M)[1]);checks.append((n,r,total))
                w.writerow([name,i+1,slot,v,n,r,total,ir]);out.flush()
            assert len(set(checks))==1
