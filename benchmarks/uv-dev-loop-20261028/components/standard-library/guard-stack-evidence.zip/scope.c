#include <valgrind/cachegrind.h>
void scope_start(void) { CACHEGRIND_START_INSTRUMENTATION; }
void scope_stop(void) { CACHEGRIND_STOP_INSTRUMENTATION; }
