from pathlib import Path
import re, shlex, subprocess, sys
p=Path(__file__).resolve().parent; b=p/'build'; stage=sys.argv[1]
screen=(p/'screen.rs').read_text(); old='"scalar" => run(&data,reps,scalar),'; new='''"full" => run(&data,reps,|a,b| {
        let pa = Path::new(OsStr::from_bytes(a));
        let pb = Path::new(OsStr::from_bytes(b));
        Some(match pa.cmp(pb) { Ordering::Less=>0, Ordering::Equal=>1, Ordering::Greater=>2 })
    }), "scalar" => run(&data,reps,scalar),'''; assert screen.count(old)==1
source=p/'full.rs'; out=p/f'full-{stage}'; modified=screen.replace(old,new)
if source.exists(): assert source.read_text()==modified
else: source.write_text(modified)
# Use a real Cargo target unit's exact build-std extern and search paths. This
# permits a tiny independent Rust driver to link the just-built std without
# acquiring Cargo's target lock or changing any Cargo build artifacts.
for line in (b/'logs/base.build.log').open():
    if line.startswith('     Running `') and ' --crate-name hex ' in line and ' --target x86_64-unknown-linux-gnu ' in line and 'noprelude,nounused:std=' in line:
        args=shlex.split(line.strip()[len('Running `'):-1]); break
else: raise ValueError('no target std annotation yet')
cmd=[str(p.parent/'toolchain/bin/rustc'),'--edition=2024','-Copt-level=3','-Ccodegen-units=1','-Cdebuginfo=1','-Zunstable-options','--target','x86_64-unknown-linux-gnu']
for i,a in enumerate(args[:-1]):
    v=args[i+1]
    if a=='-L' or a=='--extern' and v.startswith('noprelude,nounused:'):
        if a=='--extern' and v.endswith('.rmeta'):
            v=v[:-len('.rmeta')]+'.rlib'
            assert Path(v.split('=',1)[1]).is_file(),v
        cmd.extend([a,v])
cmd.extend(['-Clink-arg='+str(p/'scope.o'),str(source),'-o',str(out)])
(b/f'logs/{stage}.full-fixture-command').write_text(shlex.join(cmd)+'\n')
subprocess.run(cmd,cwd=p,check=True)
print(stage,out.stat().st_size)
