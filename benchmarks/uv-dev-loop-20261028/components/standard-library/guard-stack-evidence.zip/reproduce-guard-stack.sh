#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 3 ]]; then
    printf 'usage: %s CARGO_REPO RELEASED_OHM_SYSROOT EXISTING_SCRATCH_FROM_REPRODUCE_GUARDED\n' "$0" >&2
    exit 2
fi
repository=$(realpath "$1"); toolchain=$(realpath "$2"); lab=$(realpath "$3")
[[ -f "$lab/logs/SHA256SUMS" && ! -e "$lab/bin/guard-stack" ]]
(cd "$lab/bin" && sha256sum -c "$lab/logs/SHA256SUMS")
release=a0c7d08c898d3fdff992f2f431dec57d2486add2
heads=(567b7d201b325e745d2dadd1553363b5c85f30d7 4246bb695caa5f713c7234b037512c5262b6891f a3c13409c1d98f3e1072d86c1d968368feb90f9c 9256d6a21da8e6c0a2ba9502999d74544ed850cd 94c95d6b8ef97b0e63e04b250bc88d1a388a31af)
previous=$release
for head in "${heads[@]}"; do
    [[ $(git -C "$repository" rev-parse "$head^1") == "$previous" ]]
    previous=$head
done
git -C "$repository" diff --binary --no-ext-diff "$release" "$previous" -- > "$lab/logs/guard-stack.cargo.patch"
printf '%s  %s\n' a287c4d2cb0eb4bf63cc30674515331ec9186f4c98b070ffa58e0b0a85602c09 "$lab/logs/guard-stack.cargo.patch" | sha256sum -c -
cd "$lab/cargo-src"
patch --batch --forward --fuzz=0 -p1 < "$lab/logs/guard-stack.cargo.patch"
while IFS= read -r file; do
    git -C "$repository" show "$previous:$file" | cmp - "$file"
done < <(git -C "$repository" diff --name-only "$release" "$previous" --)
export CARGO_HOME="$lab/cargo-home" CARGO_TARGET_DIR="$lab/target"
export RUSTC="$toolchain/bin/rustc" RUSTDOC="$toolchain/bin/rustdoc" PATH="$toolchain/bin:$PATH"
export __CARGO_TESTS_ONLY_SRC_ROOT="$lab/library"
export CARGO_PROFILE_RELEASE_LTO=thin CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_OPT_LEVEL=3
export CARGO_PROFILE_RELEASE_INCREMENTAL=false CARGO_PROFILE_RELEASE_DEBUG=false CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS=false CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS=false
export LIBZ_SYS_STATIC=1 CARGO_TERM_COLOR=never CFG_RELEASE=1.99.0-dev CFG_RELEASE_CHANNEL=dev CFG_VER_DESCRIPTION=ohm-1.99.0-17
host=x86_64-unknown-linux-gnu
"$toolchain/bin/cargo" -Zohm-defaults=no -Zbuild-std build --release --locked --offline --bin cargo --target "$host" --features ohm-defaults,all-static -j6 -vv > "$lab/logs/guard-stack.build.log" 2>&1
cp "$lab/target/$host/release/cargo" "$lab/bin/guard-stack"
libs=("$lab/target/$host/release/build/std"/*/out/libstd-*.rlib)
[[ ${#libs[@]} == 1 && -f ${libs[0]} ]]
cmp "${libs[0]}" "$lab/bin/guard-libstd.rlib"
if cmp -s "$lab/bin/guard" "$lab/bin/guard-stack"; then printf 'identical Cargo executable\n' >&2; exit 1; fi
"$lab/bin/guard-stack" -Vv > "$lab/logs/guard-stack.version"
ldd "$lab/bin/guard-stack" > "$lab/logs/guard-stack.ldd"
(cd "$lab/bin" && sha256sum -c "$lab/logs/SHA256SUMS" && sha256sum guard-stack | tee "$lab/logs/guard-stack.sha256")
