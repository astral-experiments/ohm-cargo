"""Replay public Path::cmp controls against the real std archives from reproduce-guarded.sh."""
import argparse
import csv
import hashlib
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('toolchain', type=Path)
parser.add_argument('scratch', type=Path, help='populated build root from reproduce-guarded.sh')
parser.add_argument('out', type=Path, help='new directory for the measurement')
parser.add_argument('--valgrind', default='valgrind')
parser.add_argument('--valgrind-lib', type=Path, help='override VALGRIND_LIB for a locally unpacked Valgrind')
parser.add_argument('--include', type=Path, help='directory containing valgrind/cachegrind.h')
parser.add_argument('--base-target', type=Path, help='baseline target tree if it was preserved under a different name')
args = parser.parse_args()
source = Path(__file__).resolve().parent
scratch = args.scratch.resolve(); rustc = args.toolchain.resolve()/'bin/rustc'
out = args.out.resolve(); out.mkdir(parents=True, exist_ok=False)
valgrind = str(Path(shutil.which(args.valgrind) or args.valgrind).resolve())
env = os.environ.copy()
if args.valgrind_lib: env['VALGRIND_LIB'] = str(args.valgrind_lib.resolve())
cc = [os.environ.get('CC', 'cc'), '-O2']
if args.include: cc.extend(['-I', str(args.include.resolve())])
subprocess.run([*cc, '-c', source/'scope.c', '-o', out/'scope.o'], check=True)

original_target = scratch/'target'
targets = {'base': (args.base_target or scratch/'preserved-baseline-target').resolve(), 'guard': original_target}
with (scratch/'logs/base.build.log').open() as log:
    for line in log:
        if (line.startswith('     Running `') and ' --crate-name hex ' in line
            and ' --target x86_64-unknown-linux-gnu ' in line and 'noprelude,nounused:std=' in line):
            compiler_args = shlex.split(line.strip()[len('Running `'):-1]); break
    else: raise RuntimeError('could not find target hex compiler invocation in baseline Cargo -vv log')

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

for stage, target in targets.items():
    options = [str(rustc), '--edition=2024', '-Copt-level=3', '-Ccodegen-units=1',
               '-Cdebuginfo=1', '-Zunstable-options', '--target', 'x86_64-unknown-linux-gnu']
    used_std = None
    for index, key in enumerate(compiler_args[:-1]):
        value = compiler_args[index+1]
        if key == '-L' or key == '--extern' and value.startswith('noprelude,nounused:'):
            value = value.replace(str(original_target) + '/', str(target) + '/')
            if key == '--extern' and value.endswith('.rmeta'):
                value = value.removesuffix('.rmeta') + '.rlib'
            if key == '--extern' and value.startswith('noprelude,nounused:std='):
                used_std = Path(value.split('=', 1)[1])
            options.extend((key, value))
    assert used_std and digest(used_std) == digest(scratch/f'bin/{stage}-libstd.rlib')
    for name in ['full', 'extra']:
        cmd = [*options, '-Clink-arg='+str(out/'scope.o'), str(source/f'{name}.rs'), '-o', str(out/f'{name}-{stage}')]
        (out/f'{name}-{stage}.command').write_text(shlex.join(cmd)+'\n')
        subprocess.run(cmd, cwd=source, check=True)

# These repetition counts exactly match both captured tables in guard/frozen.json.
controls = [('uv-tree', 1, 'full', 3), ('short', 500, 'full', 3), ('disjoint', 750, 'full', 3),
            ('same', 750, 'full', 3), ('short-related', 650, 'extra', 4), ('short-equal', 6600, 'extra', 4),
            ('medium', 325, 'extra', 4), ('byte-one', 750, 'extra', 4)]
with (out/'pairs.csv').open('w') as handle:
    rows = csv.writer(handle); rows.writerow(['workload','pair','position','implementation','pairs','reps','checksum','Ir'])
    for name, reps, binary, pairs in controls:
        for pair in range(pairs):
            results = []
            for slot, stage in enumerate(('base','guard') if pair%2 == 0 else ('guard','base'), 1):
                stem = out/f'{name}-{pair+1}-{slot}-{stage}'; cg = stem.with_suffix('.cg')
                cmd = [valgrind, '--tool=cachegrind', '--instr-at-start=no', '--cache-sim=no', '--branch-sim=no',
                       '--trace-children=no', '--cachegrind-out-file='+str(cg), str(out/f'{binary}-{stage}'), 'full', name, str(reps)]
                proc = subprocess.run(cmd, cwd=source, env=env, check=True, capture_output=True, text=True)
                stem.with_suffix('.log').write_text(proc.stdout + proc.stderr)
                match = re.fullmatch(r'pairs (\d+) reps (\d+) checksum (\d+)\n', proc.stdout)
                assert match
                npairs, actual_reps, checksum = map(int, match.groups()); assert actual_reps == reps
                ir = int(re.search(r'^summary: (\d+)\s*$', cg.read_text(), re.M)[1])
                rows.writerow([name,pair+1,slot,stage,npairs,reps,checksum,ir]); handle.flush()
                results.append((npairs, actual_reps, checksum))
            assert results[0] == results[1], (name, pair, results)
print(out/'pairs.csv')
