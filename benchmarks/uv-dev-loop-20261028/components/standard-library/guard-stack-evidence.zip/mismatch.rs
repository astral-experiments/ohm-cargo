fn first_byte_mismatch(left: &[u8], right: &[u8]) -> Option<usize> {
    const WORD: usize = size_of::<usize>();
    let len = left.len().min(right.len());
    let (left_words, left_tail) = left[..len].as_chunks::<WORD>();
    let (right_words, right_tail) = right[..len].as_chunks::<WORD>();
    for (i, (a, b)) in left_words.iter().zip(right_words).enumerate() {
        let different = usize::from_le_bytes(*a) ^ usize::from_le_bytes(*b);
        if different != 0 {
            return Some(i * WORD + different.trailing_zeros() as usize / 8);
        }
    }
    let tail_start = len - left_tail.len();
    left_tail.iter().zip(right_tail).position(|(a, b)| a != b).map(|i| tail_start + i)
}
