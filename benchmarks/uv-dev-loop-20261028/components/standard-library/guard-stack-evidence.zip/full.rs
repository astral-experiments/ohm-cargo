use std::{cell::RefCell, cmp::Ordering, collections::BTreeSet, env, ffi::OsStr, fs, hint::black_box, os::unix::ffi::OsStrExt, path::Path};
include!("mismatch.rs");
unsafe extern "C" { fn scope_start(); fn scope_stop(); }
fn scalar(a: &[u8], b: &[u8]) -> Option<usize> {
    a.iter().zip(b).position(|(&a, &b)| a != b)
}
#[derive(Clone, Copy)]
struct Track<'a> { id: u16, path: &'a Path, pairs: &'a RefCell<Vec<(u16, u16)>> }
impl Ord for Track<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.pairs.borrow_mut().push((self.id, other.id));
        self.path.cmp(other.path)
    }
}
impl PartialOrd for Track<'_> { fn partial_cmp(&self, other: &Self) -> Option<Ordering> { Some(self.cmp(other)) } }
impl PartialEq for Track<'_> { fn eq(&self, other: &Self) -> bool { self.path == other.path } }
impl Eq for Track<'_> {}
const PATHS: &[u8] = include_bytes!("paths.dat");
fn as_paths() -> Vec<&'static [u8]> { PATHS.split(|&c| c == b'\n').filter(|p| !p.is_empty()).collect() }
fn capture() {
    let paths = as_paths();
    let pairs = RefCell::new(Vec::new());
    for root in include_str!("roots.dat").lines() {
        let mut set = BTreeSet::new();
        for id in root.split_whitespace().map(|s| s.parse::<u16>().unwrap()) {
            assert!(set.insert(Track { id, path: Path::new(OsStr::from_bytes(paths[usize::from(id)])), pairs: &pairs }));
        }
    }
    let comparisons = pairs.into_inner();
    let mut prefix: Vec<_> = comparisons.iter().map(|&(a,b)| {
        let (a, b) = (paths[usize::from(a)], paths[usize::from(b)]);
        scalar(a,b).unwrap_or(a.len().min(b.len()))
    }).collect();
    prefix.sort_unstable();
    eprintln!("{} pairs, prefix p1 {} p50 {} p99 {}", prefix.len(), prefix[prefix.len()/100], prefix[prefix.len()/2], prefix[prefix.len()*99/100]);
    let mut bytes = Vec::with_capacity(4 * comparisons.len());
    for (a,b) in comparisons { bytes.extend(a.to_le_bytes()); bytes.extend(b.to_le_bytes()); }
    fs::write("pairs.bin", bytes).unwrap();
}
fn verify() {
    let mut checks = 0u64;
    let mut check = |a: &[u8], b: &[u8]| {
        assert_eq!(scalar(a,b), first_byte_mismatch(a,b), "{a:?}, {b:?}"); checks += 1;
    };
    let mut words = vec![Vec::new()];
    for _ in 0..5 {
        let n = words.len();
        for i in 0..n { for ch in [0u8, b'/', 0xff] { let mut w = words[i].clone(); w.push(ch); words.push(w); } }
    }
    words.sort(); words.dedup();
    for a in &words { for b in &words { check(a,b); } }
    let base = (0..160).map(|i| (i as u8).wrapping_mul(37)).collect::<Vec<_>>();
    let mut rhs = [0u8;160];
    for i in 0..16 { for j in 0..16 {
        for &n in &[0,1,2,3,4,7,8,9,15,16,17,31,32,33,63,64,65,99] {
            let a = &base[i..i+n]; rhs[j..j+n].copy_from_slice(a);
            check(a,&rhs[j..j+n]); check(a,&rhs[j..j+n+1]); check(&base[i..i+n+1],&rhs[j..j+n]);
            for k in 0..n { rhs[j+k] ^= 0xff; check(a,&rhs[j..j+n]); rhs[j+k] ^= 0xff; }
        }
    } }
    for (a,b) in long_uv_pairs(&fs::read("pairs.bin").unwrap()) { check(a,b); }
    println!("{checks} equality checks passed");
}
fn long_uv_pairs(raw: &[u8]) -> Vec<(&'static [u8], &'static [u8])> {
    let paths = as_paths();
    raw.chunks_exact(4).map(|p| (paths[u16::from_le_bytes([p[0],p[1]]) as usize], paths[u16::from_le_bytes([p[2],p[3]]) as usize])).collect()
}
fn run(data: &[(&[u8], &[u8])], reps: usize, find: impl Fn(&[u8], &[u8]) -> Option<usize>) -> usize {
    let mut sum = 0usize;
    for _ in 0..reps {
        for &(a,b) in black_box(data) { sum = sum.wrapping_add(find(a,b).map_or(0,|k| k+1)); }
    }
    black_box(sum)
}
fn main() {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args[0] == "capture" { return capture(); }
    if args[0] == "verify" { return verify(); }
    let short: &[&[u8]] = &[b"",b".",b"a",b"z",b"..",b"./",b"ab",b"az",b"uv",b"src",b"a/b",b"uv/src",b"/tmp/x",b"Cargo"]; 
    let mut data: Vec<(&[u8],&[u8])> = Vec::new();
    let split: Vec<_> = (0..128u8).map(|i| { let mut p = vec![b'/'; 96+i as usize%39]; p[0]=i; p }).collect();
    let copy: Vec<_> = split.iter().cloned().collect();
    match args[1].as_str() {
        "uv-tree" => data = long_uv_pairs(&fs::read("pairs.bin").unwrap()),
        "short" => { for &a in short { for &b in short { data.push((a,b)); } } },
        "disjoint" => { for i in 0..split.len() { data.push((&split[i], &copy[(i+1)%copy.len()])); } },
        "same" => { for (a,b) in split.iter().zip(&copy) { data.push((a,b)); } },
        _ => panic!(),
    }
    let reps = args[2].parse().unwrap();
    unsafe { scope_start() };
    let sum = match args[0].as_str() { "full" => run(&data,reps,|a,b| {
        let pa = Path::new(OsStr::from_bytes(a));
        let pb = Path::new(OsStr::from_bytes(b));
        Some(match pa.cmp(pb) { Ordering::Less=>0, Ordering::Equal=>1, Ordering::Greater=>2 })
    }), "scalar" => run(&data,reps,scalar), "word" => run(&data,reps,first_byte_mismatch), _=>panic!() };
    unsafe { scope_stop() };
    println!("pairs {} reps {reps} checksum {sum}", data.len());
}
