from pathlib import Path
from hashlib import sha256
from shutil import copy2
import sys, subprocess
p=Path(__file__).resolve().parent; lab=p/'build'; stage=sys.argv[1]; original=p.parent/'toolchain/lib/rustlib/src/rust/library'
def contents(root):
    rows=[]
    for f in sorted(root.rglob('*')):
        if f.is_symlink(): rows.append((f.relative_to(root).as_posix(),'link '+str(f.readlink())))
        elif f.is_file(): rows.append((f.relative_to(root).as_posix(),sha256(f.read_bytes()).hexdigest()))
    return dict(rows)
std=contents(lab/'library'); shipped=contents(original); diffs=[name for name in sorted(set(std)|set(shipped)) if std.get(name)!=shipped.get(name)]
assert diffs==([] if stage=='base' else ['std/src/path.rs']), diffs
print('library files',len(std),'differing from shipped',diffs)
pkg=contents(lab/'cargo-src')
for component, manifest in [('library',std),('cargo',pkg)]:
    out=lab/f'logs/{stage}.{component}.manifest'
    out.write_text(''.join(f'{digest}  {path}\n' for path,digest in manifest.items())); print(component,sha256(out.read_bytes()).hexdigest())
    if stage!='base' and component=='cargo': assert out.read_bytes()==(lab/f'logs/base.{component}.manifest').read_bytes()
import shlex
# Another test target can create additional std units. Freeze exactly the std from
# the actual cargo build, identified by the real --extern in its verbose invocation.
for line in (lab/'logs/base.build.log').open():
    if line.startswith('     Running `') and ' --crate-name hex ' in line and ' --target x86_64-unknown-linux-gnu ' in line and 'noprelude,nounused:std=' in line:
        args=shlex.split(line.strip()[len('Running `'):-1]); r=Path(next(a.split('=',1)[1] for a in args if a.startswith('noprelude,nounused:std='))).with_suffix('.rlib'); break
else: raise ValueError('no Cargo target std unit found')
dst=lab/'bin'/f'{stage}-libstd.rlib'; copy2(r,dst); print('libstd',dst.stat().st_size,sha256(dst.read_bytes()).hexdigest())
