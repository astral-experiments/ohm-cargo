from pathlib import Path
from csv import writer
import os, re, subprocess, hashlib, sys
p=Path(__file__).resolve().parent; profiler=p.parent/'profiler/usr'; variant=sys.argv[1] if len(sys.argv)>1 else 'word'; suffix='' if variant=='word' else '-'+variant; raw=p/('raw-full'+suffix); raw.mkdir(exist_ok=True)
env=os.environ|{'VALGRIND_LIB':str(profiler/'libexec/valgrind')}
inputs=[p/'full-base',p/('full-'+variant),p/'full-count.py',p/'pairs.bin']
fingerprint='\n'.join(hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs)
marker=p/('counts-full'+suffix+'.inputs.sha256')
if marker.exists() and marker.read_text()==fingerprint and (p/('counts-full'+suffix+'.csv')).exists(): sys.exit(0)
with (p/('counts-full'+suffix+'.csv')).open('w') as out:
    w=writer(out);w.writerow(['workload','pair','position','implementation','pairs','reps','checksum','Ir'])
    for workload,reps in [('uv-tree',1),('short',500),('disjoint',750),('same',750)]:
        for pair, order in enumerate([('base',variant),(variant,'base'),('base',variant)],1):
            results=[]
            for pos, variant in enumerate(order,1):
                name=f'{workload}-{pair}-{pos}-{variant}';cg=raw/(name+'.cg');log=raw/(name+'.log')
                cmd=[str(profiler/'bin/valgrind'),'--tool=cachegrind','--instr-at-start=no','--cache-sim=no','--branch-sim=no','--trace-children=no','--cachegrind-out-file='+str(cg),str(p/f'full-{variant}'),'full',workload,str(reps)]
                proc=subprocess.run(cmd,cwd=p,env=env,check=True,capture_output=True,text=True);log.write_text(proc.stdout+proc.stderr)
                n,r,total=map(int,re.fullmatch(r'pairs (\d+) reps (\d+) checksum (\d+)\n',proc.stdout).groups())
                ir=int(re.search(r'^summary: (\d+)\s*$',cg.read_text(),re.M)[1]);results.append((n,r,total));w.writerow([workload,pair,pos,variant,n,r,total,ir]);out.flush()
            assert results[0]==results[1]

marker.write_text(fingerprint)
