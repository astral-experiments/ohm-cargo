from pathlib import Path
from hashlib import sha256
import random

here = Path(__file__).resolve().parent
root = Path('/tmp/ohm-uv-bench.0H03f2TH/target-main/debug')
inputs = []
manifest = []
for path in sorted(root.glob('*.d')):
    raw = path.read_bytes()
    assert raw.count(b'\n') == 1 and raw.endswith(b'\n') and not set(raw) & {0, 9, 13, 92}
    out, sep, paths = raw[:-1].partition(b': ')
    assert all(x.startswith(b'/') for x in paths.split(b' ')) and sep
    inputs.append(paths.split(b' '))
    manifest.append(f'{sha256(raw).hexdigest()}  {path.name}\n')
unique = sorted({path for subset in inputs for path in subset})
ids = {path: index for index, path in enumerate(unique)}
(here / 'sources.sha256').write_text(''.join(manifest))
(here / 'paths.dat').write_bytes(b'\n'.join(unique) + b'\n')
rng = random.Random(0xc0decafe)
with (here / 'roots.dat').open('w') as out:
    for subset in inputs:
        assert len(set(subset)) == len(subset)
        rng.shuffle(subset)
        out.write(' '.join(str(ids[path]) for path in subset) + '\n')
print(f'{len(inputs)} roots, {len(unique)} distinct paths, {sum(map(len,inputs))} insertions')
