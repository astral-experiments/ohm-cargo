# Section-placement measurements

The original real uv executable screen used 3.1893% fewer Wild instructions than #45. Both reserved shapes reproduced their canonical executables in every capture. Ten million output bytes and 184 million output bytes corresponded to 0.1435% and 4.7912% fewer instructions respectively. Each eight-pair cohort has two-sided sign-test p = 0.0078125 and balanced-assignment permutation p = 0.02857.

With a live jobserver and the five actual Wild link invocations from each edited `cargo test --no-run --locked --offline -j4`, the eight-block median instruction reduction was 3.6026%. The blocks ranged from 3.2847% to 3.7096% and all 32 commands succeeded. `actual/summary.json` and `actual/samples.csv` contain the aggregate and process records. The driver was rebuilt from unmodified Ohm Cargo release source. The build used the exact shipped rustc. This endpoint counts Wild across its threads.

The capture gate in `plan.json` was “reject if it loses on screen or fails replication or any output comparison”. Every compared file had the registered canonical SHA-256.

The independently registered actual-command rule was “Complete all eight blocks without early stopping for effect. Require precisely five known linked units and exit 0 per invocation. Retain link outputs content-addressed and all SHA-256 digests. Report all parity discrepancies including any shared parent nondeterminism.” Parent and candidate produced identical sets of full-file SHA-256s for all ten edit/unit combinations. Eight combinations had a single output digest across all observations, and the large harness had two per edit on both linkers. In those two cases the variants differed in one `.rodata.sh_entsize` byte and the 32-byte build ID. `actual/digest-counts.tsv` shows each observed complete digest by arm. `actual/byte-differences.json` contains each differing byte range.

| Input | Parent median instructions | Candidate median instructions | Paired change |
| --- | ---: | ---: | ---: |
| uv-client partial link | 59,692,160 | 60,228,804.5 | +0.9012% |
| Data-heavy regex-syntax object, default rules | 11,371,377 | 11,355,002 | −0.1680% |
| Same object, custom rules | 17,609,600.5 | 17,651,809.5 | +0.2549% |

Every candidate output and diagnostic matched across these 48 fallback-control observations and the 21 synthetic edge cases. The partial and custom controls motivated version 2. The source adds one borrowed string-table slice per parsed ELF input, two machine words on the tested target.

The test-only patch preserves the measured linker binary under the original normal release build command. All 184 libwild unit tests, 35 targeted ELF integration cases and the Mach-O-feature compile passed. The orphan integration group required the C fixture compiler flag `-fcf-protection=none` on this Ubuntu host. With the host compiler's default CET property, the same GNU BFD reference link fails on both the #45 and candidate sources.
