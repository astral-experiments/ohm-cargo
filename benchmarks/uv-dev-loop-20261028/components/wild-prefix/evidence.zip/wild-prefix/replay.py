"""Reproduce linked outputs and record all-linker-thread instructions for one captured uv invocation."""
import argparse
import csv
import hashlib
import json
import os
import random
import re
import subprocess
from pathlib import Path

p = Path(__file__).resolve().parent
w = p.parent
root = w / "edit-link-profile"
args = argparse.ArgumentParser()
args.add_argument("capture", type=int)
args.add_argument("--pairs", type=int, required=True)
args.add_argument("--label", required=True)
args = args.parse_args()
i = args.capture
d = p / args.label
d.mkdir(exist_ok=True)

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

expected = sha(root / "replay" / f"source-{i}")
arms = ["parent", "probe"]
orders = ([0,1]*((args.pairs+1)//2))[:args.pairs]
random.Random(281037+i).shuffle(orders)
plan = {"capture":i, "orders":[[arms[ix], arms[1-ix]] for ix in orders],
        "binaries":{arm:sha(p/f"{arm}-wild") for arm in arms}, "expected":expected}
(d / f"orders-{i}.json").write_text(json.dumps(plan, indent=2)+"\n")
with (d/f"samples-{i}.csv").open("x") as f:
    logger = csv.writer(f)
    logger.writerow(["pair","position","arm","linker_instructions","output_sha256"])
    for pair, order in enumerate(plan["orders"]):
        for pos, arm in enumerate(order):
            out = d / f"link-{i}"
            cmd = [str(root/"captured"/"inputs"/str(i)/"run-with"), "python3", "-B", str(w/"dynamorio/count.py"), "--", str(p/f"{arm}-wild"), "--", "--dynamic-linker", "/lib64/ld-linux-x86-64.so.2", "--threads=1", "--no-fork"]
            log = d/f"log-{i}-{pair}-{pos}-{arm}.txt"
            with log.open("w") as trace:
                subprocess.run(cmd,env=dict(os.environ, OUT=str(out)),stdout=trace,stderr=trace,check=True)
            count = json.loads(re.findall(r"DynamoRIO (.+)$",log.read_text(),re.M)[-1])["instructions"]
            digest = sha(out)
            logger.writerow([pair,pos,arm,count,digest]);f.flush()
            assert digest == expected,(i,arm,pair,digest,expected)
            print(i,pair,pos,arm,count,flush=True)
