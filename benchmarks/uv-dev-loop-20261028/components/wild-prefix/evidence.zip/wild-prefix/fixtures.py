"""ELF default section names, custom/partial links and malformed string tables."""
import csv, hashlib, os, struct, subprocess, sys
from pathlib import Path
p = Path(__file__).resolve().parent
d = p/'fixtures'
d.mkdir(exist_ok=True)
asm = r"""
.section .text.startup,"ax",@progbits
.global _start
_start: lea var(%rip),%rax; ret
.section .text.hot.foo,"ax",@progbits
.byte 0xc1
.section .text.unlikely.foo,"ax",@progbits
.byte 0xb1
.section .texture,"ax",@progbits
.byte 0xd1
.section .text.exclude,"axe",@progbits
.byte 0xe1
.section .relaxed,"a",@progbits
.byte 0xf1
.section .tex,"a",@progbits
.byte 0x72
.section .data,"aw",@progbits
var: .byte 0x33
"""
(d/'in.s').write_text(asm)
subprocess.run(["llvm-mc-18","-filetype=obj","-triple=x86_64-linux-gnu","in.s","-o","in.o"],cwd=d,check=True)
(d/'override.ld').write_text('SECTIONS { .picked : { *(.text.hot*) *(.text.unlikely*) } .saved : { *(.relaxed) } .text : { *(.text*) } .data : { *(.data*) } }\n')
src=(d/'in.o').read_bytes()
shoff=struct.unpack_from("<Q",src,40)[0]
ssize,scount,stridx=struct.unpack_from("<HHH",src,58)
s_hdr=shoff+stridx*ssize
tab_offset,tab_len=struct.unpack_from("<QQ",src,s_hdr+24)
orig_names=src[tab_offset:tab_offset+tab_len]
entries={}
for idx in range(scount):
    head=shoff+idx*ssize
    name=struct.unpack_from("<I",src,head)[0]
    entries[orig_names[name:orig_names.index(0,name)]] = head
out_cases=[("default","in.o",[]),("sort","in.o",["--sort-section=name"]),("custom","in.o",["-T","override.ld"]),("partial","in.o",["-r"]),("orphan-error","in.o",["--orphan-handling=error"]),("orphan-warn","in.o",["--orphan-handling=warn"])]
def mutate(label, edit):
    file=bytearray(src);edit(file);(d/f'{label}.o').write_bytes(file)
    out_cases.append((label,f'{label}.o',[]))
def names_file(label,tail,offset=None):
    def edit(file):
        start=len(file);tab=orig_names+tail;file.extend(tab)
        struct.pack_into('<QQ',file,s_hdr+24,start,len(tab))
        struct.pack_into('<I',file,entries[b'.texture'],len(orig_names) if offset is None else offset(len(tab)))
    mutate(label,edit)
for label,tail in [('terminal-text',b'.text\0'),('terminal-rela',b'.rela\0'),('terminal-empty',b'\0'),('short-text',b'.tex\0t\0'),('short-rela',b'.rel\0a\0'),('unterminated-text',b'.text.hot'),('unterminated-rela',b'.rela.any')]:
    names_file(label,tail)
names_file('offset-at-eof',b'\0',lambda n:n)
names_file('offset-past-eof',b'\0',lambda n:n+20)
names_file('offset-max',b'\0',lambda n:0xffffffff)
names_file('exact-end-name',b'.text\0',lambda n:n-1)
def extended(b):
    struct.pack_into('<H',b,62,0xffff);struct.pack_into('<I',b,shoff+40,stridx)
mutate('extended-index',extended)
def null_name(b):
    struct.pack_into('<I',b,shoff,orig_names.index(b'.texture\0'))
mutate('named-null-section',null_name)
def bad_align(b):
    rel=next(head for k,head in entries.items() if k.startswith(b'.rela.') )
    struct.pack_into('<Q',b,rel+48,3)
mutate('invalid-relocation-alignment',bad_align)
def damaged_table(b):
    struct.pack_into('<Q',b,s_hdr+32,len(b)+1024)
mutate('out-of-file-names-table',damaged_table)
fields=['case','input','options','parent_exit','probe_exit','output_sha256','stderr_sha256','result']
def digest(bb):
    return hashlib.sha256(bb).hexdigest()
failed=0
with (d/'checks.csv').open('w') as raw:
    log=csv.writer(raw);log.writerow(fields)
    for label,infile,opts in out_cases:
        arms={}
        for which in ('parent','probe'):
            output=d/'out';output.unlink(missing_ok=True)
            cmd=['wild','-m','elf_x86_64','--no-fork','--threads=1','-o','out',*opts]
            if '-r' not in opts:cmd+=['--no-gc-sections','-e','_start']
            cmd+=[infile]
            cmd_out=subprocess.run(cmd,executable=p/f'{which}-wild',cwd=d,capture_output=True)
            stderr=cmd_out.stderr
            (d/f'{label}.{which}.stderr').write_bytes(stderr)
            (d/f'{label}.{which}.stdout').write_bytes(cmd_out.stdout)
            arms[which]=(cmd_out.returncode,cmd_out.stdout,stderr,output.read_bytes() if output.is_file() else None)
        base,probe=arms.values()
        good=base==probe
        failed += not good
        log.writerow([label,infile,' '.join(opts),base[0],probe[0],digest(base[3]) if base[3] is not None else '',digest(base[2]),'same' if good else 'DIFFERENT'])
        print(label,base[0],probe[0],'same' if good else 'DIFFERENT')
print(len(out_cases),'fixtures,',failed,'differences')
sys.exit(bool(failed))
