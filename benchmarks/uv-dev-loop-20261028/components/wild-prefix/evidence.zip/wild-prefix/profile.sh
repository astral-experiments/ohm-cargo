#!/usr/bin/env bash
set -eu
p=$(cd "$(dirname "$0")" && pwd); w=$(dirname "$p")
until test "$(wc -l < "$p/actual/samples.csv")" -eq 193; do
 if rg -q 'Traceback|AssertionError' "$p/logs/actual.log";then exit 1;fi
 sleep 2
done
taskset -c 24-25 python3 "$p/fallback/control.py" > "$p/logs/controls.log" 2>&1
export VALGRIND_LIB="$w/profiler/usr/libexec/valgrind" DEBUGINFOD_URLS= OUT="$p/profiled-uv"
taskset -c 24-25 "$w/edit-link-profile/captured/inputs/3/run-with" "$w/profiler/usr/bin/valgrind" --tool=callgrind --callgrind-out-file="$p/candidate.callgrind" "$p/probe-wild" -- --dynamic-linker /lib64/ld-linux-x86-64.so.2 --threads=1 --no-fork > "$p/logs/callgrind.log" 2>&1
cmp "$p/profiled-uv" "$w/edit-link-profile/replay/source-3"
rg '^summary:|^totals:' "$p/candidate.callgrind" | cut -c1-95
