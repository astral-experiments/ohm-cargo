import csv,hashlib,json,os,random,re,subprocess
from pathlib import Path
d=Path(__file__).resolve().parent;p=d.parent;w=p.parent
flags=['--no-fork','--threads=1','-m','elf_x86_64']
rlib='../../edit-link-profile/target/debug/build/uv-client/58adf456cbf5b40c/out/libuv_client-58adf456cbf5b40c.rlib'
normal=['--no-gc-sections','--unresolved-symbols=ignore-all','-e','0']
cases={'partial':['-r','--whole-archive',rlib],
       'data':[*normal,'data-debug.o'],
       'script':[*normal,'-T','override.ld','data-debug.o']}
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
out=d/'controls.csv'
with out.open('x') as f:
    writer=csv.writer(f);writer.writerow(['case','pair','position','arm','instructions','sha256'])
    for num,(case,args) in enumerate(cases.items()):
        path=d/f'check-{case}';ref=sha(path)
        expected=(d/f'{case}.log').read_text();order=[0,1]*4;random.Random(483117+num).shuffle(order)
        for pair,first in enumerate(order):
            for pos,ix in enumerate([first,1-first]):
                arm=['parent','probe'][ix]
                cmd=['python3','-B',str(w/'dynamorio/count.py'),'--',str(p/f'{arm}-wild'),*flags,*args,'-o',path.name]
                cp=subprocess.run(cmd,cwd=d,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True,text=True)
                (d/f'control-{case}-{pair}-{pos}-{arm}.log').write_text(cp.stdout)
                pre,result=cp.stdout.rsplit('DynamoRIO ',1)
                assert pre==expected,(case,arm,pre,expected)
                count=json.loads(result)['instructions'];digest=sha(path)
                writer.writerow([case,pair,pos,arm,count,digest]);f.flush()
                assert ref==digest,(case,pair,arm,ref,digest)
            print(case,pair,flush=True)
