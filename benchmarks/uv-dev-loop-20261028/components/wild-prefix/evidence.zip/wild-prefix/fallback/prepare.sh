#!/usr/bin/env bash
set -eu
f=$(cd "$(dirname "$0")" && pwd);p=$(dirname "$f");w=$(dirname "$p")
cd "$f"
python3 "$f/select.py"
rlib=${UV_CLIENT_RLIB:-../../edit-link-profile/target/debug/build/uv-client/58adf456cbf5b40c/out/libuv_client-58adf456cbf5b40c.rlib}
test -f "$rlib"
"$p/parent-wild" --no-fork --threads=1 -m elf_x86_64 -r --whole-archive "$rlib" -o check-partial > partial.log 2>&1
"$p/parent-wild" --no-fork --threads=1 -m elf_x86_64 --no-gc-sections --unresolved-symbols=ignore-all -e 0 data-debug.o -o check-data > data.log 2>&1
"$p/parent-wild" --no-fork --threads=1 -m elf_x86_64 --no-gc-sections --unresolved-symbols=ignore-all -e 0 -T override.ld data-debug.o -o check-script > script.log 2>&1
