import hashlib,json,mmap,struct
from pathlib import Path
here=Path(__file__).resolve().parent
r=here.parents[1]/'edit-link-profile/target/debug/build'
packages=['uv-client','uv-resolver','regex-syntax','aho-corasick','icu_properties','icu_normalizer','icu_collections','idna','unicode-width','encoding_rs','uv-pypi-types','uv-workspace','indexmap','toml_edit','rustls']
best=None
for name in packages:
    arch=next((r/name).glob('*/out/*.rlib'),None)
    if not arch:continue
    with arch.open('rb') as file,mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as bb:
        assert bb[:8]==b'!<arch>\n'
        pos=8;longnames=b''
        while pos+60<len(bb):
            raw=bb[pos:pos+16].rstrip();size=int(bb[pos+48:pos+58]);start=pos+60;pos=start+size+(size&1)
            if raw==b'//':longnames=bb[start:start+size];continue
            member=raw[:-1] if raw.endswith(b'/') else raw
            if raw[0:1]==b'/' and raw[1:2].isdigit():
                ix=int(raw[1:]);member=longnames[ix:longnames.index(b'/\n',ix)]
            if not member.endswith(b'.o') or bb[start:start+6]!=b'\x7fELF\x02\x01':continue
            off=struct.unpack_from('<Q',bb,start+40)[0]+start;sz,n,j=struct.unpack_from('<HHH',bb,start+58)
            if n<64:continue
            st,sn=struct.unpack_from('<QQ',bb,off+j*sz+24);nm=bb[start+st:start+st+sn];counts={'text':0,'rela':0,'data':0,'debug':0}
            for i in range(n):
                ix=struct.unpack_from('<I',bb,off+i*sz)[0];s=nm[ix:nm.index(0,ix)]
                for k,v in [('text',b'.text'),('rela',b'.rela'),('data',(b'.data',b'.bss',b'.rodata')),('debug',b'.debug')]:
                    if s.startswith(v):counts[k]+=1;break
            score=(counts['data']+counts['debug'])/n
            if best is None or score>best[0]:
                best=(score,n,counts,arch,member.decode(),start,size)
score,n,counts,arch,member,start,size=best
with arch.open('rb') as f:f.seek(start);data=f.read(size)
(here/'data-debug.o').write_bytes(data)
meta=dict(archive=str(arch),member=member,size=size,sections=n,counts=counts,score=score,sha256=hashlib.sha256(data).hexdigest())
(here/'data-debug.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
