import csv,json,statistics,collections
from pathlib import Path
p=Path(__file__).resolve().parent;groups=collections.defaultdict(lambda:collections.defaultdict(dict));digests=collections.defaultdict(set)
for r in csv.DictReader((p/'controls.csv').open()):
    groups[r['case']][int(r['pair'])][r['arm']]=int(r['instructions']);digests[r['case']].add(r['sha256'])
out={}
for c,blocks in groups.items():
    assert len(blocks)==8 and all(len(b)==2 for b in blocks.values()) and len(digests[c])==1
    fractions=[(v['probe']/v['parent']-1)*100 for v in blocks.values()]
    out[c]={'pairs':len(blocks),'parent_median':statistics.median(v['parent'] for v in blocks.values()),'v1_median':statistics.median(v['probe'] for v in blocks.values()),'median_instruction_change_pct':statistics.median(fractions),'range_pct':[min(fractions),max(fractions)],'output_sha256':next(iter(digests[c]))}
print(json.dumps(out,indent=2))
