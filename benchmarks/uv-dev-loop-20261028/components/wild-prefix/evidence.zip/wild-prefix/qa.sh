#!/usr/bin/env bash
set -eu
p=$(cd "$(dirname "$0")" && pwd); w=$(dirname "$p")
until test "$(wc -l < "$p/actual/samples.csv")" -eq 193; do
 if rg -q 'Traceback|AssertionError' "$p/logs/actual.log"; then exit 1;fi
 sleep 2
done
cd "$p/test-src"
export RUSTUP_TOOLCHAIN=stable CARGO_NET_OFFLINE=true CARGO_HOME="$w/cargohome" PATH="$w/wild-test-tools/bin:$PATH"
status=0
CARGO_TARGET_DIR="$w/wild-unit-target" taskset -c 26-31 cargo test --locked -p libwild --lib -j4 > "$p/logs/official-unit.log" 2>&1 || status=1
tail -5 "$p/logs/official-unit.log"
CARGO_TARGET_DIR="$w/wild-unit-target" taskset -c 26-31 cargo check --locked -p libwild --features macho -j4 > "$p/logs/macho-check.log" 2>&1 || status=1
tail -2 "$p/logs/macho-check.log"
export CARGO_TARGET_DIR="$p/target"
for group in custom-section exclude-section linker-script-discard linker-script-filename-match linker-script-short-section-name orphan-handling partial-link-repeated-sections sort-section-name sort-section-alignments;do
 logfile="$p/logs/official-$group.log"
 taskset -c 26-31 cargo test --locked --release -p wild-linker --test integration_tests -j4 -- "elf/x86_64/$group/" --test-threads 2 --color never > "$logfile" 2>&1 || status=1
 if ! rg -q 'test result: ok\. [1-9][0-9]* passed; 0 failed' "$logfile";then status=1;fi
 tail -2 "$logfile"
done
sha256sum "$p/target/release/wild" "$p/probe-wild" > "$p/logs/after-test-release-sha256.txt"
cmp "$p/target/release/wild" "$p/probe-wild" || status=1
exit "$status"
