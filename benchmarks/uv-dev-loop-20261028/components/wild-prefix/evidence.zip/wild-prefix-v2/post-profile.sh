#!/usr/bin/env bash
set -eu
q=$(cd "$(dirname "$0")" && pwd);w=$(dirname "$q");p="$w/wild-prefix"
until test -f "$q/actual/samples.csv" && test "$(wc -l < "$q/actual/samples.csv")" -eq 193;do
 if test -f "$q/logs/actual.log" && rg -q 'Traceback|AssertionError' "$q/logs/actual.log";then exit 1;fi
 sleep 2
done
taskset -c 24-25 python3 "$q/summarize.py" actual > "$q/actual/summary.json"
taskset -c 24-25 python3 "$q/compare-artifacts.py" > "$q/actual/artifacts.json"
taskset -c 24-25 python3 "$q/byte-differences.py" > "$q/actual/byte-differences.json"
sha256sum "$w/bin/matched-base" "$w/toolchain/bin/cargo" "$w/toolchain/bin/rustc" "$w/toolchain/bin/rustdoc" "$p/parent-wild" "$q/v2-wild" > "$q/actual/executables-sha256.txt"
export VALGRIND_LIB="$w/profiler/usr/libexec/valgrind" DEBUGINFOD_URLS= OUT="$q/profiled-uv"
taskset -c 24-25 "$w/edit-link-profile/captured/inputs/3/run-with" "$w/profiler/usr/bin/valgrind" --tool=callgrind --callgrind-out-file="$q/candidate.callgrind" "$q/v2-wild" -- --dynamic-linker /lib64/ld-linux-x86-64.so.2 --threads=1 --no-fork > "$q/logs/callgrind.log" 2>&1
cmp "$q/profiled-uv" "$w/edit-link-profile/replay/source-3"
taskset -c 24-25 python3 "$p/attribution.py" "$w/edit-link-profile/replay/link3-undefined.callgrind" "$q/candidate.callgrind" > "$q/attribution.json"
