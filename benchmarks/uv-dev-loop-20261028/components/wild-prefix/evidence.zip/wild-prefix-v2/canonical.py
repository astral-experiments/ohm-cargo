import hashlib,json,os,re,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent;p=q.parent/'wild-prefix';d=q/'captures';refs=json.loads((d/'emitted.json').read_text());out={}
for run in sorted(d.glob('inputs/*/run-with')):
    refs_in=list(dict.fromkeys(re.findall(r'/build/uv/([0-9a-f]+)/out/([^/ ]{1,90})\.rlink-objects/',run.read_text())));assert len(refs_in)==1
    name=refs_in[0][1];idx=int(run.parent.name);binary=d/f'canonical-{idx}'
    with (d/f'canonical-{idx}.log').open('w') as log:
        subprocess.run([run,p/'parent-wild','--','--dynamic-linker','/lib64/ld-linux-x86-64.so.2','--no-fork','--threads=1'],env=dict(os.environ,OUT=str(binary)),stdout=log,stderr=log,check=True)
    with binary.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    out[name]={'capture':idx,'bytes':binary.stat().st_size,'canonical_sha256':sha,'emitted_sha256':refs[name]['sha256']}
(d/'canonical.json').write_text(json.dumps(out,indent=2)+'\n')
