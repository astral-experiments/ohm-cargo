import collections,json,re,sys
from pathlib import Path
p=Path(__file__).resolve().parent

def graph(path):
    names={};lines=path.read_text().splitlines()
    for l in lines:
        m=re.match(r'c?fn=\((\d+)\) (.*)',l)
        if m:names[int(m[1])]=m[2]
    edges=collections.defaultdict(lambda:[0,0]);self_cost=collections.Counter();caller=callee=None;calls=0
    for l in lines:
        if l.startswith('totals:') or l.startswith('summary:'):total=int(l.split()[1])
        if (m:=re.match(r'fn=\((\d+)\)',l)):
            caller=names[int(m[1])];callee=None
        elif (m:=re.match(r'cfn=\((\d+)\)',l)):
            callee=names[int(m[1])]
        elif (m:=re.match(r'calls=(\d+)',l)):
            calls=int(m[1])
        elif (m:=re.match(r'(?:\d+|[+-]\d+|\*) (\d+)$',l)):
            count=int(m[1])
            if callee is not None and calls:
                e=edges[caller,callee];e[0]+=calls;e[1]+=count;calls=0;callee=None
            elif caller is not None:self_cost[caller]+=count
    return total,edges,self_cost

def summ(path):
    total,edges,self_cost=graph(path)
    group=collections.defaultdict(lambda:[0,0]);allcalls=collections.defaultdict(lambda:[0,0])
    for (caller,callee),(n,c) in edges.items():
        if 'resolve_sections<' in caller or 'resolve_section<' in caller:
            for kind in ('section_name', 'HashTable', 'try_find', 'hashbrown', 'read_bytes_at_until', 'LazyCell','default_section_rule','section_alignment'):
                if kind in callee:
                    r=group[kind];r[0]+=n;r[1]+=c
            if c>=5_000_000 and not 'resolve_sections<' in callee:
                r=allcalls[callee];r[0]+=n;r[1]+=c
    return {'total':total,'edge_groups':dict(group),'all_material_direct_edges':dict(sorted(allcalls.items(),key=lambda x:-x[1][1]))}
paths=sys.argv[1:] or [str(p.parent/'edit-link-profile/replay/link3-undefined.callgrind'),str(p/'candidate.callgrind')]
print(json.dumps({str(Path(f).name):summ(Path(f)) for f in paths},indent=2))
