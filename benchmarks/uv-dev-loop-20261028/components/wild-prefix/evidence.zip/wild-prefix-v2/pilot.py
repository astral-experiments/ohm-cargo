import csv,hashlib,itertools,json,os,random,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent;p=q.parent/'wild-prefix';w=q.parent
d=q/'pilot';d.mkdir(exist_ok=True)
f=p/'fallback'
cases={'partial':['-r','--whole-archive','../../edit-link-profile/target/debug/build/uv-client/58adf456cbf5b40c/out/libuv_client-58adf456cbf5b40c.rlib'],
       'data':['--no-gc-sections','--unresolved-symbols=ignore-all','-e','0','data-debug.o'],
       'script':['--no-gc-sections','--unresolved-symbols=ignore-all','-e','0','-T','override.ld','data-debug.o'],
       'new_uv_harness':None}
bins={'parent':p/'parent-wild','v1':p/'probe-wild','v2':q/'v2-wild'}
def sha(path):
    with path.open('rb') as z:return hashlib.file_digest(z,'sha256').hexdigest()
ref=json.loads((q/'captures/canonical.json').read_text())['uv-23905aefc33b1c4d']
orders=list(itertools.permutations(bins)); met={}
with (d/'samples.csv').open('x') as log:
    writer=csv.writer(log);writer.writerow(['case','block','position','arm','instructions','out_sha256'])
    for i,(case,caseargs) in enumerate(cases.items()):
        order=list(orders);random.Random(611809+i).shuffle(order);target=d/f'{case}.elf'
        expected=ref['canonical_sha256'] if caseargs is None else sha(f/f'check-{case}')
        expected_diag='' if caseargs is None else (f/f'{case}.log').read_text()
        met[case]={'orders':order,'expected':expected,'seed':611809+i}
        (d/'orders.json').write_text(json.dumps(met,indent=2)+'\n')
        for block,seq in enumerate(order):
            for pos,arm in enumerate(seq):
                ins=['python3','-B',str(w/'dynamorio/count.py'),'--',str(bins[arm])]
                if caseargs is None:
                    cmd=[str(q/'captures/inputs'/str(ref['capture'])/'run-with'),*ins,'--','--dynamic-linker','/lib64/ld-linux-x86-64.so.2','--no-fork','--threads=1']
                else:
                    cmd=[*ins,'--no-fork','--threads=1','-m','elf_x86_64',*caseargs,'-o',str(target)]
                cp=subprocess.run(cmd,cwd=f,env=dict(os.environ,OUT=str(target)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True)
                (d/f'{case}-{block}-{pos}-{arm}.log').write_text(cp.stdout)
                diag,res=cp.stdout.rsplit('DynamoRIO ',1);assert diag==expected_diag,(case,arm,diag)
                count=json.loads(res)['instructions'];digest=sha(target)
                writer.writerow([case,block,pos,arm,count,digest]);log.flush();assert digest==expected,(case,arm,digest,expected)
            print(case,block,flush=True)
