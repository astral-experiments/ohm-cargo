import csv,hashlib,json,os,random,re,subprocess,sys
from pathlib import Path
q=Path(__file__).resolve().parent;w=q.parent;p=w/'wild-prefix';d=q/'links'
d.mkdir(exist_ok=True)
units=['uv','uv-c84366b26c530121']
refs=json.loads((q/'captures/canonical.json').read_text())
arms=['parent','v2'];bins={'parent':p/'parent-wild','v2':q/'v2-wild'}
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
plans={}
for j,unit in enumerate(units):
    first=[0,1]*5;seed=776501+j;random.Random(seed).shuffle(first)
    plans[unit]={'seed':seed,'orders':[[arms[i],arms[1-i]] for i in first],'sha256':refs[unit]['canonical_sha256'],'capture':refs[unit]['capture']}
protocol={'stage':'two reserved alternate-source actual uv shapes. Single-thread complete Wild instructions, strict per-run equality to canonical and originally emitted ELF, ten randomized balanced pairs per shape. Median within-pair relative instruction savings, sign and restricted permutation tests. Complete all pairs; the gate requires both effects positive and both tests below 0.05 on each shape.','bins':{a:sha(f) for a,f in bins.items()},'units':plans}
path=d/'plan.json'
if sys.argv[1:]==['--freeze']:
    assert all(refs[u]['canonical_sha256']==refs[u]['emitted_sha256'] for u in units)
    with path.open('x') as f:f.write(json.dumps(protocol,indent=2)+'\n')
    sys.exit()
assert json.loads(path.read_text())==protocol
for name,pl in plans.items():
    with (d/f'{name}.csv').open('x') as raw:
        wri=csv.writer(raw);wri.writerow(['pair','position','arm','linker_instructions','output_sha256'])
        for pair,order in enumerate(pl['orders']):
            for pos,arm in enumerate(order):
                out=d/f'{name}.elf';log=d/f'{name}-{pair}-{pos}-{arm}.log'
                cmd=[q/'captures/inputs'/str(pl['capture'])/'run-with','python3','-B',w/'dynamorio/count.py','--',bins[arm],'--','--dynamic-linker','/lib64/ld-linux-x86-64.so.2','--no-fork','--threads=1']
                with log.open('w') as fh:subprocess.run(cmd,env=dict(os.environ,OUT=str(out)),stdout=fh,stderr=fh,check=True)
                diag,res=log.read_text().rsplit('DynamoRIO ',1);assert not diag
                ins=json.loads(res)['instructions'];dig=sha(out);wri.writerow([pair,pos,arm,ins,dig]);raw.flush();assert dig==pl['sha256'],(name,pair,arm,dig,pl['sha256'])
            print(name,pair,flush=True)
