from pathlib import Path
import zipfile
q=Path(__file__).resolve().parent;w=q.parent;p=w/'wild-prefix'
en=q/'evidence-full.zip'
out=w/'wild-prefix-evidence.zip'
guide="""# Reproduce the Ohm Wild section-placement study

`wild-prefix-v2` contains the final patch, regression test, preregistrations, primary edited-command and link replay data, full-file digests, code, QA and results. Its parent is Ohm Wild #45. `wild-prefix` retains the first experiment and its fallback-control regression, including its separate 32-command cohort. The two directories use independent registrations and accumulated samples.

Use the README in each directory. Keep them as siblings. `wild-link-benchmarks.zip` supplies the separate original cold-diagnostics study and its instrumentation wrappers. Extract it into a sibling `edit-link-profile` directory for recapturing source and inputs. Install the same packaged Ohm and DynamoRIO versions before collecting new measurements. The sections study stores the actual invocation recipes, raw instruction and diagnostic logs, artifact SHA-256s and complete byte-difference offsets. On a fresh checkout derive local whole-file parent oracles, which include local source paths.
"""
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    z.writestr('README.md',guide)
    z.write(w.parent/'outputs/wild-link-benchmarks.zip','wild-link-benchmarks.zip')
    for study in (p,q):
        with zipfile.ZipFile(study/'evidence-full.zip') as zz:
            for name in zz.namelist():
                z.writestr(study.name+'/'+name,zz.read(name))
            included=set(zz.namelist())
        for name in ('diagnostics.py','actual/diagnostics.json','no-cet/cc','no-cet/gcc','finish-summary.py','package-all.py'):
            path=study/name
            if path.is_file() and name not in included:z.write(path,study.name+'/'+name)
print(out,out.stat().st_size)
