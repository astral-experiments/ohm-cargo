import json,mmap,os,struct
from pathlib import Path
d=Path(__file__).resolve().parent/'actual';tab=json.loads((d/'artifacts.json').read_text())
def mapsections(b):
    off=struct.unpack_from('<Q',b,40)[0];width,num,i=struct.unpack_from('<HHH',b,58)
    st,sn=struct.unpack_from('<QQ',b,off+i*width+24);names=b[st:st+sn];by=[(0,64,'ELF header'),(off,off+width*num,'section headers')]
    phex=struct.unpack_from('<Q',b,32)[0];phwidth,phnum=struct.unpack_from('<HH',b,54)
    by.append((phex,phex+phwidth*phnum,'program headers'))
    for i in range(num):
        idx,t=struct.unpack_from('<II',b,off+i*width);start,length=struct.unpack_from('<QQ',b,off+i*width+24)
        if t!=8 and length:by.append((start,start+length,names[idx:names.index(0,idx)].decode(errors='replace')))
    return sorted(by)
def ranges(bs):
    result=[]
    for i in bs:
        if result and result[-1][1]==i:result[-1][1]+=1
        else:result.append([i,i+1])
    return result
result={}
for key,fields in tab.items():
    if 'unique_files' not in fields:continue
    digest=fields['unique_files'];base,*other=sorted(digest);out=[]
    for h in other:
        with (d/'artifacts'/base).open('rb') as fa,(d/'artifacts'/h).open('rb') as fb,mmap.mmap(fa.fileno(),0,access=mmap.ACCESS_READ) as a,mmap.mmap(fb.fileno(),0,access=mmap.ACCESS_READ) as b:
            assert len(a)==len(b);ds=[]
            for ix in range(0,len(a),65536):
                aa=a[ix:ix+65536];bb=b[ix:ix+65536]
                if aa!=bb:ds.extend(ix+i for i,(x,y) in enumerate(zip(aa,bb)) if x!=y)
            sections=mapsections(a)
            for start,end in ranges(ds):
                parent=[i for i in sections if i[0]<=start<i[1]]
                prev=[i for i in sections if i[1]<=start];nex=[i for i in sections if i[0]>=end]
                out.append({'pair':[base,h],'start':start,'end':end,'region':parent[0][2] if parent else 'padding after '+prev[-1][2]+' before '+nex[0][2] if prev and nex else 'unmapped','a_hex':a[start:min(end,start+64)].hex(),'b_hex':b[start:min(end,start+64)].hex()})
    result[key]=out
print(json.dumps(result,indent=2))
