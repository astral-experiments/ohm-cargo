"""Summarize frozen paired link replays and ABBA/BAAB edited-command blocks."""
import csv, itertools, json, math, statistics, sys
from collections import defaultdict
from pathlib import Path
p=Path(__file__).resolve().parent

def tests(diffs,reported):
    nonzero=[d for d in diffs if d]
    k=min(sum(d>0 for d in nonzero),sum(d<0 for d in nonzero))
    sign=min(1,2*sum(math.comb(len(nonzero),v) for v in range(k+1))/2**len(nonzero))
    # The preregistered generator randomizes a balanced assignment to the first arm.
    directions=[1 if x=='parent' else -1 for x in reported]
    pos=[d*t for d,t in zip(diffs,directions)]
    observed=abs(sum(diffs))
    null=[]
    for plus in itertools.combinations(range(len(pos)),len(pos)//2):
        plus=set(plus)
        null.append(abs(sum(v if i in plus else -v for i,v in enumerate(pos))))
    return sign,sum(d>=observed for d in null)/len(null)

def replay(i,stage):
    d=p/stage
    rows=list(csv.DictReader((d/f'samples-{i}.csv').open()))
    order=[];pairs=defaultdict(dict)
    for row in rows:
        if row['position']=='0':order.append(row['arm'])
        pairs[int(row['pair'])][row['arm']]=int(row['linker_instructions'])
    assert len(pairs)==(2 if stage=='screen' else 8) and all(len(v)==2 for v in pairs.values())
    diffs=[v['parent']-v['probe'] for v in pairs.values()]
    frac=[d/v['parent']*100 for v,d in zip(pairs.values(),diffs)]
    return {'n':len(pairs),'parent_median':statistics.median(v['parent'] for v in pairs.values()),'probe_median':statistics.median(v['probe'] for v in pairs.values()),'median_pct':statistics.median(frac),'range_pct':[min(frac),max(frac)],'sign_and_permutation_p':tests(diffs,order),'sha256s':sorted({r['output_sha256'] for r in rows})}

def actual():
    rows=list(csv.DictReader((p/'actual/samples.csv').open()))
    totals=[r for r in rows if r['unit']=='TOTAL']
    assert len(totals)==32 and len(rows)-len(totals)==160
    blocks=defaultdict(lambda:defaultdict(int));order=[]
    for r in totals:
        if r['position']=='0':order.append(r['arm'])
        blocks[int(r['block'])][r['arm']]+=int(r['instructions'])
    diffs=[v['parent']-v['v2'] for v in blocks.values()]
    effects=[d/v['parent']*100 for v,d in zip(blocks.values(),diffs)]
    b=defaultdict(lambda:defaultdict(set));th=defaultdict(set)
    for r in rows:
        if r['unit']=='TOTAL':continue
        b[(r['source'],r['unit'])][r['arm']].add(r['sha256']);th[r['unit']].add(int(r['wild_threads']))
    return {'n_blocks':8,'commands':32,'wild_children':160,'median_pct':statistics.median(effects),'block_pct':effects,'sign_and_permutation_p':tests(diffs,order),
            'threads_by_unit':{k:sorted(v) for k,v in th.items()},'distinct_by_source_unit':{str(k):{a:sorted(v) for a,v in fam.items()} for k,fam in b.items()},
            'mean_linker_insns_command':{a:sum(int(v['instructions']) for v in totals if v['arm']==a)/16 for a in ('parent','v2')}}
if sys.argv[1:]==['actual']:result=actual()
else:result={i:replay(i,stage) for i,stage in [(3,'screen'),(0,'holdout'),(2,'holdout')]}
print(json.dumps(result,indent=2))
