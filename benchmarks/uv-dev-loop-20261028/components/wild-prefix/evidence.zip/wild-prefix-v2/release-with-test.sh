#!/usr/bin/env bash
set -eu
q=$(cd "$(dirname "$0")" && pwd); w=$(dirname "$q")
until test -f "$q/actual/samples.csv" && test "$(wc -l < "$q/actual/samples.csv")" -eq 193;do
 if test -f "$q/logs/actual.log" && rg -q 'Traceback|AssertionError' "$q/logs/actual.log";then exit 1;fi
 sleep 2
done
cd "$q/test-src"
RUSTUP_TOOLCHAIN=stable CARGO_HOME="$w/cargohome" CARGO_NET_OFFLINE=true CARGO_TARGET_DIR="$q/target" taskset -c 26-31 cargo build --release --locked -p wild-linker -j4 > "$q/logs/normal-release-with-test.log" 2>&1
sha256sum "$q/target/release/wild" "$q/v2-wild" > "$q/logs/normal-release-with-test.sha256"
cmp "$q/target/release/wild" "$q/v2-wild"
