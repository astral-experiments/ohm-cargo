"""Rebuild both edited source states per arm in pre-registered ABBA/BAAB blocks."""
import csv
import hashlib
import json
import os
import random
import subprocess
import sys
from pathlib import Path
p=Path(__file__).resolve().parent
w=p.parent
r=w/'edit-link-profile'
n=r/'native-instrument'
out=p/'actual'
out.mkdir(exist_ok=True)
units={'uv','uvx','uv-23905aefc33b1c4d','uv-c84366b26c530121','uvx-141090d4fffe584e'}
arms=['parent','v2']
orders=[0,1]*4
seed=1059043
random.Random(seed).shuffle(orders)
plan={'seed':seed,'orders':['ABBA' if oi==0 else 'BAAB' for oi in orders],
      'arms':{'A':'#45 release-source parent 435a253fcd8a44061aa0d88748ca12b8e63a092dc9d42593195142d8071ebc81',
              'B':'wild-prefix-v2 frozen 901b68fc9ca30975d837d45dcf1bdf743a6130ecef5e23d6aef44558b09bd7e1'},
      'endpoint':'Sum complete DynamoRIO Wild instruction counts of all five linker child invocations within each actual edited cargo test --no-run. Each block effect is one minus the sum of the two candidate command totals divided by the sum of the two parent totals. Median of all eight block effects. Two-sided exact sign test at alpha 0.05, ties omitted; balanced-order assignment permutation p-value also reported.',
      'workload':'uv c22e6b71933443e9cd299d4b6ac8de035ed4825b, untouched Ohm Cargo 1.99.0-17 and rustc, test --no-run --locked --offline -j4; alternating equivalent edit to crates/uv/src/install_source.rs; taskset -c 24-31; Wild default jobserver and no thread override, --no-fork solely so all Wild threads counted.',
      'completion':'Complete all eight blocks without early stopping for effect. Require precisely five known linked units and exit 0 per invocation. Retain link outputs content-addressed and all SHA-256 digests. Report all parity discrepancies including any shared parent nondeterminism.',
      'order_units':sorted(units)}
plan_path=out/'plan.json'
if sys.argv[1:]==['--freeze']:
    with plan_path.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
    print(plan['orders']);sys.exit()
assert json.loads(plan_path.read_text())==plan
artifacts=out/'artifacts';artifacts.mkdir(exist_ok=True)
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def preserve(path):
    digest=sha(path);target=artifacts/digest
    if not target.exists():
        subprocess.run(['cp','--reflink=auto','--preserve=mode',path,target], check=True)
    return digest
with (out/'samples.csv').open('x') as f:
    writer=csv.writer(f);writer.writerow(['block','position','source','arm','unit','wild_threads','instructions','bytes','sha256']);f.flush()
    for block,order in enumerate(plan['orders']):
        edits={'parent':set(),'v2':set()}
        for pos,key in enumerate(order):
            arm=arms['AB'.index(key)]
            edit=subprocess.check_output([n/'toggle'],text=True).strip();edits[arm].add(edit)
            label=f'{block}-{pos}-{arm}-{edit}';d=out/label;d.mkdir()
            env={**os.environ,'CARGO_HOME':str(w/'cargohome'),'CARGO_TARGET_DIR':str(r/'target'),
                 'RUSTC':str(w/'toolchain/bin/rustc'),'RUSTDOC':str(w/'toolchain/bin/rustdoc'),
                 'CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never','CARGO_LOG':'cargo::compiler=info',
                 'PATH':f"{w/'toolchain/bin'}:{n/'tool'}:{os.environ['PATH']}",
                 'OHM_PRIVATE_WILD':str(w/'wild-prefix'/'parent-wild' if arm=='parent' else p/'v2-wild'),'OHM_WILD_LOG':str(d),'OHM_WILD_COUNT':'1'}
            env.pop('OHM_WILD_SERIAL',None)
            with (out/f'{label}.log').open('w') as raw:
                subprocess.run([w/'bin/matched-base','test','--no-run','--locked','--offline','-j4'],cwd=r/'uv',env=env,stdout=raw,stderr=raw,check=True)
            total=0;seen=set()
            for pathlog in sorted(d.glob('*.outpath')):
                path=Path(pathlog.read_text().strip());unit=path.name
                assert unit not in seen;seen.add(unit)
                counts=json.loads(pathlog.with_suffix('.log').read_text().rsplit('DynamoRIO ',1)[1])
                insn=counts['instructions'];total+=insn
                writer.writerow([block,pos,edit,arm,unit,len(counts['threads'])-1,insn,path.stat().st_size,preserve(path)])
            assert seen==units,(label,seen)
            writer.writerow([block,pos,edit,arm,'TOTAL','',total,'','']);f.flush()
            print(block,pos,arm,edit,total,flush=True)
        assert len(edits['parent'])==len(edits['v2'])==2 and edits['parent']==edits['v2'],(block,edits)
