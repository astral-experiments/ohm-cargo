from collections import Counter
import json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
logs=list(root.glob('*-*-*/*.log')); assert len(logs)==160
cargo=list(root.glob('*-*-*.log'));assert len(cargo)==32
wild=Counter();warn=Counter()
for log in logs:
    raw=log.read_text();d,tag,instrument=raw.rpartition('DynamoRIO ')
    assert tag and json.loads(instrument)['instructions']>0
    if d:wild[d]+=1
for log in cargo:
    for line in log.read_text().splitlines():
        if re.match(r'^\s*(?:warning|error)(?:\[[^\]]+\])?:',line):warn[line]+=1
print(json.dumps({'n_wild_stderr_logs':len(logs),'wild_stderr_before_profiler_record':wild,'n_cargo_combined_output_logs':len(cargo),'cargo_warning_or_error_lines':warn},indent=2))
