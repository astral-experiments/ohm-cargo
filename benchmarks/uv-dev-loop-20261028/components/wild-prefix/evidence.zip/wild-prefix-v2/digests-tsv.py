import csv,json,sys
from pathlib import Path
d=Path(sys.argv[1]);z=json.loads((d/'artifacts.json').read_text())
arms=sorted({arm for obj in z.values() for arm in obj['observed']})
with (d/'digest-counts.tsv').open('w') as stream:
    wr=csv.writer(stream,delimiter='\t',lineterminator='\n');wr.writerow(['source','unit','complete_file_sha256',*arms])
    for key,obj in z.items():
        fam=obj['observed'];source,unit=key.split('/',1)
        for h in sorted(set().union(*fam.values())):wr.writerow([source,unit,h,*(fam.get(arm,{}).get(h,0) for arm in arms)])
