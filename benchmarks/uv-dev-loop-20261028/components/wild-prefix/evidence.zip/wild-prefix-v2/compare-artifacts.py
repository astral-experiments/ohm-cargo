import csv,hashlib,json,mmap,struct
from collections import defaultdict,Counter
from pathlib import Path
p=Path(__file__).resolve().parent;d=p/'actual'
sets=defaultdict(lambda:defaultdict(Counter))
for r in csv.DictReader((d/'samples.csv').open()):
    if r['unit']!='TOTAL':sets[r['source'],r['unit']][r['arm']][r['sha256']]+=1

def examine(path):
    with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as b:
        off=struct.unpack_from('<Q',b,40)[0]; width,num,i=struct.unpack_from('<HHH',b,58)
        name_start,name_size=struct.unpack_from('<QQ',b,off+i*width+24)
        names=b[name_start:name_start+name_size]
        for i in range(num):
            name=struct.unpack_from('<I',b,off+i*width)[0];section=names[name:names.index(0,name)]
            if section!=b'.note.gnu.build-id':continue
            begin,length=struct.unpack_from('<QQ',b,off+i*width+24)
            nn,nd,typ=struct.unpack_from('<III',b,begin)
            assert typ==3 and b[begin+12:begin+12+nn]==b'GNU\0'
            lo=begin+12+(nn+3)//4*4;hi=lo+nd
            assert hi<=begin+length
            parts=hashlib.sha256()
            parts.update(memoryview(b)[:lo]);parts.update(memoryview(b)[hi:])
            return (lo,hi,b[lo:hi].hex(),parts.hexdigest())
    raise AssertionError('GNU build ID missing')
result={}
for k,family in sorted(sets.items()):
    hashes=set().union(*family.values())
    r={'observed':dict(family),'same_full_digest_sets':len(family)==2 and len({frozenset(x) for x in family.values()})==1}
    if len(hashes)>1:
        info={h:examine(d/'artifacts'/h) for h in sorted(hashes)}
        r['all_file_bytes_except_build_id_descriptor_match']=len({(x[0],x[1],x[3]) for x in info.values()})==1
        r['unique_files']={key:{'payload_start':a,'payload_end':b,'build_id':c,'outside_payload_sha256':e} for key,(a,b,c,e) in info.items()}
    result[k[0]+'/'+k[1]]=r
print(json.dumps(result,indent=2,sort_keys=True))
