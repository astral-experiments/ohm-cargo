#!/usr/bin/env bash
set -eu
q=$(cd "$(dirname "$0")" && pwd);w=$(dirname "$q");p="$w/wild-prefix"
cd "$q/test-src"
export RUSTUP_TOOLCHAIN=stable CARGO_NET_OFFLINE=true CARGO_HOME="$w/cargohome" CARGO_TARGET_DIR="$w/wild-unit-target" PATH="$w/wild-test-tools/bin:$PATH"
extpath="$PATH";qa_rc=0
taskset -c 26-31 cargo test --locked -p libwild --lib -j4 > "$q/logs/official-unit.log" 2>&1 || qa_rc=1
taskset -c 26-31 cargo check --locked -p libwild --features macho -j4 > "$q/logs/macho-check.log" 2>&1 || qa_rc=1
for group in custom-section exclude-section linker-script-discard linker-script-filename-match linker-script-short-section-name orphan-handling partial-link-repeated-sections sort-section-name sort-section-alignments;do
 if test "$group" = orphan-handling;then export PATH="$p/no-cet:$extpath";else export PATH="$extpath";fi
 WILD_TEST_BUILD_DIR="$q/official-fixtures" taskset -c 26-31 cargo test --locked -p wild-linker --test integration_tests -j4 -- "elf/x86_64/$group/" --test-threads 2 --color never > "$q/logs/official-$group.log" 2>&1 || qa_rc=1
 if ! rg -q 'test result: ok\. [1-9][0-9]* passed; 0 failed' "$q/logs/official-$group.log";then qa_rc=1;fi
 tail -2 "$q/logs/official-$group.log"
done
exit "$qa_rc"
