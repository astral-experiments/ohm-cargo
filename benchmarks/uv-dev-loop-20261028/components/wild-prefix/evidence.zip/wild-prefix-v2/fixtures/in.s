
.section .text.startup,"ax",@progbits
.global _start
_start: lea var(%rip),%rax; ret
.section .text.hot.foo,"ax",@progbits
.byte 0xc1
.section .text.unlikely.foo,"ax",@progbits
.byte 0xb1
.section .texture,"ax",@progbits
.byte 0xd1
.section .text.exclude,"axe",@progbits
.byte 0xe1
.section .relaxed,"a",@progbits
.byte 0xf1
.section .tex,"a",@progbits
.byte 0x72
.section .data,"aw",@progbits
var: .byte 0x33
