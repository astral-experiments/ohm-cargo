import collections,csv,json,statistics
from pathlib import Path
q=Path(__file__).resolve().parent;rows=list(csv.DictReader((q/'pilot/samples.csv').open()))
assert len(rows)==72
groups=collections.defaultdict(lambda:collections.defaultdict(dict));digests=collections.defaultdict(set)
for r in rows:
    groups[r['case']][int(r['block'])][r['arm']]=int(r['instructions']);digests[r['case']].add(r['out_sha256'])
result={}
for case,bs in groups.items():
    assert len(bs)==6 and all(set(i)=={'parent','v1','v2'} for i in bs.values()) and len(digests[case])==1
    effects={a:[(v[a]/v['parent']-1)*100 for v in bs.values()] for a in ('v1','v2')}
    result[case]={'sha256':next(iter(digests[case])),'mean_instructions':{a:statistics.mean(v[a] for v in bs.values()) for a in ('parent','v1','v2')},'changes_pct':{a:statistics.median(fx) for a,fx in effects.items()},'range_pct':{a:[min(fx),max(fx)] for a,fx in effects.items()}}
passed=all(result[c]['changes_pct']['v2']<=max(0,0.60*result[c]['changes_pct']['v1']) for c in ('partial','script')) and result['data']['changes_pct']['v2']<=0.10 and result['new_uv_harness']['changes_pct']['v2']<=-2
print(json.dumps({'registered_gate_passed':passed,'cases':result},indent=2))
if not passed:raise SystemExit(1)
