import csv,itertools,json,math,statistics
from pathlib import Path
q=Path(__file__).resolve().parent;d=q/'links';plans=json.loads((d/'plan.json').read_text())['units'];result={}
for unit,plan in plans.items():
    rows=list(csv.DictReader((d/f'{unit}.csv').open()));assert len(rows)==20
    pairs=[{r['arm']:int(r['linker_instructions']) for r in rows if int(r['pair'])==i} for i in range(10)]
    assert all(set(x)=={'parent','v2'} for x in pairs)
    diff=[x['parent']-x['v2'] for x in pairs];pct=[v/x['parent']*100 for x,v in zip(pairs,diff)]
    signs=sum(v>0 for v in diff);nonzero=sum(v!=0 for v in diff);s=min(signs,nonzero-signs)
    p=2*sum(math.comb(nonzero,i) for i in range(s+1))/2**nonzero
    first=[v if arms[0]=='parent' else -v for v,arms in zip(diff,plan['orders'])]
    null=[]
    for cp in itertools.combinations(range(10),5):
        indices=set(cp);null.append(abs(sum(x if i in indices else -x for i,x in enumerate(first))))
    perm=sum(x>=abs(sum(diff)) for x in null)/len(null)
    assert len({r['output_sha256'] for r in rows})==1 and rows[0]['output_sha256']==plan['sha256']
    result[unit]={'n_pairs':10,'median_parent':statistics.median(x['parent'] for x in pairs),'median_v2':statistics.median(x['v2'] for x in pairs),'median_saving_pct':statistics.median(pct),'range_pct':[min(pct),max(pct)],'sign_p':p,'balanced_permutation_p':perm,'sha256':plan['sha256'],'passed':statistics.median(pct)>0 and p<0.05 and perm<0.05}
print(json.dumps(result,indent=2))
