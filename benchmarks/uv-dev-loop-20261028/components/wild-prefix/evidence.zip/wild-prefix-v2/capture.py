import hashlib,json,os,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent;w=q.parent;r=w/'edit-link-profile';n=r/'native-instrument';p=w/'wild-prefix'
d=q/'captures';d.mkdir(exist_ok=True);inputs=d/'inputs';inputs.mkdir(exist_ok=True);logs=d/'logs';logs.mkdir(exist_ok=True)
src=r/'uv/crates/uv/src/install_source.rs';before=src.read_bytes()
assert b'component == cellar && next == formula' in before
needle=b'PathBuf::from(path)';assert before.count(needle)==1
after=before.replace(needle,b'PathBuf::from(path.as_os_str())')
(d/'source.original.rs').write_bytes(before);(d/'source.alternate.rs').write_bytes(after)
try:
    src.write_bytes(after)
    env={**os.environ,'CARGO_HOME':str(w/'cargohome'),'CARGO_TARGET_DIR':str(r/'target'),'RUSTC':str(w/'toolchain/bin/rustc'),'RUSTDOC':str(w/'toolchain/bin/rustdoc'),'CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never','PATH':f"{w/'toolchain/bin'}:{n/'tool'}:{os.environ['PATH']}",'OHM_PRIVATE_WILD':str(p/'parent-wild'),'OHM_WILD_LOG':str(logs),'WILD_SAVE_BASE':str(inputs)}
    env.pop('OHM_WILD_COUNT',None);env.pop('OHM_WILD_SERIAL',None)
    cmd=[w/'bin/matched-base','test','--no-run','--locked','--offline','-j4']
    with (d/'cargo.log').open('w') as f:subprocess.run(cmd,cwd=r/'uv',env=env,stdout=f,stderr=f,check=True)
    refs={};original=d/'emitted';original.mkdir(exist_ok=True)
    for rec in logs.glob('*.outpath'):
        out=Path(rec.read_text().strip());copy=original/out.name
        subprocess.run(['cp','--reflink=auto','--preserve=mode',out,copy],check=True)
        with copy.open('rb') as f:refs[out.name]={'bytes':copy.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
    assert len(refs)==5 and len(list(inputs.glob('*/run-with')))==5
    (d/'emitted.json').write_text(json.dumps(refs,indent=2)+'\n')
    print(refs)
finally:
    src.write_bytes(before)
