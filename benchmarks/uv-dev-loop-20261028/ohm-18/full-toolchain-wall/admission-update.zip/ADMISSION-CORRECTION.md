# Full-toolchain Cargo check admission update

The shipped compiler rotates between build-mode artifacts in the same uv target. The original verifier rejected a zero-byte file left by an earlier build. The corrected verifier identifies the current nonempty library metadata from the traced rustc command and preserves every other coexisting metadata file, including the empty file and its SHA-256. Its gate was frozen before any elapsed observations.

For the first kit, SHA-256 `ba9e6e3c7bd7d8573d8fa1a132b6e46ea1b35f4b4129b2bdeb39bd450261efb1`, extract the small update over the extracted kit, then check its manifest.

```sh
unzip -o ohm-18-full-toolchain-update.zip -d /path/to/kit
(cd /path/to/kit && sha256sum --quiet -c SHA256SUMS)
```

If you already staged or warmed a work directory with the first kit, preserve it and upgrade its runner before timing. The installer retains any earlier zero-row admission under `check.before-metadata-v2`.

```sh
python3 /path/to/kit/upgrade-staged.py /path/to/staged-work
```

Then use the ordinary stage, warm, time, and score commands in README.md as appropriate for your work directory. The eight targets, four toolchains, six schedules, 576 assignments, and scoring rules retain their registered identities.
