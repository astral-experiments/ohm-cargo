"""Install the check admission correction in an already staged Ohm -18 replay."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import tempfile


PLAN = 'e42520290d4204514948d558fa9ff5664de51385923d2b6ff1f9d62fe4b8db34'
OLD = 'c11b420bf0899e444d8a6718889f2de0dbbec7020ed96c69056268685c3a9986'
FILES = {
    'metadata-admission-v2.json': 'e939899d5f50898c0f8c367c594be0e1c2f98e951fd977942e913af9003ecf2a',
    'metadata_admission.py': '60416f551d58de5fec9c945b57f43101a4d56edf6e6a1ea4d345654a8f378efc',
    'run.py': '44be0417ce2706d2ccc664f538315520b21327f3cb282888cf3b579e67fd0490',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install(work, kit):
    dst = work / 'round18-compiler/literal-native-amended'
    src = kit / 'protocol/literal-native-amended'
    cfg = json.loads((work / 'replay.json').read_text())
    if cfg['registered'] != PLAN or cfg['relocated'] != digest(dst / 'plan.json'):
        raise ValueError('The staged plan does not match the Ohm -18 replay.')
    for name, expected in FILES.items():
        if digest(src / name) != expected:
            raise ValueError(f'Unexpected update file {src/name}')
    if all((dst/name).is_file() and digest(dst/name) == expected for name, expected in FILES.items()):
        return
    if digest(dst/'run.py') != OLD:
        raise ValueError('The staged runner differs from the original replay.')
    for name, expected in FILES.items():
        if name != 'run.py' and (dst/name).exists() and digest(dst/name) != expected:
            raise ValueError(f'The staged copy of {name} differs from this update.')
    for cohort in ('initial', 'replica'):
        for ep in ('check', 'build', 'test'):
            trial = dst / 'evidence' / cohort / ep
            if (trial/'done.json').exists():
                raise ValueError(f'The original replay already completed {trial}.')
            rows = trial/'timings.csv'
            if rows.exists():
                with rows.open(newline='') as stream:
                    if next(csv.DictReader(stream), None) is not None:
                        raise ValueError(f'The original replay recorded timed rows in {trial}.')
            if trial.exists() and (cohort, ep) != ('initial', 'check'):
                raise ValueError(f'Unexpected earlier admission in {trial}.')
    failed = dst/'evidence/initial/check'
    if failed.exists():
        if not (failed/'admission-shipped/cargo.log').exists() or (failed/'admitted.json').exists():
            raise ValueError(f'Unrecognized first admission in {failed}.')
        archive = failed.with_name('check.before-metadata-v2')
        if archive.exists():
            raise ValueError(f'The earlier admission archive already exists at {archive}.')
        failed.rename(archive)
    for name in FILES:
        with tempfile.NamedTemporaryFile(dir=dst, delete=False) as temporary:
            temporary.write((src/name).read_bytes())
        os.replace(temporary.name, dst/name)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('staged_work_directory', type=Path)
    args = parser.parse_args()
    install(args.staged_work_directory.resolve(), Path(__file__).resolve().parent)
    print('The staged full-toolchain replay uses the trace-bound check metadata verifier.')
