"""Exercise assignment, logical target identity and failed-switch restoration without touching any experiment input."""
import itertools,json,tempfile
from pathlib import Path
import run
import analyze
r={'schedule':{},'switch_restore':False,'logical_target':False}
for name,c in run.PLAN['cohorts'].items():
 for ep,sch in c['endpoints'].items():
  pool={order:0 for order in itertools.permutations(run.ARMS)};blocks=[]
  for i,item in enumerate(sch):
   pool[tuple(item['order'])]+=1;blocks.append([dict(arm=a,rank=j,elapsed_ns={'base':20000,'stack':18000,'shipped':21000}[a]+i) for j,a in enumerate(item['order'])]);
  assert len(sch)==24 and set(pool.values())=={4};v=analyze.compare(blocks,'base','stack');assert v['conditional_two_sided_p']<.05/6 and v['median_saved_pct_interval']['lower']>0 and min(v['median_saved_pct_by_order'].values())>0;assert len({x['literal'] for x in sch})==24;r['schedule'][name+'-'+ep]={'blocks':len(sch),'orders':len(pool),'synthetic_conditional_p':v['conditional_two_sided_p']}
with tempfile.TemporaryDirectory() as t:
 d=Path(t);run.R=d;co=d/'cohort';co.mkdir()
 for q in (d/'sysroots/base',co/'targets/base',co/'homes/base'):q.mkdir(parents=True)
 try:
  with run.active(co,'base'):
   assert (d/'tools').is_dir() and (co/'target').is_dir() and (co/'cargo-home').is_dir();raise ValueError('intentional')
 except ValueError:pass
 assert (d/'sysroots/base').is_dir() and not (d/'tools').exists() and (co/'targets/base').is_dir() and (co/'homes/base').is_dir();r['switch_restore']=True
 ps=co/'target/debug/deps';ps.mkdir(parents=True);files=[ps/('uv-'+x*16) for x in ('a','f')]
 for p in files:p.write_text('')
 fake=[run.logical(co,{'compiled':['uv v0.12.0'], 'tests':['unittests src/lib.rs ('+str(p)+')']}) for p in files];assert fake[0]==fake[1];r['logical_target']=True
print(json.dumps(r,indent=2))
