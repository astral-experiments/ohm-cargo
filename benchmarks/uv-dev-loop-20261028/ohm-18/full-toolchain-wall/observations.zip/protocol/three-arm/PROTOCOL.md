# Literal Ohm stage-2 native holdout

`plan.json` freezes 432 complete Cargo commands before either final stage-2 compiler exists. The three arms are the installed Ohm 1.99.0-18, the matched rebuilt control and the eight published changes. The treatment combines five Cargo patches with their own non-uv-trained Cargo PGO, the published standard-library patch in Cargo, the compiler and the consuming process, and both published Wild patches. The matched compiler and std use the same pinned source, external released LLVM, release-like ThinLTO and one CGU. The installed control carries the official distribution compiler optimizations. Claims against the official toolchain require its observed native comparison.

## Initialize and warm

Both `../full-toolchain/arms/{base,guard}/ohm-matched-ready.json` files and the two matched PGO Cargo drivers must exist. Package stage 2 with `pack-stage.py base work/round18-cargo/pgo/bin/base` and `pack-stage.py guard work/round18-cargo/pgo/bin/guard-stack` from the task directory. The bootstrap includes the matching rustdoc. Each package checks ordinary Cargo use, an actual proc macro, the new target std, and the compiler-driver implementation before issuing a ready marker.

The new runner imports the existing version-locked `common.py`, `native.py`, and `analyze.py` directly. It changes its own interpreter's fixture root while preserving the original scripts and experimental directories. The first operation requires a free host lease. Use the ordinary devbox account with host PID visibility. The scored command requires affinity 0–15. Preparation can run on an available 16-CPU group with the same eight Cargo jobs. Run these commands from the task directory only after the coordinator releases the host.

```sh
study=work/round18-compiler/literal-native
python3 -E -s "$study/run.py" initialize
taskset -c 0-15 python3 -E -s -u "$study/run.py" warm initial
taskset -c 0-15 python3 -E -s -u "$study/run.py" warm replica
```

The runner archives the pinned uv commit into independent short and longer checkout paths. Every arm and cohort receives an initially empty target and private cargo registry. All six targets compile the full workspace with the actual selected toolchain and verify a subsequent fresh command for every endpoint. The older native study measured about 17.6 GB of logical target files per cohort/arm. Six targets of that size represent about 106 GB, before separate registry and compiler copies. This holdout performs no cache seeding from the official compiler.

The script stores physical directory trees for all three sysroots. For each run the selected complete directory is renamed to the same `round18-literal-stage2/tools` pathname. The selected independent target and Cargo home are also renamed to stable per-checkout paths. Their parked names do not appear in the compiler invocation. Per-arm receipts require correct `--print sysroot`, `--print target-libdir`, rustc, rustdoc and Cargo identities, the appropriate Wild, and `ldd` resolving libLLVM inside the live sysroot. The six pre-existing Cargo/Wild file hashes are frozen in `known-binaries.json`.

## Native samples

```sh
study=work/round18-compiler/literal-native
taskset -c 0-15 python3 -E -s -u "$study/run.py" time initial
taskset -c 0-15 python3 -E -s -u "$study/run.py" time replica
python3 -E -s "$study/run.py" report > "$study/report.json"
```

The three argv forms run from the normal uv workspace root. Each begins with the same absolute Cargo executable and ends in `--locked --offline -j8`. The subcommands are `check`, `build` and `test --no-run`. The original 72 test executables must all be listed. The native timer is the existing direct process spawn through Cargo exit, including all descendant compiler/linker work. Root-only timings, subprocess counters, trace and verification work are excluded from scored rows. The existing quiet-host requirement checks two consecutive idle windows and the coordinator's `work/round18-lab/host-cleared-for-native` clearance. The existing native lease is held throughout each command group. Any foreign compiler visible after a timed invocation invalidates the endpoint. Preserve incomplete raw rows. A partial cohort cannot support a claim.

The initial cohort edits the real Homebrew recognition predicate. The independent cohort changes the real update-instructions text. Both edits use a distinct equal-width nonce on every block. The three arms in that block receive the very same source SHA. Each cohort uses an independent randomized order of all six permutations, repeated four times per endpoint. Every arm occupies each position eight times. The replica uses the reverse endpoint order. Two settlement edits, a traced admission and two opposite-order unscored edits precede timing. A final independent source edit repeats the traced validation. Original uv bytes, timestamps and Cargo.lock hash are checked at exit. Results remain in `evidence/<cohort>/<endpoint>`.

## Workload and correctness checks

Admissions and postchecks retain successful native execve commands with complete argv, all stdout/stderr, actual role counts, compiler search paths, Cargo's raw target labels and sizes plus SHA-256s of the selected outputs. Only the edited uv crate may recompile. All 72 logical test targets must match across arms, with only Cargo's 16-digit artifact suffix removed when comparing their relative paths. Within each arm the raw roster must remain exactly the same in every scored repetition. Fresh repeated commands on the same unmodified source must reproduce every selected artifact digest. Rebuilt std may change real code, metadata and full ELF hashes across arms, which are recorded verbatim.

A regular target executable is hardlinked into two actual Homebrew-shaped paths outside the timed commands. `uv self update` must recognize the currently edited formula or its edited help text, and the control path must produce the package-manager fallback. The runner compares the entire status, stdout and stderr across all three arms for those commands and for `uv --version` and `uvx --version`. The check-only endpoint receives an out-of-timer `cargo build` after its postcheck to execute the exact checked source. No uv test executable is run.

## Analysis

For each command the frozen analysis independently compares the treatment to the matched control and the installed release. It reports paired savings in milliseconds and percent, the distribution-free 95% median interval, both pair-order medians, sign wins and the exact two-sided conditional randomization test. Initial comparisons use alpha 0.05/6. Each independently repeated comparison uses 0.05. Each test must pass, with a positive lower median interval and both pair-order medians positive. The headline for an endpoint requires both controls and both cohorts. All samples and failed comparisons remain visible. `synthetic-verified.json` exercises the six assignments, logical-target normalization and restoration on an injected directory-switch exception. It contains no performance observations.
