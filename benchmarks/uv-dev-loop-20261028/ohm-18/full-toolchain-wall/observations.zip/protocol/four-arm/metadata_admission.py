"""Identify the current uv library metadata from the actual Cargo-launched compiler command."""
import hashlib
import json
from pathlib import Path
import re

RUST_METADATA_HEADER = b'rust\x00\x00\x00\x0a'
EMPTY_SHA256 = hashlib.sha256(b'').hexdigest()


def current_library(trace_dir, rustc, target):
    """Bind the check-mode rmeta to rustc's source, crate type, output directory, and extra filename."""
    decoder = json.JSONDecoder()
    observed = []
    for trace in sorted(trace_dir.glob('exec.*')):
        for line in trace.read_text(errors='replace').splitlines():
            if not line.endswith('= 0'):
                continue
            header = re.match(r'^execve\(("(?:[^"\\]|\\.)*"), ', line)
            if not header or json.loads(header[1]) != str(rustc):
                continue
            args, _ = decoder.raw_decode(line, header.end())
            if '--crate-name' not in args or args[args.index('--crate-name') + 1] != 'uv':
                continue
            if '--crate-type' not in args or args[args.index('--crate-type') + 1] != 'lib':
                continue
            assert args[0] == str(rustc) and 'crates/uv/src/lib.rs' in args
            assert '--emit=dep-info,metadata' in args and '-o' not in args
            suffix, = [args[i + 1].removeprefix('extra-filename=') for i, arg in enumerate(args[:-1])
                       if arg == '-C' and args[i + 1].startswith('extra-filename=')]
            assert re.fullmatch('-[0-9a-f]{16}', suffix)
            directory = Path(args[args.index('--out-dir') + 1])
            assert directory == target / 'debug/build/uv' / suffix[1:] / 'out'
            name = 'libuv' + suffix + '.rmeta'
            observed.append({'path':str((directory/name).relative_to(target)), 'trace_file':trace.name,
                             'argv_sha256':hashlib.sha256(json.dumps(args,ensure_ascii=True,separators=(',',':')).encode()).hexdigest(),
                             'rustc':str(rustc),'source':'crates/uv/src/lib.rs','crate_name':'uv','crate_type':'lib',
                             'emit':'dep-info,metadata','out_dir':str(directory),'extra_filename':suffix})
    assert len(observed) == 1, ('expected one traced uv library check', observed)
    return observed[0]


def classify(path, target, binding, digest, header):
    rel = str(path.relative_to(target))
    if path.stat().st_size:
        assert header == RUST_METADATA_HEADER, ('invalid Rust metadata header', rel)
        return {'metadata_kind':'current-traced-library' if rel == binding['path'] else 'coexisting-library'}
    assert rel != binding['path'] and digest == EMPTY_SHA256 and header == b'', ('empty current library', rel)
    match = re.fullmatch(r'debug/build/uv/([0-9a-f]{16})/out/libuv-\1\.rmeta', rel)
    assert match, ('unrecognized empty metadata', rel)
    depinfo = path.with_name(f'uv-{match[1]}.d')
    dep_bytes = depinfo.read_bytes()
    source = b'crates/uv/src/bin/uv.rs'
    suffix = b'/' + path.name.encode() + b': ' + source
    assert sum(line.endswith(suffix) for line in dep_bytes.splitlines()) == 1, ('unattributed empty output', rel)
    return {'metadata_kind':'coexisting-binary-placeholder','dep_info':str(depinfo.relative_to(target)),
            'dep_info_sha256':hashlib.sha256(dep_bytes).hexdigest(), 'binary_source':source.decode()}


def verify_set(products, binding):
    assert binding['path'] in products and products[binding['path']]['metadata_kind']=='current-traced-library'
    assert sum(p['metadata_kind']=='coexisting-binary-placeholder' for p in products.values())==1
