"""Freeze the zero-row correction after validating the real failing trace and every parked arm."""
from datetime import datetime,timezone
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,os,shutil
import metadata_admission as metadata

p=Path(__file__).resolve().parent;out=p/'evidence';plan=json.loads((p/'plan.json').read_text());r=Path(plan['root']);reject=out/'initial/check';trace=reject/'admission-shipped';error=p/'time-initial.log';e=p/'metadata-before-score-20261029T0049';assert not e.exists() and not list(out.rglob('timings.csv'));assert 'AssertionError' in error.read_text();assert not (out/'replica/test').exists();assert not (r/'tools').exists()
def sha(f):
    with f.open('rb') as d:return hashlib.file_digest(d,'sha256').hexdigest()
initial=Path(plan['cohorts']['initial']['root']);selected=metadata.current_library(trace,r/'tools/bin/rustc',initial/'target');images={}
for cohort,c in plan['cohorts'].items():
    owner=Path(c['root']);assert not any((owner/x).exists() for x in ('target','cargo-home'));assert (owner/'uv/crates/uv/src/install_source.rs').read_bytes()==(owner/'original').read_bytes()
    images[cohort]={}
    for arm in plan['arms']:
        target=owner/'targets'/arm;products={}
        for f in sorted((target/'debug/build/uv').glob('*/out/libuv-*.rmeta')):
            digest=sha(f)
            with f.open('rb') as stream:header=stream.read(8)
            products[str(f.relative_to(target))]={'bytes':f.stat().st_size,'sha256':digest,'magic':header.hex(),**metadata.classify(f,target,selected,digest,header)}
        metadata.verify_set(products,selected);assert len(products)==4;images[cohort][arm]=products
# The one actual shipped trace above establishes the current identity. The eight captures here
# validate glob coverage and the independent binary dep-info before mutation or scoring.
checks=[]
def must_reject(name,fn):
    try:fn()
    except (AssertionError,FileNotFoundError):checks.append(name)
    else:raise AssertionError('accepted '+name)
with TemporaryDirectory() as d:
    scratch=Path(d);h='1234567890abcdef';path=scratch/f'debug/build/uv/{h}/out/libuv-{h}.rmeta';path.parent.mkdir(parents=True);path.touch();dep=path.with_name(f'uv-{h}.d');rel=str(path.relative_to(scratch));b={'path':'different-current-library'};invoke=lambda:metadata.classify(path,scratch,b,metadata.EMPTY_SHA256,b'')
    must_reject('unattributed empty metadata',invoke)
    dep.write_text(f'{path}: crates/uv/src/lib.rs\n');must_reject('empty library with library dep-info',invoke)
    dep.write_text(f'{path}: crates/uv/src/bin/uv.rs\n');assert invoke()['metadata_kind']=='coexisting-binary-placeholder';must_reject('empty currently traced library',lambda:metadata.classify(path,scratch,{'path':rel},metadata.EMPTY_SHA256,b''))
    path.write_bytes(b'garbage!');must_reject('non-Rust metadata',lambda:metadata.classify(path,scratch,b,sha(path),b'garbage!'))
    must_reject('absent traced current output',lambda:metadata.verify_set({},selected))
    table={selected['path']:{'metadata_kind':'current-traced-library'},'x':{'metadata_kind':'coexisting-binary-placeholder'},'y':{'metadata_kind':'coexisting-binary-placeholder'}};must_reject('second zero metadata artifact',lambda:metadata.verify_set(table,selected))
e.mkdir();snapshot={str(z.relative_to(reject)):sha(z) for z in sorted(reject.rglob('*')) if z.is_file()};reject.rename(e/'original-check');error.rename(e/'original-time-initial.log');record={'frozen_utc':datetime.now(timezone.utc).isoformat(),'reason':'The prior shipped check succeeded. A coexisting zero-byte binary .rmeta from crates/uv/src/bin/uv.rs failed the glob-wide nonempty assertion before any timed row. Both old traces and schedule remain available.', 'registered_plan_sha256':sha(p/'plan.json'),'legacy_runner_sha256':sha(p/'run.py'),'runner':{'path':'run-metadata-v2.py','sha256':sha(p/'run-metadata-v2.py')},'module':{'path':'metadata_admission.py','sha256':sha(p/'metadata_admission.py')},'diff_sha256':sha(p/'metadata-runner.patch'),'sealed_by_sha256':sha(Path(__file__)),'failed_endpoint_sha256':snapshot,'failed_log_sha256':sha(e/'original-time-initial.log'),'existing_timing_rows':0,'actual_shipped_trace_binding':selected,'all_8_pre_score_glob_receipts':images,'negative_tests':checks,'gates':'Trace the actual uv library rustc argv, require the current checked Rust metadata header and positive size, record all coexisting bytes including exactly one dep-info-proven empty uv binary placeholder. Recompute and compare every artifact hash at identical source. No edit, arm, assignment, wall clock boundary, compiler, target or statistical gate changes.'};target=p/'metadata-admission-v2.json';assert not target.exists();tmp=target.with_suffix('.pending');tmp.write_text(json.dumps(record,indent=2)+'\n');tmp.replace(target);print(sha(target),record['runner']['sha256'],record['module']['sha256'],len(checks))
