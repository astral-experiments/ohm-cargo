"""Run the preregistered four-arm literal study, preserving the historical native timing and admissions."""
import argparse,contextlib,csv,fcntl,hashlib,json,os,re,shutil,struct,subprocess,sys,time
from pathlib import Path
from bind_inputs import bind
HERE=Path(__file__).resolve().parent;WORK=HERE.parents[1];LAB=WORK/'round18-lab';sys.path.insert(0,str(LAB));import common,native
PLAN=json.loads((HERE/'plan.json').read_text());ID=common.sha(HERE/'plan.json');assert ID==(HERE/'plan.sha256').read_text().split()[0];R=Path(PLAN['root']);OUT=HERE/'evidence';ORIGINAL_ROOT=common.OLD/'round18';HOST='x86_64-unknown-linux-gnu';LINK=common.LINK;ARMS=tuple(PLAN['arms']);CPUS=PLAN['cpu'];sha=common.sha
# These module globals are private to this Python process. The files and the existing lab stay untouched.
common.ROOT=R;native.ROOT=R
for item in (LAB/'frozen-harness.sha256').read_text().splitlines():
 h,file=item.split();p=LAB/Path(file).name
 if p.name in ('native.py','analyze.py','common.py'):assert sha(p)==h,p

def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);native.write(path,data)
def cp(src,dest):
 dest.mkdir(parents=True);subprocess.run(['cp','-aL','--reflink=auto',str(src)+'/.',dest],check=True)
def copy_file(src,dst):
 tmp=dst.with_name(dst.name+'.literal-next');assert not tmp.exists();shutil.copy2(src,tmp);tmp.replace(dst)
def command(root,ep):
 args=common.command(ep);assert args==[str(R/'tools/bin/cargo'),*PLAN['endpoints'][ep]];return args
def spawn_capture(argv,env,*,cwd=None,expected=(0,)):
 c=subprocess.run(argv,env=env,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert c.returncode in expected,(argv,c.returncode,c.stderr[-1400:]);return {'argv':list(map(str,argv)),'status':c.returncode,'stdout':c.stdout.decode(errors='replace'),'stderr':c.stderr.decode(errors='replace')}
@contextlib.contextmanager
def lease():
 with (ORIGINAL_ROOT/'native-lease').open('a') as f:
  fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);yield
@contextlib.contextmanager
def active(root,arm):
 moves=[(R/'sysroots'/arm,R/'tools'),(root/'targets'/arm,root/'target'),(root/'homes'/arm,root/'cargo-home')];done=[]
 assert all(a.is_dir() and not b.exists() for a,b in moves),moves
 try:
  for a,b in moves:a.rename(b);done.append((a,b))
  yield
 finally:
  for a,b in reversed(done):b.rename(a)
@contextlib.contextmanager
def edited(root):
 p=root/'uv'/common.EDIT_PATH;original=(root/'original').read_bytes();assert p.read_bytes()==original;st=p.stat();lock=sha(root/'uv/Cargo.lock')
 try:yield
 finally:p.write_bytes(original);os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns));assert p.read_bytes()==original and sha(root/'uv/Cargo.lock')==lock

def initialize():
 known=bind(HERE,PLAN)
 for arm,x in PLAN['arms'].items():
  origin=Path(x['sysroot']);assert all((origin/k).is_file() for k in ('bin/cargo','bin/rustc','bin/rustdoc')),origin
  if arm!='shipped':assert (origin/'ohm-matched-ready.json').is_file(),origin
  assert sha(Path(x['cargo']))==known[arm]['cargo'] and sha(Path(x['wild']))==known[arm]['wild'],arm
 assert not R.exists(),f'preserve previous initialization at {R}';R.mkdir(mode=0o700,parents=True);records={}
 for arm,x in PLAN['arms'].items():
  origin,cd,wd=map(Path,(x['sysroot'],x['cargo'],x['wild']));staged=R/'sysroots'/arm;ready=origin/'ohm-matched-ready.json';
  if arm!='shipped':assert json.loads(ready.read_text())['arm']==PLAN['amendment']['sysroot_source_by_arm'][arm] and sha(origin/'bin/cargo')==sha(cd),'package stage2 with its matching PGO Cargo'
  cp(origin,staged);assert sha(staged/'bin/cargo')==sha(cd)
  if arm!='shipped':copy_file(wd,staged/LINK)
  selected=[Path('bin/cargo'),Path('bin/rustc'),Path('bin/rustdoc'),LINK];driver,=list((staged/'lib').glob('librustc_driver-*.so'));runtime,=list(q for q in (staged/'lib').glob('libLLVM.so.23.1-*') if q.is_file());std,=list((staged/'lib/rustlib'/HOST/'lib').glob('libstd-*.rlib'));selected += [q.relative_to(staged) for q in [driver,runtime,std]];hashes={str(q):sha(staged/q) for q in selected};assert hashes[str(LINK)]==sha(wd) and hashes['bin/cargo']==sha(cd)
  lhs=(origin/LINK) if arm=='shipped' else wd;assert sha(lhs)==sha(staged/LINK);records[arm]={'source':x,'sha256':hashes,'stage2_ready':sha(ready) if arm!='shipped' else None}
 assert records['base']['sha256']['bin/cargo']!=records['stack']['sha256']['bin/cargo']
 assert records['current']['stage2_ready']==records['stack']['stage2_ready']
 historical=records['stack']['sha256'];current=records['current']['sha256'];assert historical.keys()==current.keys() and all(current[k]==historical[k] for k in historical if k!=str(LINK))
 write(OUT/'sysroots.json',{'registration':ID,'input_lock_sha256':sha(HERE/'input-lock.json'),'historical_current_differ':sorted(k for k in historical if historical[k]!=current[k]),'arms':records})
 for name,c in PLAN['cohorts'].items():
  root=Path(c['root']);root.mkdir(mode=0o700,parents=True);(root/'uv').mkdir();src=WORK/'uv';assert subprocess.check_output(['git','-C',src,'rev-parse',PLAN['uv']],text=True).strip()==PLAN['uv']
  with subprocess.Popen(['git','-C',src,'archive',PLAN['uv']],stdout=subprocess.PIPE) as proc:
   subprocess.run(['tar','-xf','-','-C',root/'uv'],stdin=proc.stdout,check=True);assert proc.wait()==0
  shutil.copy2(root/'uv'/common.EDIT_PATH,root/'original')
  for arm in ARMS:
   (root/'targets'/arm).mkdir(parents=True);cp(common.OLD/'cargo/registry',root/'homes'/arm/'registry')
  write(OUT/name/'source.json',{'uv':PLAN['uv'],'edit':str(root/'uv'/common.EDIT_PATH),'pristine_sha256':sha(root/'original'),'Cargo.lock':sha(root/'uv/Cargo.lock'),'root_bytes':len(os.fsencode(root/'uv')),'accepted_sysroot':str(R/'tools')})
 write(OUT/'initialized.json',{'registration':ID})

def identity(root,arm):
 env=common.env(root);tools=R/'tools';result={}
 for k,args in {'sysroot':[tools/'bin/rustc','--print','sysroot'],'target_libdir':[tools/'bin/rustc','--print','target-libdir'],'rustc':[tools/'bin/rustc','-Vv'],'cargo':[tools/'bin/cargo','-Vv'],'rustdoc':[tools/'bin/rustdoc','-Vv']}.items():result[k]=spawn_capture(args,env)['stdout'].strip()
 assert result['sysroot']==str(tools) and result['target_libdir']==str(tools/'lib/rustlib'/HOST/'lib');assert PLAN['rustc_pin'] in result['rustc'] and PLAN['cargo_pin'] in result['cargo'];driver,=(tools/'lib').glob('librustc_driver-*.so');result['driver_ldd']=spawn_capture(['ldd',driver],env)['stdout'];assert 'not found' not in result['driver_ldd'];line=next(x for x in result['driver_ldd'].splitlines() if x.strip().startswith('libLLVM.so.'));assert (tools/'lib') in Path(line.split('=>')[1].split()[0]).resolve().parents,line
 result['selected_files']={str(q):sha(tools/q) for q in json.loads((OUT/'sysroots.json').read_text())['arms'][arm]['sha256']};assert result['selected_files']==json.loads((OUT/'sysroots.json').read_text())['arms'][arm]['sha256'];return result

def warm(name):
 c=PLAN['cohorts'][name];root=Path(c['root']);out=OUT/name;assert (OUT/'initialized.json').exists() and not (out/'warm-ready.json').exists();bodies={}
 with edited(root):
  for arm in ARMS:
   with active(root,arm):
    bodies[arm]=identity(root,arm);write(out/f'identity-{arm}.json',bodies[arm])
    for ep in ('build','test','check'):
     for warm_phase in ('warm','fresh'):
      elapsed,ro=common.run(root,ep,out/f'{arm}-{ep}-{warm_phase}.log');assert not (warm_phase=='fresh' and ro['compiled']);assert len(ro['tests'])==(72 if ep=='test' else 0)
      write(out/f'{arm}-{ep}-{warm_phase}.json',{'raw_roster':ro,'argv':command(root,ep),'warmup':True,'elapsed_ns':elapsed});print(name,arm,ep,warm_phase,flush=True)
 write(out/'warm-ready.json',{'registration':ID,'arms':list(bodies)})

def logical(root,ro):
 logical=[]
 for raw in ro['tests']:
  title,path=raw.rsplit(' (',1);p=Path(path.removesuffix(')'));rel=p.relative_to(root/'target');base=re.sub(r'-[0-9a-f]{16}$','',rel.name);assert base!=rel.name,rel;logical.append([title,str(rel.with_name(base))]);assert p.is_file()
 return {'compiled':ro['compiled'],'tests':sorted(logical)}

def artifacts(root,ep,ro):
 target=root/'target';paths={}
 if ep=='check':
  # Save every current primary uv terminal metadata file, independent of codegen hashes.
  for q in (target/'debug/build/uv').glob('*/out/libuv-*.rmeta'):paths[str(q.relative_to(target))]=q
  assert paths,'missing primary uv metadata'
 else:
  for k in ('debug/libuv.rlib','debug/uv','debug/uvx'):paths[k]=target/k
  for z in ro['tests']:
   p=Path(z.rsplit(' (',1)[1][:-1]);paths[str(p.relative_to(target))]=p
 result={};hashed={}
 for k,p in sorted(paths.items()):
  st=p.stat();assert st.st_size>0;key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key not in hashed:hashed[key]=sha(p)
  with p.open('rb') as f:magic=f.read(8)
  if k.endswith('.rlib'):assert magic==b'!<arch>\n'
  elif not k.endswith('.rmeta'):assert magic[:6]==b'\x7fELF\x02\x01'
  result[k]={'bytes':st.st_size,'sha256':hashed[key],'magic':magic.hex()}
 return result

def behavior(root,shape,tag):
 env={**common.env(root),'UV_OFFLINE':'1','UV_NO_PROGRESS':'1','NO_COLOR':'1','COLUMNS':'100'};target=root/'target/debug';results={}
 for name in ('uv','uvx'):
  j=spawn_capture([target/name,'--version'],env);assert '0.12.0' in j['stdout'];results[name+'-version']={k:j[k] for k in ('status','stdout','stderr')}
 for control,formula in [('positive',('uv-preview-'+tag if shape=='predicate' else 'uv')),('negative','unrelated-formula')]:
  # A real hardlink is essential. current_exe canonicalizes a symlink back to target/debug/uv.
  path=root/'behavior/Cellar'/formula/'1/bin/uv';path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();os.link(target/'uv',path)
  try:j=spawn_capture([path,'self','update'],env,expected=(1,2))
  finally:path.unlink()
  body=j['stdout']+j['stderr'];assert ('brew update && brew upgrade uv' in body)==(control=='positive'),body
  if control=='positive' and shape=='brew-help':assert ' # edit '+tag in body,body
  if control=='negative':assert 'Please use your package manager to update uv' in body,body
  results[control]={k:j[k] for k in ('status','stdout','stderr')}
 return results

def traced(root,ep,output):
 output.mkdir();env=common.env(root);argv=command(root,ep);trace=['strace','-ff','-qq','-v','-s','131072','-e','trace=execve,execveat','-o',str(output/'exec'),*argv]
 with (output/'cargo.log').open('x') as log:subprocess.run(trace,cwd=root/'uv',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 ro=common.rosters((output/'cargo.log').read_text());assert len(ro['compiled'])==1 and ro['compiled'][0].startswith('uv v0.12.0 (') and len(ro['tests'])==(72 if ep=='test' else 0),ro;roles=native.exec_trace(output,R/'tools/bin/cargo',R/'tools/bin/rustc',R/'tools'/LINK)
 for p in output.glob('exec.*'):
  with p.open() as f:assert not any(line.startswith('execveat(') and line.rstrip().endswith('= 0') for line in f),f'unclassified execveat in {p}'
 assert (roles.get('wild',0)>0)==(ep!='check'),roles;result={'argv':argv,'env':env,'roster':ro,'logical':logical(root,ro),'roles':roles,'artifacts':artifacts(root,ep,ro),'trace_argv':trace,'raw_exec_sha256':{p.name:sha(p) for p in sorted(output.glob('exec.*'))}};write(output/'receipt.json',result);return result

def settled(root,ep,out):
 _,ro=common.run(root,ep,out);assert not ro['compiled'] and len(ro['tests'])==(72 if ep=='test' else 0);return ro

def validate_arm(root,ep,out,shape,tag):
 receipt=traced(root,ep,out);snap=receipt['artifacts'];settled(root,ep,out/'same-source-fresh.log')
 # The digest of every selected output is checked for reproducibility at the very same edit and toolchain.
 assert artifacts(root,ep,receipt['roster'])==snap,'fresh command changed its own products';write(out/'same-source-digests.json',{'untouched':True,'files':len(snap)});
 if ep!='check':receipt['behavior']=behavior(root,shape,tag)
 return receipt

def endpoint(name,ep):
 c=PLAN['cohorts'][name];root=Path(c['root']);shape=c['edit_shape'];out=OUT/name/ep;out.mkdir();assert (OUT/name/'warm-ready.json').exists();schedule=c['endpoints'][ep];prefix=schedule[0]['literal'][:2];admitted={}
 for suffix in ('00','01'):
  common.edit(root,prefix+suffix,shape)
  for arm in ARMS:
   with active(root,arm):
    elapsed,ro=common.run(root,ep,out/(f'settle-{suffix}-{arm}.log'));assert len(ro['tests'])==(72 if ep=='test' else 0)
 source=common.edit(root,prefix+'02',shape)
 for arm in ARMS:
  with active(root,arm):admitted[arm]=validate_arm(root,ep,out/('admission-'+arm),shape,prefix+'02')
 assert all(a['logical']==admitted['base']['logical'] for a in admitted.values()),'different logical workspace targets';
 if ep!='check':assert all(a['behavior']==admitted['base']['behavior'] for a in admitted.values()),'different uv command behavior'
 write(out/'admitted.json',{'source_sha256':source,'arm_cargo_argv':command(root,ep),'arms':{k:{x:v[x] for x in ('logical','roles','behavior') if x in v} for k,v in admitted.items()}})
 # Complete real unscored edits in opposite arm orders after expensive outside-timer artifact validation.
 for suffix,order in [('03',list(reversed(schedule[0]['order']))),('04',schedule[0]['order'])]:
  common.edit(root,prefix+suffix,shape)
  for arm in order:
   with active(root,arm):_,ro=common.run(root,ep,out/f'burn-{suffix}-{arm}.log')
   assert ro==admitted[arm]['roster']
 assert os.geteuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd','native run needs ordinary host process visibility';native.quiet(CPUS,out/'quiet.jsonl');rows=out/'timings.csv';fields=['block','rank','arm','literal','source_sha256','elapsed_ns','utc_ns','seconds_user','seconds_system','voluntary_switches','involuntary_switches','input_blocks','output_blocks','major_faults','minor_faults']
 with rows.open('x',newline='',buffering=1) as f:
  wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
  for block,trial in enumerate(schedule):
   tag=trial['literal'];source=common.edit(root,tag,shape)
   for rank,arm in enumerate(trial['order']):
    with active(root,arm):res=native.run_command(root,ep,out/f'm{block:02}-{rank}-{arm}',CPUS,measure=True)
    other=native.foreign()
    with (out/'external-activity.jsonl').open('a') as ef:ef.write(json.dumps([time.time_ns(),block,rank,arm,other])+'\n')
    assert not other,f'foreign compiler activity in complete-cohort evidence {other}';assert res['roster']==admitted[arm]['roster'],'timed raw per-arm roster drift';row={k:res[k] for k in fields if k in res};row.update(block=block,rank=rank,arm=arm,literal=tag,source_sha256=source);wr.writerow(row)
 tag=prefix+'90';source=common.edit(root,tag,shape);post={}
 for arm in ARMS:
  with active(root,arm):
   check=validate_arm(root,ep,out/('post-'+arm),shape,tag);assert check['roles']==admitted[arm]['roles'] and check['roster']==admitted[arm]['roster'];
   if ep=='check':
    # Materialize the checked edit outside the score in the same selected consumer and verify its behavior.
    common.run(root,'build',out/f'check-source-materialized-{arm}.log');check['behavior']=behavior(root,shape,tag)
   else:assert check['artifacts']['debug/uv']['sha256']!=admitted[arm]['artifacts']['debug/uv']['sha256'],'different real source edits produced identical main uv'
   post[arm]={'behavior':check['behavior'],'logical':check['logical'],'artifacts':check['artifacts']}
 assert all(v['logical']==post['base']['logical'] and v['behavior']==post['base']['behavior'] for v in post.values());native.write(out/'done.json',{'post_source':source,'rows':sha(rows),'post':post});print(name,ep,'complete',flush=True)

def project_historical(blocks):
 return [[dict(r,rank=rank) for rank,r in enumerate(v for v in block if v['arm']!='current')] for block in blocks]

def passes(v,alpha):
 return v['exact_two_sided_sign_p']<alpha and v['conditional_two_sided_p']<alpha and v['median_saved_pct_interval']['lower']>0 and min(v['median_saved_pct_by_order'].values())>0

def report():
 import analyze
 labels=PLAN['amendment']['arm_labels'];controls=PLAN['amendment']['original_controls'];results={}
 for name,cfg in PLAN['cohorts'].items():
  results[name]={}
  for ep,schedule in cfg['endpoints'].items():
   out=OUT/name/ep
   if not (out/'done.json').is_file():continue
   rows=analyze.validate(out,schedule);cell={}
   for treatment,label in labels.items():
    entries={}
    for control in controls:
     v=analyze.compare(rows,control,treatment);assert v['permutation_strata']==12 and v['possible_assignments']==2**12
     v['passes']=passes(v,PLAN['gates'][name+'_alpha']);entries['vs-'+control]=v
     if treatment=='stack':
      projected=analyze.compare(project_historical(rows),control,treatment);assert projected['median_saved_pct']==v['median_saved_pct'];v['historical_projection_sensitivity']={'conditional_two_sided_p':projected['conditional_two_sided_p'],'permutation_strata':projected['permutation_strata'],'possible_assignments':projected['possible_assignments'],'same_pairs':True}
    cell[label]=entries
   results[name][ep]=cell
 qualifies={label:{ep:all(ep in cohort and all(v['passes'] for v in cohort[ep][label].values()) for cohort in results.values()) for ep in PLAN['endpoints']} for label in labels.values()}
 print(json.dumps({'registration':ID,'cohorts':results,'qualifies':qualifies},indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['bind','initialize','warm','time','report']);parser.add_argument('cohort',nargs='?',choices=PLAN['cohorts']);args=parser.parse_args();os.umask(0o077)
 if args.phase=='report':report()
 else:
  with lease():
   if args.phase=='bind':bind(HERE,PLAN);print(sha(HERE/'input-lock.json'))
   elif args.phase=='initialize':initialize()
   elif args.phase=='warm':assert args.cohort and sorted(os.sched_getaffinity(0))==CPUS;warm(args.cohort)
   else:
    assert args.cohort and sorted(os.sched_getaffinity(0))==CPUS;cfg=PLAN['cohorts'][args.cohort];root=Path(cfg['root']);
    with edited(root):
     for ep in cfg['endpoint_order']:
      out=OUT/args.cohort/ep
      if (out/'done.json').is_file():continue
      assert not out.exists(),f'preserve incomplete endpoint and invalidate its cohort under the protocol: {out}';endpoint(args.cohort,ep)
