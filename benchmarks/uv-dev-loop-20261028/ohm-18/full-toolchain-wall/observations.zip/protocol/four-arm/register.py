"""Extend the already-randomized three-arm schedule by a fourth, conditioning on every old trial."""
from collections import Counter,defaultdict
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
from itertools import permutations
import json,os,random
from pathlib import Path

HERE=Path(__file__).resolve().parent;OLD=HERE.parent/'literal-native';WORK=HERE.parents[1]
def digest(p):return sha256(p.read_bytes()).hexdigest()
def freeze(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
base=json.loads((OLD/'plan.json').read_text());old_hash=digest(OLD/'plan.json');assert old_hash=='ef97ffddaefa9362e10680c5f0160db9e1e4671de5db28853ca53739b9ed7d7c'
new=deepcopy(base);live=Path(base['root']);assert not live.exists() and not (OLD/'evidence').exists() and not (HERE/'evidence').exists()
gh=json.loads((HERE/'upstream.json').read_text());pr45,pr46=gh['prs'];assert (pr45['state'],pr45['merged'],pr46['state'],pr46['head'],pr46['base'])==('closed',False,'open','db821991bd2931dd83e59f236149340ddfc2b427','e856d81f6683cad80b9fe0ebf1a0c3c403c6fe11')
new['registered_utc']=datetime.now(timezone.utc).isoformat();original=tuple(base['arms']);current=deepcopy(base['arms']['stack']);current['wild']=str(WORK/'round18-linker/current-pr46/wild');new['arms']['current']=current
new['primary_family']='Evaluate historical eight and current seven against both the original distributed Ohm -18 and the matched rebuilt control for check, build and test --no-run. Twelve prespecified initial hypotheses are followed independently in a second checkout with a different real source edit. The historical and current treatments use exactly the same guarded stage2 compiler, target standard library and independently trained Cargo; their separately sourced Wild executable is the only arm difference.'
new['amendment']={'reason':'Ohm Wild #45 closed without merge and #46 moved from its stacked branch to the bare 0.11 base. Add the still-open seven-change configuration while preserving every randomized historical triple and source tag.','upstream_json_sha256':digest(HERE/'upstream.json'),'original_plan_sha256':old_hash,'original_runner_sha256':digest(OLD/'run.py'),'original_plan_utc':base['registered_utc'],'pre_result_checks':{'live_root':str(live),'root_absent':True,'original_evidence_absent':True,'amendment_evidence_absent':True},'current_source':{'repo':'astral-sh/ohm-wild','head':pr46['head'],'base':pr46['base'],'receipt':str(WORK/'round18-linker/current-pr46/ready.json'),'expected_fields':['source_commit','base_commit','binary_sha256','cargo_lock_sha256','build_command']},'arm_labels':{'stack':'historical-eight','current':'current-seven'},'original_controls':['shipped','base'],'treatments':['stack','current'],'maximum_timed_commands':576,'sysroot_source_by_arm':{'shipped':'shipped','base':'base','stack':'guard','current':'guard'}}
new['gates'].update(initial_alpha=0.05/12,replica_alpha=0.05,number_of_primary_hypotheses=12,assignments='Within each of the six original triple orders, independently shuffle current insertion ranks 0,1,2,3 over those four original occurrences. Every one of 24 complete permutations occurs once in each cohort and endpoint, every arm occupies every position six times, every pair is 12/12 by order. Historical projection preserves the exact original 24-block order, literals and checkout sequences.',rule='For each treatment, require both prespecified controls to pass on both independent cohorts for a given command. Use all 24 pairs per contrast. Each of the two-sided sign and other-label-and-position-conditional randomization p-values must fall below .05/12 initially and .05 on the separate replication. Require a positive lower 95% paired-median percentage interval and both pair-order medians positive everywhere. Report the twelve primary contrasts and all raw rows. A projection of the historical contrast onto its original three-arm ranks is a sensitivity, never an additional independent result.')
checks={}
for ci,name in enumerate(('initial','replica')):
    cfg=new['cohorts'][name];checks[name]={}
    for ei,ep in enumerate(cfg['endpoint_order']):
        rows=cfg['endpoints'][ep];prior=base['cohorts'][name]['endpoints'][ep];groups=defaultdict(list)
        for idx,item in enumerate(prior):groups[tuple(item['order'])].append(idx)
        assert set(groups)==set(permutations(original)) and all(len(ix)==4 for ix in groups.values());seed=81170933+2200021*ci+5393*ei;rng=random.Random(seed)
        for labels,indices in sorted(groups.items()):
            slots=[0,1,2,3];rng.shuffle(slots)
            for i,pos in zip(indices,slots,strict=True):rows[i]['order'].insert(pos,'current')
        orders=Counter(tuple(v['order']) for v in rows);assert set(orders)==set(permutations(new['arms'])) and set(orders.values())=={1}
        assert all(newitem['literal']==olditem['literal'] and [a for a in newitem['order'] if a!='current']==olditem['order'] for newitem,olditem in zip(rows,prior,strict=True))
        checks[name][ep]={'insertion_seed':seed,'full_orders':24,'positions_per_arm':[6]*4,'old_triple_order_unchanged_in_all_blocks':24,'source_literals_unchanged':24}
new['amendment']['combinatoric_checks']=checks
# The original uniform random ordering of 6 labels repeated 4 times, followed by uniform independent insertions, assigns each four-arm schedule the same probability.
new['amendment']['randomization_support']='(24!/(4!)^6) * (4!)^6 = 24!; source-triple schedule was fixed before any outcome and amendment selection used only upstream state. Given the other two labels and their positions, each primary two-arm test has 12 strata of 2 opposite orderings, 2^12 assignments.'
freeze(HERE/'plan.json',new);(HERE/'plan.sha256').write_text(digest(HERE/'plan.json')+'  plan.json\n');print(digest(HERE/'plan.json'))
