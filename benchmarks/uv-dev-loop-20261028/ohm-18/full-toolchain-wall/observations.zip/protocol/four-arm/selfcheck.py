"""Run the actual four-arm reporting pipeline on controlled positive and null effects in tiny temporary files."""
import contextlib,csv,hashlib,io,itertools,json,tempfile
from collections import Counter
from pathlib import Path
import run,bind_inputs
old=json.loads((run.HERE.parent/'literal-native/plan.json').read_text());obs={};n=0
with tempfile.TemporaryDirectory(prefix='ohm-four-arm-schedule-') as t:
 run.OUT=Path(t)/'synthetic';t=Path(t)
 for name,cfg in run.PLAN['cohorts'].items():
  for ep,sched in cfg['endpoints'].items():
   original=old['cohorts'][name]['endpoints'][ep];assert all([v for v in j['order'] if v!='current']==o['order'] and j['literal']==o['literal'] for j,o in zip(sched,original,strict=True));orders=[tuple(x['order']) for x in sched]
   assert set(orders)==set(itertools.permutations(run.ARMS)) and all(Counter(x[pos] for x in orders)==dict.fromkeys(run.ARMS,6) for pos in range(4))
   dest=run.OUT/name/ep;dest.mkdir(parents=True);f=dest/'timings.csv'
   with f.open('w',newline='') as stream:
    c=csv.DictWriter(stream,fieldnames=['arm','rank','block','literal','source_sha256','elapsed_ns']);c.writeheader()
    for idx,row in enumerate(sched):
     values={'shipped':110000,'base':100000,'stack':85000,'current':100000 if ep=='build' else 87000}
     for pos,arm in enumerate(row['order']):c.writerow(dict(arm=arm,rank=pos,block=idx,literal=row['literal'],source_sha256=hashlib.sha256(row['literal'].encode()).hexdigest(),elapsed_ns=values[arm]+idx));n+=1
   (dest/'done.json').write_text(json.dumps({'rows':run.sha(f)}))
 with contextlib.redirect_stdout(io.StringIO()) as stream:run.report()
 result=json.loads(stream.getvalue());assert result['qualifies']=={'historical-eight':dict.fromkeys(('check','build','test'),True),'current-seven':{'check':True,'build':False,'test':True}}
 for cells in result['cohorts'].values():
  for ep,cell in cells.items():
   for v in cell['historical-eight'].values():
    assert v['wins']==24 and v['conditional_two_sided_p']==2/4096 and v['historical_projection_sensitivity']['permutation_strata']==3
   assert cell['current-seven']['vs-base']['passes']==(ep!='build')
  
 source=run.PLAN['amendment']['current_source'];cl=json.loads((run.HERE/'current-source-lock.json').read_text());actual='5'*64;d={'source_commit':source['head'],'base_commit':source['base'],'binary_sha256':actual,'cargo_lock_sha256':cl['cargo_lock_sha256'],'build_command':['cargo','build','--locked','--release','-p','wild-linker']};bind_inputs.validate(d,actual,source,cl);rejections=[]
 for key,bad in [('binary_sha256','0'*64),('source_commit','1'*40),('base_commit','2'*40),('cargo_lock_sha256','3'*64),('build_command',['cargo','build'])]:
  try:bind_inputs.validate(dict(d,**{key:bad}),actual,source,cl)
  except AssertionError:rejections.append(key)
  else:raise AssertionError(key)
 assert len(rejections)==5
print(json.dumps({'trials':'synthetic only','physical_cargo_invocations':0,'synthetic_timing_rows':n,'preserved_original_assignments':144,'complete_orderings_per_cell':24,'contrasts_per_cohort':12,'full_conditional_support':4096,'synthetic_gate_results':result['qualifies'],'rejected_false_input_bindings':rejections},indent=2))
