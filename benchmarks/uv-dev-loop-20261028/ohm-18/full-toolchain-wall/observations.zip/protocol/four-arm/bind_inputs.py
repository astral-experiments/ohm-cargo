"""Bind the newly compiled binary to its preregistered PR tree before any target is initialized."""
import hashlib,json,os,re
from pathlib import Path

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def validate(receipt,actual,source,lock):
    assert receipt['source_commit']==source['head']==lock['source_commit'], 'current source identity differs'
    assert receipt['base_commit']==source['base'], 'this is not the PR on bare 0.11'
    assert re.fullmatch('[a-f0-9]{64}',receipt['binary_sha256']) and receipt['binary_sha256']==actual,'current executable differs from its source receipt'
    assert receipt['cargo_lock_sha256']==lock['cargo_lock_sha256']=='f80b6c9cbd12031026d8cef0c00611b726d8efc5452f21d6decca458600deff0', 'current lockfile differs from the published PR tree'
    command=receipt['build_command'];flatten=' '.join(command) if isinstance(command,list) else command
    assert isinstance(flatten,str) and '--release' in flatten and '--locked' in flatten and 'wild-linker' in flatten,command

def bind(here,plan):
    original=here.parent/'literal-native';assert sha(original/'plan.json')==plan['amendment']['original_plan_sha256'];assert sha(original/'run.py')==plan['amendment']['original_runner_sha256']
    historical=json.loads((original/'known-binaries.json').read_text());source=plan['amendment']['current_source'];path=Path(source['receipt']);receipt=json.loads(path.read_text());wild=Path(plan['arms']['current']['wild']);actual=sha(wild);lock=json.loads((here/'current-source-lock.json').read_text());validate(receipt,actual,source,lock)
    assert plan['arms']['current']['sysroot']==plan['arms']['stack']['sysroot'] and plan['arms']['current']['cargo']==plan['arms']['stack']['cargo']
    known={**historical,'current':{'cargo':historical['stack']['cargo'],'wild':actual}}
    result={'plan_sha256':sha(here/'plan.json'),'original_known_binaries_sha256':sha(original/'known-binaries.json'),'current_build_receipt':str(path),'current_build_receipt_sha256':sha(path),'current_source':receipt['source_commit'],'current_base':receipt['base_commit'],'current_Cargo_lock_sha256':receipt['cargo_lock_sha256'],'current_build_command':receipt['build_command'],'known_binaries':known}
    dst=here/'input-lock.json'
    if dst.exists():assert json.loads(dst.read_text())==result,'input lock changed after registration'
    else:
        assert not Path(plan['root']).exists() and not (here/'evidence').exists(),'identity must be frozen before initialization'
        tmp=here/f'.input-lock.{os.getpid()}.pending'
        with tmp.open('x') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
        try:os.link(tmp,dst)
        finally:tmp.unlink()
    return known
