"""Recalculate every registered contrast and verify the complete compressed evidence using Python 3.11+."""
import contextlib
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.dont_write_bytecode = True
import analyze
sys.path.insert(0, str(HERE / 'protocol/four-arm'))
import metadata_admission


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def digest_file(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def check_manifest():
    for line in (HERE / 'MANIFEST.sha256').read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = HERE / name
        assert path.is_relative_to(HERE) and digest_file(path) == expected, name


OUT = HERE / 'evidence'
PROTOCOL = HERE / 'protocol/four-arm'
PLAN = read(PROTOCOL / 'plan.json')
ID = digest_file(PROTOCOL / 'plan.json')


def test_source(pristine, tag, shape):
    if shape == 'predicate':
        before = b'component == cellar && next == formula'
        after = ('{\n                component == cellar && (next == formula || next == OsStr::new('
                 f'"uv-preview-{tag}"))\n            }}').encode()
    else:
        assert shape == 'brew-help'
        before = b'brew update && brew upgrade uv'
        after = before + f' # edit {tag}'.encode()
    assert pristine.count(before) == 1
    return digest(pristine.replace(before, after))


def check_raw(folder, expected, receipt=None):
    actual = {}
    selected = {}
    metadata_lines = []
    if receipt:
        tool = Path(receipt['argv'][0]).parent
        selected = {str(tool/'cargo'):'cargo', str(tool/'rustc'):'rustc',
                    str(tool.parent/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'):'wild'}
    roles = {}
    with tarfile.open(folder / 'raw-execs.tar.gz', mode='r:gz') as archive:
        for member in archive:
            assert member.isfile() and re.fullmatch(r'exec\.\d+',member.name) and member.name not in actual
            data = archive.extractfile(member).read()
            actual[member.name] = digest(data)
            if receipt:
                for line in data.decode(errors='replace').splitlines():
                    if not line.endswith('= 0'):
                        continue
                    assert not line.startswith('execveat('), member.name
                    if not line.startswith('execve('):
                        continue
                    pat = re.match(r'execve\(("(?:[^"\\]|\\.)*")', line)
                    executable = json.loads(pat[1]);role = selected.get(executable)
                    if role:
                        roles[role]=roles.get(role,0)+1
                        if role=='rustc' and 'current_library_metadata' in receipt:
                            metadata_lines.append((member.name,data))
                    else:
                        assert Path(executable).name not in ('cargo','rustc','rust-lld','ld','ld.bfd','wild','ld.lld')
    assert actual == expected, folder
    if receipt:
        assert roles == receipt['roles'], folder
        if 'current_library_metadata' in receipt:
            assert len(metadata_lines)==1
            name,data=metadata_lines[0]
            with tempfile.TemporaryDirectory() as d:
                (Path(d)/name).write_bytes(data)
                binding=metadata_admission.current_library(Path(d),tool/'rustc',Path(receipt['env']['CARGO_TARGET_DIR']))
            assert binding==receipt['current_library_metadata']
            metadata_admission.verify_set(receipt['artifacts'],binding)


def verify_collections():
    prior = read(HERE/'protocol/three-arm/plan.json')
    frozen = read(PROTOCOL/'metadata-admission-v2.json')
    assert ID == (PROTOCOL/'plan.sha256').read_text().split()[0] == frozen['registered_plan_sha256']
    assert digest_file(HERE/'protocol/three-arm/plan.json') == PLAN['amendment']['original_plan_sha256']
    assert digest_file(PROTOCOL/'run.py')==frozen['legacy_runner_sha256']
    for which in ('module','runner'):
        assert digest_file(PROTOCOL/frozen[which]['path'])==frozen[which]['sha256']
    assert frozen['existing_timing_rows']==0
    failed=HERE/'excluded-zero-row/original-check';assert not list(failed.glob('timings.csv'))
    expected={Path(k).name:v for k,v in frozen['failed_endpoint_sha256'].items() if Path(k).name.startswith('exec.')}
    check_raw(failed/'admission-shipped',expected)
    for name,hashval in frozen['failed_endpoint_sha256'].items():
        if not Path(name).name.startswith('exec.'):
            assert digest_file(failed/name)==hashval
    assert digest_file(failed.parent/'original-time-initial.log')==frozen['failed_log_sha256']
    src=(HERE/'protocol/uv-install_source.rs').read_bytes()
    for name,cohort in PLAN['cohorts'].items():
        assert read(OUT/name/'source.json')['pristine_sha256']==digest(src)
        for ep,schedule in cohort['endpoints'].items():
            folder=OUT/name/ep;admitted=read(folder/'admitted.json');done=read(folder/'done.json')
            expected_order=prior['cohorts'][name]['endpoints'][ep]
            for row, old in zip(schedule,expected_order,strict=True):
                assert row['literal']==old['literal'] and [v for v in row['order'] if v!='current']==old['order']
            assert len(schedule)==len({tuple(x['order']) for x in schedule})==24
            blocks=analyze.validate(folder,schedule);flat=[r for b in blocks for r in b];assert len(flat)==96
            foreign=[json.loads(l) for l in (folder/'external-activity.jsonl').read_text().splitlines()]
            assert len(foreign)==96
            quiet=[json.loads(l) for l in (folder/'quiet.jsonl').read_text().splitlines()]
            assert len(quiet)>=2 and [r[6] for r in quiet[-2:]]==[1,2]
            for _,busy,iowait,dirty,writeback,other,_ in quiet[-2:]:
                assert busy<.05 and iowait<.02 and dirty<65536 and writeback<8192 and not other
            rosters={}
            for arm in PLAN['arms']:
                for before in ('admission','post'):
                    phase=folder/(before+'-'+arm);receipt=read(phase/'receipt.json');fresh=read(phase/'same-source-digests.json')
                    logical=receipt['logical'];assert len(logical['tests'])==(72 if ep=='test' else 0)
                    assert len(logical['compiled'])==1 and logical['compiled'][0].startswith('uv v0.12.0 (')
                    assert logical==admitted['arms']['base']['logical']==done['post'][arm]['logical']
                    assert receipt['argv']==admitted['arm_cargo_argv'] and receipt['argv'][1:]==PLAN['endpoints'][ep]
                    assert receipt['roles']==admitted['arms'][arm]['roles']
                    assert receipt['roster']==rosters.setdefault(arm,receipt['roster'])
                    product=receipt['artifacts'];assert fresh['untouched'] and fresh['files']==len(product)
                    assert fresh['sha256']=={k:v['sha256'] for k,v in product.items()}
                    assert receipt['roster']==rosters_from_log((phase/'cargo.log').read_text())
                    assert not rosters_from_log((phase/'same-source-fresh.log').read_text())['compiled']
                    if before=='post':
                        assert product==done['post'][arm]['artifacts']
                    check_raw(phase,receipt['raw_exec_sha256'],receipt)
                assert done['post'][arm]['behavior']==done['post']['base']['behavior']
            for row,guard in zip(flat,foreign,strict=True):
                block=int(row['block']);rank=int(row['rank']);arm=row['arm']
                assert guard[1:]==[block,rank,arm,[]]
                assert row['source_sha256']==test_source(src,row['literal'],cohort['edit_shape'])
                command=folder/f'm{block:02}-{rank}-{arm}';receipt=read(command/'receipt.json')
                assert receipt['measured'] and receipt['roster']==rosters[arm]
                assert rosters_from_log((command/'cargo.log').read_text())==rosters[arm]
                for k in set(row)&set(receipt):
                    assert row[k]==str(receipt[k]),(folder,k,row[k],receipt[k])
    checked = read(HERE/'collection.json')
    assert checked['timed_command_logs']==checked['timed_command_receipts']==576
    assert all(state['source_bytes_restored'] and state['original_mtime_restored'] and state['all_arms_parked'] for state in checked['fixture_postflight'].values())


def rosters_from_log(body):
    import re
    if not re.search(r'^\s*Finished ',body,re.M) or re.search(r'^\s*(Running|Updating|Downloading|Blocking) |^running \d+ tests?',body,re.M):
        raise RuntimeError(body[-500:])
    return {'compiled': sorted(re.findall(r'^\s*(?:Checking|Compiling) (.+)$',body,re.M)),
            'tests': sorted(re.findall(r'^\s*Executable (.+)$',body,re.M))}


def project_historical(blocks):
 return [[dict(r,rank=rank) for rank,r in enumerate(v for v in block if v['arm']!='current')] for block in blocks]

def passes(v,alpha):
 return v['exact_two_sided_sign_p']<alpha and v['conditional_two_sided_p']<alpha and v['median_saved_pct_interval']['lower']>0 and min(v['median_saved_pct_by_order'].values())>0

def report():
 import analyze
 labels=PLAN['amendment']['arm_labels'];controls=PLAN['amendment']['original_controls'];results={}
 for name,cfg in PLAN['cohorts'].items():
  results[name]={}
  for ep,schedule in cfg['endpoints'].items():
   out=OUT/name/ep
   if not (out/'done.json').is_file():continue
   rows=analyze.validate(out,schedule);cell={}
   for treatment,label in labels.items():
    entries={}
    for control in controls:
     v=analyze.compare(rows,control,treatment);assert v['permutation_strata']==12 and v['possible_assignments']==2**12
     v['passes']=passes(v,PLAN['gates'][name+'_alpha']);entries['vs-'+control]=v
     if treatment=='stack':
      projected=analyze.compare(project_historical(rows),control,treatment);assert projected['median_saved_pct']==v['median_saved_pct'];v['historical_projection_sensitivity']={'conditional_two_sided_p':projected['conditional_two_sided_p'],'permutation_strata':projected['permutation_strata'],'possible_assignments':projected['possible_assignments'],'same_pairs':True}
    cell[label]=entries
   results[name][ep]=cell
 qualifies={label:{ep:all(ep in cohort and all(v['passes'] for v in cohort[ep][label].values()) for cohort in results.values()) for ep in PLAN['endpoints']} for label in labels.values()}
 print(json.dumps({'registration':ID,'cohorts':results,'qualifies':qualifies},indent=2))



def main():
    if not __debug__:
        raise RuntimeError('Run without -O so all evidence checks are active')
    check_manifest()
    analyze.test()
    verify_collections()
    output=io.StringIO()
    with contextlib.redirect_stdout(output):
        report()
    report_body=output.getvalue()
    assert json.loads(report_body)==read(HERE/'numeric-results.json')
    sys.stdout.write(report_body)

if __name__=='__main__':
    main()
