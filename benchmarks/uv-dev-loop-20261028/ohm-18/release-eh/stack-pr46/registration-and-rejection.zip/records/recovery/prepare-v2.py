"""Apply the one-line representation repair, leaving every registered statistical and product rule intact."""
from pathlib import Path
import ast,difflib,hashlib,json
D=Path(__file__).resolve().parent
S=D.parent
def h(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def one(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def save(f,b):
 if f.exists():assert f.read_bytes()==b,f
 else:
  f.parent.mkdir(parents=True,exist_ok=True)
  with f.open('xb') as x:x.write(b)
def clone(f,to,replace=()):
 s=f.read_text()
 for a,b in replace:s=one(s,a,b)
 ast.parse(s,filename=str(to));save(to,s.encode());return s
def main():
 old=S/'command';new=S/'command-v2';new.mkdir(exist_ok=True)
 source=old/'run.py'
 reader=('files_match(rec["files"],expected["files"],','files_match(read(log/"receipt.json")["files"],expected["files"],')
 original=source.read_text();fixed=one(original,*reader)
 patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),fixed.splitlines(keepends=True),fromfile='a/command/run.py',tofile='b/command/run.py'))
 save(D/'reader.patch',patch.encode())
 clone(source,new/'run.py',[reader,('home_states=root/("homes-pr46-eh-"+cell)','home_states=root/("homes-pr46-eh-v2-"+cell)'),('root/(f"rejected-{cell}-"+name)','root/(f"rejected-pr46-eh-v2-{cell}-"+name)')])
 for f in ['calibrate.c','calibrate.py','elf_equivalence.py','plan.json','plan.py','trace.py','verify.py','warm_process.py','wrap.py']:
  save(new/f,(old/f).read_bytes())
 for c in ('initial','replica'):
  for rel in ['stock/'+c+'/binding.json','release-product-oracles/'+c+'.json']: save(new/rel,(old/rel).read_bytes())
 clone(old/'cell.py',new/'cell.py',[
  ("assert read(stack/'physical'/(previous+'-returned.json'))", "assert read(stack/('physical' if previous=='build-focus' else 'physical-v2')/(previous+'-returned.json'))"),
  ("saved=stack/'physical'/(cell+'-slots-premark.json')","saved=stack/'physical-v2'/(cell+'-slots-premark.json')"),
  ("put(stack/'physical'/(cell+'-slots-returned.json')","put(stack/'physical-v2'/(cell+'-slots-returned.json')"),
  ("backup=ro/'tools'/('pr46-slot-recovery-'+cell)","backup=ro/'tools'/('pr46-slot-recovery-v2-'+cell)")])
 clone(S/'verify-fresh.py',S/'verify-fresh-v2.py',[("cmd=BASE/'command';","cmd=BASE/'command-v2';")])
 clone(S/'phase.py',S/'phase-v2.py',[
  ("phase in {'build-focus','initial-base','replica-base'}","phase in {'initial-base','replica-base'}"),
  ("    plan=read(HERE/'plan.json');boot",'''    fixed=read(HERE/'recovery/registration.json')
    assert sha(HERE/'recovery/registration.json')==grant['recovery_sha256']==(HERE/'recovery/registration.sha256').read_text().split()[0]
    assert fixed['original_plan_sha256']==digest and all(sha(HERE/name)==v for name,v in fixed['new_files'].items())
    assert sha(HERE/'physical/initial-base-returned.json')==fixed['unchanged_failed_return_sha256']
    plan=read(HERE/'plan.json');boot'''),
  ("result=HERE/'physical';","result=HERE/'physical-v2';"),("HERE/'command/cell.py'","HERE/'command-v2/cell.py'"),("read(HERE/'command/results'/cfg","read(HERE/'command-v2/results'/cfg"),("HERE/'verify-fresh.py',phase","HERE/'verify-fresh-v2.py',phase")])
 observer=(S/'host-observe-command.py').read_text()
 assert observer.count("p/'physical'")==4
 observer=observer.replace("p/'physical'","p/'physical-v2'").replace("p.name+'/phase.py'","p.name+'/phase-v2.py'").replace("'stack-pr46/phase.py'","'stack-pr46/phase-v2.py'").replace("'stack-pr46/command/cell.py'","'stack-pr46/command-v2/cell.py'")
 ast.parse(observer);save(S/'host-observe-command-v2.py',observer.encode())
 files=[S/'phase-v2.py',S/'verify-fresh-v2.py',S/'host-observe-command-v2.py',D/'reader.patch',D/'diagnose.py',D/'prepare-v2.py',D/'diagnosis.json']
 files+=list(new.glob('*.py'))+[new/'plan.json',new/'calibrate.c']+list((new/'stock').glob('*/binding.json'))+list((new/'release-product-oracles').glob('*.json'))
 registered=json.loads((S/'plan.json').read_text());receipt={'original_plan_sha256':h(S/'plan.json'),'original_implementation_sha256':h(S/'implementation.json'),'unchanged_failed_return_sha256':h(S/'physical/initial-base-returned.json'),'rejection_diagnosis_sha256':h(D/'diagnosis.json'),
  'old_collector_sha256':h(old/'run.py'),'new_collector_sha256':h(new/'run.py'),'reader_patch_sha256':h(D/'reader.patch'),'old_command_verifier_sha256':h(old/'verify.py'),'new_command_verifier_sha256':h(new/'verify.py'),
  'statistics':'same gates, binary/source/input identities, arms, native admissions, complete unfitted schedules and source literals; both cells restart fully; zero candidate counter or scored command in superseded attempt',
  'unchanged_macro_cohorts':registered['macro_cohorts'],'stock_path_bindings':registered['stock_path_bindings'],'new_files':{str(f.relative_to(S)):h(f) for f in sorted(files)}}
 assert receipt['old_command_verifier_sha256']==receipt['new_command_verifier_sha256']
 save(D/'registration.json',(json.dumps(receipt,indent=2)+'\n').encode());save(D/'registration.sha256',(h(D/'registration.json')+'  registration.json\n').encode())
 print('registration',h(D/'registration.json'),'old',receipt['old_collector_sha256'],'new',receipt['new_collector_sha256'])
if __name__=='__main__':main()
