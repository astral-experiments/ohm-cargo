"""Preserve the rejected admission and reproduce its false-negative using exact output byte ranges."""
import csv,hashlib,json,mmap,os,struct,sys
from pathlib import Path
D=Path(__file__).resolve().parent;S=D.parent;W=S.parent.parent
def rd(f):return json.loads(f.read_text())
def sha(f):
 with f.open('rb') as x:return hashlib.file_digest(x,'sha256').hexdigest()
def put(f,o):
 data=(json.dumps(o,indent=2)+'\n').encode()
 if f.exists():assert f.read_bytes()==data
 else:
  with f.open('xb') as x:x.write(data)
def ino(f):
 s=f.stat();return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns}
def replay_file(f,old,new):
 with f.open('rb') as fp,mmap.mmap(fp.fileno(),0,access=mmap.ACCESS_READ) as b:
  assert b[:6]==b'\x7fELF\x02\x01';tbl=struct.unpack_from('<Q',b,40)[0];sz,n,ndx=struct.unpack_from('<HHH',b,58)
  namepos,namesz=struct.unpack_from('<QQ',b,tbl+ndx*sz+24);names=b[namepos:namepos+namesz];fields={}
  for i in range(n):
   at=tbl+i*sz;idx,kind=struct.unpack_from('<II',b,at);name=names[idx:names.index(0,idx)]
   if name==b'.rodata':
    assert kind==1 and struct.unpack_from('<Q',b,at+56)[0] in (0,8);fields['rodata']=[at+56,at+57]
   if name==b'.note.gnu.build-id':
    off,num=struct.unpack_from('<QQ',b,at+24);assert kind==7 and num==48 and b[off:off+16]==struct.pack('<III',4,32,3)+b'GNU\0';fields['build_id']=[off+16,off+48]
  assert set(fields)=={'rodata','build_id'} and len(b)==old['size']==new['size']
  digests={'actual':hashlib.sha256(),'canonical':hashlib.sha256(),'old_reconstructed':hashlib.sha256()};last=0
  chunks=[]
  for start,end,key in sorted((a,e,k) for k,(a,e) in fields.items()):
   segment=memoryview(b)[last:start]
   for h in digests.values():h.update(segment)
   segment.release()
   raw=b[start:end];v=old['permitted_fields'][key];cur=new['permitted_fields'][key]
   assert fields[key]==v[:2]==cur[:2]
   rr=(bytes([v[2]]) if key=='rodata' else bytes.fromhex(v[2]));expect=(bytes([cur[2]]) if key=='rodata' else bytes.fromhex(cur[2]))
   assert raw==expect
   digests['actual'].update(raw);digests['canonical'].update(bytes(end-start));digests['old_reconstructed'].update(rr)
   chunks.append({'field':key,'range':[start,end],'observed_hex':raw.hex(),'old_hex':rr.hex(),'different_bytes':sum(x!=y for x,y in zip(raw,rr))});last=end
  tail=memoryview(b)[last:]
  for h in digests.values():h.update(tail)
  tail.release()
  result={k:v.hexdigest() for k,v in digests.items()}
  assert result=={'actual':new['sha256'],'canonical':old['canonical_sha256'],'old_reconstructed':old['sha256']}
  assert old['canonical_sha256']==new['canonical_sha256']
  return {'reconstructed':result,'fields':chunks,'unchanged_bytes':len(b)-sum(x['different_bytes'] for x in chunks)}
def main():
 root=Path((W/'bench-home.path').read_text().strip())/'release-eh-roles-18/initial'
 out=S/'command/results/initial/base';d=out/'admit-0-native-candidate';r=rd(d/'receipt.json');ref=rd(S/'command/release-product-oracles/initial.json')
 expected=ref['sources'][r['source_sha256']]['files']
 assert r['roster']==ref['roster'] and len(r['files'])==len(expected)==74 and len(r['roster']['tests'])==72 and r['roster']['role_counts']=={'cargo':1,'rustc':6,'wild':5}
 assert not (out/'samples.csv').exists() and [x.name for x in out.glob('admit-*')]==[d.name] and not list(out.glob('pair-*'))
 total=0
 for loc in [d,out/'structural',out/'fresh']:
  for role in ('cargo','rustc','wild'):
   for f in loc.glob(role+'-*.json'):
    record=rd(f);assert 'instructions' not in record and 'threads' not in record;total+=1
 sys.path.insert(0,str(S/'command'));from verify import files_match
 bound=rd(S/'command/plan.json')['stock_path_bindings']['initial'];allowed=set(bound['allowed'])
 files_match(r['files'],expected,allowed)
 mixed=json.loads(json.dumps(r['files']))
 for info in mixed.values():
  fields=info['permitted_fields']
  if fields:
   for k in fields:fields[k]=tuple(fields[k])
 try:files_match(mixed,expected,allowed)
 except AssertionError:pass
 else:raise AssertionError('failed to reproduce tuple/list false negative')
 saved=D/'products';saved.mkdir(exist_ok=True);paths={};target=root/'rejected-initial-base-target';structural=root/'rejected-initial-base-structural'
 for path,x in sorted(r['files'].items()):
  old=expected[path]
  if x['sha256']==old['sha256']:continue
  assert path in allowed;orig=target/path;kept=saved/x['sha256']
  if not kept.exists():os.link(orig,kept)
  assert os.path.samefile(orig,kept)
  paths[path]={'held_original_inode':ino(orig),'retained_path':str(kept.relative_to(D)),'size':x['size'],**replay_file(kept,old,x)}
 assert len(paths)==2
 assert not (root/'target').exists() and not (root/'structural').exists() and not any(root.glob('held-*')) and len(list(root.glob('rejected-initial-base-*')))==2
 pre=rd(S/'physical/initial-base-slots-premark.json');after=rd(S/'physical/initial-base-slots-returned.json')
 assert pre['slot_identity']==after['slot_identity'] and pre['source_sha256']==after['uv_source_sha256'] and pre['source_mtime_ns']==after['after_source_mtime_ns'] and after['visible_target_absent']
 assert rd(out/'restore.json')['home_restored']
 for key in ['cargo','wild']:
  f=root/'tools'/key;st=f.stat();assert [st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,sha(f)]==pre['slot_identity'][key]
 receipt={'old_plan_sha256':sha(S/'plan.json'),'old_implementation_sha256':sha(S/'implementation.json'),'old_run_py_sha256':sha(S/'command/run.py'),
          'physical_return_sha256':sha(S/'physical/initial-base-returned.json'),'host_return_sha256':sha(S/'physical/initial-base-host-returned.json'),
          'native_receipt_sha256':sha(d/'receipt.json'),'reference_oracle_sha256':sha(S/'command/release-product-oracles/initial.json'),
          'source_sha256':r['source_sha256'],'registered_product_count':74,'raw_equal':72,'recovered_canonical_equal':74,'roster':r['roster']['role_counts'],'test_executables':72,
          'observed_native_candidate_commands':1,'actual_counted_candidate_commands':0,'scored_rows':0,'native_only_role_receipts':total,
          'mixed_tuple_list_rejection_reproduced':True,'unaltered_serialized_comparator':'passed','new_products':paths,
          'retained_bytes':sum(x['size'] for x in paths.values()),'common':{'path':str(root/'common'),'identity':ino(root/'common'),'ready_sha256':sha(root/'common-ready.json')},
          'two_rejected_banks':{q.name:{'path':str(q),'identity':ino(q)} for q in [structural,target]},'uv_and_slots_restore_sha256':sha(S/'physical/initial-base-slots-returned.json'),
          'home_and_source_restore_sha256':sha(out/'restore.json'),'rejected_json_sha256':sha(out/'rejected.json')}
 put(D/'diagnosis.json',receipt);print(sha(D/'diagnosis.json'),receipt['retained_bytes'])
if __name__=='__main__':main()
