"""An owner-granted, floor-observed physical window. No implicit transition between phases."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
OLD=HERE.parent
WORK=OLD.parent
BENCH=Path((WORK/'bench-home.path').read_text().strip())
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def read(p):return json.loads(p.read_text())
def workers():
    found=[]
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():continue
        try:
            exe=os.readlink(item/'exe');comm=(item/'comm').read_text().strip();a=sorted(os.sched_getaffinity(int(item.name)))
        except (OSError,ValueError):continue
        if comm in {'cargo','rustc','wild','ld.bfd','drrun','cargo-real','rustc-real','wild-real'} or exe.endswith(('/drrun','/rustc','/cargo','/wild','/ld.bfd')):
            found.append({'pid':int(item.name),'process':comm,'affinity':a})
    return sorted(found,key=lambda x:x['pid'])
def check_qa():
    root=HERE/'official-tests';q=read(root/'summary.json')
    assert len(q)==8 and all(x['returncode']==0 for x in q.values())
    counts={}
    for name,v in q.items():
        f=root/(name+'.log');assert sha(f)==v['log_sha256']
        matches=[int(n) for s in v['results'] for n in re.findall(r'\b(\d+) passed;',s)]
        if name!='compile-integration':assert len(matches)==1;counts[name]=matches[0]
    assert counts.pop('libwild')>=183 and 'test_default_section_name_prefixes ... ok' in (root/'libwild.log').read_text()
    assert counts=={'eh-frame':1,'eh-frame-terminator':1,'crtend-only-eh-frame':2,'dynsym-debug-eh-frame':1,'relocation-overflow':1,'backtrace':1}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--allocation',required=True,type=Path);args=ap.parse_args()
    assert __debug__;a=args.allocation.resolve();grant=read(a);phase=grant['phase'];cpus=sorted(os.sched_getaffinity(0))
    assert phase in {'initial-base','replica-base'} and grant['owner']=='/root' and grant['study']=='wild-eh-pr46-stack'
    digest=sha(HERE/'plan.json');assert digest==grant['plan_sha256']==(HERE/'registration.sha256').read_text().split()[0]
    assert sha(HERE/'implementation.json')==(HERE/'implementation.sha256').read_text().split()[0]
    impl=read(HERE/'implementation.json');assert impl['plan_sha256']==digest
    for rel,value in impl['files'].items():assert sha(HERE/rel)==value,rel
    fixed=read(HERE/'recovery/registration.json')
    assert sha(HERE/'recovery/registration.json')==grant['recovery_sha256']==(HERE/'recovery/registration.sha256').read_text().split()[0]
    assert fixed['original_plan_sha256']==digest and all(sha(HERE/name)==v for name,v in fixed['new_files'].items())
    assert sha(HERE/'physical/initial-base-returned.json')==fixed['unchanged_failed_return_sha256']
    plan=read(HERE/'plan.json');boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    assert grant['host_boot_id']==boot
    assert cpus==sorted(grant['cpus']) and len(cpus)==(4 if phase=='build-focus' else 8)
    assert type(grant['other_reserved_gib']) is int and grant['other_reserved_gib']>=0
    budget=10 if phase=='build-focus' else 36;floor=120+grant['other_reserved_gib']
    result=HERE/'physical-v2';result.mkdir(exist_ok=True);started=result/(phase+'-started.json')
    assert not started.exists() and not (result/(phase+'-returned.json')).exists()
    assert not (WORK/'round18-lab/host-cleared-for-native').exists()
    assert (OLD/'command/control/pause').is_file() and sha(OLD/'command-v2/custody-after-replica-shipped.json')==plan['old_custody_sha256']
    with (BENCH/'round18/native-lease').open('r') as lock:
        fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
        prior=workers();assert not [w for w in prior if set(cpus)&set(w['affinity'])],prior
        free=lambda:shutil.disk_usage(HERE).free
        first=free();assert first>=(floor+budget)*2**30,(first/2**30,floor,budget)
        put(started,{'study':grant['study'],'phase':phase,'pid':os.getpid(),'host_boot_id':boot,'cpus':cpus,'free':first,'floor_gib':floor,'allocated_gib':budget,'plan_sha256':digest,'implementation_sha256':sha(HERE/'implementation.json'),'grant_file':a.name,'grant_sha256':sha(a),'native_lease':'shared','other_workers':prior,'started_ns':time.time_ns()})
        rows=[];minimum=first;observations=0;status='rejected';failure=None
        def run(argv):
            nonlocal minimum,observations
            log=result/(phase+'-'+str(len(rows))+'.log')
            before=time.time_ns()
            assert free()>=floor*2**30
            with log.open('xb') as output:
                child=subprocess.Popen(argv,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
                print('start',phase,child.pid,' '.join(map(str,argv)),flush=True)
                try:
                    while child.poll() is None:
                        value=free();observations+=1;minimum=min(minimum,value)
                        if value<floor*2**30:
                            raise OSError('registered disk floor crossed')
                        try:child.wait(timeout=1)
                        except subprocess.TimeoutExpired:pass
                except BaseException:
                    try:os.killpg(child.pid,signal.SIGINT)
                    except ProcessLookupError:pass
                    try:child.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid,signal.SIGKILL);child.wait()
                    raise
                finally:
                    rows.append({'pid':child.pid,'command':list(map(str,argv)),'returncode':child.returncode,'start_ns':before,'end_ns':time.time_ns(),'log':log.name,'log_sha256':sha(log)})
                assert child.returncode==0,log
        try:
            py=[sys.executable,'-B']
            if phase=='build-focus':
                run(py+[HERE/'build.py','--allocation',a])
                run(py+[HERE/'lock-focused.py','--allocation',a])
                run(py+[HERE/'official-tests.py']);check_qa()
                run(py+[HERE/'fixtures.py'])
                run(['taskset','-c',str(cpus[0]),*py,HERE/'focus.py'])
                summary=read(HERE/'focused/summary.json');qualified=summary['entry_gate_qualified']
            else:
                run(py+[HERE/'command-v2/cell.py','--allocation',a])
                cfg=plan['macro_cohorts'][phase]
                summary=read(HERE/'command-v2/results'/cfg['cohort']/cfg['control']/'summary.json')
                qualified=summary['qualified']
            run(py+[HERE/'verify-fresh-v2.py',phase])
            status='qualified' if qualified else 'inconclusive'
        except BaseException as exc:
            failure={'type':type(exc).__name__,'message':str(exc)}
            raise
        finally:
            final=workers();left=[w for w in final if set(cpus)&set(w['affinity'])]
            if left or any(x['returncode'] is None for x in rows):status='rejected'
            put(result/(phase+'-returned.json'),{'phase':phase,'status':status,'error':failure,'start_receipt_sha256':sha(started),'children':rows,'free_before':first,'minimum_observed_free':minimum,
                'end_free':free(),'floor_gib':floor,'reserve_samples':observations,'remaining_on_granted_cpus':left,'all_children_returned':all(x['returncode'] is not None for x in rows),'end_ns':time.time_ns()})
            assert not left,left
        print('terminal',phase,status,flush=True)
if __name__=='__main__':main()
