"""Verify the new focused counters, complete-command product oracles, and all predeclared orders offline."""
import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys
BASE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def effect(groups):
    diff=[];orient=[];deltas=[]
    for pair in groups:
        a,b=pair['base'],pair['candidate'];x,y=int(a['instructions']),int(b['instructions'])
        s=1 if int(a['position'])==0 else -1
        orient.append(s);diff.append(s*math.log(x/y));deltas.append(100*(x-y)/x)
    assert sorted(orient)==[-1]*4+[1]*4
    score=abs(sum(d*s for d,s in zip(diff,orient)))
    null=[abs(sum(d if i in plus else -d for i,d in enumerate(diff))) for plus in itertools.combinations(range(8),4)]
    order=sum(v+1e-15>=score for v in null)/70
    wins=sum(v>0 for v in deltas);losses=sum(v<0 for v in deltas);n=wins+losses
    sign=min(1,2*sum(math.comb(n,k) for k in range(min(wins,losses)+1))/(2**n)) if n else 1
    med=statistics.median(deltas)
    return med,wins,sign,order,(wins==8 and med>=.10 and sign<=.05 and order<=.05)
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('phase',choices=['build-focus','initial-base','replica-base']);args=ap.parse_args()
    p=read(BASE/'plan.json');ph=sha(BASE/'plan.json');assert ph==(BASE/'registration.sha256').read_text().split()[0]
    if args.phase=='build-focus':
        d=BASE/'focused';official=read(BASE/'official-tests/summary.json')
        assert len(official)==8 and all(v['returncode']==0 for v in official.values())
        for k,v in official.items():assert sha(BASE/'official-tests'/(k+'.log'))==v['log_sha256']
        probes=read(BASE/'fixture-results/summary.json');assert set(probes)==set(p['probes'])
        for name,both in probes.items():
            assert set(both)=={'base','candidate'} and all(x['matched'] and x['expected'] for x in both.values())
            assert all(sha(BASE/'fixture-results'/(name+'-'+arm+'.log'))==v['diagnostic_sha256'] for arm,v in both.items())
        admissions=read(d/'admission.json');assert set(admissions)==set(p['captures'])
        for shape,rows in admissions.items():
            assert [r['arm'] for r in rows]==['base','candidate']
            assert all(r['sha256']==p['captures'][shape]['one_worker_file_sha256'] and r['returncode']==0 for r in rows)
        cells=read(d/'summary.json');assert cells['plan_sha256']==ph;result={}
        for name in p['focused_cell_order']:
            if name not in cells['cells']:break
            cfg=p['focused_cells'][name];shape=cfg['capture'];rows=list(csv.DictReader((d/(name+'.csv')).open()));assert len(rows)==16
            parsed=[]
            for i,pair in enumerate(cfg['pairs']):
                g={}
                for j,arm in enumerate(pair['order']):
                    r=rows[i*2+j];assert (int(r['block']),int(r['position']),r['arm'])==(i,j,arm)
                    assert r['sha256']==p['captures'][shape]['one_worker_file_sha256'] and int(r['returncode'])==0
                    tag=f'{name}-{shape}-{i:02d}-{j}-{arm}'
                    assert not (d/'raw'/(tag+'.stdout')).read_bytes()
                    data=(d/'raw'/(tag+'.stderr')).read_bytes();before,sep,last=data.rpartition(b'DynamoRIO ')
                    assert not before and sep;counter=json.loads(last);assert int(r['pid'])==counter['pid'] and str(counter['pid']) in counter['threads']
                    assert int(r['instructions'])==sum(counter['threads'].values())==counter['instructions']>0
                    g[arm]=r
                parsed.append(g)
            med,w,sign,order,pass_=effect(parsed);assert pass_==cells['cells'][name]['qualified']
            result[name]={'median_pct':med,'wins':w,'sign_p':sign,'balanced_order_p':order,'qualified':pass_}
        assert cells['entry_gate_qualified']==(len(result)==2 and all(v['qualified'] for v in result.values()))
        print(json.dumps(result,indent=2))
    else:
        cmd=BASE/'command-v2';subprocess.run([sys.executable,'-B',cmd/'verify.py',args.phase],check=True)
        sys.path.insert(0,str(cmd))
        from verify import files_match
        cfg=p['macro_cohorts'][args.phase];cohort=cfg['cohort'];loc=cmd/'results'/cohort/cfg['control'];oraclep=cmd/'release-product-oracles'/(cohort+'.json');oracle=read(oraclep)
        allowed=set(p['stock_path_bindings'][cohort]['allowed']);raw=canon=n=0
        for f in loc.glob('*/receipt.json'):
            if not f.parent.name.startswith(('admit-','pair-')):continue
            r=read(f);ref=oracle['sources'][r['source_sha256']]
            assert r['roster']==oracle['roster'];files_match(r['files'],ref['files'],allowed)
            n+=1;canon+=len(r['files']);raw+=sum(x['sha256']==ref['files'][k]['sha256'] for k,x in r['files'].items())
        parity=read(loc/'release-product-parity.json')
        assert (n,canon)==(20,1480) and (n,canon,raw,sha(oraclep))==(parity['actual_commands'],parity['canonical_file_equal'],parity['raw_file_equal'],parity['old_oracle_sha256'])
        print(json.dumps(parity,indent=2))
if __name__=='__main__':main()
