"""Native exec coverage from the calibrated edited-role harness."""
import collections,json,re
from pathlib import Path

def audit_native(log, paths, records):
    ran = collections.Counter()
    for trace in log.glob("exec.*"):
        for line in trace.read_text().splitlines():
            if not re.search(r"= 0$", line):
                continue
            match = re.match(r'^execve\("([^"\\]+)",', line)
            if not match:
                raise ValueError(f"unresolved successful exec: {line[:200]}")
            ran[match[1]] += 1
    (log / "native-execs.json").write_text(json.dumps(ran, indent=2) + "\n")
    for role in ("cargo", "rustc", "wild"):
        if ran[str(paths[role])] != sum(r["role"] == role for r in records):
            raise ValueError(f"native {role} execs do not match wrapper roster: {ran}")
    allowed = {str(p) for p in paths.values()}
    for exe in ran:
        if Path(exe).name in {"cargo", "rustc", "wild", "wild-ld", "ld.bfd", "ld", "ld.lld", "rust-lld"} and exe not in allowed:
            raise ValueError(f"unwrapped compiler/cargo/linker in native run: {exe}")
