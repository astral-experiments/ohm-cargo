"""Let an owner pause an excluded cold Cargo build without leaving active compiler descendants."""
import os
import signal
import subprocess
import time

def group_exists(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False

def stop_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    deadline=time.monotonic()+3
    while time.monotonic()<deadline:
        proc.poll()
        if not group_exists(proc.pid):
            return
        time.sleep(.05)
    try:
        os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait()
    # Zombie children may retain the session ID briefly after all executable work exited.
    time.sleep(.10)

def run_warm(argv, src, env, log, pause, parked):
    for attempt in range(1000):
        pending=log/f'cold-attempt-{attempt:03}.log'
        with pending.open('x') as stream:
            proc=subprocess.Popen(argv,cwd=src,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            try:
                while proc.poll() is None:
                    if pause.exists():
                        stop_group(proc)
                        break
                    time.sleep(.25)
                else:
                    pending.rename(log/'cargo.log')
                    return proc.returncode
            except BaseException:
                stop_group(proc)
                raise
        parked()
    raise RuntimeError('unscored cold build repeatedly interrupted')
