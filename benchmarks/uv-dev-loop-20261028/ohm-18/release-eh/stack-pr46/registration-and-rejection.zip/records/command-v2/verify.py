"""Validate one complete edited-command cohort/control using only standard Python and the receipts."""
import csv
import hashlib
import itertools
import json
import math
import statistics
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def files_match(a,b,allowed):
    assert a.keys() == b.keys()
    for p,x in a.items():
        y=b[p]
        assert x['size'] == y['size'] and x['canonical_sha256'] == y['canonical_sha256'], p
        if p not in allowed:
            assert x['sha256']==x['canonical_sha256']==y['sha256'] and x['permitted_fields'] is None
        if x['sha256'] != y['sha256']:
            assert p in allowed
            f,g=x['permitted_fields'],y['permitted_fields']
            assert f['rodata'][:2]==g['rodata'][:2] and f['build_id'][:2]==g['build_id'][:2]
            assert {f['rodata'][2],g['rodata'][2]}=={0,8} and f['build_id'][2]!=g['build_id'][2]
            assert f['rodata'][1]-f['rodata'][0]==1 and f['build_id'][1]-f['build_id'][0]==32
            assert all(len(bytes.fromhex(v['build_id'][2]))==32 for v in (f,g))
def statistics_for_pairs(rows,control):
    effects=[];differences=[];assignments=[];role_effects={r:[] for r in ('cargo','rustc','wild')}
    for pair in range(8):
        a,b=sorted(rows[pair*2:pair*2+2],key=lambda x:x['arm']!=control)
        assert a['arm']==control and b['arm']=='candidate'
        x,y=int(a['total']),int(b['total'])
        effects.append(100*(x-y)/x)
        sign=1 if int(a['position'])==0 else -1
        differences.append(sign*math.log(x/y));assignments.append(sign)
        for r in role_effects:
            role_effects[r].append(100*(int(a[r])-int(b[r]))/int(a[r]))
    assert sum(assignments)==0
    score=abs(sum(d*s for d,s in zip(differences,assignments)))
    fake=[abs(sum(d if j in pos else -d for j,d in enumerate(differences))) for pos in itertools.combinations(range(8),4)]
    order_p=sum(v+1e-15>=score for v in fake)/len(fake)
    wins=sum(x>0 for x in effects);losses=sum(x<0 for x in effects);n=wins+losses
    sign_p=min(1,2*sum(math.comb(n,k) for k in range(min(wins,losses)+1))/(2**n)) if n else 1
    md=statistics.median(effects)
    return {'signed_improvements_pct':effects,'median_improvement_pct':md,'wins':wins,'losses':losses,'ties':8-n,
            'two_sided_paired_sign_p':sign_p,'two_sided_balanced_order_p':order_p,
            'role_median_improvement_pct':{k:statistics.median(v) for k,v in role_effects.items()},
            'qualified':wins==8 and md>=.10 and sign_p<=.05 and order_p<=.05}
def main():
    key=sys.argv[1];plan=read(here.parent/'plan.json');cfg=plan['macro_cohorts'][key];arm=cfg['control']
    out=here/'results'/cfg['cohort']/arm
    roles=plan['macro_roster'];expect={k:roles[k] for k in ('cargo','rustc','wild')}
    v2=read(here/'plan.json');assert v2['original_plan_sha256']==sha(here.parent/'plan.json')
    binding=v2['stock_path_bindings'][cfg['cohort']];allowed=set(binding['allowed'])
    assert binding['proof_sha256']==sha(here/'stock'/cfg['cohort']/'binding.json')
    roster=read(out/'admission.json');assert roster['role_counts']==expect and len(roster['tests'])==roles['unique_test_executables']
    ref=None
    for i,(mode,name) in enumerate(cfg['native_count_admission']):
        root=out/f'admit-{i}-{mode}-{name}';r=read(root/'receipt.json')
        assert r['roster']==roster and r['source_sha256']==cfg['edits']['1']
        if ref is None:ref=r
        else:
            assert r['source_mtime_ns']==ref['source_mtime_ns']
            files_match(ref['files'],r['files'],allowed)
        if mode=='native':
            assert (root/'native-execs.json').exists()
    rows=list(csv.DictReader((out/'samples.csv').open()))
    assert len(rows)==16
    for i,pair in enumerate(cfg['pairs']):
        refs=[]
        for j,name in enumerate(pair['order']):
            row=rows[2*i+j];assert (int(row['pair']),int(row['id']),int(row['position']),row['arm'])==(i,pair['id'],j,name)
            receipt_path=out/row['receipt'];assert receipt_path.parent.parent==out
            r=read(receipt_path);assert r['roster']==roster and r['source_sha256']==row['source_sha256']==cfg['edits'][str(pair['id'])]
            for role,count in expect.items():
                rs=[read(f) for f in receipt_path.parent.glob(role+'-*.json')]
                assert len(rs)==count and all(str(x['pid']) in x['threads'] and x['instructions']==sum(x['threads'].values())>0 for x in rs)
                assert sum(x['instructions'] for x in rs)==int(row[role])==r['totals'][role]
            assert sum(r['totals'].values())==int(row['total']) and len(r['files'])>=72
            refs.append(r)
        assert refs[0]['source_mtime_ns']==refs[1]['source_mtime_ns']
        files_match(refs[0]['files'],refs[1]['files'],allowed)
    restore=read(out/'restore.json');assert restore['target_vacant'] and restore['home_restored'] and restore['source_sha256']==plan['uv_edit_preimage_sha256']
    complete=read(out/'complete.json');assert complete['common_unchanged'] and complete['arms']==16 and complete['admission_cells']==4
    summary={'cell':key,'control':arm,'plan_sha256':sha(here.parent/'plan.json'),'stock_path_plan_sha256':sha(here/'plan.json'),'samples_sha256':sha(out/'samples.csv'),
             'role_counts':expect,'unique_test_executables':72,**statistics_for_pairs(rows,arm)}
    destination=out/'summary.json'
    if destination.exists():assert read(destination)==summary
    else:destination.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':
    main()
