"""Bindings for the preregistered exact-release edited-command harness."""
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUTER = HERE.parent
WORK = OUTER.parents[1]
BENCH = Path((WORK / 'bench-home.path').read_text().strip())
RESULTS = HERE / 'results'
ROOTS = BENCH / 'release-eh-roles-18'
RELEASE = WORK / 'upstream-monitor/toolchain18'
UV = 'c22e6b71933443e9cd299d4b6ac8de035ed4825b'
EDIT = 'crates/uv/src/install_source.rs'
BEFORE = b'component == cellar && next == formula'
ORIGINAL = subprocess.check_output(['git','-C',WORK/'uv','show',f'{UV}:{EDIT}'])
COMMAND = ['test','--no-run','--locked','--offline','-j8']
ARMS = {name:(RELEASE/'bin/cargo',OUTER/'bin'/name) for name in ('base','candidate')}
ROLES = ('cargo','rustc','wild')
WRAP = OUTER.parent / 'command/wrap.py'  # Keep the private wrapper and tool paths fixed.
COUNTER = WORK / 'edit-link-profile/native-instrument/count.py'
def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    return json.loads(path.read_text())
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
def need(value,message):
    if not value:
        raise RuntimeError(message)
def body(symbol,idx):
    need(ORIGINAL.count(BEFORE)==1,'source predicate moved')
    expression=('{\n                component == cellar && (next == formula || next == OsStr::new('
                +f'"uv-eh-{symbol}{idx:02d}"))\n            }}')
    return ORIGINAL.replace(BEFORE,expression.encode())
