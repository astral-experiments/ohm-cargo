"""Replay the frozen Wild #46 admission with only the two portable archives."""
import ast
import copy
import hashlib
import json
import sys
import zipfile
from pathlib import Path

KIT = Path(__file__).resolve().parent
FOCUS_HASH = "bfea34688b16039088d9244b3066191bea4f5dadf6fdd3eca30b5c0c37543711"
PLAN_HASH = "a1428428f46dd140c7a93d71ebe4207cfb5a9e013e6fd576ac852342a35d48ed"
RECOVERY_HASH = "8d33ecbb8c695859e848f30d20ee70ef8d3812796bfcfeaea0d743bd0e204158"
FIRST = "command/results/initial/base/"
NATIVE = FIRST + "admit-0-native-candidate/"
P = "physical/initial-base-"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main(focus_zip):
    if not __debug__:
        raise RuntimeError("Run without -O so the registered comparator's assertions execute")
    assert sha(focus_zip.read_bytes()) == FOCUS_HASH
    index = json.loads((KIT / "members.json").read_bytes())
    with zipfile.ZipFile(focus_zip) as focus:
        assert len(focus.infolist()) == len(set(focus.namelist())) == 170
        assert focus.testzip() is None
        def raw(name):
            if name in index:
                data = (KIT / "records" / name).read_bytes()
                assert sha(data) == index[name], name
                return data
            return focus.read(name)

        def read(name):
            return json.loads(raw(name))

        def check(name, expected):
            assert sha(raw(name)) == expected, name

        assert sorted(index) == sorted(p.relative_to(KIT / "records").as_posix()
                                       for p in (KIT / "records").rglob("*") if p.is_file())
        for name in index:
            raw(name)
        check("plan.json", PLAN_HASH)
        check("recovery/registration.json", RECOVERY_HASH)
        plan = read("plan.json")
        reg = read("recovery/registration.json")
        impl = read("implementation.json")
        assert impl["plan_sha256"] == reg["original_plan_sha256"] == PLAN_HASH
        check("implementation.json", reg["original_implementation_sha256"])
        for manifest in (impl["files"], reg["new_files"]):
            for name, digest in manifest.items():
                check(name, digest)
        assert reg["unchanged_macro_cohorts"] == plan["macro_cohorts"]
        bindings = read("command/plan.json")["stock_path_bindings"]
        assert reg["stock_path_bindings"] == bindings == read("command-v2/plan.json")["stock_path_bindings"]
        for cohort in ("initial", "replica"):
            old = "command/release-product-oracles/" + cohort + ".json"
            assert raw(old) == raw(old.replace("command/", "command-v2/"))
        oldverify = raw("command/verify.py")
        assert sha(oldverify) == reg["old_command_verifier_sha256"] == reg["new_command_verifier_sha256"]
        assert raw("command-v2/verify.py") == oldverify
        check("command/run.py", reg["old_collector_sha256"])
        check("command-v2/run.py", reg["new_collector_sha256"])
        check("recovery/reader.patch", reg["reader_patch_sha256"])
        assert b'files_match(rec["files"],expected["files"]' in raw("command/run.py")
        assert b'files_match(read(log/"receipt.json")["files"],expected["files"]' in raw("command-v2/run.py")
        # Execute just the authentic, hash-verified comparison on read-only records.
        tree = ast.parse(oldverify)
        tree.body = [fn for fn in tree.body if isinstance(fn, ast.FunctionDef) and fn.name == "files_match"]
        assert len(tree.body) == 1
        namespace = {}
        exec(compile(tree, "frozen-command-verify.py", "exec"), namespace)
        compare = namespace["files_match"]
        diag = read("recovery/diagnosis.json")
        audit = read("external/wild-46-rejected-initial-audit.json")
        check("recovery/diagnosis.json", reg["rejection_diagnosis_sha256"])
        check(NATIVE + "receipt.json", audit["admission_sha256"])
        check("command/release-product-oracles/initial.json", audit["release_reference_sha256"])
        r = read(NATIVE + "receipt.json")
        oracle = read("command/release-product-oracles/initial.json")
        actual = r["files"]
        expected = oracle["sources"][r["source_sha256"]]["files"]
        assert r["roster"] == oracle["roster"]
        assert r["roster"]["role_counts"] == {"cargo": 1, "rustc": 6, "wild": 5}
        assert len(set(r["roster"]["tests"])) == 72
        assert r["totals"] == {"cargo": 0, "rustc": 0, "wild": 0}
        assert len(actual) == len(expected) == diag["registered_product_count"] == 74
        allowed = set(bindings["initial"]["allowed"])
        different = {p for p in actual if actual[p]["sha256"] != expected[p]["sha256"]}
        assert different == set(diag["new_products"]) == set(audit["allowed_raw_differences"])
        assert len(different) == 2 and different <= allowed
        assert len(actual) - len(different) == diag["raw_equal"] == 72
        def rejected(data):
            try:
                compare(data, expected, allowed)
            except AssertionError:
                return True
            raise AssertionError("The comparator accepted an invalid input")

        mixed = copy.deepcopy(actual)
        for obj in mixed.values():
            if obj["permitted_fields"]:
                obj["permitted_fields"] = {k: tuple(v) for k, v in obj["permitted_fields"].items()}
        rejected(mixed)
        compare(actual, expected, allowed)
        compare(json.loads(json.dumps(mixed)), expected, allowed)
        tampered = copy.deepcopy(actual)
        ordinary = min(set(actual) - allowed)
        old = tampered[ordinary]["sha256"]
        tampered[ordinary]["sha256"] = ("1" if old[0] == "0" else "0") + old[1:]
        rejected(tampered)
        tampered = copy.deepcopy(actual)
        tampered[min(different)]["permitted_fields"]["rodata"][0] += 1
        rejected(tampered)
        # Raw byte facts below come from the original ELF reconstruction. This kit
        # cross-checks its signed-off hashes and exact positions against both manifests.
        details = {}
        for path, rec in sorted(diag["new_products"].items()):
            a, b = actual[path], expected[path]
            assert rec["reconstructed"] == {"actual": a["sha256"], "old_reconstructed": b["sha256"],
                                              "canonical": a["canonical_sha256"]}
            assert a["canonical_sha256"] == b["canonical_sha256"]
            size = rec["size"]
            assert size == a["size"] == b["size"]
            changed = 0
            positions = {}
            for field in rec["fields"]:
                key = field["field"]
                lo, hi = field["range"]
                for obj, h in [(a, "observed_hex"), (b, "old_hex")]:
                    left, right, value = obj["permitted_fields"][key]
                    assert (lo, hi) == (left, right)
                    assert bytes.fromhex(field[h]) == (bytes([value]) if key == "rodata" else bytes.fromhex(value))
                a_bytes, b_bytes = bytes.fromhex(field["observed_hex"]), bytes.fromhex(field["old_hex"])
                assert len(a_bytes) == len(b_bytes) == hi - lo
                spots = [lo + i for i, (x, y) in enumerate(zip(a_bytes, b_bytes)) if x != y]
                assert len(spots) == field["different_bytes"]
                changed += len(spots)
                positions[key] = {"range": [lo, hi], "changed_offsets": spots}
            assert set(positions) == {"rodata", "build_id"} and size - changed == rec["unchanged_bytes"]
            details[path] = {**rec["reconstructed"], "size": size, "positions": positions}
        assert sum(x["size"] for x in details.values()) == diag["retained_bytes"] == 327155680
        assert diag["observed_native_candidate_commands"] == 1
        assert diag["scored_rows"] == diag["actual_counted_candidate_commands"] == audit["sampled"] == 0
        native_roles = []
        for group in ("fresh", "structural", "admit-0-native-candidate"):
            for role in ("cargo", "rustc", "wild"):
                native_roles.extend(read(n) for n in index if n.startswith(FIRST + group + "/" + role + "-"))
        assert len(native_roles) == diag["native_only_role_receipts"] == 25
        assert all("instructions" not in x and "threads" not in x for x in native_roles)
        assert not any(n.startswith(FIRST) and ("/pair-" in n or n.endswith("samples.csv")) for n in index)
        check(P + "returned.json", reg["unchanged_failed_return_sha256"])
        closed, guest, outer = (read(P + n) for n in ("returned.json", "host-returned.json", "tool-return.json"))
        check(P + "returned.json", outer["physical_return_sha256"])
        check(P + "host-returned.json", outer["guest_return_sha256"])
        assert closed["status"] == "rejected" and closed["all_children_returned"] and not closed["remaining_on_granted_cpus"]
        assert guest["true_supervisor_absent"] and not guest["workers_on_granted_cpus"]
        assert outer["supervisor"]["exit"] == 1 and outer["host_observer"]["exit"] == 0
        assert b"assert f['rodata'][:2]==g['rodata'][:2]" in raw(P + "0.log")
        before, after = read(P + "slots-premark.json"), read(P + "slots-returned.json")
        assert before["slot_identity"] == after["slot_identity"] and after["visible_target_absent"]
        assert before["source_sha256"] == after["uv_source_sha256"] == plan["uv_edit_preimage_sha256"]
        assert before["source_mtime_ns"] == after["before_source_mtime_ns"] == after["after_source_mtime_ns"]
        assert read(FIRST + "restore.json") == audit["slots_custody"]
        retired = read("recovery/banks-retired.json")
        assert len(retired["deleted_exactly"]) == 2 and retired["both_retained_elf_sha256_verified"] and retired["original_seeds_unchanged"]
        assert audit["tuple_failure_reproduced"] and audit["serialized_receipt_passed"] and audit["tampered_control_failed"]
        return {"focused_archive_files": 170, "original_sealed_files": len(impl["files"]),
                "recovery_sealed_files": len(reg["new_files"]), "unchanged_planned_pairs": {
                    co: len(cell["pairs"]) for co, cell in plan["macro_cohorts"].items()},
                "native_roster": r["roster"]["role_counts"], "test_executables": 72, "scored_macro_rows": 0,
                "native_only_role_receipts": len(native_roles), "raw_identical": 72, "canonical_match": 74,
                "tuple_list_original_failure": True, "serialized_match": True, "corrupted_raw_sha_rejected": True,
                "corrupted_allowed_position_rejected": True, "supervisor_exit": 1, "observer_exit": 0,
                "physical_scope_closed": True, "host_only_elf_bytes": diag["retained_bytes"], "elf_receipts": details}


if __name__ == "__main__":
    print(json.dumps(main(Path(sys.argv[1])), indent=2))
