"""Run and verify the preregistered direct-release single-worker capture entry gate."""
import csv
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parents[1]
inputs = work / 'round18-linker/confirm18'
counter = work / 'dynamorio/count.py'
slot = here / 'ld.wild'
out = here / 'linked-output'
def read(p):
    return json.loads(p.read_text())
def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n')
def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def pause():
    flag = here / 'pause.requested'
    if flag.exists():
        state = here / 'counter.paused'
        state.write_text('idle at a registered pair boundary\n')
        try:
            while flag.exists():
                time.sleep(.5)
        finally:
            state.unlink(missing_ok=True)

def main():
    plan = read(here / 'plan.json')
    lock = read(here / 'focused-input-lock.json')
    assert sha(here / 'plan.json') == lock['plan_sha256'] and sha(here / 'binaries.json') == lock['binaries_sha256']
    assert all(sha(work / p) == value for p, value in lock['inputs'].items())
    cpus = sorted(os.sched_getaffinity(0))
    assert len(cpus) == 1 and cpus[0] in lock['allowed_cpus']
    official = read(here / 'official-tests/summary.json')
    assert len(official) == 8 and all(v['returncode'] == 0 for v in official.values())
    malformed = read(here / 'fixture-results/summary.json')
    assert set(malformed) == set(plan['probes'])
    for rows in malformed.values():
        assert set(rows) == {'base', 'candidate'} and all(v['matched'] and v['expected'] for v in rows.values())
    results = here / 'focused'
    results.mkdir()
    raw = results / 'raw'
    raw.mkdir()
    spec = importlib.util.spec_from_file_location('paired_analysis', work / 'round18-eh/analysis.py')
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    env0 = {k: v for k, v in os.environ.items() if not k.startswith(('WILD_', 'OHM_'))
            and k not in ('CARGO_MAKEFLAGS', 'MFLAGS', 'MAKEFLAGS', 'RUSTFLAGS', 'RUSTC_WRAPPER', 'LD_PRELOAD')}
    opts = {}
    for k, oracle in plan['captures'].items():
        arg_file = inputs / f'argv-{k}.json'
        assert sha(arg_file) == oracle['argv']['recorded']
        d = read(arg_file)
        argv = d['args']
        assert argv.count('-o') == 1 and not any(s.startswith('--threads') or s in ('--fork', '--no-fork') for s in argv)
        argv[argv.index('-o') + 1] = str(out)
        opts[k] = ([str(slot), '--no-fork', '--threads=1', *argv], env0 | d['env'])
    save(results / 'argv.json', {k: argv for k, (argv, _env) in opts.items()})
    save(results / 'receipt.json', {'plan_sha256': sha(here / 'plan.json'), 'input_lock_sha256': sha(here / 'focused-input-lock.json'),
                                     'affinity': cpus, 'single_worker': True, 'start_utc': datetime.now(UTC).isoformat()})

    def run(stage, shape, block, position, arm, counted):
        slot.unlink(missing_ok=True)
        os.link(here / 'bin' / arm, slot)
        out.unlink(missing_ok=True)
        argv, env = opts[shape]
        command = [sys.executable, str(counter), '--', *argv] if counted else argv
        proc = subprocess.run(command, env=env, capture_output=True, timeout=300)
        tag = f'{stage}-{shape}-{block:02d}-{position}-{arm}'
        (raw / f'{tag}.stderr').write_bytes(proc.stderr)
        (raw / f'{tag}.stdout').write_bytes(proc.stdout)
        assert proc.returncode == 0, (tag, proc.returncode)
        count = None
        diag = proc.stderr
        if counted:
            diag, sep, payload = proc.stderr.rpartition(b'DynamoRIO ')
            assert sep, tag
            count = json.loads(payload)
            assert count['instructions'] > 0 and count['instructions'] == sum(count['threads'].values())
            assert str(count['pid']) in count['threads']
        binary_digest = sha(out)
        assert not diag and not proc.stdout and binary_digest == plan['captures'][shape]['one_worker_file_sha256'], tag
        return {'block': block, 'position': position, 'arm': arm, 'instructions': count['instructions'] if count else None,
                'sha256': binary_digest, 'stderr': hashlib.sha256(diag).hexdigest(), 'returncode': proc.returncode,
                'pid': count['pid'] if count else None, 'bytes': out.stat().st_size}

    admission = {}
    for k in plan['captures']:
        pause()
        admission[k] = [run('admit', k, 0, i, arm, False) for i, arm in enumerate(('base', 'candidate'))]
    save(results / 'admission.json', admission)
    tiny = plan['tiny_descriptive_control']
    pause()
    save(results / 'tiny.json', [run('tiny', tiny['capture'], 0, i, arm, True) for i, arm in enumerate(tiny['order'])])
    verdict = {'plan_sha256': sha(here / 'plan.json'), 'cells': {}}
    for key in plan['focused_cell_order']:
        cell = plan['focused_cells'][key]
        groups = {}
        with (results / f'{key}.csv').open('x') as stream:
            writer = None
            for block, pair in enumerate(cell['pairs']):
                order = pair['order']
                pause()
                groups[block] = {}
                for pos, arm in enumerate(order):
                    row = run(key, cell['capture'], block, pos, arm, True)
                    if writer is None:
                        writer = csv.DictWriter(stream, fieldnames=list(row))
                        writer.writeheader()
                    writer.writerow(row)
                    stream.flush()
                    groups[block]['both' if arm == 'candidate' else 'base'] = row
        result = analysis.paired(groups)
        verdict['cells'][key] = result
        save(results / 'progress.json', verdict)
        print(key, result, flush=True)
        if not result['qualified']:
            break
    verdict['entry_gate_qualified'] = len(verdict['cells']) == len(plan['focused_cells']) and all(
        row['qualified'] for row in verdict['cells'].values())
    verdict['finished_utc'] = datetime.now(UTC).isoformat()
    save(results / 'summary.json', verdict)
    print('entry gate qualified', verdict['entry_gate_qualified'], flush=True)

if __name__ == '__main__':
    main()
