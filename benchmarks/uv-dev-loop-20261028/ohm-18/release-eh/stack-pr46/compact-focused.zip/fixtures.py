"""Exercise the original and candidate native ELF writers on success and malformed unwind records."""
import hashlib,json,os,resource,struct,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;d=p.parent/'fixtures';run=p/'fixture-results';assert (p/'focused-input-lock.json').exists();run.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def limit():
 resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
obj=run/'frame.o';subprocess.run(['as','--64','-o',obj,d/'frame.s'],check=True)
base=obj.read_bytes();eh=struct.unpack_from('<Q',base,40)[0];stride,n,st=struct.unpack_from('<HHH',base,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',base,eh+i*stride) for i in range(n)];so=sections[st][4]
def section_name(s):
 at=so+s[0];return base[at:base.index(b'\0',at)]
by_name={section_name(s):s for s in sections};frames=by_name[b'.eh_frame'][4];cie_len=struct.unpack_from('<I',base,frames)[0];fde=cie_len+4
roff,rs=by_name[b'.rela.eh_frame'][4:6];pc=next(i for i in range(roff,roff+rs,24) if struct.unpack_from('<Q',base,i)[0]==fde+8)
assert struct.unpack_from('<Q',base,pc+8)[0]&0xffffffff==2
bad_addend=bytearray(base);struct.pack_into('<q',bad_addend,pc+16,1<<34);(run/'large-addend.o').write_bytes(bad_addend)
bad_cie=bytearray(base);struct.pack_into('<I',bad_cie,frames+fde+4,0xfffffff0);(run/'malformed-cie.o').write_bytes(bad_cie)
cases=[('normal',obj,['--eh-frame-hdr'],True,b''),('no-hdr',obj,[],True,b''),('overflow-pc',run/'large-addend.o',['--eh-frame-hdr'],False,b'32 bit overflow in frame_ptr'),('broken-cie',run/'malformed-cie.o',['--eh-frame-hdr'],False,b'CIE'),('overflow-fde',obj,['--eh-frame-hdr','-T',d/'gap.ld'],False,b'32 bit overflow when computing frame_info_ptr')]
env={k:v for k,v in os.environ.items() if not k.startswith(('OHM_','WILD_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','LD_PRELOAD','RUSTC_WRAPPER','RUSTFLAGS')};results={}
for case,src,extra,success,expected in cases:
 results[case]={};prev=None
 for arm in ['base','candidate']:
  out=run/'fixture-output';out.unlink(missing_ok=True)
  slot=run/'ld.wild';slot.unlink(missing_ok=True);os.link(p/'bin'/arm,slot)
  proc=subprocess.run([slot,'--threads=1','--no-fork','--build-id=none','-e','_start','-o',out,*extra,src],env=env,capture_output=True,timeout=20,preexec_fn=limit)
  raw=proc.stdout+proc.stderr;(run/f'{case}-{arm}.log').write_bytes(raw)
  ident=(proc.returncode,raw,sha(out.read_bytes()) if proc.returncode==0 else None)
  result={'status':proc.returncode,'diagnostic_sha256':sha(raw),'matched':prev is None or ident==prev,'expected':(proc.returncode==0)==success and expected in raw,'output_sha256':ident[2],'input_sha256':sha(src.read_bytes())}
  results[case][arm]=result;prev=ident
(run/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for k,g in results.items():print(k,[(arm,v['status'],v['expected'],v['matched']) for arm,v in g.items()])
raise SystemExit(not all(v['matched'] and v['expected'] for g in results.values() for v in g.values()))
