"""Reconstruct the complete #46 tree from its audited five blobs, and stage #48 verbatim."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
RELEASE = HERE.parent
WORK = RELEASE.parent
REPO = WORK / 'ohm-wild'
OLD = WORK / 'round18-linker/current-pr46'
BASE = 'e856d81f6683cad80b9fe0ebf1a0c3c403c6fe11'
HEAD = 'db821991bd2931dd83e59f236149340ddfc2b427'
PR48 = '925cbbd80297f9054a7d80fd386a1ab2407735e5'
PATCH = '6cdd5a0e91673446eaae717184ca4d186e91967e83f6d88f9f273fd80c7bea61'
WRITER = 'libwild/src/elf_writer.rs'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(kind, data):
    header = f'{kind} {len(data)}\0'.encode()
    return hashlib.sha1(header + data).hexdigest()


def tree_id(updates, directory=''):
    ref = BASE if not directory else f'{BASE}:{directory}'
    body = bytearray()
    for entry in git('ls-tree', '-z', ref).split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.split(b'\t', 1)
        mode, kind, sha = metadata.decode().split()
        path = '/'.join(filter(None, (directory, name.decode())))
        if path in updates:
            assert kind == 'blob'
            sha = updates[path]
        elif any(candidate.startswith(path + '/') for candidate in updates):
            assert kind == 'tree'
            sha = tree_id(updates, path)
        body.extend(mode.lstrip('0').encode() + b' ' + name + b'\0' + bytes.fromhex(sha))
    return blob('tree', body)


def archive_source(path, source, overlays):
    with path.open('xb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0, compresslevel=1) as compressed:
        with tarfile.open(fileobj=compressed, mode='w:') as dest, tarfile.open(fileobj=io.BytesIO(source), mode='r:') as src:
            for member in src:
                if member.isfile():
                    data = overlays.get(member.name)
                    if data is None:
                        data = src.extractfile(member).read()
                    member.size = len(data)
                    dest.addfile(member, io.BytesIO(data))
                else:
                    dest.addfile(member)


def main():
    out = HERE / 'source'
    out.mkdir()
    prev = json.loads((OLD / 'tree-proof.json').read_text())
    upstream = {n: json.loads((HERE / 'upstream' / f'pr{n}.json').read_text()) for n in (46, 48)}
    assert [upstream[n]['pr']['head'] for n in (46, 48)] == [HEAD, PR48]
    assert upstream[46]['pr']['base'] == upstream[48]['pr']['base'] == BASE
    changes = {v['filename']: v['sha'] for v in upstream[46]['files']}
    patches = {name: (OLD / 'overlay' / name).read_bytes() for name in changes}
    assert all(blob('blob', data) == changes[name] for name, data in patches.items())
    assert tree_id(changes) == prev['head_tree'] == '13d76585a97c428380410425f8db06dcb75ba885'
    source = git('archive', '--format=tar', BASE)
    pure = out / 'pr46.tar.gz'
    archive_source(pure, source, patches)
    patch = (RELEASE / 'eh.patch').read_bytes()
    assert digest(patch) == PATCH
    (out / 'eh.patch').write_bytes(patch)
    probe = out / 'patch-check'
    before = probe / WRITER
    before.parent.mkdir(parents=True)
    old = git('show', f'{BASE}:{WRITER}')
    before.write_bytes(old)
    subprocess.run(['patch', '--batch', '--fuzz=0', '-p1'], input=patch, cwd=probe, check=True)
    new = before.read_bytes()
    expected_rows = upstream[48]['files']
    assert len(expected_rows) == 1 and expected_rows[0]['filename'] == WRITER
    assert blob('blob', new) == expected_rows[0]['sha']
    stack = out / 'pr46-plus-pr48.tar.gz'
    archive_source(stack, source, {**patches, WRITER: new})
    source_json = {
        'pr46': HEAD, 'pr48': PR48, 'release_ref': BASE, 'base_tree': tree_id(changes),
        'stacked_tree': tree_id({**changes, WRITER: blob('blob', new)}),
        'release_and_pr46_writer_git_blob': blob('blob', old), 'pr48_and_stack_writer_git_blob': blob('blob', new),
        'base_writer_sha256': digest(old), 'stacked_writer_sha256': digest(new), 'patch_sha256': PATCH,
        'cargo_lock_sha256': digest(patches['Cargo.lock']), 'release_to_pr46_files': changes,
        'pr46_to_stacked_files': [WRITER], 'archives': {q.name: {'bytes': q.stat().st_size,
        'sha256': digest(q.read_bytes())} for q in (pure, stack)},
        'provenance': 'Git archive of the released commit. Five authenticated #46 blobs replace files on that otherwise unchanged tree. Both rebuilt Git trees retain the release modes and untouched IDs. The only subsequent changed blob must equal the published #48 result, after a zero-fuzz apply.'
    }
    (HERE / 'source.json').write_text(json.dumps(source_json, indent=2) + '\n')
    print(json.dumps(source_json, indent=2))


if __name__ == '__main__':
    main()
