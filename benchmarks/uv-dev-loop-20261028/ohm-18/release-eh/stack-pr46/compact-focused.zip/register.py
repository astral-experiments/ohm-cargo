"""Freeze the exact inputs, original source edits, independent arm orders and qualification policy."""
import copy
import datetime
import hashlib
import json
import random
from pathlib import Path

here=Path(__file__).resolve().parent
release=here.parent
work=release.parent
old=release/'command-v2'
safe=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
load=lambda f:json.loads(f.read_text())
root_plan=load(release/'plan.json')
source=load(here/'source.json')
previous=load(old/'plan.json')
control=load(work/'round18-linker/current-pr46/ready.json')
assert source['pr46']==control['source_commit'] and source['cargo_lock_sha256']==control['cargo_lock_sha256']
assert safe(release/'command-v2/plan.json')=='e7e3d236d3700c40b7bf20e4d5170bcd894a64777ee88695b4d4df4dd9eb31b3'
assert load(release/'compact-complete-command.json')['sha256']=='07f0710d0f7d6122396f06b71b107f8bdedb14a34fa0786a3c53e1e179427a19'
assert safe(old/'custody-after-replica-shipped.json')=='77a591f53c7d8aee25d2db5531cccd691795d8ca53710397750eba9d1d8e726f'
def schedule(label):
    material='ohm-18-uv-unwind-pr46-base-v1/'+label+'/'+source['stacked_tree']
    seed=int.from_bytes(hashlib.sha256(material.encode()).digest()[:8],'big')
    orders=[['base','candidate'] for _ in range(4)]+[['candidate','base'] for _ in range(4)]
    random.Random(seed).shuffle(orders)
    return {'seed_material':material,'seed':seed,'orders':orders}
focused={}
for shape in ('0','1'):
    spec=schedule('focused-'+shape)
    focused[shape+'-base']={'capture':shape,'control':'base','pairs':[{'order':o} for o in spec['orders']],'randomization':spec}
macro={}
for name in ['initial-base','replica-base']:
    cfg=copy.deepcopy(root_plan['macro_cohorts'][name])
    spec=schedule('command-'+name)
    cfg['prior_order_seed']=cfg.pop('seed')
    cfg['seed']=spec['seed']
    cfg['randomization']=spec
    for pair,order in zip(cfg['pairs'],spec['orders'],strict=True):pair['order']=order
    macro[name]=cfg
seeds=Path((work/'bench-home.path').read_text().strip())/'release-eh-roles-18'
refs=[release/'plan.json',release/'source.json',release/'compact-complete-command.json',release/'compact-stock-registration.json',release/'focused-input-lock.json',work/'round18-linker/confirm18/inputs.json',work/'round18-linker/current-pr46/ready.json',old/'plan.json',old/'custody-after-replica-shipped.json',old/'calibration/PASS.json',old/'run.py',old/'verify.py',old/'elf_equivalence.py',old/'warm_process.py',old/'trace.py',release/'command/wrap.py',release/'focus.py',release/'official-tests.py',release/'fixtures.py',work/'round18-eh/analysis.py',work/'dynamorio/count.py',work/'edit-link-profile/native-instrument/count.py']
for cohort in ['initial','replica']:
    refs += [old/'stock'/cohort/'binding.json',old/'results'/cohort/'base'/'summary.json',old/'results'/cohort/'base'/'samples.csv']
plan={'version':1,'utc':datetime.datetime.now(datetime.UTC).isoformat(),'source':source,'source_receipt_sha256':safe(here/'source.json'),'protocol_sha256':safe(here/'PROTOCOL.md'),'prepare_source_sha256':safe(here/'prepare-source.py'),'register_sha256':safe(Path(__file__)),'pr46_control':control,'candidate_hash_status':'bind after a clean build and before the first linker invocation or input measurement','retained_release_packet_sha256':load(release/'compact-complete-command.json')['sha256'],'source_references':{str(f.relative_to(work)):safe(f) for f in refs},'old_custody_sha256':safe(old/'custody-after-replica-shipped.json'),'captures':root_plan['captures'],'captures_census':str((work/'round18-linker/confirm18/inputs.json').relative_to(work)),'focused_cells':focused,'focused_cell_order':list(focused),'tiny_descriptive_control':{'capture':'2','order':['base','candidate']},'gates':root_plan['thresholds_for_each_focused_and_macro_cell'],'suite':root_plan['suite'],'probes':root_plan['probes'],'uv':root_plan['uv'],'uv_edit_file':root_plan['uv_edit_file'],'uv_edit_preimage_sha256':root_plan['uv_edit_preimage_sha256'],'shipped_toolchain':root_plan['shipped_toolchain'],'macro_command':root_plan['macro_command'],'macro_roster':root_plan['macro_roster'],'macro_cohorts':macro,'macro_cell_order':list(macro),'stock_path_bindings':previous['stock_path_bindings'],'seed_receipts':{cohort:{'sha256':safe(seeds/cohort/'common-ready.json'),'state':load(seeds/cohort/'common-ready.json')} for cohort in ['initial','replica']},'thresholds_for_each_focused_and_macro_cell':root_plan['thresholds_for_each_focused_and_macro_cell'],'scope':'Same complete command, same two edits and calculator, independently randomized fresh data on #46. Prior release packets reused only for input identity and artifact admission, no older instruction totals included.','resources':{'build_qa_gib':10,'reserve_gib':120,'macro_temporary_gib':36,'two_stage_allocations':True}}
f=here/'plan.json'
with f.open('x') as s:json.dump(plan,s,indent=2);s.write('\n')
with (here/'registration.sha256').open('x') as s:s.write(safe(f)+'  plan.json\n')
print(safe(f))
