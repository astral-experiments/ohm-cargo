"""Reuse the released actual-command machinery, paths and stock-proven oracles in distinct result files."""
import csv
import hashlib
import json
from pathlib import Path

here=Path(__file__).resolve().parent
outer=here.parent
work=outer.parent
old=outer/'command-v2'
dest=here/'command'
dest.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def stable(path,data):
    if path.exists():assert path.read_bytes()==data,path
    else:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as f:f.write(data)
def put(f,o):stable(f,(json.dumps(o,indent=2)+'\n').encode())
def one(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
plan=read(here/'plan.json')
p=old/'plan.py';s=p.read_text()
s=one(s,'WORK = OUTER.parent','WORK = OUTER.parents[1]')
s=one(s,"for name in ('base','shipped','candidate')","for name in ('base','candidate')")
s=one(s,"WRAP = OUTER / 'command/wrap.py'","WRAP = OUTER.parent / 'command/wrap.py'")
stable(dest/'plan.py',s.encode())
s=(old/'run.py').read_text()
s=s[:s.index('def main():')]
s=one(s,'    t=root/"tools"\n    for (role,src)', '    t=root/"tools"\n    private=t/"pr46-eh-arms"\n    private.mkdir(exist_ok=True)\n    for (role,src)')
s=one(s,'staged=t/"arms"/(arm+"-"+role)','staged=private/(arm+"-"+role)')
s=one(s,'home_states=root/("homes-"+cell)','home_states=root/("homes-pr46-eh-"+cell)')
s=one(s,'    save(log/"receipt.json",rec)\n    return rec','''    save(log/"receipt.json",rec)
    if kind in {"admit","sample"}:
        stored=read(HERE/"release-product-oracles"/(root.name+".json"))
        expected=stored["sources"][rec["source_sha256"]]
        need(rec["roster"]==stored["roster"],"normalized process/argv differs from the release")
        from verify import files_match
        files_match(rec["files"],expected["files"],set(read(HERE/"plan.json")["stock_path_bindings"][root.name]["allowed"]))
    return rec''')
stable(dest/'run.py',s.encode())
for f in ['trace.py','warm_process.py','verify.py','elf_equivalence.py','calibrate.c','wrap.py']:
    stable(dest/f,(old/f).read_bytes())
s=(old/'calibrate.py').read_text()
s=one(s,'COUNTER = HERE.parents[1]','COUNTER = HERE.parents[2]')
s=one(s,'WRAP = HERE / "wrap.py"','WRAP = HERE.parents[1] / "command/wrap.py"')
stable(dest/'calibrate.py',s.encode())
binding={'stock_path_bindings':plan['stock_path_bindings'],'original_plan_sha256':sha(here/'plan.json')}
put(dest/'plan.json',binding)
for cell,cfg in plan['macro_cohorts'].items():
    c=cfg['cohort'];base=old/'results'/c/'base'
    stock=old/'stock'/c/'binding.json';assert sha(stock)==binding['stock_path_bindings'][c]['proof_sha256']
    stable(dest/'stock'/c/'binding.json',stock.read_bytes())
    rows=list(csv.DictReader((base/'samples.csv').open()));refs={}
    for idx,(mode,arm) in enumerate(cfg['native_count_admission']):
        if mode=='native' and arm=='base':refs['1']=base/f'admit-{idx}-{mode}-{arm}'/'receipt.json'
    for row in rows:
        if row['arm']=='base':refs[str(row['id'])]=base/row['receipt']
    assert len(refs)==9
    first=None;records={}
    for idx,path in refs.items():
        r=read(path);source=cfg['edits'][idx];assert r['source_sha256']==source and len(r['files'])==74
        if first is None:first=r['roster']
        else:assert first==r['roster']
        records[source]={'edit':idx,'prior_receipt_sha256':sha(path),'files':r['files']}
    put(dest/'release-product-oracles'/(c+'.json'),{'cohort':c,'roster':first,'sources':records})
