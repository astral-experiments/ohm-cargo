"""Record immutable collector bytes and validate their data model before a physical allocation."""
import ast
import hashlib
import json
from pathlib import Path
from datetime import UTC,datetime
import os

here=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=read(here/'plan.json');ph=sha(here/'plan.json')
assert ph==(here/'registration.sha256').read_text().split()[0]
assert not (here/'binaries.json').exists() and not (here/'focused').exists() and not (here/'command/results').exists()
files=sorted(set([f for f in here.glob('*.py')]+[f for f in (here/'command').glob('*.py')]+[here/'PROTOCOL.md',here/'WINDOW.md',here/'plan.json',here/'source.json',here/'command/plan.json',here/'command/calibrate.c']+list((here/'command/stock').glob('*/binding.json'))+list((here/'command/release-product-oracles').glob('*.json'))+list((here/'source').glob('*.tar.gz'))+[here/'source/eh.patch']))
for f in files:
    if f.suffix=='.py':ast.parse(f.read_text(),filename=str(f))
for t in p['focused_cells'].values():
    assert len(t['pairs'])==8 and sum(a['order']==['base','candidate'] for a in t['pairs'])==4 and sum(a['order']==['candidate','base'] for a in t['pairs'])==4
for c,t in p['macro_cohorts'].items():
    assert len(t['pairs'])==8 and sum(a['order']==['base','candidate'] for a in t['pairs'])==4 and sum(a['order']==['candidate','base'] for a in t['pairs'])==4
    oracle=read(here/'command/release-product-oracles'/(t['cohort']+'.json'))
    assert oracle['roster']['role_counts']=={'cargo':1,'rustc':6,'wild':5} and len(oracle['roster']['tests'])==72
    assert len(oracle['sources'])==9 and all(len(v['files'])==74 for v in oracle['sources'].values())
    assert set(oracle['sources'])=={t['edits'][str(i)] for i in [1,*[x['id'] for x in t['pairs']]]}
receipt={'created_utc':datetime.now(UTC).isoformat(),'plan_sha256':ph,'private_compilation_or_linker_executions':0,'files':{str(f.relative_to(here)):sha(f) for f in files}}
with (here/'implementation.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
with (here/'implementation.sha256').open('x') as f:f.write(sha(here/'implementation.json')+'  implementation.json\n')
print(f"{len(files)} bound files; statistical plan {ph}; implementation {sha(here/'implementation.json')}")
