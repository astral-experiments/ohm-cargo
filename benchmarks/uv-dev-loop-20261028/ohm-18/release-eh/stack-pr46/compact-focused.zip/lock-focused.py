"""Verify sealed input bytes after release and lock the exact executables and collectors before admission."""
import argparse
import hashlib
import json
import os
from datetime import UTC, datetime
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parents[1]
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(path):
    return json.loads(path.read_text())
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--allocation', type=Path, required=True)
    args = ap.parse_args()
    alloc = read(args.allocation)
    assert alloc['study']=='wild-eh-pr46-stack' and alloc['phase']=='build-focus' and alloc['owner']=='/root' and alloc['plan_sha256']==sha(here/'plan.json')
    assert set(os.sched_getaffinity(0)) <= set(alloc['cpus'])
    result = here / 'focused-input-lock.json'
    assert not result.exists()
    plan = read(here / 'plan.json')
    b = read(here / 'binaries.json')
    registered = sha(here / 'plan.json')
    assert registered == (here / 'registration.sha256').read_text().split()[0] == b['plan_sha256']
    assert sha(here / 'PROTOCOL.md') == plan['protocol_sha256'] and sha(here / 'register.py') == plan['register_sha256']
    assert sha(here / 'source.json') == plan['source_receipt_sha256']
    for name, expected in plan['source_references'].items():
        assert sha(work / name) == expected, name
    for arm, attrs in b['arms'].items():
        assert sha(here / 'bin' / arm) == attrs['binary_sha256'], arm
    manifest = read(work / 'round18-linker/confirm18/inputs.json')
    capture = work / 'round18-linker/captures18'
    verified = 0
    digests = {}
    for rel, length, expected in manifest:
        if rel.split('/', 1)[0] not in plan['captures']:
            continue
        path = capture / rel
        if length == 'link':
            assert path.is_symlink() and os.readlink(path) == expected, rel
        else:
            assert path.is_file()
            stat = path.stat()
            identity = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
            if identity not in digests:
                digests[identity] = sha(path)
                assert path.stat().st_mtime_ns == stat.st_mtime_ns, rel
            assert stat.st_size == length and digests[identity] == expected, rel
        verified += 1
    assert verified > 0
    helpers = [here / name for name in ['focus.py', 'fixtures.py', 'official-tests.py', 'lock-focused.py']]
    helpers += [work / 'dynamorio/DynamoRIO-Linux-11.3.0-1/bin64/drrun']
    lock = {'created_utc': datetime.now(UTC).isoformat(), 'plan_sha256': registered, 'binaries_sha256': sha(here / 'binaries.json'),
            'allocation_sha256': sha(args.allocation), 'allowed_cpus': sorted(alloc['cpus']), 'capture_entries_verified': verified, 'distinct_regular_inodes_hashed': len(digests),
            'inputs': {str(p.relative_to(work)): sha(p) for p in helpers}}
    with result.open('x') as out:
        json.dump(lock, out, indent=2)
        out.write('\n')
    print(sha(result))
if __name__ == '__main__':
    main()
