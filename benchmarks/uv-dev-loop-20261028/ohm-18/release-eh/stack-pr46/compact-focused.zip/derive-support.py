"""Adapt the frozen release collectors to two arms, segregated paths and the new locked plan."""
from pathlib import Path
import json,hashlib,shutil
here=Path(__file__).resolve().parent
old=here.parent
def change(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)
def emit(name,s):
    f=here/name
    if f.exists():assert f.read_text()==s,name
    else:f.write_text(s)
s=(old/'focus.py').read_text()
s=change(s,'work = here.parent','work = here.parents[1]')
s=change(s,"{'base', 'candidate', 'shipped'}","{'base', 'candidate'}")
s=change(s,"('base', 'shipped', 'candidate')","('base', 'candidate')")
s=change(s,"for block, order in enumerate(cell['pairs']):","for block, pair in enumerate(cell['pairs']):\n                order = pair['order']")
emit('focus.py',s)
s=(old/'fixtures.py').read_text()
s=change(s,"d=p/'fixtures'","d=p.parent/'fixtures'")
s=change(s,"['base','candidate','shipped']","['base','candidate']")
emit('fixtures.py',s)
s=(old/'official-tests.py').read_text()
s=change(s,'w=p.parent;src','w=p.parents[1];src')
s=change(s,"CARGO_TARGET_DIR=str(w/'wild-unit-target')","CARGO_TARGET_DIR=str(p/'qa-target'),CARGO_INCREMENTAL='0'")
s=change(s,"s['changed_files'][0]","s['pr46_to_stacked_files'][0]")
s=change(s,"s['candidate_source_sha256']","s['stacked_writer_sha256']")
emit('official-tests.py',s)
s=(old/'lock-focused.py').read_text()
s=change(s,'work = here.parent','work = here.parents[1]')
s=change(s,"assert 'release-eh' in alloc['tasks'] and alloc['released_utc']","assert alloc['study']=='wild-eh-pr46-stack' and alloc['phase']=='build-focus' and alloc['owner']=='/root' and alloc['plan_sha256']==sha(here/'plan.json')")
s=change(s,"plan['plan_code_sha256']","plan['register_sha256']")
s=change(s,"    assert sha(work / 'round18-linker/build-anchored.py') == plan['builder_sha256']\n    for name, expected in plan['support_sha256'].items():","    assert sha(here / 'source.json') == plan['source_receipt_sha256']\n    for name, expected in plan['source_references'].items():")
emit('lock-focused.py',s)
