"""Run one new admitted complete-command cell and return its private tool slots intact."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import subprocess
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run as m
from verify import files_match

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def read(p):return json.loads(p.read_text())
def identity(p):
    s=p.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,sha(p)]
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--allocation',type=Path,required=True);a=ap.parse_args()
    here=Path(__file__).resolve().parent;stack=here.parent;alloc=read(a.allocation);cell=alloc['phase']
    assert cell in ('initial-base','replica-base') and alloc['plan_sha256']==sha(stack/'plan.json') and alloc['owner']=='/root'
    assert read(stack/'focused/summary.json')['entry_gate_qualified'] and (stack/'physical/build-focus-returned.json').is_file()
    plan=read(stack/'plan.json');cfg=plan['macro_cohorts'][cell];cohort=cfg['cohort'];ro=m.ROOTS/cohort
    previous='build-focus' if cell=='initial-base' else 'initial-base'
    assert read(stack/'physical'/(previous+'-returned.json'))['status']=='qualified'
    for k,expected in plan['shipped_toolchain'].items():
        exe=m.RELEASE/('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild' if k=='wild' else 'bin/'+k)
        if k=='wild':
            exe=next(q for q in [exe,m.RELEASE/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd',m.RELEASE/'bin/wild'] if q.is_file() and sha(q)==expected)
        assert sha(exe)==expected,(k,exe)
    assert sha(ro/'common-ready.json')==plan['seed_receipts'][cohort]['sha256']
    source=ro/'source'/m.EDIT;prior_stat=source.stat();assert sha(source)==plan['uv_edit_preimage_sha256']
    binaries=read(stack/'binaries.json');ids={name:{'cargo':plan['shipped_toolchain']['cargo'],'wild':v['binary_sha256']} for name,v in binaries['arms'].items()}
    assert set(ids)=={'base','candidate'}
    for name,(cargo,wild) in m.ARMS.items():assert sha(cargo)==ids[name]['cargo'] and sha(wild)==ids[name]['wild']
    assert sha(m.WRAP)==sha(here/'wrap.py')
    out=here/'calibration'/cell
    subprocess.run([sys.executable,'-B',here/'calibrate.py',out],check=True)
    assert (out/'PASS.json').exists()
    backup=ro/'tools'/('pr46-slot-recovery-'+cell);backup.mkdir()
    slots={}
    for role in ['cargo','wild']:
        slot=ro/'tools'/role
        assert slot.is_file() and not slot.is_symlink()
        slots[role]=identity(slot);os.link(slot,backup/role)
    saved=stack/'physical'/(cell+'-slots-premark.json')
    put(saved,{'slot_identity':slots,'source_sha256':sha(source),'source_mtime_ns':prior_stat.st_mtime_ns,'allocation_sha256':sha(a.allocation)})
    try:
        m.study(cell,plan,ids)
        subprocess.run([sys.executable,'-B',here/'verify.py',cell],check=True)
        results=here/'results'/cohort/cfg['control']
        complete=read(results/'complete.json');restore=read(results/'restore.json')
        assert complete['common_unchanged'] and restore['home_restored'] and restore['target_vacant']
        stored=read(here/'release-product-oracles'/(cohort+'.json'))
        allowed=set(plan['stock_path_bindings'][cohort]['allowed']);raw=canon=records=0
        for p in sorted(results.glob('*/receipt.json')):
            if not(p.parent.name.startswith(('admit-','pair-'))):continue
            r=read(p);ref=stored['sources'][r['source_sha256']]
            assert r['roster']==stored['roster'] and set(r['files'])==set(ref['files'])
            files_match(r['files'],ref['files'],allowed)
            raw+=sum(a['sha256']==ref['files'][key]['sha256'] for key,a in r['files'].items())
            canon+=len(ref['files']);records+=1
        assert records==20 and canon==1480
        put(results/'release-product-parity.json',{'actual_commands':records,'raw_file_equal':raw,'canonical_file_equal':canon,'old_oracle_sha256':sha(here/'release-product-oracles'/(cohort+'.json')),'registered_stock_paths':sorted(allowed)})
    finally:
        for role in ['cargo','wild']:
            slot=ro/'tools'/role;os.replace(backup/role,slot)
            assert identity(slot)==slots[role]
        backup.rmdir()
        restored={'slot_identity':{r:identity(ro/'tools'/r) for r in slots},'uv_source_sha256':sha(source),'before_source_mtime_ns':prior_stat.st_mtime_ns,
                  'after_source_mtime_ns':source.stat().st_mtime_ns,'visible_target_absent':not (ro/'target').exists()}
        put(stack/'physical'/(cell+'-slots-returned.json'),restored)
        assert restored['uv_source_sha256']==plan['uv_edit_preimage_sha256'] and prior_stat.st_mtime_ns==source.stat().st_mtime_ns and restored['visible_target_absent']
if __name__=='__main__':main()
