"""Package and replay the focused results without needing a linker, checkout, or compiler."""
from datetime import UTC,datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile
p=Path(__file__).resolve().parent;out=p/'compact-focused.zip';receipt=p/'compact-focused.json'
def read(f):return json.loads(f.read_text())
def sha(f):
 with f.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
assert read(p/'physical/build-focus-returned.json')['status']=='qualified' and read(p/'physical/build-focus-host-returned.json')['true_supervisor_absent']
files={p/name for name in ['plan.json','source.json','PROTOCOL.md','WINDOW.md','registration.sha256','implementation.json','implementation.sha256','binaries.json','focused-input-lock.json','owner-build-focus.json','verify-fresh.py','pack-focused.py','host-observer.py']}
files|={p/name for name in read(p/'implementation.json')['files']}
files|=set((p/'upstream').glob('*.json'))
for dirname in ['focused','physical','build-logs']:
 files|={q for q in (p/dirname).rglob('*') if q.is_file()}
for name in ['official-tests','fixture-results']:
 files|={q for q in (p/name).glob('*') if q.is_file() and q.suffix in {'.json','.log','.o'}}
with out.open('xb') as stream,zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
 for f in sorted(files):z.write(f,f.relative_to(p))
with tempfile.TemporaryDirectory(dir=p) as tmp,zipfile.ZipFile(out) as z:
 assert z.testzip() is None;z.extractall(tmp)
 root=Path(tmp);impl=read(root/'implementation.json')
 assert all(sha(root/name)==v for name,v in impl['files'].items())
 run=subprocess.run([sys.executable,'-I','-B',root/'verify-fresh.py','build-focus'],cwd=root,capture_output=True,text=True,check=True)
 audit=json.loads(run.stdout)
with receipt.open('x') as f:json.dump({'created':datetime.now(UTC).isoformat(),'sha256':sha(out),'bytes':out.stat().st_size,'files':len(files),'zip_crc':'passed','frozen_inputs':len(impl['files']),'standalone_python_replay':audit,'linker_binary_included':False,'native_wall_time_claim':False},f,indent=2);f.write('\n')
print(receipt.read_text())
