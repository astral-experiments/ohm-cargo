"""Build matched #46 and #46+#48 at a single private source path after an exclusive allocation."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
RELEASE=HERE.parent
WORK=RELEASE.parent

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def read(p):return json.loads(Path(p).read_text())

def put(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--allocation',type=Path,required=True)
    opts=ap.parse_args();allocation=read(opts.allocation);plan=read(HERE/'plan.json');digest=sha(HERE/'plan.json')
    assert digest==(HERE/'registration.sha256').read_text().split()[0]==allocation['plan_sha256']
    assert allocation['owner']=='/root' and allocation['phase']=='build-focus' and allocation['study']=='wild-eh-pr46-stack'
    assert len(os.sched_getaffinity(0))==4 and sorted(os.sched_getaffinity(0))==sorted(allocation['cpus'])
    assert shutil.disk_usage(HERE).free>=(130+allocation.get('other_reserved_gib',0))*2**30
    assert (RELEASE/'command/control/pause').is_file() and not (WORK/'round18-lab/host-cleared-for-native').exists()
    assert sha(HERE/'PROTOCOL.md')==plan['protocol_sha256'] and sha(HERE/'source.json')==plan['source_receipt_sha256']
    for path,expected in plan['source_references'].items():assert sha(WORK/path)==expected,path
    source=plan['source']; src=HERE/'src';bins=HERE/'bin';logs=HERE/'build-logs'
    src.mkdir();bins.mkdir();logs.mkdir();target=HERE/'build-target';target.mkdir()
    for name,attrs in source['archives'].items():assert sha(HERE/'source'/name)==attrs['sha256']
    with tarfile.open(HERE/'source/pr46.tar.gz') as t:t.extractall(src,filter='data')
    writer=src/'libwild/src/elf_writer.rs'
    assert sha(writer)==source['base_writer_sha256'] and sha(src/'Cargo.lock')==source['cargo_lock_sha256']
    env={k:v for k,v in os.environ.items() if not k.startswith(('OHM_','WILD_','CARGO_PROFILE_')) and k not in {'MFLAGS','MAKEFLAGS','CARGO_MAKEFLAGS','RUSTC','RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS','LD_PRELOAD'}}
    env.update(RUSTUP_TOOLCHAIN='stable',CARGO_HOME=str(WORK/'cargohome'),CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0')
    ready=plan['pr46_control']
    for name,expected in [('rustc',ready['compiler_sha256']),('cargo',ready['cargo_executable_sha256'])]:
        path=subprocess.check_output(['rustup','which','--toolchain','stable',name],text=True).strip()
        assert sha(path)==expected
    assert sha(WORK/'round18-linker/current-pr46/wild')==ready['binary_sha256']
    result={'plan_sha256':digest,'allocated':sha(opts.allocation),'build_command':ready['build_command'],'compiler_sha256':ready['compiler_sha256'],'cargo_sha256':ready['cargo_executable_sha256'],'lock_sha256':sha(src/'Cargo.lock'),'arms':{}}
    for arm in ('base','candidate'):
        if arm=='candidate':
            assert sha(HERE/'source/eh.patch')==source['patch_sha256']
            subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(HERE/'source/eh.patch')],cwd=src,check=True)
            assert sha(writer)==source['stacked_writer_sha256']
            subprocess.run(['cargo','+stable','clean','--release','--locked','--offline','-p','libwild','-p','wild-linker'],cwd=src,env=env,check=True)
        log=logs/(arm+'.log');start=time.time_ns()
        with log.open('xb') as f:proc=subprocess.run(ready['build_command'],cwd=src,env=env,stdout=f,stderr=f)
        assert proc.returncode==0,log
        rows=[json.loads(l) for l in log.read_text().splitlines() if l.startswith('{')]
        artifacts={x['target']['name']:x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name'] in {'libwild','wild','zstd','zstd_safe','zstd_sys'}}
        assert set(artifacts)=={'libwild','wild','zstd','zstd_safe','zstd_sys'}
        assert set(artifacts['libwild']['features'])=={'fork','libloading','plugins','wasm','zstd'}
        assert set(artifacts['wild']['features'])=={'default','fork','plugins','wasm','zstd'}
        assert not artifacts['libwild']['fresh'] and not artifacts['wild']['fresh']
        shutil.copy2(artifacts['wild']['executable'],bins/arm);(bins/arm).chmod(0o555)
        h=sha(bins/arm)
        assert (h==ready['binary_sha256'])==(arm=='base'),(arm,h,ready['binary_sha256'])
        result['arms'][arm]={'binary_sha256':h,'bytes':(bins/arm).stat().st_size,'log_sha256':sha(log),'start_ns':start,'end_ns':time.time_ns(),'fresh_local_crates':True,'writer_sha256':sha(writer),'features':artifacts['wild']['features']}
    assert sha(src/'Cargo.lock')==source['cargo_lock_sha256']
    put(HERE/'binaries.json',result)

if __name__=='__main__':main()
