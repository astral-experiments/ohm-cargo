"""Inventory exactly two rejected target banks. Removal requires a separate owner's receipt and a live recheck."""
from pathlib import Path
import argparse,collections,fcntl,hashlib,json,os,shutil,stat,time
D=Path(__file__).resolve().parent;S=D.parent;W=S.parent.parent
def rd(f):return json.loads(f.read_text())
def sha(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def put(f,data):
 with f.open('x') as out:json.dump(data,out,indent=2);out.write('\n')
def stat_id(q):
 s=q.stat();return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns}
def inventory(roots):
    union={};stores={}
    for r in roots:
        digest=hashlib.sha256();files=0;dir_allocated=0
        def visit(d):
            nonlocal files,dir_allocated
            with os.scandir(d) as iterator:entries=sorted(iterator,key=lambda e:e.name)
            for item in entries:
                path=Path(item.path);s=item.stat(follow_symlinks=False);key=(s.st_dev,s.st_ino);files+=1
                data=json.dumps([str(path.relative_to(r)),s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_nlink,s.st_blocks,os.readlink(path) if stat.S_ISLNK(s.st_mode) else None],separators=(',',':')).encode();digest.update(data+b'\n')
                if stat.S_ISDIR(s.st_mode):dir_allocated+=s.st_blocks*512;visit(path)
                else:
                    row=union.setdefault(key,[s.st_nlink,s.st_blocks,0]);assert row[:2]==[s.st_nlink,s.st_blocks];row[2]+=1
        visit(r);stores[r.name]={'root':str(r),'root_identity':stat_id(r),'entries':files,'metadata_sha256':digest.hexdigest(),'directory_bytes_excluding_root':dir_allocated}
    freeable=sum(blocks*512 for count,blocks,inside in union.values() if inside==count)+sum(r['directory_bytes_excluding_root'] for r in stores.values())
    held=sum(blocks*512 for count,blocks,inside in union.values() if inside<count)
    return {'banks':stores,'estimated_reclaimable_allocated_bytes':freeable,'allocated_bytes_with_external_hardlinks':held,'method':'Allocated filesystem blocks summed once per nondirectory inode with all links inside the two banks; directory blocks exclude the two root dirs. Open descriptors or filesystem compression can affect actual free space.'}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--apply-allocation',type=Path);a=ap.parse_args()
 bench=Path((W/'bench-home.path').read_text().strip());root=bench/'release-eh-roles-18/initial';diag=rd(D/'diagnosis.json');paths=[root/'rejected-initial-base-structural',root/'rejected-initial-base-target']
 assert set(diag['two_rejected_banks'])=={q.name for q in paths} and rd(S/'physical/initial-base-host-returned.json')['true_supervisor_absent']
 assert sha(root/'common-ready.json')==diag['common']['ready_sha256'] and stat_id(root/'common')==diag['common']['identity']
 assert (S/'command-v2').exists() and not (root/'target').exists() and not (root/'structural').exists() and not list(root.glob('held-*'))
 for k,v in diag['new_products'].items():
  retained=D/v['retained_path'];assert os.path.samefile(retained,paths[1]/k) and stat_id(retained)==v['held_original_inode']
 for q in paths:assert q.parent==root and q.resolve()==q and not q.is_symlink() and stat_id(q)==diag['two_rejected_banks'][q.name]['identity']
 record=inventory(paths)
 frozen=D/'bank-retirement.json'
 if a.apply_allocation is None:
  assert not frozen.exists()
  put(frozen,{'diagnosis_sha256':sha(D/'diagnosis.json'),'retained_elf_bytes':diag['retained_bytes'],'before_free_bytes':shutil.disk_usage(root).free,'inventory':record,'allowed_paths':[str(q) for q in paths],'script_sha256':sha(Path(__file__))})
  print(sha(frozen),record['estimated_reclaimable_allocated_bytes'],record['allocated_bytes_with_external_hardlinks']);return
 g=rd(a.apply_allocation);assert g['owner']=='/root' and g['study']=='wild-eh-pr46-stack' and g['phase']=='retire-two-rejected-banks' and g['retirement_sha256']==sha(frozen)
 assert Path('/proc/1/comm').read_text().strip()=='systemd' and g['host_boot_id']==Path('/proc/sys/kernel/random/boot_id').read_text().strip()
 old=rd(frozen);assert old['script_sha256']==sha(Path(__file__)) and old['diagnosis_sha256']==sha(D/'diagnosis.json') and old['allowed_paths']==[str(q) for q in paths] and old['inventory']==record
 with (bench/'round18/native-lease').open('r') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (root/'target').exists() and not any(root.glob('held-*')) and not (D/'banks-retired.json').exists()
  before=shutil.disk_usage(root).free
  for q in paths:
   assert not q.is_symlink() and stat_id(q)==old['inventory']['banks'][q.name]['root_identity'];shutil.rmtree(q)
  assert all(not q.exists() for q in paths);assert stat_id(root/'common')==diag['common']['identity'] and sha(root/'common-ready.json')==diag['common']['ready_sha256']
  for k,v in diag['new_products'].items():assert stat_id(D/v['retained_path'])==v['held_original_inode'] and sha(D/v['retained_path'])==v['reconstructed']['actual']
  after=shutil.disk_usage(root).free
  put(D/'banks-retired.json',{'retirement_sha256':sha(frozen),'grant_sha256':sha(a.apply_allocation),'deleted_exactly':old['allowed_paths'],'free_before':before,'free_after':after,'actual_free_change':after-before,'original_seeds_unchanged':True,'both_retained_elf_sha256_verified':True,'ended_ns':time.time_ns()})
  print(sha(D/'banks-retired.json'),after-before)
if __name__=='__main__':main()
