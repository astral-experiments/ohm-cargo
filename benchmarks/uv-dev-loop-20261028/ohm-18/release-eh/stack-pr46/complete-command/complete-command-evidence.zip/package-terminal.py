"""Package a terminal positive or statistical null across the registered command gates."""
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
S=Path(__file__).resolve().parent;E=S.parent;W=E.parent
def read(f):return json.loads(f.read_text())
def sha(f):
 with f.open('rb') as i:return hashlib.file_digest(i,'sha256').hexdigest()
def dump(f,x):
 if f.exists():assert read(f)==x;return
 with f.open('x') as out:json.dump(x,out,indent=2);out.write('\n')
def main():
 assert __debug__;p=read(S/'plan.json');cohorts=[];results={};artifact_counts={}
 for key in p['macro_cell_order']:
  if cohorts and not results[cohorts[-1]]['qualified']:break
  physical=S/'physical-v2';term=read(physical/(key+'-returned.json'));host=read(physical/(key+'-host-returned.json'));tool=read(physical/(key+'-tool-return.json'))
  assert term['status'] in {'qualified','inconclusive'} and host['true_supervisor_absent'] and not host['workers_on_granted_cpus'] and tool['supervisor']['exit']==0 and tool['host_observer']['exit']==0
  c=p['macro_cohorts'][key];o=S/'command-v2/results'/c['cohort']/c['control'];summary=read(o/'summary.json')
  assert summary['qualified']==(term['status']=='qualified')
  rows=list(csv.DictReader((o/'samples.csv').open()));assert len(rows)==16
  raw=canonical=0;raw_paths={}
  for i in range(8):
   x,y=[read(o/r['receipt'])['files'] for r in rows[2*i:2*i+2]]
   for n,a in x.items():
    b=y[n];assert a['size']==b['size'] and a['canonical_sha256']==b['canonical_sha256'];canonical+=1
    if a['sha256']==b['sha256']:raw+=1
    else:raw_paths[n]=raw_paths.get(n,0)+1
  artifact_counts[key]={'within_scored_pairs_raw_equal':raw,'within_scored_pairs_canonical_equal':canonical,'raw_differences_by_stock_reproduced_path':raw_paths,**read(o/'release-product-parity.json')}
  cohorts.append(key);results[key]=summary
 assert cohorts and (len(cohorts)==2 or not results[cohorts[-1]]['qualified'])
 terminal={'plan_sha256':sha(S/'plan.json'),'recovery_sha256':sha(S/'recovery/registration.json'),'phases':cohorts,'results':results,'all_required_cells_qualified':len(cohorts)==2 and all(r['qualified'] for r in results.values()),'product_counts':artifact_counts,'endpoint':'instructions in the actual distributed -18 Cargo plus all six rustc and five Wild processes in an edited cargo test --no-run -j8. No elapsed-time inference.'}
 dump(S/'terminal.json',terminal)
 lines=['# Wild #48 measured directly on Wild #46','','Run the following command in the extracted archive using Python 3.11 or newer.','','    python3 -I -B verify-complete.py','','The verifier checks the manifest, reconstructs both Git source trees, hashes both measured linker binaries, replays the frozen focused and complete-command scores and checks the native exec records. It verifies the prior stock controls and reconstructs both historical raw ELF digests from the actual rejected admission’s retained products.','','## Complete edited Cargo commands','','Every command built tests without executing them. Each fixture uses distributed Ohm -18 Cargo plus rustc and counts every instruction across one Cargo, six rustc and five Wild processes. Both arms emit the same 72 named tests. The source-edit fixtures, each with eight balanced pairs, were registered before their first performance sample. These records measure instructions.','','| Edited uv fixture | Median saving | Winning pairs | Two-sided sign P | Balanced-order P | Raw paired matches | Canonical paired matches |','|---|---:|---:|---:|---:|---:|---:|']
 for key in cohorts:
  v=results[key];ac=artifact_counts[key];lines.append(f'| {key} | {v["median_improvement_pct"]:.6f}% | {v["wins"]}/8 | {v["two_sided_paired_sign_p"]:.7f} | {v["two_sided_balanced_order_p"]:.7f} | {ac["within_scored_pairs_raw_equal"]}/592 | {ac["within_scored_pairs_canonical_equal"]}/592 |')
 lines+=['','The only permitted raw variation is the previously stock-reproduced 0/8 ELF section-header byte and its 32-byte dependent GNU build ID at the same offsets. Each command also compares all 74 products with the earlier exact per-edit release oracle. The first fixture’s superseded native-only admission and the narrowly corrected JSON reader are preserved under recovery/.','','## Focused checks','','The two captured single-worker links saved a median 0.318124% and 0.673998% of instructions. All eight pairs improved for each input. Every scored linked file matched the registered raw SHA-256. The candidate passed 184 libwild unit tests, seven native integration cases across six groups and five normal/malformed ELF probes. The tiny third link has one descriptive pair and no statistical gate.','','## Files','','Both measured executables are under bin/. The two source archives and the exact one-file patch are under source/. compact-focused.zip contains compilation logs, official QA and raw captured-link counts. command-v2/results contains the corrected command cohorts, raw argv, full per-thread counters, product hashes and native strace files. release-evidence contains the stock path proof, earlier per-edit reference receipts and their membership in the release evidence manifest. capture-inputs gives the large captured inputs’ identity and argv for recapture. The complete captured object files and 72 emitted uv test binaries are represented by digests. The two actual ELFs used to diagnose the superseded admission are included under recovery/products/.']
 note=S/'FINAL-EVIDENCE.md';body='\n'.join(lines)+'\n'
 if note.exists():assert note.read_text()==body
 else:note.write_text(body)
 files=set()
 def add(f,as_name=None):
  assert f.is_file();n=as_name or str(f.relative_to(S));assert not Path(n).is_absolute() and '..' not in Path(n).parts
  files.add((n,f))
 for f in [S/n for n in read(S/'implementation.json')['files']]:add(f)
 for f in [S/n for n in read(S/'recovery/registration.json')['new_files']]:add(f)
 for n in ['registration.sha256','implementation.json','implementation.sha256','source.json','binaries.json','focused-input-lock.json','compact-focused.zip','compact-focused.json','bin/base','bin/candidate','verify-complete.py','pack-focused.py','package-terminal.py','terminal.json',
           'host-obser'+'ver.py','host-observe-command.py','recovery/registration.json','recovery/registration.sha256','recovery/bank-retirement.json','recovery/retirement.py']:
  add(S/n)
 for pattern in ['owner-*.json','upstream/*.json','physical/*','physical-v2/*','recovery/products/*']:
  for f in S.glob(pattern):
   if f.is_file():add(f)
 for root in ['command/results','command-v2/results','command/calibration','command-v2/calibration']:
  for f in (S/root).rglob('*'):
   if f.is_file():add(f)
 for f in [S/'recovery/banks-retired.json',S/'recovery/RETIREMENT.md',S/'recovery/READER.md',S/'FINAL-EVIDENCE.md']:
  if f.is_file():add(f)
 for n in ['compact-complete-command.json','compact-stock-registration.json','compact-stock-registration.zip']:
  add(E/n,'release-evidence/'+n)
 for k in ['0','1','2']:add(W/'round18-linker/confirm18'/('argv-'+k+'.json'),'capture-inputs/argv-'+k+'.json')
 add(W/'round18-linker/confirm18/inputs.json','capture-inputs/manifest.json');add(W/'round18-linker/captures18/audit.json','capture-inputs/audit.json')
 extra={}
 with zipfile.ZipFile(E/'compact-complete-command.zip') as z:
  assert sha(E/'compact-complete-command.zip')==p['retained_release_packet_sha256']
  extra['release-evidence/complete-manifest.sha256']=z.read('MANIFEST.sha256')
  oldindex={n:h for h,n in (l.split('  ',1) for l in extra['release-evidence/complete-manifest.sha256'].decode().splitlines())}
  refs={}
  for k in p['macro_cell_order']:
   c=p['macro_cohorts'][k]['cohort'];prior=E/'command-v2/results'/c/'base';ref=read(S/'command/release-product-oracles'/(c+'.json'));refs[c]={}
   native=next(i for i,(mode,arm) in enumerate(p['macro_cohorts'][k]['native_count_admission']) if (mode,arm)==('native','base'))
   idx={'1':prior/f'admit-{native}-native-base'/'receipt.json',**{r['id']:prior/r['receipt'] for r in csv.DictReader((prior/'samples.csv').open()) if r['arm']=='base'}}
   for edit,path in idx.items():
    key=str(path.relative_to(E));b=z.read(key);assert b==path.read_bytes() and hashlib.sha256(b).hexdigest()==oldindex[key]==ref['sources'][p['macro_cohorts'][k]['edits'][edit]]['prior_receipt_sha256']
    extra['release-evidence/'+c+'/'+edit+'.json']=b;refs[c][edit]=key
  extra['release-evidence/reference-index.json']=(json.dumps(refs,indent=2)+'\n').encode()
 extra['support/uv-edit-original.rs']=subprocess.check_output(['git','-C',W/'uv','show',p['uv']+':'+p['uv_edit_file']])
 assert hashlib.sha256(extra['support/uv-edit-original.rs']).hexdigest()==p['uv_edit_preimage_sha256']
 out=S/'compact-complete-command.zip';assert not out.exists();tmpzip=S/('packing-'+str(time.time_ns())+'.zip');manifest={}
 with tmpzip.open('xb') as archive,zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
  for name,f in sorted(files):
   assert name not in manifest;method=zipfile.ZIP_LZMA if name.startswith('recovery/products/') else zipfile.ZIP_DEFLATED
   z.write(f,name,compress_type=method);manifest[name]=sha(f)
  for name,b in sorted(extra.items()):
   assert name not in manifest;z.writestr(name,b);manifest[name]=hashlib.sha256(b).hexdigest()
  z.writestr('MANIFEST.sha256',''.join(h+'  '+n+'\n' for n,h in sorted(manifest.items())))
 with tempfile.TemporaryDirectory(dir=S) as tmp:
  with zipfile.ZipFile(tmpzip) as z:assert z.testzip() is None;z.extractall(tmp)
  root=Path(tmp);v=json.loads(subprocess.check_output([sys.executable,'-I','-B',root/'verify-complete.py'],cwd=root))
 assert not out.exists();tmpzip.rename(out)
 dump(S/'compact-complete-command.json',{'sha256':sha(out),'bytes':out.stat().st_size,'files_excluding_manifest':len(manifest),'contains_full_rejected_native_elfs':2,'contains_stacked_and_matched_linkers':True,'nested_confirmed_focused_sha256':sha(S/'compact-focused.zip'),'offline_verified':v})
 print('validated',len(manifest),'members',out.stat().st_size,'bytes',sha(out))
if __name__=='__main__':main()
