"""Offline verification of sources, binaries, fork accounting, artifacts, controls and both independent decisions."""
import collections
import csv
import hashlib
import io
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile
import zipfile
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def github_object(typ,body):
    return hashlib.sha1(typ+b' '+str(len(body)).encode()+b'\0'+body).digest()
def git_tree(archive):
    # Git archives materialize these three immutable repository gitlinks as empty directories.
    gitlinks={'external_test_suites/lld':'3b0540e63b01f00de1ee4119ce5507a2bbd8a1b6','external_test_suites/mold':'3eca43961ddc8a5f6c670358cda2be8d326a5f96','wild/tests/bins':'6b9fe565a88a19d8d0b8c52eae9eb8c443872aa4'}
    paths={};contents={}
    with tarfile.open(archive) as t:
        for m in t:
            n=m.name.rstrip('/');assert not n.startswith('/') and '..' not in Path(n).parts
            if n in gitlinks:assert m.isdir();paths[n]=(b'160000',bytes.fromhex(gitlinks[n]));continue
            if m.isdir():continue
            if m.issym():mode=b'120000';data=m.linkname.encode()
            else:assert m.isfile();mode=b'100755' if m.mode&0o111 else b'100644';data=t.extractfile(m).read()
            paths[n]=(mode,github_object(b'blob',data))
            if n in ['Cargo.lock','libwild/src/elf_writer.rs']:contents[n]=hashlib.sha256(data).hexdigest()
    nodes={}
    for n,id_ in paths.items():
        t=nodes;objects=n.split('/')
        for name in objects[:-1]:t=t.setdefault(name,{})
        assert objects[-1] not in t;t[objects[-1]]=id_
    def walk(d):
        body=bytearray()
        for k,v in sorted(d.items(),key=lambda kv:kv[0].encode()+(b'/' if isinstance(kv[1],dict) else b'')):
            mode,obj=(b'40000',walk(v)) if isinstance(v,dict) else v;body.extend(mode+b' '+k.encode()+b'\0'+obj)
        return github_object(b'tree',body)
    return walk(nodes).hex(),paths,contents
def safe_extract(archive,d):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None;names=z.namelist()
        assert len(names)==len(set(names)) and all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        z.extractall(d)
def native_roster(out):
    seen=collections.Counter()
    for f in out.glob('exec.*'):
        for line in f.read_text().splitlines():
            if not re.search(r'= 0$',line):continue
            m=re.match(r'^execve\("([^"\\]+)",',line);assert m,line[:160];seen[m[1]]+=1
    assert dict(seen)==read(out/'native-execs.json')
    roles={}
    for k,num in {'cargo':1,'rustc':6,'wild':5}.items():
        records=[read(f) for f in out.glob(k+'-*.json')];assert len(records)==num and len({r['executable'] for r in records})==1
        exe=records[0]['executable'];roles[k]=exe;assert seen[exe]==num
    wrapper=Path(roles['cargo']).parent/'linker/ld.bfd'
    assert seen[str(wrapper)]==5
    allowed=set(roles.values())|{str(wrapper)}
    assert all(Path(k).name not in {'cargo','rustc','wild','wild-ld','ld.bfd','ld','ld.lld','rust-lld'} or k in allowed for k in seen)
def verify():
    manifests=(ROOT/'MANIFEST.sha256').read_text().splitlines();names=set()
    for line in manifests:
        value,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts and name not in names
        names.add(name);assert sha(ROOT/name)==value,name
    assert names=={str(q.relative_to(ROOT)) for q in ROOT.rglob('*') if q.is_file() and q!=ROOT/'MANIFEST.sha256'}
    plan=read(ROOT/'plan.json');ph=sha(ROOT/'plan.json');assert ph==(ROOT/'registration.sha256').read_text().split()[0]=='a1428428f46dd140c7a93d71ebe4207cfb5a9e013e6fd576ac852342a35d48ed'
    impl=read(ROOT/'implementation.json');assert impl['plan_sha256']==ph and sha(ROOT/'implementation.json')=='c5a10df57657cf2acfbd541b987c0155e62b2753e2547ed525afcc9646d8c1cb'
    assert all(sha(ROOT/n)==value for n,value in impl['files'].items())
    a,base,files0=git_tree(ROOT/'source/pr46.tar.gz');b,cand,files1=git_tree(ROOT/'source/pr46-plus-pr48.tar.gz');source=plan['source']
    assert a==source['base_tree'] and b==source['stacked_tree'] and set(base)==set(cand)
    assert [k for k in sorted(base) if base[k]!=cand[k]]==['libwild/src/elf_writer.rs']
    assert files0['Cargo.lock']==files1['Cargo.lock']==source['cargo_lock_sha256']
    assert files0['libwild/src/elf_writer.rs']==source['base_writer_sha256'] and files1['libwild/src/elf_writer.rs']==source['stacked_writer_sha256']
    binaries=read(ROOT/'binaries.json');assert binaries['arms']['base']['binary_sha256']==plan['pr46_control']['binary_sha256']
    for role in ['base','candidate']:assert sha(ROOT/'bin'/role)==binaries['arms'][role]['binary_sha256']
    focus=ROOT/'compact-focused.zip';assert sha(focus)==read(ROOT/'compact-focused.json')['sha256']=='bfea34688b16039088d9244b3066191bea4f5dadf6fdd3eca30b5c0c37543711'
    result={'source_trees':[a,b],'wild_binaries':{k:v['binary_sha256'] for k,v in binaries['arms'].items()},'cells':{},'verified_files':len(names)}
    with tempfile.TemporaryDirectory() as tmp:
        t=Path(tmp);f=t/'focus';stock=t/'stock';safe_extract(focus,f)
        assert sha(f/'binaries.json')==sha(ROOT/'binaries.json') and sha(f/'plan.json')==ph
        result['focused']=json.loads(subprocess.check_output([sys.executable,'-I','-B',f/'verify-fresh.py','build-focus'],cwd=f))
        tiny=plan['tiny_descriptive_control'];tiny_rows=read(f/'focused/tiny.json');assert [r['arm'] for r in tiny_rows]==tiny['order']
        for j,row in enumerate(tiny_rows):
            tag=f"tiny-{tiny['capture']}-00-{j}-{row['arm']}";raw=f/'focused/raw'
            assert not (raw/(tag+'.stdout')).read_bytes() and row['sha256']==plan['captures'][tiny['capture']]['one_worker_file_sha256']
            before,sep,last=(raw/(tag+'.stderr')).read_bytes().rpartition(b'DynamoRIO ');assert sep and not before
            counter=json.loads(last);assert row['instructions']==counter['instructions']==sum(counter['threads'].values())>0 and str(counter['pid']) in counter['threads']
        result['descriptive_tiny_instructions']={r['arm']:r['instructions'] for r in tiny_rows}
        assert all(sha(ROOT/'capture-inputs'/('argv-'+k+'.json'))==v['argv']['recorded'] for k,v in plan['captures'].items())

        stockzip=ROOT/'release-evidence/compact-stock-registration.zip';assert sha(stockzip)==read(ROOT/'release-evidence/compact-stock-registration.json')['sha256']=='839f0365fce2b9a57170f64b599d008957dba035e86fe259eef0c6e02c9a237b'
        safe_extract(stockzip,stock);subprocess.run([sys.executable,'-I','-B',stock/'command-v2/verify-stock.py'],cwd=stock,stdout=subprocess.DEVNULL,check=True)
        release_filemap={n:h for h,n in (line.split('  ',1) for line in (ROOT/'release-evidence/complete-manifest.sha256').read_text().splitlines())}
        historical=read(ROOT/'release-evidence/compact-complete-command.json');assert historical['sha256']==plan['retained_release_packet_sha256']
        for co in ('initial','replica'):
            q=ROOT/'command/release-product-oracles'/(co+'.json');oracle=read(q)
            assert sha(stock/'command-v2/stock'/co/'binding.json')==sha(ROOT/'command/stock'/co/'binding.json')==plan['stock_path_bindings'][co]['proof_sha256']
            for v in oracle['sources'].values():
                old=ROOT/'release-evidence'/co/(v['edit']+'.json');index=read(ROOT/'release-evidence/reference-index.json')
                assert sha(old)==release_filemap[index[co][v['edit']]]==v['prior_receipt_sha256'];prior=read(old)
                assert prior['files']==v['files'] and prior['roster']==oracle['roster']
    recovered=read(ROOT/'recovery/registration.json')
    assert sha(ROOT/'recovery/registration.json')=='8d33ecbb8c695859e848f30d20ee70ef8d3812796bfcfeaea0d743bd0e204158' and recovered['original_plan_sha256']==ph
    assert recovered['unchanged_macro_cohorts']==plan['macro_cohorts'] and recovered['stock_path_bindings']==plan['stock_path_bindings']
    assert all(sha(ROOT/n)==v for n,v in recovered['new_files'].items())
    assert sha(ROOT/'command/verify.py')==sha(ROOT/'command-v2/verify.py')
    assert sha(ROOT/'physical/initial-base-returned.json')==recovered['unchanged_failed_return_sha256']
    fault=read(ROOT/'physical/initial-base-returned.json');obs=read(ROOT/'physical/initial-base-host-returned.json');session=read(ROOT/'physical/initial-base-tool-return.json')
    assert fault['status']=='rejected' and obs['true_supervisor_absent'] and not obs['workers_on_granted_cpus'] and session['supervisor']['exit']==1 and session['host_observer']['exit']==0
    failed=ROOT/'command/results/initial/base';admit=failed/'admit-0-native-candidate'
    assert not (failed/'samples.csv').exists() and not list(failed.glob('pair-*')) and list(failed.glob('admit-*'))==[admit]
    di=read(ROOT/'recovery/diagnosis.json');rr=read(admit/'receipt.json');oracle=read(ROOT/'command/release-product-oracles/initial.json')
    observed=rr['files'];expected=oracle['sources'][rr['source_sha256']]['files'];assert sha(admit/'receipt.json')==di['native_receipt_sha256']
    assert rr['roster']==oracle['roster'] and len(observed)==len(expected)==74
    sys.path.insert(0,str(ROOT/'command'));from verify import files_match
    allowed=set(plan['stock_path_bindings']['initial']['allowed']);files_match(observed,expected,allowed)
    mixed=json.loads(json.dumps(observed))
    for meta in mixed.values():
        if meta['permitted_fields']:meta['permitted_fields']={k:tuple(v) for k,v in meta['permitted_fields'].items()}
    try:files_match(mixed,expected,allowed)
    except AssertionError:pass
    else:raise AssertionError('original false negative not reproduced')
    native_roster(admit)
    assert all('instructions' not in read(f) and 'threads' not in read(f) for d in [admit,failed/'structural',failed/'fresh'] for k in ('cargo','rustc','wild') for f in d.glob(k+'-*.json'))
    spec=importlib.util.spec_from_file_location('old_rejected_elf',ROOT/'recovery/diagnose.py');dm=importlib.util.module_from_spec(spec);spec.loader.exec_module(dm)
    for n,info in di['new_products'].items():
        kept=ROOT/'recovery'/info['retained_path'];recovered_elf=dm.replay_file(kept,expected[n],observed[n])
        assert all(info[k]==v for k,v in recovered_elf.items())
    result['original_rejection']={'actual_counted_candidate_commands':0,'scored_rows':0,'raw_equal':72,'canonical_equal':74,'stock_variants_reconstructed_from_full_actual_elfs':2}
    original=(ROOT/'support/uv-edit-original.rs').read_bytes();assert hashlib.sha256(original).hexdigest()==plan['uv_edit_preimage_sha256']
    needle=b'component == cellar && next == formula';assert original.count(needle)==1
    for cfg in plan['macro_cohorts'].values():
        for idx,v in cfg['edits'].items():
            pattern=('{\n                component == cellar && (next == formula || next == OsStr::new('+f'"uv-eh-{cfg["literal_family"]}{int(idx):02d}"))\n            }}').encode()
            assert hashlib.sha256(original.replace(needle,pattern)).hexdigest()==v
    terminal=read(ROOT/'terminal.json');assert terminal['plan_sha256']==ph and terminal['phases']==plan['macro_cell_order'][:len(terminal['phases'])]
    assert terminal['phases'] and (len(terminal['phases'])==2 or not terminal['results'][terminal['phases'][-1]]['qualified'])
    assert all(terminal['results'][k]['qualified'] for k in terminal['phases'][:-1])
    for phase in ['build-focus',*terminal['phases']]:
        physical=ROOT/('physical' if phase=='build-focus' else 'physical-v2')
        host=read(physical/(phase+'-host-returned.json'));r=read(physical/(phase+'-returned.json'));tool=read(physical/(phase+'-tool-return.json'))
        assert host['true_supervisor_absent'] and host['workers_on_granted_cpus']==[] and not r['remaining_on_granted_cpus'] and r['all_children_returned'] and all(x['returncode']==0 for x in r['children']) and r['minimum_observed_free']>=r['floor_gib']*2**30
        assert tool['supervisor']['exit']==tool['host_observer']['exit']==0 and sha(physical/(phase+'-returned.json'))==tool['physical_return_sha256'] and sha(physical/(phase+'-host-returned.json'))==tool['guest_return_sha256']
        if phase=='build-focus':assert r['status']=='qualified';continue
        cohort=plan['macro_cohorts'][phase]['cohort'];out=ROOT/'command-v2/results'/cohort/'base'
        subprocess.run([sys.executable,'-I','-B',ROOT/'verify-fresh-v2.py',phase],cwd=ROOT,stdout=subprocess.DEVNULL,check=True)
        s=read(out/'summary.json');assert (r['status']=='qualified')==s['qualified']
        assert terminal['results'][phase]==s
        for d in out.glob('admit-*-native-*'):native_roster(d)
        marker=read(physical/(phase+'-slots-premark.json'));after=read(physical/(phase+'-slots-returned.json'))
        assert marker['slot_identity']==after['slot_identity'] and marker['source_sha256']==after['uv_source_sha256']==plan['uv_edit_preimage_sha256']
        assert marker['source_mtime_ns']==after['before_source_mtime_ns']==after['after_source_mtime_ns'] and after['visible_target_absent']
        calibration=read(ROOT/'command-v2/calibration'/phase/'PASS.json')
        for role,n in [('cargo',1),('rustc',1),('wild',2)]:
            assert abs(calibration['count-high'][role]-calibration['count-low'][role]-n*1600000)<=4096
            assert abs(calibration['count-outside'][role]-calibration['count-low'][role])<=4096
        start=read(physical/(phase+'-started.json'));assert Path(start['grant_file']).name==start['grant_file']
        owner=ROOT/start['grant_file'];grant=read(owner)
        assert grant['owner']=='/root' and grant['phase']==phase and grant['plan_sha256']==ph and grant['recovery_sha256']==sha(ROOT/'recovery/registration.json')
        assert sha(owner)==start['grant_sha256'] and sha(physical/(phase+'-started.json'))==r['start_receipt_sha256'] and start['cpus']==grant['cpus'] and start['host_boot_id']==grant['host_boot_id']==host['guest_boot_id']
        rows=list(csv.DictReader((out/'samples.csv').open()));raw=canon=0;paths=collections.Counter()
        for i in range(8):
            left,right=[read(out/row['receipt'])['files'] for row in rows[2*i:2*i+2]]
            for path,v in left.items():
                assert v['size']==right[path]['size'] and v['canonical_sha256']==right[path]['canonical_sha256'];canon+=1
                if v['sha256']==right[path]['sha256']:raw+=1
                else:paths[path]+=1
        c=terminal['product_counts'][phase]
        assert c=={'within_scored_pairs_raw_equal':raw,'within_scored_pairs_canonical_equal':canon,'raw_differences_by_stock_reproduced_path':dict(paths),**read(out/'release-product-parity.json')}
        result['cells'][phase]={'median_pct':s['median_improvement_pct'],'sign_p':s['two_sided_paired_sign_p'],'order_p':s['two_sided_balanced_order_p'],
                               'wins':s['wins'],'test_products':s['unique_test_executables'],'roles':s['role_counts'],'stock_release_product_parity':read(out/'release-product-parity.json')}
    result['all_required_cells_qualified']=all(v['qualified'] for v in terminal['results'].values());assert result['all_required_cells_qualified']==terminal['all_required_cells_qualified']
    return result
if __name__=='__main__':assert __debug__;print(json.dumps(verify(),indent=2))
