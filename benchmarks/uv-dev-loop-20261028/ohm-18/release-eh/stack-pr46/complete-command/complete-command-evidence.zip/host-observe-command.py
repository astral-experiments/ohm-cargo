"""Read-only guest-level custody for the already running frozen supervisor, plus its true host PIDs."""
from pathlib import Path
import sys
import json,os,time
p=Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in {'initial-base','replica-base'}
start=p/'physical'/(phase+'-started.json');end=p/'physical'/(phase+'-returned.json')
receipt=json.loads(start.read_text());cpus=set(receipt['cpus']);boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot==receipt['host_boot_id'] and Path('/proc/1/comm').read_text().strip()=='systemd'
def sample():
 rows=[];own_sup=[];heavy=[]
 for q in Path('/proc').iterdir():
  if not q.name.isdigit():continue
  try:
   pid=int(q.name);comm=(q/'comm').read_text().strip();args=(q/'cmdline').read_bytes().decode(errors='replace').split('\0');exe=os.readlink(q/'exe')
   affinity=set(os.sched_getaffinity(pid));status={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in (q/'status').read_text().splitlines() if ':' in x}
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
  if p.name+'/phase.py' in ' '.join(args) and comm.startswith('python'):
   own_sup.append(pid)
  if (comm in {'cargo','rustc','wild','ld.bfd','drrun','as','cc1','collect2','ld'} or exe.endswith(('/cargo','/rustc','/wild','/ld.bfd','/drrun'))) and cpus.intersection(affinity):
   row={'pid':pid,'ppid':int(status['PPid']),'comm':comm,'cpus':sorted(affinity),'namespace':status['NSpid'],'arg0':args[0]};heavy.append(row)
  if (comm.startswith('python') and ('stack-pr46/phase.py' in ' '.join(args) or 'stack-pr46/command/cell.py' in ' '.join(args))):
   rows.append({'pid':pid,'ppid':int(status['PPid']),'comm':comm,'cpus':sorted(affinity),'namespace':status['NSpid'],'argv':args[:-1]})
 return own_sup,rows,heavy
os.sched_setaffinity(0,{26});out=p/'physical'/(phase+'-host-observer.jsonl');first=True;prior=None
with out.open('x') as f:
 while True:
  own,rows,heavy=sample();record={'ns':time.time_ns(),'supervisor_pids':own,'supervisors':rows,'workers':heavy,'guest_boot_id':boot};key=(tuple(own),tuple((v['pid'],v['comm']) for v in heavy))
  if key!=prior or first:print(json.dumps(record),file=f,flush=True);prior=key;first=False
  if end.exists() and not own:break
  time.sleep(2)
with (p/'physical'/(phase+'-host-returned.json')).open('x') as f:json.dump({'guest_boot_id':boot,'true_supervisor_absent':not own,'workers_on_granted_cpus':heavy,'observed_ns':time.time_ns(),'log':out.name},f,indent=2)
