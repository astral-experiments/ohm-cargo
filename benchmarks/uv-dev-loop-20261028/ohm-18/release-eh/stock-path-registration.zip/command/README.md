# Conditional complete edited-command study

These commands require the registered focused entry gate to have passed and a separate eight-CPU allocation. The allocation JSON includes `eh-complete-command` in its task list plus the exact eight `cpus`, `released_utc` and outer `plan_sha256`. Source, timer fixtures and tool slots from the other studies remain separate. The initial cold build creates a new private checkout and target for each cohort under the task benchmark scratch root. It checks that a second untouched command is fresh before it snapshots that cohort’s pristine target.

```sh
script=work/round18-eh-release/command/run.py
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" seal --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" calibrate --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" warm initial --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" study initial-base --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" study initial-shipped --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" warm replica --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" study replica-base --allocation "$ALLOCATION"
taskset -c "$ALLOCATED_CPUS" python3 -B "$script" study replica-shipped --allocation "$ALLOCATION"
```

Each cell checks the preceding cells before it starts. Preserve the first valid ineligible result. To recheck a completed cell from the saved receipts, run `python3 verify.py initial-base` (or its exact registered cell ID). The verifier reads the raw per-role process records, checks the full eight pairs, arm orders, source hashes, rosters and artifact digests, enumerates all 70 balanced order assignments, and verifies source/target/home restoration. Its only dependencies are Python’s standard library and the study receipts. The emitted binary files themselves stay in private benchmark scratch.
