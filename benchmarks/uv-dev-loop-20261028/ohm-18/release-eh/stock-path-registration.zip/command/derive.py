"""Specialize the previously calibrated two-arm harness for this independent, test-only Wild study."""
import ast
import hashlib
import json
from pathlib import Path

here=Path(__file__).resolve().parent
work=here.parents[1]
src=work/'round18-cargo/edited-roles/run.py'
expected=json.loads((here.parent/'plan.json').read_text())['support_sha256'][str(src.relative_to(work))]
assert hashlib.sha256(src.read_bytes()).hexdigest()==expected
s=src.read_text()

def section(start,end,new):
    global s
    lo=s.index('def '+start+'('); hi=s.index('def '+end+'(',lo)
    s=s[:lo]+new.strip()+'\n\n'+s[hi:]

s=s.replace('sys.path.insert(0, str(WORK / "tree-count"))\nfrom identical import audit_native','from trace import audit_native\nfrom elf_equivalence import uv_elf')
section('checked_plan','clone','''
def checked_plan(allocation):
    p=read(OUTER/'plan.json')
    digest=sha(OUTER/'plan.json')
    need(digest==(OUTER/'registration.sha256').read_text().split()[0] and sha(OUTER/'PROTOCOL.md')==p['protocol_sha256'],'outer registration changed')
    focused=read(OUTER/'focused/summary.json')
    need(focused['entry_gate_qualified'] and len(focused['cells'])==4 and focused['plan_sha256']==digest,'focused gate has not passed')
    a=read(allocation)
    need('eh-complete-command' in a['tasks'] and a['released_utc'] and a['plan_sha256']==digest,'missing separate full-command allocation')
    need(len(a['cpus'])==8 and sorted(a['cpus'])==sorted(os.sched_getaffinity(0)),'requires the dedicated eight CPUs')
    need(p['uv']==UV and p['macro_command']==['cargo',*COMMAND] and p['uv_edit_preimage_sha256']==hashlib.sha256(ORIGINAL).hexdigest(),'workload mismatch')
    for cfg in p['macro_cohorts'].values():
        for index,digest in cfg['edits'].items():
            need(hashlib.sha256(body(cfg['literal_family'],int(index))).hexdigest()==digest,'source edit mismatch')
    return p
''')
s=s.replace('{"target","held-base","held-candidate","structural"}','{"target","held-base","held-shipped","held-candidate","structural"}')
section('seal','setup','''
def seal(p, allocation):
    identities={}
    bins=read(OUTER/'binaries.json')
    for arm,(cargo,wild) in ARMS.items():
        identities[arm]={'cargo':sha(cargo),'wild':sha(wild)}
        need(identities[arm]=={'cargo':p['shipped_toolchain']['cargo'],'wild':bins['arms'][arm]['binary_sha256']},f'bad {arm} binaries')
    need(sha(RELEASE/'bin/rustc')==p['shipped_toolchain']['rustc'],'shipped rustc changed')
    scripts=['run.py','plan.py','wrap.py','trace.py','calibrate.py','calibrate.c','elf_equivalence.py','verify.py','derive.py']
    dr=WORK/'dynamorio/DynamoRIO-Linux-11.3.0-1'
    return {'arms':identities,'plan_sha256':sha(OUTER/'plan.json'),'focused_gate_sha256':sha(OUTER/'focused/summary.json'),
            'allocation_sha256':sha(allocation),'cpus':sorted(os.sched_getaffinity(0)),'rustc_sha256':sha(RELEASE/'bin/rustc'),
            'counter_sha256':sha(COUNTER),'source_sha256':{x:sha(HERE/x) for x in scripts},
            'dynamorio':{n:sha(dr/n) for n in ['bin64/drrun','lib64/release/libdynamorio.so','tools/drcachesim.drrun64','tools/lib64/release/libdrmemtrace.so']}}
''')
section('mask_unit_harness','run','''
def artifact_hashes(records, tests, target, source):
    linked={Path(r['key']).resolve(strict=True) for r in records if r['role']=='wild'}
    outputs=set()
    for line in tests:
        m=re.search(r'\\((.+)\\)$',line)
        need(m is not None,f'unresolved emitted test: {line}')
        outputs.add((source/Path(m.group(1))).resolve(strict=True))
    need(len(outputs)==72 and len(linked)==5,'unexpected emitted test or link product count')
    allowed=set(read(OUTER/'plan.json')['macro_allowed_elf_variants_by_relative_path'])
    need(allowed<={str(f.relative_to(target)) for f in linked},'known ELF role names changed')
    result={}
    for f in sorted(outputs|linked):
        need(f.is_file() and f.is_relative_to(target),f'escaped or missing product: {f}')
        key=str(f.relative_to(target))
        if key in allowed:
            found=uv_elf(f)
            result[key]={'size':found['size'],'sha256':found['raw_sha256'],'canonical_sha256':found['canonical_sha256'],'permitted_fields':found['normalized_fields']}
        else:
            digest=sha(f)
            result[key]={'size':f.stat().st_size,'sha256':digest,'canonical_sha256':digest,'permitted_fields':None}
    return result

def mutable_home_state(path):
    records={}
    for entry in sorted(path.iterdir()):
        if entry.name=='registry':continue
        if entry.is_file():records[entry.name]=[sha(entry),entry.stat().st_mtime_ns]
        elif entry.is_dir():records[entry.name]=tree_state(entry)
        else:records[entry.name]=os.readlink(entry)
    return records
''')
s=s.replace('need(counts["cargo"]==1 and counts["rustc"]>0 and ((ep=="check")==(counts["wild"]==0)),f"unexpected role counts: {counts}")','need(counts=={"cargo":1,"rustc":6,"wild":5} and len(tests)==72,f"unexpected role or test counts: {counts}, {len(tests)}")')
s=s.replace('oracle=artifact_hashes(ep,records,target)','oracle=artifact_hashes(records,tests,target,src)')
s=s.replace('    env=dict(os.environ, CARGO_HOME=', '''    clean_env={k:v for k,v in os.environ.items() if not k.startswith(('WILD_','OHM_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD')}
    env=dict(clean_env, CARGO_HOME=''')

s=s.replace('need(r["instructions"]>0 and r["threads"] and r["instructions"]==sum(r["threads"].values()),"incomplete thread accounting")','need(r["instructions"]>0 and str(r["pid"]) in r["threads"] and r["instructions"]==sum(r["threads"].values()),"incomplete thread accounting")')
section('warm','match','''
def warm(cohort,p,identities):
    boundary(cohort,'test','before pristine preparation')
    root=ROOTS/cohort
    setup(root)
    out=RESULTS/cohort/'warm'
    out.mkdir(parents=True,exist_ok=True)
    need((root/'source'/EDIT).read_bytes()==ORIGINAL,'warm needs pristine source')
    stage(root,'base',identities['base'])
    if (root/'common-ready.json').exists():
        need(read(root/'common-ready.json')==tree_state(root/'common'),'pristine seed changed')
        return
    need(not (root/'common').exists() and not (root/'target').exists(),'unclaimed pristine state or interrupted warm')
    first=run(root,COMMAND,'test',out/'cold','native','warm')
    need(not run(root,COMMAND,'test',out/'fresh','native','warm'),'pristine command did not settle')
    (root/'target').rename(root/'common')
    receipt=tree_state(root/'common')
    save(root/'common-ready.json',receipt)
    save(out/'common-ready.json',{'tree':receipt,'cold_packages':first,'fresh_packages':[]})
''')
section('match','study', '''
def match(a,b):
    need(a['roster']==b['roster'],'role, exact rustc argv, package or test-executable roster changed')
    need(a['source_sha256']==b['source_sha256'] and a['source_mtime_ns']==b['source_mtime_ns'],'different source or mtime')
    need(a['files'].keys()==b['files'].keys(),'different output products')
    for path,left in a['files'].items():
        right=b['files'][path]
        need((left['size'],left['canonical_sha256'])==(right['size'],right['canonical_sha256']),f'output changed: {path}')
        if left['sha256']!=right['sha256']:
            x=left['permitted_fields'];y=right['permitted_fields']
            need(x and y and x['rodata'][:2]==y['rodata'][:2] and x['build_id'][:2]==y['build_id'][:2],'unknown field variant or location')
            need({x['rodata'][2],y['rodata'][2]}=={0,8} and x['build_id'][2]!=y['build_id'][2],f'not a demonstrated sh_entsize and dependent id change: {path}')
''')
s=s.replace('def study(cohort,ep,p,identities):\n    root=ROOTS/cohort;cfg=p["schedule"][cohort][ep];out=RESULTS/cohort/ep',
'''def study(cell,p,identities):
    cfg=p['macro_cohorts'][cell];cohort=cfg['cohort'];ep='test';control=cfg['control'];arms=(control,'candidate')
    root=ROOTS/cohort;out=RESULTS/cohort/control
    for prior in p['macro_cell_order'][:p['macro_cell_order'].index(cell)]:
        c=p['macro_cohorts'][prior];summary=RESULTS/c['cohort']/c['control']/'summary.json'
        need(summary.exists() and read(summary)['qualified'],'a preceding registered cell is incomplete or ineligible')''')
s=s.replace('expected={x["id"]:x["sha256"] for x in cfg["edits"]};home=root/"cargo-home"','expected={int(i):s for i,s in cfg["edits"].items()};home=root/"cargo-home"')
s=s.replace('home_states=root/("homes-"+ep);home_states.mkdir(mode=0o700)','home_states=root/("homes-"+cell);home_states.mkdir(mode=0o700)\n    original_home=mutable_home_state(home);copy_home_state(home,home_states/"original")')
s=s.replace('body(cfg["symbol"],i)','body(cfg["literal_family"],i)')
s=s.replace('select("base");clone(root/"common",target);set_edit(0)','select(control);clone(root/"common",target);set_edit(0)')
s=s.replace('run(root,cfg["command"],ep,','run(root,COMMAND,ep,')
s=s.replace('        for arm in ARMS:\n            dst=','        for arm in arms:\n            dst=')
s=s.replace('for name in ("held-base","held-candidate","structural"):discard(root/name)','for name in ("held-"+control,"held-candidate","structural"):discard(root/name)')
s=s.replace('for name in ("held-base","held-candidate","structural","target"):','for name in ("held-"+control,"held-candidate","structural","target"):')
s=s.replace('root/(f"rejected-{ep}-"+name)','root/(f"rejected-{cell}-"+name)')
s=s.replace('if (home_states/"predecessor").exists():copy_home_state(home_states/"predecessor",home)','copy_home_state(home_states/"original",home)\n        need(mutable_home_state(home)==original_home,"original Cargo-home state did not restore")')
s=s.replace('"target_vacant":not target.exists()','"target_vacant":not target.exists(),"home_restored":True')
s=s[:s.index('def main():')]+'''def main():
    args=argparse.ArgumentParser()
    args.add_argument('phase',choices=['seal','calibrate','warm','study'])
    args.add_argument('selection',nargs='?')
    args.add_argument('--allocation',type=Path,required=True)
    v=args.parse_args();p=checked_plan(v.allocation);f=HERE/'sealed.json';receipt=seal(p,v.allocation)
    if v.phase=='seal':
        if f.exists():need(receipt==read(f),'frozen command inputs changed')
        else:save(f,receipt)
        return
    need(f.exists() and receipt==read(f),'command input lock missing or changed')
    if v.phase=='calibrate':
        subprocess.run([sys.executable,'-B',HERE/'calibrate.py',HERE/'calibration'],check=True)
        return
    need((HERE/'calibration/PASS.json').exists(),'fresh fork/child/thread/descriptor calibration required')
    if v.phase=='warm':
        need(v.selection in {'initial','replica'},'expected one cohort')
        warm(v.selection,p,receipt['arms'])
    else:
        need(v.selection in p['macro_cohorts'],'expected a registered cell')
        study(v.selection,p,receipt['arms'])
        subprocess.run([sys.executable,'-B',HERE/'verify.py',v.selection],check=True)
if __name__=='__main__':
    main()
'''
s=s.replace('from trace import audit_native','from trace import audit_native\nfrom warm_process import run_warm')
s=s.replace("'verify.py','derive.py']","'verify.py','derive.py','warm_process.py']")
start=s.index('    with (log/"cargo.log").open("x") as f:')
end=s.index('    content=(log/"cargo.log").read_text',start)
s=s[:start]+'''    started=time.monotonic()
    if mode=="native" and kind=="warm":
        rc=run_warm(argv,src,env,log,HERE/"control/pause",lambda:boundary(root.name,ep,"excluded warm process group stopped"))
    else:
        with (log/"cargo.log").open("x") as f:
            rc=subprocess.run(argv,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    duration=time.monotonic()-started
'''+s[end:]
s=s.replace("    need(not run(root,COMMAND,'test',out/'fresh'","    boundary(cohort,'test','after pristine cold build')\n    need(not run(root,COMMAND,'test',out/'fresh'")
s=s.replace('        set_edit(1);ref=None', '        boundary(cohort,ep,"after excluded structural warmup")\n        set_edit(1);ref=None')
s=s.replace('            discard(target)\n        save(out/"admission.json"', '            discard(target)\n            boundary(cohort,ep,f"after admission cell {i+1} of 4")\n        save(out/"admission.json"')
assert 'cfg["command"]' not in s and 'guard-stack' not in s and 'round18-cargo/pgo/' not in s
ast.parse(s)
(here/'run.py').write_text(s)
