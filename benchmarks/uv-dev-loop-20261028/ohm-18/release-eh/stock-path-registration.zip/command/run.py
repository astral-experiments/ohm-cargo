#!/usr/bin/env python3
"""Prepare, admit and run the preregistered release-18 edited-role cohorts."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
from plan import *
from trace import audit_native
from warm_process import run_warm
from elf_equivalence import uv_elf

def checked_plan(allocation):
    p=read(OUTER/'plan.json')
    digest=sha(OUTER/'plan.json')
    need(digest==(OUTER/'registration.sha256').read_text().split()[0] and sha(OUTER/'PROTOCOL.md')==p['protocol_sha256'],'outer registration changed')
    focused=read(OUTER/'focused/summary.json')
    need(focused['entry_gate_qualified'] and len(focused['cells'])==4 and focused['plan_sha256']==digest,'focused gate has not passed')
    a=read(allocation)
    need('eh-complete-command' in a['tasks'] and a['released_utc'] and a['plan_sha256']==digest,'missing separate full-command allocation')
    need(len(a['cpus'])==8 and sorted(a['cpus'])==sorted(os.sched_getaffinity(0)),'requires the dedicated eight CPUs')
    need(p['uv']==UV and p['macro_command']==['cargo',*COMMAND] and p['uv_edit_preimage_sha256']==hashlib.sha256(ORIGINAL).hexdigest(),'workload mismatch')
    for cfg in p['macro_cohorts'].values():
        for index,digest in cfg['edits'].items():
            need(hashlib.sha256(body(cfg['literal_family'],int(index))).hexdigest()==digest,'source edit mismatch')
    return p

def clone(src, dst):
    need(src.is_dir() and not dst.exists(), f"bad clone: {src} -> {dst}")
    subprocess.run(["cp", "-a", "--reflink=auto", str(src), str(dst)], check=True)

def copy_home_state(src,dst):
    """Keep the 730 MB offline registry fixed and snapshot all the mutable home state."""
    dst.mkdir(mode=0o700,exist_ok=True)
    for entry in dst.iterdir():
        if entry.name=="registry":continue
        if entry.is_dir() and not entry.is_symlink():shutil.rmtree(entry)
        else:entry.unlink()
    for entry in src.iterdir():
        if entry.name!="registry":
            subprocess.run(["cp","-a","--reflink=auto",str(entry),str(dst/entry.name)],check=True)
    st=src.stat()
    os.utime(dst,ns=(st.st_atime_ns,st.st_mtime_ns))

def boundary(cohort,ep,label):
    """Park with no active Cargo, rustc or Wild process between complete paired blocks."""
    control=HERE/"control";control.mkdir(exist_ok=True)
    signal=control/"pause"
    def status(state):
        event={"state":state,"cohort":cohort,"endpoint":ep,"boundary":label,"utc_unix_ns":time.time_ns(),"pid":os.getpid()}
        tmp=control/"status.next";save(tmp,event);tmp.replace(control/"status.json")
        with (control/"boundaries.jsonl").open("a") as f:f.write(json.dumps(event)+"\n")
    if signal.exists():
        status("paused")
        print(f"Parked at {cohort}/{ep}: {label}",flush=True)
        while signal.exists():time.sleep(5)
    status("released")

def discard(path):
    need(path.parent.is_relative_to(ROOTS) and path.name in {"target","held-base","held-shipped","held-candidate","structural"}, f"unsafe private cleanup: {path}")
    shutil.rmtree(path)

def tree_state(path):
    h = hashlib.sha256()
    count = size = 0
    for base, dirs, files in os.walk(path):
        dirs.sort()
        for n in sorted(files):
            f=Path(base)/n
            st=f.lstat()
            h.update(json.dumps([str(f.relative_to(path)),st.st_mode,st.st_size,st.st_mtime_ns,os.readlink(f) if f.is_symlink() else None]).encode()+b"\n")
            count += 1
            size += st.st_size
    return {"file_metadata_sha256":h.hexdigest(),"files":count,"file_size_sum":size}

def seal(p, allocation):
    identities={}
    bins=read(OUTER/'binaries.json')
    for arm,(cargo,wild) in ARMS.items():
        identities[arm]={'cargo':sha(cargo),'wild':sha(wild)}
        need(identities[arm]=={'cargo':p['shipped_toolchain']['cargo'],'wild':bins['arms'][arm]['binary_sha256']},f'bad {arm} binaries')
    need(sha(RELEASE/'bin/rustc')==p['shipped_toolchain']['rustc'],'shipped rustc changed')
    scripts=['run.py','plan.py','wrap.py','trace.py','calibrate.py','calibrate.c','elf_equivalence.py','verify.py','derive.py','warm_process.py']
    dr=WORK/'dynamorio/DynamoRIO-Linux-11.3.0-1'
    return {'arms':identities,'plan_sha256':sha(OUTER/'plan.json'),'focused_gate_sha256':sha(OUTER/'focused/summary.json'),
            'allocation_sha256':sha(allocation),'cpus':sorted(os.sched_getaffinity(0)),'rustc_sha256':sha(RELEASE/'bin/rustc'),
            'counter_sha256':sha(COUNTER),'source_sha256':{x:sha(HERE/x) for x in scripts},
            'dynamorio':{n:sha(dr/n) for n in ['bin64/drrun','lib64/release/libdynamorio.so','tools/drcachesim.drrun64','tools/lib64/release/libdrmemtrace.so']}}

def setup(root):
    root.mkdir(mode=0o700,parents=True,exist_ok=True)
    if (root/"setup.json").exists():
        return
    src=root/"source"
    if not src.exists():
        temp=root/"source.incoming"
        temp.mkdir()
        with subprocess.Popen(["git","-C",str(WORK/"uv"),"archive",UV], stdout=subprocess.PIPE) as git:
            subprocess.run(["tar","-x","-C",str(temp)],stdin=git.stdout,check=True)
            need(git.wait()==0,"git archive failed")
        temp.rename(src)
    need((src/EDIT).read_bytes()==ORIGINAL, "unexpected archived source")
    home=root/"cargo-home"
    home.mkdir(exist_ok=True,mode=0o700)
    if not (home/"registry").exists():
        cache=BENCH/"cargo/registry"
        incoming=home/"registry.incoming"
        if incoming.exists(): # Previous cp interrupted before it could publish.
            shutil.rmtree(incoming)
        clone(cache,incoming)
        incoming.rename(home/"registry")
    t=root/"tools"
    for d in (t/"bin",t/"linker",t/"arms"):
        d.mkdir(parents=True,exist_ok=True)
    for dest in (t/"bin/cc",t/"rustc-wrapper",t/"linker/ld.bfd"):
        if not dest.is_symlink():
            dest.symlink_to(WRAP)
    save(root/"setup.json",{"source":str(src),"original_sha256":sha(src/EDIT),"cargo_lock":sha(src/"Cargo.lock"),"immutable_registry":str(BENCH/"cargo/registry"),"cargo_home":str(home),"visible_target":str(root/"target"),"rustc":str(RELEASE/"bin/rustc")})

def stage(root, arm, expected):
    t=root/"tools"
    for (role,src) in zip(("cargo","wild"), ARMS[arm]):
        staged=t/"arms"/(arm+"-"+role)
        if not staged.exists():
            temp=staged.with_suffix(".incoming")
            shutil.copy2(src,temp)
            need(sha(temp)==expected[role], f"{role} staging hash")
            temp.chmod(0o555)
            temp.rename(staged)
        need(sha(staged)==expected[role], f"{role} staged hash")
        slot=t/role
        temp=slot.with_suffix(".next")
        temp.unlink(missing_ok=True)
        os.link(staged,temp)
        os.replace(temp,slot)
        temp.unlink(missing_ok=True)
        need(os.path.samefile(slot,staged),"bad binary slot")

def artifact_hashes(records, tests, target, source):
    linked={Path(r['key']).resolve(strict=True) for r in records if r['role']=='wild'}
    outputs=set()
    for line in tests:
        m=re.search(r'\((.+)\)$',line)
        need(m is not None,f'unresolved emitted test: {line}')
        outputs.add((source/Path(m.group(1))).resolve(strict=True))
    need(len(outputs)==72 and len(linked)==5,'unexpected emitted test or link product count')
    allowed=set(read(OUTER/'plan.json')['macro_allowed_elf_variants_by_relative_path'])
    need(allowed<={str(f.relative_to(target)) for f in linked},'known ELF role names changed')
    result={}
    for f in sorted(outputs|linked):
        need(f.is_file() and f.is_relative_to(target),f'escaped or missing product: {f}')
        key=str(f.relative_to(target))
        if key in allowed:
            found=uv_elf(f)
            result[key]={'size':found['size'],'sha256':found['raw_sha256'],'canonical_sha256':found['canonical_sha256'],'permitted_fields':found['normalized_fields']}
        else:
            digest=sha(f)
            result[key]={'size':f.stat().st_size,'sha256':digest,'canonical_sha256':digest,'permitted_fields':None}
    return result

def mutable_home_state(path):
    records={}
    for entry in sorted(path.iterdir()):
        if entry.name=='registry':continue
        if entry.is_file():records[entry.name]=[sha(entry),entry.stat().st_mtime_ns]
        elif entry.is_dir():records[entry.name]=tree_state(entry)
        else:records[entry.name]=os.readlink(entry)
    return records

def run(root, command, ep, log, mode, kind):
    log.mkdir(parents=True)
    t=root/"tools";target=root/"target";src=root/"source"
    paths=dict(cargo=t/"cargo",wild=t/"wild",rustc=RELEASE/"bin/rustc",linker_wrapper=t/"linker/ld.bfd")
    clean_env={k:v for k,v in os.environ.items() if not k.startswith(('WILD_','OHM_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD')}
    env=dict(clean_env, CARGO_HOME=str(root/"cargo-home"),CARGO_TARGET_DIR=str(target),RUSTC=str(paths["rustc"]),RUSTDOC=str(RELEASE/"bin/rustdoc"),
             CARGO_NET_OFFLINE="true", CARGO_TERM_COLOR="never", SSL_CERT_DIR="/etc/ssl/certs", PATH=f"{t/'bin'}:{RELEASE/'bin'}:{os.environ['PATH']}",
             RUSTC_WRAPPER=str(t/"rustc-wrapper"), OHM_RELEASE_WILD_DIR=str(RELEASE/"lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld"),
             OHM_WRAPPED_WILD_DIR=str(t/"linker"),OHM_ACTUAL_WILD=str(paths["wild"]),OHM_SINGLE_COUNTER=str(COUNTER),OHM_ROLE_MODE=mode,OHM_ROLE_LOG=str(log))
    argv=[str(WRAP),"cargo",str(paths["cargo"]),*command]
    if mode=="native" and kind=="admit":
        argv=["strace","-ff","-qq","-s","450","-e","trace=execve,execveat","-o",str(log/"exec"),*argv]
    started=time.monotonic()
    if mode=="native" and kind=="warm":
        rc=run_warm(argv,src,env,log,HERE/"control/pause",lambda:boundary(root.name,ep,"excluded warm process group stopped"))
    else:
        with (log/"cargo.log").open("x") as f:
            rc=subprocess.run(argv,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    duration=time.monotonic()-started
    content=(log/"cargo.log").read_text(errors="replace")
    need(rc==0 and re.search(r"^\s*Finished ",content,re.M),f"{log}: Cargo status {rc}\n"+content[-1400:])
    need(not re.search(r"^\s*(Running|Updating|Downloading) |^running \d+ tests?",content,re.M),"test execution or fetching")
    packages=sorted([list(m) for m in re.findall(r"^\s*(Checking|Compiling) (.+)$",content,re.M)])
    if kind=="warm":return packages
    need(len(packages)==1 and packages[0][1].startswith("uv v"),f"unexpected package roster: {packages}")
    if kind=="structural":return packages
    tests=sorted(re.findall(r"^\s*Executable (.+)$",content,re.M))
    need((ep=="test") == bool(tests) and (ep!="test" or any(x.startswith("tests/it/") for x in tests)), "test roster shape")
    records=[read(f) for role in ROLES for f in log.glob(role+"-*.json")]
    counts=Counter(r["role"] for r in records)
    need(counts=={"cargo":1,"rustc":6,"wild":5} and len(tests)==72,f"unexpected role or test counts: {counts}, {len(tests)}")
    for r in records:
        need(r["executable"]==str(paths[r["role"]]),"incorrect selected executable path")
        if mode=="count":
            need(r["instructions"]>0 and str(r["pid"]) in r["threads"] and r["instructions"]==sum(r["threads"].values()),"incomplete thread accounting")
    if mode=="native":
        audit_native(log,paths,records)
        ran=set(read(log/"native-execs.json"))
        test_bins={str((src/Path(m[1])).resolve()) for s in tests if (m:=re.search(r"\((.+)\)$",s))}
        need(not ran.intersection(test_bins),"native trace ran an emitted test")
    roster={"packages":packages,"tests":tests,"records":sorted([r["role"],json.dumps(r["key"])] for r in records),"role_counts":dict(counts)}
    oracle=artifact_hashes(records,tests,target,src)
    sums={r:sum(x.get("instructions",0) for x in records if x["role"]==r) for r in ROLES}
    rec={"roster":roster,"files":oracle,"totals":sums,"source_sha256":sha(src/EDIT),"source_mtime_ns":(src/EDIT).stat().st_mtime_ns,
         "observed_runtime_for_budget_s":duration,"actual_binary_inodes":{r:[paths[r].stat().st_dev,paths[r].stat().st_ino] for r in ROLES}}
    save(log/"receipt.json",rec)
    return rec

def warm(cohort,p,identities):
    boundary(cohort,'test','before pristine preparation')
    root=ROOTS/cohort
    setup(root)
    out=RESULTS/cohort/'warm'
    out.mkdir(parents=True,exist_ok=True)
    need((root/'source'/EDIT).read_bytes()==ORIGINAL,'warm needs pristine source')
    stage(root,'base',identities['base'])
    if (root/'common-ready.json').exists():
        need(read(root/'common-ready.json')==tree_state(root/'common'),'pristine seed changed')
        return
    need(not (root/'common').exists() and not (root/'target').exists(),'unclaimed pristine state or interrupted warm')
    first=run(root,COMMAND,'test',out/'cold','native','warm')
    boundary(cohort,'test','after pristine cold build')
    need(not run(root,COMMAND,'test',out/'fresh','native','warm'),'pristine command did not settle')
    (root/'target').rename(root/'common')
    receipt=tree_state(root/'common')
    save(root/'common-ready.json',receipt)
    save(out/'common-ready.json',{'tree':receipt,'cold_packages':first,'fresh_packages':[]})

def match(a,b):
    need(a['roster']==b['roster'],'role, exact rustc argv, package or test-executable roster changed')
    need(a['source_sha256']==b['source_sha256'] and a['source_mtime_ns']==b['source_mtime_ns'],'different source or mtime')
    need(a['files'].keys()==b['files'].keys(),'different output products')
    for path,left in a['files'].items():
        right=b['files'][path]
        need((left['size'],left['canonical_sha256'])==(right['size'],right['canonical_sha256']),f'output changed: {path}')
        if left['sha256']!=right['sha256']:
            x=left['permitted_fields'];y=right['permitted_fields']
            need(x and y and x['rodata'][:2]==y['rodata'][:2] and x['build_id'][:2]==y['build_id'][:2],'unknown field variant or location')
            need({x['rodata'][2],y['rodata'][2]}=={0,8} and x['build_id'][2]!=y['build_id'][2],f'not a demonstrated sh_entsize and dependent id change: {path}')

def study(cell,p,identities):
    cfg=p['macro_cohorts'][cell];cohort=cfg['cohort'];ep='test';control=cfg['control'];arms=(control,'candidate')
    root=ROOTS/cohort;out=RESULTS/cohort/control
    for prior in p['macro_cell_order'][:p['macro_cell_order'].index(cell)]:
        c=p['macro_cohorts'][prior];summary=RESULTS/c['cohort']/c['control']/'summary.json'
        need(summary.exists() and read(summary)['qualified'],'a preceding registered cell is incomplete or ineligible')
    boundary(cohort,ep,"before endpoint")
    need((root/"common-ready.json").exists() and not out.exists(),"target not prepared, or cohort already observed")
    need(read(root/"common-ready.json")==tree_state(root/"common"),"common seed metadata changed")
    out.mkdir(parents=True);target=root/"target";src=root/"source"/EDIT;stat=src.stat()
    need(src.read_bytes()==ORIGINAL and not target.exists(),"fixture busy")
    expected={int(i):s for i,s in cfg["edits"].items()};home=root/"cargo-home"
    home_states=root/("homes-"+cell);home_states.mkdir(mode=0o700)
    original_home=mutable_home_state(home);copy_home_state(home,home_states/"original")
    def set_edit(i):
        src.write_bytes(body(cfg["literal_family"],i))
        need(sha(src)==expected[i],"registered edit mismatch")
    def select(arm):
        stage(root,arm,identities[arm])
    try:
        select(control);clone(root/"common",target);set_edit(0)
        run(root,COMMAND,ep,out/"structural", "native","structural")
        need(not run(root,COMMAND,ep,out/"fresh","native","warm"),"structural predecessor not fresh")
        target.rename(root/"structural");pred=tree_state(root/"structural");save(out/"predecessor.json",pred)
        copy_home_state(home,home_states/"predecessor")
        registry=tree_state(home/"registry");save(out/"registry.json",registry)
        boundary(cohort,ep,"after excluded structural warmup")
        set_edit(1);ref=None
        for i,(mode,arm) in enumerate(cfg["native_count_admission"]):
            copy_home_state(home_states/"predecessor",home)
            select(arm);clone(root/"structural",target);need(tree_state(target)==pred,"pilot seed differs")
            rec=run(root,COMMAND,ep,out/f"admit-{i}-{mode}-{arm}",mode,"admit")
            if ref:match(ref,rec)
            else:ref=rec
            discard(target)
            boundary(cohort,ep,f"after admission cell {i+1} of 4")
        save(out/"admission.json",ref["roster"])
        print("Admitted",cohort,ep,ref["roster"]["role_counts"],len(ref["roster"]["tests"]),"test executables",flush=True)
        boundary(cohort,ep,"after four-cell admission")
        for arm in arms:
            dst=root/("held-"+arm);clone(root/"structural",dst);need(tree_state(dst)==pred,"held seed differs")
            copy_home_state(home_states/"predecessor",home_states/arm)
        with (out/"samples.csv").open("x",newline="") as stream:
            rows=csv.DictWriter(stream,fieldnames=["pair","id","position","arm","cargo","rustc","wild","total","source_sha256","receipt"])
            rows.writeheader()
            for i,pair in enumerate(cfg["pairs"]):
                set_edit(pair["id"]);first=None
                for j,arm in enumerate(pair["order"]):
                    held=root/("held-"+arm);held.rename(target);select(arm)
                    copy_home_state(home_states/arm,home)
                    log=out/f"pair-{i}-{j}-{arm}"
                    rec=run(root,COMMAND,ep,log,"count","sample")
                    need(ref["roster"]==rec["roster"],"sample differs from admitted workload")
                    if first:match(first,rec)
                    else:first=rec
                    target.rename(held)
                    copy_home_state(home,home_states/arm)
                    rows.writerow(dict(pair=i,id=pair["id"],position=j,arm=arm,**rec["totals"],total=sum(rec["totals"].values()),source_sha256=rec["source_sha256"],receipt=str(log.relative_to(out)/"receipt.json")))
                    stream.flush()
                boundary(cohort,ep,f"after pair {i+1} of 8")
        need(tree_state(root/"structural")==pred, "structural seed changed")
        need(tree_state(home/"registry")==registry,"immutable offline registry changed")
        for name in ("held-"+control,"held-candidate","structural"):discard(root/name)
        save(out/"complete.json", {"pairs":8,"arms":16,"admission_cells":4,"common_unchanged":tree_state(root/"common")==read(root/"common-ready.json")})
        need(read(out/"complete.json")["common_unchanged"],"common seed changed")
    except BaseException as exc:
        save(out/"rejected.json",{"type":type(exc).__name__,"error":str(exc)})
        # Keep every rejected target outside visible slots and available for diagnosis.
        for name in ("held-"+control,"held-candidate","structural","target"):
            if (root/name).exists():(root/name).rename(root/(f"rejected-{cell}-"+name))
        raise
    finally:
        copy_home_state(home_states/"original",home)
        need(mutable_home_state(home)==original_home,"original Cargo-home state did not restore")
        src.write_bytes(ORIGINAL);os.utime(src,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        save(out/"restore.json",{"source_sha256":sha(src),"source_mtime_ns":src.stat().st_mtime_ns,"target_vacant":not target.exists(),"home_restored":True})

def main():
    args=argparse.ArgumentParser()
    args.add_argument('phase',choices=['seal','calibrate','warm','study'])
    args.add_argument('selection',nargs='?')
    args.add_argument('--allocation',type=Path,required=True)
    v=args.parse_args();p=checked_plan(v.allocation);f=HERE/'sealed.json';receipt=seal(p,v.allocation)
    if v.phase=='seal':
        if f.exists():need(receipt==read(f),'frozen command inputs changed')
        else:save(f,receipt)
        return
    need(f.exists() and receipt==read(f),'command input lock missing or changed')
    if v.phase=='calibrate':
        subprocess.run([sys.executable,'-B',HERE/'calibrate.py',HERE/'calibration'],check=True)
        return
    need((HERE/'calibration/PASS.json').exists(),'fresh fork/child/thread/descriptor calibration required')
    if v.phase=='warm':
        need(v.selection in {'initial','replica'},'expected one cohort')
        warm(v.selection,p,receipt['arms'])
    else:
        need(v.selection in p['macro_cohorts'],'expected a registered cell')
        study(v.selection,p,receipt['arms'])
        subprocess.run([sys.executable,'-B',HERE/'verify.py',v.selection],check=True)
if __name__=='__main__':
    main()
