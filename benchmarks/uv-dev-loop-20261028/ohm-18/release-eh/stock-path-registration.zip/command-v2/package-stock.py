"""Package the two stock-only admission proofs and their portable verifier, excluding ELF payloads."""
import hashlib,json,shutil,subprocess,tempfile,zipfile
from pathlib import Path
v=Path(__file__).resolve().parent;root=v.parent;src=root.parent
bench=Path((src/'bench-home.path').read_text().strip())/'release-eh-roles-18'
files={}
def add(name, f):files[str(name)]=Path(f)
def addrel(f):add(f.relative_to(root),f)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for n in ['plan.json','PROTOCOL.md','registration.sha256','binaries.json']:
    addrel(root/n)
for n in ['allocation.json','sealed.json','wrap.py','run.py','plan.py','trace.py','derive.py','verify.py','warm_process.py','calibrate.py','calibrate.c','elf_equivalence.py','README.md','calibration/PASS.json','results/initial/base/rejected.json','results/initial/base/restore.json','premeasurement-01-ptrace/attempt.json']:
    f=root/'command'/n
    if f.exists():addrel(f)
for n in ['README.md','STOCK-PATH-REGISTRATION.md','CONTROL-OBSERVER.md','plan.json','registration.sha256','sealed.json','v1-terminal.json','path-provenance.json','stock-driver-launch-01.json','premeasurement-02-async-stock-return/attempt.json','premeasurement-02-async-stock-return/original-seal.json','stock_driver.py','measure_driver.py','package-stock.py','verify-stock.py','disk-guard.py']:
    addrel(v/n)
sealed=json.loads((v/'sealed.json').read_text())['source_sha256']
for n,h in sealed.items():
    assert sha(v/n)==h
    addrel(v/n)
for c in ['initial','replica']:
    d=v/'stock'/c
    for f in d.rglob('*'):
        if f.is_file() and f.suffix!='.elf':addrel(f)
    b=json.loads((d/'binding.json').read_text())
    scripts=list((bench/c/'stock-path-controls/captures').glob('*/run-with'))
    hs={sha(f):f for f in scripts};assert len(hs)==5
    for role,p in b['proof'].items():
        add(Path('command-v2/stock')/c/'replays'/(role+'-run-with'),hs[p['captured_script_sha256']])
dest=root/'compact-stock-registration.zip'
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    manifest={}
    for n,f in sorted(files.items()):
        content=f.read_bytes();manifest[n]=hashlib.sha256(content).hexdigest()
        entry=zipfile.ZipInfo(n,date_time=(2026,10,28,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,content)
    e=zipfile.ZipInfo('MANIFEST.sha256',date_time=(2026,10,28,0,0,0));e.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(e,''.join(h+'  '+n+'\n' for n,h in manifest.items()))
with tempfile.TemporaryDirectory(dir=root) as td:
    tmp=Path(td)
    with zipfile.ZipFile(dest) as z:z.extractall(tmp)
    for line in (tmp/'MANIFEST.sha256').read_text().splitlines():
        h,n=line.split('  ',1);assert sha(tmp/n)==h
    subprocess.run(['python3','-I','-B',tmp/'command-v2/verify-stock.py'],check=True)
report={'bytes':dest.stat().st_size,'sha256':sha(dest),'files_excluding_manifest':len(files),'plan_sha256':sha(v/'plan.json'),'verified_extracted_stdlib_only':True,'contains_treatment_performance_rows':False}
(root/'compact-stock-registration.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
