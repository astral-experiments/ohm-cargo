"""Portable verification of the frozen stock scope, receipt match and A/A discrepancy table."""
import hashlib,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify():
    original=read(here.parent/'plan.json');plan=read(here/'plan.json')
    assert sha(here/'plan.json')==(here/'registration.sha256').read_text().split()[0]
    assert sha(here.parent/'plan.json')==plan['original_plan_sha256']
    assert original['macro_cohorts']==plan['original_macro_cohorts'] and original['macro_cell_order']==plan['original_cell_order']
    assert sha(here/'STOCK-PATH-REGISTRATION.md')==plan['scope_sha256'] and sha(here/'sealed.json')==plan['sealed_sha256']
    expected={'uv-bin','uvx-bin','uv-bin-test','uvx-bin-test','uv-lib-test'}
    for c,b0 in plan['stock_path_bindings'].items():
        out=here/'stock'/c;paths=read(out/'paths-before-aa.json');b=read(out/'binding.json')
        assert sha(out/'binding.json')==b0['proof_sha256'] and sha(out/'paths-before-aa.json')==b['paths_before_aa_sha256']
        assert sha(out/'native-stock/receipt.json')==b['stock_native_receipt_sha256'];native=read(out/'native-stock/receipt.json')
        assert paths['stock_wild_sha256']==original['shipped_toolchain']['wild'] and paths['stock_cargo_sha256']==original['shipped_toolchain']['cargo'] and paths['stock_rustc_sha256']==original['shipped_toolchain']['rustc']
        assert paths['source_sha256']==original['macro_cohorts'][c+'-base']['edits']['1']
        assert len(native['roster']['tests'])==72 and native['roster']['role_counts']=={'cargo':1,'rustc':6,'wild':5}
        assert len(paths['linked_paths'])==5 and len(paths['emitted_paths'])==72
        assert set(native['files'])==set(paths['emitted_paths'])|set(paths['linked_paths'])
        assert set(b['proof'])==expected and set(paths['units'])==expected|{'uv-lib-rlib'}
        assert all(b0[k]==b[k] for k in ['allowed','emitted_paths','linked_paths'])
        assert all(b[k]==paths[k] for k in ['linked_paths','emitted_paths'])
        allowed=set()
        for role,proof in b['proof'].items():
            unit=paths['units'][role];f=proof['path'];assert unit['wild_output']==f and native['files'][f]['sha256']==proof['native_sha256']
            assert sha(out/'structural'/unit['rustc_record'])==unit['rustc_record_sha256']
            assert sha(out/'native-stock'/paths['edited_rustc_units'][role]['record'])==paths['edited_rustc_units'][role]['sha256']
            a,z=[proof['rows'][str(s)] for s in [0,7]]
            assert a['size']==z['size']==native['files'][f]['size'] and all(v['status']==0 and sorted(bytes.fromhex(v['jobserver_tokens_before']))==sorted(bytes.fromhex(v['jobserver_tokens_after'])) and len(bytes.fromhex(v['jobserver_tokens_before']))==v['slots'] for v in (a,z))
            assert proof['native_sha256'] in [a['raw_sha256'],z['raw_sha256']]
            assert proof['raw_variant_demonstrated']==(a['raw_sha256']!=z['raw_sha256'])
            if proof['raw_variant_demonstrated']:
                assert role!='uvx-bin';allowed.add(f)
                x,y=proof['normalized_fields'];diff=proof['changed_bytes']
                assert x['rodata'][:2]==y['rodata'][:2] and {x['rodata'][2],y['rodata'][2]}=={0,8}
                assert x['build_id'][:2]==y['build_id'][:2] and x['build_id'][1]-x['build_id'][0]==32
                expected_diff=[[x['rodata'][0],x['rodata'][2],y['rodata'][2]]]+[[x['build_id'][0]+i,l,r] for i,(l,r) in enumerate(zip(bytes.fromhex(x['build_id'][2]),bytes.fromhex(y['build_id'][2]))) if l!=r]
                assert len(expected_diff)>1 and sorted(expected_diff)==diff
        assert allowed==set(b0['allowed'])
        print(c,'stock controls',5,'confirmed Wild paths',len(allowed),'same-stock ELF exceptions')
    for c in plan['stock_path_bindings']:
        for summary in (here/'results'/c).glob('*/summary.json'):
            s=read(summary);assert s['stock_path_plan_sha256']==sha(here/'plan.json')
            paths=plan['stock_path_bindings'][c];products=set(paths['linked_paths'])|set(paths['emitted_paths'])
            for receipt in list(summary.parent.glob('admit-*/receipt.json'))+list(summary.parent.glob('pair-*/receipt.json')):
                assert set(read(receipt)['files'])==products
if __name__=='__main__':verify()
