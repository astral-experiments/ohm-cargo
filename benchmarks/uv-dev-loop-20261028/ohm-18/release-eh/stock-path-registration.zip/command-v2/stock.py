"""Discover every fresh output path using distributed Wild only. No treatment runs here."""
from pathlib import Path
import json, os, re, sys
import run as r
from plan import *
from stock_replay import replay_provenance

SPEC = {
    ('uv','crates/uv/src/bin/uv.rs',False):'uv-bin',
    ('uvx','crates/uv/src/bin/uvx.rs',False):'uvx-bin',
    ('uv','crates/uv/src/lib.rs',True):'uv-lib-test',
    ('uv','crates/uv/src/bin/uv.rs',True):'uv-bin-test',
    ('uvx','crates/uv/src/bin/uvx.rs',True):'uvx-bin-test',
    ('uv','crates/uv/src/lib.rs',False):'uv-lib-rlib',
}
ELIGIBLE={'uv-bin','uv-lib-test','uv-bin-test','uvx-bin-test'}

def unit_binding(log,target):
    units={}
    for file in sorted(log.glob('rustc-*.json')):
        argv=read(file)['argv'];crate=argv[argv.index('--crate-name')+1]
        src=[x for x in argv if x in {z[1] for z in SPEC}]
        need(len(src)==1,'structural rustc unit lacks its actual crate root')
        role=SPEC[(crate,src[0],'--test' in argv)]
        od=Path(argv[argv.index('--out-dir')+1]);ud=od.relative_to(target).as_posix()
        need(bool(re.fullmatch(r'debug/build/uv/[0-9a-f]{16}/out',ud)),'unit outside registered Cargo output layout')
        suffix=[x.split('=',1)[1] for x in argv if x.startswith('extra-filename=')]
        if '--test' in argv:need(suffix==['-'+od.parent.name],'unit and test filename hash differ')
        if role in ('uv-bin','uvx-bin'):need(not suffix,'normal bin unexpectedly suffixed')
        metadata=[x.split('=',1)[1] for x in argv if x.startswith('metadata=')]
        need(len(metadata)==1 and role not in units,'ambiguous compiler unit')
        units[role]={'crate':crate,'source':src[0],'test':'--test' in argv,'unit_directory':ud,'metadata':metadata[0],'extra_filename':suffix,'rustc_record':file.name,'rustc_record_sha256':sha(file)}
        if role!='uv-lib-rlib':units[role]['wild_output']=str(Path(ud)/(crate+''.join(suffix)))
    need(set(units)==set(SPEC.values()),'unexpected structural rustc role set')
    links={str(Path(read(f)['key']).relative_to(target)) for f in log.glob('wild-*.json')}
    need(links=={u['wild_output'] for u in units.values() if 'wild_output' in u},'structural Wild and rustc unit mappings differ')
    return units

def confirm_edited_units(log,units,target):
    pending={u['unit_directory']:role for role,u in units.items()}
    traces={}
    for path in sorted(log.glob('rustc-*.json')):
        a=read(path)['argv']
        directory=str(Path(a[a.index('--out-dir')+1]).relative_to(target))
        role=pending.pop(directory);u=units[role]
        need(a[a.index('--crate-name')+1]==u['crate'] and ('--test' in a)==u['test'],'edited rustc target changed')
        need([x.split('=',1)[1] for x in a if x.startswith('metadata=')]==[u['metadata']],'edited rustc metadata changed')
        need([x.split('=',1)[1] for x in a if x.startswith('extra-filename=')]==u['extra_filename'],'edited rustc filename changed')
        traces[role]={'record':path.name,'sha256':sha(path),'link_only':any('link-only' in x for x in a)}
    need(not pending,'missing actual rustc target')
    return traces

def discover(cohort):
    p=r.checked_plan(OUTER/'command/allocation.json');ids=read(OUTER/'command/sealed.json')['arms']
    cfg=p['macro_cohorts'][cohort+'-base'];root=ROOTS/cohort;out=HERE/'stock'/cohort;out.mkdir(parents=True)
    target=root/'target';src=root/'source'/EDIT;home=root/'cargo-home';house=root/'stock-path-controls'
    house.mkdir(mode=0o700);stat=src.stat();original_home=r.mutable_home_state(home)
    need(src.read_bytes()==ORIGINAL and not target.exists(),'stock fixture is occupied')
    need(r.tree_state(root/'common')==read(root/'common-ready.json'),'pristine snapshot changed')
    r.copy_home_state(home,house/'original')
    try:
        r.boundary(cohort,'test','before stock-only structural admission')
        r.stage(root,'shipped',ids['shipped'])
        need(sha(root/'tools/cargo')==p['shipped_toolchain']['cargo'] and sha(root/'tools/wild')==ids['shipped']['wild'],'distributed tools not selected')
        r.clone(root/'common',target)
        src.write_bytes(body(cfg['literal_family'],0));need(sha(src)==cfg['edits']['0'],'structural source')
        r.run(root,COMMAND,'test',out/'structural','native','structural')
        need(not r.run(root,COMMAND,'test',out/'fresh','native','warm'),'stock structural successor was not fresh')
        units=unit_binding(out/'structural',target)
        r.boundary(cohort,'test','after stock-only structural admission')
        src.write_bytes(body(cfg['literal_family'],1));need(sha(src)==cfg['edits']['1'],'excluded source')
        cap=house/'captures';cap.mkdir()
        native=out/'native-stock';record=r.run(root,COMMAND,'test',native,'native','stock-discovery',capture=cap)
        traces=confirm_edited_units(native,units,target)
        emitted=set()
        for text in record['roster']['tests']:
            rel=re.search(r'\((.+)\)$',text)[1];emitted.add(str((root/'source'/rel).resolve(strict=True).relative_to(target)))
        linked={str(Path(read(f)['key']).resolve(strict=True).relative_to(target)) for f in native.glob('wild-*.json')}
        need(len(emitted)==72 and linked=={v['wild_output'] for v in units.values() if 'wild_output' in v} and set(record['files'])==emitted|linked,'unmapped stock command product')
        path_lock={'cohort':cohort,'stock_wild_sha256':sha(root/'tools/wild'),'stock_cargo_sha256':sha(root/'tools/cargo'),'stock_rustc_sha256':sha(RELEASE/'bin/rustc'),
                   'units':units,'edited_rustc_units':traces,'linked_paths':sorted(linked),'emitted_paths':sorted(emitted),'source_sha256':record['source_sha256'],'native_receipt_sha256':sha(native/'receipt.json')}
        save(out/'paths-before-aa.json',path_lock)
        proof=replay_provenance(cohort,out,root,target,units,cap,record['files'],ELIGIBLE)
        save(out/'binding.json',{'paths_before_aa_sha256':sha(out/'paths-before-aa.json'),'stock_native_receipt_sha256':sha(native/'receipt.json'),'proof':proof,'linked_paths':sorted(linked),'emitted_paths':sorted(emitted),'allowed':sorted(z['path'] for z in proof.values() if z['raw_variant_demonstrated']),'source_sha256':sha(src),'role_counts':record['roster']['role_counts']})
        print('Stock binding:',cohort,{k:v['raw_variant_demonstrated'] for k,v in proof.items()},flush=True)
        r.discard(target)
    except BaseException as exc:
        save(out/'rejected.json',{'type':type(exc).__name__,'error':str(exc)})
        if target.exists():target.rename(house/'rejected-visible-target')
        raise
    finally:
        r.copy_home_state(house/'original',home);need(r.mutable_home_state(home)==original_home,'original control Cargo home did not restore')
        src.write_bytes(ORIGINAL);os.utime(src,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        save(out/'restore.json',{'source_sha256':sha(src),'source_mtime_ns':src.stat().st_mtime_ns,'home_restored':True,'target_vacant':not target.exists()})

def lock():
    p=read(OUTER/'plan.json');bindings={}
    for c in ('initial','replica'):
        out=HERE/'stock'/c;b=read(out/'binding.json');restore=read(out/'restore.json')
        need(restore['home_restored'] and restore['target_vacant'] and restore['source_sha256']==p['uv_edit_preimage_sha256'],'fixture not restored')
        need(b['paths_before_aa_sha256']==sha(out/'paths-before-aa.json') and b['stock_native_receipt_sha256']==sha(out/'native-stock/receipt.json'),'stock proof changed')
        need(len(b['linked_paths'])==5 and len(b['emitted_paths'])==72 and len(b['proof'])==5,'incomplete stock qualification')
        bindings[c]={k:b[k] for k in ('linked_paths','emitted_paths','allowed')};bindings[c]['proof_sha256']=sha(out/'binding.json')
    amended={'original_plan_sha256':sha(OUTER/'plan.json'),'scope_sha256':sha(HERE/'STOCK-PATH-REGISTRATION.md'),'observer_sha256':sha(HERE/'CONTROL-OBSERVER.md'),'sealed_sha256':sha(HERE/'sealed.json'),'stock_path_bindings':bindings,'original_macro_cohorts':p['macro_cohorts'],'original_cell_order':p['macro_cell_order'],'former_attempt':str(Path('..')/'command/results/initial/base/rejected.json'),'scored_rows_imported':0}
    need(not (HERE/'plan.json').exists(),'v2 lock already issued')
    save(HERE/'plan.json',amended);(HERE/'registration.sha256').write_text(sha(HERE/'plan.json')+'  plan.json\n')
    print('V2 plan',sha(HERE/'plan.json'),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='lock':lock()
    else:
        need(sys.argv[1] in ('initial','replica'),'expected intended private fixture')
        discover(sys.argv[1])
