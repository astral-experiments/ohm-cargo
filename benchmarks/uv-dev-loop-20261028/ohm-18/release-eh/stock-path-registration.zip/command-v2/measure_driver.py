"""Run the original four cells in order after both stock proofs have been sealed."""
from pathlib import Path
import json,os,subprocess,sys,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from plan import *
from run import boundary,checked_plan
allocation=OUTER/'command/allocation.json'
p=checked_plan(allocation);registered=read(HERE/'plan.json')
need(sha(HERE/'plan.json')==(HERE/'registration.sha256').read_text().split()[0],'unsealed path plan')
need(registered['original_macro_cohorts']==p['macro_cohorts'] and registered['original_cell_order']==p['macro_cell_order'],'original input schedule changed')
cells=[]
for name in p['macro_cell_order']:
    cfg=p['macro_cohorts'][name];out=HERE/'results'/cfg['cohort']/cfg['control'];out.parent.mkdir(parents=True,exist_ok=True)
    boundary(cfg['cohort'],'test','before complete-command study '+name)
    with (HERE/(name+'.log')).open('x') as driver_log:
        proc=subprocess.run([sys.executable,'-u','-B',HERE/'run.py','study',name,'--allocation',allocation],stdout=driver_log,stderr=subprocess.STDOUT)
    if proc.returncode:
        save(HERE/'terminal.json',{'status':'admission or required invariant failed','cell':name,'status_code':proc.returncode,'completed_cells':cells,'plan_sha256':sha(HERE/'plan.json')})
        sys.exit(proc.returncode)
    summary=read(out/'summary.json');cells.append(summary);print(name,json.dumps(summary),flush=True)
    if not summary['qualified']:
        save(HERE/'terminal.json',{'status':'complete command did not meet its original qualification gate','cell':name,'completed_cells':cells,'plan_sha256':sha(HERE/'plan.json')})
        break
else:
    save(HERE/'terminal.json',{'status':'all four complete-command comparisons passed','completed_cells':cells,'plan_sha256':sha(HERE/'plan.json')})
