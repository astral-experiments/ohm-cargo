"""Run only the registered stock control studies and seal their output paths."""
from pathlib import Path
import sys,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from plan import *
from run import boundary
from stock import discover,lock
for cohort in ('initial','replica'):
    while not (ROOTS/cohort/'common-ready.json').is_file():
        boundary(cohort,'test','waiting for the excluded pristine baseline seed')
        time.sleep(4)
    discover(cohort)
lock()
