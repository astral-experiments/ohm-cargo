"""Independent stock A/A control over every real linker capsule from each checkout."""
import array
import fcntl
import mmap
import os
from pathlib import Path
import re
import subprocess
import termios
import time

from elf_equivalence import uv_elf
from plan import *

def token_count(fd):
    count=array.array('i',[0]);fcntl.ioctl(fd,termios.FIONREAD,count,True)
    return count[0]

def byte_differences(a,b):
    need(a.stat().st_size==b.stat().st_size,'stock replay changed file length')
    changes=[]
    with a.open('rb') as fa,b.open('rb') as fb,mmap.mmap(fa.fileno(),0,access=mmap.ACCESS_READ) as aa,mmap.mmap(fb.fileno(),0,access=mmap.ACCESS_READ) as bb:
        for at in range(0,len(aa),65536):
            x=aa[at:at+65536];y=bb[at:at+65536]
            if x==y:continue
            changes.extend([at+i,u,v] for i,(u,v) in enumerate(zip(x,y)) if u!=v)
            need(len(changes)<=33,'more stock differences than the registered ELF fields contain')
    return changes

def replay_provenance(cohort,out,root,target,units,captures,files,eligible):
    from run import boundary
    replay=out/'replays';replay.mkdir()
    env0={k:v for k,v in os.environ.items() if not k.startswith(('OHM_','WILD_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','RUSTC_WRAPPER','RUSTFLAGS','LD_PRELOAD')}
    role_paths={u['wild_output']:r for r,u in units.items() if 'wild_output' in u}
    bundles={};scripts=list(captures.glob('*/run-with'));need(len(scripts)==5,'stock Wild did not capture exactly five links')
    for script in scripts:
        lines=[x.split(': ',1)[1] for x in script.read_text().splitlines() if x.startswith('# Original output file: ')]
        need(len(lines)==1,'capture lacks unique original destination')
        path=str(Path(lines[0]).relative_to(target))
        need(path in role_paths and path not in bundles,'unexpected or duplicate capture target')
        bundles[path]=script
    proofs={}
    for path,role in sorted(role_paths.items()):
        script=bundles[path];cap=script.parent;out_file=replay/'same-output'
        recorder=replay/(role+'-argv.json')
        subprocess.run(['bash',script,WORK/'round18-linker/grab-args.py'],env=env0|{'WILD_REPLAY_ARGS':str(recorder),'OUT':str(out_file)},check=True)
        rec=read(recorder);save(replay/(role+'-argv-as-saved.json'),rec)
        av=rec['args'];n=av.index('-dynamic-linker')+1
        interp='/'+str(Path(av[n]).relative_to(cap))
        header=subprocess.check_output(['readelf','-l',target/path],text=True)
        need(interp==re.search(r'Requesting program interpreter: ([^]]+)',header)[1],'capture ELF interpreter rebasing could not be verified')
        av[n]=interp;save(recorder,rec)
        need(av[av.index('-o')+1]==str(out_file) and not any(v in ('--no-fork','--fork') or v.startswith('--threads') for v in av),'unexpected captured link options')
        rows={}
        for slots in [0,7]:
            boundary(cohort,'test',f'before excluded stock A/A {role} {slots} physical tokens')
            read_fd,write_fd=os.pipe();tokens=b'1234567'[:slots]
            if slots:os.write(write_fd,tokens)
            try:
                need(token_count(read_fd)==slots,'wrong initial jobserver count')
                env=env0|rec['env']|{'CARGO_MAKEFLAGS':f'-j --jobserver-fds={read_fd},{write_fd} --jobserver-auth={read_fd},{write_fd}'}
                proc=subprocess.run([str(root/'tools/wild'),*av],env=env,pass_fds=(read_fd,write_fd),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                initial_after=token_count(read_fd)
                cleanup_start=time.monotonic();deadline=cleanup_start+5
                after=initial_after
                while after!=slots and time.monotonic()<deadline:
                    time.sleep(.005)
                    after=token_count(read_fd)
                cleanup_wait=time.monotonic()-cleanup_start
                ret=os.read(read_fd,after) if after else b''
                need(after==slots and sorted(ret)==sorted(tokens),'stock jobserver tokens were lost or fabricated')
            finally:
                os.close(read_fd);os.close(write_fd)
            (replay/f'{role}-{slots}.stdout').write_bytes(proc.stdout);(replay/f'{role}-{slots}.stderr').write_bytes(proc.stderr)
            need(proc.returncode==0 and not proc.stdout and not proc.stderr,'stock replay diagnostics or status changed')
            dest=replay/f'{role}-{slots}.elf';os.replace(out_file,dest)
            rows[slots]={'file':dest.name,'size':dest.stat().st_size,'raw_sha256':sha(dest),'slots':slots,'jobserver_tokens_before':tokens.hex(),'jobserver_tokens_after':ret.hex(),'status':proc.returncode,'tokens_at_foreground_exit':initial_after,'cleanup_wait_s':cleanup_wait}
        native=files[path];digests={a['raw_sha256'] for a in rows.values()}
        need(native['sha256'] in digests,'neither stock replay reproduced the native Cargo output bytes')
        variation=len(digests)>1
        result={'path':path,'captured_script_sha256':sha(script),'argv_sha256':sha(recorder),'verified_elf_interpreter':interp,'native_sha256':native['sha256'],'rows':rows,'raw_variant_demonstrated':variation,'cpu_affinity':list(sorted(os.sched_getaffinity(0)))}
        if variation:
            need(role in eligible,f'unregistered logical role had a stock raw variant: {role}')
            parts=[uv_elf(replay/rows[s]['file']) for s in (0,7)]
            x,y=[p['normalized_fields'] for p in parts]
            need(parts[0]['size']==parts[1]['size'] and parts[0]['canonical_sha256']==parts[1]['canonical_sha256'],'bytes differ outside pre-existing ELF field scope')
            need(x['rodata'][:2]==y['rodata'][:2] and x['build_id'][:2]==y['build_id'][:2],'ELF field offsets moved')
            need({x['rodata'][2],y['rodata'][2]}=={0,8} and x['build_id'][2]!=y['build_id'][2],'stock variants do not have both registered field differences')
            changes=byte_differences(*[replay/rows[s]['file'] for s in (0,7)])
            other=[d for d in changes if not x['build_id'][0]<=d[0]<x['build_id'][1]]
            need(len(other)==1 and other[0][0]==x['rodata'][0] and {other[0][1],other[0][2]}=={0,8},'stock A/A has unexplained differences')
            result.update(canonical_sha256=parts[0]['canonical_sha256'],normalized_fields=[x,y],changed_bytes=changes)
        proofs[role]=result;save(replay/(role+'-proof.json'),result)
    return proofs
