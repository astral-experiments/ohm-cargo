"""Make the path-provenance amendment without changing its v1 measurement machinery."""
from pathlib import Path
p=Path(__file__).resolve().parent
old=p.parent/'command'
def replace_once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def save(name,s):
    path=p/name
    if path.exists():assert path.read_text()==s
    else:path.write_text(s)
for name in ('trace.py','calibrate.py','calibrate.c','elf_equivalence.py','warm_process.py','wrap.py','calibration','control'):
    dest=p/name
    if not dest.is_symlink():dest.symlink_to(Path('..')/'command'/name)
s=(old/'plan.py').read_text()
s=replace_once(s,"WRAP = HERE / 'wrap.py'","WRAP = OUTER / 'command/wrap.py'  # Keep the private wrapper and tool paths fixed.")
save('plan.py',s)
s=(old/'run.py').read_text()
s=replace_once(s,"def artifact_hashes(records, tests, target, source):","def artifact_hashes(records, tests, target, source, stock_discovery=False):")
s=replace_once(s,"    allowed=set(read(OUTER/'plan.json')['macro_allowed_elf_variants_by_relative_path'])\n    need(allowed<={str(f.relative_to(target)) for f in linked},'known ELF role names changed')","""    allowed=set()
    if not stock_discovery:
        binding=read(HERE/'plan.json')['stock_path_bindings'][target.parent.name]
        linked_paths={str(f.relative_to(target)) for f in linked}
        emitted_paths={str(f.relative_to(target)) for f in outputs}
        need(linked_paths==set(binding['linked_paths']),'stock-registered Wild output paths changed')
        need(emitted_paths==set(binding['emitted_paths']),'stock-registered test paths changed')
        allowed=set(binding['allowed'])
        need(allowed<=linked_paths,'stock-registered exception is outside linked paths')""")
s=replace_once(s,'def run(root, command, ep, log, mode, kind):','def run(root, command, ep, log, mode, kind, capture=None):')
s=replace_once(s,'    argv=[str(WRAP)',"""    if capture is not None:
        need(mode=='native' and kind=='stock-discovery','capture reserved for excluded distributed controls')
        need(os.path.samefile(paths['wild'],t/'arms/shipped-wild'),'capture requires stock Wild')
        env['WILD_SAVE_BASE']=str(capture)
    argv=[str(WRAP)""")
s=replace_once(s,'if mode=="native" and kind=="admit":','if mode=="native" and kind in ("admit","stock-discovery"):')
s=replace_once(s,'oracle=artifact_hashes(records,tests,target,src)',"oracle=artifact_hashes(records,tests,target,src,stock_discovery=kind=='stock-discovery')")
s=replace_once(s,'need(v.selection in p[\'macro_cohorts\'],\'expected a registered cell\')',"""need(v.selection in p['macro_cohorts'],'expected a registered cell')
        v2=read(HERE/'plan.json')
        need(sha(HERE/'plan.json')==(HERE/'registration.sha256').read_text().split()[0],'unfrozen replacement plan')
        need(v2['original_plan_sha256']==sha(OUTER/'plan.json') and v2['original_macro_cohorts']==p['macro_cohorts'],'prior component choices, orders and source edits changed')
        need(v2['scope_sha256']==sha(HERE/'STOCK-PATH-REGISTRATION.md') and v2['sealed_sha256']==sha(HERE/'sealed.json'),'stock provenance registration changed')
        for cohort,b in v2['stock_path_bindings'].items():
            need(b['proof_sha256']==sha(HERE/'stock'/cohort/'binding.json'),'stock A/A evidence changed')""")
s=replace_once(s,"'derive.py','warm_process.py'","'derive.py','warm_process.py','stock.py','stock_replay.py','STOCK-PATH-REGISTRATION.md'")
save('run.py',s)
s=(old/'verify.py').read_text()
s=replace_once(s,"allowed=set(plan['macro_allowed_elf_variants_by_relative_path'])","""v2=read(here/'plan.json');assert v2['original_plan_sha256']==sha(here.parent/'plan.json')
    binding=v2['stock_path_bindings'][cfg['cohort']];allowed=set(binding['allowed'])
    assert binding['proof_sha256']==sha(here/'stock'/cfg['cohort']/'binding.json')""")
s=replace_once(s,"'samples_sha256':sha(out/'samples.csv')","'stock_path_plan_sha256':sha(here/'plan.json'),'samples_sha256':sha(out/'samples.csv')")
save('verify.py',s)
