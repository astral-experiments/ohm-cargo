"""Inspect the parked EH worker or release it once the host owner gives it a slot."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
CONTROL = HERE.parent / "command/control"
MARKER = WORK / "round18-lab/host-cleared-for-native"
PLAN_SHA = "e7e3d236d3700c40b7bf20e4d5170bcd894a64777ee88695b4d4df4dd9eb31b3"
FREE_FLOOR = 120 * 2**30
CLONE_BUDGET = 36 * 2**30


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allocation", type=Path, help="Fresh explicit owner release receipt. Omit for read-only status.")
    parser.add_argument("--expected-boundary", help="Exact status boundary read from the parked worker.")
    parser.add_argument("--live-session", type=int, help="Poll the original exec session before release, then pass its still-running ID.")
    parser.add_argument("--projected-temporary-gib",type=float,help="Current observed remaining target growth for the next cell.")
    parser.add_argument("--other-reserved-gib",type=float,default=0,help="Additional temporary space committed to other workers.")
    args = parser.parse_args()
    assert sha(HERE / "plan.json") == PLAN_SHA
    state = json.loads((CONTROL / "status.json").read_text())
    pid = state["pid"]
    proc = Path(f"/proc/{pid}")
    visible = proc.exists() and b"measure_driver.py" in (proc / "cmdline").read_bytes()
    free = shutil.disk_usage(HERE).free
    print(json.dumps(dict(state=state, worker_pid_visible_in_current_namespace=visible, held_exec_session=19295, native_marker=MARKER.exists(),
                          paused=(CONTROL / "pause").exists(), free_bytes=free,
                          next_cell_reserve_bytes=FREE_FLOOR+CLONE_BUDGET)))
    if args.allocation is None:
        return
    assert not MARKER.exists(), "exclusive native timing is active"
    assert (CONTROL / "pause").is_file() and state["state"] == "paused"
    assert args.live_session == 19295, "poll held exec session 19295 immediately before an owner-authorized handoff"
    assert args.expected_boundary == state["boundary"]
    if visible:
        assert set(os.sched_getaffinity(pid)) == set(range(16, 24))
    assert args.allocation.stat().st_mtime_ns >= (CONTROL / "pause").stat().st_mtime_ns
    assert json.loads(args.allocation.read_text()), "empty owner allocation"
    assert args.projected_temporary_gib is not None and args.projected_temporary_gib >= 0 and args.other_reserved_gib >= 0
    protected = FREE_FLOOR + max(CLONE_BUDGET, int(args.projected_temporary_gib * 2**30)) + int(args.other_reserved_gib*2**30)
    assert free >= protected, "current projection plus the protected reserve would be consumed"
    stamp = time.time_ns()
    receipt = dict(utc_unix_ns=stamp, plan_sha256=PLAN_SHA, allocation=str(args.allocation.resolve()),
                   allocation_sha256=sha(args.allocation), released_boundary=state["boundary"],
                   worker_pid=pid, free_bytes=free, floor_bytes=FREE_FLOOR, protected_before_release=protected)
    handoffs = HERE / "handoffs"
    handoffs.mkdir(exist_ok=True)
    # Arm the existing observer before lifting the original pause flag, so the real worker
    # and the reserve observer share exactly the same release handshake.
    watcher = (
        "import os,pathlib,sys,time\n"
        "p=pathlib.Path(sys.argv[1])\n"
        "while p.exists(): time.sleep(.1)\n"
        "os.execv(sys.executable,[sys.executable,'-u','-B',sys.argv[2]])\n"
    )
    with (handoffs / f"{stamp}-disk.log").open("xb") as output:
        guard = subprocess.Popen(["taskset", "-c", "16", sys.executable, "-c", watcher,
                                  str(CONTROL / "pause"), str(HERE / "disk-guard-resumed.py")],
                                 stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    assert guard.poll() is None and not MARKER.exists()
    receipt.update(observer_pid=guard.pid, live_exec_session=args.live_session)
    with (handoffs / f"{stamp}.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    (CONTROL / "pause").unlink()
    print(json.dumps(receipt))
    # Keep the watcher attached to this fresh exec session until the next original
    # pause, including on hosts with a PID namespace per API shell invocation.
    sys.stdout.flush()
    raise SystemExit(guard.wait())


if __name__ == "__main__":
    main()
