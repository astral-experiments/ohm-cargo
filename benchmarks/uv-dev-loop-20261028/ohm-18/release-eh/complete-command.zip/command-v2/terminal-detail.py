"""Summarize closed contrasts without using host state, including every raw-byte exception."""
import csv,json,statistics
from pathlib import Path
here=Path(__file__).resolve().parent
def read(f):return json.loads(f.read_text())
def detail(summary):
    key=summary['cell'];cohort,control=key.split('-',1);d=here/'results'/cohort/control
    count={name:[] for name in [control,'candidate']};roles=['cargo','rustc','wild','total'];deltas={role:[] for role in roles}
    proof=read(here/'stock'/cohort/'binding.json')
    role_by_path={rec['path']:role for role,rec in proof['proof'].items()}
    expected_products=set(proof['linked_paths'])|set(proof['emitted_paths'])
    rows=list(csv.DictReader((d/'samples.csv').open()));assert len(rows)==16
    pairs=[]
    for i in range(8):
        a={x['arm']:x for x in rows[2*i:2*i+2]};records={arm:read(d/r['receipt']) for arm,r in a.items()}
        for arm,rec in records.items():
            assert set(rec['files'])==expected_products and rec['roster']['role_counts']=={'cargo':1,'rustc':6,'wild':5}
            count[arm].append({role:int(a[arm][role]) for role in roles})
        for role in roles:deltas[role].append(int(a[control][role])-int(a['candidate'][role]))
        pair={'pair':i,'source_sha256':a[control]['source_sha256'],'products':len(expected_products),'raw_differences':[]}
        for path,raw in records[control]['files'].items():
            other=records['candidate']['files'][path];assert raw['canonical_sha256']==other['canonical_sha256'] and raw['size']==other['size']
            if raw['sha256']==other['sha256']:continue
            assert path in proof['allowed'] and raw['permitted_fields'] and other['permitted_fields']
            pair['raw_differences'].append({'role':role_by_path[path],'path':path,control:raw,'candidate':other})
        pairs.append(pair)
    return {'cell':key,'median_instructions':{arm:{role:statistics.median([s[role] for s in records]) for role in roles} for arm,records in count.items()},'paired_instruction_deltas_control_minus_candidate':deltas,'raw_identical_pairs':sum(not p['raw_differences'] for p in pairs),'product_comparisons':sum(p['products'] for p in pairs),'raw_variant_comparisons':sum(len(p['raw_differences']) for p in pairs),'product_pairs':pairs}
if __name__=='__main__':
    terminal=read(here/'terminal.json')
    result={'plan':terminal['plan_sha256'],'details':[detail(s) for s in terminal['completed_cells']]}
    name=here/'terminal-detail.json'
    if name.is_file():assert read(name)==result
    else:name.write_text(json.dumps(result,indent=2)+'\n')
