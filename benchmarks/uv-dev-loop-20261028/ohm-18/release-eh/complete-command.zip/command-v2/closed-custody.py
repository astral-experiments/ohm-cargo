"""Seal the verified closure of one real EH cell after the two auxiliary sessions return."""
import argparse
import csv
import hashlib
import json
import shutil
import time
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("cell",choices=["initial-shipped","replica-base","replica-shipped"])
    p.add_argument("--sessions",type=Path,required=True,help="Actual held API session return receipts from this handoff")
    a=p.parse_args()
    h=Path(__file__).resolve().parent
    work=h.parents[1]
    cohort,control=a.cell.split("-")
    out=h/"results"/cohort/control
    shared=h/"control"
    root=Path((work/"bench-home.path").read_text().strip())/"release-eh-roles-18"/cohort
    summary=read(out/"summary.json");restore=read(out/"restore.json");complete=read(out/"complete.json")
    assert summary["samples_sha256"]==sha(out/"samples.csv") and summary["cell"]==a.cell
    assert complete==dict(pairs=8,arms=16,admission_cells=4,common_unchanged=True)
    with (out/"samples.csv").open() as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==16 and all(sum(int(r[n]) for n in ("cargo","rustc","wild"))==int(r["total"]) for r in rows)
    src=root/"source/crates/uv/src/install_source.rs"
    assert restore["home_restored"] and restore["target_vacant"] and sha(src)==restore["source_sha256"]
    assert src.stat().st_mtime_ns==restore["source_mtime_ns"] and (root/"common-ready.json").is_file() and (root/"common").is_dir()
    assert not any((root/n).exists() for n in ("structural","target","held-"+control,"held-candidate"))
    sessions=read(a.sessions)
    assert sessions["cell"]==a.cell and sessions["original"]["id"]==19295
    expected_helpers=["reserve_observer"] if a.cell=="replica-shipped" else ["reserve_observer","pair_latch"]
    for helper in expected_helpers:
        assert sessions[helper]["id"] and sessions[helper]["exit_code"]==0
    current=read(shared/"status.json")
    terminal=h/"terminal.json"
    if terminal.exists():
        assert sessions["original"]["exit_code"]==0 and read(terminal)["completed_cells"][-1]["cell"]==a.cell
        state="registered terminal result"
    else:
        following={"initial-shipped":"replica-base","replica-base":"replica-shipped"}[a.cell]
        assert sessions["original"]["alive_but_parked"] and (shared/"pause").is_file()
        assert current["boundary"]=="before complete-command study "+following and current["state"]=="paused"
        assert current["cohort"]==following.split("-")[0] and summary["qualified"]
        assert not (h/"results"/following.split("-")[0]/following.split("-")[1]/"predecessor.json").exists()
        state="registered supervisor parked before any next target clone"
    receipt=dict(custody_returned=True,cell=a.cell,state=state,verified_ns=time.time_ns(),free_bytes=shutil.disk_usage(root).free,
                 allocation_sessions=sessions,sessions_sha256=sha(a.sessions),supervisor_boundary=current,
                 summary=summary,complete=complete,restore=restore,raw_rows=len(rows),
                 preserved_common_seed=str(root/"common"),all_temporary_targets_absent=True,
                 sample_sha256=summary["samples_sha256"],summary_sha256=sha(out/"summary.json"),
                 no_new_slot_authorized=True)
    dest=h/f"custody-after-{a.cell}.json"
    tmp=dest.with_name(dest.name+".incoming")
    assert not dest.exists()
    with tmp.open("x") as f:
        json.dump(receipt,f,indent=2);f.write("\n")
    tmp.rename(dest)
    print(dest,sha(dest))


if __name__=="__main__":
    main()
