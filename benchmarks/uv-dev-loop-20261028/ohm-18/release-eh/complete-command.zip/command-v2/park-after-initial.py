"""Raise the already-registered pause after pair eight is released and before the next cell."""
import json,shutil,time
from pathlib import Path
here=Path(__file__).resolve().parent;control=here/'control';out=here/'results/initial/base'
while True:
    try:state=json.loads((control/'status.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError):
        time.sleep(.5);continue
    completed_boundary=state['cohort']=='initial' and state['boundary']=='after pair 8 of 8' and state['state']=='released'
    if completed_boundary or (out/'complete.json').exists() or (here/'terminal.json').exists():
        reason='Owner-requested native reservation after initial/base final pair; allow released-cell finalizer to finish.'
        try:
            with (control/'pause').open('x') as f:f.write(reason+'\n')
        except FileExistsError:pass
        record={'utc_unix_ns':time.time_ns(),'trigger':state,'target':'after initial/base complete cleanup, before any next target clone','free_bytes':shutil.disk_usage(here).free,'signal':(control/'pause').read_text()}
        (here/'park-after-initial.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record),flush=True);break
    time.sleep(.5)
