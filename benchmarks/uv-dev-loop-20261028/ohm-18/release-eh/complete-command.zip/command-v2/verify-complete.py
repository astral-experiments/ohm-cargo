"""Verify an unpacked terminal result, including registration, raw counters and joint decision."""
import argparse
import hashlib
import json
import runpy
import subprocess
import sys
from pathlib import Path


HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
ORDER=["initial-base","initial-shipped","replica-base","replica-shipped"]


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def terminal_rule(terminal,order):
    completed=terminal["completed_cells"]
    assert [e["cell"] for e in completed]==order[:len(completed)]
    assert len(completed)<=len(order)
    status=terminal["status"]
    if status=="all four complete-command comparisons passed":
        assert len(completed)==4 and all(e["qualified"] for e in completed)
    elif status=="complete command did not meet its original qualification gate":
        assert completed and all(e["qualified"] for e in completed[:-1]) and not completed[-1]["qualified"]
        assert terminal["cell"]==completed[-1]["cell"]
    elif status=="admission or required invariant failed":
        assert len(completed)<4 and all(e["qualified"] for e in completed)
        assert terminal["cell"]==order[len(completed)] and terminal["status_code"]!=0
    else:
        raise AssertionError(status)


def verify():
    manifest=ROOT/"MANIFEST.sha256"
    seen=set()
    for line in manifest.read_text().splitlines():
        expected,raw=line.split("  ",1); name=Path(raw)
        assert not name.is_absolute() and ".." not in name.parts and raw not in seen
        seen.add(raw)
        assert sha(ROOT/name)==expected, f"changed or missing {name}"
    found={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and p!=manifest}
    assert found==seen, f"unlisted or missing files: {sorted(found^seen)}"
    plan=read(ROOT/"plan.json")
    bound=read(HERE/"plan.json")
    assert sha(ROOT/"plan.json")==bound["original_plan_sha256"]=="831b24ff4991229569294e4a73d06b872b762628104592aa54b36601d56f2c6f"
    assert sha(HERE/"plan.json")=="e7e3d236d3700c40b7bf20e4d5170bcd894a64777ee88695b4d4df4dd9eb31b3"
    assert plan["macro_cell_order"]==bound["original_cell_order"]==ORDER
    src=read(ROOT/"source.json");bins=read(ROOT/"binaries.json");lock=read(HERE/"sealed.json")
    assert src["release_ref"]==bins["base_commit"]==plan["wild_release_ref"]
    assert sha(ROOT/"eh.patch")==src["patch_sha256"]==bins["patch_sha256"]==plan["source_patch_sha256"]
    assert sha(ROOT/"compact-focused.zip")=="200407bb96553a749875b4c528438b518f821a2f1f2b728ad0dbd03be1eb9480"
    assert all(bins["arms"][role]["binary_sha256"]==lock["arms"][role]["wild"] for role in ("base","shipped","candidate"))
    assert sha(HERE/"sealed.json")==bound["sealed_sha256"]
    assert all(sha(HERE/f)==h for f,h in lock["source_sha256"].items())
    subprocess.run([sys.executable,"-I","-B",HERE/"verify-stock.py"],check=True)
    terminal=read(HERE/"terminal.json")
    assert terminal["plan_sha256"]==sha(HERE/"plan.json")
    terminal_rule(terminal,ORDER)
    detail=runpy.run_path(str(HERE/"terminal-detail.py"))["detail"]
    expected=[]
    for cell in terminal["completed_cells"]:
        key=cell["cell"];cohort,arm=key.split("-")
        actual=read(HERE/"results"/cohort/arm/"summary.json")
        assert cell==actual
        subprocess.run([sys.executable,"-I","-B",HERE/"verify.py",key],check=True,stdout=subprocess.DEVNULL)
        expected.append(detail(actual))
    assert read(HERE/"terminal-detail.json")==dict(plan=terminal["plan_sha256"],details=expected)
    return dict(status=terminal["status"],registered_order=ORDER,verified_in_order=[c["cell"] for c in terminal["completed_cells"]],
                files=len(seen),physical_files_and_stock_elf_receipts=True,raw_threads_and_permutation_tests=True)


if __name__=="__main__":
    assert __debug__
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--self-test-policy",action="store_true");args=p.parse_args()
    if args.self_test_policy:
        cells=[{"cell":key,"qualified":True} for key in ORDER]
        terminal_rule(dict(completed_cells=cells,status="all four complete-command comparisons passed"),ORDER)
        terminal_rule(dict(completed_cells=cells[:2],status="admission or required invariant failed",cell=ORDER[2],status_code=1),ORDER)
        terminal_rule(dict(completed_cells=[cells[0],dict(cell=ORDER[1],qualified=False)],status="complete command did not meet its original qualification gate",cell=ORDER[1]),ORDER)
        try:
            terminal_rule(dict(completed_cells=cells[:2],status="all four complete-command comparisons passed"),ORDER)
        except AssertionError:
            print("All three terminal modes accepted; early joint pass rejected.")
        else:
            raise AssertionError("early pass accepted")
    else:
        print(json.dumps(verify(),indent=2))
