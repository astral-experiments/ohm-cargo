"""Use the registered final-pair boundary to park immediately before the next cell."""
import argparse
import csv
import json
import time
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("cell", choices=["initial-shipped", "replica-base"])
    args = p.parse_args()
    here = Path(__file__).resolve().parent
    cohort, control = args.cell.split("-")
    results = here/"results"/cohort/control
    shared = here/"control"
    receipt = here/f"park-after-{args.cell}.json"
    assert not receipt.exists()
    while not (here/"terminal.json").exists():
        try:
            status = json.loads((shared/"status.json").read_text())
            with (results/"samples.csv").open() as f:
                rows = list(csv.DictReader(f))
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(.5)
            continue
        if (len(rows)==16 and rows[-1]["pair"]=="7" and rows[-1]["position"]=="1" and
            status["cohort"]==cohort and status["state"]=="released" and
            status["boundary"]=="after pair 8 of 8" and
            (results/rows[-1]["receipt"]).stat().st_mtime_ns<=status["utc_unix_ns"]):
            try:
                with (shared/"pause").open("x") as f:
                    f.write(f"Owner-requested cutover after {args.cell}; finish this cell's cleanup.\n")
            except FileExistsError:
                pass
            with receipt.open("x") as f:
                json.dump(dict(cell=args.cell,trigger=status,rows=16,armed_ns=time.time_ns()),f,indent=2)
            return
        time.sleep(.5)


if __name__=="__main__":
    main()
