"""Build a self-contained, stdlib-checkable terminal result packet after the measured work stops."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile
here=Path(__file__).resolve().parent;root=here.parent
def sha(f):
    with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(f):return json.loads(f.read_text())
def entry(z,name,content):
    info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,content)
terminal=read(here/'terminal.json');stock=root/'compact-stock-registration.zip'
subprocess.run([sys.executable,'-I','-B',here/'terminal-detail.py'],check=True)
assert sha(stock)==read(root/'compact-stock-registration.json')['sha256']
out=root/'compact-complete-command.zip'
manifest={}
with zipfile.ZipFile(stock) as source,zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as dest:
    for name in source.namelist():
        if name=='MANIFEST.sha256':continue
        data=source.read(name);entry(dest,name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    additional=[root/'compact-stock-registration.json',here/'terminal.json',here/'terminal-detail.py',here/'terminal-detail.json',here/'package-result.py',here/'disk-guard-pausable.py',here/'disk-guard-resumed.py',here/'resumes.jsonl',here/'auxiliary-parked.jsonl',here/'disk-guard-events.jsonl']
    additional += [root/n for n in ('eh.patch','source.json','fresh-source-builds.json','REPRODUCE.md','mechanism.md','compact-focused.zip','verified-focused.json','partial-initial/FINAL-EVIDENCE.md')]
    additional += [here/n for n in ('verify-complete.py','closed-custody.py','owner-handoff.py','park-after-cell.py','park-after-initial.py','park-after-initial.json')]
    additional += list((here/'handoffs').glob('*.json'))+list(here.glob('owner-*.json'))+list(here.glob('custody-after-*.json'))+list(here.glob('park-after-*-*.json'))
    additional+=list((here/'results').rglob('*'))
    additional+=list(here.glob('initial-*.log'))+list(here.glob('replica-*.log'))
    for f in sorted(additional):
        if not f.is_file():continue
        name=str(f.relative_to(root));assert name not in manifest
        data=f.read_bytes();entry(dest,name,data);manifest[name]=hashlib.sha256(data).hexdigest()
    entry(dest,'MANIFEST.sha256',''.join(h+'  '+n+'\n' for n,h in sorted(manifest.items())).encode())
with tempfile.TemporaryDirectory(dir=root) as tmp:
    top=Path(tmp)
    with zipfile.ZipFile(out) as z:z.extractall(top)
    for name,h in manifest.items():assert sha(top/name)==h
    subprocess.run([sys.executable,'-I','-B',top/'command-v2/verify-complete.py'],check=True)
report={'bytes':out.stat().st_size,'sha256':sha(out),'stock_registration_zip_sha256':sha(stock),'registered_plan_sha256':sha(here/'plan.json'),'files_excluding_manifest':len(manifest),'terminal':terminal['status'],'completed_cells':[c['cell'] for c in terminal['completed_cells']],'verified_unpacked_stdlib':True}
(root/'compact-complete-command.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
