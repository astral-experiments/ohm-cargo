"""Park at the next existing boundary if the next whole target copies threaten the disk floor."""
import json,os,shutil,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;old=p.parent/'command/control';bench=Path((p.parent.parent/'bench-home.path').read_text().strip());roots=bench/'release-eh-roles-18'
floor=120*2**30;copy_allowance=14*2**30
while not (p/'terminal.json').exists():
    try:
        if (old/'pause').exists():
            with (p/'auxiliary-parked.jsonl').open('a') as stream:
                stream.write(json.dumps({'state':'disk observer exited at owner pause','utc_unix_ns':time.time_ns()})+'\n')
            break
        status=json.loads((old/'status.json').read_text());cohort=status['cohort'];root=roots/cohort
        # Admission uses one target copy at a time. Immediately after all four admission
        # commands the frozen driver creates two arm clones consecutively. Both copies
        # are budgeted before that sequence. Once samples start it only renames them.
        sampling=any((q/'samples.csv').exists() and not (q/'complete.json').exists() for q in (p/'results'/cohort).glob('*'))
        need=0 if sampling else 2
        free=shutil.disk_usage(roots).free
        # Even a settled pair needs space for its small incremental delta.
        margin=max(need*copy_allowance,2*2**30)
        if free-margin<floor:
            evidence={'cohort':cohort,'boundary':status['boundary'],'free_bytes':free,'conservative_remaining_copies':need,'bytes_per_copy':copy_allowance,'operational_margin_bytes':margin,'floor_bytes':floor,'utc_unix_ns':time.time_ns(),'pause':'original command/control/pause'}
            with (p/'disk-guard-events.jsonl').open('a') as f:f.write(json.dumps(evidence)+'\n')
            try:
                with (old/'pause').open('x') as f:f.write('EH conservative disk guard. Owner release required.\n')
            except FileExistsError:pass
            print(json.dumps(evidence),flush=True)
            break
    except (FileNotFoundError,json.JSONDecodeError,KeyError):pass
    time.sleep(2)
