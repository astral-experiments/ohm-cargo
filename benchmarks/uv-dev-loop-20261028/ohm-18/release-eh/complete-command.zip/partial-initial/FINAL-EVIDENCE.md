# Closing the four-control comparison

The registered order is `initial-base`, `initial-shipped`, `replica-base`, `replica-shipped`. Each cell has four excluded, same-source native/counted admissions followed by eight complete paired edits. The original rule requires all eight positive total-instruction effects, a median of at least 0.10%, and two-sided sign and balanced-order permutation p-values of at most 0.05 in every cell. A failed admission or the first failed cell closes the series without promoting a joint pass. Cells after that point stay unmeasured.

The owner of the existing supervisor will keep separate custody receipts for completed hardware blocks. After the series closes, run the packet builder only on an allocated reporting CPU. The command operates on existing receipts and does not rebuild or rerun uv.

```sh
python3 -IB work/round18-eh-release/command-v2/package-result.py
```

The terminal `compact-complete-command.zip` will contain the original registration and amendment, both checkouts' stock A/A proofs, release source/patch/build identities, calibrated fork accounting, process traces for native admission, full per-process argv and counters for counted commands, per-thread sums, full-file and canonical artifact hashes, original source-edit order and raw CSVs, actual restoration and custody receipts, and the terminal stop or pass decision. The separate focused link results and their exact digest accompany the complete-command evidence. The release and instrumented tool binaries, gigabyte ELF payloads and uv target trees remain outside the compact package.

After unpacking into an empty directory, run this from its root. Python's standard library is sufficient.

```sh
python3 -IB command-v2/verify-complete.py
```

The entry point verifies every manifest entry and the registered source and binary receipts, runs the existing independent stock verifier, recomputes each closed cell from raw per-thread totals, and checks source equality, all named products and both significance tests. It also regenerates the per-pair changed-file table and checks that the stored terminal decision follows the registered cell order and stop rule. An admission failure needs its recorded failure/retained-input diagnosis and can establish no performance result for that incomplete cell.

This replay audits the recorded hashes and counters without compiling. Repeating the measurements requires the published uv/Ohm source and binaries, the eight-CPU allocation, a fresh per-checkout stock path registration and the calibrated counter as described in `command-v2/README.md` and `REPRODUCE.md`. The instruction sum excludes uninstrumented drivers and the kernel. A smaller count on either checkout supplies no native elapsed-time measurement.
