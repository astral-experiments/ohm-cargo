"""Portable pure-Python analysis of fixed four-arm screen and two balanced paired confirmations."""
import csv,itertools,json,math,statistics,sys
from pathlib import Path
p=Path(__file__).resolve().parent
def summarize(path):
 xs=list(csv.DictReader(path.open()));groups={}
 for row in xs:groups.setdefault(int(row['block']),{})[row['arm']]=row
 return groups
def median(v):return statistics.median(v)
def screen(groups):
 assert len(groups)==4;result={}
 for name in ('maps','context','both'):
  diffs=[(int(g['base']['instructions'])-int(g[name]['instructions']))/int(g['base']['instructions']) for g in groups.values()];result[name]={'improvements_pct':[100*x for x in diffs],'median_pct':100*median(diffs)}
 result['qualified']=all(result[k]['median_pct']>0 for k in ('maps','context')) and result['both']['median_pct']>=0.10
 return result
def paired(groups):
 assert len(groups)==8;diffs=[];observed=[];logcon=[];assignment=[]
 for n,g in sorted(groups.items()):
  a=g['base'];b=g['both'];x,y=int(a['instructions']),int(b['instructions']);s=1 if int(a['position'])==0 else -1;assignment.append(s);v=math.log(x/y);observed.append(v);logcon.append(v*s);diffs.append(100*(x-y)/x)
  assert a['sha256']==b['sha256'] and a['stderr']==b['stderr']
 assert sum(assignment)==0
 cutoff=abs(sum(observed));permutations=[]
 for pos in itertools.combinations(range(8),4):
  mask=set(pos);permutations.append(abs(sum(t if i in mask else -t for i,t in enumerate(logcon))))
 permutation_p=sum(v+1e-15>=cutoff for v in permutations)/len(permutations)
 wins=sum(v>0 for v in diffs);losses=sum(v<0 for v in diffs);m=wins+losses;sign_p=min(1.0,2*sum(math.comb(m,i) for i in range(min(wins,losses)+1))/2**m) if m else 1
 return {'n':8,'improvements_pct':diffs,'median_pct':median(diffs),'wins':wins,'losses':losses,'ties':8-m,'sign_p':sign_p,'order_permutation_p':permutation_p,'qualified':median(diffs)>=.10 and wins==8 and sign_p<=.05 and permutation_p<=.05}
if __name__=='__main__':
 d=Path(sys.argv[1]) if len(sys.argv)>1 else p;r={'screen':screen(summarize(d/'screen/samples.csv'))}
 for k in ('0','1'):
  f=d/('confirm-'+k)/'samples.csv'
  if f.exists():r['capture-'+k]=paired(summarize(f))
 r['all_qualified']=r['screen']['qualified'] and all(r.get('capture-'+k,{}).get('qualified',False) for k in ('0','1'));print(json.dumps(r,indent=2))
