"""Build either the exact rebuilt #46 or the independent EH patch after an explicit CPU allocation."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parent
repo = work / 'ohm-wild'
base = 'e856d81f6683cad80b9fe0ebf1a0c3c403c6fe11'
head = 'db821991bd2931dd83e59f236149340ddfc2b427'
compiler = '58cf8f9c35b355199727627d07ae34a4e2846d67'
compiler_binary_sha = 'b53b780f77f952062f8ca8a3b70aef2390b1e45ad91939be94afdc9543026853'
matched_release_sha = '82a927b86f929b67c58be4d37ab8442f32fcdd115d97334dcc5ac190101d8865'
shipped_sha = '0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'
build_command = ['cargo', '+stable', 'build', '--release', '--locked', '--offline', '-p', 'wild-linker',
                 '-j4', '--message-format=json-render-diagnostics']

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def unpack_release(repo, src):
    with subprocess.Popen(['git', '-C', repo, 'archive', base], stdout=subprocess.PIPE) as export:
        subprocess.run(['tar', '-x', '-C', src], stdin=export.stdout, check=True)
        assert export.wait() == 0

def atomic_ready(path, receipt):
    tmp = path.with_name(path.name + '.tmp')
    write(tmp, receipt)
    tmp.replace(path)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('study', choices=['current-pr46', 'release-eh'])
    parser.add_argument('--allocation', required=True, type=Path)
    args = parser.parse_args()
    alloc = read(args.allocation)
    cpus = sorted(os.sched_getaffinity(0))
    assert 'released_utc' in alloc and args.study in alloc['tasks'] and cpus == sorted(alloc['cpus']), 'missing or wrong allocation'
    root = here / 'current-pr46' if args.study == 'current-pr46' else work / 'round18-eh-release'
    final = root / ('ready.json' if args.study == 'current-pr46' else 'binaries.json')
    assert not final.exists(), 'immutable completed receipt exists'
    src = root / 'src'
    src.mkdir()
    logs = root / 'build-logs'
    logs.mkdir()
    unpack_release(repo, src)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('WILD_', 'OHM_', 'CARGO_PROFILE_'))
           and k not in ('CARGO_MAKEFLAGS', 'MAKEFLAGS', 'MFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTFLAGS',
                         'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WORKSPACE_WRAPPER', 'LD_PRELOAD')}
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_HOME=str(work / 'cargohome'),
               CARGO_TARGET_DIR=str(work / 'wild-target'), CARGO_INCREMENTAL='0')
    rustc_path = subprocess.check_output(['rustup', 'which', '--toolchain', 'stable', 'rustc'], text=True).strip()
    cargo_path = subprocess.check_output(['rustup', 'which', '--toolchain', 'stable', 'cargo'], text=True).strip()
    rustc_version = subprocess.check_output([rustc_path, '-vV'], text=True)
    cargo_version = subprocess.check_output([cargo_path, '-V'], text=True).strip()
    assert f'commit-hash: {compiler}' in rustc_version and sha(rustc_path) == compiler_binary_sha
    assert cargo_version == 'cargo 1.99.1 (5f94df478 2026-08-27)', cargo_version

    def build(name, out):
        log = logs / f'{name}.log'
        with log.open('wb') as stream:
            subprocess.run(build_command, cwd=src, env=env, stdout=stream, stderr=stream, check=True)
        artifacts = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
        wild = next(a['executable'] for a in artifacts if a.get('reason') == 'compiler-artifact'
                    and a['target']['name'] == 'wild' and a.get('executable'))
        tmp = out.with_name(out.name + '.tmp')
        shutil.copy2(wild, tmp)
        tmp.replace(out)
        return {'binary_sha256': sha(out), 'bytes': out.stat().st_size, 'build_log_sha256': sha(log),
                'version': subprocess.check_output([out, '--version'], text=True).strip()}

    common = {'base_commit': base, 'build_command': build_command, 'compiler_commit': compiler,
              'compiler_sha256': sha(rustc_path), 'cargo_executable_sha256': sha(cargo_path),
              'rustc_version': rustc_version, 'cargo_version': cargo_version, 'cpus': cpus,
              'allocation_sha256': sha(args.allocation), 'builder_sha256': sha(Path(__file__)),
              'cargo_incremental': 0, 'completed_utc': None}
    if args.study == 'current-pr46':
        subprocess.run(['python3', root / 'prepare-source.py'], check=True)
        proof = read(root / 'tree-proof.json')
        assert proof['head_tree'] == '13d76585a97c428380410425f8db06dcb75ba885' and proof['source_commit'] == head
        for path, record in proof['overlay_files'].items():
            src_file = root / 'overlay' / path
            assert sha(src_file) == record['sha256']
            shutil.copyfile(src_file, src / path)
        lock = sha(src / 'Cargo.lock')
        assert lock == read(root / 'request.json')['expected_cargo_lock_sha256']
        fetch = ['cargo', '+stable', 'fetch', '--locked', '--target', 'x86_64-unknown-linux-gnu']
        with (logs / 'source-fetch.log').open('wb') as stream:
            if subprocess.run([*fetch, '--offline'], cwd=src, env=env, stdout=stream, stderr=stream).returncode:
                subprocess.run(fetch, cwd=src, env=env, stdout=stream, stderr=stream, check=True)
        receipt = {**common, **build('current-pr46', root / 'wild'), 'source_commit': head,
                   'source_tree': proof['head_tree'], 'tree_proof_sha256': sha(root / 'tree-proof.json'),
                   'cargo_lock_sha256': lock}
    else:
        source = read(root / 'source.json')
        f = src / source['changed_files'][0]
        lock = sha(src / 'Cargo.lock')
        assert sha(f) == source['source_sha256'] and lock == source['release_cargo_lock_sha256']
        plan_sha = (root / 'registration.sha256').read_text().split()[0]
        assert sha(root / 'plan.json') == plan_sha, 'prospective plan changed'
        out = root / 'bin'
        out.mkdir()
        arms = {'base': build('base', out / 'base')}
        assert arms['base']['binary_sha256'] == matched_release_sha, 'source-matched bare release did not reproduce'
        patch = root / 'eh.patch'
        assert sha(patch) == source['patch_sha256']
        subprocess.run(['patch', '--fuzz=0', '-p1', '-i', patch], cwd=src, check=True)
        assert sha(f) == source['candidate_source_sha256'] and sha(src / 'Cargo.lock') == lock
        arms['candidate'] = build('candidate', out / 'candidate')
        assert arms['candidate']['binary_sha256'] != matched_release_sha
        stock = work / 'upstream-monitor/toolchain18/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
        assert sha(stock) == shipped_sha
        shutil.copy2(stock, out / 'shipped')
        assert sha(out / 'shipped') == shipped_sha
        arms['shipped'] = {'binary_sha256': shipped_sha, 'bytes': stock.stat().st_size, 'origin': str(stock.relative_to(work))}
        receipt = {**common, 'source_commit': base, 'patch_sha256': source['patch_sha256'],
                   'cargo_lock_sha256': lock, 'arms': arms, 'plan_sha256': plan_sha}
    receipt['completed_utc'] = datetime.now(UTC).isoformat()
    atomic_ready(final, receipt)
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    main()
