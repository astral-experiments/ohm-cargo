"""Recheck the direct-release link receipts without Git, source checkouts, binaries or third-party packages."""
import csv
import hashlib
import itertools
import json
import math
import statistics
import sys
from pathlib import Path

p = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_text())
def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def recompute(rows, control):
    effects=[];position_delta=[];observed=[]
    for i in range(0,len(rows),2):
        x,y=sorted(rows[i:i+2],key=lambda r:r['arm']!=control)
        assert x['arm']==control and y['arm']=='candidate'
        a=int(x['instructions']);b=int(y['instructions'])
        effects.append(100*(a-b)/a)
        value=math.log(a/b);observed.append(value)
        position_delta.append(value if int(x['position'])==0 else -value)
    score=abs(sum(observed))
    fake=[abs(sum(v if i in positive else -v for i,v in enumerate(position_delta))) for positive in itertools.combinations(range(8),4)]
    wins=sum(v>0 for v in effects);losses=sum(v<0 for v in effects);n=wins+losses
    sign_p=min(1,2*sum(math.comb(n,i) for i in range(min(wins,losses)+1))/2**n) if n else 1
    return {'median_pct':statistics.median(effects),'wins':wins,'sign_p':sign_p,'order_permutation_p':sum(v+1e-15>=score for v in fake)/len(fake)}

def main():
    plan=read(p/'plan.json');outer=h(p/'plan.json')
    assert outer==(p/'registration.sha256').read_text().split()[0]
    assert h(p/'PROTOCOL.md')==plan['protocol_sha256'] and h(p/'register.py')==plan['plan_code_sha256']
    assert h(p/'eh.patch')==plan['source_patch_sha256'] and read(p/'source.json')==plan['source']
    b=read(p/'binaries.json'); ids={k:v['binary_sha256'] for k,v in b['arms'].items()}
    assert b['plan_sha256']==outer and b['source_commit']==plan['wild_release_ref']
    assert ids['base']==plan['source_matched_baseline_sha256'] and ids['shipped']==plan['shipped_wild_baseline_sha256']
    assert len(set(ids.values()))==3
    assert all(not a['fresh'] for group in read(p/'fresh-source-builds.json').values() for a in group.values())
    l=read(p/'focused-input-lock.json');assert l['plan_sha256']==outer and l['binaries_sha256']==h(p/'binaries.json')
    suite=read(p/'official-tests/summary.json')
    assert len(suite)==8 and all(q['returncode']==0 for q in suite.values())
    assert all(h(p/'official-tests'/f'{name}.log')==q['log_sha256'] for name,q in suite.items())
    fixtures=read(p/'fixture-results/summary.json')
    assert set(fixtures)==set(plan['probes'])
    for case,g in fixtures.items():
        assert set(g)==set(ids)
        assert len({(x['status'],x['diagnostic_sha256'],x['output_sha256']) for x in g.values()})==1
        for arm,x in g.items():
            assert x['matched'] and x['expected'] and h(p/f'fixture-results/{case}-{arm}.log')==x['diagnostic_sha256']
    d=p/'focused';summary=read(d/'summary.json');assert summary['plan_sha256']==outer and summary['entry_gate_qualified']
    gate=read(d/'receipt.json')
    assert gate['plan_sha256']==outer and gate['input_lock_sha256']==h(p/'focused-input-lock.json') and gate['single_worker']
    assert len(gate['affinity'])==1 and gate['affinity'][0] in l['allowed_cpus']
    intake=read(d/'admission.json')
    def raw(tag, row, counted):
        assert (d/'raw'/f'{tag}.stdout').read_bytes()==b''
        data=(d/'raw'/f'{tag}.stderr').read_bytes()
        if not counted:
            assert data==b''
            return
        assert data.startswith(b'DynamoRIO ')
        wrap=json.loads(data.removeprefix(b'DynamoRIO '))
        assert wrap['instructions']==int(row['instructions'])==sum(wrap['threads'].values())
        assert wrap['pid']==int(row['pid']) and str(wrap['pid']) in wrap['threads']
    for shape,records in intake.items():
        assert [r['arm'] for r in records]==['base','shipped','candidate']
        for pos,r in enumerate(records):
            assert r['returncode']==0 and r['sha256']==plan['captures'][shape]['one_worker_file_sha256']
            raw(f'admit-{shape}-00-{pos}-{r["arm"]}',r,False)
    tiny=plan['tiny_descriptive_control'];tinyrows=read(d/'tiny.json')
    assert [r['arm'] for r in tinyrows]==tiny['order']
    for pos,r in enumerate(tinyrows):
        assert r['returncode']==0 and r['sha256']==plan['captures'][tiny['capture']]['one_worker_file_sha256']
        raw(f'tiny-{tiny["capture"]}-00-{pos}-{r["arm"]}',r,True)
    results={}
    for key,cfg in plan['focused_cells'].items():
        with (d/f'{key}.csv').open() as s:rows=list(csv.DictReader(s))
        assert len(rows)==16 and sum(q[0]==cfg['control'] for q in cfg['pairs'])==4
        for i,order in enumerate(cfg['pairs']):
            for j,arm in enumerate(order):
                r=rows[2*i+j];shape=cfg['capture']
                assert (int(r['block']),int(r['position']),r['arm'])==(i,j,arm)
                assert r['sha256']==plan['captures'][shape]['one_worker_file_sha256'] and int(r['returncode'])==0
                assert r['stderr']==hashlib.sha256(b'').hexdigest()
                raw(f'{key}-{shape}-{i:02}-{j}-{arm}',r,True)
        got=recompute(rows,cfg['control'])
        for field,value in got.items():assert abs(value-summary['cells'][key][field])<1e-10,(key,field)
        assert got['wins']==8 and got['median_pct']>=.10 and got['sign_p']<=.05 and got['order_permutation_p']<=.05
        results[key]=got
    print(json.dumps({'verified':True,'plan_sha256':outer,'summary_sha256':h(d/'summary.json'),'scored_output_matches':64,'cells':results},indent=2))
if __name__=='__main__':
    main()
