from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
p=Path(__file__).resolve().parent;w=p.parent;src=p/'src';assert (p/'focused-input-lock.json').exists();d=p/'official-tests';d.mkdir();report={}
def wait_window():
 while (p/'pause.requested').exists():time.sleep(.2)
def run(name,cmd):
 wait_window();print(name,flush=True);log=d/(name+'.log')
 with log.open('wb') as s:result=subprocess.run(cmd,cwd=src,env=env,stdout=s,stderr=s,timeout=600)
 text=log.read_text(errors='replace');report[name]={'command':list(map(str,cmd)),'returncode':result.returncode,'results':re.findall(r'test result: [^\n]+',text),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};(d/'summary.json').write_text(json.dumps(report,indent=2)+'\n');return text if result.returncode==0 else None
env={k:v for k,v in os.environ.items() if k not in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTFLAGS','RUSTC','RUSTC_WRAPPER','LD_PRELOAD') and not k.startswith(('WILD_','OHM_'))};env.update(RUSTUP_TOOLCHAIN='stable',CARGO_HOME=str(w/'cargohome'),CARGO_TARGET_DIR=str(w/'wild-unit-target'),WILD_TEST_BUILD_DIR=str(d/'objects'),PATH=str(w/'wild-test-tools/bin')+':'+env['PATH'])
s=json.loads((p/'source.json').read_text());assert hashlib.sha256((src/s['changed_files'][0]).read_bytes()).hexdigest()==s['candidate_source_sha256']
cargo=['cargo','+stable','test','--locked','--offline','-j4']
unit=run('libwild',cargo+['-p','libwild','--lib'])
t=run('compile-integration',cargo+['-p','wild-linker','--test','integration_tests','--no-run','--message-format=json-render-diagnostics']);assert t is not None
entries=[json.loads(x) for x in t.splitlines() if x.startswith('{')];h=next(x['executable'] for x in entries if x.get('reason')=='compiler-artifact' and x['target']['name']=='integration_tests' and x['executable'])
groups=['eh-frame','eh-frame-terminator','crtend-only-eh-frame','dynsym-debug-eh-frame','relocation-overflow','backtrace']
for name in groups:
 t=run(name,[h,'elf/x86_64/'+name+'/','--color','never']);assert t is None or any(int(x)>0 for x in re.findall(r'(\d+) passed;',t)),(name,t)
raise SystemExit(any(x['returncode'] for x in report.values()))
