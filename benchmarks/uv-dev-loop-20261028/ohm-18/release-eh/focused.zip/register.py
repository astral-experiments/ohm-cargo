"""Freeze the direct-release source, two controls, workload, endpoint, and order before building."""
import hashlib
import json
import random
import subprocess
from datetime import UTC, datetime
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parent
read = lambda p: json.loads(p.read_text())
digest = lambda data: hashlib.sha256(data).hexdigest()
old = read(work / 'round18-eh/plan.json')
shipped = read(work / 'round18-lab/host-receipt.json')['shipped_sha256']
aa = read(work / 'round18-uvx-admission/summary.json')
capture = aa['all_role_summaries']
old_one_worker = read(work / 'round18-eh/known-parent-variants.json')['captures']
assert all(capture[k]['one_slot'] == v['one_slot'] for k, v in old_one_worker.items())
src = read(here / 'source.json')
uv = 'c22e6b71933443e9cd299d4b6ac8de035ed4825b'
edit = 'crates/uv/src/install_source.rs'
original = subprocess.check_output(['git', '-C', work / 'uv', 'show', f'{uv}:{edit}'])
before = b'component == cellar && next == formula'
assert original.count(before) == 1
assert src['patch_sha256'] == digest((here / 'eh.patch').read_bytes())

def pairs(arm, seed):
    orders = [[arm, 'candidate'], ['candidate', arm]] * 4
    random.Random(seed).shuffle(orders)
    return orders

def edited(symbol, idx):
    replacement = ('{\n                component == cellar && (next == formula || next == OsStr::new('
                   + f'"uv-eh-{symbol}{idx:02d}"))\n            }}')
    return original.replace(before, replacement.encode())

focus = {}
for key, ref, seed in [('0', 'base', 71527091), ('0', 'shipped', 98536311),
                       ('1', 'base', 45639101), ('1', 'shipped', 97154263)]:
    focus[f'{key}-{ref}'] = {'capture': key, 'control': ref, 'seed': seed, 'pairs': pairs(ref, seed)}
macro = {}
for cohort, arm, symbol, seed in [('initial', 'base', 'FV', 71245033), ('initial', 'shipped', 'FZ', 86209131),
                                  ('replica', 'base', 'HV', 13460987), ('replica', 'shipped', 'HZ', 24539161)]:
    rng = random.Random(seed + 1)
    ids = list(range(10, 18))
    rng.shuffle(ids)
    modes = [['native', arm], ['native', 'candidate'], ['count', arm], ['count', 'candidate']]
    rng.shuffle(modes)
    macro[f'{cohort}-{arm}'] = {'cohort': cohort, 'control': arm, 'literal_family': symbol, 'seed': seed,
                               'native_count_admission': modes,
                               'edits': {str(i): digest(edited(symbol, i)) for i in (0, 1, *ids)},
                               'pairs': [{'id': i, 'order': order} for i, order in zip(ids, pairs(arm, seed))]}
assert len({s for row in macro.values() for s in row['edits'].values()}) == 40
support = [
    'round18-eh/known-parent-variants.json', 'round18-linker/confirm18/inputs.json',
    'round18-linker/confirm18/intake.json', 'round18-uvx-admission/summary.json',
    'round18-eh/analysis.py', 'round18-eh/fixtures/frame.s', 'round18-eh/fixtures/gap.ld',
    'round18-lab/elf_equivalence.py', 'round18-cargo/edited-roles/run.py',
    'round18-cargo/edited-roles/plan.py', 'tree-count/wrap.py', 'tree-count/identical.py',
    'tree-count/calibrate.py', 'tree-count/calibrate.c', 'dynamorio/count.py',
    'edit-link-profile/native-instrument/count.py',
]
allowed = sorted(v['product'] for v in aa['all_role_summaries'].values() if v['exact_differing_bytes'] == 33)
assert len(allowed) == 4
plan = {
    'registered_utc': datetime.now(UTC).isoformat(), 'plan_version': 1, 'source': src,
    'protocol_sha256': digest((here / 'PROTOCOL.md').read_bytes()), 'plan_code_sha256': digest(Path(__file__).read_bytes()),
    'builder_sha256': digest((work / 'round18-linker/build-anchored.py').read_bytes()),
    'support_sha256': {f: digest((work / f).read_bytes()) for f in support},
    'uv': uv, 'uv_edit_file': edit, 'uv_edit_preimage_sha256': digest(original),
    'shipped_toolchain': shipped, 'wild_release_ref': src['release_ref'], 'source_patch_sha256': src['patch_sha256'],
    'source_matched_baseline_sha256': src['matched_release_control_reference_sha256'],
    'shipped_wild_baseline_sha256': src['shipped_control_sha256'], 'treatment_sha256': None,
    'binary_lock': 'Record all build receipts, executable hashes, counter/collector, allocation and environment before admission or any count.',
    'captures': {k: {'argv': old['argv'][k], 'one_worker_file_sha256': capture[k]['one_slot']} for k in ('0', '1', '2')},
    'focused_cells': focus, 'focused_cell_order': list(focus),
    'tiny_descriptive_control': {'capture': '2', 'order': ['shipped', 'candidate', 'base', 'base', 'candidate', 'shipped']},
    'suite': ['libwild all unit', 'eh-frame', 'eh-frame-terminator', 'crtend-only-eh-frame', 'dynsym-debug-eh-frame', 'relocation-overflow', 'backtrace'],
    'probes': ['normal', 'no-hdr', 'overflow-pc', 'broken-cie', 'overflow-fde'],
    'focused_entry_gate': 'Require all four individual link comparisons and functionality. Stop on ineligibility. Hold full command until new allocation.',
    'thresholds_for_each_focused_and_macro_cell': {'pairs': 8, 'wins_required': 8, 'median_improvement_pct_min': 0.10,
        'two_sided_sign_p_max': .05, 'balanced_order_permutation_p_max': .05,
        'randomization_statistic': 'absolute mean within-pair mean-position log-instruction difference under all 70 balanced orders'},
    'macro_command': ['cargo', 'test', '--no-run', '--locked', '--offline', '-j8'],
    'macro_cohorts': macro, 'macro_cell_order': list(macro),
    'macro_roster': {'cargo': 1, 'rustc': 6, 'wild': 5, 'unique_test_executables': 72},
    'macro_allowed_elf_variants_by_relative_path': allowed,
    'macro_endpoint': 'All Cargo, rustc and Wild user-mode process instructions in the complete command. No elapsed-time claim.',
    'macro_gate': 'All four independently balanced eight-pair cells separately pass both exact tests, direction and threshold. No pooling.',
    'resource_policy': 'Explicit owner allocation before compilation or any measurement; one pinned CPU for focused counts, eight allocated CPUs for complete command with its jobserver.',
}
path = here / 'plan.json'
with path.open('x') as out:
    json.dump(plan, out, indent=2)
    out.write('\n')
(here / 'registration.sha256').write_text(digest(path.read_bytes()) + '  plan.json\n')
print(digest(path.read_bytes()))
