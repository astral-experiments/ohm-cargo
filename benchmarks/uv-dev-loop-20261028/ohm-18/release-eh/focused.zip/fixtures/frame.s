.section .text.frame_entry,"ax",@progbits
.globl _start
.type _start,@function
_start:
 .cfi_startproc
 nop
 ret
 .cfi_endproc
.size _start,.-_start
.section .note.GNU-stack,"",@progbits
