"""Run the two remaining original uvx cohorts with independent custody receipts."""
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

LAB = Path(__file__).resolve().parent
sys.path.insert(0, str(LAB))
import analyze
import native
from common import DIST, EDIT_PATH, LINK, ROOT, fixture

STUDY = 'r18-uvx'
PLAN = LAB / 'registered-uvx.json'
CUSTODY = LAB / 'native-series-custody' / STUDY
RECOVERY = LAB.parent / 'round18-compiler/proof-common-seed'
GIB = 2**30


def read(p):
    return json.loads(p.read_bytes())


def digest(p):
    with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOATIME | os.O_NOFOLLOW), 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(p, data):
    with p.open('x') as f:
        json.dump(data, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def identity(p):
    st = p.lstat()
    assert not stat.S_ISLNK(st.st_mode) and p == p.resolve()
    return [st.st_dev, st.st_ino]


def snapshot(plan, name):
    root = fixture(name)
    assert root == Path(plan['cohorts'][name]['root'])
    pool = root / plan['target_pool']
    all_arms = set(plan['arms']) | set(read(LAB / 'registered-four-v3.json')['arms'])
    dirs = [root / 'target', pool, *(pool / arm for arm in sorted(all_arms))]
    assert all(p.is_dir() for p in dirs) and (pool / 'ready').is_file()
    absent = pool / 'original-target'
    assert not absent.exists() and not absent.is_symlink()
    sources = {}
    for path, original in [(root / 'uv' / EDIT_PATH, root / 'original'),
                           (root / 'uv/crates/uv/src/bin/uvx.rs', root / 'original-uvx'),
                           (root / 'uv/Cargo.lock', None)]:
        source_digest = digest(path)
        if original:
            assert source_digest == digest(original)
        sources[str(path)] = dict(identity=identity(path), sha256=source_digest,
                                  mtime_ns=path.stat().st_mtime_ns)
    slots = {}
    for role, rel in [('cargo', Path('bin/cargo')), ('wild', LINK)]:
        p = ROOT / 'tools' / rel
        original = ROOT / f'official-original-{role}'
        assert p.samefile(original) and digest(p) == digest(DIST / rel)
        slots[role] = dict(path=str(p), official=str(original), identity=identity(p), sha256=digest(p))
    rustc = digest(ROOT / 'tools/bin/rustc')
    assert rustc == digest(DIST / 'bin/rustc')
    return dict(directories={str(p): identity(p) for p in dirs}, sources=sources, slots=slots,
                rustc_sha256=rustc, absent=[str(absent)])


def cell(folder, schedule):
    files = dict(timings=folder / 'timings.csv', complete=folder / 'done.json',
                 admitted=folder / 'admitted.json')
    rows = 0
    if files['timings'].is_file():
        with files['timings'].open(newline='') as f:
            rows = sum(1 for _ in csv.DictReader(f))
    if files['complete'].is_file():
        assert rows == sum(map(len, analyze.validate(folder, schedule))) and rows > 0
    return dict(rows=rows, **{k: digest(p) if p.is_file() else None for k, p in files.items()})


def run(name, plan):
    cfg = plan['cohorts'][name]
    cpus = cfg.get('cpu', plan['cpu'])
    args = ['taskset', '-c', ','.join(map(str, cpus)), sys.executable, '-E', '-s', '-u',
            str(LAB / 'native-admitted.py'), name, '--study', STUDY, '--plan', str(PLAN), '--uvx-source']
    folder = CUSTODY / name
    assert not folder.exists() and not (LAB / STUDY / name).exists()
    assert (LAB / 'host-cleared-for-native').is_file() and not native.foreign()
    assert shutil.disk_usage(ROOT).free > 140 * GIB
    before = snapshot(plan, name)
    folder.mkdir(parents=True)
    save(folder / 'before.json', before)
    logfile = folder / 'native.log'
    start = time.time_ns()
    with logfile.open('x') as f:
        process = subprocess.run(args, stdout=f, stderr=subprocess.STDOUT)
    finish = time.time_ns()
    after = snapshot(plan, name)
    assert before == after and shutil.disk_usage(ROOT).free >= 120 * GIB
    cells = {ep: cell(LAB / STUDY / name / ep, schedule) for ep, schedule in cfg['endpoints'].items()}
    save(folder / 'returned.json', dict(study=STUDY, cohort=name, registration_sha256=digest(PLAN),
         before=before, after=after, runner=dict(argv=args, exit=process.returncode, started_ns=start,
         finished_ns=finish, log=str(logfile), log_sha256=digest(logfile)), cells=cells, journals={}))
    print(name, 'returned', process.returncode, {ep: value['rows'] for ep, value in cells.items()}, flush=True)
    if process.returncode == 0:
        assert all(v['complete'] and v['timings'] and v['admitted'] for v in cells.values())
        with (LAB / f'{STUDY}-{name}-summary.json').open('x') as f:
            subprocess.run([sys.executable, '-E', '-s', '-B', str(LAB / 'analyze.py'), str(PLAN),
                            str(LAB / STUDY)], stdout=f, check=True)
    return process.returncode


if __name__ == '__main__':
    assert os.sched_getaffinity(0) == {31} and os.geteuid() != 0
    assert Path('/proc/1/comm').read_text().strip() == 'systemd'
    assert not read(RECOVERY / 'execution/supplemental-eligibility.json')['recovered']['pending']
    data = read(PLAN)
    outcomes = [run(name, data) for name in ('initial', 'replica')]
    sys.exit(int(any(outcomes)))
