"""Verify the edited uvx input and its direct product during untimed admission."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

from common import ROOT, sha


def invocations(directory):
    compiler = str(ROOT/'tools/bin/rustc')
    prefix = 'execve('+json.dumps(compiler)+', '
    for trace in directory.glob('exec.*'):
        for line in trace.read_text(errors='replace').splitlines():
            if line.startswith(prefix) and line.endswith('= 0'):
                argv, _ = json.JSONDecoder().raw_decode(line[len(prefix):])
                if '--crate-name' in argv and argv[argv.index('--crate-name')+1]=='uvx':
                    yield argv


def verify(root, endpoint, directory):
    source = root/'uv/crates/uv/src/bin/uvx.rs'
    tag, = re.findall(rb'error: uvx could not launch uv \[([A-Z]{2}[0-9]{2})\]',source.read_bytes())
    current = [argv for argv in invocations(directory)
               if any(Path(x).as_posix().endswith('crates/uv/src/bin/uvx.rs') for x in argv)]
    assert current, 'no frontend invocation compiled the edited uvx source'
    result = dict(source_sha256=sha(source),literal=tag.decode(),endpoint=endpoint,
                  frontend_argv_sha256=[hashlib.sha256(json.dumps(a).encode()).hexdigest() for a in current])
    if endpoint=='check':
        driver, = [argv for argv in current
                   if any(x.startswith('--emit=') and 'metadata' in x.split('=',1)[1].split(',') for x in argv)]
        assert driver[driver.index('--crate-type')+1]=='bin'
        suffix, = [s.split('=',1)[1] for s in driver if s.startswith('extra-filename=')]
        out = Path(driver[driver.index('--out-dir')+1])
        assert out.is_relative_to(root/'target')
        files = [out/f'libuvx{suffix}.rmeta',out/f'uvx{suffix}.d']
        assert b'crates/uv/src/bin/uvx.rs' in files[1].read_bytes()
        result['direct_check_outputs'] = {
            str(p.relative_to(root/'target')):dict(sha256=sha(p),size=p.stat().st_size) for p in files}
    if endpoint=='build':
        built = root/'target/debug/uvx'
        with tempfile.TemporaryDirectory(dir=directory) as empty:
            executable=Path(empty)/'uvx'
            os.link(built,executable)
            proc=subprocess.run([executable],env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},capture_output=True,timeout=15)
        assert proc.returncode==2 and not proc.stdout
        assert proc.stderr.startswith(b'error: uvx could not launch uv ['+tag+b']: Could not find the `uv` binary at ')
        result['diagnostic'] = dict(sha256=sha(built),returncode=proc.returncode,stderr=proc.stderr.decode())
    path=directory/'uvx-product.json'
    with path.open('x') as f:
        json.dump(result,f,indent=2)
        f.write('\n')
