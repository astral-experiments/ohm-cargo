"""Record free space during the two native uvx cohorts and pause only their controller if required."""
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time

LAB = Path(__file__).resolve().parent
sys.path.insert(0,str(LAB))
from common import ROOT

GIB = 2**30
CUSTODY = LAB / 'native-series-custody/r18-uvx'
LOG = LAB / 'uvx-free-space.jsonl'
ALERT = LAB / 'uvx-space-pause.json'


def record(path, value, mode):
    with path.open(mode) as f:
        f.write(json.dumps(value) + '\n')
        f.flush()
        if mode == 'x':
            os.fsync(f.fileno())


def exact_controller(pid, cohort):
    proc = Path('/proc') / str(pid)
    try:
        a = [os.fsdecode(x) for x in (proc/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')]
        return (proc.stat().st_uid == os.getuid() and Path(os.readlink(proc/'exe')).name.startswith('python3')
                and a[-7:] == [str(LAB/'native-admitted.py'),cohort,'--study','r18-uvx','--plan',str(LAB/'registered-uvx.json'),'--uvx-source'])
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        return False


def main():
    assert os.geteuid() != 0 and Path('/proc/1/comm').read_text().strip() == 'systemd'
    assert os.sched_getaffinity(0) == {31} and not ALERT.exists()
    minimum = None
    while (LAB/'host-cleared-for-native').is_file() and not (CUSTODY/'replica/returned.json').exists():
        cohort = next((c for c in ('initial','replica') if (CUSTODY/c/'before.json').is_file()
                       and not (CUSTODY/c/'returned.json').exists()), None)
        if cohort:
            free = shutil.disk_usage(ROOT).free
            minimum = min(free,minimum) if minimum is not None else free
            row = dict(utc_ns=time.time_ns(),cohort=cohort,free_bytes=free,minimum_bytes=minimum)
            record(LOG,row,'a')
            if free < 134 * GIB:
                # Stop only the Python dispatcher. Its currently running Cargo command can finish.
                # A paused timing cohort is visibly recorded, including every existing sample.
                pids = [int(p.name) for p in Path('/proc').glob('[0-9]*') if exact_controller(int(p.name),cohort)]
                if len(pids) == 1:
                    try:
                        fd = os.pidfd_open(pids[0])
                    except ProcessLookupError:
                        continue
                    try:
                        if exact_controller(pids[0],cohort):
                            signal.pidfd_send_signal(fd,signal.SIGSTOP)
                            record(ALERT,dict(row,pid=pids[0],action='native Python dispatcher paused; inspect before resuming'),'x')
                            return
                    finally:
                        os.close(fd)
        time.sleep(3 if cohort else 7)


if __name__ == '__main__':
    main()
