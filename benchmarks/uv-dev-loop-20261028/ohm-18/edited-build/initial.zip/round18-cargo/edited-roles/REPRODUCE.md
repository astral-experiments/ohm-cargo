# Reproduce the release-18 edited-role comparison

The coordinator assigned CPUs 8–15 to the actual run before any counted or admission observation. The original registration had reserved CPUs 16–23. The separate `measurement-affinity.json` receipt preserves the original plan and seal hashes and records this one change. Run `taskset -c 8-15 python3 -B work/round18-cargo/edited-roles/measurement-affinity.py` to reproduce that assignment with the original sealed workload. The original `series.py` entry point enforces the originally registered CPUs. The first affinity launcher exited before dispatching any benchmark or Cargo command because this host sets `PYTHONSAFEPATH`. Its log and checksum are retained under `affinity-launch-excluded.*`.

The saved raw results can be verified without a Rust toolchain, uv checkout or DynamoRIO installation. Use Python 3.11 or later and run `python3 -B work/round18-cargo/edited-roles/summary.py` after extraction. This reads the per-process thread totals, exact compiler argument and linker output rosters, raw native per-PID exec traces, per-arm Cargo output, artifact digest receipts and randomized pair order. Recomputing the output digests from the generated executable and metadata bytes requires a fresh build. The result is written to `summary.json` and `SUMMARY.md` next to the saved registration.

To collect new samples on x86-64 Linux, use the same top-level `work` layout as the archive. Supply the exact comparison binaries or build the matched pair using `work/round18-cargo/REPRODUCE.md`. That recipe produces the PGO binary, source and training audit receipts consumed by this harness. The standalone base receipt can be regenerated before the candidate finishes.

```sh
python3 -B work/round18-cargo/recipe/audit18.py \
  work/round18-cargo/pgo /path/to/release18-cargo/sources --arms base \
  > work/round18-cargo/receipts/pgo-base-audit.json
```

Use the original release-source Wild at `work/bin/wild-baseline` (SHA-256 `82a927b86f929b67c58be4d37ab8442f32fcdd115d97334dcc5ac190101d8865`) and Wild #45+#46 at `work/wild-prefix-v2/v2-wild` (`901b68fc9ca30975d837d45dcf1bdf743a6130ecef5e23d6aef44558b09bd7e1`). `sealed.json` records both actual matched Cargo hashes and DynamoRIO files. Install the original Ohm 1.99.0-18 archive (SHA-256 `629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8`) at `work/upstream-monitor/toolchain18`. Its complete compiler sysroot and its regular `lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd` are required. Place the official DynamoRIO 11.3.0-1 release at `work/dynamorio/DynamoRIO-Linux-11.3.0-1`. The fixed wrapper uses the offline drcachesim instruction markers with no child following. Linux tools `strace`, GCC, tar, Git and GNU coreutils must be installed.

Create a private directory for benchmark fixtures and write its absolute path plus newline to `work/bench-home.path`. Seed its `cargo/registry` directory using a Cargo home with dependencies for the locked uv workspace, including dev-dependencies. Both fresh study homes copy this registry, with separate Cargo cache databases. `work/uv` must be a Git checkout containing c22e6b71933443e9cd299d4b6ac8de035ed4825b. Its working files are unused. Each cohort independently runs `git archive` on that commit. At every pilot and paired observation, the entire target is parked at the same visible path. The mutable Cargo home state is restored from the structural predecessor for each pilot and then follows separate persistent arm histories. The immutable registry remains in place and its metadata is verified after each endpoint.

Start in a new study directory tree. Preserve original registration and observations in their extracted archive. Copy the study scripts and protocol into a clean `work/round18-cargo/edited-roles`, recreate `plan.json` with `plan.py`, and generate a fresh `warm-affinity.json` for the resulting registration digest if retaining the alternative warm-only affinity. The original schedule generator has fixed seeds. Run the following when these CPUs are available to this experiment.

```sh
study=work/round18-cargo/edited-roles
python3 -B "$study/plan.py"
taskset -c 16-23 python3 -B "$study/run.py" warm initial
taskset -c 16-23 python3 -B "$study/run.py" warm replica
taskset -c 16-23 python3 -B "$study/run.py" seal
taskset -c 16-23 python3 -B "$study/run.py" calibrate
for cohort in initial replica; do
  for command in check build test; do
    taskset -c 16-23 python3 -B "$study/run.py" study "$cohort" "$command"
  done
done
python3 -B "$study/summary.py"
```

The host used `taskset -c 16-23 python3 -B "$study/series.py"` after sealing. This prepares missing pristine targets, calibrates once, and runs each endpoint's initial and independent repeat in sequence. An admission or artifact exclusion is retained and other endpoints can continue.

On a host with different logical CPU IDs, change the eight-core affinity in the local copy of `plan.py` before registering and use the same IDs in each taskset command. The manifest includes absolute fixture paths, so a new host registers a different manifest hash. To use the original warm-only exception, set `warm-affinity.json`'s `plan` field to that new hash before warming and sealing. There is no need to alter the sample sizes, workloads, seeds, or statistics. Every endpoint's four admission cells have to pass exact argv, workload and artifact checks on the new host. Retain and report any exclusion. A full run needs disk space for the warmed common targets and two separate held targets during an endpoint.

For a competing native timing window, create the empty file `work/round18-cargo/edited-roles/control/pause`. Wait for `control/status.json` to acknowledge `paused`. The controller leaves both arms' targets and Cargo homes parked and has no active compiler, linker or counter. It will resume the next frozen block when the pause file is removed. A pause can occur before an endpoint, after four-cell admission, or after both arms of a paired edit. Every request boundary is recorded in `control/boundaries.jsonl`.
