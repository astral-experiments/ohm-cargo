"""Freeze the six edited uv cohorts before the candidate driver or any role observations."""
import hashlib
import json
import random
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
BENCH = Path((WORK / "bench-home.path").read_text().strip())
RESULTS = HERE / "results"
ROOTS = BENCH / "role-studies-18"
RELEASE = WORK / "upstream-monitor/toolchain18"
EDIT = "crates/uv/src/install_source.rs"
UV = "c22e6b71933443e9cd299d4b6ac8de035ed4825b"
BEFORE = b"component == cellar && next == formula"
ORIGINAL = subprocess.check_output(["git", "-C", str(WORK / "uv"), "show", f"{UV}:{EDIT}"])
COMMANDS = {"check":["check"], "build":["build"], "test":["test", "--no-run"]}
ARMS = {
    "base": (WORK / "round18-cargo/pgo/bin/base", WORK / "bin/wild-baseline"),
    "candidate": (WORK / "round18-cargo/pgo/bin/guard-stack", WORK / "wild-prefix-v2/v2-wild"),
}
SEEDS = {
    "initial": {"check": 72518011, "build": 72518023, "test": 72518039},
    "replica": {"check": 73118401, "build": 73118417, "test": 73118431},
}
NAMES = {"initial": {"check":"A", "build":"B", "test":"C"}, "replica":{"check":"J", "build":"K", "test":"L"}}
ROLES = ("cargo","rustc","wild")
WRAP = WORK / "tree-count/wrap.py"
COUNTER = WORK / "edit-link-profile/native-instrument/count.py"

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def body(symbol, index):
    # Same structural edit was used in the release-17 edited-command experiments.
    need(ORIGINAL.count(BEFORE) == 1, "source predicate moved")
    replacement = ('{\n                component == cellar && (next == formula || next == OsStr::new('
                   f'"uv-preview-{symbol}{index:02d}"))\n            }}')
    return ORIGINAL.replace(BEFORE, replacement.encode())

def schedule():
    out = {}
    for cohort, specs in SEEDS.items():
        out[cohort] = {}
        for ep, seed in specs.items():
            rng = random.Random(seed)
            order = [["base","candidate"],["candidate","base"]] * 4
            rng.shuffle(order)
            ids = list(range(10,18))
            rng.shuffle(ids)
            cells = [["native","base"], ["count","candidate"], ["native","candidate"], ["count","base"]]
            rng.shuffle(cells)
            symbol = NAMES[cohort][ep]
            out[cohort][ep] = dict(seed=seed, symbol=symbol, root=str(ROOTS/cohort), edits=[
                {"id":i,"sha256":hashlib.sha256(body(symbol,i)).hexdigest()} for i in (0,1,*ids)],
                native_count_admission=cells, pairs=[dict(id=i,order=o) for i,o in zip(ids,order)],
                command=[*COMMANDS[ep],"--locked","--offline","-j8"])
    return out

def main():
    p = HERE / "plan.json"
    need(not p.exists() and not RESULTS.exists(), "study already registered or observed")
    reg = dict(uv=UV, edit=EDIT, original_sha256=hashlib.sha256(ORIGINAL).hexdigest(), cpus=list(range(16,24)),
       release="1.99.0-18", release_archive_sha256="629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8",
       rustc_commit="a4fa11bcd38280639cb94daacc125472657db6c3", cargo_commit="7caf39914da1e28a67744ecbc963a5f26361474d",
       cargo_baseline_tree="c9d1f41de63b6d95904dc8f5325000f38ea636b0", cargo_candidate_tree="9c6e123da812bbbf5cbed205166025c742bf0f72",
       rust_std_patch_sha256="101edf0543b3331315910306be22603c3595ad2549bae68144fd0b3408e91c40",
       cargo_build="matched independently trained eight-core release PGO; seal both Cargo hashes before admissions",
       arms={a:[str(x) for x in b] for a,b in ARMS.items()},
       wild_sha256={"base":"82a927b86f929b67c58be4d37ab8442f32fcdd115d97334dcc5ac190101d8865",
                    "candidate":"901b68fc9ca30975d837d45dcf1bdf743a6130ecef5e23d6aef44558b09bd7e1"},
       rustc_sha256="c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60",
       plan_code_sha256=sha(Path(__file__)), wrapper_sha256=sha(WRAP), counter_sha256=sha(COUNTER),
       scope="independently instrumented Cargo, all rustc and all selected Wild process PID thread instruction sums; forced --no-fork Wild; default native wall time studied separately",
       admission="fresh clone of one native structural baseline per identical fixed-width edit, all four mode x arm cells; exact rustc argv and Wild -o multisets, packages and test executables; native strace receipts; output digest oracle",
       gate="each endpoint independently; eight order-balanced edits, positive median and sign p < .05/3 primary, positive min-max 99.22% interval primary. Sign p < .05 repeat; two-sided restricted balanced-order permutation p < .05 in each. Include every eligible arm, complete both admitted cohorts, never pool; preserve and reject failures",
       protocol_sha256=sha(HERE/"PROTOCOL.md"), schedule=schedule())
    save(p,reg)
    (HERE/"registered.sha256").write_text(f"{sha(p)}  plan.json\n")
    print(sha(p))

if __name__ == "__main__":
    main()
