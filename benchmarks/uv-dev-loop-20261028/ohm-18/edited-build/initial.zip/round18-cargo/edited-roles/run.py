#!/usr/bin/env python3
"""Prepare, admit and run the preregistered release-18 edited-role cohorts."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
from plan import *
sys.path.insert(0, str(WORK / "tree-count"))
from identical import audit_native

def checked_plan(phase):
    cfg = read(HERE/"plan.json")
    need(sha(HERE/"plan.json") == (HERE/"registered.sha256").read_text().split()[0], "plan changed")
    need(sha(HERE/"plan.py") == cfg["plan_code_sha256"] and sha(HERE/"PROTOCOL.md") == cfg["protocol_sha256"], "frozen edit or protocol changed")
    allowed=[cfg["cpus"]]
    if phase=="warm" and sorted(os.sched_getaffinity(0))!=cfg["cpus"]:
        amendment=read(HERE/"warm-affinity.json")
        need(amendment["plan"]==sha(HERE/"plan.json"),"warm amendment targets different protocol")
        allowed.append(amendment["alternative_warm_cpus"])
    if phase!="seal":need(sorted(os.sched_getaffinity(0)) in allowed, "wrong CPU affinity")
    return cfg

def clone(src, dst):
    need(src.is_dir() and not dst.exists(), f"bad clone: {src} -> {dst}")
    subprocess.run(["cp", "-a", "--reflink=auto", str(src), str(dst)], check=True)

def copy_home_state(src,dst):
    """Keep the 730 MB offline registry fixed and snapshot all the mutable home state."""
    dst.mkdir(mode=0o700,exist_ok=True)
    for entry in dst.iterdir():
        if entry.name=="registry":continue
        if entry.is_dir() and not entry.is_symlink():shutil.rmtree(entry)
        else:entry.unlink()
    for entry in src.iterdir():
        if entry.name!="registry":
            subprocess.run(["cp","-a","--reflink=auto",str(entry),str(dst/entry.name)],check=True)
    st=src.stat()
    os.utime(dst,ns=(st.st_atime_ns,st.st_mtime_ns))

def boundary(cohort,ep,label):
    """Park with no active Cargo, rustc or Wild process between complete paired blocks."""
    control=HERE/"control";control.mkdir(exist_ok=True)
    signal=control/"pause"
    def status(state):
        event={"state":state,"cohort":cohort,"endpoint":ep,"boundary":label,"utc_unix_ns":time.time_ns(),"pid":os.getpid()}
        tmp=control/"status.next";save(tmp,event);tmp.replace(control/"status.json")
        with (control/"boundaries.jsonl").open("a") as f:f.write(json.dumps(event)+"\n")
    if signal.exists():
        status("paused")
        print(f"Parked at {cohort}/{ep}: {label}",flush=True)
        while signal.exists():time.sleep(5)
    status("released")

def discard(path):
    need(path.parent.is_relative_to(ROOTS) and path.name in {"target","held-base","held-candidate","structural"}, f"unsafe private cleanup: {path}")
    shutil.rmtree(path)

def tree_state(path):
    h = hashlib.sha256()
    count = size = 0
    for base, dirs, files in os.walk(path):
        dirs.sort()
        for n in sorted(files):
            f=Path(base)/n
            st=f.lstat()
            h.update(json.dumps([str(f.relative_to(path)),st.st_mode,st.st_size,st.st_mtime_ns,os.readlink(f) if f.is_symlink() else None]).encode()+b"\n")
            count += 1
            size += st.st_size
    return {"file_metadata_sha256":h.hexdigest(),"files":count,"file_size_sum":size}

def seal(p):
    audit = read(WORK/"round18-cargo/pgo/audit.json")["arms"]
    identities = {}
    for arm,(cargo,wild) in ARMS.items():
        key = "base" if arm=="base" else "guard-stack"
        identities[arm] = {"cargo":sha(cargo),"wild":sha(wild)}
        need(identities[arm] == {"cargo":audit[key]["cargo_sha256"], "wild":p["wild_sha256"][arm]}, f"arm: {arm}")
    need(sha(RELEASE/"bin/rustc")==p["rustc_sha256"] and sha(WRAP)==p["wrapper_sha256"] and sha(COUNTER)==p["counter_sha256"], "rustc/counter mismatch")
    dr=WORK/"dynamorio/DynamoRIO-Linux-11.3.0-1"
    return {"arms":identities,"plan":sha(HERE/"plan.json"),"harness":{s:sha(HERE/s) for s in ("run.py","summary.py","series.py","warm-affinity.json") if (HERE/s).exists()},"wrapper_inputs":{str(s.relative_to(WORK)):sha(s) for s in (WRAP,COUNTER,WORK/"tree-count/calibrate.c",WORK/"tree-count/calibrate.py",WORK/"tree-count/identical.py")},"dynamorio":{s:sha(dr/s) for s in ("bin64/drrun","lib64/release/libdynamorio.so","tools/drcachesim.drrun64","tools/lib64/release/libdrmemtrace.so")}}

def setup(root):
    root.mkdir(mode=0o700,parents=True,exist_ok=True)
    if (root/"setup.json").exists():
        return
    src=root/"source"
    if not src.exists():
        temp=root/"source.incoming"
        temp.mkdir()
        with subprocess.Popen(["git","-C",str(WORK/"uv"),"archive",UV], stdout=subprocess.PIPE) as git:
            subprocess.run(["tar","-x","-C",str(temp)],stdin=git.stdout,check=True)
            need(git.wait()==0,"git archive failed")
        temp.rename(src)
    need((src/EDIT).read_bytes()==ORIGINAL, "unexpected archived source")
    home=root/"cargo-home"
    home.mkdir(exist_ok=True,mode=0o700)
    if not (home/"registry").exists():
        cache=BENCH/"cargo/registry"
        incoming=home/"registry.incoming"
        if incoming.exists(): # Previous cp interrupted before it could publish.
            shutil.rmtree(incoming)
        clone(cache,incoming)
        incoming.rename(home/"registry")
    t=root/"tools"
    for d in (t/"bin",t/"linker",t/"arms"):
        d.mkdir(parents=True,exist_ok=True)
    for dest in (t/"bin/cc",t/"rustc-wrapper",t/"linker/ld.bfd"):
        if not dest.is_symlink():
            dest.symlink_to(WRAP)
    save(root/"setup.json",{"source":str(src),"original_sha256":sha(src/EDIT),"cargo_lock":sha(src/"Cargo.lock"),"immutable_registry":str(BENCH/"cargo/registry"),"cargo_home":str(home),"visible_target":str(root/"target"),"rustc":str(RELEASE/"bin/rustc")})

def stage(root, arm, expected):
    t=root/"tools"
    for (role,src) in zip(("cargo","wild"), ARMS[arm]):
        staged=t/"arms"/(arm+"-"+role)
        if not staged.exists():
            temp=staged.with_suffix(".incoming")
            shutil.copy2(src,temp)
            need(sha(temp)==expected[role], f"{role} staging hash")
            temp.chmod(0o555)
            temp.rename(staged)
        need(sha(staged)==expected[role], f"{role} staged hash")
        slot=t/role
        temp=slot.with_suffix(".next")
        temp.unlink(missing_ok=True)
        os.link(staged,temp)
        os.replace(temp,slot)
        temp.unlink(missing_ok=True)
        need(os.path.samefile(slot,staged),"bad binary slot")

def mask_unit_harness(p):
    with p.open("rb") as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as buf:
        need(buf[:6]==b"\x7fELF\x02\x01","unknown ELF")
        at=struct.unpack_from("<Q",buf,40)[0]
        width,n,ns=struct.unpack_from("<HHH",buf,58)
        names,length=struct.unpack_from("<QQ",buf,at+ns*width+24)
        strings=buf[names:names+length]
        regions=[]; fields={}
        for i in range(n):
            sh=at+i*width
            off=struct.unpack_from("<I",buf,sh)[0]
            name=strings[off:strings.index(0,off)]
            if name==b".rodata":
                ent=struct.unpack_from("<Q",buf,sh+56)[0]
                need(ent in (0,8),"unrecognized rodata entry size")
                regions.append((sh+56,sh+57));fields["rodata_entsize"]=ent
            elif name==b".note.gnu.build-id":
                loc=struct.unpack_from("<Q",buf,sh+24)[0]
                need(struct.unpack_from("<III",buf,loc)==(4,32,3) and buf[loc+12:loc+16]==b"GNU\0","unknown GNU build ID")
                regions.append((loc+16,loc+48));fields["gnu_build_id"]=buf[loc+16:loc+48].hex()
        need(len(regions)==2 and len(fields)==2,"missing permitted ELF fields")
        h=hashlib.sha256();prev=0
        for a,b in sorted(regions):
            h.update(memoryview(buf)[prev:a]);prev=b
        h.update(memoryview(buf)[prev:])
        return h.hexdigest(),fields

def artifact_hashes(ep, records, target):
    linked={Path(r["key"]) for r in records if r["role"]=="wild"}
    outputs=set(linked); library_tests=set()
    for r in records:
        if r["role"]!="rustc": continue
        a=r["argv"]
        if "--crate-name" not in a: continue
        name=a[a.index("--crate-name")+1]
        od=Path(a[a.index("--out-dir")+1])
        extra=next((x.split("=",1)[1] for x in a if x.startswith("extra-filename=")),"")
        if name=="uv" and "--test" in a and any(x.endswith("crates/uv/src/lib.rs") for x in a):
            # Ohm can move -o into a hash-namespaced directory, omitting extra-filename.
            if "-o" in a:library_tests.add(Path(a[a.index("-o")+1]))
            library_tests.add(od/(name+extra))
        if ep=="check":
            emit=next((x.partition("=")[2] for x in a if x.startswith("--emit=")),"").split(",")
            for item in emit:
                if item.partition("=")[0]=="metadata":
                    outputs.add(Path(item.partition("=")[2]) if "=" in item else od/("lib"+name+extra+".rmeta"))
    need(bool(outputs),"no emitted artifacts to compare")
    result={}
    for f in sorted(outputs):
        need(f.is_file() and f.is_relative_to(target),f"missing or escaped output: {f}")
        full=sha(f); canonical=full; permitted=None
        if f in library_tests and f in linked:
            canonical,permitted=mask_unit_harness(f)
        result[str(f.relative_to(target))]={"size":f.stat().st_size,"sha256":full,"canonical_sha256":canonical,"permitted_fields":permitted}
    return result

def run(root, command, ep, log, mode, kind):
    log.mkdir(parents=True)
    t=root/"tools";target=root/"target";src=root/"source"
    paths=dict(cargo=t/"cargo",wild=t/"wild",rustc=RELEASE/"bin/rustc",linker_wrapper=t/"linker/ld.bfd")
    env=dict(os.environ, CARGO_HOME=str(root/"cargo-home"),CARGO_TARGET_DIR=str(target),RUSTC=str(paths["rustc"]),RUSTDOC=str(RELEASE/"bin/rustdoc"),
             CARGO_NET_OFFLINE="true", CARGO_TERM_COLOR="never", SSL_CERT_DIR="/etc/ssl/certs", PATH=f"{t/'bin'}:{RELEASE/'bin'}:{os.environ['PATH']}",
             RUSTC_WRAPPER=str(t/"rustc-wrapper"), OHM_RELEASE_WILD_DIR=str(RELEASE/"lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld"),
             OHM_WRAPPED_WILD_DIR=str(t/"linker"),OHM_ACTUAL_WILD=str(paths["wild"]),OHM_SINGLE_COUNTER=str(COUNTER),OHM_ROLE_MODE=mode,OHM_ROLE_LOG=str(log))
    argv=[str(WRAP),"cargo",str(paths["cargo"]),*command]
    if mode=="native" and kind=="admit":
        argv=["strace","-ff","-qq","-s","450","-e","trace=execve,execveat","-o",str(log/"exec"),*argv]
    with (log/"cargo.log").open("x") as f:
        started=time.monotonic()
        rc=subprocess.run(argv,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
        duration=time.monotonic()-started
    content=(log/"cargo.log").read_text(errors="replace")
    need(rc==0 and re.search(r"^\s*Finished ",content,re.M),f"{log}: Cargo status {rc}\n"+content[-1400:])
    need(not re.search(r"^\s*(Running|Updating|Downloading) |^running \d+ tests?",content,re.M),"test execution or fetching")
    packages=sorted([list(m) for m in re.findall(r"^\s*(Checking|Compiling) (.+)$",content,re.M)])
    if kind=="warm":return packages
    need(len(packages)==1 and packages[0][1].startswith("uv v"),f"unexpected package roster: {packages}")
    if kind=="structural":return packages
    tests=sorted(re.findall(r"^\s*Executable (.+)$",content,re.M))
    need((ep=="test") == bool(tests) and (ep!="test" or any(x.startswith("tests/it/") for x in tests)), "test roster shape")
    records=[read(f) for role in ROLES for f in log.glob(role+"-*.json")]
    counts=Counter(r["role"] for r in records)
    need(counts["cargo"]==1 and counts["rustc"]>0 and ((ep=="check")==(counts["wild"]==0)),f"unexpected role counts: {counts}")
    for r in records:
        need(r["executable"]==str(paths[r["role"]]),"incorrect selected executable path")
        if mode=="count":
            need(r["instructions"]>0 and r["threads"] and r["instructions"]==sum(r["threads"].values()),"incomplete thread accounting")
    if mode=="native":
        audit_native(log,paths,records)
        ran=set(read(log/"native-execs.json"))
        test_bins={str((src/Path(m[1])).resolve()) for s in tests if (m:=re.search(r"\((.+)\)$",s))}
        need(not ran.intersection(test_bins),"native trace ran an emitted test")
    roster={"packages":packages,"tests":tests,"records":sorted([r["role"],json.dumps(r["key"])] for r in records),"role_counts":dict(counts)}
    oracle=artifact_hashes(ep,records,target)
    sums={r:sum(x.get("instructions",0) for x in records if x["role"]==r) for r in ROLES}
    rec={"roster":roster,"files":oracle,"totals":sums,"source_sha256":sha(src/EDIT),"source_mtime_ns":(src/EDIT).stat().st_mtime_ns,
         "observed_runtime_for_budget_s":duration,"actual_binary_inodes":{r:[paths[r].stat().st_dev,paths[r].stat().st_ino] for r in ROLES}}
    save(log/"receipt.json",rec)
    return rec

def warm(cohort, p):
    boundary(cohort,"all","before pristine preparation")
    root=ROOTS/cohort;setup(root);out=RESULTS/cohort/"warm";out.mkdir(parents=True,exist_ok=True)
    need((root/"source"/EDIT).read_bytes()==ORIGINAL,"warm needs pristine source")
    expected={"cargo":read(WORK/"round18-cargo/receipts/pgo-base-audit.json")["arms"]["base"]["cargo_sha256"],"wild":p["wild_sha256"]["base"]}
    stage(root,"base",expected)
    if (root/"common-ready.json").exists():return
    need(not (root/"common").exists(), "orphan common seed")
    for ep in COMMANDS:
        done=out/(ep+".json")
        if done.exists():continue
        boundary(cohort,ep,"before pristine warm command")
        i=sum(x.is_dir() and x.name.startswith(ep+"-") for x in out.iterdir())
        compiled=run(root,p["schedule"][cohort][ep]["command"],ep,out/f"{ep}-{i:02}","native","warm")
        save(done,{"packages":compiled,"finished_ns":time.time_ns()})
        print(f"Warmed {cohort} {ep}, {len(compiled)} packages",flush=True)
    (root/"target").rename(root/"common")
    receipt=tree_state(root/"common")
    save(root/"common-ready.json",receipt);save(out/"common-ready.json",receipt)

def match(a,b):
    need(a["roster"]==b["roster"],"role, argument, package or test executable roster changed")
    need(a["source_sha256"]==b["source_sha256"] and a["source_mtime_ns"]==b["source_mtime_ns"],"different source bytes or mtime")
    for rec in (a,b):
        need(len(rec["files"])==len(a["files"]),"different output list")
    need({p:(f["size"],f["canonical_sha256"]) for p,f in a["files"].items()} ==
         {p:(f["size"],f["canonical_sha256"]) for p,f in b["files"].items()},"different output digest")

def study(cohort,ep,p,identities):
    root=ROOTS/cohort;cfg=p["schedule"][cohort][ep];out=RESULTS/cohort/ep
    boundary(cohort,ep,"before endpoint")
    need((root/"common-ready.json").exists() and not out.exists(),"target not prepared, or cohort already observed")
    need(read(root/"common-ready.json")==tree_state(root/"common"),"common seed metadata changed")
    out.mkdir(parents=True);target=root/"target";src=root/"source"/EDIT;stat=src.stat()
    need(src.read_bytes()==ORIGINAL and not target.exists(),"fixture busy")
    expected={x["id"]:x["sha256"] for x in cfg["edits"]};home=root/"cargo-home"
    home_states=root/("homes-"+ep);home_states.mkdir(mode=0o700)
    def set_edit(i):
        src.write_bytes(body(cfg["symbol"],i))
        need(sha(src)==expected[i],"registered edit mismatch")
    def select(arm):
        stage(root,arm,identities[arm])
    try:
        select("base");clone(root/"common",target);set_edit(0)
        run(root,cfg["command"],ep,out/"structural", "native","structural")
        need(not run(root,cfg["command"],ep,out/"fresh","native","warm"),"structural predecessor not fresh")
        target.rename(root/"structural");pred=tree_state(root/"structural");save(out/"predecessor.json",pred)
        copy_home_state(home,home_states/"predecessor")
        registry=tree_state(home/"registry");save(out/"registry.json",registry)
        set_edit(1);ref=None
        for i,(mode,arm) in enumerate(cfg["native_count_admission"]):
            copy_home_state(home_states/"predecessor",home)
            select(arm);clone(root/"structural",target);need(tree_state(target)==pred,"pilot seed differs")
            rec=run(root,cfg["command"],ep,out/f"admit-{i}-{mode}-{arm}",mode,"admit")
            if ref:match(ref,rec)
            else:ref=rec
            discard(target)
        save(out/"admission.json",ref["roster"])
        print("Admitted",cohort,ep,ref["roster"]["role_counts"],len(ref["roster"]["tests"]),"test executables",flush=True)
        boundary(cohort,ep,"after four-cell admission")
        for arm in ARMS:
            dst=root/("held-"+arm);clone(root/"structural",dst);need(tree_state(dst)==pred,"held seed differs")
            copy_home_state(home_states/"predecessor",home_states/arm)
        with (out/"samples.csv").open("x",newline="") as stream:
            rows=csv.DictWriter(stream,fieldnames=["pair","id","position","arm","cargo","rustc","wild","total","source_sha256","receipt"])
            rows.writeheader()
            for i,pair in enumerate(cfg["pairs"]):
                set_edit(pair["id"]);first=None
                for j,arm in enumerate(pair["order"]):
                    held=root/("held-"+arm);held.rename(target);select(arm)
                    copy_home_state(home_states/arm,home)
                    log=out/f"pair-{i}-{j}-{arm}"
                    rec=run(root,cfg["command"],ep,log,"count","sample")
                    need(ref["roster"]==rec["roster"],"sample differs from admitted workload")
                    if first:match(first,rec)
                    else:first=rec
                    target.rename(held)
                    copy_home_state(home,home_states/arm)
                    rows.writerow(dict(pair=i,id=pair["id"],position=j,arm=arm,**rec["totals"],total=sum(rec["totals"].values()),source_sha256=rec["source_sha256"],receipt=str(log.relative_to(out)/"receipt.json")))
                    stream.flush()
                boundary(cohort,ep,f"after pair {i+1} of 8")
        need(tree_state(root/"structural")==pred, "structural seed changed")
        need(tree_state(home/"registry")==registry,"immutable offline registry changed")
        for name in ("held-base","held-candidate","structural"):discard(root/name)
        save(out/"complete.json", {"pairs":8,"arms":16,"admission_cells":4,"common_unchanged":tree_state(root/"common")==read(root/"common-ready.json")})
        need(read(out/"complete.json")["common_unchanged"],"common seed changed")
    except BaseException as exc:
        save(out/"rejected.json",{"type":type(exc).__name__,"error":str(exc)})
        # Keep every rejected target outside visible slots and available for diagnosis.
        for name in ("held-base","held-candidate","structural","target"):
            if (root/name).exists():(root/name).rename(root/(f"rejected-{ep}-"+name))
        raise
    finally:
        if (home_states/"predecessor").exists():copy_home_state(home_states/"predecessor",home)
        src.write_bytes(ORIGINAL);os.utime(src,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        save(out/"restore.json",{"source_sha256":sha(src),"source_mtime_ns":src.stat().st_mtime_ns,"target_vacant":not target.exists()})

def main():
    args=argparse.ArgumentParser()
    args.add_argument("phase",choices=("warm","seal","calibrate","study"))
    args.add_argument("cohort",choices=SEEDS,nargs="?")
    args.add_argument("endpoint",choices=COMMANDS,nargs="?")
    v=args.parse_args();p=checked_plan(v.phase)
    if v.phase=="warm":
        need(v.cohort,"specify cohort");warm(v.cohort,p);return
    if v.phase=="seal":
        s=seal(p);file=HERE/"sealed.json"
        if file.exists():need(read(file)==s,"sealed input changed")
        else:save(file,s)
        return
    if v.phase=="calibrate":
        subprocess.run([sys.executable,"-B",str(WORK/"tree-count/calibrate.py"),str(HERE/"calibration")],check=True)
        return
    need(v.cohort and v.endpoint and (HERE/"calibration/PASS.json").exists(),"missing calibration or endpoint")
    s=seal(p);need(s==read(HERE/"sealed.json"),"sealed binaries or harness changed")
    study(v.cohort,v.endpoint,p,s["arms"])

if __name__=="__main__":
    main()
