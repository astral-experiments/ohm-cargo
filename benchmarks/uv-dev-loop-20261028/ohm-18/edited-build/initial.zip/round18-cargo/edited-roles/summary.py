"""Recompute registered release-18 selected-role statistics from per-PID and per-arm receipts."""
import collections
import csv
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import hashlib

HERE=Path(__file__).resolve().parent
RESULTS=HERE/"results"
SEEDS=("initial","replica")
COMMANDS=("check","build","test")
ARMS=("base","candidate")
ROLES=("cargo","rustc","wild")
def read(p):return json.loads(p.read_text())
def save(p,record):p.write_text(json.dumps(record,indent=2)+"\n")
def need(ok,why):
    if not ok:raise RuntimeError(why)

def audit_run(where, row, mode):
    rec=read(where/"receipt.json")
    packages=sorted([list(x) for x in re.findall(r"^\s*(Checking|Compiling) (.+)$",(where/"cargo.log").read_text(),re.M)])
    need(packages==rec["roster"]["packages"] and len(packages)==1 and packages[0][1].startswith("uv v"),"logged package roster")
    tests=sorted(re.findall(r"^\s*Executable (.+)$",(where/"cargo.log").read_text(),re.M))
    need(tests==rec["roster"]["tests"],"logged tests")
    raw=[read(f) for role in ROLES for f in where.glob(role+"-*.json")]
    counts=collections.Counter(r["role"] for r in raw)
    need(dict(counts)==rec["roster"]["role_counts"] and counts["cargo"]==1,"role multiplicity")
    need(sorted([r["role"],json.dumps(r["key"])] for r in raw)==rec["roster"]["records"],"raw role argument multiset")
    if mode=="native":
        traces=collections.Counter()
        for f in where.glob("exec.*"):
            for line in f.read_text().splitlines():
                if re.search(r"= 0$",line):
                    match=re.match(r'^execve\("([^"\\]+)",',line)
                    need(match,"unexpected native exec")
                    traces[match.group(1)]+=1
        need(dict(traces)==read(where/"native-execs.json"),"native trace readback")
        programs={r["executable"] for r in raw}
        slot=next(Path(r["executable"]) for r in raw if r["role"]=="cargo")
        programs.add(str(slot.parent/"linker/ld.bfd"))
        for image in traces:
            if Path(image).name in ("cargo","rustc","wild","ld.bfd","wild-ld","ld","ld.lld","rust-lld"):
                need(image in programs,"unwrapped Cargo, compiler or linker")
        for role in ROLES:
            exe=next((r["executable"] for r in raw if r["role"]==role),None)
            need(not exe or traces[exe]==counts[role],"native trace escaped wrapper")
    else:
        pids=set()
        for r in raw:
            need(r["pid"] not in pids and str(r["pid"]) in r["threads"] and sum(r["threads"].values())==r["instructions"] and r["instructions"]>0,"PID/thread census")
            pids.add(r["pid"])
        sums={role:sum(r["instructions"] for r in raw if r["role"]==role) for role in ROLES}
        need(sums==rec["totals"] and (not row or (all(sums[role]==int(row[role]) for role in ROLES) and sum(sums.values())==int(row["total"]))),"sum differs from raw")
    return rec

def stats(pairs,threshold,initial):
    effects=[1-p["candidate"]/p["base"] for p in pairs]
    f=[math.log(p[p["order"][0]]/p[p["order"][1]]) for p in pairs]
    observed=abs(math.fsum(x if p["order"][0]=="base" else -x for x,p in zip(f,pairs)))
    null=[abs(math.fsum(x if i in ids else -x for i,x in enumerate(f))) for ids in itertools.combinations(range(8),4)]
    wins=sum(x>0 for x in effects);losses=sum(x<0 for x in effects);n=wins+losses
    sign=min(1.0,2*sum(math.comb(n,k) for k in range(min(wins,losses)+1))/2**n) if n else 1.0
    perm=sum(s>=observed-1e-12 for s in null)/len(null)
    median=statistics.median(effects)
    return {"n_pairs":len(effects),"median_paired_reduction":median,"rank_interval_99_21875":[min(effects),max(effects)],"wins":wins,"losses":losses,"ties":8-n,"two_sided_sign_p":sign,"balanced_order_randomization_p":perm,"gate_passed":median>0 and sign<threshold and perm<.05 and (not initial or min(effects)>0)}

def inspect(reg,cohort,ep):
    d=RESULTS/cohort/ep
    if (d/"rejected.json").exists():return {"state":"rejected","reason":read(d/"rejected.json")}
    if not (d/"complete.json").exists():return {"state":"collecting" if (d/"samples.csv").exists() else "not yet complete"}
    need(read(d/"complete.json")["common_unchanged"] and read(d/"restore.json")["source_sha256"]==reg["original_sha256"] and read(d/"restore.json")["target_vacant"],"failed fixture restoration")
    roster=read(d/"admission.json");cfg=reg["schedule"][cohort][ep];oracle={};variants={}
    def record(rec,label):
        file_ids={n:(v["size"],v["canonical_sha256"]) for n,v in rec["files"].items()}
        h=rec["source_sha256"]
        need(oracle.setdefault(h,file_ids)==file_ids,"artifact readback differs")
        need(rec["roster"]==roster,"not the admitted workload")
        for name,f in rec["files"].items():
            variants.setdefault(h+"/"+name,{})[label]={"sha256":f["sha256"],"permitted_fields":f["permitted_fields"]}
    for i,(mode,arm) in enumerate(cfg["native_count_admission"]):
        record(audit_run(d/f"admit-{i}-{mode}-{arm}",None,mode),f"{mode}-{arm}")
    rows=list(csv.DictReader((d/"samples.csv").open()))
    need(len(rows)==16,"incomplete")
    pairs=[]
    for i,pair in enumerate(cfg["pairs"]):
        actual=rows[2*i:2*i+2]
        need([r["arm"] for r in actual]==pair["order"] and all(int(r["pair"])==i and int(r["id"])==pair["id"] for r in actual),"schedule mismatch")
        expected=next(r["sha256"] for r in cfg["edits"] if r["id"]==pair["id"])
        mtimes=set()
        for j,r in enumerate(actual):
            label=f"pair-{i}-{j}-"+r["arm"];need(r["receipt"]==label+"/receipt.json","wrong raw directory")
            rec=audit_run(d/label,r,"count");need(rec["source_sha256"]==r["source_sha256"]==expected,"source SHA mismatch")
            mtimes.add(rec["source_mtime_ns"]);record(rec,r["arm"])
        need(len(mtimes)==1,"source mtime drift")
        pairs.append({**pair,**{r["arm"]:int(r["total"]) for r in actual}})
    for h,v in variants.items():
        if len({x["sha256"] for x in v.values()})>1:need(all(x["permitted_fields"] for x in v.values()),"unapproved full digest difference: "+h)
    result=stats(pairs,.05/3 if cohort=="initial" else .05,cohort=="initial")
    roles={arm:{role:statistics.median(int(r[role]) for r in rows if r["arm"]==arm) for role in (*ROLES,"total")} for arm in ARMS}
    med_share={role:statistics.median(int(r[role])/int(r["total"]) for r in rows if r["arm"]=="base") for role in ROLES}
    result.update(state="complete",arm_median_instruction_count=roles,control_median_per_command_role_fraction=med_share,roster={k:roster[k] for k in ("packages","role_counts","tests")},observed_pairs=pairs,different_full_digests={k:v for k,v in variants.items() if len({item["sha256"] for item in v.values()})>1})
    return result

def main():
    reg=read(HERE/"plan.json")
    need(hashlib.sha256((HERE/"plan.json").read_bytes()).hexdigest()==(HERE/"registered.sha256").read_text().split()[0],"registration digest")
    all_results={c:{ep:inspect(reg,c,ep) for ep in COMMANDS} for c in SEEDS}
    qualified={e:all(all_results[c][e].get("gate_passed",False) for c in SEEDS) for e in COMMANDS}
    save(HERE/"summary.json",{"cohorts":all_results,"independently_replicated":qualified})
    lines=["# Release-18 edited uv commands","","The three counted roles are Cargo, all invoked rustc processes and all invoked Wild processes, including their threads. Both arms use the distributed release-18 rustc. Wild runs with --no-fork in both arms. GCC, collect2, wrappers, pre-exec child work and the kernel are excluded. Values are DynamoRIO dynamic application instruction counts.","","| Command | Cohort | Base (billions) | Candidate (billions) | Median reduction | Rank interval | Sign p | Balanced p | Gate |","|---|---|---:|---:|---:|---:|---:|---:|---|"]
    for e in COMMANDS:
        for cohort in SEEDS:
            r=all_results[cohort][e]
            if r["state"]!="complete":lines.append(f'| {e} | {cohort} | | | | | | | {r["state"]} |');continue
            a=r["arm_median_instruction_count"];lo,hi=r["rank_interval_99_21875"]
            lines.append(f'| {e} | {cohort} | {a["base"]["total"]/1e9:.3f} | {a["candidate"]["total"]/1e9:.3f} | {r["median_paired_reduction"]*100:+.3f}% | [{lo*100:+.3f}%, {hi*100:+.3f}%] | {r["two_sided_sign_p"]:.5f} | {r["balanced_order_randomization_p"]:.5f} | {"pass" if r["gate_passed"] else "inconclusive"} |')
    for e in COMMANDS:
        for c in SEEDS:
            r=all_results[c][e]
            if r["state"]=="complete":
                counts=r["roster"]["role_counts"];shares=r["control_median_per_command_role_fraction"]
                desc=", ".join(f"{v:.1%} {k}" for k,v in shares.items())
                lines+=["",f'{e} {c} compiled {r["roster"]["packages"][0][1].split(" (")[0]} with {counts.get("rustc",0)} rustc and {counts.get("wild",0)} Wild processes. It reported {len(r["roster"]["tests"])} test executables. The median control role shares were {desc}.']
            elif r["state"]=="rejected":lines+=["",f'{e} {c} was excluded. {r["reason"]["error"]}']
    (HERE/"SUMMARY.md").write_text("\n".join(lines)+"\n")

if __name__=="__main__":
    main()
