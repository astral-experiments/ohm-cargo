"""Read back all original schedules, raw per-PID counts and role-specific ELF equivalence receipts."""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
old=here.parent/'edited-roles'
sys.path.insert(0,str(old))
import summary


def read(path):return json.loads(path.read_text())


def inspect(cohort,ep):
    summary.RESULTS=here/'results'
    entry=summary.inspect(read(old/'plan.json'),cohort,ep)
    if entry['state']!='complete':return entry
    reg=read(here/'registrations'/f'{cohort}-{ep}.json');root=summary.RESULTS/cohort/ep
    forms_by_edit={};workers=defaultdict(Counter)
    for log in sorted([*root.glob('admit-*'),*root.glob('pair-*')]):
        rec=read(log/'receipt.json');admission=log.name.startswith('admit-');arm=log.name.split('-')[-1]
        for key,meta in rec['files'].items():
            rule=reg['permits'].get(key);proof=meta['permitted_fields']
            if proof is None:
                assert not rule and meta['sha256']==meta['canonical_sha256'];continue
            assert proof['actual_sha256']==meta['sha256'] and proof['bytes']==meta['size']
            assert set(proof['forms'])=={'0','8'} and proof['actual_entsize'] in (0,8)
            assert proof['forms'][str(proof['actual_entsize'])]['sha256']==meta['sha256']
            assert proof['gnu_build_id_end']-proof['gnu_build_id_start']==32
            if rule:
                assert not proof['original_library_test_rule'] and proof['qualification']==rule['qualification']
                assert all(proof[k]==rule['proof'][k] for k in ('bytes','rodata_entsize_offset','gnu_build_id_start','gnu_build_id_end'))
                assert meta['canonical_sha256']==proof['forms']['0']['sha256']
                if admission:assert proof['forms']==rule['proof']['forms']
            else:
                assert ep=='test' and proof['original_library_test_rule'] and proof['qualification'] is None
                assert key.split('/')[-1].startswith('uv-')
            assert forms_by_edit.setdefault((rec['source_sha256'],key),proof['forms'])==proof['forms']
        if not admission:
            for path in log.glob('wild-*.json'):
                row=read(path);key=Path(row['key']).name
                workers[arm+'/'+key][len(row['threads'])]+=1
    entry['instrumented_wild_application_thread_counts']={k:dict(v) for k,v in sorted(workers.items())}
    entry['original_observations_excluded_before_scoring']=len(reg['original_admission_receipts'])
    return entry


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=here/'summary.json');args=p.parse_args()
    rows={c:{ep:inspect(c,ep) for ep in ('build','test')} for c in ('initial','replica')}
    report=dict(cohorts=rows,independently_replicated={ep:all(rows[c][ep].get('gate_passed',False) for c in rows) for ep in ('build','test')},
                interpretation='DynamoRIO application instructions in Cargo, every invoked rustc and Wild, including their application threads. GCC, collect2, wrappers, pre-exec child work and the kernel are excluded. Wild uses --no-fork. The native control demonstrated that jobserver availability can select a different equivalent ELF form. Native elapsed-time trials measure uninstrumented parallelism independently.')
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({c:{e:v.get('median_paired_reduction',v['state']) for e,v in row.items()} for c,row in rows.items()}))


if __name__=='__main__':main()
