"""Excluded, stock-only reproduction of two exact complete executable hashes."""
import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

from recover_forms import forms


here = Path(__file__).resolve().parent
suite, work = here.parent, here.parent.parent
bench = Path((work/'bench-home.path').read_text().strip())
role = 'debug/build/uv/e4ba81db76ae8e19/out/uv'
symbols_hash = 'aae246decf32691311d16083e5e2527ab757349c33a5f91eca57deedb5c4760c'
controls = {
    'distributed': (work/'upstream-monitor/toolchain18/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd', '0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'),
    'release-source': (work/'bin/wild-baseline', '82a927b86f929b67c58be4d37ab8442f32fcdd115d97334dcc5ac190101d8865'),
}


def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(file, data):
    file.write_text(json.dumps(data, indent=2)+'\n')


def paused():
    return any(p.exists() for p in [suite/'edited-roles/control/pause', suite/'lockfile-collision/control/pause'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cohort', choices=['initial', 'replica'])
    args = parser.parse_args()
    cfg = json.loads((here/'registration.json').read_text())
    assert cfg['files'] == {k: sha(here/k) for k in cfg['files']}
    assert sorted(os.sched_getaffinity(0)) == cfg['cpus']
    old = suite/'edited-roles/results'/args.cohort/'build'
    assert (old/'rejected.json').is_file() and not (old/'samples.csv').exists()
    root = bench/'role-studies-18'/args.cohort
    original, parked = root/'target', root/'rejected-build-target'
    temp = bench/'role-elf-calibration'/args.cohort
    temp.mkdir(mode=0o700, parents=True, exist_ok=True)
    out = here/args.cohort
    out.mkdir(exist_ok=True)
    expected = set(cfg['required_full_sha256'][args.cohort])
    assert expected == {json.loads(f.read_text())['files'][role]['sha256'] for f in old.glob('admit-*/receipt.json')}
    proof_file = out/'reconstruction.json'
    if not proof_file.exists():
        if paused(): return
        write(proof_file,forms(parked/role))
    proof = json.loads(proof_file.read_text())
    assert {r['sha256'] for r in proof['forms'].values()} == expected
    base = next(old.glob('admit-*-native-base'))
    original_argv = [json.loads(f.read_text())['argv'] for f in base.glob('wild-*.json') if json.loads(f.read_text())['key']==str(original/role)]
    assert len(original_argv)==1 and original_argv[0].count('--no-fork')==1
    symbols = next((work/'round18-linker/captures18/1').rglob('symbols.o'))
    assert sha(symbols)==symbols_hash
    final = temp/'linked-uv'
    empty = temp/'empty-raw-dylibs';empty.mkdir(exist_ok=True);assert not list(empty.iterdir())
    mapped=[];substitutions=[]
    for i, word in enumerate(original_argv[0]):
        value = word.replace(str(original)+'/', str(parked)+'/')
        if i and original_argv[0][i-1]=='-o': value=str(final)
        elif word.endswith('/symbols.o') and not Path(value).exists(): value=str(symbols)
        elif word.startswith('-plugin-opt=-fresolution='): value='-plugin-opt=-fresolution='+str(temp/'res')
        elif word.startswith('-L') and word.endswith('/raw-dylibs'): value='-L'+str(empty)
        elif word.startswith('/'): assert Path(value).is_file(), word
        if value!=word: substitutions.append([word,value])
        mapped.append(value)
    assert len([p for p in substitutions if p[1]==str(symbols)])==1
    write(out/'argv.json',dict(actual=original_argv[0],replay=mapped,path_substitutions=substitutions,temporary_symbols_sha256=sha(symbols)))
    for name,(exe,exe_sha) in controls.items():
        assert sha(exe)==exe_sha
        seen=set()
        for index,ntokens in enumerate(cfg['jobserver_tokens']):
            sample = out/f'{name}-{index:02}.json'
            if sample.exists():
                observation=json.loads(sample.read_text());assert observation['tokens']==ntokens and observation['executable_sha256']==exe_sha
            else:
                if paused(): print('Paused between control links.',flush=True);return
                rd,wr=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
                try:
                    if ntokens: os.write(wr,b'+'*ntokens)
                    flags=f'-j --jobserver-auth={rd},{wr}'
                    env=dict(os.environ,CARGO_MAKEFLAGS=flags,MAKEFLAGS=flags,LC_ALL='C')
                    # The preceding run may have left a different-size output. Wild always receives a new empty pathname.
                    final.unlink(missing_ok=True)
                    with (out/f'{name}-{index:02}.log').open('wb') as log:
                        result=subprocess.run([str(exe),*mapped],env=env,cwd=temp,pass_fds=(rd,wr),stdout=log,stderr=subprocess.STDOUT)
                    os.close(wr);wr=None
                    returned=os.read(rd,512)
                    observation=dict(executable_sha256=exe_sha,tokens=ntokens,returned_tokens=len(returned),returncode=result.returncode,
                                     bytes=final.stat().st_size if final.exists() else None,output_sha256=sha(final) if result.returncode==0 else None)
                    write(sample,observation)
                finally:
                    os.close(rd)
                    if wr is not None: os.close(wr)
            assert observation['tokens']==observation['returned_tokens'] and observation['returncode']==0, observation
            assert observation['output_sha256'] in expected, observation
            seen.add(observation['output_sha256'])
            if seen==expected: break
        assert seen==expected, f'{name} failed to produce both recorded hashes within the registered cap'
    write(out/'qualified.json',dict(artifact=role,cohort=args.cohort,endpoint='build',whole_file_sha256s=sorted(expected),controls={k:v[1] for k,v in controls.items()},reconstruction_sha256=sha(proof_file),registration_sha256=sha(here/'registration.json')))
    print(f'{args.cohort} stock and matched control A/A qualified',flush=True)


if __name__=='__main__':
    main()
