"""Check exact full SHA-256s for the two possible .rodata forms, redoing Wild's GNU build-ID computation."""
import argparse
import hashlib
import json
import mmap
import struct
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent


def forms(path):
    with path.open("rb") as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_COPY) as buf:
        assert buf[:7] == b"\x7fELF\x02\x01\x01" and struct.unpack_from("<H",buf,18)[0] == 62
        actual = hashlib.sha256(buf).hexdigest()
        table = struct.unpack_from("<Q",buf,40)[0]
        width, total, name_index = struct.unpack_from("<HHH",buf,58)
        assert width == 64 and 0 < name_index < total
        names_at, names_len = struct.unpack_from("<QQ",buf,table+width*name_index+24)
        names = buf[names_at:names_at+names_len]
        fields = {}
        for index in range(total):
            header = table + width*index
            n = struct.unpack_from("<I",buf,header)[0]
            name = names[n:names.index(0,n)]
            if name == b".rodata":
                assert "entsize" not in fields
                fields["entsize"] = header+56
            elif name == b".note.gnu.build-id":
                assert "note" not in fields
                at, size = struct.unpack_from("<QQ",buf,header+24)
                assert size == 48 and struct.unpack_from("<III",buf,at) == (4,32,3) and buf[at+12:at+16] == b"GNU\0"
                fields["note"] = at
        assert set(fields) == {"entsize","note"}
        ent, note = fields["entsize"], fields["note"]
        actual_form = struct.unpack_from("<Q",buf,ent)[0]
        assert actual_form in (0,8) and (ent+8 < note or note+48 < ent)
        header = buf[note:note+16]
        actual_id = buf[note+16:note+48].hex()
        result = {}
        for form in (0,8):
            # The released source hashes the zero-filled whole note before writing its header, name and ID.
            buf[ent] = form
            buf[note:note+48] = bytes(48)
            received = subprocess.run([str(here/"blake-stream")],input=memoryview(buf),stdout=subprocess.PIPE,check=True)
            build_id = bytes.fromhex(received.stdout.decode().strip())
            assert len(build_id) == 32
            buf[note:note+16] = header
            buf[note+16:note+48] = build_id
            result[str(form)] = dict(sha256=hashlib.sha256(buf).hexdigest(),gnu_build_id=build_id.hex())
        assert result[str(actual_form)] == dict(sha256=actual,gnu_build_id=actual_id)
        return dict(bytes=len(buf), actual_sha256=actual, actual_entsize=actual_form, rodata_entsize_offset=ent,
                    gnu_build_id_start=note+16, gnu_build_id_end=note+48, forms=result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("elf",type=Path)
    parser.add_argument("--native-sha256")
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args()
    result = forms(args.elf)
    if args.native_sha256:
        result["recorded_native_sha256"] = args.native_sha256
        result["matches_native_exactly"] = any(x["sha256"] == args.native_sha256 for x in result["forms"].values())
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))
