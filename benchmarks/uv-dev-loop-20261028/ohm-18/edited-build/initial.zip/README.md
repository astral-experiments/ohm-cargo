# Ohm -18 edited-workspace build, initial role-count cohort

Extract the archive into an empty directory. From inside it run:

```sh
python3 -I -B replay.py
```

The standalone replay checks each manifest entry, both immutable registrations, the initial exclusion, specific ELF qualification, the four native/counted × base/candidate re-admissions, exact pairs and edit identities, raw thread counts and per-arm totals, raw Cargo package logs, native exec traces, per-product hash receipts and target restoration. It recomputes the sign and balanced-order tests from eight pairs. The printed interval is the min/max rank interval with 99.21875% coverage. The scope of this packet is the primary cohort alone. Replication requires the independently scheduled repeat.

The workload is the complete uv workspace at the revision in `round18-cargo/edited-roles/plan.json`. After a fixed-width private edit in `crates/uv/src/install_source.rs`, the invocation was `cargo build --locked --offline -j8`. All four original admission cells were repeated on the same predecessor following stock link-layout calibration. The original pre-repair failed admission is retained. The first complete measured pair was suspended at a resource handoff. Its original two rows are bound to `window/individual-release.json`. The other seven pairs reused the same parked arm targets, in their original order.

The eight treatment patches are represented by two self-profiled Cargo drivers and the two matched release-source Wild binaries listed in `round18-cargo/edited-roles/sealed.json`. Both arms used the same distributed Ohm -18 rustc. The metric sums DynamoRIO dynamic application instructions in Cargo, all invoked rustc and Wild processes, and their threads. The GCC and collect2 launches, observer wrappers, pre-exec work and kernel are outside its scope. The collector uses `RUSTC_WRAPPER` to observe rustc, so the result is specific to that Cargo invocation mode. No wall-time estimate was taken.

Every measured link has an output fingerprint and raw Wild count. The two explicitly permitted forms of the ordinary uv ELF were reproduced by both unmodified-source and distributed Wild. Only the already calibrated section header entry-size and its recomputed 32-byte GNU build ID are normalized, with full-file SHA-256 retained for each possible form. The packet includes these signed-off hashes, the selected-role traces and the full reconstruction input manifest. The corresponding original executable bytes are archived separately on the measurement host.
