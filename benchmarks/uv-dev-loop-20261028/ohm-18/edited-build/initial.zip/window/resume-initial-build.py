"""Release only the existing initial/build sampler. Watch free space and restore both pauses."""
import csv,hashlib,json,os,select,shutil,signal,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent
work=here.parents[1]
recover=here.parent/'edited-role-recovery'; old=here.parent/'edited-roles'
home=Path((work/'bench-home.path').read_text().strip())
root=home/'role-studies-18/initial'; out=recover/'results/initial/build'
flags=[old/'control/pause',recover/'control/pause']; flag_hashes=['52ce9dd6f987c9e5e665b8d2aea83425f636b5788d8856bd2119977385b95023','19b368966aec9436b933c178e5f9e891b481e030fa83e02c26994abacfd89816']
cpu=set(range(8,16)); pid=2154220; gib=2**30
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows():return list(csv.DictReader((out/'samples.csv').open()))
def write(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def now():return time.time_ns()
def free():return shutil.disk_usage(root).free
def ident(p):
    s=p.lstat();assert p.is_dir() and not p.is_symlink() and s.st_uid==os.getuid() and p.resolve()==p
    return [s.st_dev,s.st_ino]
def descendants(p):
    children=set()
    for f in (Path('/proc')/str(p)/'task').glob('*/children'):
        try:children.update(map(int,f.read_text().split()))
        except (FileNotFoundError,ProcessLookupError):pass
    return children
def hard_stop(p,seen):
    if p in seen:return
    try:os.kill(p,signal.SIGSTOP)
    except ProcessLookupError:return
    seen.add(p)
    for c in descendants(p):hard_stop(c,seen)
def restore():
    for p,content in zip(flags,saved,strict=True):
        if not p.exists():
            try:
                with p.open('xb') as f:f.write(content)
            except FileExistsError:pass
def bank_state():
    state={}
    for name in ['held-base','held-candidate','rejected-build-structural','common']:
        state[name]=ident(root/name)
    return state
assert sys.argv[1:]==['--individual-release'] and os.getuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd'
window=work/'round18-lab/completed-native-counter-window.json'
assert sh(window)=='c9627a43cdbb56b785ebd88915fe0400479abd3b56ff4718e185afff4e0da124'
assert [sh(p) for p in flags]==flag_hashes
saved=[p.read_bytes() for p in flags]; admission=read(recover/'control/status.json')
assert (admission['state'],admission['cohort'],admission['endpoint'],admission['boundary'],admission['pid'])==('paused','initial','build','after pair 1 of 8',pid)
fd=os.pidfd_open(pid);proc=Path('/proc')/str(pid)
assert proc.stat().st_uid==os.getuid() and os.sched_getaffinity(pid)==cpu
assert (proc/'cmdline').read_bytes().split(bytes(1))[:-1]==[b'python3',b'-I',b'-B',b'work/round18-cargo/edited-role-recovery/recover.py',b'measure',b'initial',b'build',b'--coordinator-released']
initial=rows();assert len(initial)==2 and {r['arm'] for r in initial}=={'base','candidate'} and {r['pair'] for r in initial}=={'0'}
assert not (root/'target').exists() and not any((out/k).exists() for k in ['complete.json','rejected.json','restore.json'])
banks=bank_state();assert len(set(tuple(v) for v in banks.values()))==4
assert free()>132*gib
release=dict(utc_ns=now(),exclusive_cell='initial/build',pid=pid,cpus=sorted(cpu),window_sha256=sh(window),free_bytes=free(),guard_floor_bytes=120*gib,soft_pause_bytes=130*gib,hard_stop_bytes=124*gib,initial_rows=initial,initial_rows_sha256=sh(out/'samples.csv'),initial_banks=banks,registration=sh(recover/'registrations/initial-build.json'))
write(here/'individual-release.json',release)
minimum=release['free_bytes']; samples=0; stopped=[];why=None; triggered=False
try:
    for p in flags:p.unlink()
    while True:
        current=free();minimum=min(minimum,current);samples+=1
        if current<130*gib and not triggered:restore();triggered=True
        if current<124*gib:
            affected=set();hard_stop(pid,affected);stopped=sorted(affected);why='hard disk guard';break
        if select.select([fd],[],[],2)[0]:break
        if triggered and read(recover/'control/status.json')['state']=='paused':why='soft disk guard reached a pair boundary';break
finally:
    restore();os.close(fd)
done=(out/'complete.json').is_file();done_state=read(out/'complete.json') if done else None
record=dict(utc_ns=now(),disk_polls=samples,minimum_free_bytes=minimum,free_bytes=free(),disk_stopped_pids=stopped,guard_reason=why,completed=done,completion=done_state,restore=read(out/'restore.json') if (out/'restore.json').is_file() else None,rows=len(rows()),samples_sha256=sh(out/'samples.csv'),pause_flags=[sh(p) for p in flags],exact_two_owned_banks_absent=all(not (root/k).exists() for k in ['held-base','held-candidate']),preserved_seed_identities={k:ident(root/k) for k in ('rejected-build-structural','common')},new_diagnostics=sorted(p.name for p in root.glob('rejected-recovery-build-*')))
write(here/'individual-closure.json',record);print(json.dumps(record),flush=True)
if done:
    assert not why and minimum>=120*gib and record['rows']==16 and rows()[:2]==initial and record['pause_flags']==flag_hashes and record['exact_two_owned_banks_absent'] and not record['new_diagnostics']
    assert done_state==dict(pairs=8,arms=16,admission_cells=4,common_unchanged=True) and record['restore']['target_vacant']
    assert all(record['preserved_seed_identities'][k]==v for k,v in banks.items() if k in ('rejected-build-structural','common'))
else:sys.exit(2)
