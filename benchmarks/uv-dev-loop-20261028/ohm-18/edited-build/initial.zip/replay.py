"""Replay the initial edited-workspace build from the portable raw-role packet."""
import csv
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
PROJECT=HERE/'round18-cargo'
ORIGINAL=PROJECT/'edited-roles'
RECOVERY=PROJECT/'edited-role-recovery'
KEY='initial/build'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def require(condition, why):
    if not condition:
        raise ValueError(why)


def validate():
    entries=json.loads((HERE/'manifest.json').read_text())
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}-{'manifest.json'}
    require(actual==set(entries),'unexpected or absent packet file')
    for relative, expected in entries.items():
        p=HERE/relative
        require(not p.is_symlink() and p.resolve().is_relative_to(HERE) and digest(p)==expected,relative)
    reg=json.loads((RECOVERY/'registrations/initial-build.json').read_text())
    for relative, expected in reg['inputs'].items():
        require(digest(PROJECT/relative)==expected,'registered input '+relative)
    for relative, expected in reg['original_admission_receipts'].items():
        require(digest(ORIGINAL/relative)==expected,'excluded control '+relative)
    require(digest(ORIGINAL/'plan.json')==(ORIGINAL/'registered.sha256').read_text().split()[0],'original schedule')
    for artifact, rule in reg['permits'].items():
        qualification=PROJECT/'role-elf-calibration/initial/qualified.json'
        q=json.loads(qualification.read_text())
        reconstruction=PROJECT/'role-elf-calibration/initial/reconstruction.json'
        require(digest(qualification)==rule['qualification'] and q['artifact']==artifact and q['reconstruction_sha256']==digest(reconstruction) and rule['proof']==json.loads(reconstruction.read_text()),'calibrated ELF scope')
    sys.path.insert(0,str(RECOVERY))
    import score
    result=score.inspect('initial','build')
    require(json.loads(json.dumps(result))==json.loads((HERE/'result.json').read_text()),'rescored result differs')
    closure=json.loads((HERE/'window/individual-closure.json').read_text())
    rows=list(csv.DictReader((RECOVERY/'results'/KEY/'samples.csv').open()))
    require(closure['completed'] and closure['rows']==len(rows)==16 and closure['exact_two_owned_banks_absent'] and closure['samples_sha256']==digest(RECOVERY/'results'/KEY/'samples.csv'),'counter closure')
    require(rows[:2]==json.loads((HERE/'window/individual-release.json').read_text())['initial_rows'],'original pair not retained')
    return result


if __name__=='__main__':
    r=validate()
    print(json.dumps({k:r[k] for k in ('n_pairs','wins','losses','median_paired_reduction','rank_interval_99_21875','two_sided_sign_p','balanced_order_randomization_p','gate_passed','arm_median_instruction_count','roster')},indent=2))
