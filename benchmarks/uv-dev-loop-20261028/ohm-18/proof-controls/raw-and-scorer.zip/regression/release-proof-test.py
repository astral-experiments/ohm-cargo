"""Run the proposed unused-binary regression against otherwise released Ohm Cargo."""
from datetime import datetime, timezone
from common import *


def main():
    commit = '7caf39914da1e28a67744ecbc963a5f26361474d'
    suite = 'freshness::unused_package_library_does_not_relink_executables'
    baseline = '--baseline' in sys.argv
    root = WORK / 'round18-proof-tests'
    if baseline:
        root = root / 'release-control'
    out = root / 'source'
    root.mkdir(exist_ok=True)
    patches = [WORK / 'round18-compiler/bin-candidate' / name for name in ('proof.patch', 'regression-test.patch')]
    if baseline:
        patches = patches[1:]
    if not (root / 'source.json').exists():
        out.mkdir()
        with subprocess.Popen(['git', '-C', WORK / 'ohm-cargo', 'archive', commit], stdout=subprocess.PIPE) as git:
            subprocess.run(['tar', '-xf', '-', '-C', out], stdin=git.stdout, check=True)
            if git.wait():
                raise RuntimeError('Cargo release archive failed')
        files = ['src/compiler/mod.rs', 'src/compiler/ohm_early_tests.rs', 'src/compiler/fingerprint/mod.rs',
                 'tests/testsuite/freshness.rs']
        before = {p: sha(out / p) for p in files}
        for patch in patches:
            subprocess.run(['patch', '--dry-run', '--fuzz=0', '-p1', '-i', patch], cwd=out, check=True)
            subprocess.run(['patch', '--fuzz=0', '-p1', '-i', patch], cwd=out, check=True)
        source = dict(release=commit, before=before, after={p: sha(out / p) for p in files},
                      patches={p.name: sha(p) for p in patches})
        (root / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
    source = json.loads((root / 'source.json').read_text())
    assert source['release'] == commit and source['patches'] == {p.name: sha(p) for p in patches}
    assert source['after'] == {p: sha(out / p) for p in source['after']}
    local = OLD / 'round18-proof-cargo-tests'
    local.mkdir(exist_ok=True)
    home = local / 'cargo-home'
    if not home.exists():
        pending = local / 'incoming-cargo-home'
        pending.mkdir()
        subprocess.run(['cp', '-a', '--reflink=auto', '--', OLD / 'round18-cargo/registry-seed/registry',
                        pending / 'registry'], check=True)
        pending.rename(home)
    tool = DIST / 'bin'
    target = local / ('target-release-control' if baseline else 'target')
    env = dict(os.environ, PATH=f'{tool}:/usr/local/bin:/usr/bin:/bin', CARGO_HOME=str(home),
               CARGO_TARGET_DIR=str(target), CARGO_TERM_COLOR='never',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
               RUSTC=str(tool / 'rustc'), RUSTDOC=str(tool / 'rustdoc'), RUSTC_BOOTSTRAP='1')
    opt = '--offline' if '--fetch' not in sys.argv else None
    cmd = [tool / 'cargo', '-Zohm-defaults=no', 'test', '--locked', '-j3', '--features', 'ohm-defaults',
           '--test', 'testsuite', *([opt] if opt else []), '--', '--exact', suite, '--nocapture']
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
    logfile = root / (stamp + '.log')
    with logfile.open('x') as f:
        proc = subprocess.Popen(cmd, cwd=out, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        (root / 'active.json').write_text(json.dumps(dict(pgid=proc.pid, argv=list(map(str, cmd)), log=str(logfile))))
        code = proc.wait()
    body = logfile.read_text(errors='replace')
    executable = target / 'debug/cargo'
    if not executable.is_file():
        raise RuntimeError(f'No Cargo executable was built. See {logfile}')
    symbols = ('unused_integration_self_dependency', 'unused_executable_self_dependency')
    found = set()
    with subprocess.Popen(['nm', '--defined-only', executable], stdout=subprocess.PIPE) as proc:
        for line in proc.stdout:
            found.update(name for name in symbols if name.encode() in line)
        assert proc.wait() == 0
    assert found == {symbols[0 if baseline else 1]}, (executable, found)
    identity = dict(cargo_sha256=sha(executable), verified_symbols=sorted(found))
    if baseline:
        assert code != 0 and 'an unused package library must leave both binary outputs fresh' in body, logfile
        assert suite + ' ... FAILED' in body and 'test result: FAILED. 0 passed; 1 failed' in body, logfile
        (root / 'caught-regression.json').write_text(json.dumps(dict(release=commit, test=suite,
            expected='the released Cargo relinks side after its unused package library changes',
            log=str(logfile), log_sha256=sha(logfile), source_sha256=sha(root/'source.json'), **identity), indent=2) + '\n')
        print('Control reproduces the regression', suite, flush=True)
        return
    if code:
        raise RuntimeError(f'See {logfile} (exit {code})')
    assert suite + ' ... ok' in body and 'test result: ok. 1 passed' in body
    (root / 'passed.json').write_text(json.dumps(dict(release=commit, test=suite, log=str(logfile),
                 log_sha256=sha(logfile), source_sha256=sha(root/'source.json'), **identity), indent=2) + '\n')
    print('Passed', suite, flush=True)


if __name__ == '__main__':
    main()
