"""Recompute the warm binary-reuse control from its recorded Cargo instruction logs."""
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics

from analyze import median_interval, signed_histogram, two_sided_sign

ROOT = Path(__file__).resolve().parent
REGISTRATION = '71eb9c97467319b3af85633fbf15ffd94fc9311f98855ae3b0b32ee5d61e6abd'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def count(path, mode, endpoint):
    body = path.read_text()
    assert 'Finished ' in body and not re.search(r'^\s*(Checking|Compiling|Downloading|Updating) ', body, re.M), path
    assert len(re.findall(r'^\s*Executable ', body, re.M)) == (72 if endpoint == 'test' else 0), path
    if mode == 'dynamorio':
        line, = re.findall(r'^DynamoRIO (.+)$', body, re.M)
        record = json.loads(line)
        assert sum(record['threads'].values()) == record['instructions']
        return record['instructions']
    assert mode == 'instructions', mode
    line, = re.findall(r'\bI refs:\s+([\d,]+)', body)
    return int(line.replace(',', ''))


def score():
    path = ROOT / 'registered-proof-warm-control.json'
    assert digest(path) == REGISTRATION
    plan = json.loads(path.read_text())
    out = {}
    for cohort, config in plan['cohorts'].items():
        folder = ROOT / 'proof-warm-control' / cohort
        table = folder / 'pairs.csv'
        audit = json.loads((folder / 'audited.json').read_text())
        assert audit['csv_sha256'] == digest(table) and audit['registered_sha256'] == REGISTRATION
        with table.open() as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == audit['rows'] == 2 * config['pairs'] * len(plan['endpoints'])
        out[cohort] = {}
        for ep in plan['endpoints']:
            part = [r for r in rows if r['endpoint'] == ep]
            delta = []
            periods = []
            for i, order in enumerate(config['orders'][ep]):
                pair = part[2 * i:2 * i + 2]
                assert [r['arm'] for r in pair] == order
                values = {}
                for k, row in enumerate(pair):
                    arm = row['arm']
                    assert int(row['order']) == k and int(row['pair']) == i
                    values[arm] = count(folder / f'{ep}-{i}-{arm}.log', config['mode'], ep)
                    assert int(row['value']) == values[arm]
                delta.append(100 * (1 - values['candidate'] / values['base']))
                difference = values[order[0]] - values[order[1]]
                periods.append((difference > 0) - (difference < 0))
            wins = sum(v > 0 for v in delta)
            losses = sum(v < 0 for v in delta)
            hist = signed_histogram(periods, len(periods) // 2)
            sign = two_sided_sign(wins, losses)
            order_p = sum(n for x, n in hist.items() if abs(x) >= abs(wins - losses)) / sum(hist.values())
            med = statistics.median(delta)
            ci = median_interval(delta)
            alpha = .05 / 3 if cohort == 'initial' else .05
            out[cohort][ep] = dict(pairs=len(delta), wins=wins, losses=losses, paired_median_saving_pct=med,
                interval=ci, sign_p=sign, order_p=order_p,
                material_regression=med < -.5 and ci['upper'] < -.5 and sign < alpha and order_p < alpha)
    return dict(registration=REGISTRATION, cohorts=out, material_warm_regressions=[
        ep for ep in plan['endpoints'] if all(v[ep]['material_regression'] for v in out.values())])


if __name__ == '__main__':
    print(json.dumps(score(), indent=2))
