"""Apply a pre-observation CPU reassignment while retaining the original sealed harness."""
import json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run,series

here=Path(__file__).resolve().parent
receipt=json.loads((here/"measurement-affinity.json").read_text())
original=run.checked_plan
def checked(phase):
    cfg=original("seal")
    run.need(receipt["original_plan_sha256"]==run.sha(here/"plan.json") and receipt["original_seal_sha256"]==run.sha(here/"sealed.json"),"original frozen inputs changed")
    run.need(receipt["wrapper_sha256"]==run.sha(Path(__file__).resolve()),"affinity wrapper changed")
    run.need(receipt["actual_cpus"]==sorted(os.sched_getaffinity(0)),"incorrect amended CPU set")
    return cfg

if __name__=="__main__":
    checked("seal")
    if len(sys.argv)>1:
        run.checked_plan=checked
        run.main()
    else:
        series.run=lambda *args:subprocess.run([sys.executable,"-B",str(Path(__file__).resolve()),*args]).returncode
        series.main()
