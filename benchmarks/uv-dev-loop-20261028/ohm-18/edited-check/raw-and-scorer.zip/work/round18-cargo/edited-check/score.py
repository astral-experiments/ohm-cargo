"""Recompute only the released, completed edited-check cohorts from their raw PID receipts."""
import argparse
import csv
import hashlib
import io
import json
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
study = here.parent / "edited-roles"
work = here.parents[1]
sys.path.insert(0, str(study))
import summary


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_text())


def recompute():
    sealed = load(study / "sealed.json")
    plan = load(study / "plan.json")
    assert digest(study / "plan.json") == sealed["plan"] == (study / "registered.sha256").read_text().split()[0]
    assert digest(study / "PROTOCOL.md") == plan["protocol_sha256"]
    assert digest(study / "plan.py") == plan["plan_code_sha256"]
    assert digest(here / "inputs/original.rs") == plan["original_sha256"]
    for name, sha in sealed["harness"].items():
        assert digest(study / name) == sha
    for name, sha in sealed["wrapper_inputs"].items():
        assert digest(work / name) == sha
    assert digest(study / "measurement-affinity.py") == load(study / "measurement-affinity.json")["wrapper_sha256"]
    csv_buffer = io.StringIO(newline="")
    columns = ("cohort", "pair", "position", "arm", "edit", "source_sha256", "source_mtime_ns", "cargo_pid",
               "cargo_threads", "cargo_instructions", "rustc_pid", "rustc_threads", "rustc_instructions",
               "wild_processes", "wild_instructions", "total_instructions", "rmeta_sha256", "cargo_raw", "rustc_raw")
    writer = csv.DictWriter(csv_buffer, columns, lineterminator="\n")
    writer.writeheader()
    cohorts = {}
    for cohort in ("initial", "replica"):
        cfg = plan["schedule"][cohort]["check"]
        for edit in cfg["edits"]:
            assert digest(here / "inputs" / f'{cfg["symbol"]}{edit["id"]:02}.rs') == edit["sha256"]
        result = summary.inspect(plan, cohort, "check")
        assert result["state"] == "complete" and result["roster"]["role_counts"] == {"cargo":1, "rustc":1}
        assert not result["roster"]["tests"] and not result["different_full_digests"]
        cohorts[cohort] = result
        folder = study / "results" / cohort / "check"
        seen_stamps = {}
        for row in csv.DictReader((folder / "samples.csv").open()):
            pair, position, arm = int(row["pair"]), int(row["position"]), row["arm"]
            registered = cfg["pairs"][pair]
            assert int(row["id"]) == registered["id"] and arm == registered["order"][position]
            receipt = folder / row["receipt"]
            run = load(receipt)
            stamp = run["source_mtime_ns"]
            assert seen_stamps.setdefault(pair, stamp) == stamp
            assert len(run["files"]) == 1
            artifact, item = next(iter(run["files"].items()))
            assert artifact.endswith(".rmeta") and item["sha256"] == item["canonical_sha256"] and not item["permitted_fields"]
            flat = dict(cohort=cohort, pair=pair, position=position, arm=arm, edit=f'{cfg["symbol"]}{registered["id"]:02}',
                        source_sha256=row["source_sha256"], source_mtime_ns=stamp, wild_processes=0,
                        wild_instructions=0, total_instructions=int(row["total"]), rmeta_sha256=item["sha256"])
            assert int(row["wild"]) == 0
            for role in ("cargo", "rustc"):
                raw_files = list(receipt.parent.glob(role + "-*.json"))
                assert len(raw_files) == 1
                raw = load(raw_files[0])
                assert raw["role"] == role and sum(raw["threads"].values()) == raw["instructions"] == int(row[role])
                flat.update({role+"_pid":raw["pid"], role+"_threads":len(raw["threads"]),
                             role+"_instructions":raw["instructions"], role+"_raw":str(raw_files[0].relative_to(study))})
            assert flat["cargo_instructions"] + flat["rustc_instructions"] == flat["total_instructions"]
            writer.writerow(flat)
    report = dict(command=["cargo", *plan["schedule"]["initial"]["check"]["command"]], uv=plan["uv"], edit=plan["edit"],
                  release=plan["release"], arms=sealed["arms"], rustc_sha256=plan["rustc_sha256"],
                  plan_sha256=sealed["plan"], cohorts=cohorts,
                  independently_replicated=all(v["gate_passed"] for v in cohorts.values()))
    lines = ["# Release-18 edited uv check", "",
             "Both cohorts ran full-workspace `cargo check --locked --offline -j8` after changing the private Homebrew path predicate in `crates/uv/src/install_source.rs`. The structural edit accepted an additional `uv-preview-A00` or `uv-preview-J00` directory name. Each subsequent edit changed only the two decimal digits. Each pair used the same edit bytes, mtime, visible paths and predecessor history. The initial and replica fixtures used independent roots, schedules and literals. The original and every exact edit are in `inputs/`.",
             "",
             "The control used matched, separately trained release-18 PGO Cargo. The treatment used the five Cargo changes and the guarded standard-library path comparison linked into Cargo. Each compile used the same distributed release-18 rustc. Both stacks selected their corresponding Wild executable. Every admitted and held-out check ran exactly one Cargo process and one rustc process, rebuilt only the uv library and emitted byte-identical metadata across arms for each edit. No Wild or tests ran.",
             "",
             "| Cohort | Base instructions | Candidate instructions | Paired reduction | Exact 99.22% rank interval | Wins | Sign p | Balanced-order p |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for label, r in cohorts.items():
        med = r["arm_median_instruction_count"]
        lo, hi = r["rank_interval_99_21875"]
        lines.append(f'| {label} | {med["base"]["total"]/1e9:.6f}B | {med["candidate"]["total"]/1e9:.6f}B | {r["median_paired_reduction"]:.4%} | {lo:.4%} to {hi:.4%} | {r["wins"]}/8 | {r["two_sided_sign_p"]:.8g} | {r["balanced_order_randomization_p"]:.8g} |')
    lines += ["", "The registered primary gate required a positive initial rank interval, two-sided sign p below .05/3 and an exact balanced-order p below .05. The independent repetition required a positive median and both two-sided p values below .05. Both cohorts passed.",
              "",
              "The counters sum dynamic application instructions from all threads in Cargo and every invoked rustc and Wild. Kernel instructions, pre-exec child work and launchers lie outside the metric. Native elapsed time is a separate experiment.",
              "",
              "| Cohort | Control Cargo share | Control rustc share |",
              "|---|---:|---:|"]
    for label, r in cohorts.items():
        shares = r["control_median_per_command_role_fraction"]
        lines.append(f'| {label} | {shares["cargo"]:.3%} | {shares["rustc"]:.3%} |')
    lines += ["", "From the root of an extracted copy, run the following commands using Python 3.11 or later. The scorer re-joins each scheduled assignment with per-process and per-thread receipts, checks the native and instrumented rosters and output hashes, then recalculates both gates. The CSV lists one row per held-out command and points to each raw PID receipt. The frozen plan also includes schedules for the separately collected endpoints. This packet includes only the completed check observations.",
              "", "```sh", "sha256sum -c work/round18-cargo/edited-check/SHA256SUMS",
              "python3 -I -B work/round18-cargo/edited-check/score.py", "```", ""]
    return {"results.json":json.dumps(report, indent=2)+"\n", "paired-role-counts.csv":csv_buffer.getvalue(),
            "RESULTS.md":"\n".join(lines)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    for name, contents in recompute().items():
        if args.write:
            (here / name).write_text(contents)
        else:
            assert (here / name).read_bytes() == contents.encode(), name + " differs from the raw data"
    print("Verified both edited-check cohorts, 32 held-out commands and 64 measured process records.")
