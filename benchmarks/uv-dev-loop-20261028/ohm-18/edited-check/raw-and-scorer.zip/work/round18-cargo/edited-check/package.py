"""Save portable evidence for the two completed check cohorts without reading later endpoint samples."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parents[1]
root = work.parent
study = here.parent / "edited-roles"
sys.path.insert(0, str(study))
import plan


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    registration = json.loads((study / "plan.json").read_text())
    seal = json.loads((study / "sealed.json").read_text())
    assert sha(study / "plan.py") == registration["plan_code_sha256"]
    inputs = here / "inputs"
    inputs.mkdir(exist_ok=True)
    (inputs / "original.rs").write_bytes(plan.ORIGINAL)
    for cohort in ("initial", "replica"):
        cfg = registration["schedule"][cohort]["check"]
        assert (study / "results" / cohort / "check/complete.json").exists()
        for edit in cfg["edits"]:
            path = inputs / f'{cfg["symbol"]}{edit["id"]:02}.rs'
            path.write_bytes(plan.body(cfg["symbol"], edit["id"]))
            assert sha(path) == edit["sha256"]
    subprocess.run([sys.executable, "-I", "-B", str(here/"score.py"), "--write"], check=True)
    files = {here/name for name in ("package.py","score.py","RESULTS.md","results.json","paired-role-counts.csv")}
    files.update(inputs.glob("*.rs"))
    for name in ("PROTOCOL.md","REPRODUCE.md","plan.json","plan.py","registered.sha256","sealed.json","run.py","series.py",
                 "summary.py","measurement-affinity.json","measurement-affinity.py","warm-affinity.json",
                 "affinity-launch-excluded.json","affinity-launch-excluded.log"):
        files.add(study / name)
    files.update(work/name for name in seal["wrapper_inputs"])
    for folder in (study/"calibration", study/"results/initial/check", study/"results/replica/check"):
        files.update(path for path in folder.rglob("*") if path.is_file())
    files = sorted(files)
    names = [str(path.relative_to(root)) for path in files]
    assert all("/results/" not in name or "/check/" in name for name in names)
    manifest = here / "SHA256SUMS"
    manifest.write_text("".join(f"{sha(path)}  {name}\n" for path,name in zip(files,names)))
    target = here.parent / "edited-check-evidence.zip"
    pending = target.with_suffix(".pending")
    with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=5) as packet:
        for file in [*files, manifest]:
            packet.write(file, str(file.relative_to(root)))
        packet.write(here/"RESULTS.md", "README.md")
    with tempfile.TemporaryDirectory() as temp, zipfile.ZipFile(pending) as packet:
        assert packet.testzip() is None
        packet.extractall(temp)
        checker = Path(temp) / (here / "score.py").relative_to(root)
        subprocess.run([sys.executable, "-I", "-B", str(checker)], cwd=temp, check=True)
        subprocess.run(["sha256sum", "--check", str(manifest.relative_to(root))], cwd=temp,
                       check=True, stdout=subprocess.DEVNULL)
    pending.replace(target)
    identity = dict(file=target.name, sha256=sha(target), bytes=target.stat().st_size, entries=len(files)+2)
    (here/"archive.json").write_text(json.dumps(identity,indent=2)+"\n")
    print(json.dumps(identity), flush=True)


if __name__ == "__main__":
    main()
