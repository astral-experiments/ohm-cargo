"""Audit the two known varying fields of Wild's linked uv executable."""
import hashlib,mmap,struct

def uv_elf(path):
    with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as buf:
        assert buf[:6]==b'\x7fELF\x02\x01'
        table=struct.unpack_from('<Q',buf,40)[0]
        width,number,strings_index=struct.unpack_from('<HHH',buf,58)
        assert width==64 and strings_index<number
        names,size=struct.unpack_from('<QQ',buf,table+strings_index*width+24)
        names=buf[names:names+size]; fields={};raw=hashlib.sha256(buf).hexdigest()
        for i in range(number):
            sh=table+i*width
            name_at,kind,flags=struct.unpack_from('<IIQ',buf,sh)
            name=names[name_at:names.index(0,name_at)]
            if name==b'.rodata':
                index=sh+56;entsize=struct.unpack_from('<Q',buf,index)[0]
                assert kind==1 and entsize in (0,8) and flags&0x32==0x32
                fields['rodata']=(index,index+1,entsize)
            if name==b'.note.gnu.build-id':
                start=struct.unpack_from('<Q',buf,sh+24)[0]
                assert kind==7 and struct.unpack_from('<III',buf,start)==(4,32,3) and buf[start+12:start+16]==b'GNU\x00'
                fields['build_id']=(start+16,start+48,buf[start+16:start+48].hex())
        assert set(fields)=={'rodata','build_id'}
        hashed=hashlib.sha256();old=0
        for a,b,_ in sorted(fields.values()):
            hashed.update(memoryview(buf)[old:a]);hashed.update(b'\x00'*(b-a));old=b
        hashed.update(memoryview(buf)[old:])
        return dict(raw_sha256=raw,canonical_sha256=hashed.hexdigest(),size=len(buf),normalized_fields=fields)
