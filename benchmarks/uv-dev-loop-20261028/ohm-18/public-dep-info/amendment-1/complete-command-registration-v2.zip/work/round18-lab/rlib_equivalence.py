"""Hash Ohm archives with rustc's observed incremental session suffix normalized."""
import hashlib,re

NAME=re.compile(rb'(uv-[0-9a-f]{16}\.[a-z0-9]+\.)([a-z0-9]{7})(\.rcgu\.o)')

def archive(path):
    hashed=hashlib.sha256();raw=hashlib.sha256();session=None;counts={}
    def add(data):
        hashed.update(data);raw.update(data)
    with path.open('rb') as f:
        magic=f.read(8)
        assert magic==b'!<arch>\n'
        add(magic)
        while header:=f.read(60):
            assert len(header)==60 and header[-2:]==b'\x60\n'
            add(header)
            size=int(header[48:58]);name=header[:16].strip()
            data=f.read(size)
            assert len(data)==size
            if name in (b'//',b'lib.rmeta-link/'):
                matches=list(NAME.finditer(data))
                tags={m[2] for m in matches}
                assert len(tags)==1 and matches
                tag=next(iter(tags)); assert session is None or tag==session
                session=tag
                counts[name.decode()]=len(matches)
                normalized=NAME.sub(lambda m:m[1]+b'0000000'+m[3],data)
                assert len(normalized)==size
                hashed.update(normalized);raw.update(data)
            else:add(data)
            if size%2:add(f.read(1))
    assert counts.get('//',0)==counts.get('lib.rmeta-link/',-1)
    return dict(raw_sha256=raw.hexdigest(),normalized_sha256=hashed.hexdigest(),member_nonce=session.decode(),replacement_counts=counts)
