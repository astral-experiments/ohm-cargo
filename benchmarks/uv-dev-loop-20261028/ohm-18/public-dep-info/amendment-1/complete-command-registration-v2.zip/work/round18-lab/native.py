"""Measure direct Cargo wall time across registered arms and identical source edits."""
import argparse
import collections
import contextlib
import csv
import datetime
import fcntl
import itertools
import re
import shutil
import statistics
import threading
import time
from common import *
from rlib_equivalence import archive
from elf_equivalence import uv_elf

def write(path,obj):
    with path.open('x') as f:f.write(json.dumps(obj,indent=2)+'\n')

def stats_cpu(cpus):
    rows=[list(map(int,s.split()[1:9])) for s in Path('/proc/stat').read_text().splitlines() if s.split()[0] in {f'cpu{i}' for i in cpus}]
    return [sum(c) for c in zip(*rows)]

def host(cpus):
    mem={k[:-1]:int(v) for k,v,*_ in (s.split() for s in Path('/proc/meminfo').read_text().splitlines())}
    return dict(ts=time.time_ns(),cpu=stats_cpu(cpus),dirty_kib=mem['Dirty'],writeback_kib=mem['Writeback'],load=os.getloadavg())

def procs(pgid):
    found=[]
    for f in Path('/proc').glob('[0-9]*/stat'):
        try: s=f.read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        if s[0] not in ('Z','X') and int(s[2])==pgid:found.append(int(f.parent.name))
    return found

def foreign():
    exes={'rustc','rust-lld','ld.bfd','ld','drrun','valgrind','cargo','wild','clang','cc1','cc1plus','ld.lld','rustdoc','collect2','ninja','llvm-tblgen','llvm-min-tblgen','pgobench','llvm-profdata'}
    result=[]
    for p in Path('/proc').glob('[0-9]*'):
        try:
            path=Path(os.readlink(p/'exe'));exe=path.name
            task_binary=(path.is_relative_to(WORK) or path.is_relative_to(OLD)) and (exe in ('base','candidate','guard-stack') or exe.startswith('js-refresh'))
            if task_binary or exe in exes or exe.startswith(('cargo-','rustc-','clang-','clang++')) or exe.endswith(('-wild','-cargo')):
                result.append([int(p.name),exe])
        except (FileNotFoundError,ProcessLookupError,PermissionError): continue
    return result

def quiet(cpus,log):
    streak=0
    with log.open('x',buffering=1) as f:
        while streak<2:
            a=host(cpus);time.sleep(5);b=host(cpus)
            d=[y-x for x,y in zip(a['cpu'],b['cpu'])];tot=sum(d)
            busy=1-(d[3]+d[4])/tot;wait=d[4]/tot;other=foreign()
            good=busy<.05 and wait<.02 and b['dirty_kib']<65536 and b['writeback_kib']<8192 and not other and (LAB/'host-cleared-for-native').is_file()
            streak=(streak+1 if good else 0)
            f.write(json.dumps([b['ts'],busy,wait,b['dirty_kib'],b['writeback_kib'],other,streak])+'\n')

def select(src,dest):
    tmp=dest.with_name(dest.name+'.round18-next')
    if tmp.exists():raise ValueError(f'occupied switch {tmp}')
    os.link(src,tmp)
    os.replace(tmp,dest)
    tmp.unlink(missing_ok=True)
    assert os.path.samefile(src,dest)

def stage(plan,study):
    loc=ROOT/'bin-variants'/study
    loc.mkdir(parents=True,exist_ok=True)
    actual={}
    for arm,roles in plan['arms'].items():
        actual[arm]={}
        for role,rel in roles.items():
            src=WORK/rel
            name=f'{arm}-{role}'
            dest=loc/name
            if not dest.exists():
                shutil.copy2(src,dest)
            hs=sha(src)
            if sha(dest)!=hs:raise ValueError(f'stale copy {dest}')
            actual[arm][role]={'path':str(dest),'sha256':hs,'source':str(src)}
    return actual

def exec_trace(path,slot,rustc,linker):
    selected={str(slot):'cargo',str(rustc):'rustc',str(linker):'wild'}
    counted=collections.Counter()
    for trace in path.glob('exec.*'):
        for line in trace.read_text(errors='replace').splitlines():
            if not line.startswith('execve(') or not re.search(r'= 0$',line):continue
            match=re.match(r'execve\(("([^"\\]|\\.)*")',line)
            if not match:raise RuntimeError(line[:160])
            argv0=json.loads(match[1])
            if argv0 in selected:counted[selected[argv0]]+=1
            elif Path(argv0).name in ('cargo','rustc','rust-lld','ld','ld.bfd','wild','ld.lld'):
                raise RuntimeError(f'unexpected native compiler or linker {argv0}')
    if counted['cargo']!=1 or counted['rustc']<1:raise RuntimeError(f'expected native edit {counted}')
    return dict(counted)

def artifacts(root,ep,roster):
    target=root/'target'
    if ep=='check':
        # Cargo check can reuse native metadata. Its .rmeta files are path-stable across arms.
        paths=list((target/'debug/build/uv').glob('*/out/libuv-*.rmeta'))
    else:
        paths=[target/'debug/uvx']
    if ep=='test':
        paths += [Path(s.rsplit(' (',1)[1][:-1]) for s in roster['tests']]
    chosen={str(p.relative_to(target)):sha(p) for p in set(paths) if p.is_file()}
    if not chosen: raise RuntimeError(f'no {ep} artifacts')
    extra={}
    if ep!='check':
        rlib=archive(target/'debug/libuv.rlib');chosen['debug/libuv.rlib@normalized-rcgu-session']=rlib['normalized_sha256']
        exe=uv_elf(target/'debug/uv');chosen['debug/uv@normalized-rodata-entsize-buildid']=exe['canonical_sha256']
        extra={'archive':rlib,'uv_elf':exe}
    return chosen,extra

def run_command(root,ep,out,cpus,*,trace=False,measure=False,settle=False,options=None):
    out.mkdir()
    argv=command(ep,options)
    if trace:argv=['strace','-ff','-qq','-s','2048','-e','trace=execve,execveat','-o',str(out/'exec'),*argv]
    telemetry=host(cpus)
    with (out/'cargo.log').open('x') as f:
        start=time.perf_counter_ns()
        proc=subprocess.Popen(argv,cwd=root/'uv',env=env(root),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        _,status,usage=os.wait4(proc.pid,0)
        stop=time.perf_counter_ns()
        proc.returncode=os.waitstatus_to_exitcode(status)
    limit=time.monotonic()+45
    while pending:=procs(proc.pid):
        if time.monotonic()>limit: raise RuntimeError(f'leftover descendants {pending}')
        time.sleep(.025)
    if proc.returncode:raise RuntimeError(f'{out}: {(out/"cargo.log").read_text()[-1400:]}')
    ro=rosters((out/'cargo.log').read_text(errors='replace'))
    if ((not settle and (len(ro['compiled'])!=1 or not ro['compiled'][0].startswith('uv v0.12.0 (')))
            or len(ro['tests'])!=(72 if ep=='test' else 0)):
        raise RuntimeError(f"{out}: wrong build roster: {ro['compiled']}, {len(ro['tests'])} tests")
    result=dict(utc_ns=telemetry['ts'],elapsed_ns=stop-start,seconds_user=usage.ru_utime,seconds_system=usage.ru_stime,
                voluntary_switches=usage.ru_nvcsw,involuntary_switches=usage.ru_nivcsw,input_blocks=usage.ru_inblock,
                output_blocks=usage.ru_oublock,major_faults=usage.ru_majflt,minor_faults=usage.ru_minflt,
                before=telemetry,after=host(cpus),roster=ro,measured=measure)
    if trace:
        result['roles']=exec_trace(out,ROOT/'tools/bin/cargo',ROOT/'tools/bin/rustc',ROOT/'tools'/LINK)
        result['outputs'],result['raw_artifact_receipts']=artifacts(root,ep,ro)
    write(out/'receipt.json', result)
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('cohort',choices=['initial','replica'])
    parser.add_argument('--plan',type=Path,default=LAB/'registered18.json')
    parser.add_argument('--study',default='r18-native')
    parser.add_argument('--phase',choices=['prep','time','all'],default='all')
    parser.add_argument('--skip-quiet-pilot',action='store_true')
    args=parser.parse_args()
    plan=json.loads(args.plan.read_text())
    cfg=plan['cohorts'][args.cohort]
    cpus=cfg.get('cpu',plan['cpu'])
    options=cfg.get('options',plan.get('options'))
    shape=cfg.get('edit_shape','predicate')
    if sorted(os.sched_getaffinity(0))!=cpus:raise ValueError(f'expected CPUs {cpus}')
    if args.skip_quiet_pilot and 'pilot' not in args.study:raise ValueError('quiet gate required')
    root=Path(cfg['root'])
    parked=root/plan.get('target_pool',args.study)
    if not (parked/'ready').is_file():raise RuntimeError(f'target copies pending {parked}')
    out=LAB/args.study/args.cohort
    out.mkdir(parents=True,exist_ok=True)
    slot={'cargo':ROOT/'tools/bin/cargo','wild':ROOT/'tools'/LINK}
    source=root/'uv'/EDIT_PATH
    pristine=(root/'original').read_bytes()
    lock_file=(ROOT/'native-lease').open('a')
    fcntl.flock(lock_file,fcntl.LOCK_EX)
    try:
        assert source.read_bytes()==pristine
        original_time=source.stat()
        locksha=sha(root/'uv/Cargo.lock')
        arms=stage(plan,args.study)
        originals={}
        for role,dest in slot.items():
            base=ROOT/f'official-original-{role}'
            if not base.exists():os.link(dest,base)
            if sha(dest)!=sha(DIST/('bin/cargo' if role=='cargo' else LINK)) or not dest.samefile(base):
                raise RuntimeError('official private slots were not restored')
            originals[role]=base
        def choose(arm):
            for role,path in slot.items():select(Path(arms[arm][role]['path']),path)
        @contextlib.contextmanager
        def use(arm):
            active=root/'target'
            held=parked/arm
            if active.exists() or not held.is_dir():raise RuntimeError('invalid parked target state')
            held.rename(active)
            try:
                choose(arm)
                yield
            finally:
                active.rename(held)
        seed=parked/'original-target'
        if seed.exists() or not (root/'target').is_dir():raise RuntimeError('unrestored seed')
        (root/'target').rename(seed)
        try:
            info={'plan_sha256':sha(args.plan),'uv':REVISION,'release':'ohm-1.99.0-18',
                  'original_rustc_sha256':sha(ROOT/'tools/bin/rustc'),'arm_binaries':arms,
                  'target':str(root/'target'),'compiler':str(ROOT/'tools/bin/rustc'),
                  'edited_file':str(source),'edit_shape':shape,'argv':{ep:command(ep,options) for ep in cfg['endpoint_order']},'uv_lock_sha256':locksha,'cpus':cpus}
            if (out/'inputs.json').is_file():
                if json.loads((out/'inputs.json').read_text())!=info:raise RuntimeError('changed inputs')
            else:write(out/'inputs.json',info)
            for ep in cfg['endpoint_order']:
                assignment=cfg['endpoints'][ep]
                epout=out/ep
                epout.mkdir(exist_ok=True)
                if (epout/'done.json').is_file():continue
                previous=epout/'admitted.json'
                if not previous.exists():
                    # First transition may rebuild additional native targets after a check build.
                    # Both precursor edits and the measured edits have the same source length.
                    for i,kind in enumerate(['settle','admission']):
                        tag=assignment[0]['literal'][:-2]+f'{i:02}'
                        srcsha=edit(root,tag,shape)
                        admission={}
                        for arm in plan['arms']:
                            with use(arm):
                                res=run_command(root,ep,epout/f'{kind}-{arm}',cpus,trace=kind=='admission',settle=kind=='settle',options=options)
                            admission[arm]={'roster':res['roster']}
                            if kind=='admission':
                                admission[arm].update(roles=res['roles'],outputs=res['outputs'])
                        if kind=='admission':
                            values=list(admission.values())
                            if any(v['roster']!=values[0]['roster'] for v in values):raise RuntimeError('different test/build rosters')
                            if not plan.get('expect_artifact_differences',False) and any(v['outputs']!=values[0]['outputs'] for v in values):
                                # Keep all evidence even when a nonsemantic output needs investigation.
                                write(epout/'artifact-difference.json',admission)
                                raise RuntimeError(f'different admission outputs for {ep}')
                            if not plan.get('expect_role_differences',False) and any(v['roles']!=values[0]['roles'] for v in values):
                                raise RuntimeError(f'different native roles for {ep}')
                            write(previous,{'input_sha256':srcsha,'arms':admission})
                if args.phase=='prep':continue
                admitted=json.loads(previous.read_text())['arms']
                if not args.skip_quiet_pilot:
                    if (Path('/proc/1/comm').read_text().strip()!='systemd' or os.geteuid()==0):
                        raise RuntimeError('host process visibility under the ordinary devbox account is required for quiet measurements')
                    quiet(cpus,epout/'quiet.jsonl')
                rows=epout/'timings.csv'
                with rows.open('x',buffering=1,newline='') as f:
                    fields=['block','rank','arm','literal','source_sha256','elapsed_ns','utc_ns','seconds_user','seconds_system','voluntary_switches','involuntary_switches','input_blocks','output_blocks','major_faults','minor_faults']
                    wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
                    for block,trial in enumerate(assignment):
                        literal=trial['literal']
                        source_sha=edit(root,literal,shape)
                        for rank,arm in enumerate(trial['order']):
                            with use(arm):
                                res=run_command(root,ep,epout/f'm{block:02}-{rank}-{arm}',cpus,measure=True,options=options)
                            if not args.skip_quiet_pilot:
                                with (epout/'external-activity.jsonl').open('a') as external:
                                    external.write(json.dumps([time.time_ns(),block,rank,arm,foreign()])+'\n')
                            if res['roster']!=admitted[arm]['roster']:raise RuntimeError('timed roster drifted')
                            row={k:res[k] for k in fields if k in res}
                            row.update(block=block,rank=rank,arm=arm,literal=literal,source_sha256=source_sha)
                            wr.writerow(row)
                endsha=edit(root,assignment[0]['literal'][:-2]+'90',shape)
                post={}
                for arm in plan['arms']:
                    with use(arm):
                        res=run_command(root,ep,epout/f'post-{arm}',cpus,trace=True,options=options)
                    if res['roster']!=admitted[arm]['roster'] or res['roles']!=admitted[arm]['roles']:
                        raise RuntimeError('post-run workload drift')
                    post[arm]=res['outputs']
                if not plan.get('expect_artifact_differences',False) and len(set(map(lambda v:json.dumps(v,sort_keys=True),post.values())))!=1:
                    raise RuntimeError('post-run products differ')
                write(epout/'done.json',dict(post_source=endsha,rows=sha(rows),post=post))
                print(args.study,args.cohort,ep,'finished',flush=True)
        finally:
            if not (root/'target').exists():seed.rename(root/'target')
            for role,path in slot.items():select(originals[role],path)
            source.write_bytes(pristine);os.utime(source,ns=(original_time.st_atime_ns,original_time.st_mtime_ns))
            if sha(root/'uv/Cargo.lock')!=locksha:raise RuntimeError('Cargo.lock changed')
            if any(not slot[role].samefile(src) for role,src in originals.items()) or sha(source)!=sha(root/'original'):
                raise RuntimeError('restoration failed')
    finally:lock_file.close()

if __name__=='__main__':main()
