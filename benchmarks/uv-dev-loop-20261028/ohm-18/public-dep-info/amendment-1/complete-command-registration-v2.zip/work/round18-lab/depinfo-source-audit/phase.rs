use rustc_hash::FxHashSet as HashSet;
use std::borrow::Cow;
use std::hint::black_box;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::Instant;

type CargoResult<T> = Result<T, String>;
fn internal(message: String) -> String { message }
include!("source-sections.rs");

#[derive(Default)]
struct Output {
    target: PathBuf,
    previous: Vec<u8>,
    paths: Vec<PathBuf>,
}

fn load(path: &str) -> Vec<Output> {
    let data = std::fs::read_to_string(path).unwrap();
    let mut outputs = Vec::new();
    for line in data.lines() {
        let (kind, value) = line.split_once('\t').unwrap();
        if kind == "T" {
            outputs.push(Output { target: value.into(), ..Default::default() });
        } else {
            let out = outputs.last_mut().unwrap();
            match kind {
                "E" => {out.previous.extend_from_slice(value.as_bytes()); out.previous.push(b'\n');}
                "P" => out.paths.push(value.into()),
                _ => panic!("record {kind}"),
            }
        }
    }
    assert_eq!(outputs.len(),74);
    outputs
}

fn check() {
    let alphabet = ["", ".", "..", "a", "b", "x/.", "x//a", "x/a", "x/./a", "x../a", ".hidden",
                    "x\\", "with space", "a\nb", "a\tb", "é", "./a", "c: a"];
    let targets = ["out", "x:y", "x\\y", "space here"];
    for &target in &targets {
        let target = Path::new(target);
        for &a in &alphabet {
            for &b in &alphabet {
                let paths = [a, b, a].map(PathBuf::from);
                let canonical = release_line(&mut paths.to_vec(),target);
                let rendered = borrowed_line(&mut paths.to_vec(),target);
                assert_eq!(canonical, rendered);
                for old in [canonical.clone(), format!("{}: {a} {b}\n",target.display()).into_bytes(),
                            format!("{}: {b} {a}\n",target.display()).into_bytes(), vec![0xff],
                            format!("{}: {a} {a}\n",target.display()).into_bytes()] {
                    if matches_existing_dep_info(&old,target,&paths) {
                        assert_eq!(old,canonical);
                    }
                }
            }
        }
    }
    existing_dep_info_requires_the_complete_sorted_spelling_for_replay();
}

fn operation(outputs: &[Output], arm: &str) -> u128 {
    // Both renderers take ownership of newly collected paths in Cargo. Prepare
    // equal inputs for all arms and keep setup outside the phase timer.
    let mut paths: Vec<_> = outputs.iter().map(|o|o.paths.clone()).collect();
    let before = Instant::now();
    for (o,paths) in outputs.iter().zip(paths.iter_mut()) {
        let paths = black_box(paths);
        let matches = match arm {
            "release" => release_line(paths,&o.target) == o.previous,
            "borrowed" => borrowed_line(paths,&o.target) == o.previous,
            "head" => matches_existing_dep_info(black_box(&o.previous),&o.target,paths),
            _ => panic!("arm {arm}"),
        };
        assert!(black_box(matches));
    }
    before.elapsed().as_nanos()
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    check();
    let a = load(&args[1]);
    let b = load(&args[2]);
    for outputs in [&a,&b] {
        for arm in ["release","borrowed","head"] {operation(outputs,arm);}
    }
    println!("cohort,round,position,arm,iteration,phase_ns");
    let schedule = std::fs::read_to_string(&args[3]).unwrap();
    for line in schedule.lines().skip(1) {
        let columns: Vec<_> = line.split(',').collect();
        let outputs = match columns[0] {"initial"=>&a,"replica"=>&b,_=>unreachable!()};
        for i in 0..5 {
            let ns = operation(outputs,columns[3]);
            println!("{line},{i},{ns}");
        }
    }
}
