fn release_path(path: &Path) -> CargoResult<String> {
    path.to_str()
        .ok_or_else(|| internal(format!("path `{:?}` not utf-8", path)))
        .map(|f| f.replace(" ", "\\ "))
}
fn release_line(paths: &mut Vec<PathBuf>, target: &Path) -> Vec<u8> {
    paths.sort();
    paths.dedup();
    let deps: Vec<_> = paths.iter().map(|p| release_path(p).unwrap()).collect();
    let target_fn = release_path(target).unwrap();
    let mut contents = Vec::new();
    write!(contents, "{}:", target_fn).unwrap();
    for dep in &deps {
        write!(contents, " {}", dep).unwrap();
    }
    writeln!(contents).unwrap();
    contents
}

fn borrowed_path(path: &Path) -> CargoResult<Cow<'_, str>> {
    let path = path
        .to_str()
        .ok_or_else(|| internal(format!("path `{:?}` not utf-8", path)))?;
    if path.as_bytes().contains(&b' ') {
        Ok(Cow::Owned(path.replace(' ', "\\ ")))
    } else {
        Ok(Cow::Borrowed(path))
    }
}
fn borrowed_line(paths: &mut Vec<PathBuf>, target: &Path) -> Vec<u8> {
    paths.sort();
    paths.dedup();
    let deps: Vec<_> = paths.iter().map(|p| borrowed_path(p).unwrap()).collect();
    let target_fn = borrowed_path(target).unwrap();
    let dep_bytes = deps.iter().map(|dep| dep.len() + 1).sum::<usize>();
    let mut contents = Vec::with_capacity(target_fn.len() + 2 + dep_bytes);
    contents.extend_from_slice(target_fn.as_bytes());
    contents.push(b':');
    for dep in &deps {
        contents.push(b' ');
        contents.extend_from_slice(dep.as_bytes());
    }
    contents.push(b'\n');
    contents
}

fn matches_existing_dep_info(contents: &[u8], target: &Path, deps: &[PathBuf]) -> bool {
    let Some(target) = target.to_str().filter(|target| !target.contains(' ')) else {
        return false;
    };
    let Some(list) = std::str::from_utf8(contents)
        .ok()
        .and_then(|line| line.strip_suffix('\n'))
        .and_then(|line| line.strip_prefix(target))
        .and_then(|line| line.strip_prefix(':'))
    else {
        return false;
    };
    if list.is_empty() {
        return deps.is_empty();
    }
    let Some(list) = list.strip_prefix(' ') else {
        return false;
    };

    // Compare original spellings. Escaped spaces or equivalent spellings of a
    // path fall back to the stable sort and renderer below.
    let mut remaining: HashSet<_> = deps.iter().map(|path| path.as_os_str()).collect();
    let mut previous = None;
    for name in list.split(' ') {
        let path = Path::new(name);
        if !remaining.remove(path.as_os_str()) || previous.is_some_and(|prev| prev >= path) {
            return false;
        }
        previous = Some(path);
    }
    remaining.is_empty()
}

fn existing_dep_info_requires_the_complete_sorted_spelling_for_replay() {
    let target = Path::new("target");
    let deps = ["b", "a/file", "b"].map(PathBuf::from);
    assert!(matches_existing_dep_info(
        b"target: a/file b\n",
        target,
        &deps
    ));
    for invalid in [
        b"target: b a/file\n".as_slice(),
        b"target: a/file a/file\n",
        b"target: a/file\n",
        b"target: a/./file b\n",
        b"other: a/file b\n",
    ] {
        assert!(!matches_existing_dep_info(invalid, target, &deps));
    }
    let aliases = ["a/./file", "a/file"].map(PathBuf::from);
    assert!(!matches_existing_dep_info(
        b"target: a/file\n",
        target,
        &aliases
    ));
}

