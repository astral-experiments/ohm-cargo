"""Shared fixed inputs, prospective integrity, and physical-release checks."""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
LAB = WORK / "round18-lab"
BENCH = Path((WORK/"bench-home.path").read_text().strip())
ROOT = BENCH/"round18"
DIST = WORK/"upstream-monitor/toolchain18"
PGO = WORK/"round18-cargo/pgo"
PRIOR = HERE.parent/"small-frontend-screen"
LINK = Path("lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd")
GIB = 1 << 30
FLOOR = 120*GIB
ARMS = ("shipped","base","pr269","head")
COHORTS = ("initial","replica")
SOURCE = Path("crates/uv/src/bin/uvx.rs")
UV = "c22e6b71933443e9cd299d4b6ac8de035ed4825b"
SHIPPED = "02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
BASE = "df1fb0a090d36b14bfa9ef68f9243f05073d7f2c7908f5e26453473ad59f0721"
RUSTC = "c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60"
WILD = "0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5"
OUT = HERE/"observed"


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def h(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("x") as f:
        json.dump(obj,f,indent=2,sort_keys=True)
        f.write(chr(10))


def inventory(path):
    s = path.stat()
    return [s.st_dev,s.st_ino]


def current_inputs():
    plan = read(HERE/"registered.json")
    for raw, expected in plan["immutable_files"].items():
        need(sha(WORK/raw)==expected, "registered input changed: "+raw)
    need(read(LAB/"depinfo-source-audit/native-phase/score.json")["phase_whole_command_eligible"],
         "isolated phase never qualified the full-command study")
    return plan


def passport(study, phase, key, grant, now, boot, cpus, reg):
    need(set(grant)=={"study","phase","key","registration_sha256","host_boot_id","cpus",
                      "release","release_sha256","issued_utc_ns","expires_utc_ns"},
         "wrong grant fields")
    need((study,phase,key,reg,boot,sorted(cpus))==
         (grant["study"],grant["phase"],grant["key"],grant["registration_sha256"],
          grant["host_boot_id"],grant["cpus"]), "grant for a different study, host, identity or scope")
    need(grant["issued_utc_ns"]<=now<grant["expires_utc_ns"], "grant expired or future-dated")
    need(bool(re.fullmatch("[a-f0-9]{64}",grant["release_sha256"])), "invalid external release hash")


def authority(phase,key):
    plan=current_inputs()
    p=HERE/"grants"/(phase+"-"+key+".json")
    need(p.is_file() and os.environ.get("OHM_DEPINFO_GRANT_SHA256")==sha(p),"no exact coordinator grant")
    g=read(p)
    cpus=range(24,32) if phase=="build" else range(16)
    passport(plan["study"],phase,key,g,time.time_ns(),Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
             cpus,sha(HERE/"registered.json"))
    need(set(os.sched_getaffinity(0))==set(cpus),"incorrect physical CPU allocation")
    release=Path(g["release"])
    need(release.parent==LAB and release.name.startswith("depinfo-complete-release-") and
         sha(release)==g["release_sha256"], "coordinator release missing or changed")
    r=read(release)
    need(r.get("study")==plan["study"] and r.get("phase")==phase and r.get("key")==key and
         r.get("exclusive") is True and r.get("competing_tools")==[] and
         r.get("boot_id")==g["host_boot_id"],"physical host not exclusively released for this exact phase")
    namespaces={kind:os.readlink("/proc/self/ns/"+kind) for kind in ("user","pid")}
    need(r.get("namespaces")==namespaces and r.get("uid")==os.getuid() and
         r.get("bench_dev")==BENCH.stat().st_dev,"runner is not in the coordinator's actual host namespaces or volume")
    if phase.endswith(("-count","-native")):
        need((OUT/"subjects.json").is_file() and r.get("subjects_sha256")==sha(OUT/"subjects.json"),
             "coordinator release does not bind the frozen real driver/SDK/functional subjects")
    return g


def headroom(free, requested):
    need(free >= FLOOR+requested, f"reserve shortfall: {free:,} < {FLOOR+requested:,}")


def fsfree():
    return shutil.disk_usage(BENCH).free


@contextlib.contextmanager
def lease(phase,key):
    g=authority(phase,key)
    with (ROOT/"native-lease").open("a") as shared:
        fcntl.flock(shared,fcntl.LOCK_EX|fcntl.LOCK_NB)
        need(sha(Path(g["release"]))==g["release_sha256"],"authority changed acquiring lock")
        yield g


def fixture(cohort):
    need(cohort in COHORTS,"invalid checkout")
    return ROOT/("a" if cohort=="initial" else "independent/longer-checkout-b")


def guards():
    p=OUT/"functional"/"verified.json"
    d=read(p)
    candidate=read(HERE/"sources.json")["subjects"]["head"]
    real=read(Path(d["validated"]))
    cases=real["cases"]
    required={"canonical","absent","fresh","wrong_target","absent_newline","duplicate","reordered","extra",
              "missing","bad_utf8","extra_line","alternative_spelling","literal_edit","new_module",
              "fresh_after_new_module","alias_order_0","alias_order_1","fresh_alias_order_0","fresh_alias_order_1",
              "multiple_outputs_with_basedir","fresh_multiple_outputs"}
    need(d["patch_sha256"]==candidate["patch_sha256"] and sha(Path(d["validated"]))==d["validated_sha256"] and
         d["actual_exit"]==0 and real["identical"] and real["compiler_sha256"]==RUSTC and
         real["driver_sha256"]["release"]==BASE and
         real["driver_sha256"]["candidate"]==read(OUT/"drivers/head/verified.json")["audit"]["head_sha256"] and required<=set(cases["release"]) and
         cases["candidate"]==cases["release"] and real["escaped_log_sha256"]==sha(Path(d["escaped_log"])),
         "cold/warm/stale/malformed/escaped/multi-output guards failed")
    return sha(p)
