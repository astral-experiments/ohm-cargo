"""Design sensitivity from previously completed shipped/matched controls only."""
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUT = HERE.parents[2] / "outputs/ohm-18-further-edited-timings.csv"
ALPHA = .05 / 6
SIZES = [96, 240, 480, 960, 1920, 2400, 2880]
SHIFTS = [4, 6.58, 8.21, 10, 15, 20, 30]


def upper(n, k, p):
    if k > n:
        return 0.0
    log_p, log_q = math.log(p), math.log1p(-p)
    log_factorial = math.lgamma(n + 1)
    return min(1., math.fsum(math.exp(log_factorial - math.lgamma(j + 1) - math.lgamma(n-j + 1)
                             + j*log_p + (n-j)*log_q) for j in range(k, n + 1)))


def critical(n):
    lo, hi = n // 2, n + 1
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if upper(n, mid, .5) <= ALPHA:
            hi = mid
        else:
            lo = mid
    return hi


def main():
    raw = list(csv.DictReader(INPUT.open()))
    res = {"input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(), "alpha": ALPHA,
           "method": "Exact sign gate under empirical random orientation plus a fixed additive shift. "
           "These ceilings omit the additional practical-magnitude and order-stratum gates. "
           "The 30 control pairs per cohort give coarse local support and cannot predict actual driver differences.",
           "cohorts": {}, "counts": SIZES}
    for cohort in ("initial", "replica"):
        blocks = {}
        for row in raw:
            if (row["study"],row["checkout"],row["command"]) == ("r18-uvx",cohort,"cargo build") and row["arm"] in ("shipped","base"):
                blocks.setdefault(int(row["block"]),{})[row["arm"]] = int(row["elapsed_ns"]) / 1e6
        assert len(blocks) == 30 and all(set(row) == {"shipped","base"} for row in blocks.values())
        diffs = [row["shipped"] - row["base"] for row in blocks.values()]
        vals = [v for row in blocks.values() for v in row.values()]
        cohort_data = {"n":len(diffs),"mean_control_ms":statistics.mean(vals),
            "median_control_ms":statistics.median(vals), "absolute_control_difference_ms":sorted(map(abs,diffs)),
            "shifted_direction_probability":{},"sign_only_power":{}}
        for shift in SHIFTS:
            shifted = [d+shift for x in diffs for d in (x,-x)]
            assert all(x != 0 for x in shifted)
            cohort_data["shifted_direction_probability"][shift] = sum(x > 0 for x in shifted) / len(shifted)
        for n in SIZES:
            k = critical(n)
            cohort_data["sign_only_power"][n] = {"wins_required":k, "upper_bound_by_ms":{
                shift:round(upper(n,k,p),4) for shift,p in cohort_data["shifted_direction_probability"].items()}}
        res["cohorts"][cohort] = cohort_data
    print(json.dumps(res,sort_keys=True,indent=2))


if __name__ == "__main__":
    main()
