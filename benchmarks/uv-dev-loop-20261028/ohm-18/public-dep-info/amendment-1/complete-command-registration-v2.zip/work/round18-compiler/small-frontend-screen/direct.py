"""Replay the two real released uvx rustc argument vectors from a private incremental bank."""
import argparse
import resource
import sys
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *


def captured(cohort, role):
    catalog = read(AUDIT / "uvx-traces.json")
    key = f"{cohort}/{'build' if role == 'build-bin' else 'test'}/admission"
    row, = [r for r in catalog[key] if r["harness"] == (role == "test-harness")]
    path = WORK / row["raw"]
    require(sha(path) == row["raw_sha256"], "trace drift")
    prefix = "execve(" + json.dumps(str(TOOLS / "bin/rustc")) + ", "
    args, = [json.JSONDecoder().raw_decode(l[len(prefix):])[0] for l in path.read_text().splitlines()
             if l.startswith(prefix) and l.endswith("= 0") and '"--crate-name", "uvx"' in l]
    require(sha_args(args) == row["argv_sha256"], "argv drift")
    require(args.count(str(SOURCE)) == 1 and args.count("-Zthreads=8") == 1 and
            ("--test" in args) == (role == "test-harness"), "wrong release role")
    return args


def sha_args(args):
    return hbytes(json.dumps(args, separators=(",", ":")).encode())


def relocate(args, root, active, one, *, validate):
    """Only immutable extern/search operands point at a donor. All writes point into active."""
    args = list(args)
    previous = str(root / "target") + "/"
    donor = root / "r18-four/shipped"
    old_out = Path(args[args.index("--out-dir") + 1])
    require(old_out.is_relative_to(root / "target") and old_out.name == "out", "wrong canonical out")
    for i, arg in enumerate(args):
        if previous not in arg:
            continue
        flag = args[i-1]
        if flag == "--out-dir" and arg == str(old_out):
            args[i] = str(active / "out")
        elif flag == "-C" and arg == f"incremental={root}/target/debug/incremental":
            args[i] = f"incremental={active}/inc"
        elif flag == "-Z" and arg.startswith(f"temps-dir={old_out}/"):
            temp = Path(arg.split("=", 1)[1])
            require(temp.parent == old_out and re.fullmatch(r"uvx(?:-[0-9a-f]{16})?\.rlink-objects", temp.name),
                    ("unregistered temp destination", arg))
            args[i] = f"temps-dir={active}/out/{temp.name}"
        elif flag in ("--extern", "-L"):
            kind, name = arg.split("=", 1)
            src = Path(name)
            require(src.is_relative_to(root / "target") and
                    (flag == "--extern" or kind in ("dependency", "native")), ("unexpected input", arg))
            physical = donor / src.relative_to(root / "target")
            if validate:
                require(physical.is_file() if flag == "--extern" else physical.is_dir(),
                        f"missing recorded donor input: {physical}")
            args[i] = f"{kind}={physical}"
        else:
            raise ValueError(("unexpected writable or unreadable canonical path", flag, arg))
    require(not any(previous in arg for arg in args), "unsafely retained canonical target reference")
    if one:
        args.insert(args.index("-Zthreads=8") + 1, "-Zthreads=1")
    return args


def compile_once(args, srcroot, stage, mode, log):
    env = {"HOME": str(stage / "home"), "TMPDIR": str(stage / "tmp"), "LANG": "C.UTF-8",
           "LC_ALL": "C.UTF-8", "TZ": "UTC", "PATH": f"{TOOLS}/bin:/usr/bin:/bin"}
    # One implicit job + seven transferable tokens, mirroring an otherwise-idle -j8.
    fd_r, fd_w = os.pipe()
    try:
        os.write(fd_w, b"+" * 7)
        env["CARGO_MAKEFLAGS"] = f"-j --jobserver-auth={fd_r},{fd_w}"
        require(not log.exists(), "refuse to overwrite raw compile log")
        tool = [sys.executable, str(WORK / "edit-link-profile/native-instrument/count.py"), "--"]
        command = [*(tool if mode == "count" else []), *args]
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        with log.open("xb") as dst:
            start = time.perf_counter_ns()
            cp = subprocess.run(command, cwd=srcroot, env=env, pass_fds=(fd_r, fd_w),
                                stdout=dst, stderr=subprocess.STDOUT)
            elapsed = time.perf_counter_ns() - start
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
    finally:
        os.close(fd_r)
        os.close(fd_w)
    require(cp.returncode == 0, f"direct rustc exited {cp.returncode}: {log}")
    obs = {"elapsed_ns": elapsed, "argv_sha256": sha_args(args), "exit": cp.returncode,
           "cpu_user_s": after.ru_utime - before.ru_utime,
           "cpu_system_s": after.ru_stime - before.ru_stime, "raw_sha256": sha(log)}
    if mode == "count":
        rows = [json.loads(line[len("DynamoRIO "):]) for line in log.read_text().splitlines()
                if line.startswith("DynamoRIO ")]
        receipt, = rows
        require(receipt["instructions"] == sum(receipt["threads"].values()) > 0 and
                str(receipt["pid"]) in receipt["threads"], "invalid per-thread counter")
        obs.update(instructions=receipt["instructions"], threads=receipt["threads"], pid=receipt["pid"])
    return obs


def product(args, active, cohort, literal, role, scratch):
    names = [s.split("=", 1)[1] for s in args if s.startswith("extra-filename=")]
    require(len(names) <= 1, "unexpected duplicate output suffix")
    suffix = names[0] if names else ""
    elf = active / "out" / ("uvx" + suffix)
    with elf.open("rb") as handle:
        require(handle.read(4) == b"\x7fELF", f"missing actual emitted ELF {elf}")
    depfile = elf.with_suffix(".d")
    require(b"crates/uv/src/bin/uvx.rs" in depfile.read_bytes(), "wrong direct dep-info")
    if role != "test-harness":
        behavior_record = behavior(elf, cohort, literal, scratch)
    else:
        proc = subprocess.run([str(elf), "--list"], capture_output=True, timeout=10)
        require(proc.returncode == 0 and proc.stdout.strip() == b"0 tests, 0 benchmarks" and not proc.stderr,
                ("unexpected uvx harness", proc.stdout, proc.stderr))
        behavior_record = {"listed": proc.stdout.decode(), "exit": proc.returncode}
    return {"raw_sha256": sha(elf), "size": elf.stat().st_size, "dep_sha256": sha(depfile),
            "behavior": behavior_record}


def run(mode, cohort):
    plan = read(HERE / "schedule.json")
    with authorized("direct-" + mode, cohort, 5) as grant:
        if mode=="count":
            from score import direct_result
            require(direct_result(False)["eligible"],"direct native screen did not replicate")
        scratch = SCRATCH / ("direct-" + mode) / cohort
        record = RESULT / ("direct-" + mode) / cohort
        require(not record.exists() and not scratch.exists(), "single-shot study already attempted")
        record.mkdir(parents=True)
        scratch.mkdir(parents=True)
        srcroot = scratch / "uv"
        source = srcroot / SOURCE
        source.parent.mkdir(parents=True)
        (scratch / "home").mkdir()
        (scratch / "tmp").mkdir()
        save(record/"start.json", {"registration": sha(HERE/"registration.json"), "grant": grant,
                                   "source_sha256": sha(ORIGINAL), "mode": mode})
        for role in ROLES:
            banks = scratch / role
            banks.mkdir()
            active = banks/"active"
            for arm in DIRECT:
                for part in ("out", "inc"):
                    (banks/arm/part).mkdir(parents=True, exist_ok=True)
            directory = record / role
            directory.mkdir()
            ref = captured(cohort, role)
            variants = {a:relocate(ref, fixture(cohort), active, a == "one", validate=True) for a in DIRECT}
            save(directory / "argv.json", variants)
            if mode == "wall":
                from normal import quiet
                quiet(grant, directory)
            def observe(block, literal, order, phase):
                assert_floor(2)
                require(time.time_ns() < grant["expires_utc_ns"] and
                        sha(Path(grant["release"])) == grant["release_sha256"], "direct authority expired")
                src = changed(ORIGINAL.read_bytes(), cohort, literal)
                source.write_bytes(src)
                products = {}
                for pos, arm in enumerate(order):
                    parked = banks / arm
                    require(not active.exists() and parked.is_dir(), "unexpected active direct bank")
                    parked.rename(active)
                    try:
                        current = variants["eight" if phase == "cold" else arm]
                        obs = compile_once(current, srcroot, scratch, mode if phase == "trial" else "wall",
                                           directory/f"{phase}-{block:03}-{pos}-{arm}.log")
                        if phase in ("admit", "post"):
                            products[arm] = product(current, active, cohort, literal, role, scratch)
                        obs.update(block=block, rank=pos, arm=arm, literal=literal, source_sha256=hbytes(src))
                        if mode == "wall" and phase == "trial":
                            from normal import worker
                            obs["outside_timer"] = {"host":worker.host(NATIVE_CPUS), "foreign":worker.foreign(),
                                "cpu_psi":Path("/proc/pressure/cpu").read_text()}
                        with (directory/(phase+".jsonl")).open("a") as f:
                            print(json.dumps(obs), file=f)
                    finally:
                        active.rename(parked)
                if products:
                    require(len({(p["raw_sha256"],p["size"],p["dep_sha256"]) for p in products.values()}) == 1,
                            f"same-path same-source emitted {role} products differ under alternate thread counts")
                    save(directory/(phase+"-products.json"),products)
            prefix = "build" if role == "build-bin" else "test"
            for i, phase in enumerate(("cold", "settle", "admit"), 990):
                observe(i, tag(cohort, prefix, i), DIRECT if i % 2 == 0 else DIRECT[::-1], phase)
            cells = plan["direct-"+mode][cohort][role]
            for i, order in enumerate(cells):
                observe(i, tag(cohort, prefix, i), order, "trial")
            observe(999, tag(cohort, prefix, 999), DIRECT[::-1], "post")
            save(directory/"done.json", {"rows": 2*len(cells), "sha256": sha(directory/"trial.jsonl")})
        save(record/"done.json", {"roles":list(ROLES),"mode":mode,"cohort":cohort})


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=("count","wall"))
    p.add_argument("cohort", choices=COHORTS)
    a = p.parse_args()
    run(a.mode, a.cohort)
