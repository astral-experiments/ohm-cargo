"""Owned build-only banks. Four physical writable arms share one pathname sequentially."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import signal
import subprocess
from counted import *
from drivers import variants


def area(root,phase):
    need(phase in ("count","native"),"unknown bank owner")
    return root/("depinfo-complete-"+phase+"-v1")


def checkout(root):
    raw=subprocess.check_output(["git","-C",str(WORK/"uv"),"ls-tree","-rz",UV])
    expected=set()
    for row in raw.split(b"\0"):
        if not row: continue
        spec,name=row.split(b"\t",1)
        mode,kind,oid=spec.split()
        need(kind==b"blob","unregistered pin includes a submodule")
        name=os.fsdecode(name)
        p=root/"uv"/name
        need(p.is_file() or p.is_symlink(), "missing registered uv file: "+name)
        data=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
        got=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        need(got==oid.decode() and ((mode==b"120000")==p.is_symlink()) and
             (p.is_symlink() or (bool(p.stat().st_mode&0o111)==(mode==b"100755"))),"uv checkout drift: "+name)
        expected.add(name)
    for base,dirs,files in os.walk(root/"uv",followlinks=False):
        dirs[:]=[d for d in dirs if d!=".git"]
        for name in files:
            rel=str((Path(base)/name).relative_to(root/"uv"))
            need(rel in expected or rel==".git","untracked uv checkout file: "+rel)
    return {"commit":UV,"tracked_blobs":len(expected),"git_ls_tree_sha256":h(raw)}


def original_state(root):
    t=ROOT/"tools"
    files={str(p):{"identity":inventory(p),"mtime_ns":p.stat().st_mtime_ns,"sha256":sha(p)}
           for p in (root/"uv"/SOURCE,root/"uv/Cargo.lock")}
    tools={str(t/"bin/cargo"):(ROOT/"official-original-cargo",SHIPPED),str(t/LINK):(ROOT/"official-original-wild",WILD)}
    for visible,(donor,digest) in tools.items():
        need(Path(visible).samefile(donor) and sha(donor)==digest,"release tool slots not restored")
    need(sha(t/"bin/rustc")==RUSTC,"unexpected -18 rustc")
    return {"files":files,"root":str(root),"slots":{p:inventory(v[0]) for p,v in tools.items()},
            "canonical_target":inventory(root/"target") if (root/"target").exists() else None}


@contextlib.contextmanager
def session(root,pool,out,cohort):
    before=original_state(root)
    src=root/"uv"/SOURCE
    original=src.read_bytes()
    old_times=(src.stat().st_atime_ns,src.stat().st_mtime_ns)
    target=root/"target"
    occupied=pool/"preexisting-canonical"
    need(not occupied.exists() and not target.is_symlink() and original==(WORK/"uv"/SOURCE).read_bytes(),
         "unreturned bank or altered source")
    save(out/"before.json",before)
    if target.exists():
        target.rename(occupied)
    try:
        yield target
    finally:
        # Each activation must already have parked its owned bank before we restore a canonical donor.
        need(not target.exists(),"an active owned bank remains: restore from its inode journal before any action")
        src.write_bytes(original)
        os.utime(src,ns=old_times)
        worker.select(ROOT/"official-original-cargo",ROOT/"tools/bin/cargo")
        if occupied.exists():
            occupied.rename(target)
        after=original_state(root)
        save(out/"returned.json",{"before":before,"after":after,"equal":before==after,"source":str(src),
                                  "owned_bank_identities":{a:inventory(pool/a) for a in ARMS if (pool/a).is_dir()}})
        need(after==before,"checkout, lock, official tool slots or canonical bank identity changed")


@contextlib.contextmanager
def active(root,pool,arm,binary):
    target=root/"target"
    bank=pool/arm
    need(bank.is_dir() and not bank.is_symlink() and not target.exists(),"invalid park or active bank")
    identity=inventory(bank)
    worker.select(binary,ROOT/"tools/bin/cargo")
    need((ROOT/"tools/bin/cargo").samefile(binary) and (ROOT/"tools"/LINK).samefile(ROOT/"official-original-wild"),
         "invalid effective Cargo or Wild slot")
    bank.rename(target)
    try:
        yield
    finally:
        need(inventory(target)==identity and not bank.exists(),"owned active target changed identity")
        target.rename(bank)


def total_bytes(path):
    return max(int(subprocess.check_output(["du","-s",option,"--block-size=1","--",str(path)]).split()[0])
               for option in ("--apparent-size","--count-links"))


def prepare(mode,cohort):
    guards()
    bins=variants()
    sealed=read(OUT/"subjects.json")
    need(sealed["cargo"]=={a:{"path":str(v),"sha256":sha(v)} for a,v in bins.items()} and
         sealed["functional_sha256"]==guards() and sealed["registration_sha256"]==sha(HERE/"registered.json"),
         "subjects differ from prospective binary freeze")
    root=fixture(cohort)
    pool=area(root,mode)
    out=OUT/mode/cohort/"prepare"
    need(not pool.exists() and not out.exists(),"this preparation has already started")
    for peer_mode in ("count","native"):
        for peer_cohort in COHORTS:
            prior_pool=area(fixture(peer_cohort),peer_mode)
            if prior_pool.exists():
                retirement=OUT/peer_mode/peer_cohort/"retired.json"
                need(retirement.is_file() and read(retirement)["all_four_absent"] and
                     not any((prior_pool/name).exists() for name in (*ARMS,"preexisting-canonical")),
                     "at most four allocated target banks globally; peer must return and retire first")
    if cohort=="replica":
        need(read(OUT/mode/"initial/retired.json")["all_four_absent"],"initial receipt and return must precede replica")
    # Empirical build-only predecessor is 6.162 GB. Allow up to 12 GiB/arm + 12 GiB staging at admission;
    # use actual measured ownership and conservative destination bytes before every clone.
    headroom(fsfree(),60*GIB)
    out.mkdir(parents=True)
    identity=checkout(root)
    pool.mkdir()
    for arm,source in bins.items():
        dest=pool/("driver-"+arm)
        shutil.copy2(source,dest)
        need(sha(dest)==sha(source),"private staged driver copy drift")
    (pool/"shipped").mkdir()
    save(out/"allocation-start.json",{"pool":str(pool),"pool_inode":inventory(pool),
         "first_owned_bank":inventory(pool/"shipped"),"free_bytes_before_seed":fsfree()})
    if mode=="count":
        wrappers(pool)
    with session(root,pool,out,cohort):
        with active(root,pool,"shipped",pool/"driver-base"):
            # First baseline cold unit population is a real ordinary whole workspace build.
            cold=worker.run_command(root,"build",out/"cold-seed",list(range(16)),settle=True)
            if mode=="count":
                wrapped(root,pool,out/"wrapped-native-seed","native",warm=True)
            prior=depfiles(root)
        size=total_bytes(pool/"shipped")
        headroom(fsfree(),3*size+12*GIB)
        for i,arm in enumerate(("base","pr269","head")):
            headroom(fsfree(),(3-i)*size+12*GIB)
            subprocess.run(["cp","-a","--reflink=auto","--",str(pool/"shipped"),str(pool/arm)],check=True)
        # Compare every regular source/destination inode, including packed compiler caches, before allowing a mutation.
        distinct={a:inventory(pool/a) for a in ARMS}
        need(len({tuple(x) for x in distinct.values()})==4,"four independent target directory inodes required")
        file_count=0
        for path in (pool/"shipped").rglob("*"):
            if path.is_symlink() or not path.is_file(): continue
            rel=path.relative_to(pool/"shipped")
            xs=[(pool/a/rel).stat() for a in ARMS]
            need(len({(x.st_dev,x.st_ino) for x in xs})==4 and len({x.st_size for x in xs})==1,
                 "cross-arm hardlink, missing or differently sized file: "+str(rel))
            file_count+=1
        save(out/"prepared.json",{"mode":mode,"cohort":cohort,"uv":identity,"seed_driver":sha(bins["base"]),
             "drivers":{a:sha(bins[a]) for a in ARMS},"bank_inodes":distinct,"cross_bank_regular_files":file_count,
             "seed_max_allocated_apparent":size,"free_after":fsfree(),"public":prior,"cold_roster":cold["roster"]})
    need(read(out/"returned.json")["equal"],"seed custody failed")


def banks(mode,cohort):
    root=fixture(cohort)
    pool=area(root,mode)
    before=OUT/mode/cohort/"prepare"
    record=read(before/"prepared.json")
    need(read(before/"returned.json")["equal"] and all(inventory(pool/a)==record["bank_inodes"][a] for a in ARMS),
         "unowned, lost or unreturned target")
    need(record["drivers"]=={a:sha(p) for a,p in variants().items()},"driver set changed after preparation")
    return root,pool
