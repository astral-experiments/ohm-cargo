"""Verify the matching Cargo training and the actual release-style source/profile/binary chain."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import sys
import tempfile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(BASE))
import study as s

PGO=s.WORK/"round18-cargo/pgo"
BASE_BIN=PGO/"bin/base"
BASEREC=PGO/"records/base"
PIN="7caf39914da1e28a67744ecbc963a5f26361474d"
RUST="a4fa11bcd38280639cb94daacc125472657db6c3"
BASE_SHA="df1fb0a090d36b14bfa9ef68f9243f05073d7f2c7908f5e26453473ad59f0721"
BASE_PROFILE="446fcf1f1bbb491a589841bb595a2f58b246f87eca69c66a89f64ce853b02389"
STD_SHA="a6efe367f5e01706331c8cf0ee017af31b00bf4c43de62ebaaca7dc563b487dd"
STABLE=Path(s.read(PGO/"provenance.json")["stable_build_paths"])
MATERIAL=s.WORK/"pgo-materials"
HOST="x86_64-unknown-linux-gnu"


def training(rows,record):
    work=[]
    finished={}
    for row in rows:
        log=Path(row["log"])
        if log.parent!=record or not log.name.startswith("train."):
            continue
        if "start" in row:
            parts=shlex.split(row["command"])
            s.require(Path(parts[0])==record/"generate.bin","training used another instrumented driver")
            s.require(Path(row["cwd"]).parent==STABLE/"training-src","training used another visible corpus path")
            work.append({"log":log.name,"case":Path(row["cwd"]).name,"args":parts[1:]})
        elif "finish" in row:
            s.require(log.name not in finished and row["status"]==0,"training failure or duplicate")
            finished[log.name]=0
    names=[r["log"] for r in work]
    s.require(len(work)==len(set(names))==len(finished)==24 and set(names)==set(finished),"missing or repeated training command")
    return work


def graph(path,phase):
    rows=[json.loads(l) for l in path.read_text().splitlines()]
    s.require(all(r[3]==phase for r in rows),"wrong compilation phase")
    return collections.Counter((re.sub(r"^autocfg_[0-9a-f]{16}_([01])$",r"autocfg_probe_\1",name),target,component)
                               for name,target,component,_ in rows)


def protected_corpus(root, backup):
    expected={str(p.relative_to(root)):s.sha(p) for p in root.rglob("*") if p.is_file()}
    if backup:
        extra=expected.pop("bitmaps-3.2.1/src/bitmap.rs.orig")
        s.require(extra==s.read(PGO/"audit.json")["arms"]["base"]["patch_backups"]["bitmaps-3.2.1/src/bitmap.rs.orig"],
                  "non-uv training patch differed")
    s.require(len(expected)==270,"wrong training corpus")
    return expected


def tree_files(root):
    out={}
    for child in root.rglob("*"):
        name=str(child.relative_to(root))
        if child.is_symlink():
            out[name]=("symlink",os.readlink(child))
        elif child.is_file():
            out[name]=(child.stat().st_mode & 0o111,s.sha(child))
    return out


def source_delta(src,patch,expected_tree):
    import importlib.util
    spec=importlib.util.spec_from_file_location("held_source_tree",s.WORK/"round18-cargo/recipe/prepare.py")
    calc=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(calc)
    s.require(calc.tree(src)==expected_tree,"patched Cargo source tree does not match the generated driver")
    before=tree_files(BASEREC/"cargo-src")
    after=tree_files(src)
    delta={k for k in (set(before)|set(after)) if before.get(k)!=after.get(k)}
    s.require("src/compiler/mod.rs" in delta and delta<={"src/compiler/mod.rs","tests/testsuite/rustflags.rs"},
              "additional Cargo/std source changes")
    plus=re.findall(r"^\+\+\+ b/(.*)$",patch.read_text(),re.M)
    minus=re.findall(r"^--- a/(.*)$",patch.read_text(),re.M)
    s.require(len(plus)==len(set(plus)) and set(plus)==set(minus)==delta,"patch scope does not match source tree")
    # Check the exact declared Git diff on private copies of only the two changed textual files.
    with tempfile.TemporaryDirectory(dir=s.BENCH) as tmp:
        import shutil,subprocess
        scratch=Path(tmp)
        for name in delta:
            dest=scratch/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(BASEREC/"cargo-src"/name,dest)
        subprocess.run(["git","apply","--whitespace=nowarn",str(patch)],cwd=scratch,check=True)
        s.require(all(s.sha(scratch/name)==s.sha(src/name) for name in delta),"build was not sourced from declared patch")
    return sorted(delta)


def verify_candidate(request):
    import subprocess
    keys={"binary","record","source_tree","patch","patch_sha256","commands","provenance","profile_use_receipt",
          "audit","recipe_sha256","wrapper_sha256","host_rustc_sha256","expected_parent"}
    s.require(set(request)==keys and request["expected_parent"]==PIN,"PGO candidate request identity")
    record=Path(request["record"])
    binary=Path(request["binary"])
    patch=Path(request["patch"])
    built=s.read(Path(request["provenance"]))
    candidate_audit=s.read(Path(request["audit"]))
    canonical=s.read(PGO/"provenance.json")
    expected=s.read(HERE/"training-plan.json")
    s.require(s.sha(BASE_BIN)==BASE_SHA and s.sha(patch)==request["patch_sha256"],"baseline or source delta drift")
    s.require(built["actual_builder_sha256"]==s.sha(HERE/"build_head.py") and
              built["parent_pgo_provenance_sha256"]==s.sha(PGO/"provenance.json") and
              built["recipe_sha256"]==request["recipe_sha256"] and built["wrapper_sha256"]==request["wrapper_sha256"] and
              built["source_delta_sha256"]==request["patch_sha256"] and
              built["cargo_full_trees"]["head"]==request["source_tree"],"candidate source/build execution receipt drift")
    for key in ("rustc_perf_commit","training_trees","llvm_tools_archive_sha256","llvm_version","jobs","stable_build_paths",
                "rust","profiler"):
        s.require(built[key]==canonical[key],f"untied release input: {key}")
    for key,path in (("recipe_sha256",s.WORK/"round18-cargo/recipe/pgo18.py"),
                     ("wrapper_sha256",s.WORK/"round18-cargo/recipe/wrap-rustc.py")):
        s.require(request[key]==s.sha(path),"PGO recipe/wrapper differs")
    s.require(request["host_rustc_sha256"]==s.sha(s.DIST/"bin/rustc")==s.sha(s.TOOLS/"bin/rustc")==s.sha(Path(expected["build_argv"][0]).with_name("rustc")),
              "wrong frozen Ohm rustc")
    s.require(built["rust"]==RUST and built["jobs"]==8 and built["stable_build_paths"]==str(STABLE),
              "wrong compiler version, parallelism or stable build paths")
    source_changes=source_delta(record/"cargo-src",patch,request["source_tree"])
    cmd=[json.loads(line) for line in Path(request["commands"]).read_text().splitlines()]
    actual=training(cmd,record)
    s.require(actual==expected["training_commands"],"non-uv training differs")
    observer_rows=[json.loads(line) for line in (record/"phase-environment.jsonl").read_text().splitlines()]
    s.require(len(observer_rows)==26 and len({r["log"] for r in observer_rows})==26,"missing exact environment observations")
    envs={r["log"]:r["environment"] for r in observer_rows}
    tools=Path(expected["build_argv"][0]).parent
    s.require(all(e["RUSTC"]==str(tools/"rustc") and e["RUSTDOC"]==str(tools/"rustdoc") for e in envs.values()),
              "actual PGO build/training compiler changed")
    for phase in ("generate","use"):
        env=envs[phase+".build.log"]
        stable={"CARGO_TARGET_DIR":str(STABLE/"target"),"CARGO_HOME":str(STABLE/"build-home"),
                "__CARGO_TESTS_ONLY_SRC_ROOT":str(STABLE/"library"),"OHM_HOLDOUT_ROOT":str(STABLE),
                "OHM_HOLDOUT_PHASE":phase,"OHM_HOLDOUT_TRACE":str(record/(phase+".units.jsonl")),
                "OHM_HOLDOUT_PROFILER":canonical["profiler"],"RUSTC_WRAPPER":str(s.WORK/"round18-cargo/recipe/wrap-rustc.py"),
                "CARGO_PROFILE_RELEASE_LTO":"thin","CARGO_PROFILE_RELEASE_CODEGEN_UNITS":"1","CARGO_PROFILE_RELEASE_OPT_LEVEL":"3",
                "CARGO_PROFILE_RELEASE_INCREMENTAL":"false","CARGO_PROFILE_RELEASE_DEBUG":"false","CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS":"false",
                "CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS":"false","LIBZ_SYS_STATIC":"1","CFG_RELEASE":"1.99.0-dev",
                "CFG_RELEASE_CHANNEL":"dev","CFG_VER_DESCRIPTION":"ohm-1.99.0-18"}
        s.require(all(env.get(k)==v for k,v in stable.items()),"actual PGO compile environment drift")
    for row in actual:
        env=envs[row["log"]]
        case,label,stage=row["log"][len("train."):-len(".log")].rsplit(".",2)
        inc=stage!="full"
        s.require(case==row["case"] and env["CARGO_INCREMENTAL"]==str(int(inc)) and
                  env["CARGO_HOME"]==str(STABLE/"train-home") and env["CARGO_UNSTABLE_OHM_LINKER"]=="lld" and
                  env["LLVM_PROFILE_FILE"]==str(STABLE/"raw/%m_%p.profraw") and
                  env["CARGO_TARGET_DIR"]==str(STABLE/"training-target"/case/label/("incr" if inc else "full")),
                  "actual non-uv PGO training input changed")
    for row in actual:
        log=record/row["log"]
        s.require(log.is_file() and "Finished" in log.read_text(),"missing successful Cargo training output")
    for phase in ("generate","use"):
        bgraph=graph(BASEREC/(phase+".units.jsonl"),phase)
        s.require(graph(record/(phase+".units.jsonl"),phase)==bgraph,"which units were instrumented/optimized differs")
        starts=[r for r in cmd if "start" in r and Path(r["log"])==record/(phase+".build.log")]
        ends=[r for r in cmd if "finish" in r and Path(r["log"])==record/(phase+".build.log")]
        actual_build,=starts
        final,=ends
        fixed=s.read(HERE/"training-plan.json")["build_argv"]
        s.require(shlex.split(actual_build["command"])==fixed and Path(actual_build["cwd"])==STABLE/"cargo-src" and
                  final["status"]==0,"different real Cargo PGO build argv, cwd, features, or exit")
        # The original release recipe saved each target; use its actual linked std bytes.
        libs=list((record/(phase+".target")/HOST/"release").rglob("libstd-*.rlib"))
        s.require(bool(libs) and {s.sha(lib) for lib in libs}=={STD_SHA},"compiled std differs from matched PGO base")
    s.require(protected_corpus(record/"training-src",True)==protected_corpus(MATERIAL/"corpus",False),"training files differ")
    raw=sorted((record/"raw").glob("*.profraw"))
    s.require(len(raw)==24 and all(p.is_file() and p.stat().st_size for p in raw),"fresh profile run must retain 24 raw files")
    base_inodes={(p.stat().st_dev,p.stat().st_ino) for p in (BASEREC/"raw").glob("*.profraw")}
    s.require(not any((p.stat().st_dev,p.stat().st_ino) in base_inodes for p in raw),"raw profiles reused from base")
    text_digests=s.read(record/"profile-info.json")
    actual_profile=s.sha(record/"merged.profdata")
    used=s.read(Path(request["profile_use_receipt"]))
    s.require(used["sha256"]==actual_profile==text_digests["profdata_sha256"]!=BASE_PROFILE and
              Path(used["path"])==STABLE/"merged.profdata" and used["source_commit"] in (request["source_tree"],"tree:"+request["source_tree"]),
              "wrong individually trained profile-use input")
    s.require(text_digests["raw_files"]==24 and text_digests["covered_symbol_matches"]>0,"no Cargo profile coverage")
    with tempfile.TemporaryDirectory(dir=s.BENCH) as tmp:
        reproduced=Path(tmp)/"remerged.profdata"
        subprocess.run([str(MATERIAL/"llvm-profdata"),"merge","-o",str(reproduced),str(record/"raw")],check=True)
        s.require(s.sha(reproduced)==actual_profile,"raw profiles do not reproduce the merged input")
    head_sha=s.sha(binary)
    s.require(head_sha==s.sha(record/"use.bin")!=BASE_SHA and
              candidate_audit["cargo_sha256"]==head_sha and candidate_audit["profdata_sha256"]==actual_profile and
              candidate_audit["std_rlib_sha256"]==STD_SHA,"final profiled artifact not the audited binary")
    return {"baseline":str(BASE_BIN),"base_sha256":BASE_SHA,"head":str(binary),"head_sha256":head_sha,
            "base_profile_sha256":BASE_PROFILE,"head_profile_sha256":actual_profile,"std_sha256":STD_SHA,
            "source_tree":request["source_tree"],"patch_sha256":request["patch_sha256"],"source_changes":source_changes,
            "training_commands":actual,"raw_profiles":{p.name:s.sha(p) for p in raw},
            "uv_training_commands":0,"request_sha256":s.hbytes(json.dumps(request,sort_keys=True).encode())}
