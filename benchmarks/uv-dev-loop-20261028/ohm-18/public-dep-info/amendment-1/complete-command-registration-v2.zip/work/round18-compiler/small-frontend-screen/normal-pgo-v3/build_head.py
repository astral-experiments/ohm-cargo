"""Future source-only arm routing around the original PGO build, train, merge and use functions."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import pgo
s=pgo.s
RECIPE=s.WORK/"round18-cargo/recipe/pgo18.py"
WRAPPER=s.WORK/"round18-cargo/recipe/wrap-rustc.py"
SUITE=pgo.STABLE/"small-frontend-pgo-v3"
FUNCTIONS=("run","copytree","cargo_env","build","merge","training")


def core(inputs):
    """Extract the named original function bodies plus their exact environment sanitization."""
    tree=ast.parse(RECIPE.read_text())
    chosen=[]
    for node in tree.body:
        named=isinstance(node,ast.FunctionDef) and node.name in FUNCTIONS
        common=isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="common" for t in node.targets)
        update=isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and                isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=="common" and node.value.func.attr=="update"
        if named or common or update:chosen.append(node)
    s.require([n.name for n in chosen if isinstance(n,ast.FunctionDef)]==list(FUNCTIONS) and len(chosen)==8,
              "pinned build/train/profile recipe changed shape")
    module=ast.Module(body=chosen,type_ignores=[])
    context=dict(os=os,json=json,subprocess=subprocess,time=time,shlex=shlex,shutil=shutil,Path=Path,
                 sha256=hashlib.sha256,HOST=pgo.HOST,CASES=["bitmaps-3.2.1","diesel-2.2.10"],**inputs)
    exec(compile(module,str(RECIPE),"exec"),context)
    return context


def build(input_request):
    s.require(set(input_request)=={"cargo_parent","patch","patch_sha256","head_tree"} and
              input_request["cargo_parent"]==pgo.PIN and re_git_tree(input_request["head_tree"]),
              "unfrozen implementation request")
    patch=Path(input_request["patch"])
    s.require(s.sha(patch)==input_request["patch_sha256"],"patch changed")
    s.require(not SUITE.exists(),"this PGO arm was already attempted")
    s.require(set(os.sched_getaffinity(0))==set(range(24,32)),"use the original PGO build affinity")
    spec=s.read(pgo.PGO/"provenance.json")
    tools=Path(s.read(HERE/"training-plan.json")["build_argv"][0]).parent
    s.require(s.sha(tools/"rustc")==s.sha(s.DIST/"bin/rustc"),"wrong -18 training compiler")
    lib=pgo.STABLE/"library"
    s.require(s.sha(lib/"std/src/path.rs")==spec["std_source_sha256"]["base"] and
              s.sha(lib/"std/tests/path.rs")==spec["std_test_sha256"]["base"],"unmodified release std required")
    dest=SUITE/"records/head"
    names=["target","cargo-src","raw","merged.profdata","train-home","training-src","training-target"]
    s.require(not any((pgo.STABLE/n).exists() for n in names),"stable PGO staging paths are already owned")
    s.require(pgo.STABLE.stat().st_dev==s.BENCH.stat().st_dev or
              shutil.disk_usage(pgo.STABLE).free>=35*s.GIB,"insufficient space on the actual build filesystem")
    dest.mkdir(parents=True)
    (SUITE/"bin").mkdir()
    inputs={"lab":pgo.STABLE,"suite":SUITE,"tool":tools,"wrapper":WRAPPER,
            "profiler":Path(spec["profiler"]),"prof":pgo.MATERIAL/"llvm-profdata",
            "a":SimpleNamespace(jobs=8,materials=pgo.MATERIAL,intermediate_output=None)}
    k=core(inputs)
    original_run=k["run"]
    audited_keys=("RUSTC","RUSTDOC","RUSTC_WRAPPER","CARGO_HOME","CARGO_TARGET_DIR","__CARGO_TESTS_ONLY_SRC_ROOT",
        "OHM_HOLDOUT_ROOT","OHM_HOLDOUT_PHASE","OHM_HOLDOUT_TRACE","OHM_HOLDOUT_PROFILER","CARGO_PROFILE_RELEASE_LTO",
        "CARGO_PROFILE_RELEASE_CODEGEN_UNITS","CARGO_PROFILE_RELEASE_OPT_LEVEL","CARGO_PROFILE_RELEASE_INCREMENTAL",
        "CARGO_PROFILE_RELEASE_DEBUG","CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS","CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS",
        "LIBZ_SYS_STATIC","CFG_RELEASE","CFG_RELEASE_CHANNEL","CFG_VER_DESCRIPTION","CARGO_INCREMENTAL",
        "CARGO_UNSTABLE_OHM_LINKER","LLVM_PROFILE_FILE")
    def observe_run(cmd,log,**kwargs):
        name=Path(log).name
        if name in ("generate.build.log","use.build.log") or name.startswith("train."):
            env=kwargs["env"]
            row={"log":name,"environment":{key:env[key] for key in audited_keys if key in env}}
            with (dest/"phase-environment.jsonl").open("a") as trace:trace.write(json.dumps(row,sort_keys=True)+chr(10))
        return original_run(cmd,log,**kwargs)
    k["run"]=observe_run
    actual={**spec,"arms":["head"],"source_commits":{"head":"tree:"+input_request["head_tree"]},
            "cargo_full_trees":{"head":input_request["head_tree"]},
            "source_delta_sha256":input_request["patch_sha256"],"recipe_sha256":s.sha(RECIPE),
            "wrapper_sha256":s.sha(WRAPPER),"actual_builder_sha256":s.sha(Path(__file__)),
            "parent_pgo_provenance_sha256":s.sha(pgo.PGO/"provenance.json")}
    s.save(SUITE/"provenance.json",actual)
    src=pgo.STABLE/"cargo-src"
    k["copytree"](pgo.BASEREC/"cargo-src",src)
    k["run"](["git","apply","--whitespace=nowarn",patch],dest/"apply.log",cwd=src)
    pgo.source_delta(src,patch,input_request["head_tree"])
    (pgo.STABLE/"raw").mkdir()
    flags=["--bin","cargo","--features","ohm-defaults,all-static"]
    generate=k["build"](src,dest,"generate","cargo",flags)
    k["training"](generate,dest)
    k["merge"](dest,"_5cargo")
    profile=pgo.STABLE/"merged.profdata"
    profile_sha=s.sha(profile)
    s.save(dest/"use-profile-input.json",{"path":str(profile),"sha256":profile_sha,"source_commit":"tree:"+input_request["head_tree"]})
    use=k["build"](src,dest,"use","cargo",flags)
    s.require(s.sha(profile)==profile_sha,"training profile changed during use")
    for n in ("raw","merged.profdata","cargo-src"):
        (pgo.STABLE/n).rename(dest/n)
    binary=SUITE/"bin"/".head-pending"
    shutil.copy2(use,binary)
    version=subprocess.check_output([str(binary),"-Vv"],env=k["common"],text=True)
    s.require(pgo.PIN in version,"wrong embedded Cargo provenance")
    (dest/"driver.txt").write_text(version+"\n"+s.sha(binary)+"\n"+subprocess.check_output(["ldd",str(binary)],text=True))
    # This is a build receipt; independent audit_head separately remerges and checks all phases.
    s.save(dest/"build-result.json",{"cargo_sha256":s.sha(binary),"profdata_sha256":profile_sha,"std_rlib_sha256":pgo.STD_SHA})
    s.save(HERE/"candidate-request.json",{"binary":str(binary),"record":str(dest),"source_tree":input_request["head_tree"],
           "patch":str(patch),"patch_sha256":s.sha(patch),"commands":str(SUITE/"commands.jsonl"),
           "provenance":str(SUITE/"provenance.json"),"profile_use_receipt":str(dest/"use-profile-input.json"),
           "audit":str(dest/"build-result.json"),"recipe_sha256":s.sha(RECIPE),"wrapper_sha256":s.sha(WRAPPER),
           "host_rustc_sha256":s.sha(tools/"rustc"),"expected_parent":pgo.PIN})


def re_git_tree(value):
    import re
    return bool(re.fullmatch(r"[0-9a-f]{40}",value))
