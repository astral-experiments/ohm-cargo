"""Frozen inputs and safety checks shared by the small frontend experiment."""
import contextlib
import fcntl
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import tempfile
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
LAB = WORK / "round18-lab"
AUDIT = HERE.parent / "small-frontend-audit"
BENCH = Path((WORK / "bench-home.path").read_text().strip())
ROOT = BENCH / "round18"
DIST = WORK / "upstream-monitor/toolchain18"
TOOLS = ROOT / "tools"
LINK = Path("lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd")
ORIGINAL = WORK / "uv/crates/uv/src/bin/uvx.rs"
SOURCE = Path("crates/uv/src/bin/uvx.rs")
SCRATCH = BENCH / "r18-small-frontend-v1"
RESULT = HERE / "observed"
COHORTS = ("initial", "replica")
ENDPOINTS = ("build", "test")
ROLES = ("build-bin", "test-bin", "test-harness")
DIRECT = ("eight", "one")
NORMAL = ("shipped", "base", "head")
NATIVE_CPUS = tuple(range(16))
GIB = 1 << 30


def require(ok, why):
    if not ok:
        raise ValueError(why)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def hbytes(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write(chr(10))


def fixture(cohort):
    require(cohort in COHORTS, cohort)
    return ROOT / ("a" if cohort == "initial" else "independent/longer-checkout-b")


def tag(cohort, ep, block):
    require(0 <= block < 1000, block)
    return ("E" if cohort == "initial" else "V") + ep[0].upper() + f"{block:03}"


def changed(src, cohort, literal):
    require(re.fullmatch(r"[A-Z]{2}[0-9]{3}", literal), literal)
    mark = literal.encode()
    if cohort == "initial":
        before = b'eprintln!("error: {err}");'
        after = b'eprintln!("error: uvx could not launch uv [' + mark + b']: {err}");'
    elif cohort == "replica":
        before = b'file_name_str.strip_prefix("uvx")'
        after = b'file_name_str.strip_prefix("uvx-' + mark + b'")'
    else:
        raise ValueError(cohort)
    require(src.count(before) == 1 and mark not in src, "unrecognized original uvx source")
    return src.replace(before, after)


def behavior(binary, cohort, literal, parent):
    """Test the exact selected ELF, never cargo test. The smoke is outside all timers."""
    with tempfile.TemporaryDirectory(dir=parent) as temp:
        directory = Path(temp)
        local = directory / ("uvx" if cohort == "initial" else f"uvx-{literal}@probe")
        os.link(binary, local)
        if cohort == "replica":
            for name, script in (("uv@probe", "#!/bin/sh\nprintf '%s\\n' \"$@\"\n"),
                                 ("uv", "#!/bin/sh\nexit 77\n")):
                path = directory / name
                path.write_text(script)
                path.chmod(0o700)
        result = subprocess.run([str(local), "fixed-argument"], capture_output=True, timeout=10,
                                env={"PATH": "/usr/bin:/bin", "LANG": "C", "HOME": str(directory)})
        if cohort == "initial":
            require(result.returncode == 2 and not result.stdout and
                    result.stderr.startswith(f"error: uvx could not launch uv [{literal}]: Could not find the `uv` binary at ".encode()),
                    ("wrong diagnostic", result.returncode, result.stdout, result.stderr))
            semantic = "current tagged missing-sibling diagnostic"
        else:
            require((result.returncode, result.stdout, result.stderr) == (0, b"tool\nuvx\nfixed-argument\n", b""),
                    ("wrong suffixed sibling/forwarded argv", result.returncode, result.stdout, result.stderr))
            semantic = "selected uv@probe and forwarded tool uvx fixed-argument"
        return {"raw_sha256": sha(binary), "exit": result.returncode, "stdout": result.stdout.decode(),
                "stderr": result.stderr.decode(), "semantic": semantic}


def orders(arms, size, seed):
    perms = list(itertools.permutations(arms))
    require(size % len(perms) == 0, "schedule cannot be position balanced")
    cells = perms * (size // len(perms))
    random.Random(seed).shuffle(cells)
    return [list(x) for x in cells]


def verify_registration():
    seal = read(HERE / "registration.json")
    for name, digest in seal["files"].items():
        require(sha(WORK / name) == digest, f"registration drift: {name}")
    require(sha(ORIGINAL) == seal["original_uvx_sha256"], "uvx source drift")
    return seal


@contextlib.contextmanager
def authorized(phase, cohort, extra_gib):
    """Exclusive per-launch authority. Mere existence of an old cancellation/window is insufficient."""
    verify_registration()
    wanted = os.getenv("SMALL_FRONTEND_GRANT_SHA256")
    grant_path = HERE / "grants" / f"{phase}-{cohort}.json"
    require(wanted and grant_path.is_file() and sha(grant_path) == wanted,
            "no coordinator grant for this phase and checkout")
    grant = read(grant_path)
    require(set(grant) == {"phase", "cohort", "registration_sha256", "host_boot_id", "cpus",
                           "release", "release_sha256", "expires_utc_ns","drivers_sha256"}, "unexpected grant fields")
    require(grant["phase"] == phase and grant["cohort"] == cohort and
            grant["registration_sha256"] == sha(HERE / "registration.json") and
            grant["host_boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip() and
            time.time_ns() < grant["expires_utc_ns"], "stale or mismatched grant")
    require(tuple(grant["cpus"]) == NATIVE_CPUS and sorted(os.sched_getaffinity(0)) == list(NATIVE_CPUS),
            "the registered run requires CPUs 0–15, Cargo -j8")
    require((grant["drivers_sha256"] is None) == phase.startswith("direct-"), "wrong driver authority for phase")
    released = Path(grant["release"])
    require(released.is_absolute() and released.parent == LAB and sha(released) == grant["release_sha256"],
            "missing explicit host-wide clearance")
    with (ROOT / "native-lease").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        require(shutil.disk_usage(BENCH).free >= (120 + extra_gib) * GIB, "120 GiB reserve plus admission margin")
        for rel in (Path("bin/rustc"), LINK):
            require(sha(TOOLS / rel) == sha(DIST / rel), f"released tool changed: {rel}")
        yield grant


def assert_floor(extra=2):
    require(shutil.disk_usage(BENCH).free >= (120 + extra) * GIB, "disk reserve reached")
