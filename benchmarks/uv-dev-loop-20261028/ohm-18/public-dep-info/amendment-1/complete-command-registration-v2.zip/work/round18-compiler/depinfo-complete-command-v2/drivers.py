"""Build and audit each isolated Cargo source via the exact previously exercised PGO machinery."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import importlib.util
from pathlib import Path
import shutil
import sys
from depcommon import *

sys.path.insert(0,str(PRIOR/"normal-pgo-v3"))
import build_head
import pgo


def exact_source(src,patch,tree):
    material=read(HERE/"sources.json")["subjects"]
    arm,= [arm for arm,obj in material.items() if obj["tree"]==tree]
    candidate=material[arm]
    need(arm in ("pr269","head") and sha(patch)==candidate["patch_sha256"],"wrong one-file source patch")
    recipe=WORK/"round18-cargo/recipe/prepare.py"
    spec=importlib.util.spec_from_file_location("depinfo_tree",recipe)
    calc=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(calc)
    rel=Path(candidate["only_source"])
    need(calc.tree(src)==tree and sha(src/rel)==candidate["file_sha256"],
         "actual complete source and/or output_depinfo.rs differ")
    need(calc.tree(pgo.BASEREC/"cargo-src")==material["base"]["tree"] and
         sha(pgo.BASEREC/"cargo-src"/rel)==material["base"]["file_sha256"],"release base changed")
    plus=[x[6:] for x in Path(patch).read_text().splitlines() if x.startswith("+++ b/")]
    minus=[x[6:] for x in Path(patch).read_text().splitlines() if x.startswith("--- a/")]
    need(plus==minus==[str(rel)],"extra file in source input")
    return [str(rel)]


def driver(arm,phase):
    need(arm in ("pr269","head"),"missing isolated arm")
    pgo.source_delta=exact_source
    out=OUT/"drivers"/arm
    candidate=read(HERE/"sources.json")["subjects"][arm]
    if phase=="build":
        need(not out.exists(),"driver attempt already exists")
        out.mkdir(parents=True)
        shutil.copy2(PRIOR/"normal-pgo-v3/training-plan.json",out/"training-plan.json")
        build_head.HERE=out
        build_head.SUITE=pgo.STABLE/("depinfo-complete-command-v2-"+arm)
        request={"cargo_parent":pgo.PIN,"patch":candidate["patch"],"patch_sha256":candidate["patch_sha256"],
                 "head_tree":candidate["tree"]}
        save(out/"input.json",request)
        build_head.build(request)
    elif phase=="audit":
        req=read(out/"candidate-request.json")
        need(req["source_tree"]==candidate["tree"] and req["patch_sha256"]==candidate["patch_sha256"],
             "driver request is for a different subject")
        result=pgo.verify_candidate(req)
        need(result["source_changes"]==[candidate["only_source"]] and result["source_tree"]==candidate["tree"] and
             result["uv_training_commands"]==0 and len(result["raw_profiles"])==24,
             "profile/source/stdlib audit incomplete")
        save(out/"verified.json", {"arm":arm,"builder_adapter_sha256":sha(Path(__file__)),
                                   "input_sha256":sha(out/"input.json"),"request_sha256":sha(out/"candidate-request.json"),
                                   "audit":result})
    else:
        raise ValueError(phase)


def variants():
    result={"shipped":DIST/"bin/cargo","base":pgo.BASE_BIN}
    need(sha(result["shipped"])==SHIPPED and sha(result["base"])==BASE and sha(DIST/"bin/rustc")==RUSTC and
         sha(DIST/LINK)==WILD,"release binary drift")
    training=[]
    profiles=set()
    for arm in ("pr269","head"):
        root=OUT/"drivers"/arm
        proof=read(root/"verified.json")
        audit=proof["audit"]
        need(proof["arm"]==arm and proof["builder_adapter_sha256"]==sha(Path(__file__)) and
             proof["request_sha256"]==sha(root/"candidate-request.json") and audit["source_tree"]==
             read(HERE/"sources.json")["subjects"][arm]["tree"],"driver audit drift")
        result[arm]=Path(audit["head"])
        need(sha(result[arm])==audit["head_sha256"] and audit["std_sha256"]==pgo.STD_SHA and
             audit["base_sha256"]==BASE and len(audit["raw_profiles"])==24,"unaccepted final driver")
        profiles.add(audit["head_profile_sha256"])
        training.append(audit["training_commands"])
    need(len(profiles)==2 and pgo.BASE_PROFILE not in profiles and training[0]==training[1],
         "separate independently trained driver profiles or shared training workload not established")
    need(len({sha(x) for x in result.values()})==4,"four distinct executables required")
    return result
