"""Actual whole Cargo build. The primary instruction count is the selected Cargo/rustc/Wild sum."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import collections
import subprocess
import sys
from products import *
WRAPPER=WORK/"tree-count/wrap.py"
COUNTER=WORK/"edit-link-profile/native-instrument/count.py"
sys.path.insert(0,str(WORK/"tree-count"))
from identical import audit_native


def wrappers(pool):
    t=pool/"counter-tools"
    engine=read(WORK/"round18-cargo/edited-roles/sealed.json")["dynamorio"]
    install=WORK/"dynamorio/DynamoRIO-Linux-11.3.0-1"
    need(all(sha(install/name)==digest for name,digest in engine.items()),"uncalibrated DBI engine or collector")
    prior=read(WORK/"round18-cargo/edited-roles/plan.json")
    need(sha(WRAPPER)==prior["wrapper_sha256"] and sha(COUNTER)==prior["counter_sha256"],
         "instrumentation is not the previously calibrated one")
    (t/"bin").mkdir(parents=True)
    (t/"linker").mkdir()
    for dest in (t/"bin/cc",t/"rustc-wrapper",t/"linker/ld.bfd"):
        dest.symlink_to(WRAPPER)


def wrapped(root,pool,out,mode,*,admit=False,warm=False):
    need(mode in ("native","count") and not (mode=="count" and admit),"invalid counter mode")
    out.mkdir()
    t=pool/"counter-tools"
    tools=ROOT/"tools"
    paths={"cargo":tools/"bin/cargo","rustc":tools/"bin/rustc","wild":tools/LINK,
           "linker_wrapper":t/"linker/ld.bfd"}
    env=worker.env(root)
    env.update(PATH=str(t/"bin")+":"+env["PATH"],RUSTC_WRAPPER=str(t/"rustc-wrapper"),
               OHM_RELEASE_WILD_DIR=str((tools/LINK).parent),OHM_WRAPPED_WILD_DIR=str(t/"linker"),
               OHM_ACTUAL_WILD=str(paths["wild"]),OHM_SINGLE_COUNTER=str(COUNTER),
               OHM_ROLE_MODE=mode,OHM_ROLE_LOG=str(out))
    native=worker.command("build")
    argv=[str(WRAPPER),"cargo",*native]
    if admit:
        argv=["strace","-ff","-qq","-s","2048","-e","trace=execve,execveat","-o",str(out/"exec"),*argv]
    with (out/"cargo.log").open("x") as log:
        proc=subprocess.run(argv,cwd=root/"uv",env=env,stdout=log,stderr=subprocess.STDOUT)
    need(proc.returncode==0,"instrumented or wrapper-native Cargo failed")
    roster=worker.rosters((out/"cargo.log").read_text())
    need(roster["tests"]==[],"tests ran during the build endpoint")
    if warm:
        return roster
    need(len(roster["compiled"])==1 and roster["compiled"][0].startswith("uv v0.12.0 ("),"unexpected dirty package")
    records={role:[read(f) for f in sorted(out.glob(role+"-*.json"))] for role in ("cargo","rustc","wild")}
    need(all(len(r)==1 for r in records.values()),"incomplete Cargo, uvx rustc, Wild roster")
    totals={}
    for role,(rec,) in records.items():
        need(rec["role"]==role and rec["executable"]==str(paths[role]),"unknown role executable")
        if mode=="count":
            need(rec["threads"] and all(v>0 for v in rec["threads"].values()) and
                 sum(rec["threads"].values())==rec["instructions"] and rec["instructions"]>0,
                 "invalid thread accounting")
            totals[role]=rec["instructions"]
    need(records["cargo"][0]["argv"]==native[1:],"counted another Cargo workload")
    rustc_argv=[str(paths["rustc"]),*records["rustc"][0]["argv"]]
    product=exact_frontend(rustc_argv,root)
    wild=records["wild"][0]["argv"]
    need(wild.count("--no-fork")==1 and wild.count("-o")==1 and wild[wild.index("-o")+1]==product["produced"],
         "instrumented Wild can fork or writes the wrong source-backed uvx executable")
    if admit:
        audit_native(out,paths,[v[0] for v in records.values()])
    result={"direct_command":native,"actual_argv":argv,"status":proc.returncode,"mode":mode,"roster":roster,
            "tools":{k:str(v) for k,v in paths.items()},"frontend":product,"totals":totals,
            "wild_argv":records["wild"][0]["argv"],"environment_delta":{k:env[k] for k in
            ("RUSTC_WRAPPER","OHM_RELEASE_WILD_DIR","OHM_WRAPPED_WILD_DIR","OHM_ACTUAL_WILD","OHM_SINGLE_COUNTER",
             "OHM_ROLE_MODE","OHM_ROLE_LOG","PATH")},"public":depfiles(root) if admit else None,
            "role_files":{role:{f.name:sha(f) for f in out.glob(role+"-*.json")} for role in records},
            "log_sha256":sha(out/"cargo.log")}
    save(out/"counted.json",result)
    return result
