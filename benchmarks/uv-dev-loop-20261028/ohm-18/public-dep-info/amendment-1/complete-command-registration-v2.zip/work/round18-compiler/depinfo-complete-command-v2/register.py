"""Freeze plans and small signed inputs only. No host authorization is created."""
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from depcommon import *

def main():
    from verify_amendment import verify
    verify(sealed=False)
    snapshots=[HERE/name for name in (
        "README.md","depcommon.py","drivers.py","banks.py","counted.py","experiment.py","products.py","run.py",
        "retire.py","assess.py","rescore.py","selftest.py","selftest.json","historical-input.json","audit_input.py",
        "sources.json","269-only.patch","enroll.py","power.py","power.json","design.py","design-power.json","schedules.csv",
        "fallback-guards.py","grant_form.py","register.py","amendment.json","verify_amendment.py","source-review.json")]
    snapshots += [WORK/name for name in (
        "edit_holdout.py","measure.py","validate-depfile.py","tree-count/wrap.py","tree-count/identical.py",
        "edit-link-profile/native-instrument/count.py","round18-cargo/edited-roles/sealed.json",
        "round18-cargo/edited-roles/plan.json","round18-cargo/recipe/prepare.py","round18-cargo/recipe/pgo18.py",
        "round18-cargo/recipe/wrap-rustc.py","round18-cargo/pgo/provenance.json",
        "round18-compiler/small-frontend-screen/normal-pgo-v3/build_head.py",
        "round18-compiler/small-frontend-screen/normal-pgo-v3/pgo.py","round18-compiler/small-frontend-screen/normal-pgo-v3/training-plan.json",
        "round18-compiler/small-frontend-screen/normal-pgo-v3/physical-build/returned.json",
        "round18-compiler/small-frontend-screen/normal-pgo-v3/physical-build/generated-target-storage.json",
        "round18-compiler/small-frontend-screen/study.py","round18-compiler/small-frontend-screen/direct.py",
        "round18-compiler/small-frontend-screen/normal.py","round18-lab/native-uvx.py","round18-lab/native.py",
        "round18-lab/native-admitted.py","round18-lab/common.py","round18-lab/stock-elf-forms.json",
        "round18-lab/registered-uvx.json","round18-lab/storage-handoff/snapshot.json",
        "round18-lab/depinfo-source-audit/candidate-v2.patch","round18-lab/depinfo-source-audit/candidate.patch",
        "round18-compiler/depinfo-complete-command/registered.json","round18-lab/depinfo-source-audit/source-sections.rs",
        "round18-lab/depinfo-source-audit/phase.rs","round18-lab/depinfo-source-audit/initial.rows",
        "round18-lab/depinfo-source-audit/replica.rows","round18-lab/depinfo-source-audit/source-overlap.json",
        "round18-lab/depinfo-source-audit/phase-execution-plan.json","round18-lab/depinfo-source-audit/native-phase/score.json",
        "round18-lab/depinfo-source-audit/native-phase/returned.json","uv/crates/uv/src/bin/uvx.rs",
        "../outputs/ohm-18-further-edited-timings.csv")]
    for module in ("elf_equivalence","rlib_equivalence"):
        candidates=[p for p in (WORK/(module+".py"),LAB/(module+".py")) if p.is_file()]
        need(len(candidates)==1,module)
        snapshots+=candidates
    for c in COHORTS:
        snapshots += [LAB/"depinfo-source-audit"/(c+"-rejected-build-structural-input-shape.json"),
            LAB/"r18-uvx"/c/"build/admission-shipped/receipt.json",
            LAB/"native-series-custody/r18-uvx"/c/"returned.json",WORK/"upstream-monitor/cargo"/("admission-"+c)/"admitted.json"]
    need(not OUT.exists() and not (HERE/"grants").exists(),"no pre-existing statistical subject, run, or grant")
    need(read(LAB/"depinfo-source-audit/native-phase/score.json")["phase_whole_command_eligible"] and
         read(LAB/"depinfo-source-audit/native-phase/returned.json")["physical_returned"],"isolated prerequisite failed")
    subjects=read(HERE/"sources.json")
    power=read(HERE/"design-power.json")
    data={"study":"ohm18-output-depinfo-whole-command-v2","sealed_utc_ns":time.time_ns(),"release":"ohm-1.99.0-18",
          "uv":UV,"cargo_parent":subjects["release"],"rust_parent":"a4fa11bcd38280639cb94daacc125472657db6c3",
          "source_trees":{k:x["tree"] for k,x in subjects["subjects"].items()},
          "known_binary_sha256":{"shipped_cargo":SHIPPED,"matched_pgo_base":BASE,"shipped_rustc":RUSTC,"shipped_wild":WILD},
          "pending_binary_freeze":"observed/subjects.json after independent PGO audits and the real CLI guard before subjects",
          "endpoint":["cargo","build","--locked","--offline","-j8"],"native_affinity":list(range(16)),"pgo_affinity":list(range(24,32)),
          "ordinary_source":str(SOURCE),"edits":{"initial":"tagged missing-sibling diagnostic","replica":"tagged executable prefix selection"},
          "normal_blocks":{"initial":3456,"replica":960},"normal_commands":17664,"count_blocks_per_cohort":24,"count_commands":192,
          "order":"all 24 permutations equally frequent within each independent cohort, externally sealed scheduling CSV; disjoint count/native tags",
          "gates":{"count":"each of six: raw wins and independently conditional order-exact p <= .025; median Cargo saving >= 1,000,000 and median selected-role percent saving >= .1",
                   "native":"each of six: raw wins and independently conditional order-exact p <= .025; median raw complete-command saving >= 1,000,000 ns",
                   "aggregation":"intersection-union all three contrasts in both checkouts, no subset or interim declaration, ties count as losses",
                   "no_censoring":True,"no_interim_sign_stopping":True,"failed_futility_retry":False},
          "selected_power_estimate_six_way_union_lower_bound":power["selected_six_way_union_lower_bound"],
          "unselected_bounded_option":"480+480, documented only; no alternative path following observed data",
          "storage":{"root_floor_bytes":FLOOR,"prepare_admission_bytes":FLOOR+60*GIB,"measured_clone_headroom_bytes":12*GIB,
                     "disk_watch_stop_margin_bytes":4*GIB,"maximum_banks_global":4,"never_retire_unowned":True},
          "initial_states":{"new_target_banks":0,"new_instrumented_workloads":0,"new_timed_commands":0,"new_driver_builds":0},
          "immutable_files":{os.path.relpath(p,WORK):sha(p) for p in snapshots}}
    save(HERE/"registered.json",data)
    print(sha(HERE/"registered.json"))

if __name__=="__main__":main()
