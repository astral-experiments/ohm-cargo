"""CPU-only receipt, schedule, scorer and guard controls. No executables, target files or corpus builds."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import collections
import itertools
import tempfile
from depcommon import *
import assess
import design
import products
import run


def rejects(fn):
    try:fn()
    except (RuntimeError,AssertionError,ValueError,KeyError,FileNotFoundError):
        return
    raise AssertionError("negative control accepted")


def main():
    rows=assess.read_csv(HERE/"schedules.csv")
    need(len(rows)==4464, "wrong prospective number of complete blocks")
    for phase in ("native","count"):
        for c,n in assess.N[phase].items():
            r=[x for x in rows if (x["phase"],x["cohort"])==(phase,c)]
            orders=collections.Counter(tuple(x[k] for k in ("first","second","third","fourth")) for x in r)
            need(len(r)==n and set(orders.values())=={n//24} and len(orders)==24,"unbalanced four-arm positions")
            need(len({x["literal"] for x in r})==n and
                 all(x["literal"]==design.tag(c,i+(4000 if phase=="count" else 0)) for i,x in enumerate(r)),"wrong tags")
    for n in (2,4,6):
        for early in range(n+1):
            for late in range(n-early+1):
                signs=[1]*early+[-1]*late+[0]*(n-early-late)
                exact=collections.Counter()
                for movement in itertools.combinations(range(n),n//2):
                    first=set(movement)
                    exact[sum((i in first and v>0) or (i not in first and v<0) for i,v in enumerate(signs))]+=1
                need(exact==assess.null_weights(n,early,late)==design.null_weights(n,early,late),"null allocation weights")
    rows_count=[x for x in rows if x["phase"]=="count"]
    data={c:[] for c in COHORTS}
    for r in rows_count:
        for rank,k in enumerate(("first","second","third","fourth"),1):
            a=r[k]
            data[r["cohort"]].append({"phase":"count","cohort":r["cohort"],"block":r["block"],"rank":rank,"arm":a,
                "literal":r["literal"],"source_sha256":"a"*64,"source_mtime_ns":11,"elf_sha256":"b"*64,
                "cargo":10_000_000 if a=="head" else 14_000_000,"rustc":7_000_000,"wild":8_000_000})
    need(assess.result(rows,data,"count")["qualifies"],"strict positive synthetic six-way result rejected")
    empty={c:[{**x,"cargo":12_000_000} for x in d] for c,d in data.items()}
    need(not assess.result(rows,empty,"count")["qualifies"],"ties passed")
    slot_only={c:[{**x,"cargo":15_000_000 if x["rank"] in (1,2) else 10_000_000} for x in d] for c,d in data.items()}
    need(not assess.result(rows,slot_only,"count")["qualifies"],"pure rank advantage passed")
    edited={c:[dict(x) for x in d] for c,d in data.items()}
    edited["replica"][0]["arm"]=edited["replica"][1]["arm"]
    rejects(lambda:assess.result(rows,edited,"count"))
    edited["replica"]=[dict(x) for x in data["replica"]]
    edited["replica"][0]["elf_sha256"]="c"*64
    rejects(lambda:assess.result(rows,edited,"count"))
    names=products.public_names()
    ar=Path("/synthetic/checkout")
    good=[f'openat(AT_FDCWD, "{ar}/target/debug/{n}", O_RDONLY|O_CLOEXEC) = 5' for n in names]
    bad=good[:-1]+[good[-1].replace("= 5","= -1 ENOENT")]
    need(len(products.trace_accesses(good,ar,names,"read"))==74,"not every genuine successful open admitted")
    rejects(lambda:products.trace_accesses(bad,ar,names,"read"))
    rejects(lambda:products.trace_accesses(good,ar,names,"write"))
    good=[l.replace("O_RDONLY","O_WRONLY|O_CREAT") for l in good]
    need(len(products.trace_accesses(good,ar,names,"write"))==74,"missing real opened-write control")
    gr={"study":"D","phase":"sample-native","key":"initial","registration_sha256":"c"*64,"host_boot_id":"boot",
        "cpus":list(range(16)),"release":"/synthetic/release","release_sha256":"c"*64,"issued_utc_ns":2,"expires_utc_ns":4}
    args=("D","sample-native","initial")
    passport(*args,gr,3,"boot",range(16),"c"*64)
    rejects(lambda:passport(*args,gr,4,"boot",range(16),"c"*64))
    rejects(lambda:passport(*args,gr,3,"boot",range(8),"c"*64))
    rejects(lambda:passport(*args,{**gr,"key":"replica"},3,"boot",range(16),"c"*64))
    headroom(FLOOR+12*GIB,12*GIB)
    rejects(lambda:headroom(FLOOR+12*GIB-1,12*GIB))
    for c in COHORTS:
        cap=LAB/"r18-uvx"/c/"build/admission-shipped"
        rust=products.traced_argv(cap,ROOT/"tools/bin/rustc")
        cargo=products.traced_argv(cap,ROOT/"tools/bin/cargo")
        ld=products.traced_argv(cap,ROOT/"tools"/LINK)
        need(rust==products.normal.active_roles(cap)[0] and cargo==products.worker.command("build") and
             ld[ld.index("-o")+1]==str(Path(rust[rust.index("--out-dir")+1])/"uvx"),"historical native role binding failed")
    return {"offline_only":True,"scheduled_real_native_commands":17664,"scheduled_real_counted_commands":192,
            "statistical_controls":["all six genuine wins","all ties","pure order","incorrect arm","different binary",
                                    "enumerated every balanced order at n=2,4,6 with all tie patterns"],
            "capacity_controls":["exact headroom","one byte short","expired release","wrong CPUs","wrong checkout"],
            "source_controls":["both original real native Cargo/rustc/Wild argvs agree","74 successful direct opens",
                               "unsuccessful final open rejected","read/write distinction","fixed unique edits"],
            "new_tool_processes":0,"allocated_target_banks":0}


if __name__=="__main__":
    print(json.dumps(main(),sort_keys=True,indent=2))
