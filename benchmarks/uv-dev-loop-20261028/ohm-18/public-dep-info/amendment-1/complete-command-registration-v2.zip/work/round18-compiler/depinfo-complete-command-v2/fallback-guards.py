"""Compare dependency-file bytes and mtimes from two built Cargo drivers."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--base", type=Path, required=True)
parser.add_argument("--candidate", type=Path, required=True)
parser.add_argument("--directory", type=Path, required=True)
args = parser.parse_args()
study = Path(__file__).resolve().parent
work = study.parents[1]
distribution = work / "upstream-monitor/toolchain18"
root = args.directory.resolve()
assert " " not in str(root) and not root.exists()
root.mkdir(parents=True)
def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while data := f.read(2**20):
            h.update(data)
    return h.hexdigest()

bins = {"release": args.base.resolve(strict=True), "candidate": args.candidate.resolve(strict=True)}
assert digest(bins["release"]) != digest(bins["candidate"])
env = {k: os.environ[k] for k in ("HOME", "LANG", "TZ") if k in os.environ}
env.update(PATH=str(distribution/"bin")+":/usr/bin:/bin", RUSTC=str(distribution/"bin/rustc"),
           RUSTDOC=str(distribution/"bin/rustdoc"), CARGO_HOME=str(root/"cargo-home"),
           CARGO_TARGET_DIR=str(root/"target"), CARGO_TERM_COLOR="never", CARGO_NET_OFFLINE="true")
project = root / "project"
project.mkdir()
(project/"src").mkdir()
(project/"data").mkdir()
(project/"data/flag").write_text("fixture\n")
for mod in ("first", "second"):
    (project/"src"/(mod+".rs")).write_text("pub const VALUE: u8 = 7;\n")
stamp = 1_601_234_567_123_456_789
manifest = '[package]\nname="depinfo_guard"\nversion="0.0.1"\nedition="2024"\n'
forms = ["data//flag", "data/./flag", "data/flag"]
def build_rs(names):
    lines = ['    println!("cargo:rerun-if-changed='+n+'");' for n in names]
    (project/"build.rs").write_text("fn main() {\n"+"\n".join(lines)+"\n}\n")
def lib(mod, value):
    (project/"src/lib.rs").write_text(f"mod {mod};\npub const VALUE: u8 = {mod}::VALUE + {value};\n")
def command(driver, options=()):
    return [driver, "build", "--locked", "--offline", "-j1", *options]
def run(cmd):
    result = subprocess.run(cmd, env=env, cwd=project, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    with (root/"commands.log").open("ab") as log:
        log.write((repr([str(v) for v in cmd])+"\n").encode()+result.stdout+b"\n")
    if result.returncode:
        raise RuntimeError(result.stdout.decode(errors="replace"))

results = {}
for label, driver in bins.items():
    data = {}
    results[label] = data
    lib("first", 1)
    build_rs(["data/flag"])
    (project/"Cargo.toml").write_text(manifest)
    if label == "release":
        run([driver, "generate-lockfile", "--offline"])
    run(command(driver))
    path = root/"target/debug/libdepinfo_guard.d"
    artifact = root/"target/debug/libdepinfo_guard.rlib"
    raw = path.read_bytes()
    target, _, rest = raw.rstrip(b"\n").partition(b": ")
    names = rest.split(b" ")
    assert len(names) >= 3 and any(x.endswith(b"/src/first.rs") for x in names)
    data["canonical"] = raw.hex()
    def observe(case, contents, expected, preserve, options=()):
        if contents is None:
            path.unlink(missing_ok=True)
        else:
            path.write_bytes(contents)
            os.utime(path, ns=(stamp, stamp))
        run(command(driver, options))
        actual = path.read_bytes()
        assert actual == expected, (label,case)
        retained = path.stat().st_mtime_ns == stamp
        if preserve is not None:
            assert retained == preserve, (label,case,preserve)
        data[case] = {"hash": hashlib.sha256(actual).hexdigest(), "mtime_preserved":retained}
    observe("fresh", raw, raw, True)
    malformed = {
        "absent": None,
        "wrong_target": b"wrong" + raw,
        "absent_newline": raw[:-1],
        "duplicate": target+b": "+b" ".join([*names, names[-1]])+b"\n",
        "reordered": target+b": "+b" ".join(reversed(names))+b"\n",
        "extra": raw[:-1]+b" extraneous\n",
        "missing": target+b": "+b" ".join(names[1:])+b"\n",
        "bad_utf8": raw[:-1]+b" \xff\n",
        "extra_line": raw+b"other:\n",
        "alternative_spelling": target+b": "+b" ".join([names[0], *[n.replace(b"/src/", b"/src/./") for n in names[1:]]])+b"\n",
    }
    for case, old in malformed.items():
        assert old != raw, case
        observe(case, old, raw, False)
    before = digest(artifact)
    lib("first", 2)
    observe("literal_edit", raw, raw, True)
    assert digest(artifact) != before, "literal edit did not change the compiled library"
    lib("second", 2)
    os.utime(path, ns=(stamp,stamp))
    run(command(driver))
    changed = path.read_bytes()
    assert b"/src/second.rs" in changed and b"/src/first.rs" not in changed and path.stat().st_mtime_ns != stamp
    data["new_module"] = changed.hex()
    observe("fresh_after_new_module", changed, changed, True)
    for i, entries in enumerate((forms, list(reversed(forms)))):
        build_rs(entries)
        run(command(driver))
        aliases = path.read_bytes()
        data[f"alias_order_{i}"] = aliases.hex()
        observe(f"fresh_alias_order_{i}", aliases, aliases, True)
    (project/"Cargo.toml").write_text(manifest+'[lib]\ncrate-type=["rlib","cdylib"]\n')
    options = ["--config","build.dep-info-basedir="+json.dumps(str(root))]
    path.unlink()
    run(command(driver,options))
    multi = path.read_bytes()
    assert multi.startswith(b"target/debug/libdepinfo_guard.") and b"project/src/lib.rs" in multi
    data["multiple_outputs_with_basedir"] = multi.hex()
    # Cargo's multi-output behavior is defined by its existing parser. Compare
    # its observed mtime across drivers along with the exact selected target.
    observe("fresh_multiple_outputs", multi, multi, None, options)
    (root/"target").rename(root/(label+"-target"))
assert results["release"] == results["candidate"]

# The established #269 CLI fixture has separate Unicode, escaped spaces,
# relative/mixed base paths, and unchanged-mtime oracles.
spaces = root/"escaped"
spaces.mkdir()
shutil.copyfile(work/"validate-depfile.py", spaces/"validate-depfile.py")
(spaces/"toolchain").symlink_to(distribution, target_is_directory=True)
with (spaces/"result.log").open("xb") as log:
    subprocess.run([sys.executable, "-I","-B", str(spaces/"validate-depfile.py"), *bins.values()],
                   env=env,cwd=spaces,stdout=log,stderr=subprocess.STDOUT,check=True)
assert all(x in (spaces/"result.log").read_text() for x in ("absolute ", "relative ", "mixed "))
report = {"driver_sha256":{k:digest(v) for k,v in bins.items()},"compiler_sha256":digest(distribution/"bin/rustc"),
          "cases":results,"escaped_fixture_sha256":digest(spaces/"validate-depfile.py"),
          "escaped_log_sha256":digest(spaces/"result.log"),"identical":True}
(root/"verified.json").write_text(json.dumps(report,indent=2)+"\n")
print(len(results["release"]),"main CLI cases; three escaped-path modes; both drivers matched")
