"""Freeze the prospective complete-command assignments and model their actual order-stratified gate."""
import csv
import itertools
import json
import math
from pathlib import Path
import random
import statistics
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import power

HERE = Path(__file__).resolve().parent
ARMS = ("shipped","base","pr269","head")
COHORTS = {"initial":3456,"replica":960}
ALPHA = .025


def schedule(n, seed):
    permutations = list(itertools.permutations(ARMS))
    assert n % len(permutations) == 0
    orders = permutations * (n // len(permutations))
    random.Random(seed).shuffle(orders)
    return orders


def tag(cohort, index):
    # Existing genuine-uvx helper accepts exactly two uppercase letters plus three digits.
    return ("I" if cohort == "initial" else "R") + chr(65 + index//1000) + f"{index%1000:03d}"


def null_weights(n, early, late=None):
    """Exact integer assignment masses. Each pair of remaining arm slots is conditionally uniform."""
    m = n//2
    if late is None:
        late = n-early
    tied = n-early-late
    assert n == 2*m and min(early,late,tied) >= 0
    counts = {}
    for x in range(max(0,m-late-tied), min(early,m)+1):
        for z in range(max(0,m-x-late),min(tied,m-x)+1):
            y = m-x-z
            wins = x + late-y
            counts[wins] = counts.get(wins,0) + math.comb(early,x)*math.comb(late,y)*math.comb(tied,z)
    assert sum(counts.values()) == math.comb(n,m)
    return counts


def calibrate(cohort, n, data, rng, repeats=2048):
    import numpy as np
    m = n//24
    nh = n//12
    blocks = {}
    for r in data:
        if (r["study"],r["checkout"],r["command"]) == ("r18-uvx",cohort,"cargo build") and r["arm"] in ("base","shipped"):
            blocks.setdefault(int(r["block"]),[]).append((int(r["rank"]),int(r["elapsed_ns"])/1e6))
    assert len(blocks)==30 and all(len(v)==2 for v in blocks.values())
    diff = [sorted(v)[0][1]-sorted(v)[1][1] for v in blocks.values()]
    power.ALPHA = ALPHA
    critical = power.critical(n)
    length = 1 << n.bit_length()
    # FFT convolution reproduces the conventional exact randomization tail up to floating rounding.
    # The actual native scorer uses integer masses.
    spectra = []
    for early in range(nh+1):
        weights = null_weights(nh,early)
        den = sum(weights.values())
        pdf = np.zeros(nh+1)
        for k,v in weights.items():
            pdf[k] = v/den
        spectra.append(np.fft.rfft(pdf,length))
    spectra = np.asarray(spectra)
    outputs = {}
    for delta in (6.58,8.21,15.,20.):
        f, l = sum(x < delta for x in diff)/30, sum(-x < delta for x in diff)/30
        if delta in (6.58,8.21):
            assert not any(0 < y+delta < 1. for x in diff for y in (x,-x))
        passed = 0
        for start in range(0,repeats,16):
            a = rng.binomial(m,f,size=(16,12))
            b = rng.binomial(m,l,size=(16,12))
            wins = np.sum(a+b,axis=1)
            e = a+m-b
            distribution = np.fft.irfft(np.prod(spectra[e],axis=1),length)
            upper = np.cumsum(distribution[:,::-1],axis=1)[:,::-1][np.arange(16),wins]
            passed += int(np.sum((wins>=critical) & (upper<=ALPHA)))
        outputs[str(delta)]={"first_wins":f,"second_wins":l,"estimated_power":passed/repeats,
                            "MC_standard_error":math.sqrt((passed/repeats)*(1-passed/repeats)/repeats)}
    return {"n":n,"historical_early_minus_late_median_ms":statistics.median(diff),"historical_pairs":30,
            "wins_required":critical,"deltas_ms":outputs,"simulations_per_shift":repeats}


def main():
    import numpy as np
    schedule_path = HERE/"schedules.csv"
    with schedule_path.open("w") as stream:
        w=csv.writer(stream,lineterminator="\n")
        w.writerow(["phase","cohort","block","literal","first","second","third","fourth"])
        for ci,(cohort,n) in enumerate(COHORTS.items()):
            for phase, count, offset, seed in (("native",n,0,1826102915),("count",24,4000,1826102932)):
                for i,order in enumerate(schedule(count,seed+ci*2317)):
                    w.writerow([phase,cohort,i,tag(cohort,i+offset),*order])
    raw = list(csv.DictReader(power.INPUT.open()))
    rng=np.random.default_rng(202610290936)
    result={"alpha_per_contrast":ALPHA,"claim":"all three controls in both checkouts, intersection-union",
            "selected":{},"unselected_bounded_alternative":{}}
    for cohort,n in COHORTS.items():
        result["selected"][cohort]=calibrate(cohort,n,raw,rng)
        result["unselected_bounded_alternative"][cohort]=calibrate(cohort,480,raw,rng)
    for family in ("selected","unselected_bounded_alternative"):
        errors=[]
        for c in COHORTS:
            row=result[family][c]["deltas_ms"]
            errors.extend([1-row["6.58"]["estimated_power"]]+[1-row["8.21"]["estimated_power"]]*2)
        result[family+"_six_way_union_lower_bound"]=max(0,1-sum(errors))
    print(json.dumps(result,sort_keys=True,indent=2))


if __name__ == "__main__":
    main()
