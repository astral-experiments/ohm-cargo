"""Prospectively authorized physical runner. Every phase owns a separate single-use grant and receipt."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import argparse
import ctypes
import secrets
import signal
import subprocess
import sys
import time
from depcommon import *

PHASES={"build":("pr269","head"),"audit":("pr269","head"),"retire-pgo":("pr269","head"),
        "functional":("all",),**{p+"-"+m:COHORTS for m in ("count","native") for p in ("prepare","admit","sample","retire")}}


def functional():
    from drivers import variants
    bins=variants()
    d=OUT/"functional"
    d.mkdir()
    root=BENCH/"depinfo-complete-guards-v1"
    need(not root.exists(),"cannot replace a functional fixture")
    argv=[sys.executable,"-I","-B",str(HERE/"fallback-guards.py"),"--base",str(bins["base"]),
          "--candidate",str(bins["head"]),"--directory",str(root)]
    with (d/"guard.log").open("x") as log:
        rc=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT).returncode
    need(rc==0,"CLI fallback/canonical-byte or mtime oracle failed")
    raw=root/"verified.json"
    data=read(raw)
    need(data["driver_sha256"]=={"release":sha(bins["base"]),"candidate":sha(bins["head"])} and
         data["identical"],"functional test used different sources")
    save(d/"verified.json",{"patch_sha256":read(HERE/"sources.json")["subjects"]["head"]["patch_sha256"],
        "validated":str(raw),"validated_sha256":sha(raw),"escaped_log":str(root/"escaped/result.log"),
        "actual_exit":rc,"argv":argv,"guard_log_sha256":sha(d/"guard.log")})
    accepted=guards()
    save(OUT/"subjects.json",{"release":"ohm-1.99.0-18","registration_sha256":sha(HERE/"registered.json"),
            "rustc_sha256":RUSTC,"wild_sha256":WILD,"cargo":{a:{"sha256":sha(path),"path":str(path)} for a,path in bins.items()},
            "sources_sha256":sha(HERE/"sources.json"),"audits":{a:sha(OUT/"drivers"/a/"verified.json") for a in ("pr269","head")},
            "profiles":{a:read(OUT/"drivers"/a/"verified.json")["audit"]["head_profile_sha256"] for a in ("pr269","head")},
            "matched_base_profile":read(OUT/"drivers/head/verified.json")["audit"]["base_profile_sha256"],
            "functional_sha256":accepted,"both_edits_and_74_names_sha256":sha(HERE/"historical-input.json")})


def execute(phase,key,g):
    if phase in ("build","audit"):
        from drivers import driver
        driver(key,phase)
        if phase=="build":
            from retire import record_pgo_targets
            record_pgo_targets(key)
    elif phase=="retire-pgo":
        from retire import pgo_targets
        pgo_targets(key)
    elif phase=="functional":
        functional()
    else:
        verb,mode=phase.split("-")
        if verb=="prepare":
            from banks import prepare
            # Complete instruction qualification is mandatory before even allocating native banks.
            if mode=="native":
                from rescore import all_results
                need(all_results("count")["qualifies"],"count not qualified")
            prepare(mode,key)
        elif verb=="admit":
            from experiment import admission
            admission(mode,key)
        elif verb=="sample":
            from experiment import sample
            sample(mode,key,g)
        else:
            from retire import bank_targets
            bank_targets(mode,key)


def child_pids(pid):
    found=set()
    try:
        threads=list(Path(f"/proc/{pid}/task").iterdir())
    except (FileNotFoundError,ProcessLookupError):
        return []
    for t in threads:
        try:
            found.update(map(int,(t/"children").read_text().split()))
        except (FileNotFoundError,ProcessLookupError):
            pass
    return sorted(found)


def descendants(pid):
    results={}
    pending=child_pids(pid)
    while pending:
        p=pending.pop()
        if p in results: continue
        try:
            stat=Path(f"/proc/{p}/stat").read_text().rsplit(")",1)[1].split()
        except (FileNotFoundError,ProcessLookupError):continue
        results[p]=(stat[0],int(stat[19]))
        pending.extend(child_pids(p))
    return results


def stop_descendants(child):
    # The supervisor is a Linux subreaper, so setsid() cannot evade custody.
    for _ in range(12):
        d=descendants(os.getpid())
        for pid,(state,start) in reversed(list(d.items())):
            if pid==child.pid or state in ("Z","X"):continue
            if descendants(os.getpid()).get(pid)==(state,start):
                try:os.kill(pid,signal.SIGTERM)
                except ProcessLookupError:pass
        time.sleep(.15)
        if child.poll() is not None:break
    if child.poll() is None:
        child.send_signal(signal.SIGINT)
    try:child.wait(15)
    except subprocess.TimeoutExpired:
        for pid,(state,start) in descendants(os.getpid()).items():
            if state not in ("Z","X") and descendants(os.getpid()).get(pid)==(state,start):
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
        child.wait()


def reap():
    zombies=[]
    for _ in range(60):
        pending=descendants(os.getpid())
        if not pending: return zombies
        if any(state not in ("Z","X") for state,_ in pending.values()):
            time.sleep(.1)
            continue
        for pid in child_pids(os.getpid()):
            try:
                got,status=os.waitpid(pid,os.WNOHANG)
                if got:
                    zombies.append([got,status])
            except ChildProcessError:pass
    need(not descendants(os.getpid()),"live or unreaped study-owned processes")
    return zombies


def run(phase,key):
    need(phase in PHASES and key in PHASES[phase],"unknown physical scope")
    with lease(phase,key) as g:
        reserve=(60 if phase.startswith("prepare-") else 10 if phase=="build" else 6)*GIB
        headroom(fsfree(),reserve)
        if phase in ("build","audit","retire-pgo"):
            from drivers import pgo
            if pgo.STABLE.stat().st_dev!=BENCH.stat().st_dev:
                need(shutil.disk_usage(pgo.STABLE).free>=12*GIB,"separate PGO volume lacks staging room")
        need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,"cannot establish descendant subreaper")
        out=OUT/"physical"/(phase+"-"+key)
        need(not out.exists(),"single-use grant already attempted")
        out.mkdir(parents=True)
        read_fd,write_fd=os.pipe()
        nonce=secrets.token_hex(32)
        os.write(write_fd,nonce.encode())
        os.close(write_fd)
        child=None
        low=fsfree()
        adopted=[]
        try:
            save(out/"owner.json",{"host":g["host_boot_id"],"parent_pid":os.getpid(),"grant_sha256":sha(HERE/"grants"/(phase+"-"+key+".json")),
                                  "free":low,"started_ns":time.time_ns(),"coordinator_release":g["release_sha256"]})
            with (out/"process.log").open("x") as log:
                child=subprocess.Popen([sys.executable,"-B",__file__,phase,key,"--worker-fd",str(read_fd),"--nonce",nonce,
                                          "--parent",str(os.getpid())],pass_fds=(read_fd,),start_new_session=True,
                                       stdout=log,stderr=subprocess.STDOUT)
                os.close(read_fd)
                save(out/"launched.json",{"worker":child.pid,"pid_session":os.getsid(child.pid),"parent":os.getpid()})
                while child.poll() is None:
                    for pid in child_pids(os.getpid()):
                        if pid!=child.pid:
                            try:
                                got,status=os.waitpid(pid,os.WNOHANG)
                                if got:adopted.append([got,status])
                            except ChildProcessError:pass
                    free=fsfree()
                    low=min(low,free)
                    need(free>=FLOOR+4*GIB,"4 GiB pre-floor disk stop")
                    need(time.time_ns()<g["expires_utc_ns"] and Path(g["release"]).is_file() and
                         sha(Path(g["release"]))==g["release_sha256"],"physical grant expired or replaced")
                    if phase=="build" and pgo.STABLE.stat().st_dev!=BENCH.stat().st_dev:
                        need(shutil.disk_usage(pgo.STABLE).free>=4*GIB,"local PGO volume almost full")
                    time.sleep(.4)
            code=child.wait()
        except BaseException as e:
            save(out/"fault.json",{"exception":repr(e),"free":fsfree(),"minimum_free":low,
                 "owned_before_stop":descendants(os.getpid()),"time_ns":time.time_ns()})
            if child is not None:stop_descendants(child)
            raise
        finally:
            if child is not None:
                if child.poll() is None:stop_descendants(child)
                zombies=reap()
                save(out/"returned.json",{"worker_exit":child.returncode,"minimum_free":low,"after_free":fsfree(),
                     "final_owned":descendants(os.getpid()),"adopted_zombie_exits":adopted+zombies,
                     "timestamp_ns":time.time_ns(),"process_sha256":sha(out/"process.log"),
                     "grant_sha256":sha(HERE/"grants"/(phase+"-"+key+".json"))})
        need(code==0,"physical worker rejected. Preserve its raw evidence and original single-use grant")


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("phase",choices=PHASES)
    ap.add_argument("key")
    ap.add_argument("--worker-fd",type=int)
    ap.add_argument("--nonce")
    ap.add_argument("--parent",type=int)
    a=ap.parse_args()
    need(a.key in PHASES[a.phase],"invalid phase key")
    if a.worker_fd is None:run(a.phase,a.key)
    else:
        need(os.getppid()==a.parent and os.getsid(0)==os.getpid() and
             os.read(a.worker_fd,128).decode()==a.nonce and len(a.nonce)==64,"direct worker invocation refused")
        os.close(a.worker_fd)
        grant=authority(a.phase,a.key)
        execute(a.phase,a.key,grant)
