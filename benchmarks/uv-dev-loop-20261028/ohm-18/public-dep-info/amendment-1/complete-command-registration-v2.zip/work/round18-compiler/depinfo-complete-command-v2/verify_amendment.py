"""Check the pre-observation correction, isolated matching code and primary design. No builds or grants."""
import ast
import csv
import hashlib
import json
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
OLD=HERE.with_name("depinfo-complete-command")
WORK=HERE.parents[1]
AUDIT=WORK/"round18-lab/depinfo-source-audit"
SRC=Path("src/compiler/output_depinfo.rs")
sys.path.insert(0,str(HERE))
from enroll import REL,git,new_tree,oid

def require(value,msg):
    if not value:
        raise ValueError(msg)

def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def integrated(patch,original):
    with tempfile.TemporaryDirectory() as name:
        path=Path(name)/SRC
        path.parent.mkdir(parents=True)
        path.write_bytes(original)
        subprocess.run(["git","apply","--whitespace=nowarn","-"],input=patch.read_bytes(),cwd=name,check=True)
        return path.read_bytes()

def body(data):
    start=data.index(b"fn matches_existing_dep_info(")
    return data[start:data.index(b"\n}",start)+2]

def verify(sealed=True):
    a=read(HERE/"amendment.json")
    original=read(OLD/"registered.json")
    require(h(OLD/"registered.json")==a["original_registration_sha256"],"old registration changed")
    for name,expected in original["immutable_files"].items():
        require(h(WORK/name)==expected,"old registered input changed: "+name)
    require(not (OLD/"observed").exists() and not (OLD/"grants").exists(),"old study obtained observations/authority")
    original_source=git("show",REL+":"+str(SRC))
    trees=read(HERE/"sources.json")["subjects"]
    old=read(OLD/"sources.json")["subjects"]
    parent=git("rev-parse",REL+"^{tree}").decode().strip()
    first,last=[integrated(AUDIT/name,original_source) for name in ("candidate.patch","candidate-v2.patch")]
    missing=b'paths::read_bytes(first_output.with_extension("d"))'
    require(first.count(missing)==1 and last==first.replace(missing,b'paths::read_bytes(&first_output.with_extension("d"))'),"source difference is not exactly the borrow")
    require(body(first)==body(last)==body((AUDIT/"source-sections.rs").read_bytes()),"isolated matcher differs from integrated source")
    require(trees["base"]==old["base"] and {k:v for k,v in trees["pr269"].items() if k!="patch"}==
            {k:v for k,v in old["pr269"].items() if k!="patch"},"one of the reference sources changed")
    for arm,source in ((old["head"],first),(trees["head"],last)):
        blob=oid(b"blob",source)
        require(blob==arm["blob"] and new_tree(parent,SRC.parts,blob)==arm["tree"] and
                hashlib.sha256(source).hexdigest()==arm["file_sha256"] and h(Path(arm["patch"]))==arm["patch_sha256"],"incorrect integrated Git tree or patch")
    require(trees["head"]["tree"]==a["new_candidate"]["tree"] and old["head"]["tree"]==a["old_candidate"]["tree"],"candidate identity")
    require(h(AUDIT/"candidate-v2.patch")==a["new_candidate"]["patch_sha256"],"corrected patch identity")
    require(h(HERE/"schedules.csv")==h(OLD/"schedules.csv")==a["schedules_sha256"],"assignments changed")
    with (HERE/"schedules.csv").open() as f:
        n=Counter((row["phase"],row["cohort"]) for row in csv.DictReader(f))
    require(dict(n)=={("count","initial"):24,("count","replica"):24,("native","initial"):3456,("native","replica"):960},"sample population changed")
    for name in a["unaltered_design_files"]:
        require((OLD/name).read_bytes()==(HERE/name).read_bytes(),name+" changed")
    for name,expected in a["retained_isolated_evidence"].items():
        require(h(AUDIT/name)==expected,"phase evidence changed: "+name)
    require(h(HERE/"source-review.json")==a["source_review_sha256"],"static review changed")
    for p in HERE.glob("*.py"):
        ast.parse(p.read_text(),filename=str(p))
    if sealed:
        new=read(HERE/"registered.json")
        exempt={"study","sealed_utc_ns","source_trees","immutable_files"}
        require(set(original)==set(new) and all(new[k]==original[k] for k in new.keys()-exempt),"design, gates, counts or original declared circumstances changed")
        require(new["study"]=="ohm18-output-depinfo-whole-command-v2" and new["source_trees"]=={k:v["tree"] for k,v in trees.items()},"wrong study or subjects")
        for name,expected in new["immutable_files"].items():
            require(h(WORK/name)==expected,"successor registered input changed: "+name)
    return {"old_source_bytes":len(first),"new_source_bytes":len(last),"source_difference":"one ASCII ampersand",
            "old_tree":old["head"]["tree"],"new_tree":trees["head"]["tree"],"same_extracted_matcher_sha256":hashlib.sha256(body(last)).hexdigest(),
            "identical_immutable_inputs_in_v1":len(original["immutable_files"]),"native_commands":4*(3456+960),"counted_commands":4*(24+24),
            "no_v1_observations_or_grants":True,"frozen_registration_checked":sealed}

if __name__=="__main__":
    print(json.dumps(verify(),sort_keys=True,indent=2))
