"""Validate full raw custody, raw actual counts and behavioral receipts, then call portable scorer."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import assess
from depcommon import *
import sys
sys.path.insert(0,str(PRIOR))
import study


def all_results(phase,verify_logs=True):
    data={}
    for c in COHORTS:
        out=OUT/phase/c/"sample"
        a=OUT/phase/c/"admission"
        closed=read(out/"closed.json")
        need(closed["mode"]==phase and closed["cohort"]==c and closed["registration_sha256"]==sha(HERE/"registered.json"),
             "wrong closed statistical stage")
        for name,key in (("rows.csv","rows_sha256"),("external.jsonl","external_sha256"),
                         ("postflight.json","postflight_sha256"),("returned.json","returned_sha256")):
            need(sha(out/name)==closed[key],"closed raw evidence changed: "+str(out/name))
        need(closed["admission_sha256"]==sha(a/"admitted.json") and read(a/"returned.json")["equal"] and
             read(out/"returned.json")["equal"] and (out/"external.jsonl").stat().st_size>0 and
             all(not json.loads(l)["external"] for l in (out/"external.jsonl").read_text().splitlines()),
             "failed admission, custody or foreign activity")
        admitted=read(a/"admitted.json")
        rs=assess.read_csv(out/"rows.csv")
        expected=assess.blocks_for(assess.read_csv(HERE/"schedules.csv"),rs,phase,c)
        need(closed["blocks"]==len(expected) and closed["rows"]==len(rs),"missing completed real commands")
        if verify_logs:
            original=(WORK/"uv"/SOURCE).read_bytes()
            for r in rs:
                need(r["source_sha256"]==h(study.changed(original,c,r["literal"])) and
                     r["driver_sha256"]==admitted["drivers"][r["arm"]],"source or physical driver drift")
                dest=out/f'{int(r["block"]):04}-{r["rank"]}-{r["arm"]}'
                rec=dest/("receipt.json" if phase=="native" else "counted.json")
                need(sha(dest/"cargo.log")==r["cargo_log_sha256"] and sha(rec)==r["measure_receipt_sha256"] and
                     sha(dest/"uvx-behavior.json")==r["behavior_sha256"],"raw command, digest or behavior drift")
                need(sha(dest/"drain.json")==r["drain_sha256"] and read(dest/"drain.json")["live_after"]==[],
                     "unverified post-foreground cleanup")
                raw=read(rec)
                behavior=read(dest/"uvx-behavior.json")
                need(behavior["raw_sha256"]==r["elf_sha256"] and behavior["semantic"]==
                     admitted["arms"][r["arm"]]["semantic"],"program is not the current edit")
                if c=="initial":
                    need(behavior["exit"]==2 and behavior["stdout"]=="" and
                         behavior["stderr"].startswith("error: uvx could not launch uv ["+r["literal"]+
                                                       "]: Could not find the `uv` binary at "),
                         "current initial diagnostic was not observed")
                else:
                    need((behavior["exit"],behavior["stdout"],behavior["stderr"])==(0,"tool\nuvx\nfixed-argument\n",""),
                         "wrong forwarded replica program output")
                if phase=="native":
                    need(raw["measured"] and raw["elapsed_ns"]==int(r["elapsed_ns"])>0 and raw["roster"]["tests"]==[] and
                         len(raw["roster"]["compiled"])==1,"wrong foreground timing/roster")
                else:
                    for role in ("cargo","rustc","wild"):
                        [(name,fingerprint)]=raw["role_files"][role].items()
                        need(sha(dest/name)==fingerprint,"raw role trace drift")
                        role_rec=read(dest/name)
                        need(role_rec["instructions"]==sum(role_rec["threads"].values())==
                             raw["totals"][role]==int(r[role])>0,"incorrect user-mode instruction count")
                    need(raw["frontend"]["argv_sha256"]==admitted["arms"][r["arm"]]["argv_sha256"],"wrong uvx compiler args")
        data[c]=rs
    return assess.result(assess.read_csv(HERE/"schedules.csv"),data,phase)
