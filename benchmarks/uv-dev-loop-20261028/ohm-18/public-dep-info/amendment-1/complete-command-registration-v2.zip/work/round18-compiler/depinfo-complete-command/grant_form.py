"""Print the required forms. The physical coordinator separately writes/releases them after inspection."""
import argparse
import os
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from depcommon import *
from run import PHASES

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("phase",choices=PHASES)
    ap.add_argument("key")
    ap.add_argument("--minutes",required=True,type=int)
    a=ap.parse_args()
    need(a.key in PHASES[a.phase] and 0<a.minutes<=720,"wrong release scope/duration")
    reg=sha(HERE/"registered.json")
    label=a.phase+"-"+a.key
    where=LAB/("depinfo-complete-release-"+label+".json")
    boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    release={"study":"ohm18-output-depinfo-whole-command-v1","phase":a.phase,"key":a.key,"boot_id":boot,
             "exclusive":"COORDINATOR verifies true","competing_tools":"COORDINATOR inspects actual empty list",
             "namespaces":{n:os.readlink("/proc/self/ns/"+n) for n in ("user","pid")},
             "uid":os.getuid(),"bench_dev":BENCH.stat().st_dev}
    if a.phase.endswith(("-count","-native")):
        p=OUT/"subjects.json"
        release["subjects_sha256"]=sha(p) if p.is_file() else "MUST ALREADY BE FROZEN"
    now=time.time_ns()
    grant={"study":release["study"],"phase":a.phase,"key":a.key,"registration_sha256":reg,
           "host_boot_id":boot,"cpus":list(range(24,32) if a.phase=="build" else range(16)),
           "release":str(where),"release_sha256":sha(where) if where.is_file() else "SHA OF ACTUAL RELEASE",
           "issued_utc_ns":now,"expires_utc_ns":now+a.minutes*60_000_000_000}
    print(json.dumps({"release_path":str(where),"release_template":release,
                      "grant_path":str(HERE/"grants"/(label+".json")),"grant_template":grant},indent=2))
