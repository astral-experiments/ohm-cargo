"""Portable, standard-library-only scorer for all four-arm blocks. No bench tree access."""
import argparse
import collections
import csv
import json
import math
from pathlib import Path
import statistics

ARMS=("shipped","base","pr269","head")
N={"native":{"initial":3456,"replica":960},"count":{"initial":24,"replica":24}}


def need(ok,why):
    if not ok:
        raise ValueError(why)


def null_weights(n,early,late):
    m=n//2
    tied=n-early-late
    need(n==2*m and min(early,late,tied)>=0,"odd or invalid conditional order stratum")
    counts=collections.defaultdict(int)
    for x in range(max(0,m-late-tied),min(early,m)+1):
        for z in range(max(0,m-x-late),min(tied,m-x)+1):
            y=m-x-z
            wins=x+late-y
            counts[wins]+=math.comb(early,x)*math.comb(late,y)*math.comb(tied,z)
    need(sum(counts.values())==math.comb(n,m),"randomization mass mismatch")
    return dict(counts)


def survival_binomial(n,k):
    return sum(math.comb(n,i) for i in range(k,n+1)),2**n


def tail_result(num,den):
    need(0<=num<=den and den>0,"invalid exact tail")
    return {"p":num/den,"passes_one_sided_025":40*num<=den}


def exact_order(strata,wins):
    masses={0:1}
    for pairs in strata.values():
        # Pair records hold (is_head_earlier, earlier_value, later_value). Ties never add a win.
        n=len(pairs)
        need(sum(x[0] for x in pairs)*2==n,"head order not balanced within each nuisance-arm arrangement")
        weights=null_weights(n,sum(x[1]<x[2] for x in pairs),sum(x[1]>x[2] for x in pairs))
        nxt=collections.defaultdict(int)
        for x,a in masses.items():
            for y,b in weights.items():
                nxt[x+y]+=a*b
        masses=nxt
    return tail_result(sum(v for k,v in masses.items() if k>=wins),sum(masses.values()))


def median_ci(xs):
    data=sorted(xs)
    n=len(data)
    # Central distribution-free two-sided interval with coverage at least 95% (also report all raw data).
    cumulative=0
    k=0
    for i in range(n//2):
        prospective=cumulative+math.comb(n,i)
        if prospective*40>2**n:
            break
        cumulative=prospective
        k+=1
    return [data[max(k-1,0)],data[min(n-k,n-1)]]


def contrast(blocks,control,phase):
    differences=[]
    percentage=[]
    cargo_savings=[]
    strata=collections.defaultdict(list)
    by_order=collections.defaultdict(list)
    for block in blocks:
        h=block["head"]
        c=block[control]
        hr,cr=int(h["rank"]),int(c["rank"])
        val=(lambda r:int(r["elapsed_ns"])) if phase=="native" else (
             lambda r:sum(int(r[s]) for s in ("cargo","rustc","wild")))
        a,b=val(c),val(h)
        need(min(a,b)>0,"missing positive physical observation")
        k=tuple((int(row["rank"]),arm) for arm,row in sorted(block.items()) if arm not in ("head",control))
        strata[k].append((hr<cr,b if hr<cr else a,a if hr<cr else b))
        d=a-b
        differences.append(d)
        percentage.append(100*d/a)
        by_order["head_first" if hr<cr else "head_second"].append(d)
        if phase=="count":
            cargo_savings.append(int(c["cargo"])-int(h["cargo"]))
    n=len(differences)
    need(len(strata)==12 and {len(p) for p in strata.values()}=={n//12},"registered nuisance positions differ")
    wins=sum(d>0 for d in differences)
    raw=tail_result(*survival_binomial(n,wins))
    corrected=exact_order(strata,wins)
    med=statistics.median(differences)
    pct=statistics.median(percentage)
    practical=med>=1_000_000 if phase=="native" else pct>=.1 and statistics.median(cargo_savings)>=1_000_000
    return {"n":n,"wins":wins,"ties":sum(d==0 for d in differences),"median_difference":med,
            "median_difference_95pct":median_ci(differences),"median_percent":pct,"median_percent_95pct":median_ci(percentage),
            "order_medians":{k:statistics.median(v) for k,v in by_order.items()},
            "raw_sign":raw,"conditional_randomization":corrected,"practical_threshold_pass":practical,
            "median_cargo_instructions_saved":statistics.median(cargo_savings) if phase=="count" else None,
            "pass":practical and raw["passes_one_sided_025"] and corrected["passes_one_sided_025"]}


def blocks_for(schedules,rows,phase,cohort):
    expected=[s for s in schedules if (s["phase"],s["cohort"])==(phase,cohort)]
    need(len(expected)==N[phase][cohort] and len(rows)==4*len(expected),"missing or extra observations")
    output=[]
    for i,reg in enumerate(expected):
        need(int(reg["block"])==i,"schedule not in original block order")
        block={}
        for rank,col in enumerate(("first","second","third","fourth"),1):
            r=rows[i*4+rank-1]
            need((r["phase"],r["cohort"],int(r["block"]),int(r["rank"]),r["literal"],r["arm"])==
                 (phase,cohort,i,rank,reg["literal"],reg[col]),"row identity or order mismatch")
            need(r["arm"] not in block and len(r["source_sha256"])==64 and len(r["elf_sha256"])==64,
                 "missing current source or program identity")
            block[r["arm"]]=r
        need(set(block)==set(ARMS) and
             len({(x["source_sha256"],x["source_mtime_ns"],x["elf_sha256"]) for x in block.values()})==1,
             "not the same edit and byte-exact current executable")
        output.append(block)
    return output


def result(schedules,data,phase):
    out={}
    for c in N[phase]:
        b=blocks_for(schedules,data[c],phase,c)
        out[c]={a:contrast(b,a,phase) for a in ARMS if a!="head"}
    return {"phase":phase,"measurement_unit":"nanoseconds" if phase=="native" else "selected user-mode instructions",
            "per_contrast_alpha":.025,"claim":"all three controls in both independent checkouts",
            "contrasts":out,"qualifies":all(x["pass"] for d in out.values() for x in d.values())}


def read_csv(path):
    with Path(path).open() as f:
        return list(csv.DictReader(f))


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("phase",choices=N)
    p.add_argument("schedules",type=Path)
    p.add_argument("initial",type=Path)
    p.add_argument("replica",type=Path)
    args=p.parse_args()
    print(json.dumps(result(read_csv(args.schedules),{c:read_csv(getattr(args,c)) for c in N[args.phase]},args.phase),
                     indent=2,sort_keys=True))
