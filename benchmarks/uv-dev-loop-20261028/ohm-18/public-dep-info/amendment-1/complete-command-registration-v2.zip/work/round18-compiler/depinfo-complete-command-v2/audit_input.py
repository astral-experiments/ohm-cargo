"""Use only old release observations, pinned source bytes and stored layout records. No target reads."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import csv
import json
import statistics
from products import *

out={}
for c in COHORTS:
    cap=LAB/"r18-uvx"/c/"build/admission-shipped"
    [argv]=normal.active_roles(cap)
    q=read(cap/"receipt.json")
    captured=read(cap/"uvx-product.json")
    need(q["roles"]=={"cargo":1,"rustc":1,"wild":1} and
         [a for a in argv if a.startswith("-Zthreads=")]==["-Zthreads=8"] and
         str(SOURCE) in argv and "--test" not in argv and "-Zlink-only" not in argv,
         "historical target check failed")
    old=read(WORK/"upstream-monitor/cargo"/("admission-"+c)/"admitted.json")
    public=old["base"]["all_public_depfiles"]
    structure=read(LAB/"depinfo-source-audit"/(c+"-rejected-build-structural-input-shape.json"))
    need(sorted(public)==public_names() and public==old["candidate"]["all_public_depfiles"] and
         not structure["path_mismatches"],"previous public corpus crosscheck")
    with (LAB/"r18-uvx"/c/"build/timings.csv").open() as f:rows=list(csv.DictReader(f))
    gaps=[int(y["utc_ns"])-int(x["utc_ns"])-int(x["elapsed_ns"]) for x,y in zip(rows,rows[1:])]
    times=[int(r["elapsed_ns"]) for r in rows if r["arm"] in ("base","shipped")]
    sup=read(LAB/"native-series-custody/r18-uvx"/c/"returned.json")["runner"]
    windows=0
    for ep in ("check","build","test"):
        with (LAB/"r18-uvx"/c/ep/"timings.csv").open() as f:ep_rows=list(csv.DictReader(f))
        windows+=int(ep_rows[-1]["utc_ns"])+int(ep_rows[-1]["elapsed_ns"])-int(ep_rows[0]["utc_ns"])
    physical=[json.loads(l) for l in (PRIOR/"observer-v2/observed/direct-count"/c/"build-bin/trial.jsonl").read_text().splitlines()]
    out[c]={"workspace_argv":worker.command("build"),"cwd":str(fixture(c)/"uv"),"native_roles":q["roles"],
            "actual_frontend_argv":argv,"actual_frontend_argv_sha256":h(json.dumps(argv,separators=(",",":")).encode()),
            "original_source_sha256":sha(WORK/"uv"/SOURCE),"source_trace_binding":captured,"previous_cold_warm_log":
            (WORK/"upstream-monitor/cargo"/("warm-"+c)/"warm.log").read_text().splitlines()[-1].strip(),
            "historical_pub_count":len(public),"historical_effectively_traced":["uv.d"],
            "complete_winning_shape_not_yet_traced_all_74":True,"sorted_public_names":sorted(public),
            "structural_path_count":sum(r["published"] for r in structure["roots"].values()),
            "historical_control_mean_ns":int(statistics.mean(times)),"measured_stage_gap_mean_ns":int(statistics.mean(gaps)),
            "original_three_endpoint_fixed_seconds":(sup["finished_ns"]-sup["started_ns"]-windows)/1e9,
            "old_count_semantics":"direct rustc only, for budget context","mean_direct_eight_rustc_only_dbi_foreground_ns":int(statistics.mean(r["elapsed_ns"] for r in physical if r["arm"]=="eight"))}
print(json.dumps(out,sort_keys=True,indent=2))
