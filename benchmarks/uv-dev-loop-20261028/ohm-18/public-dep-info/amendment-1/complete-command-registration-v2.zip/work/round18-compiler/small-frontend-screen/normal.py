"""Drive the normal, unwrapped Cargo command; use the existing released ELF and roster oracles."""
import argparse
import csv
import importlib.util
import signal
import sys
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *
import direct
sys.path.insert(0, str(LAB))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


worker = load("small_frontend_native", LAB/"native-uvx.py")
canon = load("small_frontend_elf_forms", LAB/"native-admitted.py")
canon.raw_artifacts = worker.artifacts
worker.artifacts = canon.artifacts
BASE = WORK / "round18-cargo/fast/bin/base"
BASE_READY = WORK / "round18-cargo/fast/base/ready.json"
PIN = "7caf39914da1e28a67744ecbc963a5f26361474d"


def drivers(grant):
    receipt = HERE/"drivers.json"
    require(grant["drivers_sha256"] and sha(receipt)==grant["drivers_sha256"], "unapproved candidate receipt")
    v = read(receipt)
    require(set(v)=={"cargo_parent","parent_tree","baseline_sha256","head","head_sha256","head_tree",
                     "linked_std_sha256","recipe_sha256","patch","patch_sha256","build_receipt",
                     "build_receipt_sha256"}, "driver receipt schema")
    base = read(BASE_READY)
    require(v["cargo_parent"] == PIN and v["parent_tree"] == base["source_tree"] and
            v["baseline_sha256"] == base["cargo_sha256"] == sha(BASE) and
            v["linked_std_sha256"] == base["std_rlib_sha256"] and
            v["recipe_sha256"] == sha(WORK/"round18-cargo/recipe/build-fast-v2.py"),
            "matched control, Cargo source, recipe, or libstd does not match")
    require(re.fullmatch(r"[0-9a-f]{40,64}",v["head_tree"]) and v["head_tree"] != v["parent_tree"],
            "missing changed source identity")
    head = Path(v["head"])
    patch = Path(v["patch"])
    build = Path(v["build_receipt"])
    require(sha(head)==v["head_sha256"] != sha(BASE) and sha(patch)==v["patch_sha256"] and
            sha(build)==v["build_receipt_sha256"], "unverified source or binary")
    changed_files = re.findall(r"^\+\+\+ b/(.*)$", patch.read_text(), flags=re.M)
    require("src/compiler/mod.rs" in changed_files and set(changed_files) <=
            {"src/compiler/mod.rs","tests/testsuite/rustflags.rs"}, "candidate changes another component")
    proof = read(build)
    for key in ("cargo_parent","parent_tree","head_tree","linked_std_sha256","recipe_sha256","head_sha256","patch_sha256"):
        require(proof[key]==v[key], f"build/source audit mismatch: {key}")
    return {"shipped": DIST/"bin/cargo","base":BASE,"head":head}


def quiet(grant, directory):
    """Same activity limits as the previous native worker, tied to this launch's live grant."""
    cpus = NATIVE_CPUS
    good = 0
    with (directory/"quiet.jsonl").open("x") as raw:
        while good < 2:
            require(time.time_ns() < grant["expires_utc_ns"] and
                    sha(Path(grant["release"])) == grant["release_sha256"], "quiet-window grant expired")
            first = worker.host(cpus)
            time.sleep(5)
            last = worker.host(cpus)
            diff = [b-a for a,b in zip(first["cpu"],last["cpu"])]
            busy = 1-(diff[3]+diff[4])/sum(diff)
            iowait = diff[4]/sum(diff)
            external = worker.foreign()
            clean = busy < .05 and iowait < .02 and last["dirty_kib"] < 65536 and last["writeback_kib"] < 8192
            good = good+1 if clean and not external else 0
            print(json.dumps([last["ts"],busy,iowait,last["dirty_kib"],last["writeback_kib"],external,good]),file=raw,flush=True)


def pool(cohort):
    return fixture(cohort)/"small-frontend-common-v1"


def copy_bank(src, dst):
    require(src.is_dir() and not dst.exists(), "refuse to replace target bank")
    proc = subprocess.Popen(["cp","-a","--reflink=auto","--",str(src),str(dst)],start_new_session=True)
    try:
        while proc.poll() is None:
            assert_floor(6)
            time.sleep(.25)
        require(proc.returncode==0, f"independent target copy failed: {dst}")
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            proc.wait()


def prepare(cohort):
    from score import direct_result
    with authorized("normal-prepare",cohort,62) as grant:
        require(direct_result(True)["eligible"], "direct screen did not replicate")
        require(read(RESULT/"controls"/"done.json")["eligible"], "frozen fixture controls did not qualify")
        source = fixture(cohort)/"r18-four/shipped"
        paths = pool(cohort)
        require(not paths.exists(),"target banks already attempted")
        paths.mkdir()
        stat = source.stat()
        before = {a:sha(p) for a,p in drivers(grant).items()}
        for arm in NORMAL:
            copy_bank(source,paths/arm)
        # Ensure working copies do not share mutable directory or manifest-file inodes.
        witnesses = {}
        for r in (source, *(paths/a for a in NORMAL)):
            p = r/"debug/uvx"
            q = r/"debug/libuv.rlib"
            require(p.is_file() and q.is_file(),f"donor has no settled build outputs: {r}")
            witnesses[str(r)] = {"dir_ino":r.stat().st_ino,"exe_ino":p.stat().st_ino,
                                 "exe_sha":sha(p),"lib_ino":q.stat().st_ino,"lib_sha":sha(q)}
        for prop in ("dir_ino","exe_ino","lib_ino"):
            require(len({w[prop] for w in witnesses.values()})==4, f"writable files alias another donor: {prop}")
        require(len({w["exe_sha"] for w in witnesses.values()})==len({w["lib_sha"] for w in witnesses.values()})==1,
                "different common predecessor bytes")
        save(paths/"ready.json",{"donor":[str(source),stat.st_dev,stat.st_ino],"checks":witnesses,"drivers":before,
                                 "reserve_bytes":shutil.disk_usage(BENCH).free,"registration":sha(HERE/"registration.json")})


def active_roles(directory):
    rows = []
    prefix = "execve("+json.dumps(str(TOOLS/"bin/rustc"))+", "
    for f in sorted(directory.glob("exec.*")):
        for l in f.read_text().splitlines():
            if l.startswith(prefix) and l.endswith("= 0"):
                a,_=json.JSONDecoder().raw_decode(l[len(prefix):])
                require("--crate-name" in a and a[a.index("--crate-name")+1]=="uvx" and str(SOURCE) in a,
                        "unexpected non-uvx frontend on a warm uvx edit")
                rows.append(a)
    return rows


def verify_roles(root, directory, cohort, ep, arm, literal, result):
    args = active_roles(directory)
    expected = {"check":{"cargo":1,"rustc":1},"build":{"cargo":1,"rustc":1,"wild":1},
                "test":{"cargo":1,"rustc":2,"wild":2}}[ep]
    require(result["roles"]==expected and len(result["roster"]["tests"])==(72 if ep=="test" else 0),
            "ordinary Cargo role or full 72-product roster drift")
    require(sorted("--test" in a for a in args)==([False,True] if ep=="test" else [False]), "wrong active targets")
    out = {}
    for a in args:
        role = "harness" if "--test" in a else "binary"
        observed = [s.split("=")[-1] for s in a if s.startswith("-Zthreads=")]
        require(observed == (["8","1"] if ep=="check" or arm=="head" else ["8"]),
                ("actual frontend flags", ep,arm,role,observed))
        normalized = [s for s in a if s != "-Zthreads=1"]
        artifact = Path(a[a.index("--out-dir")+1])
        require(artifact.is_relative_to(root/"target"),"wrong active output root")
        if ep=="check":
            suffix,=[s.split("=",1)[1] for s in a if s.startswith("extra-filename=")]
            chosen = artifact/("libuvx"+suffix+".rmeta")
            d = artifact/("uvx"+suffix+".d")
            require(chosen.is_file() and b"crates/uv/src/bin/uvx.rs" in d.read_bytes(),"wrong check products")
            products = {"rmeta":sha(chosen),"d":sha(d)}
        else:
            suffixes=[s.split("=",1)[1] for s in a if s.startswith("extra-filename=")]
            produced = artifact/("uvx"+(suffixes[0] if suffixes else ""))
            if role=="harness":
                matched=[Path(s.rsplit(" (",1)[1][:-1]) for s in result["roster"]["tests"]
                         if s.rsplit(" (",1)[-1].split("/")[-1].startswith("uvx-")]
                require(len(matched)==1 and sha(matched[0])==sha(produced),"test roster does not name emitted harness")
                listed = subprocess.run([str(produced),"--list"],capture_output=True,timeout=10)
                require((listed.returncode,listed.stdout.strip(),listed.stderr)==(0,b"0 tests, 0 benchmarks",b""),
                        "wrong uvx harness")
                products={"elf":sha(produced),"listed":listed.stdout.decode()}
            else:
                require(sha(produced)==sha(root/"target/debug/uvx"),"active normal binary alias is wrong")
                smoke=behavior(produced,cohort,literal,root)
                products={"elf":smoke["raw_sha256"],"behavior":smoke["semantic"],"exit":smoke["exit"]}
                save(directory/"normal-program.json",smoke)
        out[role]={"effective_flags":observed,"exact_argv_sha256":direct.sha_args(a),
                   "other_argv_sha256":direct.sha_args(normalized),"products":products}
    save(directory/"frontend.json",out)
    return {k:(v["other_argv_sha256"],v["products"]) for k,v in out.items()}


def execute(cohort):
    from score import direct_result
    with authorized("normal-time",cohort,8) as grant:
        require(direct_result(True)["eligible"] and read(RESULT/"controls"/"done.json")["eligible"],
                "complete direct & correctness gates required")
        root = fixture(cohort)
        banks = pool(cohort)
        variants = drivers(grant)
        ready = read(banks/"ready.json")
        require(ready["drivers"]=={a:sha(p) for a,p in variants.items()} and
                ready["registration"]==sha(HERE/"registration.json"),"unregistered banks or drivers")
        out = RESULT/"normal"/cohort
        require(not out.exists(),"single-shot native cohort already attempted")
        out.mkdir(parents=True)
        slot = TOOLS/"bin/cargo"
        official = ROOT/"official-original-cargo"
        source = root/"uv"/SOURCE
        lockfile = root/"uv/Cargo.lock"
        seed = banks/"original-target"
        original = ORIGINAL.read_bytes()
        stamp = source.stat()
        locksha = sha(lockfile)
        require(source.read_bytes()==original and not seed.exists() and slot.samefile(official) and
                (TOOLS/LINK).samefile(ROOT/"official-original-wild") and sha(slot)==sha(DIST/"bin/cargo"),
                "unrestored checkout, private slot or target")
        copies = {}
        for name,path in variants.items():
            dest=banks/("driver-"+name)
            shutil.copy2(path,dest)
            require(sha(dest)==sha(path),"staged driver changed")
            copies[name]=dest
        def edit(literal):
            data=changed(original,cohort,literal)
            source.write_bytes(data)
            return hbytes(data)
        @contextlib.contextmanager
        def use(arm):
            active = root/"target"
            held = banks/arm
            require(not active.exists() and held.is_dir(),"parked target ownership")
            held.rename(active)
            try:
                worker.select(copies[arm],slot)
                yield
            finally:
                active.rename(held)
        def one(arm,ep,where,literal,*,trace=False,measure=False,settle=False):
            with use(arm):
                res=worker.run_command(root,ep,where,NATIVE_CPUS,trace=trace,measure=measure,settle=settle)
                exposure=verify_roles(root,where,cohort,ep,arm,literal,res) if trace else None
            return res,exposure
        schedule = read(HERE/"schedule.json")["normal"][cohort]
        original_ino=(root/"target").stat().st_ino
        (root/"target").rename(seed)
        try:
            save(out/"inputs.json",{"grant":grant,"registration_sha256":sha(HERE/"registration.json"),
                                     "arms":{k:sha(v) for k,v in copies.items()},"lock":locksha,
                                     "commands":{ep:worker.command(ep) for ep in ("check",*ENDPOINTS)},
                                     "released_rustc":sha(TOOLS/"bin/rustc"),"released_wild":sha(TOOLS/LINK)})
            order=("check","build","test") if cohort=="initial" else ("check","test","build")
            for ep in order:
                cell=out/ep
                cell.mkdir()
                def audit(name, block):
                    literal=tag(cohort,ep,block)
                    digest=edit(literal)
                    full={}
                    exposures={}
                    for arm in NORMAL:
                        got,exposures[arm]=one(arm,ep,cell/(name+"-"+arm),literal,trace=True)
                        full[arm]={k:got[k] for k in ("roster","roles","outputs")}
                    for values in (list(full.values()),list(exposures.values())):
                        require(all(x==values[0] for x in values),"cross-arm role, argv or product mismatch")
                    return {"source_sha256":digest,"arms":full}
                first=tag(cohort,ep,990)
                edit(first)
                for arm in NORMAL:
                    one(arm,ep,cell/("settle-"+arm),first,settle=True)
                registered=audit("admission",991)
                save(cell/"admitted.json",registered)
                if ep=="check":
                    save(cell/"unchanged.json",audit("post",999))
                    continue
                quiet(grant,cell)
                cols=("block","rank","arm","literal","source_sha256","elapsed_ns","utc_ns","seconds_user","seconds_system",
                      "voluntary_switches","involuntary_switches","input_blocks","output_blocks","major_faults","minor_faults")
                with (cell/"timings.csv").open("x",newline="",buffering=1) as csvfile, (cell/"external.jsonl").open("x",buffering=1) as external:
                    wr=csv.DictWriter(csvfile,fieldnames=cols)
                    wr.writeheader()
                    for i,ordering in enumerate(schedule[ep]):
                        assert_floor(3)
                        require(time.time_ns()<grant["expires_utc_ns"] and sha(Path(grant["release"]))==grant["release_sha256"],
                                "authority expired mid-schedule; preserve all rows")
                        literal=tag(cohort,ep,i)
                        digest=edit(literal)
                        for rank,arm in enumerate(ordering):
                            res,_=one(arm,ep,cell/f"m{i:03}-{rank}-{arm}",literal,measure=True)
                            require(res["roster"]==registered["arms"][arm]["roster"],"measured roster drift")
                            wr.writerow({**{k:res[k] for k in cols if k in res},"block":i,"rank":rank,"arm":arm,
                                         "literal":literal,"source_sha256":digest})
                            print(json.dumps([i,rank,arm,worker.foreign(),worker.host(NATIVE_CPUS),
                                              Path("/proc/pressure/cpu").read_text()]),file=external)
                closed=audit("post",999)
                save(cell/"done.json",{"rows":sha(cell/"timings.csv"),"post":closed})
        finally:
            require(not (root/"target").exists(),"active target remains, preserve journal")
            seed.rename(root/"target")
            worker.select(official,slot)
            source.write_bytes(original)
            os.utime(source,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
            require(slot.samefile(official) and locksha==sha(lockfile) and sha(source)==sha(ORIGINAL) and
                    (root/"target").stat().st_ino==original_ino,"original target/checkout/slot failed to return")
            save(out/"returned.json",{"source_sha256":sha(source),"source_mtime_ns":source.stat().st_mtime_ns,
                                     "lock_sha256":locksha,"original_target_ino":original_ino,
                                     "banks":{k:(banks/k).stat().st_ino for k in NORMAL},"cargo_sha256":sha(slot)})


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("prepare","time"))
    p.add_argument("cohort",choices=COHORTS)
    a=p.parse_args()
    (prepare if a.action=="prepare" else execute)(a.cohort)
