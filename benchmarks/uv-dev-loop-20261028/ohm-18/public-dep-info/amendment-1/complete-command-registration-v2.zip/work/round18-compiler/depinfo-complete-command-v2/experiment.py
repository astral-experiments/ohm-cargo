"""Hard admissions, two disjoint four-arm families, and the ordinary unwrapped wall timer."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import csv
import threading
from banks import *
from design import COHORTS as NS


def ordered(mode,cohort):
    with (HERE/"schedules.csv").open() as stream:
        seq=[r for r in csv.DictReader(stream) if (r["phase"],r["cohort"])==(mode,cohort)]
    n=24 if mode=="count" else NS[cohort]
    need(len(seq)==n and list(range(n))==[int(r["block"]) for r in seq],"incomplete registration")
    return seq


def admission(mode,cohort):
    root,pool=banks(mode,cohort)
    bins=local_bins(pool)
    out=OUT/mode/cohort/"admission"
    need(not out.exists(),"existing admission or exclusion")
    out.mkdir()
    prefix="I" if cohort=="initial" else "R"
    regen=prefix+"Q010"
    role=prefix+"Q012"
    reset=prefix+"Q011"
    accepted={}
    with session(root,pool,out,cohort):
        for arm in ARMS:
            d=out/arm
            d.mkdir()
            with active(root,pool,arm,bins[arm]):
                public=public_admit(root,d,cohort,regen,pool/("saved-public-"+arm))
                signal_edit(root,cohort,role)
                plain=native_roles(root,d/"unwrapped",cohort,role)
                match={"public":public,"products":plain["products"],"unchanged_raw":plain["unchanged_raw"],"argv_sha256":plain["frontend"]["argv_sha256"],
                       "elf":plain["frontend"]["elf_sha256"],"source":plain["source_sha256"],
                       "semantic":plain["behavior"]["semantic"]}
                if mode=="count":
                    for label,wmode in (("wrapper-native","native"),("actual-dbi","count")):
                        signal_edit(root,cohort,reset)
                        wrapped(root,pool,d/(label+"-reset"),"native")
                        signal_edit(root,cohort,role)
                        observed=wrapped(root,pool,d/label,wmode,admit=wmode=="native")
                        behavior=study.behavior(root/"target/debug/uvx",cohort,role,root)
                        need(observed["frontend"]==plain["frontend"] and
                             behavior["semantic"]==match["semantic"] and hashes(depfiles(root))==public and
                             observed["roster"]==plain["roster"],"wrapper/DBI changed current uvx or admitted output")
                        save(d/(label+"-correspondence.json"),{"native_receipt_sha256":sha(d/"unwrapped/admitted.json"),
                            "instrumented_receipt_sha256":sha(d/label/"counted.json"),"behavior":behavior,
                            "active_frontend_and_output_equal":True})
                accepted[arm]=match
        need(all(m==accepted["shipped"] for m in accepted.values()),"cross-arm source, argv, 74 depfiles or products differ")
        save(out/"admitted.json",{"mode":mode,"cohort":cohort,"drivers":{a:sha(bins[a]) for a in ARMS},"arms":accepted,
             "expected_roster":{"cargo":1,"rustc":1,"wild":1},"all_74_opened_written_read":True})
    need(read(out/"returned.json")["equal"],"admission custody failed")


def current_stage(phase,cohort):
    return OUT/phase/cohort/"sample"


def before_count_or_wall(mode,cohort):
    for c in COHORTS if mode=="native" else (cohort,):
        a=OUT/mode/c/"admission"
        if mode=="native" and not a.exists():
            # Each independent cohort is physically seeded, admitted and retired sequentially.
            # Both count cohorts must already have physically qualified; we never need two four-bank pools.
            if c != cohort:
                continue
        need(read(a/"admitted.json")["all_74_opened_written_read"] and read(a/"returned.json")["equal"],
             "missing hard corpus admission")
    if mode=="native":
        from rescore import all_results
        result=all_results("count",verify_logs=True)
        need(result["qualifies"],"count gate failed; no wall commands authorized")


def foreign_observer(out,stop,detected):
    me=os.getppid()  # The unique launch supervisor also owns reparented linker cleanup.
    def ours(pid):
        seen=set()
        while pid>1 and pid not in seen:
            if pid==me: return True
            seen.add(pid)
            try:
                stat=Path(f"/proc/{pid}/stat").read_text().rsplit(")",1)[1].split()
                pid=int(stat[1])
            except (FileNotFoundError,ProcessLookupError): return None
        return False
    with (out/"external.jsonl").open("x") as log:
        while True:
            observed=[(pid,name,ours(pid)) for pid,name in worker.foreign()]
            outside=[r for r in observed if r[2] is False]
            log.write(json.dumps({"time_ns":time.time_ns(),"observed":observed,"external":outside})+chr(10))
            log.flush()
            if outside:
                detected.extend(outside)
            if stop.wait(2):
                return


def drain_owned(out):
    from run import descendants
    parent=os.getppid()
    worker_pid=os.getpid()
    start=time.monotonic_ns()
    samples=0
    while True:
        all_pids=descendants(parent)
        live={p:v for p,v in all_pids.items() if p!=worker_pid and v[0] not in ("Z","X")}
        samples+=1
        if not live:
            break
        need(time.monotonic_ns()-start<45_000_000_000,"late live descendant after foreground returned")
        time.sleep(.01)
    data={"worker":worker_pid,"supervisor":parent,"live_after":[],"polls":samples,
          "drain_ns":time.monotonic_ns()-start,"remaining_zombies":[p for p,v in all_pids.items() if v[0] in ("Z","X")]}
    save(out/"drain.json",data)
    return sha(out/"drain.json")


def sample(mode,cohort,g):
    before_count_or_wall(mode,cohort)
    root,pool=banks(mode,cohort)
    bins=local_bins(pool)
    out=current_stage(mode,cohort)
    need(not out.exists(),"no repeated or resumed statistical stage")
    out.mkdir()
    admitted=read(OUT/mode/cohort/"admission/admitted.json")
    assignments=ordered(mode,cohort)
    manifest=admitted["arms"]["shipped"]
    with session(root,pool,out,cohort):
        if mode=="native":
            normal.quiet(g,out)
        stop=threading.Event()
        exterior=[]
        observer=threading.Thread(target=foreign_observer,args=(out,stop,exterior),daemon=True)
        observer.start()
        prior={}
        try:
            with (out/"rows.csv").open("x") as sink:
                fields=("phase","cohort","block","rank","arm","literal","source_sha256","source_mtime_ns",
                        "driver_sha256","elapsed_ns","cargo","rustc","wild","elf_sha256",
                        "cargo_log_sha256","measure_receipt_sha256","behavior_sha256","drain_sha256")
                w=csv.DictWriter(sink,fieldnames=fields,lineterminator=chr(10))
                w.writeheader()
                sink.flush()
                for block in assignments:
                    need(not exterior and observer.is_alive(),"external process or observer failure; retain all prior rows")
                    n=int(block["block"])
                    literal=block["literal"]
                    src=signal_edit(root,cohort,literal)
                    stamp=(root/"uv"/SOURCE).stat().st_mtime_ns
                    winners=[]
                    for rank,col in enumerate(("first","second","third","fourth"),1):
                        arm=block[col]
                        dest=out/f"{n:04}-{rank}-{arm}"
                        need(stamp>prior.get(arm,-1),"source clock did not progress on an arm")
                        prior[arm]=stamp
                        with active(root,pool,arm,bins[arm]):
                            if mode=="native":
                                raw=worker.run_command(root,"build",dest,list(range(16)),measure=True)
                                receipt=dest/"receipt.json"
                                timed=raw["elapsed_ns"]
                                totals={}
                            else:
                                raw=wrapped(root,pool,dest,"count")
                                receipt=dest/"counted.json"
                                need(raw["frontend"]["argv_sha256"]==manifest["argv_sha256"],"counted frontend role changed")
                                timed=""
                                totals=raw["totals"]
                            drained=drain_owned(dest)
                            current=study.behavior(root/"target/debug/uvx",cohort,literal,root)
                            save(dest/"uvx-behavior.json",current)
                            winners.append((current["raw_sha256"],current["semantic"]))
                            rec=dict(phase=mode,cohort=cohort,block=n,rank=rank,arm=arm,literal=literal,
                                     source_sha256=src,source_mtime_ns=stamp,driver_sha256=admitted["drivers"][arm],
                                     elapsed_ns=timed,elf_sha256=current["raw_sha256"],cargo_log_sha256=sha(dest/"cargo.log"),
                                     measure_receipt_sha256=sha(receipt),behavior_sha256=sha(dest/"uvx-behavior.json"),drain_sha256=drained,
                                     **{r:totals.get(r,"") for r in ("cargo","rustc","wild")})
                            w.writerow(rec)
                            sink.flush()
                    need(len(set(winners))==1,"four-arm current-ELF or behavior mismatch")
            # Same genuine edit after each arm's last native/count row, with all 74 files present.
            final=("I" if cohort=="initial" else "R")+"Z888"
            post={}
            for arm in ARMS:
                with active(root,pool,arm,bins[arm]):
                    signal_edit(root,cohort,final)
                    d=out/("post-"+arm)
                    d.mkdir()
                    trace_public(root,d/"all-present","read")
                    need(hashes(depfiles(root))==manifest["public"],"postflight public byte drift")
                    signal_edit(root,cohort,final[:2]+"889")
                    q=native_roles(root,d/"unwrapped",cohort,final[:2]+"889")
                    need(q["unchanged_raw"]==manifest["unchanged_raw"],"previously fresh library or uv program changed raw bytes")
                    post[arm]={"public":hashes(q["public"]),"products":q["products"],"unchanged_raw":q["unchanged_raw"],"frontend":q["frontend"],
                               "behavior":q["behavior"]["semantic"]}
            need(all(x==post["shipped"] for x in post.values()),"postflight current products/role inequivalence")
            need(not exterior and observer.is_alive(),"foreign tool or lost observer during the registered run")
            save(out/"postflight.json",post)
        finally:
            stop.set()
            observer.join(10)
        need(not observer.is_alive() and not exterior,"activity failure during closure")
    need(read(out/"returned.json")["equal"],"stage custody failure")
    save(out/"closed.json",{"cohort":cohort,"mode":mode,"blocks":len(assignments),"rows":4*len(assignments),
                 "rows_sha256":sha(out/"rows.csv"),"postflight_sha256":sha(out/"postflight.json"),
                 "external_sha256":sha(out/"external.jsonl"),"returned_sha256":sha(out/"returned.json"),
                 "admission_sha256":sha(OUT/mode/cohort/"admission/admitted.json"),
                 "registration_sha256":sha(HERE/"registered.json"),"guards_sha256":guards()})


def local_bins(pool):
    bins=variants()
    for a,source in bins.items():
        staged=pool/("driver-"+a)
        need(staged.is_file() and sha(staged)==sha(source),"staged driver drift")
    return {a:pool/("driver-"+a) for a in bins}
