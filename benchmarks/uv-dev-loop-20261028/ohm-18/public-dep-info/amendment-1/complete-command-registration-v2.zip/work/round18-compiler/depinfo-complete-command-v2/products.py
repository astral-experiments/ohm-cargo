"""Require actual Cargo accesses to all 74 public make depfiles and a current executable."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import ast
import collections
import importlib.util
import subprocess
import sys
from depcommon import *

sys.path.insert(0,str(PRIOR))
import normal
import study
worker = normal.worker


def public_names():
    a=read(LAB/"depinfo-source-audit/initial-rejected-build-structural-input-shape.json")["roots"]
    b=read(LAB/"depinfo-source-audit/replica-rejected-build-structural-input-shape.json")["roots"]
    names=sorted(a)
    need(len(names)==74 and sorted(b)==names and all(Path(n).name==n and n.endswith(".d") for n in names),
         "public products differ from the two frozen structural datasets")
    return names


def depfiles(root):
    debug=root/"target/debug"
    paths={p.name:p for p in debug.glob("*.d")}
    need(sorted(paths)==public_names() and all(p.is_file() and not p.is_symlink() for p in paths.values()),
         "all and only the 74 public regular depfiles must exist")
    return {n:{"sha256":sha(p),"bytes":p.stat().st_size,"mtime_ns":p.stat().st_mtime_ns} for n,p in paths.items()}


def hashes(snapshot):
    return {n:v["sha256"] for n,v in snapshot.items()}


def trace_accesses(lines, root, names, action):
    debug=root/"target/debug"
    selected={}
    pattern=r'openat(?:2)?\(AT_FDCWD, ("(?:\\.|[^"\\])*"), (.*?)\)\s*=\s*(\d+)'
    for raw in lines:
        match=re.search(pattern,raw)
        if not match:
            continue
        path=Path(ast.literal_eval(match[1]))
        if path.parent!=debug or path.name not in names:
            continue
        flags=match[2]
        if action=="read" and "O_RDONLY" in flags or action=="write" and ("O_WRONLY" in flags or "O_RDWR" in flags):
            selected.setdefault(path.name,[]).append(raw.rstrip())
    need(set(selected)==set(names), f"missing {action} opens in Cargo: {sorted(set(names)-set(selected))}")
    return selected


def trace_public(root,out,action):
    # strace's path filter drops execve. Tracing just this root PID's thread group (no -f) binds
    # these opens to actual Cargo; the companion independent exec -ff admission binds the tools.
    names=public_names()
    out.mkdir()
    paths=[str(root/"target/debug"/n) for n in names]
    argv=["strace","-qq","-s","4096","-e","trace=openat,openat2"]
    argv += [token for p in paths for token in ("-P",p)]
    argv += ["-o",str(out/"public-open.trace"),*worker.command("build")]
    with (out/"cargo.log").open("x") as log:
        p=subprocess.run(argv,cwd=root/"uv",env=worker.env(root),stdout=log,stderr=subprocess.STDOUT)
    need(p.returncode==0 and worker.rosters((out/"cargo.log").read_text())["tests"]==[],"all-public trace run failed")
    selected=trace_accesses((out/"public-open.trace").read_text().splitlines(),root,names,action)
    save(out/"observed.json",{"argv":argv,"trace_sha256":sha(out/"public-open.trace"),
                             "successful_cargo_open_lines":selected,"cargo_log_sha256":sha(out/"cargo.log")})
    return selected


def signal_edit(root,cohort,literal):
    source=root/"uv"/SOURCE
    before=(WORK/"uv"/SOURCE).read_bytes()
    data=study.changed(before,cohort,literal)
    source.write_bytes(data)
    need(source.read_bytes()==data,"edit not durable")
    return h(data)


def exact_frontend(argv,root):
    need(argv.count("--crate-name")==1 and argv[argv.index("--crate-name")+1]=="uvx" and
         argv.count("--crate-type")==1 and argv[argv.index("--crate-type")+1]=="bin" and
         any(a.endswith(str(SOURCE)) for a in argv) and "--test" not in argv and
         "-Zlink-only" not in argv and [x for x in argv if x.startswith("-Zthreads=")]==["-Zthreads=8"],
         "wrong actual release uvx source-backed build role")
    output=Path(argv[argv.index("--out-dir")+1])
    suffix=[a.split("=",1)[1] for a in argv if a.startswith("extra-filename=")]
    need(len(suffix)<=1 and output.is_relative_to(root/"target"), "escaped active output")
    produced=output/("uvx"+(suffix[0] if suffix else ""))
    alias=root/"target/debug/uvx"
    need(produced.is_file() and alias.is_file() and sha(produced)==sha(alias),"original rustc output and public ELF differ")
    return {"rustc_argv":argv,"argv_sha256":h(json.dumps(argv,separators=(",",":")).encode()),
            "produced":str(produced),"alias":str(alias),"elf_sha256":sha(alias)}


def traced_argv(directory,path):
    exp="execve("+json.dumps(str(path))+", "
    rows=[]
    for f in directory.glob("exec.*"):
        for l in f.read_text(errors="strict").splitlines():
            if l.startswith(exp) and l.endswith("= 0"):
                argv,_=json.JSONDecoder().raw_decode(l[len(exp):])
                rows.append(argv)
    need(len(rows)==1,"expected exactly one native invocation for "+str(path))
    return rows[0]


def native_roles(root,out,cohort,literal):
    raw=worker.run_command(root,"build",out,list(range(16)),trace=True)
    need(raw["roles"]=={"cargo":1,"rustc":1,"wild":1},"changed native cargo/rustc/wild roster")
    active=normal.active_roles(out)
    need(len(active)==1,"ordinary uvx binary must be the sole compile")
    product=exact_frontend(active[0],root)
    cargo=traced_argv(out,ROOT/"tools/bin/cargo")
    wild=traced_argv(out,ROOT/"tools"/LINK)
    need(cargo==worker.command("build") and wild.count("-o")==1 and wild[wild.index("-o")+1]==product["produced"],
         "real Cargo arguments or Wild output differ from the source-backed uvx unit")
    raw_unchanged={name:sha(root/"target/debug"/name) for name in ("uv","libuv.rlib")}
    smoke=study.behavior(root/"target/debug/uvx",cohort,literal,root)
    value={"roles":raw["roles"],"roster":raw["roster"],"frontend":product,"public":depfiles(root),
           "products":raw["outputs"],"unchanged_raw":raw_unchanged,"cargo_argv":cargo,"wild_argv":wild,"behavior":smoke,"literal":literal,"source_sha256":sha(root/"uv"/SOURCE)}
    save(out/"admitted.json",value)
    return value


def public_admit(root,dest,cohort,token,stash):
    source=root/"uv"/SOURCE
    original=depfiles(root)
    # On our disposable bank only. Original aliases are retained in the receipt directory on the same filesystem.
    need(not stash.exists(),"depfile stash already exists")
    stash.mkdir()
    for name in original:
        (root/"target/debug"/name).rename(stash/name)
    signal_edit(root,cohort,token)
    trace_public(root,dest/"regenerated","write")
    new=depfiles(root)
    need(hashes(new)==hashes(original),"regeneration changed any of the 74 public byte strings")
    warm=token[:2]+f"{int(token[2:])+1:03}"
    signal_edit(root,cohort,warm)
    trace_public(root,dest/"all-present","read")
    final=depfiles(root)
    need(new==final,"warm output bytes or some public mtime changed despite identical paths")
    # Return old aliases to this disposable arm only after keeping the full prior bytes, identities and new values.
    for name,info in original.items():
        need(sha(stash/name)==info["sha256"],"saved public bytes drifted")
    receipt={"source_sha256":sha(source),"old":original,"recreated":new,"untouched_warm":final,
             "stash_path":str(stash),"opened":74,"regenerated":74,"compiler_from_companion_admission":True}
    save(dest/"public-admission.json",receipt)
    return hashes(final)
