#!/usr/bin/env python3
"""Prepare independent release-18 Cargo source snapshots and a private, source-equipped toolchain."""
import hashlib, json, os, shutil, stat, subprocess
from pathlib import Path

D = Path(__file__).resolve().parents[1]
W = D.parent
B = Path((W / 'bench-home.path').read_text().strip()) / 'round18-cargo'
MON = W / 'upstream-monitor'; OLD = MON / 'cargo'; OFFICIAL = MON / 'toolchain18'
CARGO = '7caf39914da1e28a67744ecbc963a5f26361474d'; RUST = 'a4fa11bcd38280639cb94daacc125472657db6c3'
UV = 'c22e6b71933443e9cd299d4b6ac8de035ed4825b'
HOST = 'x86_64-unknown-linux-gnu'; RELEASE = 'ohm-1.99.0-18'
PATCHES = [264, 267, 268, 269, 270]

def digest(f):
    with f.open('rb') as h:return hashlib.file_digest(h, 'sha256').hexdigest()

def tree(p):
    def git(typ, data):return hashlib.sha1(typ+b' '+str(len(data)).encode()+b'\0'+data).digest()
    def walk(d):
        children=[]
        for item in d.iterdir():
            if d == p and item.name == 'git-commit-info': continue
            if item.is_symlink(): mode, value, key = b'120000', git(b'blob', os.fsencode(os.readlink(item))), os.fsencode(item.name)
            elif item.is_dir(): mode, value, key = b'40000', walk(item), os.fsencode(item.name)+b'/'
            else:
                mode=b'100755' if item.stat().st_mode & 0o111 else b'100644'; value=git(b'blob',item.read_bytes()); key=os.fsencode(item.name)
            children.append((key,mode+b' '+os.fsencode(item.name)+b'\0'+value))
        return git(b'tree',b''.join(v for _,v in sorted(children)))
    return walk(p).hex()

def main():
    assert set(os.sched_getaffinity(0)) <= set(range(16,32))
    B.mkdir(mode=0o700); inputs=D/'inputs';inputs.mkdir(); intended=json.loads((OLD/'depfile-plan.json').read_text())
    shutil.copy2(OLD/'base-7caf399.tar.gz',inputs/'cargo.tar.gz'); assert digest(inputs/'cargo.tar.gz')==intended['source_archive_sha256']
    for n in PATCHES:
        shutil.copy2(OLD/f'patches/{n}.patch',inputs/f'{n}.patch');assert digest(inputs/f'{n}.patch')==intended['patch_sha256'][str(n)]
    shutil.copy2(MON/'rust/247.diff',inputs/'247.patch')
    hdr=[l for l in (inputs/'247.patch').read_text().splitlines() if l.startswith('diff --git ')];assert len(hdr)==2 and any('/std/src/path.rs ' in l for l in hdr)
    src=B/'sources';src.mkdir(); base=src/'base';base.mkdir(); subprocess.run(['tar','-xzf',inputs/'cargo.tar.gz','--strip-components=1','-C',base],check=True)
    subprocess.run(['cp','-a','--reflink=auto',base,src/'guard-stack'],check=True)
    for n in PATCHES:
        with (inputs/f'{n}.patch').open('rb') as f:subprocess.run(['git','apply','--whitespace=error-all','-'],stdin=f,cwd=src/'guard-stack',check=True)
    trees={a:tree(src/a) for a in ['base','guard-stack']}; assert trees['base']!=trees['guard-stack']
    metadata=CARGO+'\n'+CARGO[:9]+'\n2026-10-28\n'
    for arm in trees:(src/arm/'git-commit-info').write_text(metadata)
    prefix=B/'toolchain';subprocess.run(['cp','-al',OFFICIAL,prefix],check=True)
    libdir=prefix/'lib/rustlib/src/rust';libdir.mkdir(parents=True)
    full=MON/'download18'/f'rust-1.99.0-dev-{HOST}'/'rust-src/lib/rustlib/src/rust/library'
    subprocess.run(['cp','-a','--reflink=auto',full,libdir/'library'],check=True)
    assert CARGO in subprocess.check_output([prefix/'bin/cargo','-Vv'],text=True) and RUST in subprocess.check_output([prefix/'bin/rustc','-Vv'],text=True)
    assert subprocess.check_output([prefix/'bin/rustc','--print','sysroot'],text=True).strip()==str(prefix)
    std_base=digest(full/'std/src/path.rs'); test_base=digest(full/'std/tests/path.rs')
    guarded=B/'guarded-std';guarded.mkdir();subprocess.run(['cp','-a','--reflink=auto',full,guarded/'library'],check=True)
    with (inputs/'247.patch').open('rb') as f:subprocess.run(['git','apply','--whitespace=error-all','-'],stdin=f,cwd=guarded,check=True)
    guardsha=digest(guarded/'library/std/src/path.rs'); gtest=digest(guarded/'library/std/tests/path.rs');assert guardsha!=std_base and test_base!=gtest
    seed=B/'registry-seed';seed.mkdir(mode=0o700);subprocess.run(['cp','-a','--reflink=auto',W/'pgo-confirmation-v2/build-home/registry',seed/'registry'],check=True)
    stmt={'source':str(src),'scratch':str(B),'toolchain':str(prefix),'release_toolchain':str(OFFICIAL),'cargo_pin':CARGO,'rust_pin':RUST,'uv_pin':UV,'release':RELEASE,'archive_sha256':intended['distribution_archive_sha256'],'cargo_source_archive_sha256':digest(inputs/'cargo.tar.gz'),'cargo_trees':trees,'cargo_drafts':PATCHES,'cargo_patch_sha256':{str(n):digest(inputs/f'{n}.patch') for n in PATCHES},'rust_pr':247,'rust_patch_sha256':digest(inputs/'247.patch'),'std_path_sha256':{'base':std_base,'guard-stack':guardsha},'std_path_test_sha256':{'base':test_base,'guard-stack':gtest},'cargo_hash':digest(prefix/'bin/cargo'),'rustc_hash':digest(prefix/'bin/rustc'),'build_registry':str(seed),'training_registry':str(W/'pgo-confirmation-v2/seed-home'),'materials':str(W/'pgo-materials')}
    (D/'inputs.json').write_text(json.dumps(stmt,indent=2)+'\n'); print('inputs ready',json.dumps(trees),flush=True)
if __name__=='__main__':main()
