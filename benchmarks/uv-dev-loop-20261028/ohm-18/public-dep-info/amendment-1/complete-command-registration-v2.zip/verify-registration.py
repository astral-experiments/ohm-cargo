import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
w=r/'work'
plans=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for dirname,digest in [('depinfo-complete-command', 'a833e97451fb2e702ab1b345d6271854c2cb80c08bd8777aebf2024b049606e1'), ('depinfo-complete-command-v2', 'c5fdaa3d2f9fd771be67d462e80d0c96303e1326d61d7d22654f876d5cecd1f7')]:
    p=w/'round18-compiler'/dirname/'registered.json'
    assert sha(p)==digest
    v=json.loads(p.read_bytes())
    for n,h in v['immutable_files'].items():
        x=(w/n).resolve(strict=True)
        assert x.is_relative_to(r) and sha(x)==h,n
    plans.append(v)
assert all(plans[0][k]==plans[1][k] for k in ('uv', 'cargo_parent', 'rust_parent', 'known_binary_sha256', 'endpoint', 'native_affinity', 'pgo_affinity', 'ordinary_source', 'edits', 'normal_blocks', 'normal_commands', 'count_blocks_per_cohort', 'count_commands', 'order', 'gates', 'selected_power_estimate_six_way_union_lower_bound', 'unselected_bounded_option', 'storage', 'initial_states'))
print('Verified both registrations, their original inputs and identical statistical design.')
