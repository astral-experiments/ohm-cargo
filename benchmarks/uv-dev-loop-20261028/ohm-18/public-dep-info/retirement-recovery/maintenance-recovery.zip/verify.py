"""Offline maintenance-packet replay; never consult a recorded absolute path, actual SDK or /proc."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
WORK=ROOT/"work"
R=WORK/"round18-compiler/depinfo-complete-command-v3-retire-recovery"
V=R.with_name("depinfo-complete-command-v3")
L=WORK/"round18-lab"
D=L/"depinfo-v3-segment-receipts/drivers"
ORIGINAL="/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work"
V3="5fa7f3456fe8a3c5f002602c4bd71dc0a059ec1f2651ee4913e36c1e4ac53e1c"
REPAIR="7aa1f5899a0a46012905e979d32823fb0d028bc6a5d7a5b6ee75735d39b52929"
OLD_FAILURE="e421a5625d283d9b08d29f645dd8d4879552a45f8ea9cac1e2076921e86464e6"
SCHEDULE="87a652621d50050459b7ec05bb05faa392323635a5bf2caa3f7ea0047857fbfb"
SOURCE="624b9843cb3ebde395bf37f6e86e6023b14d8171"
def need(x,msg):
    if not x:raise ValueError(msg)
def h(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def js(p):return json.loads(p.read_bytes())
def map_path(raw):
    p=PurePosixPath(raw)
    need(p.is_relative_to(ORIGINAL) and ".." not in p.parts,"unknown absolute source path")
    return WORK / p.relative_to(ORIGINAL)
def check_file(p,s):
    need(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT) and h(p)==s,"wrong packet file "+str(p.relative_to(ROOT)))
def split_seal():
    manifest=js(ROOT/"manifest.json")
    for name,record in manifest["files"].items():
        p=ROOT/name
        check_file(p,record["sha256"]);need(p.stat().st_size==record["bytes"],"size changed")
    check_file(V/"registered.json",V3);check_file(R/"registered.json",V3);check_file(R/"recovery.json",REPAIR)
    for k,v in js(R/"recovery.json")["frozen_files"].items():check_file(WORK/k,v)
    pp=js(R/"preserved-inputs.json")
    for k,v in pp.items():check_file(WORK/k,v)
    check_file(D/"failure.json",OLD_FAILURE)
    return len(manifest["files"]),len(pp)
def schedule():
    v=js(V/"registered.json");f=V/"schedules.csv"
    check_file(f,SCHEDULE);need(v["source_trees"]=={k:a["tree"] for k,a in js(V/"sources.json")["subjects"].items()},"subject trees changed")
    check_file(V/"assess.py",v["immutable_files"]["round18-compiler/depinfo-complete-command-v3/assess.py"])
    need(v["normal_blocks"]=={"initial":3456,"replica":960} and v["count_blocks_per_cohort"]==24 and
         v["normal_commands"]==17664 and v["count_commands"]==192 and v["gates"]["no_interim_sign_stopping"],"population or gate changed")
    for k,digest in v["immutable_files"].items():
        p=WORK/k
        if p.is_file() and p.resolve().is_relative_to(WORK):check_file(p,digest)
    with f.open() as stream:rows=list(csv.DictReader(stream))
    need(len(rows)==4464,"missing order blocks")
    for phase in ("native","count"):
        for co in ("initial","replica"):
            subset=[r for r in rows if (r["phase"],r["cohort"])==(phase,co)]
            orders=collections.Counter(tuple(r[k] for k in ("first","second","third","fourth")) for r in subset)
            n=v["normal_blocks"][co] if phase=="native" else 24
            need(len(subset)==n and list(range(n))==[int(r["block"]) for r in subset] and
                 len(orders)==24 and set(orders.values())=={n//24} and len({r["literal"] for r in subset})==n,"changed assignments")
            if phase=="native":
                banks=js(V/"bank-design.json")[co]
                cells=collections.Counter((a,b) for order,m in orders.items() for _ in range(m) for a,b in zip(order,banks))
                need(len(cells)==16 and set(cells.values())=={n//4},"physical bank balance changed")
    return v
def prefix(v):
    frozen=js(D/"failure.json");intake=js(D/"intake.json");outer=js(L/"depinfo-driver-retirement-root-audit.json")
    need((outer["session"],outer["chunk"],outer["exit"])==(83431,"b235d8",1) and outer["before_retirement_manifest_absent"] and
         not (D/"returned.json").exists() and list((p["phase"],p["key"],p["exit"]) for p in frozen["phases"])==
         [("build","pr269",0),("audit","pr269",0),("retire-pgo","pr269",1)],"refused attempt or completed prefix changed")
    before=intake["previous_return"];before_sha=intake["previous_return_sha256"];check_file(map_path(before),before_sha)
    for row in frozen["phases"]:
        label=row["phase"]+"-"+row["key"]
        need(row==js(D/(label+".json")),"outer phase row drift")
        check_file(D/(label+".log"),row["log_sha256"])
        physical=map_path(row["physical_file"]);check_file(physical,row["physical_sha256"])
        dest=physical.parent
        r=js(physical);g=V/"grants"/(label+".json");check_file(g,r["grant_sha256"])
        data=js(g);release=map_path(data["release"]);check_file(release,data["release_sha256"])
        own=js(dest/"owner.json");child=js(dest/"launched.json");c=js(release)
        need(r["worker_exit"]==row["exit"] and r["final_owned"]=={} and r["minimum_free"]>=120*2**30 and
             own["parent_pid"]==child["parent"]==row["supervisor_pid"] and child["worker"]==child["pid_session"] and
             data["registration_sha256"]==frozen["registration_sha256"]==V3 and
             (c["previous_return"],c["previous_return_sha256"])==(before,before_sha) and
             own["coordinator_release"]==h(release) and own["grant_sha256"]==row["grant_sha256"]==h(g),"physical prefix not linked")
        check_file(dest/"process.log",r["process_sha256"])
        before,before_sha=row["physical_file"],row["physical_sha256"]
    need(before_sha==outer["worker_return_sha256"],"root saw a different terminal worker")
    trace=(map_path(before).parent/"process.log").read_text()
    need("unused(dirs.values())" in trace and "Permission denied: '/proc/2262570/fd'" in trace,"wrong refusal")
    src=(V/"retire.py").read_text().split("def pgo_targets(arm):",1)[1]
    need(src.index("unused(dirs.values())")<src.index('save(out/"retirement-before.json"')<src.index("path.rename(scratch)"),"unexpected destructive branch")
    d=V/"observed/drivers/pr269";req=js(d/"candidate-request.json");verified=js(d/"verified.json");audit=verified["audit"]
    need(verified["arm"]=="pr269" and verified["request_sha256"]==h(d/"candidate-request.json") and
         verified["input_sha256"]==h(d/"input.json") and verified["builder_adapter_sha256"]==h(V/"drivers.py") and
         req["source_tree"]==audit["source_tree"]==v["source_trees"]["pr269"] and req["patch_sha256"]==audit["patch_sha256"] and
         audit["uv_training_commands"]==0 and len(audit["training_commands"])==len(audit["raw_profiles"])==24,"PGO audit changed")
    build=js(map_path(req["audit"]));use=js(map_path(req["profile_use_receipt"]));commands=[json.loads(x) for x in map_path(req["commands"]).read_text().splitlines()]
    starts=[Path(x["log"]).name for x in commands if "start" in x]
    ends=[x for x in commands if "finish" in x]
    need(len(starts)==len(ends)==41 and len({d["log"] for d in audit["training_commands"]})==24 and
         all(d["log"] in starts for d in audit["training_commands"]) and all(x["status"]==0 for x in ends),
         "PGO commands no longer support the independently recorded training")
    need(build["cargo_sha256"]==audit["head_sha256"]==outer["control_driver"] and
         build["profdata_sha256"]==audit["head_profile_sha256"]==use["sha256"] and build["std_rlib_sha256"]==audit["std_sha256"] and
         audit["base_sha256"]==v["known_binary_sha256"]["matched_pgo_base"] and
         req["host_rustc_sha256"]==v["known_binary_sha256"]["shipped_rustc"],"driver/profile/linked std mismatch")
    ownership=js(d/"owned-reproducible.json");probe=js(R/"readonly-actual.json")
    need(ownership["children"]==probe["owned_directories"] and ownership["build_request_sha256"]==h(d/"candidate-request.json") and
         probe["reaudited_predelete"] and probe["real_host_return"]["exit"]==0 and probe["scan"]["complete"] and probe["scan"]["checked_live"]==20,
         "original bank identity not preserved")
    zs=probe["scan"]["confirmed_terminal"]
    need(len(zs)==2 and {z["pid"] for z in zs}=={2262570,3008171} and all(z["pid"]==z["tgid"] and z["tasks"]==[z["pid"]] and
         z["threads"]==1 and z["state"] in ("Z","X") and z["disposition"]=="twice-verified single terminal thread" for z in zs),
         "retention relied on a live or unconfirmed thread")
    return {"control_sha256":audit["head_sha256"],"profile_sha256":audit["head_profile_sha256"],"verified_raw_profiles":24,
            "original_retirement_supervisor":{"session":83431,"chunk":"b235d8","exit":1},"control_build_and_audit_exit":[0,0],
            "predelete_original_inodes":ownership["children"],"genuine_reader_control":{"live":20,"terminal":2}}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("--published-v3",type=Path);args=ap.parse_args()
    members,retained=split_seal();v=schedule();out=prefix(v)
    publication=js(L/"depinfo-bank-design-published.json")
    need(publication["commit"]==SOURCE and publication["blobs"]["public-dep-info/amendment-2/segment.py"]["sha256"]==h(L/"depinfo-segment-v3.proposed.py"),"wrong published predecessor")
    pub=publication["blobs"]["public-dep-info/amendment-2/complete-command-registration-v3.zip"]
    if args.published_v3:
        blob=args.published_v3.read_bytes()
        need(hashlib.sha256(blob).hexdigest()==pub["sha256"] and len(blob)==pub["byteSize"] and
             hashlib.sha1(b"blob "+str(len(blob)).encode()+b"\0"+blob).hexdigest()==pub["oid"],"incorrect published v3 archive")
        with zipfile.ZipFile(args.published_v3) as z:
            need(any(name.endswith("/registered.json") or name=="registered.json" for name in z.namelist()) and
                 any(z.read(name)==(V/"registered.json").read_bytes() for name in z.namelist() if name.endswith("registered.json")),
                 "registration missing from published archive")
    # These two read-only commands load only the extracted Python and receipts. The synthetic test
    # uses in-memory authorizations and empty temporary fixture directories.
    coord=L/"depinfo-segment-v3-retire-recovery.py"
    seal=json.loads(subprocess.check_output([sys.executable,"-I","-B",str(coord),"--verify-recovery"],cwd=ROOT))
    tests=subprocess.check_output([sys.executable,"-I","-B",str(coord),"--self-test"],cwd=ROOT)
    need(seal["recovery_sha256"]==REPAIR and tests==(R/"selftest.json").read_bytes(),"detached synthetic replay mismatch")
    out.update(recovery_sha256=REPAIR,v3_sha256=V3,schedule_sha256=SCHEDULE,packed_members=members,
               original_evidence_files=retained,native_population=17664,count_population=192,actual_new_scored_rows=0,
               synthetic_accepted=15,synthetic_rejected=24,published_v3_checked=bool(args.published_v3))
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=="__main__":main()
