"""Produce the separately named coordinator from the fixed original without modifying its bytes."""
from pathlib import Path
import hashlib

here=Path(__file__).resolve().parent
lab=here.parents[1]/"round18-lab"
old=lab/"depinfo-segment-v3.proposed.py"
target=lab/"depinfo-segment-v3-retire-recovery.py"
s=old.read_text()
assert hashlib.sha256(old.read_bytes()).hexdigest()=="62b171555d8db3b739ce48a73cd51b234c9e0e82c988b32c16a179009d9db641"

def one(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)

one('bench = Path((work/"bench-home.path").read_text().strip())','''repair_root=study.with_name("depinfo-complete-command-v3-retire-recovery")
sys.path.insert(0,str(repair_root))
import custody as repair
bench = Path((work/"bench-home.path").read_text().strip())''')
one('segments=("drivers","count-initial"', 'segments=("retire-control","head-driver","functional","count-initial"')
one('receipts=lab/"depinfo-v3-segment-receipts"', 'receipts=lab/"depinfo-v3-retire-recovery-segments"')
one('''    if segment=="drivers":
        return [(phase,arm,45 if phase=="build" else 15) for arm in ("pr269","head")
                for phase in ("build","audit","retire-pgo")]+[("functional","all",15)]''','''    if segment=="retire-control":return [("retire-pgo","pr269",15)]
    if segment=="head-driver":return [("build","head",45),("audit","head",15),("retire-pgo","head",15)]
    if segment=="functional":return [("functional","all",15)]''')
one('''    return lab/("depinfo-complete-release-v3-"+label+".json"),study/"grants"/(label+".json"),observed/"physical"/label''','''    if (phase,key)==("retire-pgo","pr269"):
        return (lab/("depinfo-complete-release-v3-reader-resume-"+label+".json"),
                repair_root/"grants"/(label+".json"),repair_root/"observed/physical"/label)
    return lab/("depinfo-complete-release-v3-"+label+".json"),study/"grants"/(label+".json"),observed/"physical"/label''')
one('"depinfo-complete-command-v3/run.py",','"depinfo-complete-command-v3/run.py","depinfo-complete-command-v3-retire-recovery/retirement_runner.py",')
one('''    return out

def segment_return(name):''','''    if repair.is_retirement(phase):
        closure=read(d/"reader-closure.json")
        expected_roots=repair.reader_roots(phase,key)
        last=(d/"process.log").read_text().splitlines()
        require(last and last[-1]=="DEPINFO_RETIRE_READER_CLOSURE "+sha(d/"reader-closure.json"),
                "raw returned worker log did not seal those reader observations")
        require(r["retirement_recovery_sha256"]==repair.reg() and r["preserved_failed_return_sha256"]==repair.ORIG_RETURN and
                closure["recovery_sha256"]==repair.reg() and closure["original_retire_sha256"]==sha(study/"retire.py") and
                closure["source_sha256"]==sha(repair_root/"retirement_runner.py"),"missing exact corrected reader evidence")
        require(len(closure["calls"])==(4 if phase=="retire-pgo" else 1),"missing per-target reader scans")
        for i,h in enumerate(closure["calls"],1):
            p=d/f"reader-{i:02}.json";checkfile(p,h);x=read(p)
            repair.validate_reader_report(x["scan"])
            require(x["roots"]==expected_roots[i-1],"scanner observed other physical roots")
            require(x["scan"]["complete"] is True and x["phase"]==phase and x["key"]==key and
                    x["call"]==i and x["grant_sha256"]==sha(grant),"reader census was incomplete or detached")
        if (phase,key)==("retire-pgo","pr269"):
            require(read(d/"prior-owned-before.json")["children"]==repair.OWNED,"corrected retirement used other directories")
    return out

def segment_return(name):''')
one('''    result={}
    for p,kind,key in peers():''','''    result={repair.ROOT_RECEIPT:read(repair.ROOT_RECEIPT)["utc_ns"]}
    for p,kind,key in peers():''')
one('''    if matches:
        stamp=peer_return''','''    if p==repair.ROOT_RECEIPT:
        require(digest==repair.WITNESS,"different failed intake")
        stamp=read(p)["utc_ns"]
    elif matches:
        stamp=peer_return''')
one('''    require(isinstance(session,int) and session>0 and isinstance(chunk,str) and
            re.fullmatch(r"[0-9a-f]{6}",chunk) and type(exit_code) is int and exit_code==0,''','''    require(isinstance(session,int) and session>0 and isinstance(chunk,str) and
            re.fullmatch(r"[0-9a-f]{6}",chunk) and type(exit_code) is int and
            (exit_code==0 or (session,chunk,exit_code)==(83431,"b235d8",1)),''')
a=s.index('    done={(p,k) for s in prior for p,k,_ in phases(s)}');b=s.index('    return prior',a)
s=s[:a]+'''    require({p.name for p in (lab/"depinfo-v3-segment-receipts").iterdir()}=={"drivers"} and
            not (lab/"depinfo-v3-segment-receipts/drivers/returned.json").exists(),
            "a different original full-driver segment appeared or was rewritten")
    done={(p,k) for s in prior for p,k,_ in phases(s)}
    scopes={(p,k) for s in segments for p,k,_ in phases(s)}
    for phase,key in scopes:
        present=tuple(p.exists() or p.is_symlink() for p in physical_paths(phase,key))
        require(present==((phase,key) in done,)*3,"premature, absent or unreturned corrected scope: "+phase+" "+key)
    # Three immutable original attempts include the failed retirement. Its second attempt belongs
    # only to the recovery folder. The old grant, failure and supervision records stay untouched.
    expected={study/"grants":set(),observed/"physical":set(),repair_root/"grants":set(),repair_root/"observed/physical":set(),lab:set()}
    for phase,key in repair.OLD_SCOPES:
        label=phase+"-"+key
        expected[study/"grants"].add(label+".json");expected[observed/"physical"].add(label)
        expected[lab].add("depinfo-complete-release-v3-"+label+".json")
    for p,k in done:
        r,g,d=physical_paths(p,k)
        expected[lab].add(r.name);expected[g.parent].add(g.name);expected[d.parent].add(d.name)
    for folder,names in expected.items():
        prefix="depinfo-complete-release-*.json" if folder==lab else "*"
        require({v.name for v in folder.glob(prefix)}==names,"outstanding or missing original/recovery scope under "+str(folder))
''' +s[b:]
one('''    release,grant,_=physical_paths(phase,key)
    require(Path(result["release_path"])==release''','''    release,grant,_=physical_paths(phase,key)
    if (phase,key)==("retire-pgo","pr269"):
        label=phase+"-"+key
        require(Path(result["release_path"])==lab/("depinfo-complete-release-v3-"+label+".json") and
                Path(result["grant_path"])==study/"grants"/(label+".json"),"unexpected original single-use grant")
        result["release_path"]=str(release);result["grant_path"]=str(grant)
        result["grant_template"]["release"]=str(release)
    if repair.is_retirement(phase):
        result["release_template"].update(retirement_recovery_sha256=repair.reg(),
                  preserved_failed_return_sha256=repair.ORIG_RETURN,retirement_scanner_sha256=sha(repair_root/"safe_unused.py"))
    require(Path(result["release_path"])==release''')
one('''    verify()
    provenance=''', '''    verify()
    repair.verify_seal()
    require((a.previous.absolute()==repair.ROOT_RECEIPT)==
            ((a.previous_session,a.previous_chunk,a.previous_exit)==(83431,"b235d8",1)),
            "only the exact refused cleanup may use that nonzero tool return")
    provenance=''')
one('''            prior=expected_progress(a.segment)
''','''            prior=expected_progress(a.segment)
            if a.segment=="retire-control":repair.validate_predelete()
''')
one('''            if a.segment!="drivers":''','''            if a.segment not in ("retire-control","head-driver","functional"):''')
one('''        history={"segment":a.segment,''','''        history={"retirement_recovery_sha256":repair.reg(),"original_failed_segment_sha256":repair.FOLD,"segment":a.segment,''')
one('''                args=["taskset","-c",mask,sys.executable,"-I","-B",str(study/"run.py"),phase,key]''','''                runner=repair_root/"retirement_runner.py" if repair.is_retirement(phase) else study/"run.py"
                args=["taskset","-c",mask,sys.executable,"-I","-B",str(runner),phase,key]''')
one('''    require(v["segment"]==name and v["physical_returned"] is True''','''    require(v["retirement_recovery_sha256"]==repair.reg() and v["original_failed_segment_sha256"]==repair.FOLD and
            v["segment"]==name and v["physical_returned"] is True''')
one('''        require(row==read(d/(label+".json")) and row["phase"]==phase''','''        candidate=repair_root/"retirement_runner.py" if repair.is_retirement(phase) else study/"run.py"
        require(row["args"]==["taskset","-c","24-31" if phase=="build" else "0-15",sys.executable,"-I","-B",str(candidate),phase,key],
                "wrong physical entrypoint or arguments")
        require(row==read(d/(label+".json")) and row["phase"]==phase''')
# Keep the predecessor’s synthetic test unmodified in its own source. This successor has different intermediate phases.
a=s.index('def selftest():');b=s.index('def main():',a)
s=s[:a]+'''def selftest():
    import runpy
    return runpy.run_path(str(repair_root/"selftest.py"),run_name="__main__")

'''+s[b:]
one('    if sys.argv[1:]==["--self-test"]:','''    if sys.argv[1:]==["--verify-recovery"]:
        repair.verify_seal()
        print(json.dumps({"recovery_sha256":repair.reg(),"original_failed_segment_sha256":repair.FOLD,
                          "supervisor":[83431,"b235d8",1],"eligible_segments":list(segments)},indent=2))
        return
    if sys.argv[1:]==["--verify-predelete"]:
        repair.verify_seal()
        print(json.dumps(repair.validate_predelete(),indent=2))
        return
    if sys.argv[1:]==["--self-test"]:''')
if __name__=="__main__":
    if (here/"recovery.json").exists():assert target.read_text()==s
    else:target.write_text(s)
