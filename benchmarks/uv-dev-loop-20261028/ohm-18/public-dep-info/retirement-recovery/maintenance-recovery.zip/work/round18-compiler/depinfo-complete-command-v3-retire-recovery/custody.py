"""Immutable prefix and ownership checks for the one qualified recovery; no compiler work."""
from pathlib import Path
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
STUDY=HERE.with_name("depinfo-complete-command-v3")
WORK=HERE.parents[1]
LAB=WORK/"round18-lab"
LEGACY=LAB/"depinfo-segment-v3.proposed.py"
COORD=LAB/"depinfo-segment-v3-retire-recovery.py"
OLD=LAB/"depinfo-v3-segment-receipts/drivers"
ROOT_RECEIPT=LAB/"depinfo-driver-retirement-root-audit.json"
V3="5fa7f3456fe8a3c5f002602c4bd71dc0a059ec1f2651ee4913e36c1e4ac53e1c"
FOLD="e421a5625d283d9b08d29f645dd8d4879552a45f8ea9cac1e2076921e86464e6"
ORIG_RETURN="f1447589c7e8492249a1474e38786eb7c6b9d3c80e57111127ed83e481a50abb"
WITNESS="8fb5df342921768842f84cbf4e27add878404f264a5fd76345ed67143b47fadf"
OWNED={"generate.target":[64769,43797036],"training-target":[64769,43819964],"use.target":[64769,43821808]}
OLD_SCOPES=(("build","pr269"),("audit","pr269"),("retire-pgo","pr269"))
def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def read(p):
    return json.loads(p.read_bytes())
def require(ok,why):
    if not ok:raise ValueError(why)
def check(p,expected):
    require(p.is_file() and not p.is_symlink() and p.resolve()==p.absolute() and sha(p)==expected,"changed frozen source/evidence: "+str(p))
def scope(phase,key):
    return HERE if (phase,key)==("retire-pgo","pr269") else STUDY
def is_retirement(phase):
    return phase in ("retire-pgo","retire-count","retire-native")
def reg():
    return sha(HERE/"recovery.json")
def verify_seal():
    s=read(HERE/"recovery.json")
    require(s["original_registration_sha256"]==V3 and s["original_failure_sha256"]==FOLD and
            s["original_supervisor"]=={"session":83431,"chunk":"b235d8","exit":1},"wrong recovery registration")
    for name,digest in s["frozen_files"].items():check(WORK/name,digest)
    for name,digest in read(HERE/"preserved-inputs.json").items():check(WORK/name,digest)
    frozen=read(OLD/"failure.json");r=read(ROOT_RECEIPT)
    require(sha(OLD/"failure.json")==FOLD and sha(ROOT_RECEIPT)==WITNESS and
            r["session"]==83431 and r["chunk"]=="b235d8" and r["exit"]==1 and r["worker_return_sha256"]==ORIG_RETURN,
            "not the original root-inspected exit")
    require([(x["phase"],x["key"],x["exit"]) for x in frozen["phases"]]==[("build","pr269",0),("audit","pr269",0),("retire-pgo","pr269",1)] and
            not os.path.lexists(OLD/"returned.json") and frozen["coordinator_sha256"]==sha(LEGACY) and
            frozen["registration_sha256"]==sha(STUDY/"registered.json")==V3,
            "original scientific or physical prefix changed")
    for row in frozen["phases"]:
        label=row["phase"]+"-"+row["key"]
        p=STUDY/"observed/physical"/label/"returned.json"
        v=read(p)
        require(row==read(OLD/(label+".json")) and row["physical_sha256"]==sha(p) and
                v["final_owned"]=={} and v["worker_exit"]==row["exit"] and v["grant_sha256"]==row["grant_sha256"],
                "original per-phase physical result changed")
    return s
def validate_predelete():
    d=STUDY/"observed/drivers/pr269"
    ownership=read(d/"owned-reproducible.json")
    root=Path(ownership["record"])
    require(root==WORK/"round18-cargo/pgo/depinfo-complete-command-v3-pr269/records/head" and
            ownership["children"]==OWNED and ownership["record_inode"]==[64769,43787562],"different original ownership")
    require(not any(os.path.lexists(d/f) for f in ("retirement-before.json","retired-targets.json")),"failed retirement was not pre-delete")
    for path,ident in [(root,ownership["record_inode"])]+[(root/k,v) for k,v in OWNED.items()]:
        st=path.lstat()
        require(path.is_dir() and not path.is_symlink() and path.absolute()==path.resolve() and st.st_uid==os.getuid() and
                [st.st_dev,st.st_ino]==ident and not os.path.lexists(path.with_name(path.name+".retirement-in-progress")),"directory moved since the preserved pre-delete exit")
    return {"record":str(root),"record_inode":ownership["record_inode"],"children":OWNED}

def validate_reader_report(scan):
    require(scan["complete"] is True and scan["scope"]=="all process groups with the invoking uid in their UID quartet" and
            type(scan["checked_live"]) is int and scan["checked_live"]>=0 and type(scan["raced_reaped"]) is int and
            scan["raced_reaped"]>=0,"incomplete reader controls")
    for item in scan["confirmed_terminal"]:
        if item["disposition"]=="reaped":
            require(set(item)=={"pid","start","disposition"} and item["pid"]>0 and item["start"]>=0,"invalid reaped identity")
        else:
            require(item["disposition"]=="twice-verified single terminal thread" and item["state"] in ("Z","X") and
                    item["pid"]==item["tgid"] and item["threads"]==1 and item["tasks"]==[item["pid"]] and
                    item["pid"]>0 and item["start"]>=0 and len(item["uids"])==4 and os.getuid() in item["uids"],
                    "a live, multiple-thread or unverified process was skipped")

def reader_roots(phase,key):
    if phase=="retire-pgo":
        owned=read(STUDY/"observed/drivers"/key/"owned-reproducible.json")
        root=Path(owned["record"])
        keys=list(owned["children"])
        require(set(keys)=={"generate.target","use.target","training-target"},"unexpected generated root roster")
        return [[{"path":str(root/n),"identity":owned["children"][n]} for n in keys]]+[
            [{"path":str(root/(n+".retirement-in-progress")),"identity":owned["children"][n]}] for n in keys]
    mode=phase.removeprefix("retire-")
    cohort=STUDY/"observed"/mode/key
    owned=read(cohort/"prepare/prepared.json")["bank_inodes"]
    root=Path(read(cohort/"sample/returned.json")["before"]["root"])/("depinfo-complete-"+mode+"-v3")
    names=("shipped","base","pr269","head")
    require(set(owned)==set(names),"unregistered bank roster for retirement")
    return [[{"path":str(root/n),"identity":owned[n]} for n in names]]
