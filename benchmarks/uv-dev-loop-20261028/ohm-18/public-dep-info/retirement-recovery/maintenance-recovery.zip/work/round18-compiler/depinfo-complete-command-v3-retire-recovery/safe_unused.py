"""Fail-closed read-only retirement scan. No process arguments or unrelated pathname is logged."""
import errno
import os
from pathlib import Path

TERMINAL = ("Z","X")
VANISHED = (FileNotFoundError,ProcessLookupError)

def fail(condition, reason):
    if not condition: raise RuntimeError(reason)

def live_info(proc):
    parts=(proc/"stat").read_text().rsplit(")",1)[1].split()
    status={}
    with (proc/"status").open() as f:
        for line in f:
            key,_,value=line.partition(":")
            if key in ("Uid","Tgid","Threads"):status[key]=value.split()
    return {"pid":int(proc.name),"start":int(parts[19]),"state":parts[0],
            "uids":[int(v) for v in status["Uid"]],"tgid":int(status["Tgid"][0]),"threads":int(status["Threads"][0])}

def safe_terminal(proc, original, inspect=live_info):
    """An inaccessible live leader or a zombie leader with living siblings cannot be skipped."""
    try:
        first=inspect(proc)
        tasks=sorted(int(p.name) for p in (proc/"task").iterdir())
        last=inspect(proc)
    except VANISHED:
        # Never turn an absent individual Linux file, or an immediately reused PID, into a reaping receipt.
        if not os.path.lexists(proc):return {"pid":original["pid"],"start":original["start"],"disposition":"reaped"}
        raise
    valid=(len(original["uids"])==4 and first==last and first["pid"]==first["tgid"]==original["pid"]
           and first["start"]==original["start"] and first["uids"]==original["uids"]
           and first["state"] in TERMINAL and first["threads"]==1 and tasks==[first["pid"]])
    fail(valid,f"uninspectable live, changing or multi-thread process: pid {original['pid']}")
    return {**first,"tasks":tasks,"disposition":"twice-verified single terminal thread"}

def read_links(proc, expected):
    def check(link,is_fd):
        try:
            text=os.readlink(link).removesuffix(" (deleted)")
        except VANISHED:
            if is_fd:return
            raise
        ref=Path(text)
        fail(not any(ref==p or p in ref.parents for p in expected),f"live pid {proc.name} refers to an owned target")
    # Inspect every live task, including processes whose leader does not share its fd table or cwd.
    for entry in (proc/"task").iterdir():
        try:
            for suffix in ("cwd","root","exe"):check(entry/suffix,False)
            for fd in (entry/"fd").iterdir():check(fd,True)
        except VANISHED:
            if not os.path.lexists(entry):continue
            raise
    # Reading a mapped object may outlive its fd. Only the membership result is retained.
    encoded=[os.fsencode(p) for p in expected]
    with (proc/"maps").open("rb") as maps:
        for line in maps:
            value=line.split(None,5)
            if len(value)<6 or not value[5].startswith(b"/"):continue
            mapped=value[5].rstrip(b"\n").removesuffix(b" (deleted)")
            fail(not any(mapped==p or mapped.startswith(p+b"/") for p in encoded),f"live pid {proc.name} maps an owned target")

def scan(paths, proc_root=Path("/proc"), uid=None, inspect=live_info, readers=read_links):
    expected=[Path(p).resolve(strict=True) for p in paths]
    fail(expected and all(p.is_dir() for p in expected),"retirement scan requires real original directories")
    uid=os.getuid() if uid is None else uid
    report={"complete":False,"scope":"all process groups with the invoking uid in their UID quartet",
            "checked_live":0,"confirmed_terminal":[],"raced_reaped":0}
    try:
        for proc in proc_root.glob("[0-9]*"):
            try:prior=inspect(proc)
            except VANISHED:
                if not os.path.lexists(proc):continue
                raise
            if uid not in prior["uids"]:continue
            try:
                if prior["state"] in TERMINAL:
                    report["confirmed_terminal"].append(safe_terminal(proc,prior,inspect))
                    continue
                readers(proc,expected)
                final=inspect(proc)
                fail(final["start"]==prior["start"] and final["uids"]==prior["uids"],
                     f"pid changed generation or credentials during retirement scan: {proc.name}")
                report["checked_live"]+=1
            except VANISHED:
                if not os.path.lexists(proc):
                    report["raced_reaped"]+=1
                else:
                    report["confirmed_terminal"].append(safe_terminal(proc,prior,inspect))
            except PermissionError:
                report["confirmed_terminal"].append(safe_terminal(proc,prior,inspect))
        report["complete"]=True
        return report
    except BaseException as exc:
        # The caller writes the decision outside the generated targets, before allowing any removal.
        exc.retirement_scan={**report,"retained":True,"error_type":type(exc).__name__,"blocked_pid":proc.name if "proc" in locals() else None}
        raise
