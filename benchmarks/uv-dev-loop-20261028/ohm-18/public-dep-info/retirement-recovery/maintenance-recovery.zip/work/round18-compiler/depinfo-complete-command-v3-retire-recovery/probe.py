"""Read only the named process's public identity, task count and fd-directory accessibility."""
import errno
import json
import os
from pathlib import Path

def on_host():
    if Path("/proc/1/comm").read_text().strip()!="systemd":
        raise RuntimeError("genuine guest PID namespace required")
    root=Path("/proc/2262570")
    result={"pid":2262570,"guest_pid1":"systemd"}
    try:
        st=(root/"stat").read_text().rsplit(")",1)[1].split()
        labels={k:v.strip() for k,v in (s.split(":",1) for s in (root/"status").read_text().splitlines() if ":" in s) if k in ("Uid","Threads","Name","Tgid")}
        result.update(state=st[0],start_ticks=int(st[19]),uid=list(map(int,labels["Uid"].split())),
                      threads=int(labels["Threads"]),tgid=int(labels["Tgid"]),name=labels["Name"])
        try:
            with os.scandir(root/"fd") as it: next(it,None)
            result["fd_directory"]="accessible"
        except PermissionError as e:
            result["fd_directory"]="denied";result["fd_errno"]=e.errno
        now=(root/"stat").read_text().rsplit(")",1)[1].split()
        result["rechecked_state"]=now[0];result["same_start"]=int(now[19])==result["start_ticks"]
        try:
            result["task_ids"]=[int(p.name) for p in (root/"task").iterdir()]
        except PermissionError:
            result["task_list"]="denied"
    except (FileNotFoundError,ProcessLookupError):
        result["observed"]="already reaped during probe"
    print(json.dumps(result,sort_keys=True))

if __name__=="__main__":on_host()
