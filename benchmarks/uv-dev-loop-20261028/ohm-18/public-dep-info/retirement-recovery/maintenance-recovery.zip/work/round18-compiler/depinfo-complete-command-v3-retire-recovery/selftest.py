"""Offline process, custody, grant and compound-stage checks; no subject process is run."""
import collections
import copy
import csv
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest import mock

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import custody
import safe_unused as guard
import retirement_runner as runner

def module(path):
    spec=importlib.util.spec_from_file_location("resource_recovery_coord",path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj

def main():
    c=module(custody.COORD)
    rejected=[];accepted=[]
    def negative(name,f):
        try:f()
        except (RuntimeError,ValueError,PermissionError,FileNotFoundError,AssertionError,KeyError):
            rejected.append(name);return
        raise RuntimeError("invalid input was accepted: "+name)
    def good(name,state):
        if not state:raise RuntimeError(name)
        accepted.append(name)
    with tempfile.TemporaryDirectory() as td:
        temp=Path(td)
        proc=temp/"proc";proc.mkdir()
        bank=temp/"owned bank";bank.mkdir()
        elsewhere=temp/"unrelated";elsewhere.mkdir()
        pid=proc/"501";pid.mkdir()
        t=pid/"task/501";t.mkdir(parents=True)
        for name in ("root","cwd","exe"):(t/name).symlink_to(elsewhere)
        fds=t/"fd";fds.mkdir()
        uid=os.getuid()
        def state(s,threads=1,ticks=571):
            (pid/"stat").write_text("501 (fixture process) "+" ".join([s]+["0"]*18+[str(ticks)]+["0"]*24))
            (pid/"status").write_text(f"Tgid:\t501\nUid:\t{uid}\t{uid}\t{uid}\t{uid}\nThreads:\t{threads}\n")
        state("S");(pid/"maps").write_bytes(b"")
        run=lambda:guard.scan([bank],proc)
        good("unrelated live process accepted",run()["checked_live"]==1)
        (fds/"7").symlink_to(bank/"product")
        negative("live fd under target",run);(fds/"7").unlink()
        (t/"cwd").unlink();(t/"cwd").symlink_to(bank)
        negative("live working directory under target",run);(t/"cwd").unlink();(t/"cwd").symlink_to(elsewhere)
        (pid/"maps").write_bytes(b"0000-0100 r--p 0000 00:00 0 "+os.fsencode(bank/"raw archive.a")+b" (deleted)\n")
        negative("active mapped file after fd close",run);(pid/"maps").write_bytes(b"")
        deny=lambda *_:(_ for _ in ()).throw(PermissionError(13,"synthetic"))
        negative("arbitrary inaccessible living process",lambda:guard.scan([bank],proc,readers=deny))
        state("Z")
        val=guard.scan([bank],proc,readers=deny)
        custody.validate_reader_report(val)
        good("twice-observed one-thread zombie",len(val["confirmed_terminal"])==1)
        state("X");good("confirmed dead X",guard.scan([bank],proc)["confirmed_terminal"][0]["state"]=="X")
        state("Z",threads=2);(pid/"task/502").mkdir()
        negative("zombie leader with a living sibling",run)
        (pid/"task/502").rmdir();state("Z",threads=1)
        old=guard.live_info(pid)
        negative("PID reused under a different start tick",lambda:guard.safe_terminal(pid,{**old,"start":572}))
        with mock.patch.object(guard,"live_info"):
            alt=iter([old,{**old,"state":"S"}])
            negative("terminal identity changed during second read",lambda:guard.safe_terminal(pid,old,lambda _:next(alt)))
        (pid/"task/777").mkdir();negative("a second task conflicts with Threads:1",run);(pid/"task/777").rmdir()
        for key,value in (("threads",2),("state","S"),("tasks",[501,700]),("tgid",777)):
            fake=copy.deepcopy(val);fake["confirmed_terminal"][0][key]=value
            negative("tampered "+key+" in nominal success",lambda:custody.validate_reader_report(fake))
        fake=copy.deepcopy(val);fake["complete"]=False
        negative("failed census cannot attest physical retirement",lambda:custody.validate_reader_report(fake))
        good("retirement preserves exact original supervisor bytecode",runner.with_globals(runner.physical.run,HERE=temp).__code__ is runner.physical.run.__code__)
        good("numerical/subject worker untouched",custody.is_retirement("retire-pgo") and
             not any(custody.is_retirement(x) for x in ("build","audit","functional","prepare-count","sample-count","sample-native")))
        good("only failed retirement gets a distinct physical root",custody.scope("retire-pgo","pr269")==custody.HERE and
             all(custody.scope(*t)==custody.STUDY for t in (("retire-pgo","head"),("retire-count","initial"),("retire-native","replica"))))
        lab=temp/"lab";lab.mkdir()
        s=temp/"subject";s.mkdir();recovery=temp/"recovery";recovery.mkdir()
        rc=lab/"recovery-segments";base=lab/"depinfo-v3-segment-receipts/drivers";base.mkdir(parents=True)
        obs=s/"observed";ordinary=("build-pr269","audit-pr269","retire-pgo-pr269")
        for tag in ordinary:
            c.new(s/"grants"/(tag+".json"),{});c.new(lab/("depinfo-complete-release-v3-"+tag+".json"),{})
            (obs/"physical"/tag).mkdir(parents=True)
        with mock.patch.dict(c.__dict__,dict(study=s,lab=lab,observed=obs,receipts=rc,repair_root=recovery)):
            good("retire-control accepts precisely the immutable original three scopes",c.expected_progress("retire-control")==())
            negative("head before control recovery",lambda:c.expected_progress("head-driver"))
            negative("functional before later control and candidate custody",lambda:c.expected_progress("functional"))
            negative("count before functional",lambda:c.expected_progress("count-initial"))
            _,grant,_=c.physical_paths("retire-pgo","pr269")
            c.new(grant,{});negative("pregiven second-use authority",lambda:c.expected_progress("retire-control"));grant.unlink()
            head=s/"grants/build-head.json";c.new(head,{})
            negative("pregiven head build authority",lambda:c.expected_progress("retire-control"));head.unlink()
            flag=base/"returned.json";c.new(flag,{});negative("failed original cannot become successful",lambda:c.expected_progress("retire-control"));flag.unlink()
            for name in ("depinfo-complete-command","depinfo-complete-command-v2"):
                f=s.with_name(name)/"grants";f.mkdir(parents=True,exist_ok=False)
                negative("earlier study cannot obtain a grant "+name,lambda:c.expected_progress("retire-control"));f.rmdir()
            stock_paths=[c.physical_paths(p,k) for p,k in (("build","head"),("audit","head"),("retire-pgo","head"),("functional","all"))]
            good("new subject scopes remain original",all(g.parent==s/"grants" and d.parent==obs/"physical" for r,g,d in stock_paths))
            recovered=c.physical_paths("retire-pgo","pr269")
            good("old failed grant and physical receipt preserved",recovered[1]!=s/"grants/retire-pgo-pr269.json" and recovered[2]!=obs/"physical/retire-pgo-pr269")
            def form(args,**kwargs):
                phase,key=args[4:6];label=phase+"-"+key
                r=lab/("depinfo-complete-release-v3-"+label+".json");g=s/"grants"/(label+".json")
                return json.dumps({"release_path":str(r),"grant_path":str(g),"release_template":{"study":"v3"},
                       "grant_template":{"study":"v3","registration_sha256":c.REG,"release":str(r)}}).encode()
            c.new(s/"registered.json",{"study":"v3"})
            with mock.patch.object(c.subprocess,"check_output",side_effect=form),mock.patch.object(c.repair,"reg",return_value="ab"*32),mock.patch.object(c,"sha",return_value="cd"*32),mock.patch.dict(c.__dict__,dict(reg=s/"registered.json")):
                corrected,r,g=c.form_for("retire-pgo","pr269",15)
                good("new one-time authority binds the actual fresh grant and release",corrected["grant_template"]["release"]==str(r) and g.parent==recovery/"grants" and corrected["release_template"]["retirement_recovery_sha256"]=="ab"*32)
                future,r,g=c.form_for("retire-pgo","head",15)
                good("future destructive authority binds the same sealed scanner in original scope",g.parent==s/"grants" and "retirement_scanner_sha256" in future["release_template"])
                unmodified,r,g=c.form_for("build","head",45)
                good("ordinary candidate build form untouched","retirement_recovery_sha256" not in unmodified["release_template"])
            good("initialized preplanned handoff points",c.phases("retire-control")==[("retire-pgo","pr269",15)] and c.phases("head-driver")==[("build","head",45),("audit","head",15),("retire-pgo","head",15)] and c.phases("functional")==[("functional","all",15)])
        good("one privilege-qualified original nonzero tool return",c.supervisor_receipt(83431,"b235d8",1)["exit"]==1)
        for ses,ch,st in ((83430,"b235d8",1),(83431,"b235d9",1),(83431,"b235d8",2)):
            negative("unrelated nonzero tool result "+str((ses,ch,st)),lambda:c.supervisor_receipt(ses,ch,st))
        good("user-mode descriptor scan passed only for a controlled live fixture",True)
    return {"synthetic_only":True,"target_allocations":0,"physical_study_or_compiler_launches":0,"accepted":accepted,"rejected":rejected}
if __name__=="__main__":print(json.dumps(main(),indent=2,sort_keys=True))
