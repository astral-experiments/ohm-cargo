"""Guest access only, no target traversal or process command lines, paths, maps or fd names are recorded."""
import collections,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from safe_unused import live_info
def main():
    assert Path('/proc/1/comm').read_text().strip()=='systemd'
    denied=[];checked=0
    for p in Path('/proc').glob('[0-9]*'):
        try:
            info=live_info(p)
            if os.getuid() not in info['uids']:continue
            checked+=1
            for what in ('fd','maps','cwd','exe'):
                try:
                    if what=='fd':
                        with os.scandir(p/'fd') as f:next(f,None)
                    elif what=='maps':
                        with (p/'maps').open('rb') as f:pass
                    else:os.readlink(p/what)
                except PermissionError:
                    denied.append(dict(pid=info['pid'],state=info['state'],threads=info['threads'],field=what))
                except (FileNotFoundError,ProcessLookupError):pass
        except (FileNotFoundError,ProcessLookupError):continue
    print(json.dumps({'host_same_uid_processes':checked,'denied':denied,'blocked_live':sum(x['state'] not in ('Z','X') for x in denied)},sort_keys=True))
if __name__=='__main__':main()
