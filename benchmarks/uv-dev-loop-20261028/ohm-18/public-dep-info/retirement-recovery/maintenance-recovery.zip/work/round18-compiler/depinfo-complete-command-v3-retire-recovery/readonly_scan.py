"""Dry check of the current three recorded target identities; no grants, receipts in targets, or cleanup."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import custody
import safe_unused
if __name__=="__main__":
    assert Path("/proc/1/comm").read_text().strip()=="systemd"
    before=custody.validate_predelete()
    root=Path(before["record"])
    result=safe_unused.scan([root/f for f in before["children"]])
    custody.validate_reader_report(result)
    assert custody.validate_predelete()==before
    print(json.dumps({"reaudited_predelete":True,"owned_directories":before["children"],"scan":result},sort_keys=True))
