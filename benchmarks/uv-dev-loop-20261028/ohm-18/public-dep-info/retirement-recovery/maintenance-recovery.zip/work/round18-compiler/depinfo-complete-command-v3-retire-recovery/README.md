# Resuming the Ohm Cargo complete-command study after a refused cleanup

The original v3 driver supervisor (session 83431, chunk b235d8) exited 1 after the #269 PGO build and independent audit had each returned 0. Its first retirement scan could not enumerate the fd table for PID 2262570. It stopped before the retirement journal, a rename or a removal. The three generated target directories still had their original device and inode numbers when this amendment was sealed. The original failure and those successes remain in the original receipt directories.

A read-only check on the genuine guest saw the same UID, PID and process start tick on both sides of the refusal, a Z state and exactly one task. A second guest-wide census found two such zombie groups and zero live groups with denied inspection. A dry run of the actual replacement scanner checked 20 live groups, confirmed both single-task zombies, and revalidated all three generated target identities afterwards. It did not open files inside those targets or alter them.

## Scope and checks

The adapter uses the original registration, source trees, toolchains, training, driver and functional audits, timing, instruction population, statistical gates, CPU allocation, 120 GiB reserve, subreaper, watchdog and file/slot custody. Only retirement runs through the new entrypoint. For the first exact retirement its grant and physical supervisor evidence use a separate directory. The three earlier physical attempts, including the exit 1, keep their names, receipts and authority. The new retirement writes the original intended target-retirement manifest only after the original checks succeed.

The scanner checks every process group whose real, effective, saved or filesystem UID matches the study user. It inspects each live task's fd, root, cwd and executable and the group's file mappings. It rejects a reference to a target, including a mapped file with its old fd closed. A same-user group with an unreadable live reference blocks removal. Skipping a terminal group requires two identical process observations with the same start tick, a single task equal to the leader, and Z or X state. A vanished process must actually be gone. The scope retains the original study's same-user custody boundary and covers separate task fd tables and memory mappings within it.

Every scan records only its authorized roots, their actual identities, counts and the verified terminal PID identities. No command lines, unrelated fd names or maps are saved. The child prints the aggregate reader-closure digest into its original supervisor log. The compound checker verifies that digest, each scan, target roster and kernel disposition. A violation stops the original cleanup at that gate and leaves the original nonzero result available. There is no generic retry.

## Coordinator

Use the same Python interpreter recorded by the original PGO build, `/home/dev-user/.virtualenvs/openai/bin/python3`. The prospective root coordinator is `work/round18-lab/depinfo-segment-v3-retire-recovery.py`.

```sh
python3 -I -B work/round18-lab/depinfo-segment-v3-retire-recovery.py --self-test
python3 -I -B work/round18-lab/depinfo-segment-v3-retire-recovery.py --verify-recovery
python3 -I -B work/round18-lab/depinfo-segment-v3-retire-recovery.py --verify-predelete
```

The root may later grant `retire-control`, `head-driver`, `functional`, `count-initial`, `count-replica`, `native-initial`, then `native-replica`. Each segment separately requires the most recent actual root-observed external or recovery physical return, no outstanding host owner, all earlier recovery segments and no premature grants. The root can interleave its verified historical Cargo test cells at these boundaries. Count qualification remains mandatory before either native allocation.

```sh
/home/dev-user/.virtualenvs/openai/bin/python3 -I -B work/round18-lab/depinfo-segment-v3-retire-recovery.py SEGMENT \
    --previous REAL_LATEST_RETURN --previous-sha SHA --previous-session SESSION \
    --previous-chunk CHUNK --previous-exit ACTUAL_EXIT
```

The original nonzero handoff is accepted only for the exact root audit at `work/round18-lab/depinfo-driver-retirement-root-audit.json`, SHA-256 `8fb5df342921768842f84cbf4e27add878404f264a5fd76345ed67143b47fadf`, with the literal session 83431, chunk b235d8 and exit 1. If a later historical cell has completed, use its independently validated successful return instead. The historical failed prefix remains a mandatory prerequisite in either case. New segment journals live under `work/round18-lab/depinfo-v3-retire-recovery-segments`; the terminal scope remains the registered v3 experiment. The receipt named `registered.json` here is a byte-identical copy of the scientific v3 registration for the fresh first physical grant. The new resource/ownership protocol is sealed separately in `recovery.json`.

The first real recovery grant requires the four original directory identities to match again, the original pilot return and raw logs to be intact and the cleanup journal to remain absent. Only the real authorized retirement can remove its generated directories. The source, final driver, independent training evidence, merged/raw profiles and linked standard library follow the original v3 preservation rules. No benchmark sample was collected by this amendment.
