"""Byte-stable ZIP layout. Repack only the checksum manifest and its named extracted files."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

def archive(output, blobs):
    with zipfile.ZipFile(output,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for name,data in sorted(blobs.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=7)
if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("output",type=Path);a=ap.parse_args()
    base=Path(__file__).resolve().parent;raw=(base/"manifest.json").read_bytes();m=json.loads(raw)
    data={"manifest.json":raw}
    for k,v in m["files"].items():
        path=base/k
        if not path.resolve().is_relative_to(base) or path.is_symlink():raise ValueError(k)
        contents=path.read_bytes()
        if len(contents)!=v["bytes"] or hashlib.sha256(contents).hexdigest()!=v["sha256"]:raise ValueError(k)
        data[k]=contents
    archive(a.output,data)
