import csv, hashlib, json, os, runpy, subprocess, sys, tarfile
from pathlib import Path
p = Path(__file__).resolve().parent
rustc = Path(sys.argv[1]).resolve(strict=True)
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
if hasattr(os, "sched_getaffinity"):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
with tarfile.open(p / "rustc-hash-2.1.2.crate") as t:
    for member in t.getmembers():
        if member.isfile() and member.name.startswith("rustc-hash-2.1.2/src/"):
            relative = Path(member.name).relative_to("rustc-hash-2.1.2")
            assert ".." not in relative.parts
            dest = out / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(t.extractfile(member).read())
flags = ["-C", "opt-level=3", "-C", "codegen-units=1", "-C", "debuginfo=0"]
subprocess.run([rustc, "--edition=2021", "--crate-name", "rustc_hash", "--crate-type", "rlib", "--cfg", 'feature="std"', *flags, out / "src/lib.rs", "-o", out / "librustc_hash.rlib"], check=True)
subprocess.run([rustc, "--edition=2024", "--extern", f"rustc_hash={out}/librustc_hash.rlib", *flags, p / "phase.rs", "-o", out / "phase"], check=True)
with (out / "samples.csv").open("xb") as f:
    subprocess.run([out / "phase", p / "initial.rows", p / "replica.rows", p / "schedule.csv"], stdout=f, check=True)
result = runpy.run_path(str(p / "score.py"))["score"](list(csv.DictReader((out / "samples.csv").open())), list(csv.DictReader((p / "schedule.csv").open())))
result["compiler_sha256"] = hashlib.sha256(rustc.read_bytes()).hexdigest()
(out / "score.json").write_text(json.dumps(result, indent=2) + "\n")
print(out / "score.json")
