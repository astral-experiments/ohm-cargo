"""Recover particular workspace-unit dependency lists from an existing release-18 target."""
import json
import os
import struct
import sys
import tomllib
from collections import Counter, defaultdict
from pathlib import Path


OUT = Path(__file__).resolve().parent
cohort = Path(sys.argv[1])
bank = sys.argv[2] if len(sys.argv) > 2 else "common"
debug = cohort / bank / "debug"
source = cohort / "source"
target = cohort / "target"
members = {}
for manifest in (source / "crates").glob("*/Cargo.toml"):
    members[tomllib.loads(manifest.read_text())["package"]["name"]] = manifest.parent


def direct_paths(dep, crate):
    record = dep.read_bytes()
    assert record[:5] == bytes((1, 0, 0, 0, 255)) and record[5] in (3, 4)
    count, = struct.unpack_from("<I", record, 6)
    cursor = 10
    result = []
    for _ in range(count):
        ty = record[cursor]
        assert ty in (0, 1)
        size, = struct.unpack_from("<I", record, cursor + 1)
        cursor += 5
        path = os.fsdecode(record[cursor:cursor+size])
        cursor += size
        has_sum = record[cursor]
        cursor += 1
        assert has_sum in (0, 1)
        if has_sum:
            size, = struct.unpack_from("<I", record, cursor + 8)
            cursor += 12 + size
        result.append(str((crate if ty == 0 else target) / path))
    return result


by_hash = defaultdict(list)
units = {}
root_by_inode = defaultdict(list)
for name, crate in members.items():
    for directory in (debug / "build" / name).glob("*/fingerprint"):
        for p in directory.glob("*.json"):
            if not (p.stem.startswith(("lib-", "bin-", "build-script-", "run-build-script-"))
                    and p.with_suffix("").is_file()):
                continue
            data = json.loads(p.read_bytes())
            if "deps" not in data or "local" not in data:
                continue
            unit = str(p.relative_to(debug))
            fp_hash = int.from_bytes(bytes.fromhex(p.with_suffix("").read_text()), "little")
            by_hash[fp_hash].append(unit)
            paths = []
            rerun = []
            if (directory / ("dep-" + p.stem)).is_file():
                paths = direct_paths(directory / ("dep-" + p.stem), crate)
            for local in data["local"]:
                for value in local.get("RerunIfChanged", {}).get("paths", []):
                    rerun.append(str(crate / value))
            units[unit] = {"raw": paths, "rerun": rerun, "edges": [d[3] for d in data["deps"]]}
            if p.stem.startswith(("lib-", "bin-")):
                for output in (directory.parent / "out").iterdir():
                    if output.is_file() and (output.suffix in (".so", ".rlib") or output.name == p.stem[4:].replace("-", "_")):
                        root_by_inode[(output.stat().st_dev, output.stat().st_ino)].append(unit)

orders = {}
missing = {}
use_count = Counter()
for depfile in sorted(debug.glob("*.d")):
    published = depfile.read_text().rstrip("\n")
    binary, files = published.split(": ", 1)
    assert "\\ " not in files
    observed = files.split()
    lifted = debug / Path(binary).name
    st = lifted.stat()
    roots = root_by_inode[(st.st_dev, st.st_ino)]
    assert len(roots) == 1, (lifted, roots)
    visited = []
    seen = set()
    def descend(unit):
        if unit in seen:
            return
        seen.add(unit)
        visited.append(unit)
        for dep_hash in units[unit]["edges"]:
            if dep_hash in by_hash:
                choices = by_hash[dep_hash]
                assert len(choices) == 1, choices
                descend(choices[0])
    descend(roots[0])
    seen_files = {path for unit in visited for field in ("raw", "rerun") for path in units[unit][field]}
    if seen_files != set(observed):
        missing[depfile.name] = {"absent":sorted(set(observed)-seen_files), "extra":sorted(seen_files-set(observed))}
    orders[depfile.name] = {"units":visited, "published":len(observed), "root":roots[0]}
    use_count.update(visited)

assert len(orders) >= 70
counts = {unit: {"raw":len(units[unit]["raw"]), "uses":n} for unit,n in use_count.items()}
result = {"cohort":str(cohort), "ordering":"depth-first by stable fingerprint dep hash, not a trace of live unit_deps order",
          "units":{u:units[u] for u in counts}, "roots":orders, "path_mismatches":missing}
(OUT / (cohort.name+"-"+bank+"-input-shape.json")).write_text(json.dumps(result, separators=(",",":"))+"\n")
print(json.dumps({"roots":len(orders),"visited_local_units":len(counts),"public_path_entries":sum(x["published"] for x in orders.values()),
                  "root_path_mismatch":len(missing),"all_raw_paths_in_distinct_local_units":sum(x["raw"] for x in counts.values()),
                  "raw_paths_visited_across_roots":sum(x["raw"]*x["uses"] for x in counts.values()),
                  "largest_reused_lists":sorted(counts.items(),key=lambda v:v[1]["raw"]*v[1]["uses"],reverse=True)[:5]},indent=2))
