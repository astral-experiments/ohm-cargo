import csv
import hashlib
import itertools
import json
import random
import subprocess
import textwrap
from datetime import datetime, timezone
from pathlib import Path

out = Path(__file__).resolve().parent
work = out.parents[1]
repo = work/"ohm-cargo"
src = "src/compiler/output_depinfo.rs"
base = "7caf39914da1e28a67744ecbc963a5f26361474d"
borrowed = "9256d6a21da8e6c0a2ba9502999d74544ed850cd"
assert subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip() == base

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def frozen(sha): return subprocess.check_output(["git","-C",str(repo),"show",sha+":"+src],text=True)
def between(s,b,e): return s[s.index(b):s.index(e,s.index(b))]

generated = []
for label,rev in (("release",base),("borrowed",borrowed)):
    source = frozen(rev)
    inner = between(source, "    fn wrap_path(", "\n    }")+"\n    }"
    inner = textwrap.dedent(inner).replace("fn wrap_path(",f"fn {label}_path(")
    renderer = textwrap.dedent(between(source,"            if single_output {","                // Preserve the mtime"))
    renderer = renderer.split("{",1)[1].strip().replace("?;",".unwrap();")
    generated.append(inner+f"""
fn {label}_line(paths: &mut Vec<PathBuf>, target: &Path) -> Vec<u8> {{
    paths.sort();
    paths.dedup();
    let deps: Vec<_> = paths.iter().map(|p| {label}_path(p).unwrap()).collect();
    let target_fn = {label}_path(target).unwrap();
    {renderer}
    contents
}}
""")
candidate = (repo/src).read_text()
actual = between(candidate,"fn matches_existing_dep_info(", "/// Collects all dependencies")
generated.append(actual.replace("#[test]\n","").replace(
    "fn existing_dep_info_requires_the_complete_sorted_spelling()",
    "fn existing_dep_info_requires_the_complete_sorted_spelling_for_replay()"))
(out/"source-sections.rs").write_text("\n".join(generated))
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","-C",str(repo),"diff","--",src]))

for cohort in ("initial","replica"):
    data = json.loads((out/f"{cohort}-rejected-build-structural-input-shape.json").read_bytes())
    assert data["path_mismatches"] == {} and len(data["roots"]) == 74
    contents = []
    for name,record in data["roots"].items():
        dep = (Path(data["cohort"])/"rejected-build-structural/debug"/name).read_text()
        assert dep.endswith("\n") and dep.count("\n") == 1 and "\t" not in dep
        target, fields = dep.rstrip("\n").split(": ",1)
        contents.extend(["T\t"+target,"E\t"+dep.rstrip("\n")])
        direct = []
        for u in record["units"]:
            for field in ("raw","rerun"):
                direct.extend(data["units"][u][field])
        assert set(direct) == set(fields.split(" "))
        contents.extend("P\t"+p for p in direct)
    (out/f"{cohort}.rows").write_text("\n".join(contents)+"\n")
permutations = list(itertools.permutations(("release","borrowed","head")))
rng = random.Random(202610290833)
orders = {}
for c in ("initial","replica"):
    orders[c] = permutations*4
    rng.shuffle(orders[c])
with (out/"schedule.csv").open("w") as f:
    writer = csv.writer(f,lineterminator="\n")
    writer.writerow(("cohort","round","position","arm"))
    for i in range(24):
        for c in (("initial","replica") if i%2==0 else ("replica","initial")):
            for a,arm in enumerate(orders[c][i]):
                writer.writerow((c,i,a,arm))
files = ["schedule.csv","initial.rows","replica.rows","phase.rs","source-sections.rs","candidate.patch",
         "shape.py","prepare.py","source-overlap.json"]
plan = {"utc":datetime.now(timezone.utc).isoformat(),"release":base,"borrowed":borrowed,
        "method":"hot in-process phase only; all 74 actual .d outputs / 9,581 fields match on each checkout; recursive group order reconstructed from fingerprint edges, not a live trace; one unmodified released rustc; one pinned CPU; five inner iterations per complete 3-way block",
        "observations":144,"inner_iterations":5,"cohorts":2,"independent_blocks_per_cohort":24,
        "whole_command_gate":"both cohorts median phase saving >=8ms vs release and >=4ms vs #269; two-sided order statistic interval positive against each",
        "instruction_screen_gate":"on each cohort lower bound positive in both comparisons and median >=2ms over #269; treat as exact-scope phase diagnostic only until observed on normal commands",
        "required_guards":"exact raw spellings, full coverage of the dependency set, canonical Path order, target, newline; raw alias, escaping, invalid bytes and basedir use the existing full renderer; missing/corrupt previous outputs recover; multi-output legacy behavior untouched",
        "files":{f:sha(out/f) for f in files},
        "physical_status":"unlaunched; requires a new exclusive physical slot after the active Wild comparison"}
(out/"phase-plan.json").write_text(json.dumps(plan,indent=2)+"\n")
print(sha(out/"phase-plan.json"),{f:(out/f).stat().st_size for f in ("initial.rows","replica.rows","source-sections.rs")})
