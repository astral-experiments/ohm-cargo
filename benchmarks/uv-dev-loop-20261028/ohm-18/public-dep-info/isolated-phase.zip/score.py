import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

out = Path(__file__).resolve().parent

def score(rows, schedule):
    assert len(rows) == len(schedule)*5 == 720
    per_arm = defaultdict(list)
    for i,row in enumerate(rows):
        goal = schedule[i//5]
        assert all(row[k] == v for k,v in goal.items())
        assert int(row["iteration"]) == i%5 and int(row["phase_ns"]) > 0
        per_arm[(goal["cohort"],int(goal["round"]),goal["arm"])].append(int(row["phase_ns"])/1e6)
    result = {}
    for cohort in ("initial","replica"):
        contrasts = {}
        for arm in ("release","borrowed"):
            ds = []
            for i in range(24):
                def inner(k):
                    values = per_arm[cohort,i,k]
                    assert len(values) == 5
                    return statistics.median(values)
                ds.append(inner(arm)-inner("head"))
            n = len(ds)
            rank = max(k for k in range(1,n//2+1) if 2*sum(math.comb(n,j) for j in range(k))/2**n <= .05)
            ordered = sorted(ds)
            contrasts[arm] = {"blocks":n,"median_saved_ms":statistics.median(ds),
                    "rank_interval_ms":[ordered[rank-1],ordered[-rank]],"two_sided_coverage":1-2*sum(math.comb(n,j) for j in range(rank))/2**n,
                    "wins":sum(x>0 for x in ds),"paired_deltas_ms":ds}
        result[cohort] = contrasts
    positive = all(c["rank_interval_ms"][0]>0 for v in result.values() for c in v.values())
    counts = positive and all(v["borrowed"]["median_saved_ms"]>=2 for v in result.values())
    wall = positive and all(v["release"]["median_saved_ms"]>=8 and v["borrowed"]["median_saved_ms"]>=4 for v in result.values())
    return {"cohorts":result,"phase_instruction_screen_eligible":counts,"phase_whole_command_eligible":wall,
            "scope":"isolated hot dependency-output phase; no actual Cargo command wall or instruction claim"}

if __name__ == "__main__":
    rows = list(csv.DictReader((out/"native-phase/samples.csv").open()))
    schedule = list(csv.DictReader((out/"schedule.csv").open()))
    result = score(rows,schedule)
    (out/"native-phase/score.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:r for k,r in result.items() if k!="cohorts"}))
    for c,v in result["cohorts"].items():
        print(c,[(a,round(w["median_saved_ms"],3),[round(q,3) for q in w["rank_interval_ms"]]) for a,w in v.items()])
