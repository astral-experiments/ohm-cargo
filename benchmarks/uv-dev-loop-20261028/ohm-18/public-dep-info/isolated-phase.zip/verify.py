import csv, hashlib, json, runpy
from pathlib import Path
p = Path(__file__).resolve().parent
files = json.loads((p / "manifest.json").read_bytes())
assert set(files) == {x.relative_to(p).as_posix() for x in p.rglob("*") if x.is_file() and x != p / "manifest.json"}
for name, digest in files.items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, name
score = runpy.run_path(str(p / "score.py"))["score"]
data = list(csv.DictReader((p / "native-phase/samples.csv").open()))
order = list(csv.DictReader((p / "schedule.csv").open()))
observed = score(data, order)
assert observed == json.loads((p / "native-phase/score.json").read_bytes())
assert observed["phase_whole_command_eligible"] and observed["phase_instruction_screen_eligible"]
for checkout, items in observed["cohorts"].items():
    print(checkout, {arm: (round(v["median_saved_ms"], 3), v["rank_interval_ms"], v["wins"]) for arm, v in items.items()})
