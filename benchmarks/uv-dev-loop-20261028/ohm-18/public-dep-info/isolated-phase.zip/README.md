# Cargo dependency-output phase after editing uv

Each of two uv checkouts supplied 74 actual public dependency files with 9,581 paths. Both reconstructed inputs spell the same path sets as their corresponding public files. Input groups follow Cargo fingerprint edges. The reconstruction retains each group's local order. Cargo's live recursive visit order was not recorded.

The experiment times one in-process pass over a checkout's complete set of public dependency files. It compares the released Cargo source, the rendering change from Ohm Cargo PR 269, and the proposed fast path. A single CPU ran all six possible arm orders four times per checkout. Each block uses the median of five repetitions. The raw measurements and original pre-run plan are included.

After unpacking, run `python3 -I -B verify.py` to check the archive and recompute the result. Run `python3 -I -B replay.py /path/to/ohm-18/bin/rustc new-output-directory` to repeat the phase. The compiler, crate and schedule used for the recorded measurements are identified by their hashes. The crate archive is included for offline builds.

Full Cargo commands have additional work, including reading dependency files and collecting the paths. This phase measures the path comparison and rendering portion only.
