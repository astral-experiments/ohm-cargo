import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from pathlib import Path

out = Path(__file__).resolve().parent
work = out.parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def write(path,data): path.write_text(json.dumps(data,indent=2)+"\n")
parser = argparse.ArgumentParser()
parser.add_argument("--released",required=True,type=Path)
args = parser.parse_args()
assert Path("/proc/1/comm").read_text().strip()=="systemd" and os.geteuid()!=0
assert os.sched_getaffinity(0)=={8} and shutil.disk_usage(work).free > 120*2**30
grant = read(args.released)
assert grant["study"]=="depinfo-native-phase" and grant["owner"]=="/root"
prev = Path(grant["previous_physical_return"])
assert sha(prev)==grant["previous_return_sha256"] and read(prev)["custody_returned"]
plan = read(out/"phase-plan.json")
assert grant["phase_plan_sha256"]==sha(out/"phase-plan.json")
assert all(sha(out/n)==v for n,v in plan["files"].items())
frozen = read(out/"phase-execution-plan.json")
assert all(sha(out/n)==v for n,v in frozen.items())
r = out/"native-phase"
r.mkdir()
rustc = work/"upstream-monitor/toolchain18/bin/rustc"
storage = work/"round18-cargo/pgo/build-home/registry"
crate = next((storage/"src").glob("*/rustc-hash-2.1.2"))
crate_tar = next((storage/"cache").glob("*/rustc-hash-2.1.2.crate"))
assert sha(crate_tar)=="94300abf3f1ae2e2b8ffb7b58043de3d399c73fa6f4b73826402a5c457614dbe"
with tarfile.open(crate_tar) as t:
    for p in (crate/"src").glob("**/*.rs"):
        member = t.extractfile("rustc-hash-2.1.2/"+str(p.relative_to(crate)))
        assert member and member.read() == p.read_bytes()
env = {**os.environ,"PATH":str(rustc.parent)+":/usr/bin:/bin"}
flags = ["-C","opt-level=3","-C","codegen-units=1","-C","debuginfo=0"]
commands = [
    [str(rustc),"--edition=2021","--crate-name","rustc_hash","--crate-type","rlib","--cfg",'feature="std"',*flags,str(crate/"src/lib.rs"),"-o",str(r/"librustc_hash.rlib")],
    [str(rustc),"--edition=2024","--extern","rustc_hash="+str(r/"librustc_hash.rlib"),*flags,str(out/"phase.rs"),"-o",str(r/"phase")],
    [str(r/"phase"),str(out/"initial.rows"),str(out/"replica.rows"),str(out/"schedule.csv")],
]
receipt = {"started_ns":time.time_ns(),"commands":commands,"compiler_sha256":sha(rustc),
           "crate_archive_sha256":sha(crate_tar),"plan_sha256":sha(out/"phase-plan.json"),"grant_sha256":sha(args.released),"steps":[]}
rc = 1
try:
    for i,cmd in enumerate(commands):
        with (r/("samples.csv" if i==2 else f"compile-{i}.out")).open("xb") as stdout, (r/f"step-{i}.stderr").open("xb") as stderr:
            proc = subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr)
        receipt["steps"].append({"index":i,"exit":proc.returncode})
        proc.check_returncode()
    subprocess.run([sys.executable,"-I","-B",str(out/"score.py")],check=True)
    rc = 0
finally:
    receipt.update(actual_exit=rc,finished_ns=time.time_ns(),physical_returned=True,free_bytes=shutil.disk_usage(work).free)
    write(r/"returned.json",receipt)
