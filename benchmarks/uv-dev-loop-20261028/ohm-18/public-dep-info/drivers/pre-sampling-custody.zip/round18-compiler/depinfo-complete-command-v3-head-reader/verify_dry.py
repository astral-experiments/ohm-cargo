"""Read-only. Verifies original resource returns and the exact real prior handoff; no lock, grant or process census."""
from pathlib import Path
import importlib.util,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import custody as c
spec=importlib.util.spec_from_file_location('new_head_coordinator',c.COORD)
co=importlib.util.module_from_spec(spec);spec.loader.exec_module(co)
c.verify_seal()
assert c.sha(c.STUDY/'registered.json')==co.REG and c.sha(c.STUDY/'schedules.csv')==co.SCHEDULE
wait=c.read(c.HIST_WAIT);c.historical(wait,wait,c.sha(c.HIST))
assert co.peer_return(c.HIST,'cargo','replica-test')==c.read(c.HIST)['utc_ns']
assert co.verify_handoff(c.HIST,c.sha(c.HIST),False)==c.read(c.HIST)['utc_ns']
if sys.argv[1:]==['--before-grant']:
 assert co.verify_handoff(c.HIST,c.sha(c.HIST),True)==c.read(c.HIST)['utc_ns']
 assert co.expected_progress('retire-head')==() and co.phases('retire-head')==[('retire-pgo','head',15)]
 old=c.read(c.HIST.with_name('closure.json'));assert old['terminal']=='excluded' and old['worker_returncode']==1 and old['rows']==0
 d=c.validate_predelete();sc=c.read(HERE/'guest-census.json')['observed'];assert sc['owned']==d['children']
c.validate_reader_report(c.read(HERE/'guest-census.json')['observed']['scan'])
assert co.physical_paths('retire-pgo','head')[1].parent==HERE/'grants'
assert all(co.physical_paths(p,k)[1].parent==c.STUDY/'grants' for n in co.segments[1:] for p,k,_ in co.phases(n))
print(json.dumps({'verified_frozen_schedule':co.SCHEDULE,'prior_control_failure':[83431,'b235d8',1],
                  'head_failure':[8861,'57baf8',1],'historical':wait,'eligible_scopes':co.segments,'allocated':False},sort_keys=True))
