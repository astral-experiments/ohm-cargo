"""Reconstruct the small mechanical changes to the earlier sealed coordinator."""
from pathlib import Path
import hashlib,sys
here=Path(__file__).resolve().parent;lab=here.parents[1]/'round18-lab'
src=lab/'depinfo-segment-v3-retire-recovery.py'
assert hashlib.sha256(src.read_bytes()).hexdigest()=='1e76537399a2ca56cf6ead5cc427d61171b2fb42601b2cf5cf10f155ed622b38'
s=src.read_text()
def r(a,b,n=1):
    global s
    assert s.count(a)==n,(a,s.count(a),n)
    s=s.replace(a,b)
r('repair_root=study.with_name("depinfo-complete-command-v3-retire-recovery")','repair_root=study.with_name("depinfo-complete-command-v3-head-reader")')
r('segments=("retire-control","head-driver",','segments=("retire-head",')
r('receipts=lab/"depinfo-v3-retire-recovery-segments"','receipts=lab/"depinfo-v3-head-reader-segments"')
r('    if segment=="retire-control":return [("retire-pgo","pr269",15)]\n    if segment=="head-driver":return [("build","head",45),("audit","head",15),("retire-pgo","head",15)]','    if segment=="retire-head":return [("retire-pgo","head",15)]')
r('if (phase,key)==("retire-pgo","pr269"):', 'if (phase,key)==("retire-pgo","head"):',3)
r('depinfo-complete-release-v3-reader-resume-', 'depinfo-complete-release-v3-head-reader-')
r('"depinfo-complete-command-v3-retire-recovery/retirement_runner.py",','"depinfo-complete-command-v3-retire-recovery/retirement_runner.py","depinfo-complete-command-v3-head-reader/retirement_runner.py",')
r('        closure=read(d/"reader-closure.json")','        repair.validate_pregrant(r["pregrant_reader"],phase,key)\n        closure=read(d/"reader-closure.json")')
r('    prev=Path(v["previous_return"]);digest=v["previous_return_sha256"]','''    prev=Path(v["previous_return"]);digest=v["previous_return_sha256"]
    if name=="retire-head":
        require(prev==repair.HIST and v["historical_outer_wait_sha256"]==sha(repair.HIST_WAIT),"wrong historical predecessor")
        repair.historical(v["previous_supervisor"],read(repair.HIST_WAIT),digest)
        peer_return(prev,"cargo","replica-test")''')
r('result={repair.ROOT_RECEIPT:read(repair.ROOT_RECEIPT)["utc_ns"]}','result={repair.ROOT_RECEIPT:read(repair.ROOT_RECEIPT)["failure_ns"]}')
r('        stamp=read(p)["utc_ns"]','        stamp=read(p)["failure_ns"]')
r('(exit_code==0 or (session,chunk,exit_code)==(83431,"b235d8",1)),','exit_code==0,')
r('    for p,k in done:', '''    first=repair.PRIOR
    expected[first/"grants"]={"retire-pgo-pr269.json"}
    expected[first/"observed/physical"]={"retire-pgo-pr269"}
    expected[lab].add("depinfo-complete-release-v3-reader-resume-retire-pgo-pr269.json")
    for p,k in done:''')
r('    require((a.previous.absolute()==repair.ROOT_RECEIPT)==\n            ((a.previous_session,a.previous_chunk,a.previous_exit)==(83431,"b235d8",1)),\n            "only the exact refused cleanup may use that nonzero tool return")','''    require(a.previous.absolute()!=repair.ROOT_RECEIPT,"the old failed cleanup cannot release the host past the historical cell")''')
r('            if a.segment=="retire-control":repair.validate_predelete()','''            if a.segment=="retire-head":
                require(prev==repair.HIST,"historical replica-test actually owned the host after the failed head")
                repair.historical(provenance,read(repair.HIST_WAIT),digest)
                repair.validate_predelete()''')
r('a.segment not in ("retire-control","head-driver","functional")','a.segment not in ("retire-head","functional")')
r('        new(logs/"intake.json",history)','        history["historical_outer_wait_sha256"]=sha(repair.HIST_WAIT)\n        new(logs/"intake.json",history)')
r('                    new(release,certificate)','''                    if repair.is_retirement(phase):
                        certificate["pregrant_reader"]=repair.pregrant(phase,key)
                        quiet();require(external_snapshot()==others,"host changed during pregrant reader census")
                    new(release,certificate)''')
r('"supervisor":[83431,"b235d8",1]','"supervisor":[8861,"57baf8",1]')
dest=lab/'depinfo-segment-v3-head-reader.py'
if sys.argv[1:]==['--verify']:
    assert dest.read_text()==s
else:
    with dest.open('x') as f:f.write(s)
