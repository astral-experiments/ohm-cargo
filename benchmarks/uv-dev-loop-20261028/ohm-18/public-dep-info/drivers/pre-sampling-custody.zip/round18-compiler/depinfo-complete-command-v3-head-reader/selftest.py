"""Synthetic only. The script cannot allocate a physical grant or invoke a real proc helper."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import manager as m
import custody as c
cases=[]
def accept(name,fn):
    fn();cases.append(name)
def reject(name,fn):
    try:fn()
    except (RuntimeError,ValueError,AssertionError):cases.append(name);return
    raise AssertionError('expected failure: '+name)
def who(p):
    start,ppid,name,cap,cg=m.pin(p);pid=int(p.name)
    return dict(pid=pid,tgid=pid,ppid=ppid,start=start,name=name,cap_eff=cap,cgroup=cg,state='S',threads=1,uids=[1000]*4)
def collect(pid=3303870,override=None):
    p=Path('/proc')/str(pid)
    calls=[]
    def command(proc,op,path):
        args=m.argv(proc,op,path);assert args[:3]==['/usr/bin/sudo','-n','--']
        calls.append((op,path))
        if override is not None:
            x=override(op,path,calls)
            if x is not None:return x
        if op=='ls':return (str(pid)+'\n').encode() if path.name=='task' else b'4\n17\n'
        if op=='cat':return b'100-200 r--p 000 ab:cd 7 /unrelated/example\n'
        return b'/outside/owned-suffix\0'
    data=m.run_readers(p,[Path('/owned')],command,who)
    row={'bounded_privileged_readers':[data],'restarted_after_vanished_opaque':[]}
    m.validate(row)
    assert len(calls)==11 and data['fixed_links']==3 and data['fd_links']==2
    return row
for pid in m.PINS:accept('each pinned generation '+str(pid),lambda pid=pid:collect(pid))
for where in ('cwd','root','exe','4','17'):
    reject('target on '+where,lambda where=where:collect(override=lambda op,p,_:b'/owned/product (deleted)\0' if op=='readlink' and p.name==where else None))
for task in (False,True):
    reject('mapped target '+str(task),lambda task=task:collect(override=lambda op,p,_:b'100-200 r--p 000 ab:cd 7 /owned/file (deleted)\n' if op=='cat' and ('task' in p.parts)==task else None))
reject('descriptor set changed',lambda:collect(override=lambda op,p,c:b'4\n' if op=='ls' and p.name=='fd' and c.count((op,p))==2 else None))
reject('task set changed',lambda:collect(override=lambda op,p,c:b'3303870\n3303871\n' if op=='ls' and p.name=='task' else None))
reject('incomplete readlink',lambda:collect(override=lambda op,p,c:b'no nul' if op=='readlink' else None))
reject('incomplete maps',lambda:collect(override=lambda op,p,c:b'' if op=='cat' else None))
reject('fd listing is not numeric',lambda:collect(override=lambda op,p,c:b'../other\n' if op=='ls' and p.name=='fd' else None))
for op,path in [('cat','cmdline'),('cat','environ'),('cat','mem'),('readlink','../../etc/shadow'),('sh','maps'),('ls','fds'),('cat','/proc/3303871/maps')]:
    r=Path('/proc/3303870')
    reject('denied utility/path '+op+' '+path,lambda op=op,path=path,r=r:m.argv(r,op,r/path))
reject('opaque unknown live process not a privileged subject',lambda:m.argv(Path('/proc/1'),'cat',Path('/proc/1/maps')))
def bad_start():
    val=collect();val['bounded_privileged_readers'][0]['identity']['start']+=1;m.validate(val)
reject('wrong generation report',bad_start)
def prior_error(reason='uninspectable live, changing or multi-thread process: pid 123'):
    exc=RuntimeError(reason);exc.retirement_scan={'complete':False,'retained':True,'blocked_pid':'123','error_type':'RuntimeError',
        'opaque_identity':{'pid':123,'start':5,'state':'S','threads':1,'uids':[1000]*4}}
    return exc
def attempt(seq):
    def run(_):
        x=seq.pop(0)
        if isinstance(x,Exception):raise x
        return x
    return run
reject('opaque live remains blocked after bounded wait',lambda:m.scan([],attempt([prior_error()]),exists=lambda _:True,wait=lambda _:None))
def vanished():
    result=m.scan([],attempt([prior_error(),{'complete':True,'bounded_privileged_readers':[]}]),exists=lambda _:False,wait=lambda _:None)
    assert result['complete'] and len(result['restarted_after_vanished_opaque'])==1
    m.validate(result)
accept('disappeared requires full successful rescan',vanished)
reject('changed/target conflict is never retried',lambda:m.scan([],attempt([prior_error('live pid 123 maps an owned target')]),exists=lambda _:False,wait=lambda _:None))
reject('bounded restart count',lambda:m.scan([],attempt([prior_error(),prior_error(),prior_error()]),exists=lambda _:False,wait=lambda _:None))
w={'session':91078,'chunk':'296d24','exit':0,'validated_sha256':'xyz'};v={k:w[k] for k in ('session','chunk','exit')}
accept('actual independent final historical observer',lambda:c.historical(v,w,'xyz'))
for key,value in [('exit',1),('session',8861),('chunk','57baf8'),('validated_sha256','bad')]:
    reject('historical mismatch '+key,lambda key=key,value=value:c.historical(v,{**w,key:value},'xyz'))
assert c.allowed('retire-pgo','head') and all(c.allowed(p,k) for p in ('retire-native','retire-count') for k in ('initial','replica'))
assert not any(c.allowed(p,k) for p,k in [('build','head'),('retire-pgo','pr269'),('sample-native','initial'),('retire-native','x')])
print(json.dumps({'passed':cases,'count':len(cases),'physical_work':False,'real_cargo_or_sudo':False},sort_keys=True))
