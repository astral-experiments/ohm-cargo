"""Use the frozen native supervisor and retire functions; substitute only the verified fd scanner."""
import argparse
import contextlib
import os
from pathlib import Path
import sys
from types import FunctionType
SELF=Path(__file__).resolve()
sys.path.insert(0,str(SELF.parent))
import custody
import manager
sys.path.insert(0,str(custody.STUDY))
import depcommon as v3
import run as physical

def with_globals(function, **extra):
    return FunctionType(function.__code__,{**function.__globals__,**extra},function.__name__,
                        function.__defaults__,function.__closure__)

def authority(phase,key):
    custody.require(custody.allowed(phase,key),"this adapter cannot run a nonretirement workload")
    scope=custody.scope(phase,key)
    # Current inputs and subjects always resolve in the original v3 suite. Only the duplicate first
    # scope's grant and supervisor receipt need distinct destinations.
    grant=with_globals(v3.authority,HERE=scope)(phase,key)
    release=v3.read(Path(grant["release"]))
    custody.require(release["retirement_recovery_sha256"]==custody.reg() and
                    release["preserved_failed_return_sha256"]==custody.ORIG_RETURN and
                    release["retirement_scanner_sha256"]==custody.sha(SELF.parent/"safe_unused.py"),
                    "release did not authorize the exact retirement-only recovery")
    custody.validate_pregrant(release["pregrant_reader"],phase,key)
    return grant

def execute(phase,key,grant):
    import retire
    scope=custody.scope(phase,key)
    out=scope/"observed/physical"/(phase+"-"+key)
    if scope==custody.HERE:
        v3.save(out/"prior-owned-before.json",custody.validate_predelete())
    i=0
    def strict(paths):
        nonlocal i
        i+=1
        paths=list(paths)
        evidence={"phase":phase,"key":key,"call":i,"grant_sha256":custody.sha(scope/"grants"/(phase+"-"+key+".json")),
                  "roots":[{"path":str(p),"identity":v3.inventory(p)} for p in paths]}
        try:
            evidence["scan"]=manager.scan(paths)
            custody.validate_reader_report(evidence["scan"])
        except BaseException as e:
            evidence["scan"]=getattr(e,"retirement_scan",{"complete":False,"retained":True,"error_type":type(e).__name__})
            v3.save(out/f"reader-{i:02}.json",evidence)
            raise
        v3.save(out/f"reader-{i:02}.json",evidence)
    retire.unused=strict
    physical.execute(phase,key,grant)
    expected=4 if phase=="retire-pgo" else 1
    custody.require(i==expected,"wrong number of original ownership/reader gates")
    v3.save(out/"reader-closure.json",{"phase":phase,"key":key,"source_sha256":custody.sha(SELF),
            "original_retire_sha256":custody.sha(custody.STUDY/"retire.py"),"recovery_sha256":custody.reg(),
            "calls":[custody.sha(out/f"reader-{j:02}.json") for j in range(1,i+1)]})
    print("DEPINFO_RETIRE_READER_CLOSURE "+custody.sha(out/"reader-closure.json"),flush=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("phase",choices=("retire-pgo","retire-count","retire-native"));ap.add_argument("key")
    ap.add_argument("--worker-fd",type=int);ap.add_argument("--nonce");ap.add_argument("--parent",type=int)
    a=ap.parse_args()
    custody.verify_seal()
    custody.require(custody.allowed(a.phase,a.key) and a.key in physical.PHASES[a.phase],"unregistered retirement scope")
    scope=custody.scope(a.phase,a.key)
    if a.worker_fd is None:
        if scope==custody.HERE:custody.validate_predelete()
        # Keep the original subreaper, affinity, real namespace, quiet lease, full free-space
        # watchdog, nonce pipe, child session, euthanasia and reaping logic.
        selected_lease=contextlib.contextmanager(with_globals(v3.lease.__wrapped__,authority=authority))
        supervisor=with_globals(physical.run,__file__=str(SELF),HERE=scope,OUT=scope/"observed",lease=selected_lease)
        supervisor(a.phase,a.key)
    else:
        custody.require(os.getppid()==a.parent and os.getsid(0)==os.getpid() and
                        os.read(a.worker_fd,128).decode()==a.nonce and len(a.nonce)==64,"direct retirement worker refused")
        os.close(a.worker_fd)
        execute(a.phase,a.key,authority(a.phase,a.key))

if __name__=="__main__":main()
