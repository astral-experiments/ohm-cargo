# Cargo PGO head retirement and physical handoff

The published v3 four-driver trial keeps its complete-command schedule, four-bank design, executable identities, inputs, worker and scoring. The independently trained head and #269 drivers passed their original audits. The head compound job returned session 8861, chunk 57baf8, exit 1 before its first target rename. The earlier #269 cleanup failure and successful single-job repair remain distinct records. The next actual host owner was the unrelated historical replica test. Its supervisor returned 91078/296d24/0 after its own worker returned 1 with zero observations.

The head's original reader correctly rejected a live user manager while opening its task cwd. Three long-lived, single-thread login-service process generations blocked normal reads. The supplemental observer first uses the frozen unprivileged guard, which inspects every matching UID quartet and task. For an actual PermissionError only, it checks each exact registered PID, start tick, boot, comm, parent, UID quartet, task count, cgroup and capabilities. It calls root-owned, nonwritable absolute ls, readlink and cat through /usr/bin/sudo -n with a fixed option/path grammar against that PID. All target checks and all retirement remain unprivileged. The output retains only identities, membership and counts. It compares cwd, root, exe, every fd and both group/task maps, validates fd/task membership at both ends of the scan, and checks the identity around the reads. No interpreter or script runs as root. The earlier frozen rule for twice-verified singleton Z/X and vanished processes stays in force. Any other opaque live process blocks the operation. A short wait and a full rescan are allowed only when a previously opaque PID actually disappears. An observed reader, including a mapped or deleted-but-live target, blocks retirement.

The three original PGO target inodes remain recorded. A real full read-only diagnostic checked 22 live tasks, including 35, 7 and 12 FDs in the three services. Its role is diagnosis. The new allocation separately requires the independently verified latest historical return and tool wait plus a fresh complete external census under the exclusive native lock. The actual retirement still executes the original four inode-recorded scans, preserve/remerge assurance and disk watchdog. The four subsequent bank-retirement scopes use the same observer and actual before-grant check. Each non-retirement phase still calls the byte-identical v3 physical worker. An ownership failure retains its attempted stage, without automatic deletion, PGO reruns, or a grant for a later stage.

Run on the physical host only under the physical coordinator's authority. Registration and synthetic verifier are read-only.

```sh
P=/home/dev-user/.virtualenvs/openai/bin/python3
H=work/round18-compiler/depinfo-complete-command-v3-head-reader
C=work/round18-lab/depinfo-segment-v3-head-reader.py
taskset -c 29 "$P" -I -B "$C" --self-test
taskset -c 29 "$P" -I -B "$H/verify_dry.py" --before-grant
# Only the coordinator can launch this job after independent physical host clearance.
taskset -c 29 "$P" -I -B "$C" retire-head \
  --previous work/round18-cargo/edited-role-next/cells/replica-test/validated.json \
  --previous-sha fc7da1fabda1719d1992b9a670b1de00b17f9574200d724f3f90b1aae86af01b \
  --previous-session 91078 --previous-chunk 296d24 --previous-exit 0
```

For each later segment, use the actual most recent verified outer return and wait in the same five arguments. Successful receipts land in work/round18-lab/depinfo-v3-head-reader-segments. The head's new physical endpoint lands under this package's observed/physical/retire-pgo-head. Later physical endpoints remain in the v3 study. A pre-seed opening below 180 GiB prevents four-bank allocation even if head retirement succeeds. The separate 120 GiB floor remains active throughout.
