"""Immutable two-failure prefix and one pre-rename Cargo-head recovery; science stays in v3."""
import hashlib,importlib.util,json,os,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
STUDY=HERE.with_name('depinfo-complete-command-v3')
PRIOR=HERE.with_name('depinfo-complete-command-v3-retire-recovery')
WORK=HERE.parents[1];LAB=WORK/'round18-lab'
COORD=LAB/'depinfo-segment-v3-head-reader.py'
PREV_COORD=LAB/'depinfo-segment-v3-retire-recovery.py'
OLD=LAB/'depinfo-v3-retire-recovery-segments/head-driver'
ROOT_RECEIPT=OLD/'failure.json'
ROOT_WITNESS=LAB/'head-driver-return-and-historical-replica-handoff.json'
HIST=WORK/'round18-cargo/edited-role-next/cells/replica-test/validated.json'
HIST_WAIT=LAB/'depinfo-head-reader-historical-return.json'
V3='5fa7f3456fe8a3c5f002602c4bd71dc0a059ec1f2651ee4913e36c1e4ac53e1c'
FOLD=WITNESS='792557737fa3098302c62d7d1ddaa1532a5f076aa8ce441c081528b5f015c421'
ORIG_RETURN='ec81a2bb273d07b8bdb52042eb767cbf0f371b0a309ef10b336b8c7064c1d367'
ROOT_SHA='aac01396892b9b4e130a8aa5c78b9f40c2bb1c3e4873797f86046283023511a0'
CONTROL='ee124eed932d64b53ff674d9718bba61f4469e53073cf1f6a88be6d5290aba31'
BUILD='f8679401e9d0d37644dd50679e72adcefb6590289af5944aba21050f4fa900cf'
AUDIT='093bfd0509caee7bf56b1a8fe0f50b8dad9e7ca81a77b5cee16304b04cfdd2cf'
REQUEST='799817fc1e1d49429b75a394b915fb6adf2e10ccf0d54ad4f235a9e277cd442f'
OWNED={'generate.target':[64769,43804965],'training-target':[64769,43843429],'use.target':[64769,43845267]}
OLD_SCOPES=tuple((p,k) for k in ('pr269','head') for p in ('build','audit','retire-pgo'))
PYTHON='/home/dev-user/.virtualenvs/openai/bin/python3'
spec=importlib.util.spec_from_file_location('prior_retirement_custody',PRIOR/'custody.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
require,check,sha,read=prior.require,prior.check,prior.sha,prior.read
is_retirement,reader_roots=prior.is_retirement,prior.reader_roots
import manager
def reg():return sha(HERE/'recovery.json')
def scope(phase,key):return HERE if (phase,key)==('retire-pgo','head') else STUDY
def allowed(phase,key):
    return (phase,key)==('retire-pgo','head') or (phase in ('retire-count','retire-native') and key in ('initial','replica'))
def historical(v,wait,digest):
    import re
    require(set(wait)=={'session','chunk','exit','validated_sha256'} and wait['session']==91078 and wait['exit']==0 and
            type(wait['session']) is int and type(wait['exit']) is int and re.fullmatch(r'[0-9a-f]{6}',wait['chunk']) and
            wait['validated_sha256']==digest and {k:wait[k] for k in ('session','chunk','exit')}=={k:v[k] for k in ('session','chunk','exit')},
            'missing/incorrect actual historical replica-test tool wait or validated return')
def verify_seal():
    registration=read(HERE/'recovery.json')
    require(registration['original_registration_sha256']==V3 and registration['original_failed_head_segment_sha256']==FOLD and
            registration['original_supervisor']=={'session':8861,'chunk':'57baf8','exit':1},'wrong head-retirement registration')
    prior.verify_seal()
    for mapping in (registration['frozen_files'],read(HERE/'preserved-inputs.json')):
        for path,digest in mapping.items():check(WORK/path,digest)
    check(HIST,'fc7da1fabda1719d1992b9a670b1de00b17f9574200d724f3f90b1aae86af01b');check(HIST_WAIT,'c944fe8db59bf5e09c0c615acc01faf219033911c2443c9e3b13ac8a356bbdab')
    historical({'session':91078,'chunk':'296d24','exit':0},read(HIST_WAIT),sha(HIST))
    check(ROOT_RECEIPT,FOLD);check(ROOT_WITNESS,ROOT_SHA);w=read(ROOT_WITNESS);failed=read(ROOT_RECEIPT)
    require(not os.path.lexists(OLD/'returned.json') and (w['tool_session'],w['final_chunk'],w['actual_exit'])==(8861,'57baf8',1)
            and w['absent_owned_processes'] is True and w['failure_sha256']==FOLD and w['next_allowed']=='historical replica-test only' and
            w['physical_returns']==[['build',0,BUILD],['audit',0,AUDIT],['retire-pgo',1,ORIG_RETURN]],
            'old rejection or exact prior outer supervisor was changed')
    require(failed['coordinator_sha256']==sha(PREV_COORD) and failed['registration_sha256']==V3 and
            failed['original_failed_segment_sha256']==prior.FOLD and failed['retirement_recovery_sha256']==prior.reg() and
            failed['previous_return_sha256']==CONTROL and set(p.name for p in OLD.parent.iterdir())=={'retire-control','head-driver'},
            'preserved compound head prefix changed')
    old_control=OLD.parent/'retire-control/returned.json'
    check(old_control,CONTROL)
    subprocess.run([PYTHON,'-I','-B',str(PREV_COORD),'--verify-return',str(old_control),CONTROL],
                   stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,check=True)
    for row,(phase,code,digest) in zip(failed['phases'],w['physical_returns'],strict=True):
        label=phase+'-head';d=STUDY/'observed/physical'/label;raw=read(d/'returned.json')
        require(row==read(OLD/(label+'.json')) and row['phase']==phase and row['key']=='head' and row['exit']==code and
                row['physical_sha256']==sha(d/'returned.json')==digest and raw['worker_exit']==code and raw['final_owned']=={} and
                raw['grant_sha256']==row['grant_sha256']==sha(STUDY/'grants'/(label+'.json')) and
                raw['process_sha256']==sha(d/'process.log') and row['log_sha256']==sha(OLD/(label+'.log')),
                'old actual phase wait or audited driver changed: '+label)
    rejected=STUDY/'observed/physical/retire-pgo-head'
    first=read(rejected/'reader-01.json')
    require(first['roots']==reader_roots('retire-pgo','head')[0] and first['scan']['complete'] is False and
            first['scan']['retained'] is True and first['scan']['blocked_pid']=='3303870' and
            not (rejected/'reader-02.json').exists() and not (rejected/'reader-closure.json').exists(),
            'original first-of-four guard disposition changed')
    return registration
def validate_predelete():
    d=STUDY/'observed/drivers/head';o=read(d/'owned-reproducible.json')
    root=Path(o['record'])
    check(d/'candidate-request.json',REQUEST)
    require(o==read(ROOT_WITNESS)['intact_candidate_scratch'] and root==WORK/'round18-cargo/pgo/depinfo-complete-command-v3-head/records/head'
            and o['record_inode']==[64769,43797064] and o['children']==OWNED and o['build_request_sha256']==REQUEST,
            'different PGO record, request or owned targets')
    require(not any(os.path.lexists(d/name) for name in ('retirement-before.json','retired-targets.json')),'prior failure was not pre-rename')
    for path,token in [(root,o['record_inode']),*((root/n,t) for n,t in OWNED.items())]:
        s=path.lstat()
        require(path.is_dir() and path.resolve()==path and s.st_uid==os.getuid() and [s.st_dev,s.st_ino]==token and
                not os.path.lexists(path.with_name(path.name+'.retirement-in-progress')),'previously owned PGO directory changed')
    return {'record':str(root),'record_inode':o['record_inode'],'children':o['children']}
def validate_reader_report(scan):
    prior.validate_reader_report(scan);manager.validate(scan)
def validate_pregrant(value,phase,key):
    require(value['phase']==phase and value['key']==key and value['roots']==reader_roots(phase,key)[0] and
            value['manager_reader_sha256']==sha(HERE/'manager.py'),'unbound before-grant reader or roots')
    validate_reader_report(value['scan'])
def pregrant(phase,key):
    roots=reader_roots(phase,key)[0]
    def identities():
        return [[p.lstat().st_dev,p.lstat().st_ino] for p in [Path(r['path']) for r in roots]
                if p.is_dir() and p.resolve()==p and p.lstat().st_uid==os.getuid()]
    required=[r['identity'] for r in roots]
    require(identities()==required,'pregrant original roots missing or changed')
    report={'phase':phase,'key':key,'roots':roots,'manager_reader_sha256':sha(HERE/'manager.py'),
            'scan':manager.scan([Path(r['path']) for r in roots])}
    require(identities()==required,'roots changed during external census')
    validate_pregrant(report,phase,key)
    return report
