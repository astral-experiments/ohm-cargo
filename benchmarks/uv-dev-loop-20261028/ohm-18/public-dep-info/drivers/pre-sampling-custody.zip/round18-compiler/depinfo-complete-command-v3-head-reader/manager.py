"""Unprivileged retirement observer. Elevate only fixed, identity-checked read-only procfs operations."""
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import safe_unused

UIDS=[1000]*4
CGR='0::/user.slice/user-1000.slice/user@1000.service/init.scope'
PINS={3303870:(22288693,1,'systemd','0000000800000000',CGR),
      3303871:(22288695,3303870,'(sd-pam)','0000000000000000',CGR),
      3304032:(22288789,3303850,'sshd','0000000000000000','0::/user.slice/user-1000.slice/session-490.scope')}
def pin(proc):
    need(proc.parent==Path('/proc') and proc.name in {str(pid) for pid in PINS},'unregistered proc PID')
    return PINS[int(proc.name)]
BOOT='5a939a53-79ef-4ab0-8ada-c57a788992d3'
NAMES=('sudo','ls','cat','readlink')
def need(ok,message):
    if not ok:raise RuntimeError(message)
def identity(proc):
    """Only this single previously denied manager may receive elevated reads."""
    start,ppid,name,cap,cgroup=pin(proc)
    pid=int(proc.name)
    need(os.geteuid()==1000 and Path('/proc/1/comm').read_text().strip()=='systemd' and
         Path('/proc/sys/kernel/random/boot_id').read_text().strip()==BOOT,'wrong guest, uid or process')
    s=safe_unused.live_info(proc)
    fields=dict((a,b.strip()) for a,b in (x.split(':',1) for x in (proc/'status').read_text().splitlines() if ':' in x))
    need(s['pid']==s['tgid']==pid and s['uids']==UIDS and s['threads']==1 and s['start']==start and s['state'] not in ('Z','X') and
         fields['PPid']==str(ppid) and fields['Name']==name and fields['CapEff']==cap and (proc/'cgroup').read_text().strip()==cgroup and
         [p.name for p in (proc/'task').iterdir()]==[str(pid)],'denied PID is not the original living single-task user manager')
    return {'pid':pid,'start':start,'uids':s['uids'],'threads':1,'state':s['state'],'tgid':pid,'ppid':ppid,'name':name,'cgroup':cgroup,'cap_eff':cap}
def tools():
    for name in NAMES:
        p=Path('/usr/bin')/name
        for q in (p,*p.parents):
            st=q.lstat()
            need(q.resolve()==q and st.st_uid==0 and not st.st_mode&0o022 and
                 (stat.S_ISREG(st.st_mode) if q==p else stat.S_ISDIR(st.st_mode)), 'untrusted procfs read-only utility or ancestor')
def argv(proc,op,path):
    pin(proc)
    task=proc/'task'/proc.name
    term=str(path)
    if op=='ls' and path in (proc/'task',task/'fd'):args=['/usr/bin/ls','-1','-U','--color=never','--',term]
    elif op=='cat' and path in (proc/'maps',task/'maps'):args=['/usr/bin/cat','--',term]
    elif op=='readlink' and (path in [task/x for x in ('cwd','root','exe')] or
             path.parent==task/'fd' and path.name.isascii() and path.name.isdigit() and str(int(path.name))==path.name):
        args=['/usr/bin/readlink','-z','--',term]
    else:raise RuntimeError('unregistered root executable or proc path')
    return ['/usr/bin/sudo','-n','--',*args]
def call(proc,op,path):
    # Never invoke a shell, interpreter, mutable script, ls -L, or utility supplied by PATH.
    args=argv(proc,op,path)
    identity(proc)
    p=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=4,
                     cwd='/',env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},check=False)
    need(p.returncode==0,'read-only proc utility refused or a proc entry changed')
    return p.stdout
def ids(data):
    words=data.splitlines()
    need(all(x.isascii() and x.isdigit() and str(int(x)).encode()==x for x in words) and len(words)==len(set(words)),
         'invalid task/fd inventory')
    return sorted(int(x) for x in words)
def checked(value,paths):
    value=value.removesuffix(b' (deleted)')
    need(not any(value==p or value.startswith(p+b'/') for p in paths),'live manager references an owned retirement path')
def run_readers(proc,paths,command=call,who=identity):
    pid=int(proc.name);task=proc/'task'/proc.name
    before=who(proc)
    encoded=[os.fsencode(p) for p in paths]
    need(ids(command(proc,'ls',proc/'task'))==[pid],'task inventory changed')
    fds=ids(command(proc,'ls',task/'fd'))
    for path in [*(task/n for n in ('cwd','root','exe')),*(task/'fd'/str(fd) for fd in fds)]:
        body=command(proc,'readlink',path)
        need(body.endswith(b'\x00') and len(body)>1 and body.count(b'\x00')==1,'incomplete proc readlink result')
        checked(body[:-1],encoded)
    ranges=[]
    for path in (proc/'maps',task/'maps'):
        raw=command(proc,'cat',path)
        need(bool(raw) and raw.endswith(b'\n'),'missing or truncated process maps')
        count=0
        for line in raw.splitlines():
            fields=line.split(None,5)
            need(len(fields)>=5 and b'-' in fields[0] and b':' in fields[3],'invalid map record')
            if len(fields)==6 and fields[5].startswith(b'/'):
                checked(fields[5],encoded)
            count+=1
        ranges.append(count)
    need(ids(command(proc,'ls',task/'fd'))==fds and ids(command(proc,'ls',proc/'task'))==[pid],'fd or task set changed during privileged census')
    after=who(proc)
    need({k:v for k,v in before.items() if k!='state'}=={k:v for k,v in after.items() if k!='state'},
         'manager identity changed across proc inspection')
    return {'identity':before,'end_state':after['state'],'task_views':1,'fd_links':len(fds),'fixed_links':3,
            'group_and_task_map_counts':ranges,'fd_set_rechecked':True,'target_matches':0}
def scan_once(paths):
    results=[]
    blocked=[]
    def reader(proc,expected):
        try:
            safe_unused.read_links(proc,expected)
        except PermissionError:
            if proc.parent!=Path('/proc') or proc.name not in {str(pid) for pid in PINS}:
                blocked.append(safe_unused.live_info(proc));raise
            # The original scanner still handles any failure/terminal transition fail-closed.
            identity(proc)
            tools()
            results.append(run_readers(proc,expected))
    try:
        result=safe_unused.scan(paths,readers=reader)
    except Exception as e:
        if hasattr(e,'retirement_scan'):
            e.retirement_scan['bounded_privileged_readers']=results
            e.retirement_scan['opaque_identity']=next((x for x in reversed(blocked) if str(x['pid'])==e.retirement_scan.get('blocked_pid')),None)
        raise
    result['bounded_privileged_readers']=results
    return result
def scan(paths,attempt=scan_once,exists=os.path.lexists,wait=None):
    import time
    wait=time.sleep if wait is None else wait
    rejected=[]
    for number in range(3):
        try:
            result=attempt(paths)
            result['restarted_after_vanished_opaque']=rejected
            return result
        except Exception as exc:
            report=getattr(exc,'retirement_scan',{})
            info=report.get('opaque_identity')
            if number==2 or not info or str(exc)!=f"uninspectable live, changing or multi-thread process: pid {info['pid']}":
                raise
            proc=Path('/proc')/str(info['pid'])
            for _ in range(10):
                if not exists(proc):break
                wait(.2)
            if exists(proc):raise
            rejected.append({'rejected_prior_scan':report,'observed_absent_pid':info['pid']})
    raise RuntimeError('reader retry exhausted')

def validate(report):
    retries=report['restarted_after_vanished_opaque']
    need(isinstance(retries,list) and len(retries)<=2,'unbounded/invalid previous scan dispositions')
    for old in retries:
        r=old['rejected_prior_scan'];i=r['opaque_identity']
        need(r['complete'] is False and r['retained'] is True and r['error_type']=='RuntimeError' and
             r['blocked_pid']==str(old['observed_absent_pid'])==str(i['pid']) and i['pid']>0 and i['start']>=0,
             'previous scan did not reject the observed vanished generation')
    values=report.get('bounded_privileged_readers')
    need(isinstance(values,list) and len(values)<=len(PINS) and len({z['identity']['pid'] for z in values})==len(values),'invalid privileged reader roster')
    for x in values:
        z=x['identity']
        start,ppid,name,cap,cgroup=pin(Path('/proc')/str(z['pid']))
        need(z['pid']==z['tgid'] and z['start']==start and z['uids']==UIDS and z['threads']==1 and
             z['ppid']==ppid and z['name']==name and z['cgroup']==cgroup and z['cap_eff']==cap and
             z['state'] not in ('Z','X') and x['end_state'] not in ('Z','X') and
             x['fixed_links']==3 and x['task_views']==1 and x['target_matches']==0 and x['fd_set_rechecked'] is True and
             type(x['fd_links']) is int and x['fd_links']>=0 and len(x['group_and_task_map_counts'])==2 and
             all(type(n) is int and n>0 for n in x['group_and_task_map_counts']),
             'unproved privileged process or incomplete reader evidence')
