"""Mechanical resource-only successor over the last immutable coordinator."""
from pathlib import Path
import hashlib,sys
here=Path(__file__).resolve().parent;lab=here.parents[1]/'round18-lab'
src=lab/'depinfo-segment-v3-head-reader.py'
assert hashlib.sha256(src.read_bytes()).hexdigest()=='6c1e62fa914c51ebe8c49b050edc5d8eb38d87050c0752bb07e9e3b822596671'
s=src.read_text()
def r(a,b,n=1):
    global s
    assert s.count(a)==n,(a,s.count(a),n)
    s=s.replace(a,b)
r('repair_root=study.with_name("depinfo-complete-command-v3-head-reader")','repair_root=study.with_name("depinfo-complete-command-v3-ssh-reader")')
r('import custody as repair','import custody as repair\nimport journal')
r('segments=("retire-head","functional","count-initial","count-replica","native-initial","native-replica")',
  'segments=("retire-head","functional","count-initial","cleanup-count-initial","count-replica","cleanup-count-replica","native-initial","cleanup-native-initial","native-replica","cleanup-native-replica")')
r('receipts=lab/"depinfo-v3-head-reader-segments"','receipts=lab/"depinfo-v3-ssh-reader-segments"')
r('    mode,co=segment.split("-")','''    if segment.startswith("cleanup-"):
        _,mode,co=segment.split("-")
        return [("retire-"+mode,co,45)]
    mode,co=segment.split("-")''')
r('for prefix in ("prepare","admit","sample","retire")','for prefix in ("prepare","admit","sample")')
r('depinfo-complete-release-v3-head-reader-', 'depinfo-complete-release-v3-ssh-reader-')
r('"depinfo-complete-command-v3-head-reader/retirement_runner.py",','"depinfo-complete-command-v3-head-reader/retirement_runner.py","depinfo-complete-command-v3-ssh-reader/retirement_runner.py",')
r('''    if name=="retire-head":
        require(prev==repair.HIST and v["historical_outer_wait_sha256"]==sha(repair.HIST_WAIT),"wrong historical predecessor")
        repair.historical(v["previous_supervisor"],read(repair.HIST_WAIT),digest)
        peer_return(prev,"cargo","replica-test")''','''    if journal.known(prev):
        journal.wait_for(prev,digest,v["previous_supervisor"],None)
    if name=="retire-head":
        require(journal.known(prev) and (prev==journal.FIRST or prev.parent.parent.name==name) and
                v["historical_outer_wait_sha256"]==sha(repair.HIST_WAIT),"wrong historical/failed-preflight chain")
        peer_return(repair.HIST,"cargo","replica-test")''')
r('''    for p,kind,key in peers():
        if p.exists():''','''    result[journal.FIRST]=journal.valid_zero(journal.FIRST)
    if journal.ZERO.is_dir():
        for p in journal.ZERO.glob("*/*/zero.json"):result[p]=journal.valid_zero(p)
    for p,kind,key in peers():
        if p.exists():''')
r('    if p==repair.ROOT_RECEIPT:\n        require(digest==repair.WITNESS', '    if journal.known(p):\n        stamp=journal.valid_zero(p)\n    elif p==repair.ROOT_RECEIPT:\n        require(digest==repair.WITNESS')
r('            exit_code==0,','            exit_code in (0,1),')
r('    verify_handoff(prev,digest,latest=True)','''    verify_handoff(prev,digest,latest=True)
            if journal.known(prev):
                require((prev==journal.FIRST and a.segment=="retire-head") or
                        (prev!=journal.FIRST and prev.parent.parent.name==a.segment),"zero-grant predecessor is for a different phase")
                journal.wait_for(prev,digest,provenance,new)
            else:require(provenance["exit"]==0,"nonzero tool return is allowed only for the exact admitted zero-grant attempt")''')
r('''                require(prev==repair.HIST,"historical replica-test actually owned the host after the failed head")
                repair.historical(provenance,read(repair.HIST_WAIT),digest)''','''                require(journal.known(prev),"the latest failed no-grant intake is mandatory after the historical test")
                peer_return(repair.HIST,"cargo","replica-test")''')
r('''                        certificate["pregrant_reader"]=repair.pregrant(phase,key)''','''                        try:certificate["pregrant_reader"]=repair.pregrant(phase,key)
                        except BaseException as denied:
                            journal.census_failure(logs,phase,key,denied,physical_paths(phase,key),new)
                            raise''')
r('''            new(logs/"failure.json",{**history,"error":repr(exc),"failure_ns":time.time_ns()})
            raise''','''            new(logs/"failure.json",{**history,"error":repr(exc),"failure_ns":time.time_ns()})
            journal.park(logs,a.segment,order,history,physical_paths,new)
            raise''')
dest=lab/'depinfo-segment-v3-ssh-reader.py'
if sys.argv[1:]==['--verify']:assert dest.read_text()==s
else:
    with dest.open('x') as f:f.write(s)
