"""Checks real immutable metadata and old vs new physical order. Does not acquire a lease or issue a grant."""
import importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import custody as c,journal as j,manager
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x);return x
co=module('new_coordinator',c.COORD);prev=module('earlier_coordinator',c.LAB/'depinfo-segment-v3-head-reader.py')
c.verify_seal();j.wait_for(j.FIRST,j.FIRST_HASH,j.FIRST_WAIT,None);co.peer_return(c.HIST,'cargo','replica-test')
old=[(p,k,m) for x in prev.segments for p,k,m in prev.phases(x)]
new=[(p,k,m) for x in co.segments for p,k,m in co.phases(x)]
assert old==new and len(new)==18
assert all(len(co.phases(n))==1 and co.phases(n)[0][0].startswith('retire-') for n in j.NAMES)
assert co.SCHEDULE==prev.SCHEDULE and co.REG==prev.REG
co.verify_handoff(j.FIRST,j.FIRST_HASH,False)
if sys.argv[1:]==['--before-grant']:
    assert co.expected_progress('retire-head')==()
    co.verify_handoff(j.FIRST,j.FIRST_HASH,True)
    c.validate_predelete()
r=c.read(HERE/'guest-census.json')['observed'];c.validate_reader_report(r['scan'])
assert r['qualified_ssh_workers']==[3304032,3313438] and r['owned']==c.OWNED
f=c.read(HERE/'guest-final.json')['observed'];c.validate_reader_report(f['scan'])
assert 3313438 in f['qualified_ssh_workers'] and f['owned']==c.OWNED
print(json.dumps({'physical_phases':new,'same_as_previous':True,'failed_zero':j.FIRST_WAIT,'guest_census_live':r['scan']['checked_live'],
                  'source_schedule':co.SCHEDULE,'issued_grants':0},sort_keys=True))
