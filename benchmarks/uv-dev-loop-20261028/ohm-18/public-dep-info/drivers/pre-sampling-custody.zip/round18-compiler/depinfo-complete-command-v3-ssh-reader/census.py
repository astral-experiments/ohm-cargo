"""Read-only benchmark-guest diagnostic. Record no unrelated fd names, mapping contents or commands."""
import json,os,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import manager
P=HERE.with_name('depinfo-complete-command-v3')/'observed/drivers/head/owned-reproducible.json'
if __name__=='__main__':
 o=json.loads(P.read_bytes())
 roots=[Path(o['record'])/n for n in o['children']]
 def current():
  return [[p.lstat().st_dev,p.lstat().st_ino] for p in roots]
 assert current()==list(o['children'].values()) and all(p.resolve()==p and p.lstat().st_uid==1000 for p in roots)
 s=manager.scan(roots);manager.validate(s);assert current()==list(o['children'].values())
 print(json.dumps({'owned':o['children'],'qualified_ssh_workers':[x['identity']['pid'] for x in s['bounded_privileged_readers'] if 'ssh_service' in x],
                   'real_guest_pid1':Path('/proc/1/comm').read_text().strip(),'scan':s},sort_keys=True))
