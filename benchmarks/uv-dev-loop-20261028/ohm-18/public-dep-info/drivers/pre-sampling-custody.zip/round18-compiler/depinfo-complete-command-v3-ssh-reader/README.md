# SSH reader and append-only zero-grant retry

The original head worker and audit succeeded. Its first deletion guard refused a live reader and returned 8861/57baf8/1. The first repaired preflight returned 91453/3e579b/1 before any grant, physical supervisor or rename. The original historical predecessor 91078/296d24/0 and its nested exclusion are verified separately. All original inputs, scientific phases and raw evidence remain in place.

The exact two singleton systemd and sd-pam generations retain their previous membership checks. A living user SSH worker additionally needs all four UIDs equal to 1000, zero capabilities, one task, a numbered session scope for user 1000, a single-task UID-0 sshd monitor in the same scope, and that monitor's direct parent must be the original root service master PID 584757, start 4016607, on the sealed guest. All three exe links must point to the same canonical root-owned, nonwritable installed sshd, with its pinned file identity and SHA-256. The chain is rechecked during individual reads, and all three executable links before and after the leaf census. Root service processes get only their restricted exe readlink for this verification. The leaf receives the full registered set of fd, cwd, root, exe and both maps checks. Other live opaque processes block the operation. A previously observed opaque generation may trigger two full restarts at most, only after its numeric PID is actually gone. The chain does not admit an owned open or mapped file.

The per-cohort last physical cleanup now has an independent outer dispatcher return so a future zero-grant cleanup rejection cannot consume its already-completed samples. The ordered list of all 18 v3 physical (phase,key,duration) triples is byte-for-byte equal as parsed. A zero-grant preflight is journaled under depinfo-v3-ssh-reader-zero/<segment>/NNNNN only when the complete reader rejected, all three release/grant/worker paths are absent and no physical row or phase was started. Existing failed records remain separately named. Use the latest zero.json and the actual outer session/chunk/exit 1 to make another independent cleanup-only attempt. Intrinsic correctness failures, any issued release and started physical work cannot take this route. Every new attempt repeats all the original physical and resource gates. A fully blocked live process leaves the old targets intact.

The physical coordinator can launch the first separately registered retry with the following form.

```sh
PY=/home/dev-user/.virtualenvs/openai/bin/python3
CO=work/round18-lab/depinfo-segment-v3-ssh-reader.py
taskset -c 29 "$PY" -I -B "$CO" retire-head \
  --previous work/round18-lab/depinfo-v3-head-reader-segments/retire-head/failure.json \
  --previous-sha 555061e2bf6a1d4535450e93a471f8d7badb6205fbf6754ddb8e0beea39ea769 \
  --previous-session 91453 --previous-chunk 3e579b --previous-exit 1
```

After a successful retire-head, use the actual latest returned outer receipt for functional, count-initial, cleanup-count-initial, count-replica, cleanup-count-replica, native-initial, cleanup-native-initial, native-replica and cleanup-native-replica. Original IUT, thresholds, jobs, budgets, sources, toolchain, content audits and 120/180 GiB controls all remain binding.
