"""Append-only, zero-grant reader denials. No physical worker or sample can qualify for this path."""
import os,re,time
from pathlib import Path
import custody as repair

ZERO=repair.LAB/'depinfo-v3-ssh-reader-zero'
FIRST=repair.LAB/'depinfo-v3-head-reader-segments/retire-head/failure.json'
FIRST_HASH='555061e2bf6a1d4535450e93a471f8d7badb6205fbf6754ddb8e0beea39ea769'
FIRST_WAIT={'session':91453,'chunk':'3e579b','exit':1}
NAMES=('retire-head','cleanup-count-initial','cleanup-count-replica','cleanup-native-initial','cleanup-native-replica')
def known(p):
    return p==FIRST or (p.parent.parent.parent==ZERO and p.parent.parent.name in NAMES and
                         re.fullmatch(r'[0-9]{5}',p.parent.name) and p.name=='zero.json')
def check_first():
    r=repair;h=FIRST.parent;v=r.read(FIRST);r.check(FIRST,FIRST_HASH)
    r.require(set(p.name for p in h.iterdir())=={'intake.json','failure.json'} and v['phases']==[] and v['segment']=='retire-head' and
        v['previous_return']==str(r.HIST) and v['previous_return_sha256']==r.sha(r.HIST) and '3313438' in v['error'] and
        v['registration_sha256']==r.V3 and v['retirement_recovery_sha256']==r.PREV_RECOVERY and
        not any(os.path.lexists(p) for p in (r.PREV_READER/'grants',r.PREV_READER/'observed',
                          r.LAB/'depinfo-complete-release-v3-head-reader-retire-pgo-head.json')),'original intake was not a real zero-grant refusal')
    r.historical(v['previous_supervisor'],r.read(r.HIST_WAIT),r.sha(r.HIST));return v['failure_ns']
def valid_zero(p):
    r=repair;r.require(known(p),'unknown zero-grant family')
    if p==FIRST:return check_first()
    token=r.read(p);folder=p.parent;phase=token['phase'];key=token['key'];stage=p.parent.parent.name
    r.require(set(x.name for x in folder.iterdir()) in ({'intake.json','failure.json','pregrant-denied.json','zero.json'},
              {'intake.json','failure.json','pregrant-denied.json','zero.json','tool-return.json'}),'extra/missing zero-grant contents')
    for name in ('intake','failure','pregrant-denied'):r.check(folder/(name+'.json'),token[name+'_sha256'])
    failure=r.read(folder/'failure.json');intake=r.read(folder/'intake.json');refusal=r.read(folder/'pregrant-denied.json')
    expected=('retire-pgo','head') if stage=='retire-head' else ('retire-'+stage.split('-')[1],stage.split('-')[2])
    r.require(stage in NAMES and (phase,key)==expected and r.allowed(phase,key) and
              token['registration_sha256']==r.reg() and token['authorization_written'] is False and token['child_started'] is False and
              failure['phases']==intake['phases']==[] and failure['segment']==intake['segment']==stage and
              failure['registration_sha256']==intake['registration_sha256']==r.V3 and token['failure_ns']==failure['failure_ns'] and
              refusal['phase']==phase and refusal['key']==key and refusal['reader']['complete'] is False and
              refusal['reader']['retained'] is True and refusal['roots']==r.reader_roots(phase,key)[0] and
              refusal['scope_absent']==[True,True,True] and refusal['error']==failure['error'],'not a before-grant reader denial')
    return token['failure_ns']
def wait_for(p,digest,v,write):
    r=repair;r.check(p,digest);valid_zero(p)
    observed={k:v[k] for k in ('session','chunk','exit')}
    r.require(type(observed['session']) is int and observed['session']>0 and re.fullmatch(r'[0-9a-f]{6}',observed['chunk']) and
              type(observed['exit']) is int and observed['exit']==1,'zero-grant retry requires actual rejected supervisor wait')
    if p==FIRST:
        r.require(observed==FIRST_WAIT,'different first rejected intake wait');return
    record={**observed,'zero_sha256':digest};target=p.with_name('tool-return.json')
    if write and not os.path.lexists(target):write(target,record)
    r.require(target.is_file() and not target.is_symlink() and r.read(target)==record,'new zero-grant wait missing or inconsistent')
def census_failure(logs,phase,key,exc,paths,write):
    report=getattr(exc,'retirement_scan',None)
    if isinstance(report,dict) and report.get('complete') is False and report.get('retained') is True:
        write(logs/'pregrant-denied.json',{'phase':phase,'key':key,'error':repr(exc),'reader':report,'roots':repair.reader_roots(phase,key)[0],
                                          'scope_absent':[not os.path.lexists(p) for p in paths]})
def park(logs,segment,order,history,paths,write):
    r=repair
    if segment not in NAMES or len(order)!=1 or history['phases'] or not (logs/'pregrant-denied.json').is_file():return
    phase,key,_=order[0]
    if any(os.path.lexists(p) for p in paths(phase,key)):return
    if {p.name for p in logs.iterdir()}!={'intake.json','failure.json','pregrant-denied.json'}:return
    # The root coordinator holds its outer allocation lock; only a pre-grant reader error reaches this transition.
    parent=ZERO/segment;parent.mkdir(parents=True,exist_ok=True)
    sequential=sorted(x.name for x in parent.iterdir())
    r.require(sequential==[f'{i:05}' for i in range(1,len(sequential)+1)],'zero-grant journal gap')
    dest=parent/f'{len(sequential)+1:05}';r.require(not os.path.lexists(dest),'attempt destination collision')
    data={'registration_sha256':r.reg(),'phase':phase,'key':key,'authorization_written':False,'child_started':False,
          'failure_ns':r.read(logs/'failure.json')['failure_ns'],
          **{n+'_sha256':r.sha(logs/(n+'.json')) for n in ('intake','failure','pregrant-denied')}}
    write(logs/'zero.json',data);logs.rename(dest);valid_zero(dest/'zero.json')
    print('Retained zero-grant attempt',dest/'zero.json',r.sha(dest/'zero.json'),flush=True)
