"""Small process-class, retry and zero-grant tests. All inputs are synthetic except sealed, read-only references."""
from pathlib import Path
import copy,json,sys,tempfile
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import custody as c,manager as m,journal as j
cases=[]
def test(name,f,fail=False):
    try:f()
    except (RuntimeError,ValueError,AssertionError):
        if fail:cases.append(name);return
        raise
    if fail:raise AssertionError('expected rejection '+name)
    cases.append(name)
def chain():
    master=dict(pid=m.MASTER,tgid=m.MASTER,threads=1,uids=[0]*4,name='sshd',ppid=1,start=m.MASTER_START,
                state='S',cgroup='0::/system.slice/ssh.service',cap_eff=m.ROOTCAP)
    parent={**master,'pid':923,'tgid':923,'ppid':m.MASTER,'start':m.MASTER_START+10,'cgroup':'0::/user.slice/user-1000.slice/session-345.scope'}
    leaf={**parent,'pid':924,'tgid':924,'ppid':923,'start':m.MASTER_START+20,'uids':[1000]*4,'cap_eff':'0'*16}
    return leaf,parent,master
test('verified SSH service chain',lambda:m.validate_ssh(*chain()))
for i,key,value in [(0,'uids',[1000,0,0,1000]),(0,'name','codex-linux-san'),(0,'cgroup','0::/system.slice/ssh.service'),
                    (0,'threads',2),(0,'ppid',33),(0,'cap_eff',m.ROOTCAP),(0,'start',2),(1,'uids',[1000]*4),
                    (1,'cgroup','0::/user.slice/user-1000.slice/session-77.scope'),(1,'ppid',1),(2,'start',1),(2,'pid',999),(2,'state','Z')]:
    def f(i=i,key=key,value=value):
        d=chain();d[i][key]=value;m.validate_ssh(*d)
    test(f'wrong chain member {i} {key}',f,True)
def cert():
    leaf,parent,master=chain()
    return {'identity':leaf,'end_state':'S','target_matches':0,'fixed_links':3,'fd_links':18,'fd_set_rechecked':True,'task_views':1,
            'group_and_task_map_counts':[12,12],'ssh_service':{'parent':parent,'master':master,'sshd_sha256':m.SSH_SHA,'three_exe_links_rechecked':True}}
def verify(roster):
    m.validate({'restarted_after_vanished_opaque':[],'bounded_privileged_readers':roster})
test('SSH roster',lambda:verify([cert()]))
for n in ('sshd_sha256','three_exe_links_rechecked'):
    d=cert();d['ssh_service'][n]=False;test('reject '+n,lambda d=d:verify([d]),True)
d=cert();d['target_matches']=1;test('reject real owned file',lambda:verify([d]),True)
test('reject double-counted leaf',lambda:verify([cert(),cert()]),True)
def denied():
    exc=RuntimeError('uninspectable live, changing or multi-thread process: pid 123')
    exc.retirement_scan={'complete':False,'retained':True,'blocked_pid':'123','error_type':'RuntimeError','opaque_identity':{'pid':123,'start':7}};return exc
def run(seq):
    def attempt(_):
        x=seq.pop(0)
        if isinstance(x,Exception):raise x
        return x
    return attempt
test('opaque live retained',lambda:m.scan([],run([denied()]),exists=lambda p:True,wait=lambda n:None),True)
def rerun():
    result=m.scan([],run([denied(),{'bounded_privileged_readers':[],'complete':True}]),exists=lambda p:False,wait=lambda n:None)
    assert result['restarted_after_vanished_opaque'][0]['observed_absent_pid']==123;m.validate(result)
test('vanished causes complete real-new-scan requirement',rerun)
def jf():
    with tempfile.TemporaryDirectory() as tmp:
        base=Path(tmp);j.ZERO=base/'zero'
        orig=c.reader_roots;c.reader_roots=lambda *args:[[]]
        oldreg=c.reg;c.reg=lambda:'reg'
        def wr(p,data):
            with p.open('x') as f:json.dump(data,f,sort_keys=True)
        try:
            def construct(name,template,grant=False,realrow=False):
                logs=base/name;logs.mkdir();paths=[logs.parent/(name+'-'+x) for x in ['release','grant','physical']]
                if grant:paths[0].write_text('g')
                history={'segment':'retire-head','phases':[1] if realrow else [],'registration_sha256':c.V3}
                ex=denied();wr(logs/'intake.json',history);j.census_failure(logs,'retire-pgo','head',ex,paths,wr)
                wr(logs/'failure.json',{**history,'error':repr(ex),'failure_ns':1091})
                j.park(logs,'retire-head',[('retire-pgo','head',15)],history,lambda *a:paths,wr)
                return logs
            p=construct('attempt1',{});assert not p.exists()
            p=construct('attempt2',{});assert not p.exists()
            for n in (1,2):
                z=j.ZERO/'retire-head'/f'{n:05}'/'zero.json'
                assert j.valid_zero(z)==1091
                v={'session':n,'chunk':f'{n:06x}','exit':1};j.wait_for(z,c.sha(z),v,wr);j.wait_for(z,c.sha(z),v,None)
                test('wrong future zero wait '+str(n),lambda:j.wait_for(z,c.sha(z),{**v,'exit':0},None),True)
            assert construct('has-grant',{},grant=True).is_dir()
            assert construct('has-row',{},realrow=True).is_dir()
        finally:c.reader_roots=orig;c.reg=oldreg
test('two separately retained denials and no auto-retry after any release or row',jf)
print(json.dumps({'tests':cases,'count':len(cases),'physical_work':False,'privileged_execution':False},sort_keys=True))
