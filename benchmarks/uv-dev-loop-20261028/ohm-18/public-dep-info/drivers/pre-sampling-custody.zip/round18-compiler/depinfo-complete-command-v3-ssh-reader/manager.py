"""Read sensitive procfs data only through the frozen three fixed root-owned read-only programs."""
from pathlib import Path
from types import FunctionType
import hashlib,importlib.util,os,re,stat,subprocess,sys
HERE=Path(__file__).resolve().parent
OLD=HERE.with_name('depinfo-complete-command-v3-head-reader')
sys.path.insert(0,str(HERE))
import safe_unused
spec=importlib.util.spec_from_file_location('prior_pinned_reader',OLD/'manager.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
need=old.need
FIXED={3303870,3303871}
MASTER=584757
MASTER_START=4016607
ROOTCAP='000001ffffffffff'
SSHD=Path('/usr/sbin/sshd')
SSH_SHA='95b291d957f87dd200796c4986c97b6f4d970e26ad620ec9174e69c13ec5c137'
SESSION=re.compile(r'0::/user\.slice/user-1000\.slice/session-[1-9][0-9]*\.scope')
def canonical(proc):
    need(proc.parent==Path('/proc') and proc.name.isascii() and proc.name.isdigit() and
         int(proc.name)>1 and str(int(proc.name))==proc.name,'noncanonical process path')
    return int(proc.name)
def data(proc):
    pid=canonical(proc);x=safe_unused.live_info(proc)
    s=dict((a,b.strip()) for a,b in (v.split(':',1) for v in (proc/'status').read_text().splitlines() if ':' in v))
    return {**x,'ppid':int(s['PPid']),'name':s['Name'],'cap_eff':s['CapEff'],'cgroup':(proc/'cgroup').read_text().strip()}
def validate_ssh(leaf,parent,master):
    for d in (leaf,parent,master):
        need(d['state'] not in ('Z','X') and d['pid']==d['tgid'] and d['threads']==1 and d['name']=='sshd',
             'SSH chain is not single-task, living sshd')
    need(leaf['uids']==[1000]*4 and leaf['cap_eff']=='0'*16 and SESSION.fullmatch(leaf['cgroup']) and
         leaf['ppid']==parent['pid'] and leaf['cgroup']==parent['cgroup'] and parent['ppid']==master['pid'] and
         master['pid']==MASTER and master['start']==MASTER_START and master['ppid']==1 and master['cgroup']=='0::/system.slice/ssh.service' and
         master['uids']==parent['uids']==[0]*4 and master['cap_eff']==parent['cap_eff']==ROOTCAP and
         master['start']<parent['start']<=leaf['start'] and len({leaf['pid'],parent['pid'],master['pid']})==3,
         'SSH certificate chain, uid/capabilities, cgroup or daemon generation changed')
def chain(proc):
    need(Path('/proc/1/comm').read_text().strip()=='systemd' and os.geteuid()==1000 and
         Path('/proc/sys/kernel/random/boot_id').read_text().strip()==old.BOOT,'wrong guest or identity')
    leaf=data(proc)
    # An untrusted process cannot choose an arbitrary root process for inspection.
    need(leaf['name']=='sshd' and leaf['uids']==[1000]*4 and SESSION.fullmatch(leaf['cgroup']) and leaf['ppid']>1 and leaf['cap_eff']=='0'*16,
         'opaque live process is outside the SSH service class')
    parent=data(Path('/proc')/str(leaf['ppid']));master=data(Path('/proc')/str(MASTER))
    validate_ssh(leaf,parent,master)
    for d in (leaf,parent,master):
        need([p.name for p in (Path('/proc')/str(d['pid'])/'task').iterdir()]==[str(d['pid'])],'SSH task roster changed')
    return leaf,parent,master
def stable(chain_):
    return [{k:v for k,v in r.items() if k!='state'} for r in chain_]
def trusted_binary():
    for q in (SSHD,*SSHD.parents):
        s=q.lstat()
        need(q.resolve()==q and s.st_uid==0 and not s.st_mode&0o022 and
             (stat.S_ISREG(s.st_mode) if q==SSHD else stat.S_ISDIR(s.st_mode)),'untrusted SSH image/ancestor')
    st=SSHD.stat()
    with SSHD.open('rb') as f:
        need([st.st_dev,st.st_ino,st.st_size]==[64769,24527,925512] and os.fstat(f.fileno()).st_ino==st.st_ino and
             hashlib.file_digest(f,'sha256').hexdigest()==SSH_SHA,'physical SSH executable changed')
def with_globals(fn,**updates):
    return FunctionType(fn.__code__,{**fn.__globals__,**updates},fn.__name__,fn.__defaults__,fn.__closure__)
def ssh_reader(proc,paths):
    expected=chain(proc);trusted_binary();old.tools()
    def checked():
        current=chain(proc);need(stable(current)==stable(expected),'SSH process identity changed during census')
        return current
    # The initial public process chain permits only readlink on the three registered exe links.
    # No root-owned daemon or root monitor receives fd, cwd, maps or directory access.
    def exe_links():
        checked()
        for r in expected:
            pid=str(r['pid']);live=Path('/proc')/pid/'task'/pid/'exe'
            out=subprocess.run(['/usr/bin/sudo','-n','--','/usr/bin/readlink','-z','--',str(live)],stdin=subprocess.DEVNULL,
                  stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,cwd='/',env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},timeout=4)
            need(out.returncode==0 and out.stdout==os.fsencode(SSHD)+b'\0','SSH chain image does not resolve to the registered executable')
        checked()
    exe_links()
    def approved(p):
        need(p==proc,'only the authenticated leaf receives complete proc reads');return checked()[0]
    bounded_argv=with_globals(old.argv,pin=approved)
    command=with_globals(old.call,identity=approved,argv=bounded_argv)
    observed=old.run_readers(proc,paths,command,approved)
    exe_links()
    observed['ssh_service']={'parent':expected[1],'master':expected[2],'three_exe_links_rechecked':True,'sshd_sha256':SSH_SHA}
    return observed
def scan_once(paths):
    completed=[];blocked=[]
    def reader(proc,roots):
        try:safe_unused.read_links(proc,roots)
        except PermissionError:
            if proc.parent==Path('/proc') and proc.name in {str(p) for p in FIXED}:
                old.identity(proc);old.tools();completed.append(old.run_readers(proc,roots));return
            pid=safe_unused.live_info(proc)
            try:chain(proc)
            except (RuntimeError,PermissionError):
                blocked.append(pid);raise PermissionError('unrecognized opaque process')
            completed.append(ssh_reader(proc,roots))
    try:out=safe_unused.scan(paths,readers=reader)
    except Exception as exc:
        if hasattr(exc,'retirement_scan'):
            r=exc.retirement_scan;r['bounded_privileged_readers']=completed
            r['opaque_identity']=next((i for i in reversed(blocked) if str(i['pid'])==r.get('blocked_pid')),None)
        raise
    out['bounded_privileged_readers']=completed
    for info in blocked:
        if not os.path.lexists(Path('/proc')/str(info['pid'])):
            exc=RuntimeError(f"uninspectable live, changing or multi-thread process: pid {info['pid']}")
            exc.retirement_scan={**out,'complete':False,'retained':True,'opaque_identity':info,'blocked_pid':str(info['pid']),'error_type':'RuntimeError'}
            raise exc
    return out
def scan(paths,attempt=scan_once,exists=os.path.lexists,wait=None):
    import time
    wait=time.sleep if wait is None else wait
    rejected=[]
    for attempt_number in range(3):
        try:
            result=attempt(paths);result['restarted_after_vanished_opaque']=rejected
            return result
        except Exception as exc:
            report=getattr(exc,'retirement_scan',{})
            report['restarted_after_vanished_opaque']=list(rejected)
            info=report.get('opaque_identity')
            if attempt_number==2 or not info or str(exc)!=f"uninspectable live, changing or multi-thread process: pid {info['pid']}":raise
            proc=Path('/proc')/str(info['pid'])
            for _ in range(10):
                if not exists(proc):break
                wait(.2)
            if exists(proc):raise
            rejected.append({'rejected_prior_scan':{k:v for k,v in report.items() if k!='restarted_after_vanished_opaque'},'observed_absent_pid':info['pid']})
    raise RuntimeError('full reader restart exhausted')
def validate(scan):
    reports=scan['bounded_privileged_readers']
    need(isinstance(reports,list) and len(reports)==len({r['identity']['pid'] for r in reports}),'repeated or invalid proc certificate')
    fixed=[];ssh=[]
    for row in reports:
        if row['identity']['pid'] in FIXED:
            need('ssh_service' not in row,'non-SSH service lacks explicit original pin');fixed.append(row)
        else:ssh.append(row)
    old.validate({**scan,'bounded_privileged_readers':fixed})
    for row in ssh:
        d=row['identity'];c=row['ssh_service'];validate_ssh(d,c['parent'],c['master'])
        need(c['sshd_sha256']==SSH_SHA and c['three_exe_links_rechecked'] is True and row['end_state'] not in ('Z','X')
             and row['target_matches']==0 and row['task_views']==1 and row['fixed_links']==3 and row['fd_set_rechecked'] is True
             and type(row['fd_links']) is int and row['fd_links']>=0 and len(row['group_and_task_map_counts'])==2 and
             all(type(n) is int and n>0 for n in row['group_and_task_map_counts']),'incomplete SSH leaf reader')
