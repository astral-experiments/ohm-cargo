# Registered complete-command comparison

From the extracted root, python3 -I -B verify-registration.py checks the registration and all 70 named input hashes. The physical runner, exact patches, comparisons, model, schedule and prior control observations are under work/round18-compiler/depinfo-complete-command. Its README describes the host inputs and commands. Historical relative paths resolve from work/. This packet was sealed before building either new Cargo binary or collecting any measured command in this experiment.
