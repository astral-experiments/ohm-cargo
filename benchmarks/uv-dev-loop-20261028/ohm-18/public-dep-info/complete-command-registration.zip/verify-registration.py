import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
w=r/'work'
p=w/'round18-compiler/depinfo-complete-command/registered.json'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(p)=='a833e97451fb2e702ab1b345d6271854c2cb80c08bd8777aebf2024b049606e1'
v=json.loads(p.read_bytes())
assert len(v['immutable_files'])==70
for n,h in v['immutable_files'].items():
 f=(w/n).resolve(strict=True)
 assert f.is_relative_to(r) and sha(f)==h,n
print('Verified registered.json and all 70 immutable inputs.')
