# Ohm -18 Cargo dep-info study, prospective bank correction

This kit checks the exact v2-to-v3 source and protocol changes, the numerical scorer and the entire native assignment grid without running a compiler. It contains both complete local protocol directories, their original registration bytes, both root coordinator sources, the unified delta and a hash manifest. The 85 registered workspace inputs remain enumerated in the v3 registration. The existing external lab receipts, Cargo toolchains and uv checkout are needed for physical execution.

V3 keeps all 17,664 planned ordinary native Cargo commands and 192 instrumented Cargo commands, the selected instruction roles, the two edited uv checkouts and every original scientific gate. The only experimental change is which prepared target directory each driver uses in the normal native calls. Initial ranks one through four use banks named shipped, base, pr269 and head. The replica rotates these names by two ranks. Their names identify the four original directory inodes. Across either complete checkout, all four drivers visit all four real inodes equally.

The bank follows execution rank and checkout only. Under the conditional order test's enumerated reallocations, the two other Cargo drivers stay at their fixed ranks, and exchanging head/control changes their ranks while leaving every physical location in place. Bank-specific costs can be absorbed in the fixed slot observations. The experiment measures an average driver effect across those slots. Within each checkout it does not separately estimate rank and bank effects.

## Detached verification

Extract the zip to an empty directory. From its top level run the following commands.

```sh
python3 -I -B verify-delta.py
python3 -I -B protocols/depinfo-complete-command-v3/bank-selftest.py > fresh-selftest.json
cmp fresh-selftest.json protocols/depinfo-complete-command-v3/bank-selftest.json
```

The synthetic replay checks the full 17,664-row assignment, 96 mock raw command/bank receipts, four actual *empty temporary* directories and 35 deliberately malformed cases. It also compares the v2 and v3 numerical scorers on identical observations. There are no measured samples or Cargo build outputs in this preregistration.

## Physical use in the original workspace

Use the new source as `work/round18-lab/depinfo-segment-v3.proposed.py`. The superseded coordinator is included for comparison, and the active root can review the separate proposal. Its five possible segments are `drivers`, `count-initial`, `count-replica`, `native-initial` and `native-replica`. The root supplies the most recent real completed physical owner plus the actual outer tool return IDs, and issues each new grant just in time.

```sh
python3 -I -B work/round18-lab/depinfo-segment-v3.proposed.py --self-test
python3 -I -B work/round18-lab/depinfo-segment-v3.proposed.py SEGMENT \
  --previous PATH --previous-sha SHA256 --previous-session SESSION_ID \
  --previous-chunk CHUNK_ID --previous-exit EXIT_STATUS
```

After both native cohorts physically close, use `bank_replay.py initial` and `bank_replay.py replica` to check the physical directory observed immediately before and after every unchanged foreground timer, plus the actual parked return and binding to the prepared four-directory map. The standalone reader accepts a detached observed tree via `--observed PATH`. The full `rescore.all_results("native")` verifier requires these checks as well as the original product, behavior, roster, source, raw elapsed and six numerical checks.

The full-workspace `verify_amendment.py` also verifies every external predecessor and v3 registration input. The portable `verify-delta.py` checks the included source directories against both frozen hash manifests, the unchanged external identities, and the complete diff. The v1 registration (the earlier single-borrow correction) remains unmodified and is named by its SHA in v2 and v3.
