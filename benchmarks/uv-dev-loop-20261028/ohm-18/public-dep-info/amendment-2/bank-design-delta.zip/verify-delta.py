"""Validate a detached source delta kit without the guest, cargo, Git or runtime artifacts."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
V2="c5fdaa3d2f9fd771be67d462e80d0c96303e1326d61d7d22654f876d5cecd1f7"
V3="5fa7f3456fe8a3c5f002602c4bd71dc0a059ec1f2651ee4913e36c1e4ac53e1c"
LEGACY_COORD="15d569451ea3515517d988d0e4d4b51940a6eb3e11bf2c6d5e2c7e7344133168"
NEW_COORD="62b171555d8db3b739ce48a73cd51b234c9e0e82c988b32c16a179009d9db641"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check(state,message):
    if not state: raise ValueError(message)

def load(path):
    return json.loads(path.read_bytes())

def difference(left,right):
    if left.is_file() and right.is_file() and left.read_bytes()==right.read_bytes(): return ""
    a=left.read_text().splitlines(keepends=True) if left.is_file() else []
    b=right.read_text().splitlines(keepends=True) if right.is_file() else []
    old=left.relative_to(ROOT).as_posix() if a else "/dev/null"
    new=right.relative_to(ROOT).as_posix() if b else "/dev/null"
    return "".join(difflib.unified_diff(a,b,fromfile=old,tofile=new))

def main():
    m=load(ROOT/"manifest.json")
    for name,h in m["sha256"].items():check(digest(ROOT/name)==h,"changed packet member: "+name)
    src=ROOT/"protocols";a=src/"depinfo-complete-command-v2";b=src/"depinfo-complete-command-v3"
    check(digest(a/"registered.json")==V2 and digest(b/"registered.json")==V3,"unexpected scientific registration")
    for d in (a,b):
        reg=load(d/"registered.json")
        for name,h in reg["immutable_files"].items():
            prefix="round18-compiler/"+d.name+"/"
            if name.startswith(prefix):
                check(digest(d/name.removeprefix(prefix))==h,"protocol does not match scientist's original manifest")
    old=load(a/"registered.json");new=load(b/"registered.json")
    check(set(new)==set(old)|{"native_banking"} and all(old[k]==new[k] for k in old if k not in ("immutable_files","sealed_utc_ns","study")),"changed original scientific fields")
    for k,v in old["immutable_files"].items():
        if not k.startswith("round18-compiler/depinfo-complete-command-v2/"):
            check(new["immutable_files"].get(k)==v,"different external source or subject")
    c1=ROOT/"coordinator/depinfo-segment.py";c2=ROOT/"coordinator/depinfo-segment-v3.proposed.py"
    check(digest(c1)==LEGACY_COORD and digest(c2)==NEW_COORD,"unexpected physical coordinator")
    files=sorted({p.name for p in a.iterdir() if p.is_file()}|{p.name for p in b.iterdir() if p.is_file()})
    full="".join(difference(a/f,b/f) for f in files)+difference(c1,c2)
    check(full==(ROOT/"v2-to-v3.diff").read_text(),"whole source delta mismatch")
    check(load(b/"bank-design.json")==new["native_banking"],"bank map differs from registration")
    summary=load(b/"bank-selftest.json")
    check(len(summary["negative_controls"])==35 and summary["unchanged_scorer_contrasts_replayed"]==3,"missing synthetic evidence")
    print(json.dumps({"v2":V2,"v3":V3,"directory_members":len(m["sha256"]),"matched_external_inputs":True,
                      "exact_complete_delta":True,"original_native_observations":17664,"actual_native_observations":0,
                      "unchanged_scorer":digest(b/"assess.py"),"per_arm_per_bank":{"initial":864,"replica":240}},sort_keys=True))

if __name__=="__main__":main()
