from collections import Counter
import csv,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;w=r/"work";ex=w/"round18-compiler"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
plans=[]
for name,h in {'depinfo-complete-command': 'a833e97451fb2e702ab1b345d6271854c2cb80c08bd8777aebf2024b049606e1', 'depinfo-complete-command-v2': 'c5fdaa3d2f9fd771be67d462e80d0c96303e1326d61d7d22654f876d5cecd1f7', 'depinfo-complete-command-v3': '5fa7f3456fe8a3c5f002602c4bd71dc0a059ec1f2651ee4913e36c1e4ac53e1c'}.items():
    p=ex/name/"registered.json";assert sha(p)==h
    plan=read(p);plans.append(plan)
    for n,h in plan["immutable_files"].items():
        q=(w/n).resolve(strict=True)
        assert q.is_relative_to(r) and sha(q)==h,n
b,c=plans[1:]
assert {k for k in b.keys()|c.keys() if b.get(k)!=c.get(k)}=={"native_banking","sealed_utc_ns","study","immutable_files"}
d=ex/"depinfo-complete-command-v3";design=read(d/"bank-design.json")
arms=("shipped","base","pr269","head");cols=("first","second","third","fourth")
assert design["initial"]==list(arms) and design["replica"]==list(arms[2:]+arms[:2])
schedule=list(csv.DictReader((d/"schedules.csv").open()))
for cohort,n in (("initial",3456),("replica",960)):
    rows=[q for q in schedule if (q["phase"],q["cohort"])==("native",cohort)]
    assert [int(q["block"]) for q in rows]==list(range(n))
    visits=Counter();orders=Counter()
    for q in rows:
        order=tuple(q[col] for col in cols);assert set(order)==set(arms)
        orders[order]+=1
        for rank,arm in enumerate(order):visits[arm,design[cohort][rank]]+=1
    assert len(orders)==24 and set(orders.values())=={n//24}
    assert len(visits)==16 and set(visits.values())=={n//4}
    print(cohort,n,"real-edit blocks scheduled;",n//4,"visits per driver and physical bank")
print("Verified three registrations, constituent inputs, unchanged source and analysis, and all 17,664 native assignments.")
