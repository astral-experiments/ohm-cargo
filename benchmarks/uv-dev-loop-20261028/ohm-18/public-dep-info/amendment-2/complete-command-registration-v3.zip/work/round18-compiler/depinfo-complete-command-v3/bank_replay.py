"""Detached, standard-library verification of native bank assignments and actual directory custody."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path

ARMS = ("shipped", "base", "pr269", "head")
RANKS = ("first", "second", "third", "fourth")
GRID = {"initial": ARMS, "replica": ("pr269", "head", "shipped", "base")}
BLOCKS = {"initial": 3456, "replica": 960}
ORDER_SHA = "87a652621d50050459b7ec05bb05faa392323635a5bf2caa3f7ea0047857fbfb"


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def csv_read(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def valid_digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def identities(preparation, cohort):
    ids = preparation["bank_inodes"]
    require(preparation["mode"] == "native" and preparation["cohort"] == cohort and set(ids) == set(ARMS),
            "wrong preparation")
    require(all(isinstance(v, list) and len(v) == 2 and all(type(x) is int for x in v) and
                v[0] >= 0 and v[1] > 0 for v in ids.values()) and len({tuple(v) for v in ids.values()}) == 4,
            "missing, duplicate or invalid physical bank identity")
    return ids


def verify_grid(schedule, rows, cohort, ids, bindings, maximum=None):
    n = BLOCKS[cohort] if maximum is None else maximum
    blocks = [s for s in schedule if (s["phase"], s["cohort"]) == ("native", cohort)]
    require(n > 0 and n % 24 == 0 and len(blocks) == n and len(rows) == n * 4, "raw bank population or schedule changed")
    vus = collections.Counter()
    ranks = collections.Counter()
    order_counts = collections.Counter()
    previous = -1
    for block, planned in enumerate(blocks):
        require(int(planned["block"]) == block, "block number changed")
        order = tuple(planned[col] for col in RANKS)
        require(set(order) == set(ARMS), "scheduled a driver twice")
        order_counts[order] += 1
        current = rows[4 * block:4 * block + 4]
        require(len({(r["source_sha256"], r["source_mtime_ns"]) for r in current}) == 1 and
                valid_digest(current[0]["source_sha256"]), "different edit within block")
        stamp = int(current[0]["source_mtime_ns"])
        require(stamp > previous, "source clock did not advance")
        previous = stamp
        visited = []
        for rank, (arm, row) in enumerate(zip(order, current), 1):
            bank = GRID[cohort][rank - 1]
            require((row["phase"], row["cohort"], int(row["block"]), int(row["rank"]), row["arm"], row["literal"]) ==
                    ("native", cohort, block, rank, arm, planned["literal"]), "changed row, order, rank, arm or edit")
            require(row["bank_id"] == bank and [int(row["bank_dev"]), int(row["bank_ino"])] == ids[bank],
                    "physical bank differs from preregistered rank or preparation identity")
            require(valid_digest(row["bank_binding_sha256"]), "missing physical binding digest")
            bindings(row, bank, ids[bank])
            ranks[arm, rank] += 1
            vus[arm, bank] += 1
            visited.append(bank)
        require(set(visited) == set(ARMS), "four distinct physical banks required for one edit")
    require(len(order_counts) == 24 and set(order_counts.values()) == {n // 24}, "order imbalance")
    require(len(ranks) == 16 and set(ranks.values()) == {n // 4}, "arm and rank imbalance")
    require(len(vus) == 16 and set(vus.values()) == {n // 4}, "arm and bank imbalance")
    return {"cohort": cohort, "blocks": n, "rows": 4 * n, "arm_bank": {a: {b: vus[a,b] for b in ARMS} for a in ARMS},
            "per_arm_rank": n // 4, "physical_identities": ids, "rank_to_bank": list(GRID[cohort]),
            "each_edit_visits_all_four_banks": True, "statistic_conditions_on_unchanged_locations": True}


def check_binding(data, row, bank, expected, root, preparation_sha):
    expected_keys = {"cohort", "block", "rank", "arm", "literal", "bank_id", "source_sha256", "source_mtime_ns",
                     "driver_sha256", "measure_receipt_sha256", "prepare_sha256", "canonical_target", "parked_path",
                     "active_before", "active_after", "parked_after"}
    require(set(data) == expected_keys, "incomplete or extended raw physical receipt")
    for key in ("cohort", "arm", "literal", "source_sha256", "driver_sha256", "measure_receipt_sha256"):
        require(data[key] == row[key], "physical receipt disagrees with command in " + key)
    for key in ("block", "rank", "source_mtime_ns"):
        require(type(data[key]) is int and data[key] == int(row[key]), "raw row key changed: " + key)
    require(data["bank_id"] == bank and data["prepare_sha256"] == preparation_sha and
            data["canonical_target"] == str(root / "target") and
            data["parked_path"] == str(root / "depinfo-complete-native-v3" / bank), "wrong bank, preparation or path")
    require(all(data[k] == expected and all(type(v) is int for v in data[k])
                for k in ("active_before", "active_after", "parked_after")), "raw physical inode changed during command")


def check_loan(receipt, ids, root):
    require(receipt["equal"] is True and receipt["before"] == receipt["after"] and
            receipt["owned_bank_identities"] == ids and receipt["before"]["root"] == str(root),
            "seeding, admission or sample did not return its four original bank identities")


def verify(study, observed, cohort):
    path = observed / "native" / cohort
    sample = path / "sample"
    prepared = path / "prepare" / "prepared.json"
    psha = sha(prepared)
    ids = identities(read(prepared), cohort)
    registration = read(study / "registered.json")
    require(registration["study"] == "ohm18-output-depinfo-whole-command-v3", "wrong study family")
    design = read(study / "bank-design.json")
    require(design == registration["native_banking"] and tuple(design[cohort]) == GRID[cohort],
            "independent bank map differs from registration")
    require(sha(study / "schedules.csv") == ORDER_SHA, "changed native schedule")
    closed = read(sample / "closed.json")
    require((closed["mode"], closed["cohort"], closed["blocks"], closed["rows"]) ==
            ("native", cohort, BLOCKS[cohort], 4 * BLOCKS[cohort]), "closed population differs from the preregistered grid")
    require(closed["registration_sha256"] == sha(study / "registered.json") and
            closed["rows_sha256"] == sha(sample / "rows.csv") and closed["bank_design_sha256"] == sha(study / "bank-design.json") and
            closed["bank_prepare_sha256"] == psha and closed["bank_prepare_return_sha256"] == sha(path / "prepare/returned.json") and
            closed["admission_sha256"] == sha(path / "admission/admitted.json") and
            closed["bank_admission_return_sha256"] == sha(path / "admission/returned.json") and
            closed["returned_sha256"] == sha(sample / "returned.json"), "sample custody, registration or raw rows changed")
    root = Path(read(path / "prepare/returned.json")["before"]["root"])
    require(root.is_absolute(), "canonical target is not absolute")
    for stage in ("prepare", "admission", "sample"):
        check_loan(read(path / stage / "returned.json"), ids, root)
    preparation = read(prepared)
    admitted = read(path / "admission/admitted.json")
    require(preparation["drivers"] == admitted["drivers"], "prepared and admitted drivers disagree")
    def lookup(row, bank, ident):
        require(row["driver_sha256"] == admitted["drivers"][row["arm"]], "wrong physical driver")
        dest = sample / f'{int(row["block"]):04}-{row["rank"]}-{row["arm"]}'
        binding = dest / "active-bank.json"
        require(row["bank_binding_sha256"] == sha(binding) and row["measure_receipt_sha256"] == sha(dest / "receipt.json"),
                "raw target binding or foreground receipt changed")
        check_binding(read(binding), row, bank, ident, root, psha)
    return verify_grid(csv_read(study / "schedules.csv"), csv_read(sample / "rows.csv"), cohort, ids, lookup)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("cohort", choices=GRID)
    cli.add_argument("--study", type=Path, default=Path(__file__).resolve().parent)
    cli.add_argument("--observed", type=Path, help="detached copy of observed/; defaults to STUDY/observed")
    args = cli.parse_args()
    print(json.dumps(verify(args.study, args.observed or args.study / "observed", args.cohort), indent=2, sort_keys=True))
