"""Read-only v2→v3 scope, source, schedule, grants, objective and byte-level input verification."""
import ast
import collections
import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.with_name("depinfo-complete-command-v2")
ORIGINAL = HERE.with_name("depinfo-complete-command")
WORK = HERE.parents[1]
V1 = "a833e97451fb2e702ab1b345d6271854c2cb80c08bd8777aebf2024b049606e1"
V2 = "c5fdaa3d2f9fd771be67d462e80d0c96303e1326d61d7d22654f876d5cecd1f7"
SCHEDULE = "87a652621d50050459b7ec05bb05faa392323635a5bf2caa3f7ea0047857fbfb"
MAP = {"initial":["shipped","base","pr269","head"],"replica":["pr269","head","shipped","base"]}
PATH_ONLY = {
    "drivers.py": [("depinfo-complete-command-v2-", "depinfo-complete-command-v3-")],
    "retire.py": [("depinfo-complete-command-v2-", "depinfo-complete-command-v3-")],
    "run.py": [("depinfo-complete-guards-v2", "depinfo-complete-guards-v3")],
    "banks.py": [('"depinfo-complete-"+phase+"-v2"', '"depinfo-complete-"+phase+"-v3"')],
    "grant_form.py": [("depinfo-complete-release-v2-", "depinfo-complete-release-v3-"),
                      ("ohm18-output-depinfo-whole-command-v2", "ohm18-output-depinfo-whole-command-v3")],
    "enroll.py": [('"pr269": (HERE / "269-only.patch",',
                   '"pr269": (HERE.with_name("depinfo-complete-command-v2") / "269-only.patch",')],
}
ALLOWED = set(PATH_ONLY) | {"README.md","amendment.json","register.py","verify_amendment.py","experiment.py","rescore.py","registered.json"}
NEW = {"bank-design.json","bank-selftest.json","bank-selftest.py","banking.py","bank_replay.py"}


def check(state, msg):
    if not state:
        raise ValueError(msg)


def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def func_bodies(src):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)}


def measure(src):
    hits=[n for n in ast.walk(ast.parse(src)) if isinstance(n,ast.Call) and
          isinstance(n.func,ast.Attribute) and n.func.attr=="run_command"]
    check(len(hits)==1,"unregistered additional Cargo timing call")
    return ast.dump(hits[0],include_attributes=False)


def verify(sealed=True):
    for prior, expected in ((ORIGINAL,V1),(PREVIOUS,V2)):
        check(sha(prior/"registered.json")==expected,"wrong predecessor")
        for k,v in read(prior/"registered.json")["immutable_files"].items():
            check(sha(WORK/k)==v,"changed predecessor input: "+k)
        check(all(not (prior/f).exists() for f in ("observed","grants")),"superseded version has physical work")
    old=read(PREVIOUS/"registered.json")
    oldfiles={f.name for f in PREVIOUS.iterdir() if f.is_file()}
    newfiles={f.name for f in HERE.iterdir() if f.is_file()}
    check(not (oldfiles-{"registered.json"})-newfiles and newfiles-oldfiles==NEW,"unexpected scope in study directory")
    identical=sorted(f for f in oldfiles-ALLOWED if sha(PREVIOUS/f)==sha(HERE/f))
    check(set(identical)==oldfiles-ALLOWED,"non-banking physical, scientific or source input changed")
    for f, replacements in PATH_ONLY.items():
        raw=(PREVIOUS/f).read_text()
        for a,b in replacements:
            check(raw.count(a)>0,"missing administrative path change")
            raw=raw.replace(a,b)
        check(raw==(HERE/f).read_text(),"change beyond declared storage namespace: "+f)
    before=(PREVIOUS/"experiment.py").read_text()
    after=(HERE/"experiment.py").read_text()
    prevfunc=func_bodies(before)
    nextfunc=func_bodies(after)
    check(prevfunc.keys()==nextfunc.keys() and
          [k for k in prevfunc if prevfunc[k]!=nextfunc[k]]==["sample"],"non-sample function changed")
    timer=measure(before)
    check(timer==measure(after) and sha(PREVIOUS/"assess.py")==sha(HERE/"assess.py"),"timer or inference changed")
    # Explicitly check the original count-command expression and entire count receipt extraction.
    count='''                                raw=wrapped(root,pool,dest,"count")
                                receipt=dest/"counted.json"
                                need(raw["frontend"]["argv_sha256"]==manifest["argv_sha256"],"counted frontend role changed")
                                timed=""
                                totals=raw["totals"]'''
    check(before.count(count)==1 and after.count(count)==1 and
          after.count('bank=banking.bank_at(cohort,rank) if mode=="native" else arm')==1,"count command or bank changed")
    rv=(PREVIOUS/"rescore.py").read_text()
    hook='''        if phase=="native":
            from bank_replay import verify
            verify(HERE,OUT,c)
'''
    check((HERE/"rescore.py").read_text()==rv.replace('        data[c]=rs',hook+'        data[c]=rs'),
          "existing raw or numerical score code changed")
    check(sha(HERE/"schedules.csv")==SCHEDULE and (PREVIOUS/"sources.json").read_bytes()==(HERE/"sources.json").read_bytes(),
          "treatments, source roster or schedule changed")
    a=read(HERE/"amendment.json")
    check(a["supersedes_registration_sha256"]==V2 and a["schedule_sha256"]==SCHEDULE and
          a["candidate_patch_sha256"]==read(HERE/"sources.json")["subjects"]["head"]["patch_sha256"],"amendment evidence changed")
    bank=read(HERE/"bank-design.json")
    check(all(bank[c]==banks for c,banks in MAP.items()),"bank permutation changed")
    schedule=list(csv.DictReader((HERE/"schedules.csv").read_text().splitlines()))
    marg={}
    for c,n in (("initial",3456),("replica",960)):
        rows=[r for r in schedule if r["phase"]=="native" and r["cohort"]==c]
        cells=collections.Counter((r[key],bank[c][pos]) for r in rows
                                  for pos,key in enumerate(("first","second","third","fourth")))
        check(len(rows)==n and len(cells)==16 and set(cells.values())=={n//4},"unbalanced arm by bank")
        marg[c]=n//4
    controls=read(HERE/"bank-selftest.json")
    check(controls["synthetic_only"] is True and len(controls["negative_controls"])==35 and
          controls["unchanged_scorer_contrasts_replayed"]==3 and controls["mocked_detached_raw_receipts"]==96,"synthetic safety gate")
    for source in HERE.glob("*.py"):
        ast.parse(source.read_text(),filename=str(source))
    if sealed:
        new=read(HERE/"registered.json")
        check(set(new)==set(old)|{"native_banking"} and all(new[k]==old[k] for k in old if
              k not in {"study","sealed_utc_ns","immutable_files"}),"original source, threshold, size or population changed")
        check(new["study"]=="ohm18-output-depinfo-whole-command-v3" and new["native_banking"]==bank,"wrong registration")
        for k,v in new["immutable_files"].items():
            check(sha(WORK/k)==v,"changed v3 registered input: "+k)
        for k,v in old["immutable_files"].items():
            if not k.startswith("round18-compiler/depinfo-complete-command-v2/"):
                check(new["immutable_files"].get(k)==v,"external prerequisite or raw calibration removed: "+k)
    return {"v1_sha256":V1,"v2_sha256":V2,"v3_sha256":sha(HERE/"registered.json") if sealed else None,
            "unchanged_registered_v2_inputs":len(old["immutable_files"]),"unchanged_study_files":identical,
            "schedule_sha256":SCHEDULE,"per_arm_per_bank":marg,"rank_and_bank_aliased_in_each_cohort":True,
            "native_commands":17664,"count_commands":192,"original_scorer_sha256":sha(HERE/"assess.py"),
            "timer_ast_sha256":hashlib.sha256(timer.encode()).hexdigest(),"v1_or_v2_physical_work":False,
            "v3_frozen_inputs":len(new["immutable_files"]) if sealed else None,"bank_negative_controls":35}


if __name__=="__main__":
    print(json.dumps(verify(),indent=2,sort_keys=True))
