"""Resolve the three one-file source trees without writing a Git object or touching the checkout."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / "ohm-cargo"
SRC = Path("src/compiler/output_depinfo.rs")
REL = "7caf39914da1e28a67744ecbc963a5f26361474d"
PR = "9256d6a21da8e6c0a2ba9502999d74544ed850cd"


def git(*args):
    return subprocess.check_output(["git", "-C", REPO, *args])


def oid(kind, data):
    return hashlib.sha1(kind + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def new_tree(root, bits, blob):
    raw = git("cat-file", "tree", root)
    name = bits[0].encode()
    pos = 0
    while pos < len(raw):
        null = raw.index(b"\0", pos)
        _, entry = raw[pos:null].split(b" ", 1)
        start = null + 1
        if entry == name:
            sub = new_tree(raw[start:start+20].hex(), bits[1:], blob) if len(bits) > 1 else blob
            return oid(b"tree", raw[:start] + bytes.fromhex(sub) + raw[start+20:])
        pos = start + 20
    raise ValueError(name)


def main():
    parent = git("rev-parse", REL + "^{tree}").decode().strip()
    original = git("show", REL + ":" + str(SRC))
    patch = WORK / "round18-lab/depinfo-source-audit/candidate-v2.patch"
    material = {
        "base": (None, original),
        "pr269": (HERE.with_name("depinfo-complete-command-v2") / "269-only.patch", git("show", PR + ":" + str(SRC))),
    }
    # Re-diff the isolated released source files. The full #269 commit includes unrelated parent changes.
    borrowed = git("diff", REL, PR, "--", str(SRC))
    (HERE / "269-only.patch").write_bytes(borrowed)
    with tempfile.TemporaryDirectory() as name:
        target = Path(name) / SRC
        target.parent.mkdir(parents=True)
        for arm, delta in (("pr269", borrowed), ("head", patch.read_bytes())):
            target.write_bytes(original)
            subprocess.run(["git","apply","--whitespace=nowarn","-"],cwd=name,input=delta,check=True)
            if arm == "pr269":
                assert target.read_bytes() == material[arm][1]
            else:
                material[arm] = (patch, target.read_bytes())
    enrolled = {}
    for arm, (delta, raw) in material.items():
        blob = oid(b"blob", raw)
        enrolled[arm] = {"blob":blob,"file_sha256":hashlib.sha256(raw).hexdigest(),
                "tree":new_tree(parent,SRC.parts,blob),"only_source":str(SRC)}
        if delta:
            enrolled[arm].update(patch=str(delta),patch_sha256=hashlib.sha256(delta.read_bytes()).hexdigest())
    assert enrolled["base"]["tree"] == parent
    print(json.dumps({"release":REL,"pr269":PR,"subjects":enrolled},sort_keys=True,indent=2))


if __name__ == "__main__":
    main()
