"""Explicitly granted retirement only for exact owned reproducible targets after successful return."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import os
import subprocess
from banks import *


def unused(paths):
    resolved=[p.resolve(strict=True) for p in paths]
    for proc in Path("/proc").glob("[0-9]*"):
        try:
            if proc.stat().st_uid!=os.getuid(): continue
            # Deleted/open descendants still remain attributable via their /proc symlink.
            refs=[proc/"cwd",proc/"root",proc/"exe",*list((proc/"fd").iterdir())]
            for f in refs:
                try:
                    target=Path(os.readlink(f).removesuffix(" (deleted)"))
                except (FileNotFoundError,PermissionError,ProcessLookupError,OSError):
                    continue
                need(not any(target==p or p in target.parents for p in resolved),f"live user process {proc.name} uses {target}")
        except (FileNotFoundError,ProcessLookupError):
            continue


def owned_target(root,name,expected):
    path=root/name
    need(path.is_dir() and not path.is_symlink() and path.parent.resolve()==root.resolve() and
         path.stat().st_uid==os.getuid() and inventory(path)==expected,"target inode, owner or location changed")
    return path


def record_pgo_targets(arm):
    from drivers import pgo
    d=OUT/"drivers"/arm
    record=Path(read(d/"candidate-request.json")["record"])
    expected=pgo.STABLE/("depinfo-complete-command-v3-"+arm)/"records/head"
    need(record==expected and record.is_dir() and not record.is_symlink(),"unexpected PGO ownership")
    children={name:inventory(record/name) for name in ("generate.target","use.target","training-target")}
    save(d/"owned-reproducible.json",{"record":str(record),"record_inode":inventory(record),"children":children,
                                      "build_request_sha256":sha(d/"candidate-request.json")})


def pgo_targets(arm):
    import drivers
    pgo=drivers.pgo
    pgo.source_delta=drivers.exact_source
    out=OUT/"drivers"/arm
    prereq=read(out/"verified.json")
    owned=read(out/"owned-reproducible.json")
    request=read(out/"candidate-request.json")
    record=Path(owned["record"])
    need(record==pgo.STABLE/("depinfo-complete-command-v3-"+arm)/"records/head" and
         owned["record_inode"]==inventory(record) and owned["build_request_sha256"]==sha(out/"candidate-request.json")
         and not (out/"retired-targets.json").exists(),"unexpected PGO retirement request")
    need(pgo.verify_candidate(request)==prereq["audit"], "full original independent audit no longer reproduces")
    dirs={n:owned_target(record,n,token) for n,token in owned["children"].items()}
    unused(dirs.values())
    before=fsfree()
    saved={}
    for label,path in dirs.items():
        keep={}
        if label in ("generate.target","use.target"):
            libs=list((path/pgo.HOST/"release").rglob("libstd-*.rlib"))
            need(libs and all(sha(lib)==pgo.STD_SHA for lib in libs),"unverified linked std")
            # Retain the exact std archive bytes at their original paths. Keep the separate original cargo binary.
            keep={str(lib.relative_to(path)):sha(lib) for lib in libs}
        saved[label]=keep
    save(out/"retirement-before.json",{"owned":owned,"preserve":saved,"audited_sha256":sha(out/"verified.json"),
                                      "free":before,"action":"retain sources, logs, raw/remerged profile, binaries and linked std"})
    for label,path in dirs.items():
        scratch=record/(label+".retirement-in-progress")
        need(not scratch.exists() and inventory(path)==owned["children"][label],"unexpected completed tree")
        path.rename(scratch)
        if saved[label]:
            path.mkdir()
            for rel,digest in saved[label].items():
                dest=path/rel
                dest.parent.mkdir(parents=True,exist_ok=True)
                # Independent bytes before retiring the original. Avoid relying on the continued existence of a hardlink.
                shutil.copy2(scratch/rel,dest)
                need(sha(dest)==digest,"failed to retain exact linked std")
        unused([scratch])
        need(inventory(scratch)==owned["children"][label],"original target identity changed before retirement")
        shutil.rmtree(scratch)
    repeated=pgo.verify_candidate(request)
    need(repeated==prereq["audit"],"retained PGO evidence failed original full remerge/linked-std auditor")
    save(out/"retired-targets.json",{"owned":owned,"retained_std":saved,"before":before,"after":fsfree(),
                                    "repeated_independent_audit_equal":True,"audited_sha256":sha(out/"verified.json")})


def bank_targets(mode,cohort):
    root,pool=banks(mode,cohort)
    out=OUT/mode/cohort
    sample=out/"sample"
    closed=read(sample/"closed.json")
    returned=read(sample/"returned.json")
    need(returned["equal"] and sha(sample/"returned.json")==closed["returned_sha256"] and
         sha(sample/"rows.csv")==closed["rows_sha256"] and sha(sample/"postflight.json")==closed["postflight_sha256"] and
         original_state(root)==returned["before"] and not (out/"retired.json").exists(),"unclosed or changed owned study")
    owned=read(out/"prepare/prepared.json")["bank_inodes"]
    paths={a:owned_target(pool,a,owned[a]) for a in ARMS}
    need(returned["owned_bank_identities"]==owned and not (pool/"preexisting-canonical").exists(),
         "original and returned donor identities are not accounted for")
    unused(paths.values())
    before=fsfree()
    save(out/"retirement-before.json",{"inodes":owned,"free":before,"closed_sha256":sha(sample/"closed.json"),
                                       "returned_sha256":sha(sample/"returned.json")})
    for a,path in paths.items():
        need(inventory(path)==owned[a],"not authorized to retire a changed bank")
        shutil.rmtree(path)
    save(out/"retired.json",{"inodes":owned,"after_free":fsfree(),"before_free":before,
                             "untouched_official_state":original_state(root),"all_four_absent":not any(p.exists() for p in paths.values())})
