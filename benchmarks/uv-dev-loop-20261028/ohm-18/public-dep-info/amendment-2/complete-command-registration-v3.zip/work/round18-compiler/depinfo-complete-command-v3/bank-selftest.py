"""Synthetic controls only. The two full assignment grids remain in memory; no benchmark is invoked."""
import collections
import copy
import hashlib
import itertools
import json
from pathlib import Path
import runpy
import sys
import tempfile
from unittest import mock

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
import banking
import bank_replay as replay

def h(text):
    return hashlib.sha256(text.encode()).hexdigest()

def reject(name, function):
    try:
        function()
    except (ValueError, KeyError, FileNotFoundError, AssertionError):
        return name
    raise RuntimeError("a corrupt case passed: " + name)

def rows(schedule, co, ids):
    output = []
    for b in (b for b in schedule if (b["phase"], b["cohort"]) == ("native", co)):
        for rank,col in enumerate(replay.RANKS,1):
            bank = banking.bank_at(co, rank)
            arm = b[col]
            dev, ino = ids[bank]
            output.append(dict(phase="native", cohort=co, block=b["block"], rank=str(rank), arm=arm, literal=b["literal"],
                               source_sha256=h(co+b["literal"]), source_mtime_ns=str(123_400 + int(b["block"])),
                               driver_sha256=h("driver-"+arm), measure_receipt_sha256=h(co+b["literal"]+arm),
                               elapsed_ns=str(800_000_000 + 4_000*rank + (int(b["block"])+rank)%7*1_000_007),
                               bank_id=bank, bank_dev=str(dev), bank_ino=str(ino), bank_binding_sha256=h("placeholder")))
    return output

def main():
    schedule = replay.csv_read(here / "schedules.csv")
    ids = {a:[21,43+i] for i,a in enumerate(replay.ARMS)}
    noop = lambda *_: None
    profiles = {}
    exclusions = []
    for co in replay.GRID:
        sample = rows(schedule, co, ids)
        profiles[co] = replay.verify_grid(schedule, sample, co, ids, noop)
        for change, updates in (
            ("opposite bank with real dev/inode", {"bank_id":sample[1]["bank_id"],"bank_ino":sample[1]["bank_ino"]}),
            ("physical swap behind unchanged rank", {"bank_ino":sample[1]["bank_ino"]}),
            ("wrong treatment order", {"arm":sample[1]["arm"]}),
            ("different source", {"source_sha256":h("wrong")}),
            ("different source clock", {"source_mtime_ns":"17"}),
            ("missing binding hash", {"bank_binding_sha256":""}),
        ):
            changed = [dict(sample[0], **updates)] + sample[1:]
            exclusions.append(reject(co+" "+change, lambda:replay.verify_grid(schedule,changed,co,ids,noop)))
        exclusions.append(reject(co+" missing row", lambda:replay.verify_grid(schedule,sample[:-1],co,ids,noop)))
        corrupt = [dict(r, bank_id=r["arm"], bank_dev=str(ids[r["arm"]][0]), bank_ino=str(ids[r["arm"]][1])) for r in sample[:8]]
        exclusions.append(reject(co+" original fixed physical arm",lambda:replay.verify_grid(schedule,corrupt+sample[8:],co,ids,noop)))
    # Full detached-file API exercised with the real 24 order permutations and mocked in-memory file bytes.
    co = "initial"
    schedule24 = [dict(phase="native", cohort=co, block=str(i), literal=f"IA{i:03}", **dict(zip(replay.RANKS,p)))
                  for i,p in enumerate(itertools.permutations(replay.ARMS))]
    sample = rows(schedule24, co, ids)
    fake = Path("/synthetic-depinfo")
    std = fake/"study"
    obs = fake/"observed"
    cohort = obs/"native"/co
    src = Path("/synthetic-canonical-checkout")
    p = cohort/"prepare/prepared.json"
    prep = {"cohort":co,"mode":"native","bank_inodes":ids,"drivers":{a:h("driver-"+a) for a in replay.ARMS}}
    loan = {"before":{"root":str(src)},"after":{"root":str(src)},"equal":True,"owned_bank_identities":ids}
    store = {p:prep,std/"bank-design.json":banking.DESIGN,std/"registered.json":{"study":"ohm18-output-depinfo-whole-command-v3","native_banking":banking.DESIGN},
             cohort/"admission/admitted.json":{"drivers":prep["drivers"]}}
    for key in ("prepare","admission","sample"):
        store[cohort/key/"returned.json"] = copy.deepcopy(loan)
    cr = cohort/"sample/closed.json"
    def digest(path):
        if path == std/"schedules.csv": return replay.ORDER_SHA
        return h(json.dumps(store[path],sort_keys=True))
    for r in sample:
        d = cohort/"sample"/f'{int(r["block"]):04}-{r["rank"]}-{r["arm"]}'
        bank = r["bank_id"]
        store[d/"receipt.json"] = {"elapsed_ns":r["elapsed_ns"],"rank":r["rank"],"arm":r["arm"]}
        r["measure_receipt_sha256"] = digest(d/"receipt.json")
        b = {k:r[k] for k in ("cohort","arm","literal","source_sha256","driver_sha256","measure_receipt_sha256")}
        b.update({k:int(r[k]) for k in ("block","rank","source_mtime_ns")})
        b.update(bank_id=bank,prepare_sha256=digest(p),canonical_target=str(src/"target"),
                 parked_path=str(src/"depinfo-complete-native-v3"/bank),
                 active_before=ids[bank],active_after=ids[bank],parked_after=ids[bank])
        store[d/"active-bank.json"] = b
        r["bank_binding_sha256"] = digest(d/"active-bank.json")
    store[cohort/"sample/rows.csv"] = sample
    store[cr] = {"registration_sha256":digest(std/"registered.json"),"rows_sha256":digest(cohort/"sample/rows.csv"),
                 "cohort":co,"mode":"native","blocks":24,"rows":96,
                 "bank_design_sha256":digest(std/"bank-design.json"),"bank_prepare_sha256":digest(p),
                 "bank_prepare_return_sha256":digest(cohort/"prepare/returned.json"),"returned_sha256":digest(cohort/"sample/returned.json"),
                 "admission_sha256":digest(cohort/"admission/admitted.json"),"bank_admission_return_sha256":digest(cohort/"admission/returned.json")}
    store[std/"schedules.csv"] = schedule24
    with mock.patch.multiple(replay, BLOCKS={"initial":24,"replica":24}, read=lambda p:store[p], sha=digest, csv_read=lambda p:store[p]):
        assert replay.verify(std,obs,co)["rows"] == 96
        first=sample[0]
        d=cohort/"sample"/f'0000-1-{first["arm"]}'/"active-bank.json"
        binding=store[d]
        for label,key,val in (("wrong original inode","active_before",ids["base"]),("within-command target replaced","active_after",ids["base"]),
                              ("wrong parked return","parked_after",ids["base"]),("detached path substitution","canonical_target","/other/target"),
                              ("same-inode wrong binding","parked_path",str(src/"depinfo-complete-native-v3/base")),
                              ("borrowed physical command","measure_receipt_sha256",h("unrelated")),
                              ("wrong preparation hash","prepare_sha256",h("unrelated")),("wrong logged treatment","arm","pr269")):
            with mock.patch.dict(binding, {key:val}):
                # Reseal both enclosing hashes. The independent reader must still reject invalid underlying observations.
                with mock.patch.dict(first, {"bank_binding_sha256":digest(d)}):
                    with mock.patch.dict(store[cr], {"rows_sha256":digest(cohort/"sample/rows.csv")}):
                        exclusions.append(reject(label,lambda:replay.verify(std,obs,co)))
        ad = cohort/"admission/returned.json"
        with mock.patch.dict(store[ad],{"equal":False}):
            with mock.patch.dict(store[cr],{"bank_admission_return_sha256":digest(ad)}):
                exclusions.append(reject("unreturned admitted banks",lambda:replay.verify(std,obs,co)))
    exclusions.append(reject("duplicate prepared inode",lambda:replay.identities({**prep,"bank_inodes":{**ids,"head":ids["base"]}},co)))
    # Four genuinely different empty test directories; exercise pre/post canonical checks without invoking a compiler.
    with tempfile.TemporaryDirectory() as temp:
        d = Path(temp)
        target = d/"target"
        parks = [d/a for a in replay.ARMS]
        for p1 in parks: p1.mkdir()
        seen = [banking.identity(p1) for p1 in parks]
        assert len({tuple(v) for v in seen}) == 4
        for p1, ident in zip(parks,seen):
            p1.rename(target)
            assert banking.measure_slot(target,p1,ident) == ident
            other = next(v for v in seen if v!=ident)
            exclusions.append(reject("real wrong swap "+p1.name,lambda:banking.measure_slot(target,p1,other)))
            p1.symlink_to(d/"missing")
            exclusions.append(reject("occupied vacant alias "+p1.name,lambda:banking.measure_slot(target,p1,ident)))
            p1.unlink()
            target.rename(p1)
            assert banking.measure_slot(p1,target,ident) == ident
        target.symlink_to(parks[0])
        exclusions.append(reject("canonical directory symlink",lambda:banking.identity(target)))
    source2 = here.with_name("depinfo-complete-command-v2")/"assess.py"
    a2 = runpy.run_path(str(source2))["contrast"]
    a3 = runpy.run_path(str(here/"assess.py"))["contrast"]
    blocks = [{r["arm"]:r for r in sample[b:b+4]} for b in range(0,len(sample),4)]
    stripped = [{a:{k:v for k,v in r.items() if not k.startswith("bank_")} for a,r in b.items()} for b in blocks]
    for rival in replay.ARMS[:-1]:
        assert a2(stripped,rival,"native")==a3(blocks,rival,"native")
    return {"synthetic_only":True,"fixed_full_assignments":profiles,"mocked_detached_raw_receipts":96,
            "live_empty_directory_sensor_controls":4,"unchanged_scorer_contrasts_replayed":3,
            "negative_controls":exclusions,"no_benchmark_target_or_tool":True}

if __name__=="__main__":
    print(json.dumps(main(),sort_keys=True,indent=2))
