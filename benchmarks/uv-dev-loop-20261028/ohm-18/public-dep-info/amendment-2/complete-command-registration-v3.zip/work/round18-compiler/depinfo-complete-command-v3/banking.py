"""Native-only physical target observations outside the existing Cargo wall clock."""
import json
import os
import stat
from pathlib import Path

DESIGN = json.loads(Path(__file__).with_name("bank-design.json").read_text())


def bank_at(cohort, rank):
    if type(rank) is not int or not 1 <= rank <= 4:
        raise ValueError("invalid execution rank")
    return DESIGN[cohort][rank - 1]


def identity(directory):
    observed = directory.lstat()
    if not stat.S_ISDIR(observed.st_mode):
        raise ValueError("physical bank is not a directory: " + str(directory))
    return [observed.st_dev, observed.st_ino]


def measure_slot(active, vacant, expected):
    actual = identity(active)
    if os.path.lexists(vacant) or actual != expected:
        raise ValueError(f"bank custody: {active} {actual}, expected {expected}; vacancy {vacant}")
    return actual
