"""Recompute the elapsed-time gates and validate each arm's full metadata manifest."""
import argparse
import ast
import csv
import gzip
import hashlib
import importlib.util
import json
import re
from pathlib import Path

here=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def compressed(p):
    with gzip.open(p,'rt') as f:return json.load(f)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def compiler_argv(root,prefix,plan,fixture):
    rustc=str(Path(plan['candidate_path']).parents[3]/'upstream-monitor/toolchain18/bin/rustc');cargo=str(Path(fixture)/'bin/cargo')
    quoted=r'"(?:[^"\\]|\\.)*"';entry=re.compile(r'^execve\(('+quoted+r'), (\[(?:'+quoted+r'(?:, )?)*\]), ')
    programs=[];args=[]
    for proof in root.glob(prefix+'.log.exec.*'):
        for line in proof.read_text().splitlines():
            if not line.startswith('execve') or not line.endswith('= 0'):continue
            m=entry.match(line);assert m,proof;exe=ast.literal_eval(m[1]);argv=ast.literal_eval(m[2]);assert exe in (cargo,rustc) and argv[0]==exe
            programs.append(exe)
            if exe==rustc and '--crate-name' in argv:
                assert argv[argv.index('--crate-name')+1] in ('uv','uvx') and any(v.startswith('--emit=') and 'metadata' in v and 'link' not in v for v in argv)
                args.append(argv)
    assert programs.count(cargo)==1 and args;return sorted(args)
def main():
    p=argparse.ArgumentParser();p.add_argument('--raw',action='store_true');p.add_argument('--objects',type=Path);a=p.parse_args()
    reg=read(here/'registration.json');assert sha(here/'run.py')==reg['script_sha256'] and sha(here/'PROTOCOL.md')==reg['protocol_sha256']
    objects=a.objects or Path(reg['raw_metadata']);scores={};seen={};reads=0
    for name,identity in reg['subjects'].items():
        subj=here.parent/('lockfile-collision' if name=='hash' else 'lockfile-collision-ordered');assert sha(subj/'plan.json')==identity['plan_sha256']
        plan=read(subj/'plan.json');src=importlib.util.spec_from_file_location('score_'+name,subj/'stats.py');stats=importlib.util.module_from_spec(src);src.loader.exec_module(stats)
        assert sha(subj/'stats.py')==identity['identity']['harness']['stats.py'];scores[name]={}
        for cohort,fixed in identity['cohorts'].items():
            d=here/name/'results'/cohort
            if not (d/'summary.json').exists():scores[name][cohort]={'state':'rejected' if (d/'rejected.json').exists() else 'incomplete'};continue
            cfg=plan['cohorts'][cohort];keys=set(fixed['products']);assert len(keys)==696
            assert sha(d/'pristine-rmeta.json.gz')==fixed['pristine_manifest_sha256'];assert sha(d/'warm.json')==fixed['warm_sha256']
            products=compressed(d/'pristine-rmeta.json.gz');assert set(products)==keys
            for _,size,_,_,sig in products.values():assert seen.setdefault(sig,size)==size
            admissions=[read(d/f'admit-{arm}.json') for arm in ('base','candidate')];assert admissions[0]==admissions[1]
            for arm in ('base','candidate'):assert compiler_argv(d,'admit-'+arm,plan,fixed['fixture'])==admissions[0]['rustc_argv']
            if name=='hash' and cohort=='wall-initial':
                original_control=compressed(d/'excluded-original-base-rmeta.json.gz')
                assert {key:row[-1] for key,row in original_control.items()}==admissions[0]['metadata']
            def validate(log,meta):
                nonlocal reads
                before=compressed(d/(log+'.rmeta-before.json.gz'));after=compressed(d/(log+'.rmeta-after.json.gz'))
                assert set(before)==set(after)==set(meta)==keys
                change={k for k in after if before[k][:4]!=after[k][:4]};assert change==set(reg['changed'])
                rotated={k for k in after if before[k][0]!=after[k][0]};assert rotated=={k for k in change if '/{session}/' in k}
                for k in keys:
                    raw,size,_,_,sig=after[k];assert sig==meta[k] and seen.setdefault(sig,size)==size
                    if '/{session}/' in k:assert re.fullmatch(re.escape(k).replace(re.escape('{session}'),r's-[a-z0-9]+-[a-z0-9]+-[a-z0-9]+'),raw)
                    else:assert k==raw
                reads+=1
            for arm in ('base','candidate'):validate('admit-'+arm,admissions[0]['metadata'])
            for when in ['preflight','postflight']:
                checks=[json.loads(line) for line in (d/(when+'.jsonl')).read_text().splitlines()];assert [v[-1] for v in checks[-2:]]==[1,2]
            rows=list(csv.DictReader((d/'samples.csv').open()));assert len(rows)==48 and len(cfg['order'])==24
            pairs=[]
            for i,order in enumerate(cfg['order']):
                pair={'order':order};previous=None
                for pos,arm in enumerate(order):
                    row=rows[2*i+pos];f=d/row['receipt'];rec=read(f);log=f.stem
                    assert row['arm']==arm and int(row['pair'])==i and int(row['position'])==pos and rec['arm']==arm
                    assert rec['value']==int(row['value'])>0 and row['metric']=='elapsed_ns'
                    assert rec['edit_sha256']==row['edit_sha256']==cfg['edit_sha256'][cfg['source_labels'][i]]
                    body=(d/(log+'.log')).read_text();pkg=sorted(re.findall(r'^\s*(?:Checking|Compiling) (.+)$',body,re.M));assert pkg==rec['compiled']==admissions[0]['compiled']
                    assert len(pkg)==1 and pkg[0].startswith('uv v') and not re.search(r'^\s*(Running|Blocking|Downloading|Updating) |^running \d+ test',body,re.M)
                    validate(log,rec['metadata']);state=(rec['metadata'],rec['edit_sha256'],rec['edit_mtime_ns'])
                    if previous:assert state==previous
                    previous=state;pair[arm]=rec['value']
                pairs.append(pair)
            scored=stats.summarize(pairs,cohort=='wall-initial');assert scored==read(d/'summary.json');scores[name][cohort]={'state':'verified',**scored}
    if a.raw:
        for sig,size in sorted(seen.items()):
            f=objects/sig[:2]/sig;assert f.stat().st_size==size and sha(f)==sig
    result=dict(cohorts=scores,verified_command_manifests=reads,verified_products_per_command=696,distinct_observed_raw_byte_streams=len(seen),verified_raw_objects=a.raw,
            qualified={g:all(v.get('gate',False) for v in cohort.values()) for g,cohort in scores.items()})
    (here/('verified-raw.json' if a.raw else 'verified.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
