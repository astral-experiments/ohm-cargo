"""Keep every metadata byte while identifying two rotating incremental paths by role."""
import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import sys
import time
import traceback
from pathlib import Path

HERE=Path(__file__).resolve().parent
SUITE=HERE.parent
BENCH=Path((SUITE.parent/'bench-home.path').read_text().strip())
CAS=BENCH/'resolver-wall-raw-metadata'
SUBJECTS={'hash':'lockfile-collision','ordered':'lockfile-collision-ordered'}
COHORTS=('wall-initial','wall-repeat')
PREFIX='debug/incremental/uv-03lozwew6kg2v/'
SLOTS={'metadata.rmeta','ohm-check-metadata.rmeta'}
PUBLIC='debug/build/uv/0f93810b947feec2/out/libuv-0f93810b947feec2.rmeta'
DIR=re.compile(r's-[0-9a-z]+-[0-9a-z]+-[0-9a-z]+')
RELEASE='199e5cff4cc9f59222fea6d7453b49a09aa073ee87adedfd162c82a0e0b9ae51'


def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def files(directory):
    result={};sessions=set()
    for file in directory.rglob('*.rmeta'):
        rel=file.relative_to(directory).as_posix();key=rel
        if rel.startswith(PREFIX):
            rest=rel.removeprefix(PREFIX).split('/')
            if len(rest)==2 and DIR.fullmatch(rest[0]) and rest[1] in SLOTS:
                sessions.add(rest[0]);key=PREFIX+'{session}/'+rest[1]
        assert key not in result and file.is_file() and not file.is_symlink(),f'duplicate or non-regular product {key}'
        st=file.stat();result[key]=(rel,st.st_size,st.st_mtime_ns,st.st_ino)
    assert len(result)==696 and len(sessions)==1 and all(PREFIX+'{session}/'+k in result for k in SLOTS)
    return result


def content(directory,metadata,pending):
    out={}
    for key,(relative,size,*_) in metadata.items():
        raw=(directory/relative).read_bytes();assert len(raw)==size
        signature=digest(raw);out[key]=signature
        if signature not in pending and not (CAS/signature[:2]/signature).exists():pending[signature]=raw
    return out


def flush(pending):
    for signature,raw in pending.items():
        final=CAS/signature[:2]/signature;final.parent.mkdir(parents=True,exist_ok=True)
        if not final.exists():final.write_bytes(raw)
        assert sha(final)==signature
    pending.clear()


def raw_snapshot(out,metadata,signatures):
    with gzip.open(out,'wt',compresslevel=1) as f:
        json.dump({k:[*v,signatures[k]] for k,v in sorted(metadata.items())},f,separators=(',',':'))


def paths(name):
    subject=SUITE/SUBJECTS[name];original=subject/'recovery' if name=='hash' else subject
    return subject,original


def freeze():
    registration=HERE/'registration.json';assert not registration.exists()
    assert sha(SUITE.parent/'round18-lab/host-opened-for-resolver-and-literal.json')==RELEASE
    assert sorted(os.sched_getaffinity(0))==list(range(24,32)) and (SUITE/'edited-roles/control/pause').exists()
    failed=paths('hash')[1]/'results/wall-initial';assert read(failed/'rejected.json')['reason']=='removed metadata' and not (failed/'samples.csv').exists()
    subjects={};pending={};excluded={}
    for name in SUBJECTS:
        subject,original=paths(name);plan=read(subject/'plan.json');ident=read(original/'native-seal.json');receipt={}
        for label in COHORTS:
            cfg=plan['cohorts'][label];root=Path(cfg['fixture']);out=HERE/name/'results'/label;out.mkdir(parents=True)
            assert not (original/'results'/label/'samples.csv').exists() and not (root/'target').exists()
            former=original/'results'/label/'warm.json';assert read(former)['identity']==ident;shutil.copyfile(former,out/'warm.json')
            before=files(root/'predecessor');keys=sorted(before)
            assert PUBLIC in keys
            base=content(root/'predecessor',before,pending);raw_snapshot(out/'pristine-rmeta.json.gz',before,base)
            if name=='hash' and label=='wall-initial':
                dirty=files(root/'held-base');clean=files(root/'held-candidate');assert sorted(clean)==sorted(dirty)==keys
                assert content(root/'held-candidate',clean,pending)==base
                changed={k for k in keys if before[k][:3]!=dirty[k][:3]}
                assert changed=={PUBLIC,*[PREFIX+'{session}/'+leaf for leaf in SLOTS]},changed
                sig=content(root/'held-base',dirty,pending);raw_snapshot(out/'excluded-original-base-rmeta.json.gz',dirty,sig)
                excluded=dict(receipts={p.name:sha(p) for p in sorted(failed.iterdir()) if p.is_file()},source_before=sha(root/'source/crates/uv/src/install_source.rs'),changed=sorted(changed))
            receipt[label]=dict(fixture=str(root),products=keys,warm_sha256=sha(former),pristine_manifest_sha256=sha(out/'pristine-rmeta.json.gz'))
        subjects[name]=dict(plan_sha256=sha(subject/'plan.json'),identity=ident,cohorts=receipt)
        for label in ('instructions-initial','instructions-repeat'):
            src=original/'results'/label/'summary.json';assert read(src)['gate'];dst=HERE/name/'results'/label;dst.mkdir(parents=True);shutil.copyfile(src,dst/'summary.json')
    flush(pending)
    save(registration,dict(registered_ns=time.time_ns(),script_sha256=sha(Path(__file__)),protocol_sha256=sha(HERE/'PROTOCOL.md'),release_sha256=RELEASE,
         changed=sorted({PUBLIC,*[PREFIX+'{session}/'+leaf for leaf in SLOTS]}),subjects=subjects,excluded_control=excluded,
         raw_metadata=str(CAS),cpu=list(range(24,32))))
    print('Sealed all 696 logical paths, their initial bytes and all four untouched assignments.',flush=True)


def sample(name,label):
    reg=read(HERE/'registration.json');s=reg['subjects'][name];subject,original=paths(name)
    assert reg['script_sha256']==sha(Path(__file__)) and reg['protocol_sha256']==sha(HERE/'PROTOCOL.md') and reg['release_sha256']==sha(SUITE.parent/'round18-lab/host-opened-for-resolver-and-literal.json')
    assert sorted(os.sched_getaffinity(0))==reg['cpu'] and (SUITE/'edited-roles/control/pause').exists()
    sys.path.insert(0,str(subject));import common,measure
    identity=common.seal(wall=True)
    if name=='hash':identity['environment_registration_sha256']=sha(original/'registration.json')
    assert identity==s['identity'] and sha(subject/'plan.json')==s['plan_sha256']
    cfg=common.PLAN['cohorts'][label];root=Path(cfg['fixture']);out=HERE/name/'results'/label
    assert not (out/'summary.json').exists() and not (out/'rejected.json').exists()
    assert sha(out/'warm.json')==s['cohorts'][label]['warm_sha256']
    if name=='hash' and label=='wall-initial' and not (out/'restored.json').exists():
        for n in ('held-base','home-base'):(root/n).rename(root/('excluded-original-'+n))
        common.clone(root/'predecessor',root/'held-base');common.clone(root/'home-candidate',root/'home-base')
        source=root/'source';structural=cfg['source_labels'][0][0]+'00';assert common.set_edit(source,structural[0],0)==cfg['edit_sha256'][structural]
        pending={};assert content(root/'held-base',files(root/'held-base'),pending)==content(root/'held-candidate',files(root/'held-candidate'),pending);assert not pending
        save(out/'restored.json',dict(source_sha256=common.sha(source/common.EDIT),restored_from='immutable structural predecessor; mutable home from untouched matching candidate snapshot'))
    original_run=measure.run;pending={};current={}
    def wrapped(root,arm,cmd,log,*extra):
        current['log']=log
        return original_run(root,arm,cmd,log,*extra)
    def checked(root,before):
        after=files(root/'target');assert sorted(before)==sorted(after)==s['cohorts'][label]['products']
        changed=sorted(k for k in after if before[k]!=after[k]);assert changed==reg['changed'],f'different metadata write roster: {changed}'
        actual_changes=sorted(k for k in after if before[k][0]!=after[k][0]);assert actual_changes==sorted(PREFIX+'{session}/'+leaf for leaf in SLOTS)
        sig=content(root/'target',after,pending)
        raw_snapshot(current['log'].with_suffix('.rmeta-before.json.gz'),before,{k:None for k in before})
        raw_snapshot(current['log'].with_suffix('.rmeta-after.json.gz'),after,sig)
        return sig
    measure.HERE=HERE/name;measure.metadata=lambda root:files(root/'target');measure.checked_metadata=checked;measure.run=wrapped
    try:measure.sample(label,identity,True)
    except BaseException as exc:
        save(out/'rejected.json',dict(reason=str(exc),traceback=traceback.format_exc()));raise
    finally:flush(pending)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['freeze','sample']);p.add_argument('guard',choices=SUBJECTS,nargs='?');p.add_argument('cohort',choices=COHORTS,nargs='?');p.add_argument('--coordinator-released',action='store_true',required=True);a=p.parse_args()
    if a.phase=='freeze':freeze()
    else:assert a.guard and a.cohort;sample(a.guard,a.cohort)
