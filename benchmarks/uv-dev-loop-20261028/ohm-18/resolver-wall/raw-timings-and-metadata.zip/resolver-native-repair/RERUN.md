# Repeat the edited-check timings

Use x86-64 Linux with Python 3.11 or later, `strace`, an eight-CPU affinity mask and an otherwise quiet host. Extract the two resolver counter archives, matched driver binaries and this native evidence at their recorded project-relative paths. Install the official Ohm 1.99.0-18 toolchain under `work/upstream-monitor/toolchain18`, place the pinned uv checkout under `work/uv`, and populate a task-private Cargo registry as described in `work/round18-cargo/RESOLVER-REPLAY.md`. The matched fast Cargo executables have these SHA-256 identities.

| Arm | SHA-256 |
| --- | --- |
| Common baseline | `bc362fc8ece4c1b3c854056792c04e8869216da26b95e4dac8e5fbe6d1922255` |
| Unique name/version hash set | `3cea1d24d8ce9ff9122934d8fd69c5be43356c2c25ee4af5984baffb0b01c279` |
| Strictly increasing adjacent pairs | `83747e12bec8dc80089d573ce79f8c1310e6e45e2942d69fcdda627e7293cdf2` |

The following commands use CPUs 0 through 7. Substitute eight permitted local CPUs throughout. Each preparation registers its original source-edit and order assignments, warms two fresh targets using only the baseline, then binds every metadata product at those two fixture paths. Each sample command runs the prespecified sign and order tests in the primary and repeat cohort. Stop other builds, tests and counters before sampling. Run the two sampling commands sequentially.

```sh
mkdir -p replication-output
script=work/round18-cargo/resolver-native-repair/portable.py
taskset -c 0-7 python3 -I -B "$script" prepare hash replication-output/hash
taskset -c 0-7 python3 -I -B "$script" prepare ordered replication-output/ordered
taskset -c 0-7 python3 -I -B "$script" sample hash replication-output/hash --quiet-host-released
taskset -c 0-7 python3 -I -B "$script" sample ordered replication-output/ordered --quiet-host-released
```

Results and all raw `.rmeta` byte streams are under each output directory. `results/wall-initial/summary.json` and `results/wall-repeat/summary.json` contain median paired reductions, arm medians in nanoseconds, exact sign and balanced-order randomization probabilities, rank intervals and qualification gates. `pristine-rmeta.json.gz` and the per-command `*.rmeta-after.json.gz` files retain physical and logical paths, sizes and full-file hash references.

To re-score the original observations after extracting the evidence, run `python3 -I -B work/round18-cargo/resolver-native-repair/verify.py`. Add `--raw --objects /path/to/resolver-wall-raw-metadata` to hash every archived metadata object. The original collector's zero-row rejection and rejected metadata inventories remain separate from the repaired cohorts.
