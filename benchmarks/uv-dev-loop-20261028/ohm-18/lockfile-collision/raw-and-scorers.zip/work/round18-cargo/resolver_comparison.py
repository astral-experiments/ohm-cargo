"""Combine the two frozen instruction packets and re-score them after extraction."""
import csv
import hashlib
import io
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


suite = Path(__file__).resolve().parent
prefix = 'work/round18-cargo/'
guards = {'hash': ('lockfile-collision', 'recovery/'), 'ordered': ('lockfile-collision-ordered', '')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    files, elfs, originals, sources, lines = {}, {}, {}, {}, []
    table = io.StringIO()
    composer = csv.writer(table)
    composer.writerow(['guard', 'cohort', 'pair', 'first_arm', 'base_instructions', 'candidate_instructions', 'fraction_saved'])
    for guard, (directory, subdir) in guards.items():
        source = suite / f'resolver-{guard}-counters.zip'
        originals[source.name] = digest(source.read_bytes())
        with zipfile.ZipFile(source) as packet:
            for name in packet.namelist():
                data = packet.read(name)
                if data.startswith(b'\x7fELF'):
                    elfs[name] = dict(sha256=digest(data), bytes=len(data), in_archive=source.name)
                else:
                    assert name not in files or files[name] == data, f'conflicting shared input {name}'
                    files[name] = data
        root = prefix + directory + '/' + subdir
        verified = json.loads(files[root + 'verified.json'])
        sources[guard] = verified
        for phase in ('initial', 'repeat'):
            key = 'instructions-' + phase
            measurement = verified['cohorts'][key]
            rows = list(csv.DictReader(io.StringIO(files[root + 'results/' + key + '/samples.csv'].decode())))
            assert len(rows) == 2 * measurement['n'] and measurement['gate']
            for p in range(measurement['n']):
                arms = [r for r in rows if int(r['pair']) == p]
                assert [int(r['position']) for r in arms] == [0, 1]
                assert {r['arm'] for r in arms} == {'base', 'candidate'}
                values = {r['arm']: int(r['value']) for r in arms}
                composer.writerow([guard, phase, p, arms[0]['arm'], values['base'], values['candidate'], 1-values['candidate']/values['base']])
            lo, hi = measurement['median_interval_fraction']
            lines.append(f"| {guard} | {phase} | {measurement['n']} | {measurement['arm_medians']['base']:,.1f} | {measurement['arm_medians']['candidate']:,.1f} | {measurement['median_fraction'] * 100:.4f}% | [{lo*100:.4f}, {hi*100:.4f}]% | {measurement['sign_p']:.6f} | {measurement['balanced_order_p']:.6f} |")

    report = '''# Two lockfile collision guards on Ohm Cargo 1.99.0-18

Both guards bypass the `EncodeResolve` collision check when package name/version pairs prove that serialised package IDs are distinct. The hash-set guard accepts unique pairs in any order. The ordered guard accepts strictly increasing pairs without allocation. Either declines ambiguous input and calls the same existing diagnostic. uv has 728 locked packages, 27 names with multiple versions and zero exact name/version collisions.

Each row compares one guard with the same unmodified version of the earlier stack, using matched non-PGO release-style drivers. The baseline includes the five Cargo changes and Rust standard-library path guard linked into Cargo. These observations count the Cargo process on an ordinary, warmed `cargo check --locked --offline -j8`. Initial observations used DynamoRIO and independent repeats used Cachegrind. No compiler or linker work is included. Fractions are medians of paired reductions. The rank intervals have 96.14% coverage at 12 pairs and 99.22% at 8 pairs.

| Guard | Cohort | Pairs | Base median | Guard median | Saved | Rank interval | Sign p | Order p |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
''' + '\n'.join(lines) + '''

All four cohorts passed their own registered gates. The earlier hash-set screen's counter setup failed before its first observation. Its original log, three successful base-only setup admissions and the narrow certificate-environment recovery are included. Independent schedules and a common comparator do not establish a significant difference between the guards. Native edited-command timings are a separately registered study.

Each guard passed nine Cargo CLI cases and forty direct diagnostic comparisons for lockfile formats v1–v5. The Ohm-only census covered 55 published releases, 285 branch heads and 229 pull request heads (143 open), including both source layouts. Among 304 Cargo-source commits, five file versions retained the same unconditional operation. The two function forms differed only in spelling the empty `HashMap` constructor. Thirteen other commits were benchmark-only. The near matches, source-blob proofs and separate review of [Ohm Cargo #275](https://github.com/astral-sh/ohm-cargo/pull/275) accompany the report. The census timestamp and all refs are in `ohm-source-census/`.

Run these commands at the extracted archive root to check every file and reconstruct both score receipts from raw observations and fixed schedules.

```sh
sha256sum -c SHA256SUMS
python3 -I -B work/round18-cargo/lockfile-collision/verify.py --recovery
python3 -I -B work/round18-cargo/lockfile-collision-ordered/verify.py
python3 -I -B work/round18-cargo/lockfile-collision/render-source-census.py
```

`paired-counts.csv` has all 40 pairs. Raw process outputs, per-pair receipts, protocols, sources, patches and case witnesses are under `work/`. `identities.json` records SHA-256 and the packet for each compiled executable omitted from this compact copy. See `work/round18-cargo/RESOLVER-REPLAY.md` for new-machine reproduction with those binaries or freshly built matched drivers.
'''
    files['README.md'] = report.encode()
    files['paired-counts.csv'] = table.getvalue().encode()
    files['identities.json'] = (json.dumps(dict(original_packets=originals, optional_elfs=elfs, study_gates=sources), indent=2) + '\n').encode()
    files[prefix + Path(__file__).name] = Path(__file__).read_bytes()
    files['SHA256SUMS'] = ''.join(f'{digest(data)}  {name}\n' for name, data in sorted(files.items())).encode()
    output = suite / 'resolver-comparison-evidence.zip'
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=5) as packet:
        for name, data in sorted(files.items()):
            packet.writestr(name, data)
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(output) as packet:
        packet.extractall(tmp)
        subprocess.run(['sha256sum', '-c', 'SHA256SUMS'], cwd=tmp, check=True, stdout=subprocess.DEVNULL)
        for guard, (directory, subdir) in guards.items():
            script = Path(tmp) / prefix / directory / 'verify.py'
            result = script.parent / subdir / 'verified.json'
            old = digest(result.read_bytes())
            subprocess.run([sys.executable, '-I', '-B', str(script), *(['--recovery'] if guard == 'hash' else [])], cwd=tmp, check=True, stdout=subprocess.DEVNULL)
            assert digest(result.read_bytes()) == old
        census = Path(tmp) / prefix / 'lockfile-collision' / 'render-source-census.py'
        subprocess.run([sys.executable, '-I', '-B', str(census)], cwd=tmp, check=True, stdout=subprocess.DEVNULL)
    receipt = dict(sha256=digest(output.read_bytes()), bytes=output.stat().st_size, entries=len(files), paired_rows=40)
    output.with_suffix('.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
