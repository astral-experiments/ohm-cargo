"""Materialize the registered study from the first guard's sealed harness after calibration."""
import argparse,datetime,hashlib,json,os,shutil
from pathlib import Path
here=Path(__file__).resolve().parent;parent=here.with_name("lockfile-collision")
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def read(f):return json.loads(f.read_text())
def save(f,x):f.write_text(json.dumps(x,indent=2)+"\n")
def replace_one(s,a,b):
    if s.count(a)!=1:raise RuntimeError("unexpected source for replacement: "+a)
    return s.replace(a,b)
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--coordinator-released",action="store_true");args=ap.parse_args()
    assert args.coordinator_released and not (parent/"control/pause").exists()
    assert not (here/"measurement-seal.json").exists() and not (here/"harness-inputs.json").exists()
    parent_seal=read(parent/"measurement-seal.json")
    for f,expected in parent_seal["harness"].items():assert sha(parent/f)==expected
    calibration=parent/"excluded-counter-preflight/benign-context/disposition.json"
    selected=read(calibration)["chosen"];assert selected
    cpus=sorted(os.sched_getaffinity(0));assert 4<=len(cpus)<=8
    vals={k:"<per-command working directory>" if k=="PWD" else os.environ[k] for k in selected["keys"]}
    save(here/"counter-affinity.json",dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_plan_sha256=sha(here/"plan.json"),counter_cpus=cpus,benign_context=vals,calibration_sha256=sha(calibration)))
    provenance={}
    for f in ("build.py","common.py","measure.py","correctness.py","probe.rs","stats.py","verify.py","ohm-census.py","source-screen.json"):
        src=parent/f;s=src.read_text()
        if f in ("build.py","correctness.py"):s=replace_one(s,"guard-stack-plus-lockfile-collision","guard-stack-plus-lockfile-collision-ordered")
        if f=="correctness.py":s=replace_one(s,"collision-proof-18/correctness","collision-ordered-18/correctness")
        if f=="stats.py":
            s=replace_one(s,"    median=statistics.median(gains)","    cutoff=.025 if n==12 or wall_initial else .05\n    median=statistics.median(gains)")
            s=replace_one(s,"sign<.05 and order<.05","sign<cutoff and order<cutoff")
        if f=="common.py":
            s=replace_one(s,"    val=WORK/",'    context=read(HERE/"counter-affinity.json")["benign_context"]\n    for key,value in context.items():\n        clean[key]=str(root/"source") if key=="PWD" else value\n    val=WORK/')
        (here/f).write_text(s)
        provenance[f]=dict(parent_sha256=sha(src),local_sha256=sha(here/f))
    text=(parent/"COUNTER-AND-PILOT.md").read_text()
    (here/"COUNTER-AND-PILOT.md").write_text("# Ordered comparison control details\n\nUse this directory’s own registered plan, fixture locations, three explicit CPU and environment receipts, and tighter primary alpha. The implementation of the two counters, rank intervals, native compiler admission, and workload/output verification is identical to the separately sealed first guard.\n\n"+text)
    save(here/"harness-inputs.json",dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_original_seal_sha256=sha(parent/"measurement-seal.json"),sources=provenance,preparation_sha256=sha(Path(__file__).resolve())))
if __name__=="__main__":main()
