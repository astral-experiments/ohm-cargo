# Ordered comparison control details

Use this directory’s own registered plan, fixture locations, three explicit CPU and environment receipts, and tighter primary alpha. The implementation of the two counters, rank intervals, native compiler admission, and workload/output verification is identical to the separately sealed first guard.

# Release-18 resolver guard measurement details

These details were fixed before the candidate was built or observed. The source hunk, workloads, randomized assignments, edits and qualification gates remain in the original `plan.json` and `PROTOCOL.md`.

Use the stable Cargo slot and private offline registry at each cohort’s registered location. Allow four unmeasured native and four unmeasured instrumented freshness runs before its frozen counter series. After initial preparation, park an independent target and the complete mutable part of each Cargo home for each arm. Snapshot the common structural predecessor independently for both wall arms. Record the exact traced native rustc argv and every rewritten metadata output during each excluded 01 admission. The native held-out invocations run directly with no tracer or compiler wrapper. The per-pair checks compare the Cargo rebuilt-package roster and all rewritten `.rmeta` paths and hashes with the admitted units. Compare complete bytes for the two arms of each edit. Trace presence of any extra process on a fresh admission or any linker or test on an edited admission rejects the workload. The child environment is an explicit allowlist so the full traced argv and environment can be retained.

Report the median paired fractional reduction, medians of the two arms, the exact two-sided sign test after dropping ties, and the narrowest symmetric order-statistic median interval with coverage at least 95%. The balanced-order test uses the absolute sum of log(control/treatment) across pairs. Enumerate exactly every possible assignment of half the pairs to control-first using the observed first-versus-second log ratios, with two-sided tails. Numerical boundary tolerance is 10⁻¹² on the summed log statistic. A 24-pair result has 2,704,156 eligible order allocations.

The first counter measures DynamoRIO dynamic application instructions in the original Cargo PID and all its threads, with child following disabled. Cachegrind’s independent repeat counts Cargo’s instruction references. No rustc compilation or package build is admitted in these two no-work cohorts. Neither counter includes kernel execution. The wall cohorts measure the whole, real edited check including its released rustc process. A native timing window needs an explicit release plus two five-second CPU/IO/worker quiet probes before and after each entire cohort.

CLI fixtures compare real generated lockfile bytes for two distinct versions of a package, and compare the entire stderr and status for a colliding same-version pair on different paths. Rust-version declarations select V1 through V4 in the actual resolver. V5 can be read explicitly, but the public CLI resolution path selects at most V4 by MSRV. A separate fixture therefore feeds actual Cargo `Resolve` graphs to the original and guarded functions at every V1–V5. The fixture extracts the original Rust function bodies and their actual encoders verbatim from the registered sources, gives both private functions module-level test visibility, and links the candidate’s verified Cargo library. It compares exact error text and success over path, Git, mixed-source, legacy branch, distinct-version and empty inputs.

The coordinator assigned CPUs 24–27 for the counter cohorts in a pre-observation amendment. Use `CPUSET=24-27` below for the actual allocation. The wall cohorts retain the original eight-CPU requirement, with the same assignment sealed across both cohorts before the first native admission. The build must precede the subject hash seal. See the release-18 driver recipe for the exact private stack and toolchain files.

```sh
suffix=work/round18-cargo/lockfile-collision
CPUSET=24-27
taskset -c "$CPUSET" python3 -B "$suffix/build.py"
taskset -c "$CPUSET" python3 -B "$suffix/measure.py" seal
taskset -c "$CPUSET" python3 -B "$suffix/measure.py" correctness
for cohort in instructions-initial instructions-repeat; do
  taskset -c "$CPUSET" python3 -B "$suffix/measure.py" warm "$cohort"
  taskset -c "$CPUSET" python3 -B "$suffix/measure.py" sample "$cohort"
done
```

If both independent instruction gates pass, bootstrap the two new roots with the same `warm` command for `wall-initial` and `wall-repeat`. In the later explicitly released quiet window run each sequentially with `sample COHORT --coordinator-released`.
