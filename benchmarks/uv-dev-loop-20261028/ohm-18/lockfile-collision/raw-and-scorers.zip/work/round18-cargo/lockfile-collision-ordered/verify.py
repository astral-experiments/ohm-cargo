"""Verify all available observations from their archived logs and randomized schedule."""
import csv,hashlib,json,re,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from stats import summarize
def read(p):return json.loads(p.read_text())
def need(ok,why):
    if not ok:raise RuntimeError(why)
def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
plan=read(HERE/"plan.json")
data=HERE/"recovery" if sys.argv[1:]==["--recovery"] else HERE
need(sys.argv[1:] in ([],["--recovery"]),"use --recovery for the separately admitted counter cohort")
need(sha(HERE/"plan.json")== (HERE/"registered.sha256").read_text().split()[0],"original plan changed")
need(sha(HERE/"guard.patch")==plan["patch_sha256"] and sha(HERE/"PROTOCOL.md")==plan["protocol_sha256"],"hunk or protocol changed")
identity=read(data/"measurement-seal.json")
if data!=HERE:
    registration=read(data/"registration.json");need(identity["environment_registration_sha256"]==sha(data/"registration.json") and registration["driver_sha256"]==sha(HERE/"recover.py"),"recovery registration changed")
for f,s in identity["harness"].items():need(sha(HERE/f)==s,"sealed harness differs: "+f)
correct=read(HERE/"correctness/PASS.json")
need(len(correct["path_fixtures"])==9 and correct["exact_resolver_cases"]==40,"incomplete correctness receipt")
need(sha(HERE/"correctness/collision_compare.rs")==correct["probe_sha256"],"exact generated resolver probe changed")
for n in range(1,5):
    for kind in ("distinct","duplicate"):
        d=HERE/"correctness";b=d/f"v{n}-path-{kind}-base";c=d/f"v{n}-path-{kind}-candidate"
        suffix=".lock" if kind=="distinct" else ".log"
        need(b.with_suffix(suffix).read_bytes()==c.with_suffix(suffix).read_bytes(),"path fixture output changed")
need((HERE/"correctness/two-file-git-base.lock").read_bytes()==(HERE/"correctness/two-file-git-candidate.lock").read_bytes(),"Git lockfile bytes differ")
results={}
for label,cfg in plan["cohorts"].items():
    d=data/"results"/label;wall=label.startswith("wall")
    if (d/"rejected.json").is_file():
        results[label]=dict(state="excluded",reason=read(d/"rejected.json"));continue
    if not (d/"summary.json").is_file():
        results[label]=dict(state="not complete");continue
    want=read(d/"warm.json");need(want["identity"]["cargo"]==identity["cargo"],"subject identities differ")
    raw=list(csv.DictReader((d/"samples.csv").open()));need(len(raw)==2*cfg["n"],"wrong row count")
    pairs=[]
    for i,order in enumerate(cfg["order"]):
        pair={"order":order};previous=None
        for j,arm in enumerate(order):
            row=raw[2*i+j];need(row["pair"]==str(i) and row["position"]==str(j) and row["arm"]==arm,"frozen assignments differ")
            f=d/f"pair-{i:02}-{j}-{arm}.json";need(row["receipt"]==f.name,"wrong audit receipt")
            rec=read(f);body=f.with_suffix(".log").read_text(errors="replace")
            need(int(row["value"])==rec["value"] and rec["arm"]==arm and rec["edit_sha256"]==row["edit_sha256"],"receipt and CSV differ")
            roster=sorted(re.findall(r"^\s*(?:Checking|Compiling) (.+)$",body,re.M))
            need(roster==rec["compiled"] and not re.search(r"^\s*(Running|Blocking|Downloading|Updating) |^running \d+ test",body,re.M),"workload changed")
            need(re.search(r"^\s*Finished ",body,re.M),"Cargo did not finish")
            if wall:
                ref=read(d/"admit-base.json");need(ref==read(d/"admit-candidate.json"),"native admission mismatch")
                need(roster==ref["compiled"] and set(rec["metadata"])==set(ref["metadata"]),"native roster changed")
                need(row["metric"]=="elapsed_ns" and rec["value"]>0 and row["edit_sha256"]==cfg["edit_sha256"][cfg["source_labels"][i]],"wrong edit/time")
            else:
                need(not roster and row["metric"]=="Cargo_PID_instructions" and row["edit_sha256"]==want["source_sha256"],"unsettled Cargo-only count")
                if label=="instructions-initial":
                    dr=json.loads(re.findall(r"^DynamoRIO (.+)$",body,re.M)[-1])
                    value=sum(dr["threads"].values());need(str(dr["pid"]) in dr["threads"] and value==dr["instructions"],"DynamoRIO thread totals disagree")
                else:
                    commands=re.findall(r"^==(\d+)== Command: (.+)$",body,re.M)
                    require_command=str(Path(cfg["fixture"])/"bin/cargo")+" "+" ".join(cfg["command"])
                    need(len(commands)==1 and commands[0][1]==require_command,"Cachegrind did not identify the expected Cargo PID")
                    values=re.findall(r"^==(\d+)== I\s+refs:\s*([\d,]+)\s*$",body,re.M)
                    need(len(values)==1 and values[0][0]==commands[0][0],"extra or missing Cachegrind PID")
                    value=int(values[0][1].replace(",",""))
                need(value==rec["value"],"reported instruction value differs from counter")
            observed=(rec["metadata"],rec["edit_sha256"],rec["edit_mtime_ns"])
            if previous:need(observed==previous,"paired outputs or source state differ")
            previous=observed;pair[arm]=rec["value"]
        pairs.append(pair)
    stats=summarize(pairs,label=="wall-initial");need(stats==read(d/"summary.json"),"statistics differ")
    results[label]={"state":"verified",**stats}
out=dict(registered_plan=identity["plan_sha256"],identities=identity["cargo"],counter_cpus=identity["cpus"],cohorts=results)
(data/"verified.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
