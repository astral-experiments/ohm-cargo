import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

HERE=Path(__file__).resolve().parent
SUITE=HERE.parent
WORK=SUITE.parent
PLAN=json.loads((HERE/"plan.json").read_text())
RELEASE=WORK/"upstream-monitor/toolchain18"
BENCH=Path((WORK/"bench-home.path").read_text().strip())
EDIT="crates/uv/src/install_source.rs"
ORIGINAL=subprocess.check_output(["git","-C",str(WORK/"uv"),"show",PLAN["uv"]+":"+EDIT])
BASE=Path(PLAN["base"]["path"]);CANDIDATE=Path(PLAN["candidate_path"])
COUNTER=WORK/"dynamorio/count.py"
VALGRIND=WORK/"profiler/usr/bin/valgrind"
def read(p):return json.loads(p.read_text())
def save(p,j):p.write_text(json.dumps(j,indent=2)+"\n")
def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def need(ok,why):
    if not ok:raise RuntimeError(why)
def clone(src,dst):
    need(src.is_dir() and not dst.exists(),f"invalid copy {src}, {dst}")
    subprocess.run(["cp","-a","--reflink=auto",str(src),str(dst)],check=True)
def env(root,*,online=False):
    home=root/"env-home";home.mkdir(exist_ok=True,mode=0o700)
    clean=dict(PATH=str(RELEASE/"bin")+":/usr/bin:/bin:/usr/local/bin",HOME=str(home),TZ="UTC",LC_ALL="C.UTF-8",CARGO_HOME=str(root/"cargo-home"),CARGO_TARGET_DIR=str(root/"target"),CARGO_NET_OFFLINE="false" if online else "true",RUSTC=str(RELEASE/"bin/rustc"),RUSTDOC=str(RELEASE/"bin/rustdoc"),CARGO_TERM_COLOR="never",SSL_CERT_DIR="/etc/ssl/certs")
    context=read(HERE/"counter-affinity.json")["benign_context"]
    for key,value in context.items():
        clean[key]=str(root/"source") if key=="PWD" else value
    val=WORK/"profiler/usr/libexec/valgrind"
    if val.is_dir():clean["VALGRIND_LIB"]=str(val)
    return clean
def seal(wall=False):
    built=read(HERE/"build/ready.json");need(sha(BASE)==PLAN["base"]["sha256"]==built["parent_binary"],"baseline binary")
    need(sha(CANDIDATE)==built["candidate_binary"] and sha(RELEASE/"bin/rustc")==PLAN["rustc_sha256"],"candidate or compiler")
    need(sha(HERE/"guard.patch")==PLAN["patch_sha256"] and sha(HERE/"plan.json")== (HERE/"registered.sha256").read_text().split()[0],"registered hunk or cohort")
    cpus=sorted(os.sched_getaffinity(0));amendment=read(HERE/"counter-affinity.json")
    need(amendment["original_plan_sha256"]==sha(HERE/"plan.json"),"counter allocation targets another plan")
    need(len(cpus)==8 if wall else cpus==amendment["counter_cpus"],"wrong cohort CPU assignment")
    dr=WORK/"dynamorio/DynamoRIO-Linux-11.3.0-1"
    need(sha(HERE/"register.py")==PLAN["reg_code_sha256"] and sha(HERE/"PROTOCOL.md")==PLAN["protocol_sha256"],"source registration changed")
    return {"cpus":cpus,"plan_sha256":sha(HERE/"plan.json"),"cargo":{"base":sha(BASE),"candidate":sha(CANDIDATE)},"rustc":sha(RELEASE/"bin/rustc"),"counter":sha(COUNTER),"dynamorio":{str(p.relative_to(dr)):sha(p) for p in (dr/"bin64/drrun",dr/"lib64/release/libdynamorio.so",dr/"tools/lib64/release/libdrmemtrace.so")},"cachegrind_launcher":sha(VALGRIND),"harness":{f:sha(HERE/f) for f in ("build.py","common.py","measure.py","correctness.py","probe.rs","stats.py","COUNTER-AND-PILOT.md","counter-affinity.json")}}
def setup(root):
    root.mkdir(mode=0o700,parents=True,exist_ok=True);source=root/"source"
    if not source.exists():
        src=root/"source.incoming";src.mkdir()
        with subprocess.Popen(["git","-C",str(WORK/"uv"),"archive",PLAN["uv"]],stdout=subprocess.PIPE) as git:
            subprocess.run(["tar","-x","-C",str(src)],stdin=git.stdout,check=True);need(git.wait()==0,"uv archive failed")
        src.rename(source)
    need((source/EDIT).read_bytes()==ORIGINAL,"unsettled input")
    home=root/"cargo-home";home.mkdir(mode=0o700,exist_ok=True)
    if not (home/"registry").exists():
        clone(BENCH/"cargo/registry",home/"registry.incoming");(home/"registry.incoming").rename(home/"registry")
    tools=root/"bin";tools.mkdir(exist_ok=True,mode=0o700)
    for arm,path in (("base",BASE),("candidate",CANDIDATE)):
        dest=tools/arm
        if not dest.exists():shutil.copy2(path,dest);dest.chmod(0o555)
        need(sha(dest)==sha(path),"fixture ELF changed")
    return source
def select(root,arm):
    src=root/"bin"/arm;dst=root/"bin/cargo";tmp=dst.with_suffix(".next")
    tmp.unlink(missing_ok=True);os.link(src,tmp);os.replace(tmp,dst);tmp.unlink(missing_ok=True)
    need(dst.samefile(src),"bad executable selector")
    return dst
def set_edit(src,label,i):
    key=b"component == cellar && next == formula"
    replacement=('{\n                component == cellar && (next == formula || next == OsStr::new('
                 f'"uv-preview-{label}{i:02d}"))\n            }}').encode()
    f=src/EDIT;f.write_bytes(ORIGINAL.replace(key,replacement));return sha(f)
def run(root,arm,command,log,mode="native"):
    slot=select(root,arm)
    argv=[str(slot),*command]
    if mode=="trace":argv=["strace","-ff","-qq","-v","-s","1048576","-e","trace=execve,execveat","-o",str(log)+".exec",*argv]
    if mode=="dynamorio":argv=[sys.executable,"-B",str(COUNTER),"--",*argv]
    if mode=="cachegrind":argv=[str(VALGRIND),"--tool=cachegrind","--trace-children=no","--cachegrind-out-file=/dev/null",*argv]
    with log.open("x") as f:
        start=time.perf_counter_ns()
        result=subprocess.run(argv,cwd=root/"source",env=env(root),stdout=f,stderr=subprocess.STDOUT)
        ns=time.perf_counter_ns()-start
    body=log.read_text(errors="replace");need(result.returncode==0 and re.search(r"^\s*Finished ",body,re.M),f"Cargo failed: {log}\n"+body[-700:])
    need(not re.search(r"^\s*(Running|Blocking|Updating|Downloading) |^running \d+ test",body,re.M),"test, contention or fetching")
    compiled=sorted(re.findall(r"^\s*(?:Checking|Compiling) (.+)$",body,re.M))
    if mode=="dynamorio":
        raw=json.loads(re.findall(r"^DynamoRIO (.+)$",body,re.M)[-1]);value=raw["instructions"]
        need(str(raw["pid"]) in raw["threads"] and sum(raw["threads"].values())==value,"missing thread instructions")
    elif mode=="cachegrind":value=int(re.findall(r"I\s+refs:\s*([\d,]+)",body)[-1].replace(",",""))
    else:value=ns
    return value,compiled
