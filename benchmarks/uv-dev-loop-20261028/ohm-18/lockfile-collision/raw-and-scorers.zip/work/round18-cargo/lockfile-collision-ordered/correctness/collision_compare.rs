// The generator appends the exact release encoders and both collision functions.
use cargo::resolver::{Resolve, ResolveVersion};
use cargo::util::data_structures::{HashMap, HashSet};
use cargo::util::interning::InternedString;
use cargo::util::Graph;
use cargo::workspace::{GitReference, PackageId, SourceId};
use cargo::CargoResult;
use cargo_util_schemas::lockfile::{TomlLockfilePackageId, TomlLockfileSourceId};
use rustc_hash::FxBuildHasher;

fn pkg(name: &str, version: &str, source: SourceId) -> PackageId {
    PackageId::new(name.into(), version.parse().unwrap(), source)
}

fn case(v: ResolveVersion, name: &str, ids: &[PackageId], collision: bool) {
    let mut g = Graph::new();
    for id in ids { g.add(*id); }
    let resolved = Resolve::new(g, Default::default(), Default::default(), Default::default(),
        Default::default(), vec![], v, Default::default());
    assert_eq!(resolved.len(), ids.len());
    let parent = control::check_duplicate_pkgs_in_lockfile(&resolved).map_err(|e| e.to_string());
    let head = guarded::check_duplicate_pkgs_in_lockfile(&resolved).map_err(|e| e.to_string());
    assert_eq!(parent, head, "{v:?} {name}");
    assert_eq!(head.is_err(), collision, "{v:?} {name}");
    println!("{v:?} {name}: {head:?}");
}

fn main() {
    let a = SourceId::for_path(std::path::Path::new("/a")).unwrap();
    let b = SourceId::for_path(std::path::Path::new("/b")).unwrap();
    let c = SourceId::for_path(std::path::Path::new("/c")).unwrap();
    let git = SourceId::from_url("git+https://fixtures.invalid/one").unwrap();
    let other = SourceId::from_url("git+https://fixtures.invalid/two").unwrap();
    let master = SourceId::from_url("git+https://fixtures.invalid/one?branch=master").unwrap();
    for v in [ResolveVersion::V1, ResolveVersion::V2, ResolveVersion::V3, ResolveVersion::V4, ResolveVersion::V5] {
        let one = pkg("one","1.0.0",a);
        case(v,"empty",&[],false);
        case(v,"single",&[one],false);
        case(v,"distinct-names",&[one,pkg("two","1.0.0",b)],false);
        case(v,"same-name-three-versions",&[one,pkg("one","1.0.1",b),pkg("one","1.0.1+build",c)],false);
        case(v,"three-paths-first-error",&[pkg("one","1.0.0",c),one,pkg("one","1.0.0",b)],true);
        case(v,"mixed-path-git",&[one,pkg("one","1.0.0",git)],false);
        case(v,"different-git-sources",&[pkg("one","1.0.0",git),pkg("one","1.0.0",other)],false);
        case(v,"default-git-versus-master",&[pkg("one","1.0.0",git),pkg("one","1.0.0",master)],v<=ResolveVersion::V2);
    }
}

mod encode { use super::*;
pub struct EncodeState<'a> {
    counts: Option<HashMap<InternedString, HashMap<&'a semver::Version, usize>>>,
}
impl<'a> EncodeState<'a> {
    pub fn new(resolve: &'a Resolve) -> EncodeState<'a> {
        let counts = if resolve.version() >= ResolveVersion::V2 {
            let mut map = HashMap::default();
            for id in resolve.iter() {
                let slot = map
                    .entry(id.name())
                    .or_insert_with(HashMap::default)
                    .entry(id.version())
                    .or_insert(0);
                *slot += 1;
            }
            Some(map)
        } else {
            None
        };
        EncodeState { counts }
    }
}
pub fn encodable_package_id(
    id: PackageId,
    state: &EncodeState<'_>,
    resolve_version: ResolveVersion,
) -> TomlLockfilePackageId {
    let name = id.name().to_string();
    if let Some(counts) = &state.counts {
        let versions = &counts[&id.name()];
        if versions[id.version()] == 1 {
            return TomlLockfilePackageId {
                name,
                version: (versions.len() > 1).then(|| id.version().to_string()),
                source: None,
            };
        }
    }

    let mut id_to_encode = id.source_id();
    if resolve_version <= ResolveVersion::V2 {
        if let Some(GitReference::Branch(b)) = id_to_encode.git_reference() {
            if b == "master" {
                id_to_encode =
                    SourceId::for_git(id_to_encode.url(), GitReference::DefaultBranch).unwrap();
            }
        }
    }
    TomlLockfilePackageId {
        name,
        version: Some(id.version().to_string()),
        source: encodable_source_id(id_to_encode.without_precise(), resolve_version),
    }
}
fn encodable_source_id(id: SourceId, version: ResolveVersion) -> Option<TomlLockfileSourceId> {
    if id.is_path() {
        None
    } else {
        Some(
            if version >= ResolveVersion::V4 {
                TomlLockfileSourceId::new(id.as_encoded_url().to_string())
            } else {
                TomlLockfileSourceId::new(id.as_url().to_string())
            }
            .expect("source ID should have valid URLs"),
        )
    }
}
}
mod control { use super::*;
pub(super) fn check_duplicate_pkgs_in_lockfile(resolve: &Resolve) -> CargoResult<()> {
    let mut unique_pkg_ids = HashMap::default();
    let state = encode::EncodeState::new(resolve);
    for pkg_id in resolve.iter() {
        let encodable_pkd_id = encode::encodable_package_id(pkg_id, &state, resolve.version());
        if let Some(prev_pkg_id) = unique_pkg_ids.insert(encodable_pkd_id, pkg_id) {
            anyhow::bail!(
                "package collision in the lockfile: packages {} and {} are different, \
                 but only one can be written to lockfile unambiguously",
                prev_pkg_id,
                pkg_id
            )
        }
    }
    Ok(())
}
}
mod guarded { use super::*;
pub(super) fn check_duplicate_pkgs_in_lockfile(resolve: &Resolve) -> CargoResult<()> {
    // Strictly increasing name-version pairs cannot collide when encoded.
    if resolve
        .iter()
        .map(|id| (id.name(), id.version()))
        .is_sorted_by(|a, b| a < b)
    {
        return Ok(());
    }

    let mut unique_pkg_ids = HashMap::default();
    let state = encode::EncodeState::new(resolve);
    for pkg_id in resolve.iter() {
        let encodable_pkd_id = encode::encodable_package_id(pkg_id, &state, resolve.version());
        if let Some(prev_pkg_id) = unique_pkg_ids.insert(encodable_pkd_id, pkg_id) {
            anyhow::bail!(
                "package collision in the lockfile: packages {} and {} are different, \
                 but only one can be written to lockfile unambiguously",
                prev_pkg_id,
                pkg_id
            )
        }
    }
    Ok(())
}
}
