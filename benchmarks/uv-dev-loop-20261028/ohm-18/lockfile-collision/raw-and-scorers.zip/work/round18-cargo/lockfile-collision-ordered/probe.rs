// The generator appends the exact release encoders and both collision functions.
use cargo::resolver::{Resolve, ResolveVersion};
use cargo::util::data_structures::{HashMap, HashSet};
use cargo::util::interning::InternedString;
use cargo::util::Graph;
use cargo::workspace::{GitReference, PackageId, SourceId};
use cargo::CargoResult;
use cargo_util_schemas::lockfile::{TomlLockfilePackageId, TomlLockfileSourceId};
use rustc_hash::FxBuildHasher;

fn pkg(name: &str, version: &str, source: SourceId) -> PackageId {
    PackageId::new(name.into(), version.parse().unwrap(), source)
}

fn case(v: ResolveVersion, name: &str, ids: &[PackageId], collision: bool) {
    let mut g = Graph::new();
    for id in ids { g.add(*id); }
    let resolved = Resolve::new(g, Default::default(), Default::default(), Default::default(),
        Default::default(), vec![], v, Default::default());
    assert_eq!(resolved.len(), ids.len());
    let parent = control::check_duplicate_pkgs_in_lockfile(&resolved).map_err(|e| e.to_string());
    let head = guarded::check_duplicate_pkgs_in_lockfile(&resolved).map_err(|e| e.to_string());
    assert_eq!(parent, head, "{v:?} {name}");
    assert_eq!(head.is_err(), collision, "{v:?} {name}");
    println!("{v:?} {name}: {head:?}");
}

fn main() {
    let a = SourceId::for_path(std::path::Path::new("/a")).unwrap();
    let b = SourceId::for_path(std::path::Path::new("/b")).unwrap();
    let c = SourceId::for_path(std::path::Path::new("/c")).unwrap();
    let git = SourceId::from_url("git+https://fixtures.invalid/one").unwrap();
    let other = SourceId::from_url("git+https://fixtures.invalid/two").unwrap();
    let master = SourceId::from_url("git+https://fixtures.invalid/one?branch=master").unwrap();
    for v in [ResolveVersion::V1, ResolveVersion::V2, ResolveVersion::V3, ResolveVersion::V4, ResolveVersion::V5] {
        let one = pkg("one","1.0.0",a);
        case(v,"empty",&[],false);
        case(v,"single",&[one],false);
        case(v,"distinct-names",&[one,pkg("two","1.0.0",b)],false);
        case(v,"same-name-three-versions",&[one,pkg("one","1.0.1",b),pkg("one","1.0.1+build",c)],false);
        case(v,"three-paths-first-error",&[pkg("one","1.0.0",c),one,pkg("one","1.0.0",b)],true);
        case(v,"mixed-path-git",&[one,pkg("one","1.0.0",git)],false);
        case(v,"different-git-sources",&[pkg("one","1.0.0",git),pkg("one","1.0.0",other)],false);
        case(v,"default-git-versus-master",&[pkg("one","1.0.0",git),pkg("one","1.0.0",master)],v<=ResolveVersion::V2);
    }
}
