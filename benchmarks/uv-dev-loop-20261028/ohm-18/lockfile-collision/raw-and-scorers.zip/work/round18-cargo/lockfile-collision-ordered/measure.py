import argparse,ast,contextlib,csv,os,re,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *
from stats import summarize

def boundary(label,point):
    ctl=HERE/"control";ctl.mkdir(exist_ok=True)
    def report(state):
        rec=dict(utc_unix_ns=time.time_ns(),pid=os.getpid(),state=state,cohort=label,boundary=point)
        tmp=ctl/"status.pending";save(tmp,rec);tmp.replace(ctl/"status.json")
        with (ctl/"boundaries.jsonl").open("a") as stream:stream.write(json.dumps(rec)+"\n")
    if (ctl/"pause").exists():
        report("paused")
        while (ctl/"pause").exists():time.sleep(2)
    report("released")

def snapshot_home(src,dst):
    dst.mkdir(mode=0o700,exist_ok=True)
    for f in dst.iterdir():
        if f.name=="registry":continue
        if f.is_dir() and not f.is_symlink():shutil.rmtree(f)
        else:f.unlink()
    for f in src.iterdir():
        if f.name!="registry":subprocess.run(["cp","-a","--reflink=auto",str(f),str(dst/f.name)],check=True)

@contextlib.contextmanager
def parked(root,arm):
    t=root/"target";hold=root/("held-"+arm);home=root/"cargo-home";state=root/("home-"+arm)
    hold.rename(t);snapshot_home(state,home)
    try:yield
    finally:
        t.rename(hold);snapshot_home(home,state)

def trace(log,root):
    # -v emits argv and environment. The subprocess starts with common.env's explicit allowlist.
    rustc=str(RELEASE/"bin/rustc");cargo=str(root/"bin/cargo");records=[];progs=[]
    quoted=r'"(?:[^"\\]|\\.)*"'
    entry=re.compile(r'^execve\(('+quoted+r'), (\[(?:'+quoted+r'(?:, )?)*\]), ')
    for receipt in sorted(log.parent.glob(log.name+".exec.*")):
        for ln in receipt.read_text(errors="replace").splitlines():
            if not ln.endswith("= 0") or not ln.startswith("execve"):continue
            m=entry.match(ln);need(m,f"unparsed successful exec in {receipt}")
            path=ast.literal_eval(m[1]);argv=ast.literal_eval(m[2]);progs.append(path)
            need(path in (cargo,rustc),"unadmitted process executed: "+path)
            if path==rustc and "--crate-name" in argv:
                records.append(argv)
    need(progs.count(cargo)==1,"missing or extra Cargo exec")
    return sorted(records)

def metadata(root):
    target=root/"target";observed={}
    for f in target.rglob("*.rmeta"):
        st=f.stat();observed[str(f.relative_to(target))]=(st.st_size,st.st_mtime_ns,st.st_ino)
    return observed

def checked_metadata(root,before):
    after=metadata(root)
    need(not (before.keys()-after.keys()),"removed metadata")
    which=[s for s,st in after.items() if before.get(s)!=st]
    need(which,"no rewritten metadata for edited uv")
    return {s:sha(root/"target"/s) for s in sorted(which)}

def quiet(out,cpus):
    def sample():
        rows=[list(map(int,line.split()[1:9])) for line in Path("/proc/stat").read_text().splitlines() if line.split()[0] in {f"cpu{c}" for c in cpus}]
        return [sum(v) for v in zip(*rows)]
    def workers():
        names={"rustc","cargo","wild","ld.bfd","ld","collect2","rust-lld","drrun","valgrind","ninja","llvm-profdata","cc1","cc1plus"}
        found=[]
        for process in Path("/proc").glob("[0-9]*"):
            try:p=(process/"exe").resolve(strict=True)
            except (FileNotFoundError,ProcessLookupError,PermissionError):continue
            if p.name in names or p.name.startswith(("cargo-","rustc-","clang-")) or (p.name in ("base","candidate","guard-stack") and (p.is_relative_to(WORK) or p.is_relative_to(BENCH))):found.append([process.name,p.name])
        return found
    passes=0
    with out.open("x",buffering=1) as f:
        while passes<2:
            a=sample();time.sleep(5);b=sample();d=[y-x for x,y in zip(a,b)]
            total=sum(d);busy=1-(d[3]+d[4])/total;wait=d[4]/total
            mem={k.rstrip(":"):int(v) for k,v,*_ in (s.split() for s in Path("/proc/meminfo").read_text().splitlines())}
            w=workers();ok=busy<.03 and wait<.01 and mem["Writeback"]==0 and mem["Dirty"]<262144 and not w
            passes=passes+1 if ok else 0
            f.write(json.dumps([time.time_ns(),busy,wait,mem["Dirty"],mem["Writeback"],w,passes])+"\n")

def warm(label,identity):
    cfg=PLAN["cohorts"][label];root=Path(cfg["fixture"]);out=HERE/"results"/label
    out.mkdir(parents=True,exist_ok=True);need(not (out/"warm.json").exists(),"preparation already sealed")
    boundary(label,"before fixture preparation")
    src=setup(root);lock=sha(src/"Cargo.lock");cmd=cfg["command"]
    need(lock==read(HERE/"source-screen.json")["lock_sha256"],"unexpected uv lockfile")
    _,roster=run(root,"base",cmd,out/"bootstrap.log");need(any(x.startswith("uv v") for x in roster),"did not warm entire uv")
    wall=label.startswith("wall")
    if wall:
        pre=cfg["source_labels"][0][0]+"00"
        need(set_edit(src,pre[0],0)==cfg["edit_sha256"][pre],"structural edit")
        _,r=run(root,"base",cmd,out/"structural.log");need(any(x.startswith("uv v") for x in r),"missing structural uv rebuild")
    _,ro=run(root,"base",cmd,out/"settled.log","trace")
    need(ro==[] and not trace(out/"settled.log",root),"fresh target compiled packages")
    need(sha(src/"Cargo.lock")==lock,"mutated uv lockfile")
    for arm in ("base","candidate"):
        clone(root/"target",root/("held-"+arm))
        snapshot_home(root/"cargo-home",root/("home-"+arm))
    (root/"target").rename(root/"predecessor")
    save(out/"warm.json",dict(identity=identity,lock_sha256=lock,source_sha256=sha(src/EDIT),cold_roster=roster))
    boundary(label,"after fixture preparation")

def sample(label,identity,release):
    cfg=PLAN["cohorts"][label];root=Path(cfg["fixture"]);out=HERE/"results"/label;src=root/"source"
    boundary(label,"before admission or counter warmup")
    warm_record=read(out/"warm.json");need(warm_record["identity"]==identity,"affinity or subject changed after preparation")
    wall=label.startswith("wall");mode=("dynamorio" if label=="instructions-initial" else "cachegrind") if not wall else "native"
    if wall:
        need(release,"native host release is required")
        for name in ("instructions-initial","instructions-repeat"):need(read(HERE/"results"/name/"summary.json")["gate"],"both independent instruction gates required")
        quiet(out/"preflight.jsonl",identity["cpus"])
    cmd=cfg["command"];need(sha(src/"Cargo.lock")==warm_record["lock_sha256"],"lockfile changed")
    reference=None
    if wall:
        key=cfg["source_labels"][0][0]+"01";stamp=time.time_ns()
        for arm in ("base","candidate"):
            with parked(root,arm):
                need(set_edit(src,key[0],1)==cfg["edit_sha256"][key],"admission edit")
                os.utime(src/EDIT,ns=(stamp,stamp));before=metadata(root);log=out/("admit-"+arm+".log")
                _,ro=run(root,arm,cmd,log,"trace");args=trace(log,root);meta=checked_metadata(root,before)
                need(len(ro)==1 and ro[0].startswith("uv v") and args,"missing edited compiler workload")
                for a in args:
                    need(a[a.index("--crate-name")+1] in ("uv","uvx") and any(s.startswith("--emit=") and "metadata" in s and "link" not in s for s in a),"unexpected check compiler unit")
                admission=dict(compiled=ro,rustc_argv=args,metadata=meta);save(out/("admit-"+arm+".json"),admission)
                if reference is None:reference=admission
                else:need(admission==reference,"native arms differ on identical predecessor and source")
    else:
        for warm_mode in ("native",mode):
            for i,arm in enumerate(("base","candidate","base","candidate")):
                with parked(root,arm):
                    _,ro=run(root,arm,cmd,out/f"settle-{warm_mode}-{i}-{arm}.log",warm_mode);need(not ro,"counter preparation compiled a package")
    boundary(label,"before paired observations")
    rows=[]
    with (out/"samples.csv").open("x",newline="") as f:
        writer=csv.DictWriter(f,["pair","position","arm","value","metric","edit_sha256","receipt"]);writer.writeheader()
        for i,order in enumerate(cfg["order"]):
            pair=dict(order=order);evidence=[]
            if wall:
                key=cfg["source_labels"][i];stamp=time.time_ns()
                need(set_edit(src,key[0],int(key[1:]))==cfg["edit_sha256"][key],"held-out edit")
                os.utime(src/EDIT,ns=(stamp,stamp))
            for position,arm in enumerate(order):
                with parked(root,arm):
                    log=out/f"pair-{i:02}-{position}-{arm}.log";before=metadata(root) if wall else None
                    value,ro=run(root,arm,cmd,log,mode)
                    need(ro==(reference["compiled"] if wall else []),"changed build workload")
                    meta=checked_metadata(root,before) if wall else {}
                    if wall:need(meta.keys()==reference["metadata"].keys(),"changed compiler output-unit roster")
                    rec=dict(arm=arm,compiled=ro,edit_sha256=sha(src/EDIT),edit_mtime_ns=(src/EDIT).stat().st_mtime_ns,metadata=meta,value=value)
                    logfile=log.with_suffix(".json");save(logfile,rec);pair[arm]=value;evidence.append((rec["edit_sha256"],rec["edit_mtime_ns"],meta))
                    writer.writerow(dict(pair=i,position=position,arm=arm,value=value,metric=("elapsed_ns" if wall else "Cargo_PID_instructions"),edit_sha256=rec["edit_sha256"],receipt=logfile.name));f.flush()
            need(evidence[0]==evidence[1],"paired source or compiler output bytes differed")
            rows.append(pair)
            boundary(label,f"after complete pair {i+1}")
    need(sha(src/"Cargo.lock")==warm_record["lock_sha256"],"lockfile changed")
    if wall:quiet(out/"postflight.jsonl",identity["cpus"])
    result=summarize(rows,label=="wall-initial");save(out/"summary.json",result);print(label,json.dumps(result),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=("seal","correctness","warm","sample"));ap.add_argument("cohort",nargs="?",choices=PLAN["cohorts"]);ap.add_argument("--coordinator-released",action="store_true")
    args=ap.parse_args();wall=bool(args.cohort and args.cohort.startswith("wall"));identity=seal(wall);f=HERE/"measurement-seal.json"
    if args.phase=="seal":
        need(not f.exists(),"already sealed");save(f,identity);return
    original=read(f)
    if wall:
        original["cpus"]=identity["cpus"]
        native=HERE/"native-seal.json"
        if not native.exists():
            need(args.phase=="warm" and all(read(HERE/"results"/c/"summary.json")["gate"] for c in ("instructions-initial","instructions-repeat")),"both counter gates required before native preparation")
            save(native,identity)
        need(read(native)==identity,"native cohorts require the same eight CPUs")
    need(original==identity,"harness, binaries or CPU assignment changed")
    if args.phase=="correctness":
        from correctness import execute
        execute();return
    need((HERE/"correctness/PASS.json").is_file() and args.cohort,"correctness or cohort missing")
    if args.phase=="warm":warm(args.cohort,identity)
    else:
        out=HERE/"results"/args.cohort
        try:sample(args.cohort,identity,args.coordinator_released)
        except BaseException as ex:
            if not (out/"rejected.json").exists():save(out/"rejected.json",dict(reason=str(ex),type=type(ex).__name__))
            raise
if __name__=="__main__":main()
