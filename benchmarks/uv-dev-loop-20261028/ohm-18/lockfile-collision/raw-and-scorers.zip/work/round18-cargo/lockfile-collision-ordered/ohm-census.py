"""Read the Ohm release/branch/PR sources for a qualified resolver guard. No remote writes."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import base64,gzip,hashlib,json,os,re,subprocess,sys

HERE=Path(__file__).resolve().parent
WORK=HERE.parent.parent
GH="/home/dev-user/.local/bin/gh-auto"
ROUTE="/home/dev-user/code/oss/relic"
REPO="astral-sh/ohm-cargo"
PATHS=("src/resolver/mod.rs","src/cargo/core/resolver/mod.rs")
OUT=HERE/"ohm-source-census"
def gh(*args):return subprocess.check_output([GH,*args],cwd=ROUTE)
def get(api,fields):return [json.loads(s) for s in gh("api","--paginate",api,"--jq",fields+"|tojson").decode().splitlines()]
def save(p,x):p.write_text(json.dumps(x,indent=1)+"\n")
def require(ok,message):
    if not ok:raise RuntimeError(message)
def graph(group):
    parts=" ".join(f'q{i}:object(expression:{json.dumps(sha+":"+path)}){{... on Blob{{oid byteSize}}}}' for i,(sha,path) in enumerate(group))
    query='{repository(owner:"astral-sh",name:"ohm-cargo"){'+parts+'}}'
    payload=json.loads(gh("api","graphql","-f","query="+query))["data"]["repository"]
    return {(sha,path):payload[f"q{i}"] for i,(sha,path) in enumerate(group)}
def blob(oid):
    path=OUT/"blobs"/(oid+".rs.gz")
    if path.exists():return gzip.decompress(path.read_bytes())
    got=subprocess.run(["git","-C",str(WORK/"ohm-cargo"),"cat-file","blob",oid],env=dict(os.environ,GIT_NO_LAZY_FETCH="1"),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    raw=got.stdout if got.returncode==0 else base64.b64decode(json.loads(gh("api",f"repos/{REPO}/git/blobs/{oid}"))["content"])
    require(hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==oid,"wrong blob identity")
    path.write_bytes(gzip.compress(raw,mtime=0));return raw
def classify(raw):
    s=raw.decode();lines=s.splitlines();needle="fn check_duplicate_pkgs_in_lockfile("
    callers=[{"line":i+1,"context":lines[max(0,i-6):i+5]} for i,line in enumerate(lines) if "check_duplicate_pkgs_in_lockfile(" in line and needle not in line]
    if needle not in s:return {"requires_review":"function absent or renamed","callers":callers}
    i=s.index(needle);end=s.find("\n}",i)
    require(end>i,"could not delimit candidate function")
    fn=s[i:end+2]
    return dict(start_line=s[:i].count("\n")+1,source=fn,normalized_body=hashlib.sha256(re.sub(r'\s+','',fn).encode()).hexdigest(),callers=callers)
def main():
    for cohort in ("instructions-initial","instructions-repeat"):
        require(json.loads((HERE/"results"/cohort/"summary.json").read_text())["gate"],"both independent instruction gates must pass before the live census")
    require(gh("api","user","--jq",".login").strip()==b"charliermarsh","wrong GitHub account")
    OUT.mkdir(exist_ok=True);(OUT/"blobs").mkdir(exist_ok=True)
    branches=get(f"repos/{REPO}/branches?per_page=100",".[]|{name,sha:.commit.sha}")
    prs=get(f"repos/{REPO}/pulls?state=all&per_page=100",".[]|{number,title,state,merged_at,html_url,sha:.head.sha}")
    releases=get("repos/astral-sh/ohm/releases?per_page=100",".[]|{tag_name,draft,prerelease,html_url}")
    cached={r["tag_name"]:r for r in json.loads((WORK/"upstream-monitor/rust/release-history.json").read_text())["releases"]}
    refs={};release_pins={}
    for r in releases:
        tag=r["tag_name"];m=re.fullmatch(r"ohm-(\d+\.\d+\.\d+)-(\d+)",tag)
        if not m or r["draft"]:continue
        if tag in cached:pin=cached[tag]["cargo"]
        else:
            path=f"toolchains/{m[1]}/{m[2]}.json";mdata=json.loads(gh("api",f"repos/astral-sh/ohm/contents/{path}?ref={tag}"))
            manifest=json.loads(base64.b64decode(mdata["content"]));pin=manifest["sources"]["cargo"]["revision"]
        release_pins[tag]=pin;refs.setdefault(pin,{}).setdefault("releases",[]).append(tag)
    for r in branches:refs.setdefault(r["sha"],{}).setdefault("branches",[]).append(r["name"])
    for r in prs:refs.setdefault(r["sha"],{}).setdefault(r["state"]+"_prs",[]).append(r["number"])
    default=gh("api",f"repos/{REPO}","--jq",".default_branch").decode().strip()
    save(OUT/"inventory.json",dict(as_of=datetime.now(timezone.utc).isoformat(),default_branch=default,branches=branches,prs=prs,releases=release_pins))
    items=[(ref,path) for ref in refs for path in PATHS]
    with ThreadPoolExecutor(max_workers=3) as ex:
        probes={k:v for result in ex.map(graph,[items[i:i+60] for i in range(0,len(items),60)]) for k,v in result.items()}
    findings={}
    for ref,entry in refs.items():
        choices=[(path,probes[ref,path]["oid"]) for path in PATHS if probes[ref,path]]
        if not choices:
            tree=json.loads(gh("api",f"repos/{REPO}/git/trees/{ref}?recursive=1"))
            require(not tree.get("truncated"),"incomplete alternate-path search for "+ref)
            candidates=[e for e in tree["tree"] if e["type"]=="blob" and re.search(r"(?:^|/)resolver(?:/mod)?\.rs$",e["path"])]
            choices=[(e["path"],e["sha"]) for e in candidates]
            if not choices:
                entry["root_names"]=sorted({x["path"].split("/")[0] for x in tree["tree"]})
                entry["source_absent"]=True
        entry["resolver_sources"]={}
        for path,oid in choices:
            if oid not in findings:findings[oid]=classify(blob(oid))
            entry["resolver_sources"][path]=oid
    save(OUT/"refs.json",refs);save(OUT/"source-findings.json",findings)
    print(len(branches),"branches,",len(prs),"all PR heads,",len(release_pins),"releases,",len(refs),"commits,",len(findings),"distinct resolver blobs. Review source-findings and any alternate paths before publication.")
if __name__=="__main__":main()
