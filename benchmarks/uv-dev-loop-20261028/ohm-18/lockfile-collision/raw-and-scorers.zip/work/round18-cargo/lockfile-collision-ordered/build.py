"""Build the single registered guard from an untouched release-18 fast-stack snapshot."""
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;suite=here.parent
sys.path.insert(0,str(suite/"recipe"))
from prepare import digest,tree

def main():
    plan=json.loads((here/"plan.json").read_text());cfg=json.loads((suite/"inputs.json").read_text())
    assert digest(here/"plan.json")== (here/"registered.sha256").read_text().split()[0]
    assert digest(here/"guard.patch")==plan["patch_sha256"]
    prior=json.loads((suite/"fast/guard-stack/ready.json").read_text());base=Path(plan["base"]["path"])
    assert digest(base)==plan["base"]["sha256"]==prior["cargo_sha256"]
    affinity=sorted(os.sched_getaffinity(0));assert 1<=len(affinity)<=8
    stage=Path(cfg["scratch"])/"fast";src,lib,target=[stage/n for n in ("cargo-src","library","target")]
    park=stage/"guard-stack-plus-lockfile-collision-ordered";assert not park.exists()
    out=here/"build";out.mkdir();park.mkdir()
    for f in (src,lib,target):
        assert not f.exists()
        subprocess.run(["cp","-a","--reflink=auto",str(stage/"guard-stack"/f.name),str(f)],check=True)
    try:
        f=src/"src/resolver/mod.rs"
        assert tree(src)==prior["source_tree"]==plan["parent_cargo_tree"]
        assert digest(lib/"std/src/path.rs")==prior["std_path_source_sha256"] and digest(f)==plan["source_from_sha256"]
        subprocess.run(["git","apply","--no-index","--check",str(here/"guard.patch")],cwd=src,check=True)
        subprocess.run(["git","apply","--no-index",str(here/"guard.patch")],cwd=src,check=True)
        assert digest(f)==plan["source_to_sha256"]
        tool=Path(cfg["toolchain"])/"bin"
        base_env={k:v for k,v in os.environ.items() if k not in ("RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","CARGO_BUILD_RUSTFLAGS","LLVM_PROFILE_FILE") and not k.startswith(("CARGO_PROFILE_","CARGO_TARGET_","CARGO_UNSTABLE_","OHM_"))}
        env=dict(base_env,PATH=str(tool)+":"+base_env["PATH"],RUSTC=str(tool/"rustc"),RUSTDOC=str(tool/"rustdoc"),CARGO_HOME=str(stage/"cargo-home"),CARGO_TARGET_DIR=str(target),__CARGO_TESTS_ONLY_SRC_ROOT=str(lib),CARGO_PROFILE_RELEASE_LTO="thin",CARGO_PROFILE_RELEASE_CODEGEN_UNITS="1",CARGO_PROFILE_RELEASE_OPT_LEVEL="3",CARGO_PROFILE_RELEASE_DEBUG="false",CARGO_PROFILE_RELEASE_INCREMENTAL="false",CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS="false",CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS="false",CARGO_NET_OFFLINE="true",LIBZ_SYS_STATIC="1",CARGO_TERM_COLOR="never",CFG_RELEASE="1.99.0-dev",CFG_RELEASE_CHANNEL="dev",CFG_VER_DESCRIPTION=cfg["release"])
        cmd=prior["command"].copy();cmd[cmd.index("-j8")]="-j"+str(len(affinity))
        meta={"command":cmd,"env":{k:v for k,v in env.items() if base_env.get(k)!=v},"source_tree":tree(src),"source_sha256":digest(f),"std_source_sha256":digest(lib/"std/src/path.rs"),"affinity":affinity,"parent_binary":digest(base),"start_ns":time.time_ns()}
        (out/"command.json").write_text(json.dumps(meta,indent=2)+"\n")
        with (out/"cargo.log").open("wb") as log:
            p=subprocess.Popen(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            (out/"pgid").write_text(str(p.pid)+"\n")
            if p.wait():raise SystemExit("Cargo build failed; private stage preserved")
        std_inputs=set()
        for line in (out/"cargo.log").open():
            if "--crate-name cargo " in line:std_inputs.update(re.findall(r"(?<![a-zA-Z])std=([^\s\x27\x22]+?\.rlib)\b",line))
        assert std_inputs and {digest(Path(path)) for path in std_inputs}=={prior["std_rlib_sha256"]}
        built=target/"x86_64-unknown-linux-gnu/release/cargo"
        version=subprocess.check_output([built,"-Vv"],text=True);assert cfg["cargo_pin"] in version
        dst=Path(plan["candidate_path"]);dst.parent.mkdir(exist_ok=True);pending=dst.with_suffix(".pending")
        shutil.copy2(built,pending);pending.chmod(0o555);pending.rename(dst)
        meta.update(end_ns=time.time_ns(),parent_std_rlib_sha256=prior["std_rlib_sha256"],verified_linked_std=sorted(std_inputs),candidate_binary=digest(dst),cargo_version=version)
        (out/"ready.json").write_text(json.dumps(meta,indent=2)+"\n")
        print(digest(dst),flush=True)
    finally:
        for f in (src,lib,target):
            if f.exists():f.rename(park/f.name)

if __name__=="__main__":main()
