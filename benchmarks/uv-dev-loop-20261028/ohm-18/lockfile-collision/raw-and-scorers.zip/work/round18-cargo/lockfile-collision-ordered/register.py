"""Freeze a separate mechanism, source and fresh assignments without building or running Cargo."""
import hashlib,json,random,subprocess
from datetime import datetime,timezone
from difflib import unified_diff
from pathlib import Path
here=Path(__file__).resolve().parent
suite=here.parent;work=suite.parent
parent=json.loads((suite/"lockfile-collision/plan.json").read_text())
src=Path(json.loads((suite/"inputs.json").read_text())["source"])/"guard-stack/src/resolver/mod.rs"
old=src.read_text();needle="fn check_duplicate_pkgs_in_lockfile(resolve: &Resolve) -> CargoResult<()> {\n"
guard="""    // Strictly increasing name-version pairs cannot collide when encoded.
    if resolve
        .iter()
        .map(|id| (id.name(), id.version()))
        .is_sorted_by(|a, b| a < b)
    {
        return Ok(());
    }

"""
assert old.count(needle)==1 and not (here/"plan.json").exists()
new=old.replace(needle,needle+guard);patch="".join(unified_diff(old.splitlines(True),new.splitlines(True),"a/src/resolver/mod.rs","b/src/resolver/mod.rs"))
(here/"guard.patch").write_text(patch)
def h(s):return hashlib.sha256(s).hexdigest()
root=Path((work/"bench-home.path").read_text().strip())/"collision-ordered-18"
original=subprocess.check_output(["git","-C",str(work/"uv"),"show",parent["uv"]+":crates/uv/src/install_source.rs"])
bef=b"component == cellar && next == formula"
assert original.count(bef)==1
def edit(s,i):
    replacement=('{'+'\n                component == cellar && (next == formula || next == OsStr::new('+f'"uv-preview-{s}{i:02d}"))\n            }}').encode()
    return h(original.replace(bef,replacement))
cohorts={}
for label,seed in (("instructions-initial",90148231),("instructions-repeat",91724519),("wall-initial",93374207),("wall-repeat",95380391)):
    c=parent["cohorts"][label].copy();n=c["n"];order=[["base","candidate"],["candidate","base"]]*(n//2);random.Random(seed).shuffle(order)
    ids=list(range(10,10+n));random.Random(seed+1409).shuffle(ids);s="M" if label=="wall-initial" else "N";wall=label.startswith("wall")
    c.update(order_seed=seed,order=order,fixture=str(root/label),source_labels=[f"{s}{i:02d}" for i in ids] if wall else [],edit_sha256={f"{s}{i:02d}":edit(s,i) for i in (0,1,*ids)} if wall else {})
    cohorts[label]=c
plan=dict(parent,registered=datetime.now(timezone.utc).isoformat(),study="release-18 ordered lockfile collision precondition",source_to_sha256=h(new.encode()),patch_sha256=h(patch.encode()),protocol_sha256=h((here/"PROTOCOL.md").read_bytes()),reg_code_sha256=h(Path(__file__).read_bytes()),candidate_path=str(here/"bin/candidate"),cohorts=cohorts)
(here/"plan.json").write_text(json.dumps(plan,indent=2)+"\n");(here/"registered.sha256").write_text(h((here/"plan.json").read_bytes())+"  plan.json\n")
