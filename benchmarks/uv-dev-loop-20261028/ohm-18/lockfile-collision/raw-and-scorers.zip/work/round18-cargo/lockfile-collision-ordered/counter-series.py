"""Build the registered ordered guard and run its two instruction cohorts after host release."""
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parent
control = root / "control"
coordinator_pause = root.with_name("lockfile-collision") / "control/pause"


def invoke(script, *args):
    while coordinator_pause.exists():
        time.sleep(2)
    subprocess.run([sys.executable, "-B", str(root / script), *args], check=True)


def main():
    if sys.argv[1:] != ["--coordinator-released"] or sorted(os.sched_getaffinity(0)) != list(range(24, 28)):
        raise SystemExit("use the explicitly released four counter CPUs")
    control.mkdir(exist_ok=True)
    local = control / "pause"
    if not local.is_symlink():
        local.symlink_to(os.path.relpath(coordinator_pause, control))
    assert local.resolve() == coordinator_pause.resolve()
    if not (root / "build/ready.json").exists():
        invoke("build.py")
    if not (root / "measurement-seal.json").exists():
        invoke("measure.py", "seal")
    if not (root / "correctness/PASS.json").exists():
        invoke("measure.py", "correctness")
    for phase in ("instructions-initial", "instructions-repeat"):
        receipts = root / "results" / phase
        if (receipts / "rejected.json").exists():
            raise SystemExit(f"{phase} has a preserved rejection")
        if not (receipts / "warm.json").exists():
            invoke("measure.py", "warm", phase)
        if not (receipts / "summary.json").exists():
            invoke("measure.py", "sample", phase)
        invoke("verify.py")


if __name__ == "__main__":
    main()
