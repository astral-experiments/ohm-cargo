"""Archive the original inputs, exclusions and independently verified instruction cohorts."""
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

suite = Path(__file__).resolve().parent
work = suite.parent
project = work.parent


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("guard", choices=("hash", "ordered"))
    args = parser.parse_args()
    subject = suite / ("lockfile-collision" if args.guard == "hash" else "lockfile-collision-ordered")
    data = subject / "recovery" if args.guard == "hash" else subject
    verify = [sys.executable, "-B", str(subject / "verify.py")]
    if args.guard == "hash":
        verify.append("--recovery")
    subprocess.run(verify, check=True, stdout=subprocess.DEVNULL)
    status = json.loads((data / "verified.json").read_text())["cohorts"]
    assert all(status[label]["state"] == "verified" for label in ("instructions-initial", "instructions-repeat"))
    files = set()
    for path in subject.rglob("*"):
        if (path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts and
                path.name != "pause" and not any(name in ("wall-initial", "wall-repeat") for name in path.parts)):
            files.add(path)
    common = suite / "lockfile-collision"
    for directory in ("ohm-source-census", "excluded-counter-preflight"):
        for path in (common / directory).rglob("*"):
            if path.is_file() and not path.is_symlink():
                files.add(path)
    for name in ("common.py", "register.py", "build.py", "measure.py", "correctness.py", "probe.rs", "stats.py",
                 "verify.py", "ohm-census.py", "source-screen.json", "PROTOCOL.md", "COUNTER-AND-PILOT.md",
                 "RECOVERY.md", "measurement-seal.json", "counter-affinity.json", "render-source-census.py"):
        files.add(common / name)
    files.update((Path(__file__).resolve(), suite / "replay_resolver.py", suite / "RESOLVER-REPLAY.md",
                  suite / "resolver-counter-tools.json", work / "bench-home.path", suite / "inputs.json", suite / "packages.json",
                  suite / "recipe/prepare.py", suite / "fast/guard-stack/ready.json",
                  work / "upstream-monitor/rust/release-history.json"))
    for name in ("count.py", "README.md", "fixture.c", "calibrate.py", "calibration.csv"):
        files.add(work / "dynamorio" / name)
    target = suite / ("resolver-" + args.guard + "-counters.zip")
    pending = target.with_suffix(".pending")
    with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=5) as packet:
        for path in sorted(files):
            packet.write(path, path.relative_to(project))
    with zipfile.ZipFile(pending) as packet:
        assert len(packet.namelist()) == len(files) and packet.testzip() is None
        with tempfile.TemporaryDirectory() as temporary:
            for entry in packet.infolist():
                if entry.file_size < 2 * 1024 * 1024:
                    packet.extract(entry, temporary)
            extracted = Path(temporary) / subject.relative_to(project)
            receipt = Path(temporary) / data.relative_to(project) / "verified.json"
            previous = digest(receipt)
            detached = [sys.executable, "-I", "-B", str(extracted / "verify.py")]
            if args.guard == "hash":
                detached.append("--recovery")
            subprocess.run(detached, check=True, cwd=temporary, stdout=subprocess.DEVNULL)
            assert digest(receipt) == previous
    pending.replace(target)
    result = dict(path=str(target), sha256=digest(target), bytes=target.stat().st_size, entries=len(files),
                  scope="Both Cargo-process instruction cohorts, excluded preflights, binary, scripts, correctness, and Ohm census.")
    target.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
