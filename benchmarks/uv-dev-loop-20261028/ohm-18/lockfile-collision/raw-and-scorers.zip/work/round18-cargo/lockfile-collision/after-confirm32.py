"""Wait for written host clearance, then run the excluded admission and unobserved cohorts."""
import json,os,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent
release=here.parents[1]/"round18-lab/counter-window-after-confirm32.json"
pause=here/"control/pause"
while not release.is_file():time.sleep(3)
record=json.loads(release.read_text())
if pause.exists() and pause.stat().st_mtime_ns<=release.stat().st_mtime_ns:pause.unlink()
while pause.exists():time.sleep(3)
assert sorted(os.sched_getaffinity(0))==[24,25,26,27]
(here/"control/resolver-release-receipt.json").write_text(json.dumps(dict(utc_unix_ns=time.time_ns(),coordinator=record),indent=2)+"\n")
def run(*s):subprocess.run([sys.executable,"-B",*[str(x) for x in s]],check=True)
run(here/"diagnose-control.py","--coordinator-released")
run(here/"recover.py","prepare")
for cohort in ("instructions-initial","instructions-repeat"):
    run(here/"recover.py","warm",cohort)
    run(here/"recover.py","sample",cohort)
    run(here/"verify.py","--recovery")
