"""Freeze the release-18 collision-check source guard and independent screens."""
import hashlib
import json
from pathlib import Path
import random
import subprocess
from difflib import unified_diff

here=Path(__file__).resolve().parent
suite=here.parent
w=suite.parent
bench=Path((w/"bench-home.path").read_text().strip())
cfg=json.loads((suite/"inputs.json").read_text())
src=Path(cfg["source"])/"guard-stack"
rel="src/resolver/mod.rs"
before=(src/rel).read_text()
key="fn check_duplicate_pkgs_in_lockfile(resolve: &Resolve) -> CargoResult<()> {\n"
guard="""    // Equal lockfile IDs must have the same name and version, even when
    // the lockfile omits fields that distinguish no packages.
    let unique_name_versions = {
        let mut seen = HashSet::with_capacity_and_hasher(resolve.len(), FxBuildHasher::default());
        resolve.iter().all(|id| seen.insert((id.name(), id.version())))
    };
    if unique_name_versions {
        return Ok(());
    }

"""
assert before.count(key)==1 and not (here/"plan.json").exists()
after=before.replace(key,key+guard)
patch="".join(unified_diff(before.splitlines(True),after.splitlines(True),"a/"+rel,"b/"+rel))
(here/"guard.patch").write_text(patch)
def h(x):return hashlib.sha256(x).hexdigest()
def orders(n,seed):
    r=random.Random(seed)
    a=[["base","candidate"],["candidate","base"]]*(n//2)
    r.shuffle(a)
    return a
def edits(symbol,index):
    source=subprocess.check_output(["git","-C",str(w/"uv"),"show","c22e6b71933443e9cd299d4b6ac8de035ed4825b:crates/uv/src/install_source.rs"])
    key=b"component == cellar && next == formula"
    replacement=('{\n                component == cellar && (next == formula || next == OsStr::new('
                 f'"uv-preview-{symbol}{index:02d}"))\n            }}').encode()
    assert source.count(key)==1
    return h(source.replace(key,replacement))
cohorts={}
for label,n,seed,backend in [("instructions-initial",12,83514011,"DynamoRIO Cargo PID, all threads, no descendants"),
                             ("instructions-repeat",8,85174319,"Valgrind Cachegrind Cargo PID, all threads, no descendants"),
                             ("wall-initial",24,87351247,"native monotonic complete command"),
                             ("wall-repeat",24,89232791,"native monotonic complete command")]:
    literal_ids=list(range(10,10+n))
    random.Random(seed+901).shuffle(literal_ids)
    symbol="X" if label=="wall-initial" else "Y"
    wall=label.startswith("wall")
    cohorts[label]=dict(n=n,order_seed=seed,order=orders(n,seed),backend=backend,
        fixture=str(bench/"collision-proof-18"/label),source_labels=[f"{symbol}{i:02}" for i in literal_ids] if wall else [],
        edit_sha256={f"{symbol}{i:02}":edits(symbol,i) for i in (0,1,*literal_ids)} if wall else {},
        command=["check","--locked","--offline","-j8"])
base=suite/"fast/bin/guard-stack"
plan=dict(registered="2026-10-28T22:05Z",study="release-18 lockfile collision precondition",uv="c22e6b71933443e9cd299d4b6ac8de035ed4825b",
    release_cargo_commit="7caf39914da1e28a67744ecbc963a5f26361474d",parent_cargo_tree="9c6e123da812bbbf5cbed205166025c742bf0f72",
    configuration="existing verified fast release-O3, ThinLTO, single-CGU, ohm-defaults, all-static, compiled std #247 with five Cargo changes; PGO disabled in both arms",
    base={"path":str(base),"sha256":json.loads((suite/"drivers.json").read_text())["arms"]["fast"]["guard-stack"]["sha256"]},
    candidate_path=str(here/"bin/candidate"),candidate_hash="to be sealed before observation",
    patch_sha256=h(patch.encode()),source_from_sha256=h(before.encode()),source_to_sha256=h(after.encode()),
    rustc_sha256="c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60",
    protocol_sha256=h((here/"PROTOCOL.md").read_bytes()),reg_code_sha256=h(Path(__file__).read_bytes()),cohorts=cohorts)
(here/"plan.json").write_text(json.dumps(plan,indent=2)+"\n")
(here/"registered.sha256").write_text(h((here/"plan.json").read_bytes())+"  plan.json\n")
print(h(patch.encode()),h((here/"plan.json").read_bytes()))
