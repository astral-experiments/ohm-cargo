"""Repeat the unobserved screen under a separately sealed, validated benign environment."""
import argparse,datetime,hashlib,json,os,shutil,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import common as c,measure as m

R=HERE/"recovery"
ORIGINAL_ENV=c.env
def context(root,keys):
    permitted={"USER","LOGNAME","SHELL","LANG","TERM","PWD","PYTHONSAFEPATH","SSL_CERT_FILE","NO_COLOR","COLORTERM","PAGER","LC_CTYPE","HOMEBREW_CELLAR","HOMEBREW_PREFIX","HOMEBREW_REPOSITORY"}
    c.need(set(keys)<=permitted,"undeclared process context")
    values={k:os.environ[k] for k in keys if k!="PWD"}
    if "PWD" in keys:values["PWD"]=str(root/"source")
    return values

def prepare():
    c.need(not (HERE/"control/pause").exists(),"coordinator has not released the CPU set")
    decision=c.read(HERE/"excluded-counter-preflight/benign-context/disposition.json")
    chosen=decision["chosen"];c.need(chosen is not None,"no stable benign environment was demonstrated")
    attempts=c.read(HERE/"excluded-counter-preflight/benign-context/attempts.json")
    c.need(all(any(r["name"]==chosen["method"]+s and r["valid"] for r in attempts) for s in ("","-repeat1","-repeat2")),"require all three successful control-only probes")
    out=HERE/"results/instructions-initial"
    c.need((out/"rejected.json").is_file() and not (out/"samples.csv").exists() and not list(out.glob("settle-dynamorio-*-candidate.log")),"an instrumented treatment or paired sample exists")
    c.need(not (HERE/"results/instructions-repeat").exists() and not R.exists(),"existing replication or recovery")
    root=Path(c.PLAN["cohorts"]["instructions-initial"]["fixture"]);archive=root.parent/"preflight-excluded"/root.name
    c.need(root.is_dir() and not (root/"target").exists() and not archive.exists(),"original fixture is not parked")
    R.mkdir();archive.parent.mkdir(exist_ok=True);root.rename(archive)
    for src in ("correctness","control"):
        (R/src).symlink_to(Path("..")/src,target_is_directory=True)
    shutil.copy2(HERE/"source-screen.json",R/"source-screen.json")
    original=c.read(HERE/"measurement-seal.json");c.need(c.seal()==original,"original subjects changed")
    info={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Recovery after an unsuccessful pre-sample, pre-treatment control counter invocation. Preserve the failed suite and all excluded control-only diagnoses. Recreate both independent roots at their original absolute paths. Same programs, source, flags, CPU set, n, randomized assignments, counter and tests. The only measured-environment change is the separately calibrated explicit ordinary process context. No held-out or instrumented treatment values informed it.",
          "old_root":str(archive),"plan_sha256":c.sha(HERE/"plan.json"),"original_seal_sha256":c.sha(HERE/"measurement-seal.json"),"excluded_rejection_sha256":c.sha(out/"rejected.json"),"diagnostic_disposition_sha256":c.sha(HERE/"excluded-counter-preflight/benign-context/disposition.json"),"driver_sha256":c.sha(Path(__file__).resolve()),"keys":chosen["keys"],"host_values":context(root,chosen["keys"])}
    if "PWD" in info["host_values"]:info["host_values"]["PWD"]="<per command working directory>"
    c.save(R/"registration.json",info)
    c.save(R/"measurement-seal.json",{**original,"environment_registration_sha256":c.sha(R/"registration.json")})

def main():
    c.need(len(sys.argv)>=2,"use prepare, warm COHORT or sample COHORT after host release")
    if sys.argv[1]=="prepare":prepare();return
    c.need(sys.argv[1] in ("warm","sample") and len(sys.argv)==3 and sys.argv[2] in ("instructions-initial","instructions-repeat"),"recovery is restricted to the counter cohorts")
    c.need(not (HERE/"control/pause").exists(),"coordinator has not released the CPU set")
    info=c.read(R/"registration.json")
    c.need(info["driver_sha256"]==c.sha(Path(__file__).resolve()) and info["plan_sha256"]==c.sha(HERE/"plan.json"),"recovery driver or plan changed")
    def ordinary(root,*,online=False):
        extra=context(root,info["keys"])
        for k,v in extra.items():
            if k!="PWD":c.need(v==info["host_values"][k],"registered context value changed")
        return dict(ORIGINAL_ENV(root,online=online),**extra)
    original_seal=c.seal
    def sealed(wall=False):
        c.need(not wall,"this recovery has no native time observations")
        return {**original_seal(),"environment_registration_sha256":c.sha(R/"registration.json")}
    c.env=m.env=ordinary;m.seal=sealed;m.HERE=R
    m.main()
if __name__=="__main__":main()
