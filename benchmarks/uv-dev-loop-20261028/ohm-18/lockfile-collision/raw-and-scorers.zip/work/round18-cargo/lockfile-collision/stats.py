import bisect,itertools,math,statistics

def restricted_order(first_to_second,first_base):
    """Exact balanced-order test using the absolute sum of the assigned log ratios."""
    n=len(first_to_second);m=n//2
    total=sum(first_to_second)
    observed=abs(2*sum(x for x,b in zip(first_to_second,first_base) if b)-total)
    tolerance=1e-12
    if observed<=tolerance:return 1.0
    lower=(total-observed+tolerance)/2
    upper=(total+observed-tolerance)/2
    lhs,rhs=first_to_second[:m],first_to_second[m:]
    extreme=0
    for k in range(m+1):
        right=sorted(sum(x) for x in itertools.combinations(rhs,m-k))
        for x in itertools.combinations(lhs,k):
            s=sum(x)
            extreme+=bisect.bisect_right(right,lower-s)+len(right)-bisect.bisect_left(right,upper-s)
    return extreme/math.comb(n,m)

def summarize(rows,wall_initial):
    gains=sorted(1-x["candidate"]/x["base"] for x in rows)
    wins=sum(g>0 for g in gains);losses=sum(g<0 for g in gains);nz=wins+losses;n=len(gains)
    sign=min(1.,2*sum(math.comb(nz,j) for j in range(min(wins,losses)+1))/2**nz)
    k=max((j for j in range(1,n//2+1) if 2*sum(math.comb(n,a) for a in range(j))/2**n<=.05),default=0)
    interval=[gains[k-1],gains[-k]] if k else [None,None]
    d=[math.log(row[row["order"][0]]/row[row["order"][1]]) for row in rows]
    order=restricted_order(d,[row["order"][0]=="base" for row in rows])
    median=statistics.median(gains)
    return dict(n=n,wins=wins,losses=losses,ties=n-nz,arm_medians={a:statistics.median(r[a] for r in rows) for a in ("base","candidate")},median_fraction=median,median_interval_fraction=interval,median_interval_coverage=1-2*sum(math.comb(n,a) for a in range(k))/2**n,sign_p=sign,balanced_order_p=order,gate=median>0 and sign<.05 and order<.05 and (not wall_initial or interval[0]>0))
