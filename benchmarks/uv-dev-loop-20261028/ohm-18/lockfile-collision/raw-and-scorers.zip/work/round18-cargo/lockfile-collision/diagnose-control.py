"""After host release, identify a benign process-context fix using only excluded baseline calls."""
import json,os,re,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *

def main():
    need(sys.argv[1:]==["--coordinator-released"] and not (HERE/"control/pause").exists(),"counter window is closed")
    need(sorted(os.sched_getaffinity(0))==read(HERE/"counter-affinity.json")["counter_cpus"],"wrong probe CPUs")
    out=HERE/"excluded-counter-preflight/benign-context";out.mkdir()
    root=Path(PLAN["cohorts"]["instructions-initial"]["fixture"]);t=root/"target";prev=root/"diagnostic-predecessor"
    need(prev.is_dir() and not t.exists(),"only the excluded diagnostic target may be opened")
    slots=[
        ("user",("USER","LOGNAME")),("shell",("SHELL",)),("terminal",("TERM","LANG")),
        ("pwd",("PWD",)),("ordinary",("USER","LOGNAME","SHELL","TERM","LANG","PWD")),
        ("ordinary-python",("USER","LOGNAME","SHELL","TERM","LANG","PWD","PYTHONSAFEPATH")),
        ("tls",("SSL_CERT_FILE",)),("display",("NO_COLOR","COLORTERM","PAGER","LC_CTYPE")),
        ("ordinary-platform",("USER","LOGNAME","SHELL","TERM","LANG","PWD","PYTHONSAFEPATH","SSL_CERT_FILE","NO_COLOR","COLORTERM","PAGER","LC_CTYPE","HOMEBREW_CELLAR","HOMEBREW_PREFIX","HOMEBREW_REPOSITORY")),
    ]
    records=[];chosen=None
    def attempt(name,context):
        if (HERE/"control/pause").exists():raise SystemExit("paused before next control-only probe")
        slot=select(root,"base");cmd=[sys.executable,"-B",str(COUNTER),"--",str(slot),*PLAN["cohorts"]["instructions-initial"]["command"]]
        actual=dict(env(root),**context);start=time.monotonic()
        proc=subprocess.run(cmd,cwd=root/"source",env=actual,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        body=proc.stdout.decode(errors="replace");(out/(name+".log")).write_bytes(proc.stdout)
        valid=proc.returncode==0 and bool(re.search(r"^\s*Finished ",body,re.M)) and not re.search(r"^\s*(Checking|Compiling|Blocking|Running) ",body,re.M)
        if valid:
            dr=json.loads(re.findall(r"^DynamoRIO (.+)$",body,re.M)[-1]);valid=dr["instructions"]>0 and str(dr["pid"]) in dr["threads"] and sum(dr["threads"].values())==dr["instructions"]
        r=dict(name=name,keys=sorted(context),returncode=proc.returncode,log_bytes=len(proc.stdout),valid=bool(valid),duration_budget_s=time.monotonic()-start)
        records.append(r);save(out/"attempts.json",records);print(r,flush=True)
        return valid
    prev.rename(t)
    try:
        for name,keys in slots:
            ctx={k:os.environ[k] for k in keys if k in os.environ}
            if "PWD" in ctx:ctx["PWD"]=str(root/"source")
            if attempt(name,ctx) and all(attempt(name+"-repeat"+str(i),ctx) for i in (1,2)):
                chosen={"method":name,"keys":sorted(ctx),"derive_pwd_from_command_working_directory":"PWD" in ctx};break
    finally:t.rename(prev)
    save(out/"disposition.json",dict(chosen=chosen,scope="Excluded control-only work. No instrumented candidate or held-out sample was invoked."))
    if not chosen:raise SystemExit("no stable benign context; retain failed initial cohort and stop or separately register another design")
if __name__=="__main__":main()
