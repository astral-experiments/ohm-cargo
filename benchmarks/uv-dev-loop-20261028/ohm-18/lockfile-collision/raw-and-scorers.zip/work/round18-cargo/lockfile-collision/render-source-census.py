"""Require equivalence of the previous collision check and callers before emitting the Ohm audit."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
out = here / "ohm-source-census"


def load(name):
    return json.loads((out / name).read_text())


inventory = load("inventory.json")
refs = load("refs.json")
findings = load("source-findings.json")
release = inventory["releases"]["ohm-1.99.0-18"]
source_path, oid = next(iter(refs[release]["resolver_sources"].items()))
reference = findings[oid]
caller = reference["callers"][0]["context"]
assert "    check_cycles(&resolve)?;" in caller and "    check_duplicate_pkgs_in_lockfile(&resolve)?;" in caller
assert "    let state = encode::EncodeState::new(resolve);" in reference["source"]
assert "        let encodable_pkd_id = encode::encodable_package_id(pkg_id, &state, resolve.version());" in reference["source"]
counts = collections.Counter()
unavailable = []
for sha, ref in refs.items():
    if not ref["resolver_sources"]:
        assert ref["source_absent"] and ref["root_names"] == ["benchmarks"] and "releases" not in ref
        unavailable.append(sha)
        continue
    assert len(ref["resolver_sources"]) == 1
    for name, oid in ref["resolver_sources"].items():
        counts[name] += 1
        assert oid in findings
for oid, record in findings.items():
    source = gzip.decompress((out / "blobs" / (oid + ".rs.gz")).read_bytes())
    assert hashlib.sha1(b"blob " + str(len(source)).encode() + b"\0" + source).hexdigest() == oid
    assert source.decode().count(record["source"]) == 1
    assert record["source"].replace("HashMap::new()", "HashMap::default()") == reference["source"]
    assert len(record["callers"]) == 1 and record["callers"][0]["context"] == caller

branches = {r["name"]: r["sha"] for r in inventory["branches"]}
prs = {r["number"]: r for r in inventory["prs"]}
examined = [
    ("release 1.99.0-18", release),
    ("Cargo default branch", branches[inventory["default_branch"]]),
    ("Cargo 1.99 integration", branches["ohm-1.99.0"]),
]
receipt = dict(as_of=inventory["as_of"], release_pins=len(inventory["releases"]), branch_heads=len(branches),
               pr_heads=len(prs), open_prs=sum(r["state"] == "open" for r in prs.values()), commits=len(refs),
               resolver_commits=sum(counts.values()), benchmark_only_commits=len(unavailable),
               lookup_paths=counts, resolver_file_versions=len(findings),
               distinct_function_bodies=len({record["normalized_body"] for record in findings.values()}),
               program_differences=["HashMap::new() versus HashMap::default()"], caller_contexts=1)
(out / "verified.json").write_text(json.dumps(receipt, indent=2) + "\n")
lines = [
    "# Ohm resolver duplication check", "",
    f"The {inventory['as_of']} census covered {receipt['release_pins']} published Ohm releases, {len(branches)} Cargo branch heads and all {len(prs)} Cargo pull request heads, including {receipt['open_prs']} open PRs. The {len(refs)} unique commits included {sum(counts.values())} with Cargo source and {len(unavailable)} containing only benchmark data.",
    "",
    f"Across both resolver module layouts the {len(findings)} distinct file versions call the collision check immediately after cycle checking and build the full lockfile encoder state. They encode every resolved package and insert it in a map. The two observed function bodies differ only in the map constructor. Both proposed name/version shortcuts are absent.",
    "",
]
for label, sha in examined:
    name, blob = next(iter(refs[sha]["resolver_sources"].items()))
    line = findings[blob]["start_line"]
    lines.append(f"- {label} uses the full check. [Pinned source](https://github.com/astral-sh/ohm-cargo/blob/{sha}/{name}#L{line})")
lines.extend(["", "The nearest posted changes affect collection choice, field formatting or decoding.",
              ""])
for number in (11, 246, 266, 271):
    pr = prs[number]
    lines.append(f"- [#{number} {pr['title']}]({pr['html_url']})")
if (out / "nearby-275-files.json").is_file():
    neighbor = load("nearby-275.json")
    changed = {entry["filename"]: entry["patch"] for entry in load("nearby-275-files.json")}
    assert prs[275]["sha"] == neighbor["head_sha"] and neighbor["base_sha"] == release
    assert set(changed) == {"src/ops/resolve.rs", "tests/testsuite/workspaces.rs"}
    assert "fn workspace_specs_allow_cached_resolve(" in changed["src/ops/resolve.rs"]
    assert refs[neighbor["head_sha"]]["resolver_sources"] == refs[release]["resolver_sources"]
    lines += ["", "PR #275 indexes workspace members by name when testing whether selected package specifications can use the existing resolve cache. Its other file tests that eligibility logic. The lockfile collision helper and caller have the exact release blob at the PR head. [PR #275](https://github.com/astral-sh/ohm-cargo/pull/275/files)"]
lines += ["", "The API inventory, commit-to-blob mapping, complete Git-identified module texts and extracted caller/body evidence are saved alongside this report.", ""]
(out / "REPORT.md").write_text("\n".join(lines))
