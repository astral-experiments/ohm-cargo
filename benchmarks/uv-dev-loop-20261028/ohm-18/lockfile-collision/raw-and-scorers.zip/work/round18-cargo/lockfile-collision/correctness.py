import os,re,shlex,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *

def package(root,name,version,extras=""):
    (root/"src").mkdir(parents=True,exist_ok=True)
    (root/"src/lib.rs").write_text("pub fn fixture() {}\n")
    (root/"Cargo.toml").write_text(f'[package]\nname="{name}"\nversion="{version}"\nedition="2015"\n'+extras+"\n")

def block(source,start):
    i=source.index(start);j=source.index("\n}\n",i)+3
    return source[i:j]

def probe(out):
    config=read(SUITE/"inputs.json");stage=Path(config["scratch"])/"fast"
    old=stage/"guard-stack/cargo-src/src/resolver";park=stage/"guard-stack-plus-lockfile-collision"
    new=park/"cargo-src/src/resolver"
    encoded=(old/"encode.rs").read_text()
    need((new/"encode.rs").read_bytes()==(old/"encode.rs").read_bytes(),"encoder changed")
    source=(HERE/"probe.rs").read_text()+"\nmod encode { use super::*;\n"
    for start in ("pub struct EncodeState","impl<'a> EncodeState","pub fn encodable_package_id(","fn encodable_source_id("):
        source+=block(encoded,start)
    source+="}\n"
    for name,d in (("control",old),("guarded",new)):
        fragment=block((d/"mod.rs").read_text(),"fn check_duplicate_pkgs_in_lockfile(")
        source+="mod "+name+" { use super::*;\npub(super) "+fragment+"}\n"
    generated=out/"collision_compare.rs";generated.write_text(source)
    rustc=str(Path(config["toolchain"])/"bin/rustc")
    marker=rustc+" --crate-name cargo "
    lines=[ln for ln in (HERE/"build/cargo.log").read_text().splitlines() if marker in ln and "--crate-type bin" in ln]
    need(len(lines)==1,"cannot identify the candidate's rustc link command")
    args=shlex.split(lines[0][lines[0].index(marker):].removesuffix("`"))
    args=[s.replace(str(stage/"target"),str(park/"target")) for s in args]
    args[args.index("--crate-name")+1]="collision_compare"
    original_rs=next(i for i,s in enumerate(args) if s.endswith(".rs"));args[original_rs]=str(generated)
    args[args.index("--out-dir")+1]=str(out)
    args=["--emit=link" if s.startswith("--emit=") else s for s in args]
    save(out/"probe-command.json",args)
    with (out/"compile.log").open("wb") as f:
        subprocess.run(args,cwd=park/"cargo-src",env=env(out),stdout=f,stderr=subprocess.STDOUT,check=True)
    exe=next(p for p in out.glob("collision_compare*") if p.is_file() and os.access(p,os.X_OK))
    with (out/"probe.log").open("wb") as f:subprocess.run([str(exe)],env=env(out),stdout=f,stderr=subprocess.STDOUT,check=True)
    lines=(out/"probe.log").read_text().splitlines()
    need(len(lines)==40 and all(sum(s.startswith(f"V{i} ") for s in lines)==8 for i in range(1,6)),"incomplete direct resolver tests")

def execute():
    out=HERE/"correctness";out.mkdir()
    root=BENCH/"collision-proof-18/correctness";root.mkdir(mode=0o700,parents=True)
    (root/"cargo-home").mkdir(mode=0o700)
    (root/"bin").mkdir()
    for arm,path in (("base",BASE),("candidate",CANDIDATE)):shutil.copy2(path,root/"bin"/arm)
    project=root/"fixture";project.mkdir()
    evidence=[]
    for version,msrv in enumerate(("1.38","1.41","1.53","1.83"),1):
        for collision in (False,True):
            left=project/"left";right=project/"right";main=project/"subject"
            package(left,"same","1.0.0");package(right,"same","1.0.0" if collision else "2.1.0")
            package(main,"subject","0.1.0",f'rust-version="{msrv}"\n[workspace]\n[dependencies]\nleft={{package="same",path="../left"}}\nright={{package="same",path="../right"}}')
            observations=[]
            for arm in ("base","candidate"):
                lock=main/"Cargo.lock";lock.unlink(missing_ok=True)
                stem=out/f"v{version}-path-{'duplicate' if collision else 'distinct'}-{arm}"
                cmd=[str(select(root,arm)),"generate-lockfile","--offline","--manifest-path",str(main/"Cargo.toml")]
                p=subprocess.run(cmd,cwd=main,env=env(root),capture_output=True)
                stem.with_suffix(".log").write_bytes(p.stdout+p.stderr)
                if collision:
                    need(p.returncode==101 and b"package collision in the lockfile" in p.stderr,"path diagnostic missing")
                else:
                    need(p.returncode==0 and lock.exists(),"valid path fixture failed")
                    shutil.copy2(lock,stem.with_suffix(".lock"))
                observations.append(dict(status=p.returncode,lock=sha(lock) if lock.is_file() else None,error=p.stderr.decode() if collision else None))
            need(observations[0]==observations[1],"path fixture outputs or diagnostics differ")
            evidence.append(dict(resolve_version=version,fixture="two path packages",duplicate=collision,receipt=observations[0]))
    remotes=[]
    for name in ("git-one","git-two"):
        repo=project/name
        need(repo.resolve().parent==project.resolve() and not repo.exists(),"unexpected synthetic repo")
        package(repo,"same","1.0.0")
        subprocess.run(["git","-C",str(repo),"init","-q","--template=","-b","master"],check=True,env=env(root))
        git=["git","-C",str(repo),"-c","core.hooksPath=/dev/null","-c","user.name=Fixture","-c","user.email=fixture@example.invalid"]
        origin=subprocess.check_output([*git,"rev-parse","--show-toplevel","--path-format=absolute","--git-common-dir"],text=True,env=env(root)).splitlines()
        need(origin==[str(repo.resolve()),str(repo.resolve()/".git")],"incorrect synthetic checkout")
        subprocess.run([*git,"add","Cargo.toml","src/lib.rs"],check=True,env=env(root))
        git_env=dict(env(root),GIT_AUTHOR_DATE="2001-02-03T04:05:06Z",GIT_COMMITTER_DATE="2001-02-03T04:05:06Z")
        subprocess.run([*git,"commit","-qm","synthetic package"],check=True,env=git_env)
        remotes.append(repo.as_uri())
    package(main,"subject","0.1.0",f'rust-version="1.83"\n[workspace]\n[dependencies]\nleft={{package="same",git="{remotes[0]}"}}\nright={{package="same",git="{remotes[1]}"}}')
    cmd=["generate-lockfile","--manifest-path",str(main/"Cargo.toml")]
    need(all(uri.startswith(project.as_uri()+"/") for uri in remotes),"expected two private file remotes")
    cached=subprocess.run([str(select(root,"base")),*cmd],cwd=main,env=env(root,online=True),capture_output=True)
    (out/"prepare-file-git.log").write_bytes(cached.stdout+cached.stderr)
    need(cached.returncode==0,"could not prepare the two private file:// repositories")
    git_outputs=[]
    for arm in ("base","candidate"):
        (main/"Cargo.lock").unlink()
        got=subprocess.run([str(select(root,arm)),*cmd,"--offline"],cwd=main,env=env(root),capture_output=True)
        (out/f"two-file-git-{arm}.log").write_bytes(got.stdout+got.stderr)
        need(got.returncode==0,"actual Git fixture failed")
        shutil.copy2(main/"Cargo.lock",out/f"two-file-git-{arm}.lock")
        git_outputs.append(sha(main/"Cargo.lock"))
    need(git_outputs[0]==git_outputs[1],"different lockfile bytes for the two Git sources")
    evidence.append(dict(resolve_version=4,fixture="two same-version Git packages at separate local URLs",receipt={"lock":git_outputs[0]}))
    # This directly runs the exact two private function bodies and three private encoder items
    # against real Cargo Resolve/PackageId/SourceId values, including V5, which the CLI does not select.
    probe(out)
    save(out/"PASS.json",dict(path_fixtures=evidence,exact_resolver_cases=40,git_and_v5="see generated collision_compare.rs and probe.log",probe_sha256=sha(out/"collision_compare.rs")))

if __name__=="__main__":execute()
