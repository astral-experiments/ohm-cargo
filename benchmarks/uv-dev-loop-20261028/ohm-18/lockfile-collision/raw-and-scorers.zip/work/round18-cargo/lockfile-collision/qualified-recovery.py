"""Use an independently verified recovered counter pair to admit the original native plan or read the Ohm source census."""
import importlib.util
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
import common
import measure

recovery = here / "recovery"
phases = ("instructions-initial", "instructions-repeat")


def main():
    verified = common.read(recovery / "verified.json")
    for phase in phases:
        summary = common.read(recovery / "results" / phase / "summary.json")
        common.need(summary["gate"] and verified["cohorts"][phase]["gate"], "both independently verified counter gates must pass")
    if sys.argv[1:] == ["census"]:
        spec = importlib.util.spec_from_file_location("ohm_source_census", here / "ohm-census.py")
        census = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(census)
        census.HERE = recovery
        census.main()
        return
    common.need(len(sys.argv) == 4 and sys.argv[1] in ("warm", "sample")
                and sys.argv[2] in ("wall-initial", "wall-repeat") and sys.argv[3] == "--coordinator-released",
                "native work requires an explicit, separate coordinator release")
    common.need(not (here / "control/pause").exists(), "coordinator pause is still active")
    registration = recovery / "registration.json"
    info = common.read(registration)
    common.need(info["driver_sha256"] == common.sha(here / "recover.py") and info["plan_sha256"] == common.sha(here / "plan.json"),
                "counter process-context registration changed")

    def native_seal(wall=False):
        common.need(wall, "native cohort required")
        return {**common.seal(wall=True), "environment_registration_sha256": common.sha(registration)}

    measure.HERE = recovery
    measure.seal = native_seal
    # Both the original env() and the native run(), stats, plan and assignments remain intact.
    context_file = recovery / "native-original-context.json"
    context = dict(wrapper_sha256=common.sha(Path(__file__).resolve()), source_plan_sha256=common.sha(here / "plan.json"),
                   counter_registration_sha256=common.sha(registration), native_env="original sealed common.env()",
                   native_env_sha256=common.sha(here / "common.py"), forwarding_counter_context=False)
    if not context_file.exists():
        common.need(sys.argv[1] == "warm", "prepare the native fixture first")
        common.save(context_file, context)
    common.need(common.read(context_file) == context, "native wrapper or input changed")
    measure.main()


if __name__ == "__main__":
    main()
