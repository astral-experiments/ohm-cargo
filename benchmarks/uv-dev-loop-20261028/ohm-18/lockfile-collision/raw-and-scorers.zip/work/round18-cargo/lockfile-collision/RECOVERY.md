# Reproducing the resolver measurements

The measured base is the release-18 fast stack with the five Cargo changes and the guarded standard-library path comparison linked into Cargo. The candidate adds the single hunk in `guard.patch`. Both use the distributed release-18 compiler to check uv. The original plan, both schedules, build flags, binary hashes and first attempted cohort remain in this directory.

The first excluded DynamoRIO control warmup exited before producing output. On a disposable target the same control exited 255 twice with the original environment. The normal parent environment succeeded in a separate diagnostic. Three further controls succeeded with one additional variable, `SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt`. The other earlier proposed contexts failed. The original failure and every accepted or rejected probe are under `excluded-counter-preflight/`. Its `benign-context/tls-input.json` identifies the local CA bundle. The commands all ran offline.

The confirmation uses fresh private source, registry and target directories at the originally specified paths, with that one additional variable in both arms and both counter setups. The separate registration is `recovery/registration.json`. It was written after the three control admissions and before the first instrumented candidate or held-out observation. The old target was parked separately. DynamoRIO measures Cargo and its application threads in the initial cohort. Cachegrind independently counts Cargo in the repeat. Neither counter follows child processes. Inspect the complete fresh-workspace admission and each no-rebuild roster alongside the raw logs.

The measurement host used the directories listed in `plan.json`, the release-18 files described in `../inputs.json`, the pinned uv Git checkout at `../../uv`, and the absolute private benchmark directory named by `../../bench-home.path`. The release-18 driver evidence contains the build prerequisites and exact matched base source. For a fresh rerun, use an empty private benchmark root, record new absolute paths and hashes in a new registration, choose four available CPUs for both counter setups, and set `SSL_CERT_FILE` to the ordinary readable system CA bundle. Preserve the distributed compiler, both ELF identities, uv pin, command flags, counter versions, schedules and excluded presample steps. Old targets carry absolute source and registry paths.

After reconstructing the recorded driver and private inputs, the counter sequence on the measurement host was equivalent to the following commands from the workspace root. Each command requires the same CPU affinity. The first two commands operate on the original excluded preflight fixture.

```sh
d=work/round18-cargo/lockfile-collision
taskset -c 24-27 /usr/bin/python3 -B "$d/diagnose-control.py" --coordinator-released
taskset -c 24-27 /usr/bin/python3 -B "$d/recover.py" prepare
for c in instructions-initial instructions-repeat
do
    taskset -c 24-27 /usr/bin/python3 -B "$d/recover.py" warm "$c" &&
    taskset -c 24-27 /usr/bin/python3 -B "$d/recover.py" sample "$c" &&
    /usr/bin/python3 -B "$d/verify.py" --recovery || exit 1
done
```

The archived observations can be checked independently with `python3 -B work/round18-cargo/lockfile-collision/verify.py --recovery`. It recomputes the statistics, paired assignments, role identities and totals from the underlying logs and checks the source and output hashes. If both counter gates pass, `qualified-recovery.py census` performs the source comparison against Ohm and the same wrapper accepts the original native phases. Native timing requires a separately released quiet slot with eight fixed CPUs. It uses the original clean native environment.
