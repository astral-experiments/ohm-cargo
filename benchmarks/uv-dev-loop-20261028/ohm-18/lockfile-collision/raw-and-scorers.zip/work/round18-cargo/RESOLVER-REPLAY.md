# Rerun the release-18 resolver guard

Use a fresh directory on x86-64 Linux. The original measurement host ran Ubuntu 24.04. The raw verifier needs only Python 3.11 or later and the corresponding resolver counter archive. For the hash-set guard, extract the archive and run the following command.

```sh
python3 -B work/round18-cargo/lockfile-collision/verify.py --recovery
```

The ordered variant uses `work/round18-cargo/lockfile-collision-ordered/verify.py` without arguments. Each verifier re-reads the complete paired raw logs.

For fresh measurements, unpack the resolver archive in the working directory and `driver-binaries.zip` into its `work/` directory. The resulting base executable should be `work/round18-cargo/fast/bin/guard-stack`. Set up the following inputs.

- Install the official x86-64 release at `work/upstream-monitor/toolchain18`. The original distribution archive SHA-256 was `629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8`. [Ohm 1.99.0-18](https://github.com/astral-sh/ohm/releases/tag/ohm-1.99.0-18)
- Extract the Linux x86-64 DynamoRIO archive into `work/dynamorio/`. The resulting installation is `work/dynamorio/DynamoRIO-Linux-11.3.0-1`. [DynamoRIO 11.3.0](https://github.com/DynamoRIO/dynamorio/releases/tag/release_11.3.0)
- Extract the Ubuntu Noble `valgrind` amd64 package version `1:3.22.0-0ubuntu3` using `dpkg-deb -x valgrind_3.22.0-0ubuntu3_amd64.deb work/profiler`. Use the native glibc debug symbols appropriate for the measurement host if Valgrind requests them. [Ubuntu package publication](https://launchpad.net/ubuntu/+source/valgrind/1%3A3.22.0-0ubuntu3)
- Place a checkout of uv at `work/uv` and check out the registered revision `c22e6b71933443e9cd299d4b6ac8de035ed4825b` in this private copy. The replay takes a new Git archive from that commit for each cohort. [Pinned uv source](https://github.com/astral-sh/uv/tree/c22e6b71933443e9cd299d4b6ac8de035ed4825b)

Populate a private dependency cache for the pinned workspace. Run these commands from the workspace root, with no existing study active at the `bench-home.path` location being configured.

```sh
uvbench_root=$(mktemp -d)
printf '%s\n' "$uvbench_root" > work/bench-home.path
mkdir -m 700 "$uvbench_root/cargo"
toolchain="$PWD/work/upstream-monitor/toolchain18/bin"
CARGO_HOME="$uvbench_root/cargo" RUSTC="$toolchain/rustc" \
    "$toolchain/cargo" fetch --locked --manifest-path work/uv/Cargo.toml
```

Pick four available CPUs on the host. `prepare` verifies the two Cargo binaries, rustc, counter binaries, original harness hashes and fixed randomized assignments, then records a fresh output path, CPU set and local system CA bundle. `run` creates independent source, registry and target copies there. Each cohort runs offline, with native admissions followed by the two counter setups. Choose a new output path when preparing a replay. The archived exclusion remains intact.

```sh
cpus=0-3
result="$uvbench_root/hash-replay"
taskset -c "$cpus" python3 -B work/round18-cargo/replay_resolver.py hash prepare --output "$result"
taskset -c "$cpus" python3 -B work/round18-cargo/replay_resolver.py hash run --output "$result"
```

Use `ordered` in both commands and a separate output path to repeat the allocation-free guard. A host that uses another system CA bundle can provide its path with `--ca-bundle` in both commands. The per-pair receipts, Cargo rosters, full raw counter logs, summary statistics and prospective registration go into the selected result directory.
