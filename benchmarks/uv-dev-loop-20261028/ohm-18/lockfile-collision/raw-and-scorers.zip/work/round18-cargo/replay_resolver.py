"""Replay the two registered resolver instruction cohorts in a fresh checkout and temporary root."""
import argparse
import copy
import datetime
import json
import os
import shutil
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("guard", choices=("hash", "ordered"))
    parser.add_argument("phase", choices=("prepare", "run"))
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ca-bundle", type=Path, default=Path("/etc/ssl/certs/ca-certificates.crt"))
    args = parser.parse_args()
    suite = Path(__file__).resolve().parent
    subject = suite / ("lockfile-collision" if args.guard == "hash" else "lockfile-collision-ordered")
    sys.path.insert(0, str(subject))
    import common as c
    import measure as m

    out = args.output.resolve()
    cpus = sorted(os.sched_getaffinity(0))
    c.need(len(cpus) == 4, "select four available CPUs using taskset")
    c.need(not out.is_relative_to(subject), "choose a new evidence and fixture directory")
    base = suite / "fast/bin/guard-stack"
    candidate = subject / "bin/candidate"
    saved = c.read(subject / "measurement-seal.json")
    c.need(c.sha(subject / "plan.json") == saved["plan_sha256"] == (subject / "registered.sha256").read_text().split()[0],
           "original plan or schedules changed")
    c.need(c.sha(subject / "guard.patch") == c.PLAN["patch_sha256"], "registered source hunk changed")
    for name, expected in saved["harness"].items():
        c.need(c.sha(subject / name) == expected, "archived harness changed: " + name)
    programs = dict(base=c.sha(base), candidate=c.sha(candidate), rustc=c.sha(c.RELEASE / "bin/rustc"),
                    dynamorio_counter=c.sha(c.COUNTER), cachegrind=c.sha(c.VALGRIND))
    c.need(programs == dict(**saved["cargo"], rustc=saved["rustc"], dynamorio_counter=saved["counter"],
                            cachegrind=saved["cachegrind_launcher"]), "archived binaries or counter versions differ")
    for name, expected in saved["dynamorio"].items():
        c.need(c.sha(c.WORK / "dynamorio/DynamoRIO-Linux-11.3.0-1" / name) == expected, "DynamoRIO changed: " + name)
    for name, expected in c.read(suite / "resolver-counter-tools.json")["cachegrind_amd64"].items():
        c.need(c.sha(c.WORK / "profiler/usr/libexec/valgrind" / name) == expected, "Cachegrind changed: " + name)
    registry = c.BENCH / "cargo/registry"
    c.need(registry.is_dir() and not registry.is_symlink(), "populate the private benchmark root with a copy of the locked uv registry")
    ca = args.ca_bundle.resolve(strict=True)
    cfg = copy.deepcopy(c.PLAN)
    for label in ("instructions-initial", "instructions-repeat"):
        cfg["cohorts"][label]["fixture"] = str(out / "fixtures" / label)
    reg = dict(original_plan_sha256=c.sha(subject / "plan.json"), script_sha256=c.sha(Path(__file__).resolve()),
               cargo_and_counter=programs, cpus=cpus, uv=cfg["uv"], registry=str(registry), ca_bundle=str(ca),
               ca_sha256=c.sha(ca), cohorts={k:v for k,v in cfg["cohorts"].items() if k.startswith("instructions-")})
    receipt = out / "replay-registration.json"
    if args.phase == "prepare":
        out.mkdir(mode=0o700, parents=True, exist_ok=False)
        c.save(receipt, dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), configuration=reg))
        shutil.copy2(subject / "source-screen.json", out / "source-screen.json")
        print(receipt)
        return
    c.need(c.read(receipt)["configuration"] == reg, "prepared replay inputs changed")
    c.need(not (out / "results").exists() and not (out / "fixtures").exists(), "preserve the previous replay and prepare a new output directory")
    c.BASE, c.CANDIDATE = base, candidate
    c.PLAN = m.PLAN = cfg
    m.HERE = out
    archived_env = c.env
    def ordinary(root, *, online=False):
        return {**archived_env(root, online=online), "SSL_CERT_FILE": str(ca)}
    c.env = m.env = ordinary
    identity = dict(cpus=cpus, cargo=saved["cargo"], replay_registration_sha256=c.sha(receipt))
    for label in ("instructions-initial", "instructions-repeat"):
        try:
            m.warm(label, identity)
            m.sample(label, identity, False)
        except BaseException as exc:
            c.save(out / ("rejected-" + label + ".json"), dict(reason=str(exc),type=type(exc).__name__))
            raise
    print(json.dumps({label:c.read(out / "results" / label / "summary.json") for label in reg["cohorts"]}, indent=2))


if __name__ == "__main__":
    main()
