# Rerun the 32-core Ohm -18 linker comparison

The two independently prepared checkouts each run 36 blocks of three ordinary `cargo test --no-run` builds. Every block makes a real edit to uv. The first checkout changes a private predicate and the second changes the Homebrew help text. Cargo uses its default parallelism on 32 physical cores. The three arms use the distributed Ohm -18 Cargo and rustc, with either the distributed Wild linker, the previous Wild draft #46, or #46 plus the late jobserver retry. All 72 test executables must be present. The timed commands only build them.

Use x86-64 Linux with a host-wide `/proc`, systemd as PID 1, 32 available physical cores, Python 3.11 or newer, strace, Git, tar, taskset and GNU coreutils. Run as a regular user. This experiment used about 17 GB per full target. Allow at least 160 GB free for the eight targets, copied registries and toolchain. Use a fresh directory on one filesystem for the private targets and binary slots. [Ohm -18 release](https://github.com/astral-sh/ohm/releases/tag/ohm-1.99.0-18) · [Pinned uv](https://github.com/astral-sh/uv/tree/c22e6b71933443e9cd299d4b6ac8de035ed4825b)

Set `OHM18` to the installed, unmodified Linux x86-64 toolchain directory containing `bin/cargo`. Set `UV_REPO` to a clone containing the pinned uv commit. Set `REPLAY` to a directory that does not yet exist. Choose the CPU IDs for one hardware thread on each of 32 physical cores. The warmup may download registry dependencies. Supply `--seed-cargo-home /path/to/cargo-home` to copy an existing populated registry instead.

```sh
sha256sum -c SHA256SUMS
python3 replay-confirm32.py prepare --toolchain "$OHM18" --uv-repository "$UV_REPO" \
  --work-dir "$REPLAY" --cpus 0-31
python3 replay-confirm32.py time --work-dir "$REPLAY"
```

Run the timing step on an otherwise idle host. The wrapper verifies component hashes and archives the pinned uv tree twice. Each linker has its own initially identical build output parked at the same absolute target path during execution. The original benchmark harness verifies the rebuilt crate, role counts, artifact contents and 72 test paths, then waits for two quiet five-second intervals. All 216 scored observations enter the analysis. The archive contains the frozen assignment, admission and post-run receipts, raw Cargo logs and the two tests of the paired change. [Immutable assignment](https://github.com/astral-sh/ohm-cargo/tree/21683ea1b3332d0f16f58b04c16cd539ac50323f/benchmarks/uv-dev-loop-20261028/ohm-18)

Results from a new run are in `$REPLAY/round18-lab/result.json`. The file reports seconds, paired savings, distribution-free median intervals and exact two-sided sign and order-conditioned p-values against each control. A positive lower median bound and both p-values below .0125 are required in all four comparisons. The historical report is in `results/qualification.json`.

The wrapper copies the frozen plan and relocates only fixture paths and CPU IDs for execution. Its scorer uses the original immutable plan to verify the complete block assignments. You can repeat the scoring step with `python3 replay-confirm32.py score --work-dir "$REPLAY"`.

To recompute the bundled historical result on any machine with Python 3.11 or newer, run `python3 replay-confirm32.py audit`. This uses the recorded raw rows and needs neither Ohm nor a uv checkout.
