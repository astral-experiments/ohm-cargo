#!/usr/bin/env python3
"""Replay both registered 32-core post-edit uv test builds on x86-64 Linux."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile


KIT = Path(__file__).resolve().parent
PROTOCOL = KIT / 'protocol'
PLAN = 'registered-32-heldout.json'
PLAN_SHA = 'f715395aa473fea9f3b3dcaaf3b5331baae3873964e7a07a80926ef1151106c8'
UV = 'c22e6b71933443e9cd299d4b6ac8de035ed4825b'
LINK = Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')
COMPONENTS = {
    'bin/cargo': '02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573',
    'bin/rustc': 'c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60',
    str(LINK): '0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5',
}
CANDIDATES = {
    'bin/wild-pr-46': ('wild-prefix-v2/v2-wild', '901b68fc9ca30975d837d45dcf1bdf743a6130ecef5e23d6aef44558b09bd7e1'),
    'bin/wild-returned-slots': ('round18-linker/js-refresh-v3', '3b31c5baad41cbe6bbd3647b31f913f02d03f0d41c90eda445974ca1e59575de'),
}
HARNESS = (
    'common.py', 'native.py', 'native-admitted.py', 'rlib_equivalence.py',
    'elf_equivalence.py', 'stock-elf-forms.json', 'analyze.py', 'qualify-32.py',
)


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def verify(path, expected):
    if digest(path) != expected:
        raise RuntimeError(f'Unexpected SHA-256 for {path}')


def copy(src, dst):
    subprocess.run(['cp', '-a', '--reflink=auto', '--', src, dst], check=True)


def cpu_ids(spec):
    ids = set()
    for part in spec.split(','):
        bounds = [int(n) for n in part.split('-')]
        if len(bounds) > 2 or bounds[0] > bounds[-1]:
            raise ValueError(f'Invalid CPU range {part}')
        ids.update(range(bounds[0], bounds[-1] + 1))
    if len(ids) != 32 or not ids.issubset(os.sched_getaffinity(0)):
        raise ValueError('Choose exactly 32 CPUs available to this process')
    topology = set()
    for cpu in ids:
        entry = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
        topology.add(tuple((entry / key).read_text().strip() for key in ('physical_package_id', 'core_id')))
    if len(topology) != 32:
        raise ValueError('Choose one logical CPU on each of 32 distinct physical cores')
    return sorted(ids)


def invoke(script, *args, cpus=None, out=None):
    env = {k: v for k, v in os.environ.items() if not k.startswith('OHM_BENCH_')}
    cmd = [sys.executable, '-E', '-s', '-u', script, *args]
    if cpus is not None:
        cmd = ['taskset', '-c', ','.join(map(str, cpus)), *cmd]
    return subprocess.run(cmd, check=True, env=env, stdout=out)


def relocate(plan, scratch, cpus):
    frozen = json.loads(json.dumps(plan))
    old = Path('/tmp/ohm-uv-bench.0H03f2TH')
    plan['cpu'] = cpus
    for cohort, cfg in plan['cohorts'].items():
        cfg['cpu'] = cpus
        cfg['root'] = str(scratch / Path(cfg['root']).relative_to(old))
        assert cfg['endpoints'] == frozen['cohorts'][cohort]['endpoints']
    return plan


def prepare(args, work):
    verify(PROTOCOL / PLAN, PLAN_SHA)
    release = args.toolchain.resolve(strict=True)
    repo = args.uv_repository.resolve(strict=True)
    for name, expected in COMPONENTS.items():
        verify(release / name, expected)
    for src, (_, expected) in CANDIDATES.items():
        verify(KIT / src, expected)
    cpus = cpu_ids(args.cpus)
    subprocess.run(['git', '-C', repo, 'cat-file', '-e', UV + '^{commit}'], check=True)
    # A new private root keeps link switching and Cargo's fingerprints separate from user data.
    work.mkdir(mode=0o700)
    scratch = work / 'sandbox'
    root = scratch / 'round18'
    lab = work / 'round18-lab'
    warm = work / 'warmup'
    root.mkdir(parents=True)
    lab.mkdir()
    warm.mkdir()
    (work / 'bench-home.path').write_text(str(scratch) + '\n')
    (work / 'uv').symlink_to(repo, target_is_directory=True)
    (work / 'upstream-monitor').mkdir()
    (work / 'upstream-monitor/toolchain18').symlink_to(release, target_is_directory=True)
    for name in ('measure.py', 'edit_holdout.py'):
        shutil.copyfile(PROTOCOL / name, work / name)
    for name in (*HARNESS, PLAN):
        shutil.copyfile(PROTOCOL / name, lab / name)
    for name in ('common.py', 'warm-32.py'):
        shutil.copyfile(PROTOCOL / name, warm / name)
    original = json.loads((PROTOCOL / PLAN).read_text())
    relocated = json.dumps(relocate(original, scratch, cpus), indent=2) + '\n'
    (lab / 'local-plan.json').write_text(relocated)
    (warm / PLAN).write_text(relocated)
    for src, (name, _) in CANDIDATES.items():
        dst = work / name
        dst.parent.mkdir()
        shutil.copy2(KIT / src, dst)
        dst.chmod(0o755)
    tool = root / 'tools'
    copy(release, tool)
    for role, name in [('cargo', Path('bin/cargo')), ('wild', LINK)]:
        slot = tool / name
        if slot.is_symlink() or not slot.resolve().is_relative_to(tool):
            raise RuntimeError(f'Expected a regular binary in the private toolchain: {slot}')
        os.link(slot, root / ('official-original-' + role), follow_symlinks=False)
    home = scratch / 'cargo'
    home.mkdir()
    if args.seed_cargo_home:
        copy((args.seed_cargo_home / 'registry').resolve(strict=True), home / 'registry')
    else:
        archived = scratch / 'fetch-input'
        archived.mkdir()
        with subprocess.Popen(['git', '-C', repo, 'archive', UV], stdout=subprocess.PIPE) as git:
            subprocess.run(['tar', '-xf', '-', '-C', archived], stdin=git.stdout, check=True)
            if git.wait():
                raise RuntimeError('Could not archive pinned uv')
        env = dict(HOME=os.environ['HOME'], PATH=f"{tool / 'bin'}:/usr/local/bin:/usr/bin:/bin",
                   CARGO_HOME=str(home), RUSTC=str(tool / 'bin/rustc'), LC_ALL='C.UTF-8')
        subprocess.run([tool / 'bin/cargo', 'fetch', '--locked'], env=env, cwd=archived, check=True)
    invoke(warm / 'warm-32.py', cpus=cpus[4:8])


def score(lab):
    verify(lab / PLAN, PLAN_SHA)
    proc = invoke(lab / 'qualify-32.py', out=subprocess.PIPE)
    result = json.loads(proc.stdout)
    print(json.dumps(result, indent=2))
    return result


def audit_recorded():
    with tempfile.TemporaryDirectory() as name:
        work = Path(name)
        lab = work / 'round18-lab'
        lab.mkdir()
        (work / 'bench-home.path').write_text(str(work))
        for src in ('measure.py', 'edit_holdout.py'):
            shutil.copyfile(PROTOCOL / src, work / src)
        for src in ('common.py', 'analyze.py', 'qualify-32.py', PLAN):
            shutil.copyfile(PROTOCOL / src, lab / src)
        with zipfile.ZipFile(KIT / 'results/full-logs.zip') as archive:
            for cohort in ('initial', 'replica'):
                folder = Path('r18-32-confirm') / cohort / 'test'
                (lab / folder).mkdir(parents=True)
                for src in ('admitted.json', 'timings.csv', 'done.json', 'external-activity.jsonl'):
                    (lab / folder / src).write_bytes(archive.read((folder / src).as_posix()))
        result = score(lab)
        recorded = json.loads((KIT / 'results/qualification.json').read_text())
        if not result['complete'] or result != recorded:
            raise RuntimeError('Recorded results differ from the independent raw-data calculation')


def time_cohorts(work):
    lab = work / 'round18-lab'
    plan = json.loads((lab / 'local-plan.json').read_text())
    cpus = cpu_ids(','.join(map(str, plan['cpu'])))
    if os.geteuid() == 0 or Path('/proc/1/comm').read_text().strip() != 'systemd':
        raise RuntimeError('Run as a regular user with a host-wide /proc on a Linux systemd host')
    for cfg in plan['cohorts'].values():
        if not (Path(cfg['root']) / plan['target_pool'] / 'ready').is_file():
            raise RuntimeError('Run prepare to completion before timing')
    (lab / 'host-cleared-for-native').touch()
    for cohort in plan['cohorts']:
        invoke(lab / 'native-admitted.py', cohort, '--study', 'r18-32-confirm',
               '--plan', lab / 'local-plan.json', cpus=cpus)
    result = score(lab)
    if not result['complete']:
        raise RuntimeError('Expected two complete cohorts')
    (lab / 'result.json').write_text(json.dumps(result, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    prep = commands.add_parser('prepare', help='populate two independent cold test fixtures')
    prep.add_argument('--uv-repository', type=Path, required=True)
    prep.add_argument('--toolchain', type=Path, required=True)
    prep.add_argument('--seed-cargo-home', type=Path)
    prep.add_argument('--cpus', default='0-31')
    timing = commands.add_parser('time', help='run both fixed three-linker schedules on an idle host')
    for command in (prep, timing, commands.add_parser('score', help='audit completed raw trials')):
        command.add_argument('--work-dir', type=Path, required=True)
    commands.add_parser('audit', help='recalculate the bundled historical result without building uv')
    args = parser.parse_args()
    if args.action == 'audit':
        audit_recorded()
        return
    work = args.work_dir.resolve()
    if args.action == 'prepare':
        prepare(args, work)
    elif args.action == 'time':
        time_cohorts(work)
    else:
        score(work / 'round18-lab')


if __name__ == '__main__':
    main()
