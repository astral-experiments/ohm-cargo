"""Check the published four-contrast gate using complete cohorts only."""
from analyze import compare,validate
from common import *
import collections

plan_path=LAB/'registered-32-heldout.json'
assert sha(plan_path)=='f715395aa473fea9f3b3dcaaf3b5331baae3873964e7a07a80926ef1151106c8'
plan=json.loads(plan_path.read_text())
report={'registered_sha256':sha(plan_path),'cohorts':{},'complete':False,'qualifies':False}
for cohort,cfg in plan['cohorts'].items():
    directory=LAB/'r18-32-confirm'/cohort/'test'
    if not (directory/'done.json').exists():continue
    blocks=validate(directory,cfg['endpoints']['test'])
    assert len(blocks)==36 and all(len(block)==3 for block in blocks)
    for pos in range(3):
        assert collections.Counter(block[pos]['arm'] for block in blocks)=={arm:12 for arm in plan['arms']}
    assert len({tuple(r['arm'] for r in block) for block in blocks})==6
    admission=json.loads((directory/'admitted.json').read_text())['arms']
    for v in admission.values():
        assert v['roles']=={'cargo':1,'rustc':6,'wild':5}
        assert len(v['roster']['tests'])==len(set(v['roster']['tests']))==72
    rows=[json.loads(r) for r in (directory/'external-activity.jsonl').read_text().splitlines()]
    assert len(rows)==108
    competitors=[r for r in rows if r[-1]]
    entry={'comparators':{},'competing_builds':competitors}
    for control in ['base','shipped']:
        stats=compare(blocks,control,'stack')
        qualifies=stats['median_saved_pct_interval']['lower']>0 and max(stats['exact_two_sided_sign_p'],stats['conditional_two_sided_p'])<.0125
        entry['comparators'][control]={'passes_statistics':qualifies,**stats}
    report['cohorts'][cohort]=entry
report['complete']=len(report['cohorts'])==2
report['qualifies']=report['complete'] and all(x['passes_statistics'] for c in report['cohorts'].values() for x in c['comparators'].values()) and not any(c['competing_builds'] for c in report['cohorts'].values())
print(json.dumps(report,indent=2))
