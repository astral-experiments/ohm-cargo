"""Populate independent high-core holdout checkouts and equal per-arm targets."""
from common import *
import fcntl
import shutil
import time

plan=json.loads((LAB/'registered-32-heldout.json').read_text())
assert not (LAB/'host-cleared-for-native').exists()
def copy(src,dst):
    subprocess.run(['cp','-a','--reflink=auto','--',src,dst],check=True)
def write(path,contents):
    with path.open('x') as f:json.dump(contents,f,indent=2);f.write('\n')
def inventory(directory):
    checksum=hashlib.sha256();count=0;total=0
    for d,ds,names in os.walk(directory):
        ds.sort()
        for name in sorted(names):
            f=Path(d)/name;s=f.lstat()
            checksum.update(f'{f.relative_to(directory)}\t{s.st_size}\t{s.st_mtime_ns}\n'.encode())
            count+=1;total+=s.st_size
    return dict(files=count,bytes=total,metadata_sha256=checksum.hexdigest())
with (ROOT/'native-lease').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX)
    assert (ROOT/'tools/bin/cargo').samefile(ROOT/'official-original-cargo')
    assert (ROOT/'tools'/LINK).samefile(ROOT/'official-original-wild')
    for key,cfg in plan['cohorts'].items():
        root=Path(cfg['root']);root.mkdir(parents=True,mode=0o700)
        out=LAB/'warm-confirm32'/key;out.mkdir(parents=True)
        (root/'cargo-home').mkdir(mode=0o700)
        copy(OLD/'cargo/registry',root/'cargo-home/registry')
        (root/'uv').mkdir()
        with subprocess.Popen(['git','-C',WORK/'uv','archive',REVISION],stdout=subprocess.PIPE) as git:
            subprocess.run(['tar','-xf','-','-C',root/'uv'],stdin=git.stdout,check=True)
            if git.wait():raise RuntimeError('uv archive failed')
        shutil.copy2(root/'uv'/EDIT_PATH,root/'original')
        locksha=sha(root/'uv/Cargo.lock');results=[]
        for ep,phase in [('build','warm'),('test','warm'),('test','fresh')]:
            with (out/f'{ep}-{phase}.log').open('x') as log:
                start=time.monotonic()
                subprocess.run(command(ep,['--locked','--offline','-j4']),cwd=root/'uv',env=env(root),stdout=log,stderr=subprocess.STDOUT,check=True)
            roster=rosters((out/f'{ep}-{phase}.log').read_text())
            assert len(roster['tests'])==(72 if ep=='test' else 0)
            if phase=='fresh':assert not roster['compiled']
            results.append(dict(endpoint=ep,phase=phase,compiled=len(roster['compiled']),tests=len(roster['tests']),seconds=time.monotonic()-start))
            print(key,results[-1],flush=True)
        assert locksha==sha(root/'uv/Cargo.lock') and sha(root/'original')==sha(root/'uv'/EDIT_PATH)
        target=root/'target';pool=root/plan['target_pool'];pool.mkdir()
        original=inventory(target)
        assert original['files']>10000
        for arm in plan['arms']:
            copy(target,pool/arm)
            assert inventory(pool/arm)==original
            print(key,'copied',arm,flush=True)
        write(pool/'ready',dict(uv=REVISION,lock_sha256=locksha,metadata=original,arms=list(plan['arms'])))
        write(out/'done.json',results)
