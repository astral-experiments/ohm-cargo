# Ohm -18, one edited uv instruction cohort

Extract this packet into an empty directory and run the read-only replay from that directory.

```sh
python3 -I -B replay.py
```

`scope.json` names the cohort and full-workspace endpoint. Its counter is the sum of DynamoRIO application instructions in Cargo, all invoked rustc processes and Wild linkers and their application threads. The original eight changes use matched Cargo/Wild pairs. Both arms use distributed Ohm -18 rustc. Rust compiler observation uses Cargo's wrapper environment. GCC, collect2, observer wrappers, pre-exec work and kernel instructions are outside the sum. No tests execute. This packet alone provides one cohort.

The replay checks the signed-off input hashes, original schedule, stock ELF calibration, raw per-thread and per-process counts, exec and package rosters, edit identity and source/target restoration. Every file is included in `manifest.json`. The original failed admission and its available raw streams accompany the registered recovery. The allowed byte differences are restricted to the prequalified ELF roles and two fully reconstructed output forms. The packet contains the metadata and raw hashes required by the original score; calibrated full-size host ELFs are separately retained. `control/` contains the prospective launch registration; `custody/` identifies the actual live child, resource release and terminal state.

A completed cohort always reports its eight-pair statistics, including a failed gate. A collector rejection reports a null gate and no performance estimate. Every saved partial row and excluded receipt is retained and identified. An unfinished allocation, an unverified return, or a failed packet replay is not an eligible terminal packet. Replication requires separately qualified complete primary and repeat cohorts.
