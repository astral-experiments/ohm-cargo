"""Shared names and file-only checks for three existing registered cells."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent
WORK=PROJECT.parent
LAB=WORK/'round18-lab'
STUDY=PROJECT/'edited-role-recovery'
ORIGINAL=PROJECT/'edited-roles'
CELLS=('replica-build','initial-test','replica-test')
PAUSES=(ORIGINAL/'control/pause',STUDY/'control/pause')
PREVIOUS=PROJECT/'edited-role-window'
FLOOR=120*2**30
CLEAR='c9627a43cdbb56b785ebd88915fe0400479abd3b56ff4718e185afff4e0da124'
OLD_RETURN='cc9ed221837716053b3d58fdb74dc84402116f441684ddd44dfb37d61014347c'


def need(ok,message):
    if not ok:raise RuntimeError(str(message))


def sha(path):
    with path.open('rb') as src:return hashlib.file_digest(src,'sha256').hexdigest()


def read(path):return json.loads(path.read_text())


def write_new(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2,sort_keys=True);out.write('\n')


def cell(name):
    need(name in CELLS,'only the three remaining assigned cells are accepted')
    return tuple(name.split('-'))


def check_seal():
    p=HERE/'registration.json'
    need(sha(p)==(HERE/'registration.sha256').read_text().split()[0],'changed next-cell control registration')
    reg=read(p)
    for rel,digest in reg['code'].items():need(sha(HERE/rel)==digest,rel)
    for name in CELLS:need(sha(STUDY/'registrations'/(name+'.json'))==reg['cells'][name]['registration'],name)
    need(sha(LAB/'completed-native-counter-window.json')==CLEAR,'original terminal clearance differs')
    need(sha(PREVIOUS/'process-return.json')==OLD_RETURN,'old sampler return changed')
    return reg


def eh_return():
    # The first shipped comparator follows the completed Cargo primary. Never use an older EH
    # handoff once a later comparator has started creating its own records.
    root=WORK/'round18-eh-release/command-v2'
    cases=[('initial','shipped'),('replica','base'),('replica','shipped')]
    begun=[(a,b) for a,b in cases if (root/'results'/a/b).is_dir()]
    need(begun and begun==cases[:len(begun)],'invalid or missing EH comparator sequence')
    a,b=begun[-1];path=root/f'custody-after-{a}-{b}.json'
    need(path.is_file() and not path.is_symlink() and read(path).get('custody_returned') is True,'latest EH owner has not returned the host')
    return path


def grant(name):
    c,e=cell(name);reg=check_seal()
    eh=eh_return()
    return dict(only_cell=name,cohort=c,endpoint=e,eh_return=str(eh.relative_to(WORK)),eh_return_sha256=sha(eh),next_registration_sha256=sha(HERE/'registration.json'),
                original_registration_sha256=reg['cells'][name]['registration'],prior_native_return=CLEAR,
                real_host_cpus=list(range(8,16)),floor_bytes=FLOOR,authority='coordinator explicitly released this individual cell after the EH/native allocation returned')


def table_rows(table):
    import csv
    return list(csv.DictReader(table.open())) if table.is_file() else []
