"""Archive one independently terminal historical role cell and re-score a fresh extraction."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
import replay


def select_files(name):
    cohort,ep=c.cell(name);reg=c.read(c.STUDY/'registrations'/(name+'.json'));oldcase=c.ORIGINAL/'results'/cohort/ep
    raw=c.STUDY/'results'/cohort/ep;cal=c.PROJECT/'role-elf-calibration'
    folders=[raw,*oldcase.glob('admit-*'),cal/(cohort if ep=='build' else 'test-'+cohort)]
    paths={p for directory in folders for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    paths.update(c.PROJECT/rel for rel in reg['inputs'])
    paths.update(c.ORIGINAL/rel for rel in reg['original_admission_receipts'])
    paths.update([oldcase/'rejected.json',oldcase/'restore.json',c.ORIGINAL/'PROTOCOL.md',c.ORIGINAL/'REPRODUCE.md',
                  c.STUDY/'registrations'/(name+'.json'),c.WORK/'tree-count/wrap.py',c.WORK/'edit-link-profile/native-instrument/count.py'])
    paths.update(cal/filename for filename in ['registration.json','PROTOCOL.md','stock_replay.py','test_controls.py','verified-for-release.json','detached.json'])
    sel={p.relative_to(c.WORK).as_posix():p for p in paths}
    controls=c.HERE/'cells'/name
    for p in controls.iterdir():
        if p.is_file():sel['custody/'+p.name]=p
    sel['custody/coordinator-grant.json']=c.HERE/'grants'/(name+'.json')
    given=c.read(sel['custody/coordinator-grant.json']);sel['custody/eh-return.json']=c.WORK/given['eh_return']
    sel['custody/native-return.json']=c.LAB/'completed-native-counter-window.json'
    sel['custody/original-first-cell-return.json']=c.PREVIOUS/'process-return.json'
    for p in c.HERE.iterdir():
        if p.is_file() and p.name in (*c.read(c.HERE/'registration.json')['code'].keys(),'registration.sha256','registration.json'):
            sel['control/'+p.name]=p
    sel.update({'replay.py':c.HERE/'replay.py','README.md':c.HERE/'packet-readme.md'})
    c.need(all(f.is_file() and not f.is_symlink() for f in sel.values()),'missing or aliased evidence input')
    return sel


def main(name):
    c.check_seal();cohort,ep=c.cell(name);ctl=c.HERE/'cells'/name
    c.need(c.read(ctl/'validated.json')['closure_sha256']==c.sha(ctl/'closure.json'),'not a verified terminal custody')
    r=replay.score_cell(c.PROJECT,name)
    packet=c.HERE/'packets'/name;packet.mkdir(parents=True,exist_ok=False)
    c.write_new(packet/'scope.json',dict(cell=name,cohort=cohort,endpoint=ep,replication='This packet contains only this cohort of this command.',counter_scope=r['scope']))
    c.write_new(packet/'result.json',r)
    sources={**select_files(name),'scope.json':packet/'scope.json','result.json':packet/'result.json'}
    manifest={k:c.sha(p) for k,p in sorted(sources.items())}
    archive=packet/('ohm18-edited-roles-'+name+'.zip');tmp=archive.with_suffix('.partial')
    with zipfile.ZipFile(tmp,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for k,p in sorted(sources.items()):z.write(p,k)
        z.writestr('manifest.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    with tempfile.TemporaryDirectory(prefix='ohm18-edited-role-rescore-') as dest:
        with zipfile.ZipFile(tmp) as z:z.extractall(dest)
        p=subprocess.run([sys.executable,'-I','-B',str(Path(dest)/'replay.py')],cwd=dest,capture_output=True,text=True,env={'PATH':os.defpath})
        if p.returncode:
            (packet/'replay-failure.log').write_text(p.stdout+'\n'+p.stderr)
            raise RuntimeError('independent packet replay failed; retained partial archive')
        c.write_new(packet/'replayed-summary.json',json.loads(p.stdout))
    tmp.rename(archive)
    rec=dict(cell=name,outcome=r['public'],recorded_arms=r['recorded_arms'],relative_archive=archive.name,bytes=archive.stat().st_size,files=len(manifest)+1,archive_sha256=c.sha(archive),replayed_result_sha256=c.sha(packet/'replayed-summary.json'))
    c.write_new(packet/'bundle.json',rec);print(json.dumps(rec))


if __name__=='__main__':
    q=argparse.ArgumentParser();q.add_argument('cell',choices=c.CELLS);main(q.parse_args().cell)
