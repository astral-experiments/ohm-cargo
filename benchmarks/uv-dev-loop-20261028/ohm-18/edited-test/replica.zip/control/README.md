# Remaining Ohm -18 edited-role counts

The only authorized endpoints of this controller are the three already registered recovery cells. Start them one at a time in `replica-build`, `initial-test`, `replica-test` order, subject to a separate explicit coordinator release for each. The previously completed primary build stays in its own packet. This controller uses the immutable `edited-role-recovery/recover.py` and original scorer, with no change to scheduled edits, arm order, counter scope, product oracle, workload or statistical gates.

After explicit release of a named cell and custody return from the EH/native allocation, use the following commands on the real non-root Linux host from the project root. In this example the coordinator has granted only `replica-build`.

```sh
cell=replica-build
ctl=work/round18-cargo/edited-role-next
python3 -I -B "$ctl/host.py" issue "$cell" --coordinator-released
taskset -c 8-15 python3 -I -B "$ctl/host.py" start "$cell"
taskset -c 24 python3 -I -B "$ctl/package.py" "$cell"
```

The grant template refuses to emit a grant while the most recently started EH comparator still lacks its positive, individually named custody-return receipt. It embeds that exact receipt and hash. Leave the peer pause flags in place while waiting and allow the coordinator to own the native lease. At admission, the guardian takes an exclusive local allocation lock and the native lease, checks the peer pause and the actual real-host process table, and refuses a preexisting worker, result directory, held target or visible target. The historical observer's last PID is never authority. It spawns exactly one new session under the held pauses, pins the PID with a kernel pidfd, and checks its live parent, session, process group, real executable, complete argv, UID, CPUs and process start tick. Its newly written pause registration must have this PID, the chosen cell, the initial phase, and a timestamp after launch before either pause is removed. It rechecks the original source and exact protected directory identities. A subsequent cell requires the previous cell's verified closure digest. No executable-proof study or other endpoint is dispatched.

Each original runner clones at most two working arm targets at once and retains the original failure/structural predecessor. Before launch, require more than the greater of 150 GiB and 120 GiB plus twice the entire registered predecessor plus 3 GiB. The live watcher polls every second, requests both original pauses below 130 GiB and freezes this owned process tree at 124 GiB if necessary. The immutable runner also checks actual free space before every clone. A guard interruption leaves the affected process and private evidence for explicit coordinator recovery. On an ordinary return, the watcher records the actual child status, keeps both pauses, verifies source and visible target restoration and protected directory inodes, and identifies only the two arm banks retired by the original successful finalizer. A collector rejection preserves its quarantine and cannot qualify performance.

`package.py CELL` packages one verified terminal cell at a time and refuses to include data from unstarted or unfinished cells. It retains complete statistics whether the original gate passes or fails. A terminal collector rejection has a null gate and no performance estimate. A separate replay launched on a fresh extraction verifies the original scoring code, scope-specific raw inputs and restored custody. Output is under `packets/CELL/`. `selftest.py` uses source and small invented records only.
