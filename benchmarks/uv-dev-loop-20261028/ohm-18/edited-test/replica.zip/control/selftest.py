"""CPU-only synthetic control and eight-pair replay. Never stage a benchmark or launch a child."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c,host,replay


def expect_failure(fn):
    try:fn()
    except (RuntimeError,ValueError):return
    raise AssertionError('invalid input accepted')


def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data)+'\n')


def invent(project):
    old=project/'edited-roles';rec=project/'edited-role-recovery';old.mkdir();rec.mkdir()
    (old/'summary.py').write_bytes((c.ORIGINAL/'summary.py').read_bytes());(rec/'score.py').write_bytes((c.STUDY/'score.py').read_bytes())
    cohort,ep='replica','build';name=cohort+'-'+ep;base=rec/'results'/cohort/ep
    h=lambda s:hashlib.sha256(str(s).encode()).hexdigest()
    modes=[['native','base'],['count','candidate'],['native','candidate'],['count','base']]
    cfg=dict(native_count_admission=modes,edits=[dict(id=i,sha256=h(i)) for i in range(8)],pairs=[dict(id=i,order=list(reversed(replay.ARMS)) if i%2 else list(replay.ARMS)) for i in range(8)])
    plan=dict(original_sha256=h(444),schedule={cohort:{ep:cfg}});put(old/'plan.json',plan);(old/'registered.sha256').write_text(c.sha(old/'plan.json')+'  plan.json\n')
    put(rec/'registrations'/(name+'.json'),dict(cohort=cohort,endpoint=ep,original_admission_receipts={},permits={},inputs={'edited-roles/summary.py':c.sha(old/'summary.py')},schedule=cfg))
    roles=['cargo','rustc','wild'];keys={r:'synthetic-'+r for r in roles}
    roster=dict(packages=[['Compiling','uv v0.0.0 (/invented)']],role_counts=dict.fromkeys(roles,1),tests=[],records=sorted([[r,json.dumps(keys[r])] for r in roles]))
    def sample(directory,i,mode):
        directory.mkdir(parents=True);(directory/'cargo.log').write_text('   Compiling uv v0.0.0 (/invented)\n')
        nums={r:10000+ix for ix,r in enumerate(roles)}
        for j,role in enumerate(roles):
            pid=str(100+j);put(directory/(role+'-'+pid+'.json'),dict(role=role,key=keys[role],pid=int(pid),threads={pid:nums[role]},instructions=nums[role],executable='/imaginary/'+role))
        if mode=='native':
            traces={'/imaginary/'+r:1 for r in roles};put(directory/'native-execs.json',traces)
            (directory/'exec.1').write_text(''.join(f'execve("{e}", ["fixture"], NULL) = 0\n' for e in traces))
        put(directory/'receipt.json',dict(source_sha256=h(i),source_mtime_ns=i+10,totals=nums,files={'debug/fixture':dict(size=11,sha256=h(i+20),canonical_sha256=h(i+20),permitted_fields=None)},roster=roster))
        return nums
    put(base/'admission.json',roster)
    for j,(mode,arm) in enumerate(modes):sample(base/f'admit-{j}-{mode}-{arm}',33,mode)
    rows=[]
    for i,pair in enumerate(cfg['pairs']):
        for j,arm in enumerate(pair['order']):
            sub=f'pair-{i}-{j}-{arm}';totals=sample(base/sub,i,'count')
            rows.append(dict(pair=i,id=i,position=j,arm=arm,**totals,total=sum(totals.values()),source_sha256=h(i),receipt=sub+'/receipt.json'))
    def write_rows(data):
        with (base/'samples.csv').open('w',newline='') as f:
            out=csv.DictWriter(f,fieldnames=rows[0]);out.writeheader();out.writerows(data)
    write_rows(rows);put(base/'complete.json',dict(common_unchanged=True));put(base/'restore.json',dict(target_vacant=True,source_sha256=plan['original_sha256']))
    return base,name,rows,write_rows


def portable(root,project,raw_result,synthetic_epoch=9000):
    name=raw_result['cell'];cohort,ep=name.split('-');raw=project/'edited-role-recovery/results'/cohort/ep
    control=root/'control';custody=root/'custody'
    def digest(p):return c.sha(p)
    fake_source=project/'edited-role-recovery/registrations'/(name+'.json')
    put(custody/'native-return.json',{'synthetic':True});put(custody/'eh-return.json',{'custody_returned':True});put(custody/'original-first-cell-return.json',{'synthetic':True})
    reg=dict(code={},cells={name:{'registration':digest(fake_source)}},native_return=digest(custody/'native-return.json'),initial_build_return=digest(custody/'original-first-cell-return.json'))
    put(control/'registration.json',reg);h=digest(control/'registration.json');(control/'registration.sha256').write_text(h+'  registration.json')
    grant=dict(only_cell=name,original_registration_sha256=digest(fake_source),next_registration_sha256=h,prior_native_return=reg['native_return'],eh_return_sha256=digest(custody/'eh-return.json'),real_host_cpus=list(range(8,16)))
    put(custody/'coordinator-grant.json',grant);h=digest(custody/'coordinator-grant.json')
    w=dict(pid=5454,ppid=91,session=5454,group=5454,cpus=grant['real_host_cpus']);status=dict(pid=5454,cohort=cohort,endpoint=ep,state='paused',boundary='before validating inputs',utc_ns=synthetic_epoch+1)
    ad=dict(cell=name,worker=w,pauses={'x':'fixture'},anchors={'fake':[9,1]},grant_sha256=h,selected_grant=grant,plan_sha256=digest(fake_source),accepted_worker_status=status,spawn_ns=synthetic_epoch,guardian_pid=91)
    complete=raw_result['public']['gate'] is not None
    cl=dict(cell=name,worker=w,worker_exited=True,source_restored=True,target_vacant=True,pauses=ad['pauses'],minimum_free_bytes=121*2**30,protected_anchors=ad['anchors'],rows=raw_result['recorded_arms'],issued_grant=h,samples_sha256=digest(raw/'samples.csv'),terminal='complete' if complete else 'excluded',worker_returncode=0 if complete else 1)
    put(custody/'admitted.json',ad);put(custody/'closure.json',cl);put(custody/'validated.json',dict(closure_sha256=digest(custody/'closure.json'),admission_sha256=digest(custody/'admitted.json')))
    put(root/'scope.json',{'cell':name});put(root/'result.json',raw_result)
    put(root/'manifest.json',{p.relative_to(root).as_posix():digest(p) for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'})
    with patch.object(replay,'HERE',root):
        assert replay.validate()['public']==raw_result['public']


def main():
    observed={'pid':555}
    mark=dict(pid=555,cohort='replica',endpoint='build',state='paused',boundary='before validating inputs',utc_ns=238)
    host.authenticate(mark,observed,'replica','build','before validating inputs',200)
    for item in [dict(pid=993),dict(cohort='initial'),dict(endpoint='test'),dict(state='released'),dict(boundary='after pair 1 of 8'),dict(utc_ns=189)]:
        expect_failure(lambda:host.authenticate({**mark,**item},observed,'replica','build','before validating inputs',200))
    for name in c.CELLS:
        reg=c.read(c.STUDY/'registrations'/(name+'.json'));replay.qualification(c.PROJECT,c.ORIGINAL,reg)
    expect_failure(lambda:replay.public_outcome(dict(state='collecting')))
    expect_failure(lambda:replay.public_outcome(dict(state='complete',gate_passed=None,n_pairs=8)))
    assert replay.public_outcome(dict(state='complete',gate_passed=True,n_pairs=8))['gate'] is True
    with tempfile.TemporaryDirectory(prefix='synthetic-edit-role-schema-') as raw:
        root=Path(raw);project=root/'round18-cargo';project.mkdir();out,name,rows,table=invent(project)
        tied=replay.score_cell(project,name);assert tied['public']['gate'] is False and tied['scored_estimate']['two_sided_sign_p']==1 and tied['scored_estimate']['ties']==8
        portable(root,project,tied)
        (out/'complete.json').unlink();put(out/'rejected.json',dict(type='AssertionError',error='invented conflicting object',traceback='synthetic fixture'))
        table(rows[:1])
        expect_failure(lambda:replay.score_cell(project,name))
        for row in rows[2:]:shutil.rmtree((out/row['receipt']).parent)
        early=replay.score_cell(project,name);assert early['public']['gate'] is None and early['scored_estimate'] is None and early['recorded_arms']==1 and len(early['partial_or_excluded_readbacks'])==6
        portable(root,project,early)
        table([]);shutil.rmtree(out/'pair-0-1-candidate');shutil.rmtree(out/'pair-0-0-base')
        zero=replay.score_cell(project,name);assert zero['public']['gate'] is None and zero['recorded_arms']==0
        portable(root,project,zero)
        table([{**rows[0],'arm':'candidate'}]);expect_failure(lambda:replay.score_cell(project,name))
    print(json.dumps(dict(stale_or_wrong_marker_failures=6,registered_calibrations_checked=3,original_statistics_real_code_on_synthetic_ties=True,exact_gate_false=True,full_manifest_replays_for_inconclusive_partial_or_zero=3,empty_and_partial_exclusions_gate_null=True,rejects_future_or_misassigned_arms=True,real_benchmark_processes=0,real_targets=0),sort_keys=True))


if __name__=='__main__':main()
