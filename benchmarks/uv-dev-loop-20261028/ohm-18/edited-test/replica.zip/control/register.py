"""Prospectively identify the existing one-use cells without creating benchmark state or authority."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c


def main():
    h=c.HERE;home=Path((c.WORK/'bench-home.path').read_text().strip())/'role-studies-18'
    c.need(not any((h/n).exists() for n in ('cells','grants','packets','one-cell.lock','registration.json','registration.sha256')),'already registered, attempted, or granted')
    c.need(all(p.is_file() for p in c.PAUSES),'original pauses not present')
    c.need(c.sha(c.PREVIOUS/'process-return.json')==c.OLD_RETURN and c.sha(c.LAB/'completed-native-counter-window.json')==c.CLEAR,'past return identity')
    cases={}
    for name in c.CELLS:
        co,ep=c.cell(name);d=home/co;p=c.STUDY/'registrations'/(name+'.json');r=c.read(p);prednames=['common','rejected-'+ep+'-structural','homes-'+ep]
        c.need(not (c.STUDY/'results'/co/ep).exists() and all(not (d/n).exists() for n in ('target','held-base','held-candidate','recovery-homes-'+ep)),'benchmark state already allocated')
        c.need(all((d/n).is_dir() and not (d/n).is_symlink() for n in prednames),'missing preserved predecessor')
        c.need(len(r['schedule']['pairs'])==8 and r['cpus']==list(range(8,16)),'unexpected prior registration')
        cases[name]=dict(registration=c.sha(p),schedule_sha256=hashlib.sha256(json.dumps(r['schedule'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),original_rejection=c.sha(c.ORIGINAL/'results'/co/ep/'rejected.json'),structural=r['structural'],protected_identities={n:[(d/n).stat().st_dev,(d/n).stat().st_ino] for n in prednames})
    names=['common.py','host.py','package.py','replay.py','register.py','selftest.py','synthetic.json','README.md','packet-readme.md']
    c.write_new(h/'registration.json',dict(version=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),order=list(c.CELLS),code={n:c.sha(h/n) for n in names},cells=cases,native_return=c.CLEAR,initial_build_return=c.OLD_RETURN,original_immutable_gate='read directly from the registered original scorer; support positive, negative/inconclusive, and excluded outcomes',new_hardware_measurements=0,new_target_allocations=0,issued_individual_grants=0))
    with (h/'registration.sha256').open('x') as f:f.write(c.sha(h/'registration.json')+'  registration.json\n')
    c.check_seal();print(c.sha(h/'registration.json'))
if __name__=='__main__':main()
