"""Test the real result reader on invented counts. Never open or create a target bank."""
import collections
import copy
import csv
import json
from pathlib import Path
import shutil
import sys
import tempfile

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import replay


def put(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj))


def run(source_work,scratch):
    source=source_work/"round18-cargo"
    work=scratch/"work"
    project=work/"round18-cargo"
    study=project/replay.NAME
    old=project/"edited-roles"
    reg=replay.read(source/replay.NAME/"registrations/replica-test.json")
    reference=next(iter(reg["original_admission_receipts"]))
    for name in (replay.NAME+"/registrations/replica-test.json",replay.NAME+"/score.py","edited-roles/summary.py",
                 "edited-roles/plan.json","edited-roles/"+reference,"edited-role-next/replay.py"):
        dest=project/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,dest)
    basis=replay.read(source/"edited-role-recovery/results/replica/test/admit-0-native-base/receipt.json")
    for key,rule in reg["permits"].items():
        item=basis["files"][key]
        proof=copy.deepcopy(rule["proof"])
        proof["actual_entsize"]=next(int(v) for v,h in proof["forms"].items() if h["sha256"]==item["sha256"])
        proof["actual_sha256"]=item["sha256"]
        proof.update(original_library_test_rule=False,qualification=rule["qualification"])
        item.update(permitted_fields=proof,canonical_sha256=proof["forms"]["0"]["sha256"])
    ref=replay.read(old/reference)
    source_mtime=ref["source_mtime_ns"]
    seeds={e["id"]:e["sha256"] for e in reg["schedule"]["edits"]}
    assert ref["roster"]==basis["roster"]
    out=study/"results/replica/test";out.mkdir(parents=True)
    def one(directory,mode,arm,edit,wins):
        directory.mkdir()
        raw=copy.deepcopy(basis)
        raw.update(source_sha256=seeds[edit],source_mtime_ns=source_mtime if edit==1 else source_mtime+edit)
        counts=collections.Counter();execs=collections.Counter()
        lines=[kind+" "+value for kind,value in raw["roster"]["packages"]]
        lines+=["Executable "+v for v in raw["roster"]["tests"]]
        (directory/"cargo.log").write_text("\n".join(lines)+"\n")
        for i,(role,s) in enumerate(raw["roster"]["records"]):
            key=json.loads(s);pid=38000+i;value=900 if wins and arm=="candidate" else 1000
            exe=f"/synthetic-data/role/{role}"
            counts[role]+=value;execs[exe]+=1
            put(directory/f"{role}-{pid}.json",{"role":role,"pid":pid,"key":key,"argv":key if isinstance(key,list) else ["-o",key],
                "executable":exe,"instructions":value,"threads":{str(pid):value}})
        if mode=="native":
            (directory/"exec.38000").write_text("".join(f'execve("{exe}", ["synthetic"], []) = 0\n'*n for exe,n in execs.items()))
            put(directory/"native-execs.json",dict(execs))
        raw["totals"]=dict(counts);put(directory/"receipt.json",raw)
        return dict(counts)
    def observe(full,partial=False,wins=True):
        for d in list(out.iterdir()):
            if d.is_file():d.unlink()
            else:shutil.rmtree(d)
        how_many=16 if full else 3 if partial else 0
        if how_many:
            for i,(mode,arm) in enumerate(reg["schedule"]["native_count_admission"]):
                one(out/f"admit-{i}-{mode}-{arm}",mode,arm,1,wins)
            put(out/"admission.json",ref["roster"])
            with (out/"samples.csv").open("w",newline="") as f:
                writer=csv.DictWriter(f,fieldnames=["pair","id","position","arm","cargo","rustc","wild","total","source_sha256","receipt"])
                writer.writeheader()
                for ix in range(how_many):
                    i,j=divmod(ix,2);p=reg["schedule"]["pairs"][i];arm=p["order"][j]
                    log=f"pair-{i}-{j}-{arm}"
                    counts=one(out/log,"count",arm,p["id"],wins)
                    writer.writerow(dict(pair=i,id=p["id"],position=j,arm=arm,**counts,total=sum(counts.values()),
                                         source_sha256=seeds[p["id"]],receipt=log+"/receipt.json"))
        if full:
            put(out/"complete.json",{"common_unchanged":True});put(out/"restore.json",{"source_sha256":replay.read(old/"plan.json")["original_sha256"],"target_vacant":True,"mutable_home_restored":True})
        else:
            put(out/"rejected.json",{"type":"SyntheticFailure","error":"deliberate self-test"})
            if not how_many:
                (out/"admit-0-native-base").mkdir()
            else:
                i,j=divmod(how_many,2);arm=reg["schedule"]["pairs"][i]["order"][j]
                (out/f"pair-{i}-{j}-{arm}").mkdir()
        return replay.streams(work)
    results={}
    for label,full,partial,wins,gate,n in [("complete_pass",True,False,True,True,16),
                ("complete_null",True,False,False,False,16),("excluded_zero",False,False,False,None,0),
                ("excluded_partial",False,True,False,None,3)]:
        row=observe(full,partial,wins)
        assert row["public"]["gate"] is gate and row["recorded_arms"]==n and (row["scored_estimate"] is None)==(gate is None)
        results[label]={"gate":gate,"recorded_arms":n}
    table=out/"samples.csv"
    with table.open() as f:rows=list(csv.DictReader(f))
    def rewrite():
        with table.open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    def rejects(why):
        try:replay.streams(work)
        except (ValueError,AssertionError,RuntimeError):results[why]=True
        else:raise ValueError("accepted "+why)
    old_count=rows[0]["cargo"];rows[0]["cargo"]="1";rewrite();rejects("corrupt_partial_counter_rejected")
    rows[0]["cargo"]=old_count;rows[0]["position"]="1";rewrite();rejects("noncontiguous_partial_assignment_rejected")
    return results


if __name__=="__main__":
    if len(sys.argv)!=3:raise SystemExit("python3 -I -B selftest.py WORK EMPTY_TEST_PARENT")
    with tempfile.TemporaryDirectory(prefix="invented-results-",dir=sys.argv[2]) as d:
        print(json.dumps({"synthetic_only":True,"subject_launches":0,"cases":run(Path(sys.argv[1]).resolve(),Path(d))},indent=2,sort_keys=True))
