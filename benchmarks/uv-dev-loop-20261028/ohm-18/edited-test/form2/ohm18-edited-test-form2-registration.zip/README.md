# Ohm -18 edited-test replica registration

The archive registers a separate wrapper-assisted `cargo test --no-run --locked --offline -j8` comparison on the full uv workspace at `c22e6b71933443e9cd299d4b6ac8de035ed4825b`. The earlier replica returned with zero scored rows and a null gate. Its immutable archive SHA-256 is `62a3c431e37c34688429f4faff04a775136073e14035738729a72953e0785dd4`. Its original collector error, source restoration, worker status 1, supervisor return 0, summary and raw-control product digests are present. The full 1,387-file archive can be matched separately by digest. The independently published initial cohort measured 2.096593% fewer counted instructions.

Two historical stock `uv` binaries showed exactly 33 differing bytes. All differences are in the 32-byte GNU build ID and one byte of the ELF section-header entry size for `.rodata`. The ordinary-bin admission now requires the two observed full SHA-256s. For each scored edit, the original ELF decoder recomputes Wild's two BLAKE3 GNU IDs and requires the corresponding two entire-file SHA-256s to agree across arms. This addition applies only to one named, matching normal `uv` binary relink. The archived stock comparison SHA-256 is `86d0beb82377dfb476327dcc55703136b7383f89d9ac6dae4f891777a09b3ba0`. Both original 316,713,312-byte files are host-resident. Their hashes, offsets and per-file masked digests are archived.

## Verify without the benchmark machine

A Python 3.11 or newer standard library is sufficient. Check the external `SHA256SUMS`, extract the ZIP in a fresh directory and run:

```sh
python3 -I -B detached.py
```

The reader checks the content manifest, recomputes the ten registered edit digests from the original uv file, checks the earlier rejection and three role-specific controls, then verifies the exact 8-pair schedule, both driver digests, all 72 test executable names and 1 Cargo/6 rustc/5 Wild admission roster. The reader's audit hook rejects file reads beyond this extraction and Python's standard library, filesystem writes and process launches. The top-level ZIP SHA supplied at publication is the external integrity anchor. All ZIP entries have deterministic timestamps and modes. When restoring a physical installation with an extractor that drops Unix permissions, set mode 0755 on `work/tree-count/wrap.py` and `work/round18-cargo/role-elf-calibration/blake-stream`.

The frozen source registration is `b2490310d1a7ff445a86e4033d32f90c900c71f2278822085d341b5dbd40342e`. Its read-only operational guide is `work/round18-cargo/edited-role-replica-test-form2/README.md`. Original build and instrumentation provenance is in `work/round18-cargo/edited-roles/REPRODUCE.md`, with `plan.json`, `sealed.json`, `round18-cargo/pgo/audit.json`, the executable ELF checker, released wrapper sources and the original matched PGO driver hashes. Run the physical commands only in the original, separately granted Linux fixture. They authenticate three actual source/target/home directory inodes and require the original toolchain, original uv checkout and DynamoRIO installation. The compact evidence archive supplies the scripts and exact immutable prerequisites. It does not distribute those multi-gigabyte fixtures, release installations or Cargo binaries.

## Package and replay a returned result

After the physical supervisor exits and validates restoration, use its real outer session, final chunk and exit status, the previously published registration ZIP, and its external SHA-256. Run the archived top-level packer with a new output directory:

```sh
python3 -I -B pack.py outcome --work "$actual_project_work" --output "$fresh_output" \
  --registered-archive "$registration_zip" --registered-sha256 "$published_digest" \
  --session "$tool_session" --chunk "$final_chunk" --exit-status "$tool_exit"
```

The packer includes every file under the new replica's raw result directory, all native exec traces and per-thread counts, the coordinator grant, the linked preceding host receipt, worker and guardian records, and the full immutable registration ZIP. It independently replays a fresh extraction under the same read-only policy. The caller supplies the tool's outer return. The reader checks the real child/guardian identities and closed source, targets, mutable Cargo home, pause sentinels and global disk floor against the recorded custody.

- A complete, qualified run publishes its eight paired reductions and both exact p-values. The original replica gate requires a positive median and two-sided sign and order-balanced randomization p-values below .05.
- A complete run that misses the gate publishes all eight pairs and its nonqualifying result.
- A closed collector error publishes the precise failure and every zero or partial raw record, with a null gate and no estimate. Each written row must be a contiguous prefix of the frozen schedule, with counts that reconcile to its stored per-PID streams. Only the currently failing trial may have raw output beyond that prefix. A worker that is still live or lacks a validated return cannot produce an outcome packet.

The measure sums DynamoRIO application instructions in Cargo, all six rustc programs and all five Wild programs. It excludes GCC, collect2, observers, kernel and pre-exec work. The fixed parent/child rustc uses the released compiler and registered wrapper. Wild uses `--no-fork`. No tests execute. Keep the prior exclusion and this separately registered, stock-calibrated repeat distinct in any report.
