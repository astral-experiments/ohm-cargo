"""Create a deterministic registration packet or a verified single-cohort outcome packet."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import replay


def encoded(o):
    return (json.dumps(o,sort_keys=True,indent=2)+"\n").encode()


def packed(items):
    manifest={n:hashlib.sha256(b).hexdigest() for n,b in sorted(items.items())}
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,"w") as z:
        for n,b in sorted({**items,"manifest.json":encoded(manifest)}.items()):
            info=zipfile.ZipInfo(n,(1980,1,1,0,0,0))
            info.create_system=3
            info.external_attr=(0o100755 if n.endswith(("/blake-stream","/tree-count/wrap.py")) else 0o100644)<<16
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    return buf.getvalue()


def registration(work):
    project=work/"round18-cargo"
    study=project/replay.NAME
    old=project/"edited-roles"
    prev=project/"edited-role-next"
    rec=project/"edited-role-recovery"
    prior=rec/"results/replica/test"
    cfg=replay.read(study/"registrations/replica-test.json")
    front=replay.read(study/"registration.json")
    seal=replay.read(old/"sealed.json")
    selected={project/n for n in front["frozen"]}|{project/n for n in cfg["inputs"]}
    selected.update(old/n for n in cfg["original_admission_receipts"])
    selected.update(old/n for n in seal["harness"])
    selected.update(work/n for n in seal["wrapper_inputs"])
    selected.update(project/n for n in front["peer_pause_sha256"])
    selected.update(study/n for n in ("registration.json","registration.sha256","ready.json","dry-test.py","control/pause","control/supervisor.pause"))
    selected.update(old/n for n in ("PROTOCOL.md","REPRODUCE.md","results/replica/test/predecessor.json","results/replica/test/rejected.json",
                                    "results/replica/test/registry.json","results/replica/test/restore.json"))
    selected.update(prior/n for n in ("admit-0-native-base/receipt.json","registry.json","predecessor.json","rejected.json","restore.json"))
    selected.update(prev/n for n in ("replay.py","registration.sha256","cells/replica-test/admitted.json","cells/replica-test/worker.log",
                                     "packets/replica-test/replayed-summary.json","packets/replica-test/result.json",
                                     "packets/initial-test/bundle.json","packets/initial-test/replayed-summary.json"))
    calibration=project/"role-elf-calibration"
    selected.update(p for p in (calibration/"test-replica").rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    selected.update(calibration/n for n in ("PROTOCOL.md","test_controls.py","stock_replay.py","registration.json","verified-for-release.json"))
    selected.update(work/n for n in ("bench-home.path","edit_holdout.py","measure.py","round18-cargo/pgo/audit.json","round18-cargo/replica-test-quarantine-audit/STORAGE.md"))
    source=replay.read(old/"plan.json")["edit"]
    selected.add(work/"uv"/source)
    items={}
    for p in selected:
        replay.need(p.parent.resolve()==p.parent and p.is_file() and not p.is_symlink(),p)
        items["work/"+p.relative_to(work).as_posix()]=p.read_bytes()
    for name in ("pack.py","replay.py","detached.py","README.md","selftest.py"):
        items[name]=(HERE/name).read_bytes()
    items["scope.json"]=encoded({"kind":"registration","study":replay.NAME,"registration":replay.REG,
        "original_exclusion":replay.PRIOR_PACKET,"stock_proof":replay.SCAN,"prior_hardware_rows":0,
        "initial_packet":replay.INITIAL_PACKET,"subject_launch":False})
    return items


def verified_contents(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist()
        replay.need(len(names)==len(set(names)) and all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in names),"unsafe archive member")
        manifest=json.loads(z.read("manifest.json"))
        replay.need(set(names)==set(manifest)|{"manifest.json"},"bad subarchive membership")
        files={n:z.read(n) for n in manifest}
        for n,h in manifest.items():
            replay.need(hashlib.sha256(files[n]).hexdigest()==h,"published input "+n)
    return files


def outcome(work,archive,expected,session,chunk,rc):
    raw=archive.read_bytes()
    replay.need(hashlib.sha256(raw).hexdigest()==expected,"wrong published registration zip")
    items=verified_contents(raw)
    replay.need(json.loads(items["scope.json"])["kind"]=="registration","previous result supplied as a registration")
    for n in ("pack.py","replay.py","detached.py"):
        replay.need(items[n]==(HERE/n).read_bytes(),"published tool changed: "+n)
    project=work/"round18-cargo"
    study=project/replay.NAME
    rawdir=study/"results/replica/test"
    controls=study/"cells/replica-test"
    replay.need((controls/"validated.json").is_file(),"worker has no verified terminal return")
    # Confirm immutable premeasurement files match the exact published registration.
    for n,b in items.items():
        if n.startswith("work/"):
            p=work/Path(n).relative_to("work")
            replay.need(replay.sha(p)==hashlib.sha256(b).hexdigest(),"changed publication "+n)
    selected={p for d in (rawdir,controls) for p in d.rglob("*") if p.is_file()}
    authority=study/"control/authority.json"
    selected.update([authority,study/"grants/replica-test.json",work/replay.read(authority)["preceding_receipt"]])
    for p in selected:
        replay.need(p.is_file() and not p.is_symlink() and p.resolve()==p and p.is_relative_to(work),p)
        n="work/"+p.relative_to(work).as_posix()
        b=p.read_bytes()
        replay.need(n not in items or b==items[n],"overwrote a frozen input")
        items[n]=b
    cl=replay.read(controls/"closure.json")
    items.update({"published-registration.zip":raw,"outer-return.json":encoded({"session":session,"chunk":chunk,"exit_status":rc,
                  "closure_sha256":replay.sha(controls/"closure.json"),"worker_returncode":cl["worker_returncode"]}),
                  "scope.json":encoded({"kind":"outcome","study":replay.NAME,"registration":replay.REG,
                  "registration_packet_sha256":expected,"original_exclusion":replay.PRIOR_PACKET,"stock_proof":replay.SCAN}),
                  "result.json":encoded(replay.streams(work))})
    return items


def main():
    p=argparse.ArgumentParser()
    p.add_argument("kind",choices=("registration","outcome"));p.add_argument("--work",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True,help="new evidence output directory")
    p.add_argument("--registered-archive",type=Path);p.add_argument("--registered-sha256")
    p.add_argument("--session",type=int);p.add_argument("--chunk");p.add_argument("--exit-status",type=int)
    a=p.parse_args();work=a.work.resolve()
    if a.kind=="registration":
        replay.inputs(work)
        items=registration(work)
    else:
        replay.need(None not in (a.registered_archive,a.registered_sha256,a.session,a.chunk,a.exit_status),"missing actual return or published registration")
        items=outcome(work,a.registered_archive,a.registered_sha256,a.session,a.chunk,a.exit_status)
    raw=packed(items)
    replay.need(packed(dict(reversed(list(items.items()))))==raw,"nondeterministic archive")
    directory=a.output.resolve()
    directory.mkdir(parents=True,exist_ok=False)
    archive=directory/("ohm18-edited-test-form2-"+a.kind+".zip")
    with archive.open("xb") as f:f.write(raw)
    with tempfile.TemporaryDirectory(prefix="detached-",dir=directory) as temp:
        dest=Path(temp)
        with zipfile.ZipFile(archive) as z:z.extractall(dest)
        proc=subprocess.run([sys.executable,"-I","-B",str(dest/"detached.py")],cwd=dest,
                            env={"PATH":os.defpath,"LANG":"C"},capture_output=True,text=True)
        if proc.returncode:
            (directory/"replay-failure.log").write_text(proc.stderr+proc.stdout)
            raise RuntimeError("detached validation failed; kept exact failing packet")
        result=json.loads(proc.stdout)
    digest=hashlib.sha256(raw).hexdigest()
    (directory/"detached.json").write_bytes(encoded(result))
    (directory/"SHA256SUMS").write_text(f"{digest}  {archive.name}\n{replay.sha(directory/'detached.json')}  detached.json\n")
    receipt={"archive":archive.name,"sha256":digest,"bytes":len(raw),"files":len(items)+1,"replayed_sha256":replay.sha(directory/"detached.json"),
             "detached_exit":proc.returncode,"stable_across_opposite_insertion_order":True,"python":sys.version.split()[0],"registration":replay.REG}
    (directory/"bundle.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__=="__main__":
    main()
