"""Run the stdlib reader while denying release/fixture/workspace reads, processes and writes."""
import os
from pathlib import Path
import runpy
import sys
import sysconfig

ROOT=Path(__file__).resolve().parent
LIB=Path(sysconfig.get_path("stdlib")).resolve()


def guard(event,args):
    if event=="open":
        value,mode,flags=args
        if isinstance(value,int):
            raise PermissionError("inherited file descriptor read")
        path=Path(value).resolve()
        if not (path.is_relative_to(ROOT) or path.is_relative_to(LIB)):
            raise PermissionError("detached read outside extraction/stdlib: "+str(path))
        if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            raise PermissionError("read-only extraction")
    elif event in {"os.listdir","os.scandir"} and args and args[0] is not None:
        if isinstance(args[0],int):
            raise PermissionError("detached directory descriptor")
        p=Path(args[0]).resolve()
        if not (p.is_relative_to(ROOT) or p.is_relative_to(LIB)):
            raise PermissionError("detached directory read: "+str(p))
    elif event in {"subprocess.Popen","os.system","os.exec","os.posix_spawn","os.fork","socket.connect",
                   "os.remove","os.rename","os.mkdir","os.rmdir","os.chmod","os.link","os.symlink","os.truncate"}:
        raise PermissionError("forbidden detached operation: "+event)


if __name__=="__main__":
    if not sys.flags.isolated or not sys.dont_write_bytecode:
        raise SystemExit("use python3 -I -B detached.py")
    sys.addaudithook(guard)
    runpy.run_path(str(ROOT/"replay.py"),run_name="__main__")
