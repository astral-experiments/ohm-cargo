"""Prepare the one-time allocation **only** after the named coordinator grants this study."""
import argparse
import os
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--preceding-receipt",required=True,type=Path)
    p.add_argument("--preceding-sha256",required=True)
    p.add_argument("--coordinator-released",action="store_true",required=True)
    a=p.parse_args()
    assert os.geteuid()!=0 and Path("/proc/1/comm").read_text().strip()=="systemd"
    c.check_seal()
    receipt=a.preceding_receipt.resolve(strict=True)
    c.need(receipt.is_relative_to(c.WORK) and receipt.is_file() and not a.preceding_receipt.is_symlink() and
           c.sha(receipt)==a.preceding_sha256,"coordinator's return receipt and bytes differ")
    c.need(not (c.HERE/"control/authority.json").exists() and not (c.HERE/"grants/replica-test.json").exists(),
           "one-use allocation was already issued")
    c.need(all(p.is_file() for p in c.PAUSES+c.PEERS),"missing original or new pause")
    c.write_new(c.HERE/"control/authority.json",{"study":c.HERE.name,"only_cell":"replica-test",
                "preceding_receipt":str(receipt.relative_to(c.WORK)),"preceding_sha256":a.preceding_sha256,
                "registration":c.sha(c.HERE/"registration.json"),"coordinator_released":True,"issued_ns":time.time_ns(),
                "boot_id":Path("/proc/sys/kernel/random/boot_id").read_text().strip()})
    c.write_new(c.HERE/"grants/replica-test.json",c.grant("replica-test"))


if __name__=="__main__":
    main()
