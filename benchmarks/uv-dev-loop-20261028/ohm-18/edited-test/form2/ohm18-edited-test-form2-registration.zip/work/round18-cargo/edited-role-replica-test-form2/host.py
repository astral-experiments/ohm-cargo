"""Start exactly one frozen recovery worker, attest its live process/session and supervise free space."""
import argparse
import contextlib
import fcntl
import json
import os
import select
import shutil
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

CPU=set(range(8,16));GIB=2**30


def identity(p):
    s=p.lstat()
    c.need(stat.S_ISDIR(s.st_mode) and p.resolve()==p and s.st_uid==os.getuid(),p)
    return [s.st_dev,s.st_ino]


def cmdline(pid):
    return [x.decode(errors='surrogateescape') for x in (Path('/proc')/str(pid)/'cmdline').read_bytes().split(bytes(1)) if x]


def status(pid):
    obj={}
    for line in (Path('/proc')/str(pid)/'status').read_text().splitlines():
        key,_,value=line.partition(':');obj[key]=value.strip()
    return obj


def live(pid,argv):
    p=Path('/proc')/str(pid);st=status(pid);line=(p/'stat').read_text();after=line.rsplit(')',1)[1].split()
    c.need(st['State'].split()[0]!='Z' and list(map(int,st['Uid'].split()))==[os.getuid()]*4,'non-live or unexpected worker user')
    c.need(cmdline(pid)==argv and (p/'exe').resolve()==Path(sys.executable).resolve(),'unexpected live executable or argv')
    c.need(int(st['PPid'])==os.getpid() and os.getsid(pid)==pid and os.getpgid(pid)==pid and os.sched_getaffinity(pid)==CPU,'worker parent/session/affinity mismatch')
    return dict(pid=pid,ppid=os.getpid(),session=os.getsid(pid),group=os.getpgid(pid),start_ticks=int(after[19]),exe=str((p/'exe').resolve()),argv=argv,uid=os.getuid(),cpus=sorted(CPU))


def authenticate(admission,observed,cohort,ep,phase,not_before):
    c.need(admission.get('utc_ns',0)>=not_before,'observer is older than the newly launched worker')
    c.need((admission.get('pid'),admission.get('cohort'),admission.get('endpoint'),admission.get('state'),admission.get('boundary'))==
            (observed['pid'],cohort,ep,'paused',phase),'stale or mismatched paused observer')


def old_worker_or_tracker():
    found=[]
    for d in Path('/proc').glob('[0-9]*'):
        try:
            if d.stat().st_uid!=os.getuid():continue
            pid=int(d.name);a=cmdline(pid)
            if not a or status(pid)['State'].startswith('Z'):continue
            exe=(d/'exe').resolve()
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        word=' '.join(a)
        if any(Path(x).name=='recover.py' and 'edited-role-recovery/' in x for x in a) or (exe.name in ('drrun','drcachesim','drcachesim_launcher','cachegrind-amd64-linux') and any(k in word for k in ('ohm','role-studies','dynamorio'))):
            found.append(pid)
    return found


def take(lock,stack):
    c.need(not lock.is_symlink(),'unexpected lock symlink')
    f=stack.enter_context(lock.open('a'))
    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)


def session_tree(pid):
    family={pid};active=[pid]
    while active:
        cur=active.pop()
        for f in (Path('/proc')/str(cur)/'task').glob('*/children'):
            try:children=set(map(int,f.read_text().split()))
            except (FileNotFoundError,ProcessLookupError):continue
            active.extend(children-family);family.update(children)
    return family


def supervisor(name):
    cohort,ep=c.cell(name);reg=c.check_seal()
    c.need(os.getuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd','real non-root host required')
    c.need(os.sched_getaffinity(0)==CPU,'fixed 8–15 CPU set required')
    root=Path((c.WORK/'bench-home.path').read_text().strip())/'role-studies-18'/cohort
    out=c.STUDY/'results'/cohort/ep;ctl=c.HERE/'cells'/name
    given=c.HERE/'grants'/(name+'.json')
    c.need(given.is_file() and not given.is_symlink() and c.read(given)==c.grant(name),'fresh named grant required')
    prev=c.CELLS.index(name)
    if prev:
        prior_dir=c.HERE/'cells'/c.CELLS[prev-1]
        c.need(c.read(prior_dir/'validated.json')['closure_sha256']==c.sha(prior_dir/'closure.json'),'preceding terminal has not passed its custody audit')
        prior=c.read(prior_dir/'closure.json')
        c.need(prior['terminal'] in ['complete','excluded'] and prior['worker_exited'] and prior['source_restored'],'preceding cell/custody incomplete')
    eh=c.WORK/'round18-eh-release/command/control/pause'
    with contextlib.ExitStack() as stack:
        take(c.PROJECT/'edited-role-next/one-cell.lock',stack);take(root.parents[1]/'round18/native-lease',stack)
        c.need(eh.is_file() and not (c.LAB/'host-cleared-for-native').exists() and not old_worker_or_tracker(),'peer workload not parked or native lease requested')
        c.need(all(p.is_file() and not p.is_symlink() for p in c.PAUSES),'both original sentinels required before starting')
        saved={p:p.read_bytes() for p in c.PAUSES}
        marks={str(p.relative_to(c.WORK)):c.sha(p) for p in c.PAUSES}
        c.need(not ctl.exists() and not out.exists(),'attempt already allocated or result directory exists')
        c.need(not any(root.glob('rejected-form2-'+ep+'-*')),'existing quarantine requires separate owner review')
        for key in ('target','held-base','held-candidate','form2-recovery-homes-'+ep):c.need(not (root/key).exists(),key+' already occupied')
        r=c.read(c.STUDY/'registrations'/(name+'.json'));source=root/'source'/c.read(c.ORIGINAL/'plan.json')['edit']
        for rel,h in r['inputs'].items():c.need(c.sha(c.PROJECT/rel)==h,'mutated registered source/input '+rel)
        c.need(c.sha(source)==c.read(c.ORIGINAL/'plan.json')['original_sha256'],'unrestored private source')
        anchors={n:identity(root/n) for n in ['common','rejected-'+ep+'-structural','homes-'+ep]}
        c.need(anchors==reg['cells'][name]['protected_identities'],'structural bank or initial membership changed')
        free=lambda:shutil.disk_usage(root).free
        minimum=free();start_floor=max(150*GIB,c.FLOOR+2*r['structural']['file_size_sum']+3*GIB)
        c.need(minimum>start_floor,'insufficient actual preflight reserve')
        ctl.mkdir(parents=True)
        argv=[sys.executable,'-I','-B',str(c.STUDY/'recover.py'),'measure',cohort,ep,'--coordinator-released']
        fdout=stack.enter_context((ctl/'worker.log').open('xb'))
        spawn_ns=time.time_ns()
        worker=subprocess.Popen(argv,stdout=fdout,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
        def fail_closed():
            if worker.poll() is not None:return
            for p,data in saved.items():
                if not p.exists():
                    try:
                        with p.open('xb') as f:f.write(data)
                    except FileExistsError:pass
            try:os.killpg(worker.pid,signal.SIGSTOP)
            except ProcessLookupError:return
            for member in session_tree(worker.pid):
                try:os.kill(member,signal.SIGSTOP)
                except ProcessLookupError:pass
            if not (ctl/'guard-aborted.json').exists():
                c.write_new(ctl/'guard-aborted.json',dict(utc_ns=time.time_ns(),pid=worker.pid,group=worker.pid,parked=True,authority='explicit separate owner recovery required'))
        stack.callback(fail_closed)
        pidfd=os.pidfd_open(worker.pid);stack.callback(os.close,pidfd)
        start=None
        for _ in range(300):
            if worker.poll() is not None:break
            try:
                observed=live(worker.pid,argv);marker=c.read(c.STUDY/'control/status.json')
                authenticate(marker,observed,cohort,ep,'before validating inputs',spawn_ns);start=observed;break
            except (FileNotFoundError,ProcessLookupError,RuntimeError,json.JSONDecodeError):time.sleep(.1)
        if start is None:
            if worker.poll() is None:os.killpg(worker.pid,signal.SIGTERM)
            rc=worker.wait()
            c.write_new(ctl/'admission-failed.json',dict(exit_status=rc,pauses=marks,reason='exact live worker did not reach its unchanged pre-allocation boundary'))
            raise RuntimeError('worker admission failed with both pauses retained')
        c.write_new(ctl/'admitted.json',dict(cell=name,utc_ns=time.time_ns(),spawn_ns=spawn_ns,boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),accepted_worker_status=marker,guardian_pid=os.getpid(),guardian_start_ticks=(Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]),worker=start,initial_free_bytes=minimum,start_floor=start_floor,registered_predecessor_bytes=r['structural']['file_size_sum'],anchors=anchors,grant_sha256=c.sha(given),selected_grant=c.read(given),plan_sha256=c.sha(c.STUDY/'registrations'/(name+'.json')),pauses=marks))
        def restore():
            for p,data in saved.items():
                if not p.exists():
                    try:
                        with p.open('xb') as f:f.write(data)
                    except FileExistsError:pass
        banks={};soft=False;hard=False;last=None;polls=0
        try:
            for p in saved:p.unlink()
            while True:
                c.need(all(p.is_file() for p in c.PEERS),'original peer pause removed')
                available=free();minimum=min(minimum,available);polls+=1
                for arm in ('base','candidate'):
                    n='held-'+arm
                    try:device_inode=identity(root/n)
                    except FileNotFoundError:continue
                    c.need(banks.setdefault(n,device_inode)==device_inode,'borrowed or replaced target '+n)
                if available<130*GIB and not soft:restore();soft=True
                if available<124*GIB and not hard:
                    os.killpg(worker.pid,signal.SIGSTOP)
                    for pid in session_tree(worker.pid):
                        try:os.kill(pid,signal.SIGSTOP)
                        except ProcessLookupError:pass
                    hard=True;restore()
                    c.write_new(ctl/'hard-floor-stop.json',dict(utc_ns=time.time_ns(),free=available,live_worker=live(worker.pid,argv),reason='owned worker tree frozen above 120 GiB; explicit coordinator action required'))
                if soft and last!='parked':
                    try:mark=c.read(c.STUDY/'control/status.json')
                    except (OSError,json.JSONDecodeError):mark={}
                    if mark.get('pid')==worker.pid and mark.get('state')=='paused':
                        c.write_new(ctl/'disk-boundary.json',dict(marker=mark,free=available));last='parked'
                if select.select([pidfd],[],[],1)[0]:break
        finally:restore()
        rc=worker.wait();restored=c.read(out/'restore.json') if (out/'restore.json').is_file() else {}
        disposition='complete' if (out/'complete.json').is_file() and not (out/'rejected.json').exists() else 'excluded' if (out/'rejected.json').is_file() and not (out/'complete.json').exists() else 'guard failure'
        absent=all(not (root/n).exists() for n in ('target','held-base','held-candidate'))
        retained={p.name:identity(p) for p in root.glob('rejected-form2-'+ep+'-*') if p.is_dir()}
        postmarks={str(p.relative_to(c.WORK)):c.sha(p) for p in c.PAUSES}
        receipt=dict(cell=name,worker=start,worker_exited=True,worker_returncode=rc,issued_grant=c.sha(given),terminal=disposition,source_restored=restored.get('source_sha256')==c.sha(source)==c.read(c.ORIGINAL/'plan.json')['original_sha256'],target_vacant=absent and restored.get('target_vacant') is True,free_bytes=free(),minimum_free_bytes=minimum,guard_polls=polls,guard_soft=soft,guard_hard=hard,protected_anchors={n:identity(root/n) for n in anchors},observed_owned_banks=banks,preserved_excluded_banks=retained,pauses=postmarks,rows=len(c.table_rows(out/'samples.csv')),samples_sha256=c.sha(out/'samples.csv') if (out/'samples.csv').is_file() else None)
        c.write_new(ctl/'closure.json',receipt)
        c.need(disposition!='guard failure' and receipt['source_restored'] and receipt['target_vacant'] and postmarks==marks and receipt['protected_anchors']==anchors and restored.get('mutable_home_restored') is True and minimum>=c.FLOOR,'incomplete control closure')
        if disposition=='complete':
            c.need(rc==0 and sorted(banks)==['held-base','held-candidate'] and len({tuple(v) for v in banks.values()})==2 and not retained and receipt['rows']==16,'successful terminal custody differs')
        else:c.need(rc!=0,'unexpected zero status on failed admission/count')
        c.write_new(ctl/'validated.json',dict(closure_sha256=c.sha(ctl/'closure.json'),admission_sha256=c.sha(ctl/'admitted.json'),utc_ns=time.time_ns()))
        print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    c.need(sys.argv[1:]==['start','replica-test'],'run allocation.py with the coordinator-released receipt first')
    supervisor('replica-test')
