"""Score only the new replica; the excluded 91078 observation remains visible."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c


def verify_plan():
    from collections import Counter
    reg=c.check_seal()
    old=c.read(c.PROJECT/"edited-role-recovery/registrations/replica-test.json")
    new=c.read(c.HERE/"registrations/replica-test.json")
    role=reg["new_role"]
    orig=c.read(c.ORIGINAL/next(iter(old["original_admission_receipts"])))
    # Check that the stronger narrow ordinary-bin classifier matches precisely one
    # actual released compiler and linker in the untouched original admission.
    all_roles=orig["roster"]["records"]
    argvs=[json.loads(raw) for k,raw in all_roles if k=="rustc"]
    matched=[a for a in argvs if any(x.endswith("/"+role+".rlink") for x in a)]
    c.need(len(matched)==1,"ambiguous or missing regular-bin rlink")
    a=matched[0]
    c.need(a.count("--crate-name")==1 and a[a.index("--crate-name")+1]=="uv" and "--test" not in a and
           a.count("--crate-type")==1 and a[a.index("--crate-type")+1]=="bin" and
           a.count("link-only")==1 and a[a.index("link-only")-1]=="-Z","wrong ordinary-bin role")
    c.need(sum(k=="wild" and json.loads(raw).endswith("/"+role) for k,raw in all_roles)==1,"wrong linker output")
    c.need(orig["roster"]["role_counts"]=={"cargo":1,"rustc":6,"wild":5} and len(orig["roster"]["tests"])==72,"old roster changed")
    c.need(set(old["permits"])==set(new["permits"])-{role} and len(new["permits"])==3,"unregistered expansion")
    cfg=new["schedule"]
    c.need(len(cfg["pairs"])==len({p["id"] for p in cfg["pairs"]})==8 and
           Counter(x["order"][0] for x in cfg["pairs"])=={"base":4,"candidate":4},"unbalanced or repeated edits")
    c.need(len(cfg["native_count_admission"])==4 and len(set(tuple(x) for x in cfg["native_count_admission"]))==4,"incomplete four cells")
    return {"study":c.HERE.name,"registration":c.sha(c.HERE/"registration.json"),"frozen_prior_gate":None,
            "frozen_prior_scored_rows":0,"new_permitted_role":role,"total_explicit_roles":3,
            "registered_pairs":8,"new_hardware_samples":False,"admission_roster":orig["roster"]["role_counts"],
            "test_executables":72,"grant_present":(c.HERE/"control/authority.json").exists()}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--plan-only",action="store_true")
    a=p.parse_args()
    result=verify_plan()
    if not a.plan_only:
        import score
        cell=c.HERE/"cells/replica-test"
        closure=c.read(cell/"closure.json")
        c.need(c.read(cell/"validated.json")["closure_sha256"]==c.sha(cell/"closure.json") and
               closure["terminal"] in ("complete","excluded") and closure["source_restored"] and
               closure["target_vacant"] and closure["worker_exited"],"unclosed study")
        r=score.inspect("replica","test")
        if closure["terminal"]=="complete":
            c.need(r["state"]=="complete" and closure["rows"]==16,"missing complete comparison")
        else:
            c.need(r["state"]=="rejected" and "gate_passed" not in r,"rejection scored")
        result.update(new_hardware_samples=closure["rows"]>0,scored_arms=closure["rows"],result=r,
                      initial_test_gate="unchanged historical cohort",closure_sha256=c.sha(cell/"closure.json"))
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
