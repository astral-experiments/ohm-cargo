"""Derive one isolated successor from the previously frozen worker and guardian. No fixture access."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c

HERE=c.HERE
ORIG=c.PROJECT/"edited-role-recovery"
NEXT=c.PROJECT/"edited-role-next"
AUDIT=c.PROJECT/"replica-test-quarantine-audit"
STOCK_SHA="86d0beb82377dfb476327dcc55703136b7383f89d9ac6dae4f891777a09b3ba0"
EXCLUDED="7ce6d653e7e21d5bd36d7498d048a5d787d3bee09d760fa105f3b3af9dc1eea1"
ROLE="debug/build/uv/e6ac92541876a4a1/out/uv"


def put(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    if isinstance(data,str):
        data=data.encode()
    if p.is_file():
        assert p.read_bytes()==data,p
    else:
        with p.open("xb") as f:f.write(data)


def keep(p,data):
    put(p,json.dumps(data,indent=2,sort_keys=True)+"\n")


def replace(text,src,dst,count=1):
    assert text.count(src)==count,src
    return text.replace(src,dst)


def main():
    assert not (HERE/"control/authority.json").exists() and not (HERE/"results").exists()
    for p in ["control","registrations","grants"]:(HERE/p).mkdir(exist_ok=True)
    old_reg=c.read(ORIG/"registrations/replica-test.json")
    next_reg=c.read(NEXT/"registration.json")
    assert c.sha(ORIG/"registrations/replica-test.json")==next_reg["cells"]["replica-test"]["registration"]
    assert c.sha(NEXT/"registration.json")==(NEXT/"registration.sha256").read_text().split()[0]
    assert c.sha(NEXT/"host.py")==next_reg["code"]["host.py"]
    assert c.sha(ORIG/"recover.py")==old_reg["inputs"]["edited-role-recovery/recover.py"]
    assert c.sha(AUDIT/"stock-comparison.json")==STOCK_SHA
    assert c.sha(NEXT/"cells/replica-test/closure.json")==EXCLUDED
    evidence=c.read(AUDIT/"stock-comparison.json")
    assert evidence["historical_scored_rows"]==0 and evidence["historical_gate"] is None
    assert evidence["role"]==ROLE and evidence["different_bytes"]==33 and evidence["different_outside_mask"]==0
    assert evidence["identical_after_proved_40_byte_mask"] and evidence["per_elf_scan_bytes"]==316713312
    forms={}
    for rec in evidence["files"].values():
        f=rec["metadata"]["fields"]
        assert f["gnu_build_id"][:2]==[896,928] and f["rodata_sh_entsize"][:2]==[316711384,316711392]
        value=int.from_bytes(bytes.fromhex(f["rodata_sh_entsize"][2]),"little")
        assert value in (0,8) and str(value) not in forms
        forms[str(value)]={"sha256":rec["actual_raw_sha256"],"gnu_build_id":f["gnu_build_id"][2]}
    assert set(forms)=={"0","8"} and forms["0"]["sha256"]==evidence["ordinary_reference_baseline_raw_sha256"]
    rule={"name":"uv","test":False,"qualification":STOCK_SHA,
          "proof":{"bytes":316713312,"actual_sha256":forms["0"]["sha256"],"actual_entsize":0,
                   "rodata_entsize_offset":316711384,"gnu_build_id_start":896,"gnu_build_id_end":928,"forms":forms}}
    keep(HERE/"normal-uv-stock.json",{"role":ROLE,"rule":rule,"provenance":STOCK_SHA})
    src=(ORIG/"recover.py").read_text()
    src=replace(src,"    assert len(result)==2\n    return result",
                "    assert (cohort,ep)==('replica','test') and len(result)==2\n"
                "    extra=read(here/'normal-uv-stock.json');assert extra['role'] not in result\n"
                "    result[extra['role']]=extra['rule']\n    return result")
    src=replace(src,"    if any(f.exists() for f in [old/'control/pause',folder/'pause']):",
                "    pauses=[folder/'supervisor.pause',folder/'pause']\n"
                "    assert (old/'control/pause').is_file() and (here.parent/'edited-role-recovery/control/pause').is_file()\n"
                "    if any(f.exists() for f in pauses):")
    src=replace(src,"        while any(f.exists() for f in [old/'control/pause',folder/'pause']):",
                "        while any(f.exists() for f in pauses):")
    src=replace(src,"state=root/('recovery-homes-'+ep)","state=root/('form2-recovery-homes-'+ep)")
    src=replace(src,"f'rejected-recovery-{ep}-{name}'","f'rejected-form2-{ep}-{name}'")
    marker="        else:\n            assert ep=='test' and any(r['role']=='rustc'"
    src=replace(src,marker,
                "            if not rule['test'] and ep=='test':\n"
                "                assert key==read(here/'normal-uv-stock.json')['role'] and a.count('--crate-type')==1 and a[a.index('--crate-type')+1]=='bin'\n"
                "                assert a.count('link-only')==1 and a[a.index('link-only')-1]=='-Z'\n"+marker)
    start="    try:\n        boundary(cohort,ep,'before four admissions')"
    src=replace(src,start,
                "    saved_home=state/'before-study';assert not saved_home.exists()\n"
                "    run.copy_home_state(home,saved_home);home_before=home_files(saved_home)\n"+start)
    src=replace(src,"        write(out/'restore.json',dict(source_sha256=sha(src),target_vacant=not target.exists()))",
                "        run.copy_home_state(saved_home,home)\n"
                "        verify_home=state/'returned-study';run.copy_home_state(home,verify_home);assert home_files(verify_home)==home_before\n"
                "        write(out/'restore.json',dict(source_sha256=sha(src),target_vacant=not target.exists(),mutable_home_restored=True))")
    _,main_at=src.split("if __name__=='__main__':")
    src=src[:-len(main_at)] + """
    assert sys.argv[1:]==['measure','replica','test','--coordinator-released']
    parent=Path('/proc')/str(os.getppid())
    pa=[v.decode() for v in (parent/'cmdline').read_bytes().split(bytes(1)) if v]
    assert pa[1:]==['-I','-B',str(here/'host.py'),'start','replica-test']
    assert (parent/'exe').resolve()==Path(sys.executable).resolve()
    study('replica','test')
"""
    put(HERE/"recover.py",src)
    put(HERE/"score.py",(ORIG/"score.py").read_bytes())
    host=(NEXT/"host.py").read_text()
    host=replace(host,"take(c.HERE/'one-cell.lock',stack)","take(c.PROJECT/'edited-role-next/one-cell.lock',stack)")
    host=replace(host,"'rejected-recovery-'+ep+'-*'","'rejected-form2-'+ep+'-*'",2)
    host=replace(host,"'recovery-homes-'+ep","'form2-recovery-homes-'+ep")
    host=replace(host,"                available=free();minimum=min(minimum,available);polls+=1",
                 "                c.need(all(p.is_file() for p in c.PEERS),'original peer pause removed')\n"
                 "                available=free();minimum=min(minimum,available);polls+=1")
    host=replace(host,"and minimum>=c.FLOOR,'incomplete control closure'","and restored.get('mutable_home_restored') is True and minimum>=c.FLOOR,'incomplete control closure'")
    prefix,main_at=host.split("if __name__=='__main__':")
    host=prefix+"""if __name__=='__main__':
    c.need(sys.argv[1:]==['start','replica-test'],'run allocation.py with the coordinator-released receipt first')
    supervisor('replica-test')
"""
    put(HERE/"host.py",host)
    reg=dict(old_reg)
    reg["supersedes_only"]="excluded 91078 / 296d24 / 0, actual worker 1, before treatment or scored rows"
    reg["permits"]={**old_reg["permits"],ROLE:rule}
    add=[HERE/n for n in ("recover.py","score.py","normal-uv-stock.json")]
    add.extend((AUDIT/"stock-comparison.json",AUDIT/"compare_stock.py"))
    reg["inputs"]={**old_reg["inputs"],**{str(p.relative_to(c.PROJECT)):c.sha(p) for p in add}}
    keep(HERE/"registrations/replica-test.json",reg)
    for p in c.PAUSES:put(p,"Separate replica-test normal uv proof. Require the fresh named coordinator grant.\n")
    anchored=[HERE/n for n in ("freeze.py","common.py","allocation.py","recover.py","host.py","score.py",
                              "normal-uv-stock.json","registrations/replica-test.json","README.md","score_result.py")]
    anchored += [ORIG/"registrations/replica-test.json",ORIG/"recover.py",ORIG/"score.py",
                 NEXT/"host.py",NEXT/"registration.json",NEXT/"cells/replica-test/closure.json",
                 NEXT/"cells/replica-test/validated.json",NEXT/"packets/replica-test/bundle.json",
                 AUDIT/"compare_stock.py",AUDIT/"stock-comparison.json"]
    outer={"study":HERE.name,"endpoint":"replica/test","new_role":ROLE,"old_exclusion":EXCLUDED,
           "statistic":"unmodified original score.py and summary.py; 8 balanced pairs; exact p < .05 and balanced p < .05, positive median",
           "normal_rule":"Complete raw equality or the two whole valid per-literal BLAKE3/Wild ELF forms; exact original admission forms are mandatory",
           "cells":{"replica-test":{**next_reg["cells"]["replica-test"],"registration":c.sha(HERE/"registrations/replica-test.json")}},
           "peer_pause_sha256":{str(p.relative_to(c.PROJECT)):c.sha(p) for p in c.PEERS},
           "frozen":{str(p.relative_to(c.PROJECT)):c.sha(p) for p in anchored}}
    keep(HERE/"registration.json",outer)
    put(HERE/"registration.sha256",c.sha(HERE/"registration.json")+"  registration.json\n")
    print(c.sha(HERE/"registration.json"))


if __name__=="__main__":
    main()
