"""Portable, single-cohort replay for complete, statistically null, or terminally excluded cells."""
import csv
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ARMS=('base','candidate')


def need(ok,why):
    if not ok:raise ValueError(why)


def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read(p):return json.loads(p.read_text())


def public_outcome(result):
    if result['state']=='complete':
        need(type(result.get('gate_passed')) is bool and result['n_pairs']==8,'complete packet requires the fixed eight pairs and exact gate')
        return {'disposition':'passes primary/replica threshold' if result['gate_passed'] else 'inconclusive under registered gate','gate':result['gate_passed'],'state':'complete'}
    need(result['state']=='rejected' and 'reason' in result,'nonterminal results have no packet')
    return {'disposition':'excluded; no statistical estimate','gate':None,'state':'rejected'}


def prefix(rows,reg):
    pairs=reg['schedule']['pairs'];edits={x['id']:x['sha256'] for x in reg['schedule']['edits']}
    need(len(pairs)==8 and len(rows)<=16,'invalid sample budget')
    for ix,row in enumerate(rows):
        i,j=divmod(ix,2);p=pairs[i];arm=p['order'][j]
        need((row['arm'],int(row['pair']),int(row['id']),int(row['position']),row['receipt'],row['source_sha256'])==(arm,i,p['id'],j,f'pair-{i}-{j}-{arm}/receipt.json',edits[p['id']]),'not the registered contiguous sample prefix')


def qualification(project,original,reg):
    cal=project/'role-elf-calibration';cohort=reg['cohort'];ep=reg['endpoint']
    for artifact,rule in reg['permits'].items():
        if ep=='build':
            folder=cal/cohort;q=read(folder/'qualified.json');source=cal/'registration.json'
            data=read(folder/'reconstruction.json')
            need(q['reconstruction_sha256']==digest(folder/'reconstruction.json'),'build reconstruction hash')
        else:
            folder=cal/('test-'+cohort)/rule['name'];q=read(folder/'qualified.json');source=folder.parent/'registration.json'
            cfg=read(source)
            need(cfg['original_rejection_sha256']==digest(original/'results'/cohort/'test/rejected.json'),'test calibration ancestor')
            item=cfg['roles'][rule['name']];need(item['role']==artifact,'test artifact name');data=item['reconstruction']
        need(q['cohort']==cohort and q['endpoint']==ep and q['artifact']==artifact and q['registration_sha256']==digest(source),'wrong scalar ELF scope')
        need(digest(folder/'qualified.json')==rule['qualification'] and data==rule['proof'] and q['whole_file_sha256s']==sorted(x['sha256'] for x in data['forms'].values()),'ELF forms')
        need(q['controls']['release-source']==read(original/'sealed.json')['arms']['base']['wild'] and set(q['controls'])=={'distributed','release-source'},'stock controls')


def score_cell(project,name):
    cohort,ep=name.split('-');original=project/'edited-roles';recovery=project/'edited-role-recovery';reg=read(recovery/'registrations'/(name+'.json'))
    out=recovery/'results'/cohort/ep
    for k,p in reg['inputs'].items():need(digest(project/k)==p,'original registered input '+k)
    for k,p in reg['original_admission_receipts'].items():need(digest(original/k)==p,'original excluded control '+k)
    original_plan=read(original/'plan.json')
    need(digest(original/'plan.json')==(original/'registered.sha256').read_text().split()[0] and reg['schedule']==original_plan['schedule'][cohort][ep],'original plan/schedule')
    qualification(project,original,reg)
    sys.path.insert(0,str(recovery));import score
    result=score.inspect(cohort,ep);public=public_outcome(result)
    rows=list(csv.DictReader((out/'samples.csv').open())) if (out/'samples.csv').is_file() else []
    prefix(rows,reg)
    admissions=[f'admit-{i}-{m}-{a}' for i,(m,a) in enumerate(reg['schedule']['native_count_admission'])]
    adirs={p.name for p in out.glob('admit-*') if p.is_dir()}
    need(adirs==set(admissions[:len(adirs)]) and (not rows or len(adirs)==4),'invalid admission prefix')
    pairs=[f'pair-{i}-{j}-{arm}' for i,p in enumerate(reg['schedule']['pairs']) for j,arm in enumerate(p['order'])]
    dirs={p.name for p in out.glob('pair-*') if p.is_dir()}
    need(len(rows)<=len(dirs)<=len(rows)+1 and dirs==set(pairs[:len(dirs)]),'unscored future arm or missing raw stream')
    readbacks=[]
    if public['gate'] is None:
        for row in rows:
            directory=out/Path(row['receipt']).parent
            rec=score.summary.audit_run(directory,row,'count')
            need(rec['source_sha256']==row['source_sha256'] and rec['roster']==read(out/'admission.json'),'writing a row without workload admission')
        for log in sorted([*out.glob('admit-*'),*out.glob('pair-*')]):
            if not (log/'receipt.json').is_file():readbacks.append(dict(directory=log.name,complete_receipt=False));continue
            mode='native' if '-native-' in log.name else 'count'
            try:score.summary.audit_run(log,None,mode);error=None
            except (KeyError,ValueError,RuntimeError,AssertionError) as exc:error=f'{type(exc).__name__}: {exc}'
            readbacks.append(dict(directory=log.name,complete_receipt=True,internal_raw_audit_error=error))
    return dict(cell=name,scope='One held-out cohort of the wrapper-assisted Cargo + all invoked rustc + Wild role sum. GCC/collect2, observers, kernel, and pre-exec work are outside the metric.',public=public,scored_estimate=result if public['gate'] is not None else None,exclusion=result.get('reason'),recorded_arms=len(rows),partial_or_excluded_readbacks=readbacks)


def validate():
    manifest=read(HERE/'manifest.json')
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}-{'manifest.json'}
    need(actual==set(manifest),'file membership differs')
    for name,h in manifest.items():
        p=HERE/name
        need(not p.is_symlink() and p.resolve().is_relative_to(HERE) and digest(p)==h,name)
    meta=read(HERE/'scope.json');name=meta['cell'];cohort,ep=name.split('-');project=HERE/'round18-cargo'
    result=score_cell(project,name)
    need(json.loads(json.dumps(result))==read(HERE/'result.json'),'independent raw replay differs')
    custody=HERE/'custody';cl=read(custody/'closure.json');valid=read(custody/'validated.json');ad=read(custody/'admitted.json')
    need(valid['closure_sha256']==digest(custody/'closure.json') and valid['admission_sha256']==digest(custody/'admitted.json'),'custody verification')
    need(ad['cell']==cl['cell']==name and ad['worker']==cl['worker'] and cl['worker_exited'] and cl['source_restored'] and cl['target_vacant'] and cl['pauses']==ad['pauses'],'worker identity and return')
    need(cl['minimum_free_bytes']>=120*2**30 and cl['protected_anchors']==ad['anchors'] and cl['rows']==result['recorded_arms'],'disk reserve, seeds, and row count')
    control=HERE/'control';reg=read(control/'registration.json');g=read(custody/'coordinator-grant.json')
    need(digest(control/'registration.json')==(control/'registration.sha256').read_text().split()[0]==g['next_registration_sha256'],'future harness registration')
    for file,h in reg['code'].items():need(digest(control/file)==h,'mutable external control '+file)
    need(digest(custody/'coordinator-grant.json')==ad['grant_sha256']==cl['issued_grant'] and ad['selected_grant']==g and g['only_cell']==name,'individual release mismatch')
    need(digest(custody/'native-return.json')==g['prior_native_return']==reg['native_return'] and digest(custody/'original-first-cell-return.json')==reg['initial_build_return'],'prior custody mismatch')
    need(digest(custody/'eh-return.json')==g['eh_return_sha256'] and read(custody/'eh-return.json')['custody_returned'] is True,'EH custody return')
    r=project/'edited-role-recovery'/'registrations'/(name+'.json')
    need(reg['cells'][name]['registration']==ad['plan_sha256']==g['original_registration_sha256']==digest(r),'old cell registration mismatch')
    live=ad['worker'];mark=ad['accepted_worker_status']
    need(live['pid']==live['session']==live['group']==mark['pid'] and live['ppid']==ad['guardian_pid'] and live['cpus']==g['real_host_cpus'] and mark['utc_ns']>=ad['spawn_ns'] and (mark['cohort'],mark['endpoint'],mark['state'],mark['boundary'])==(cohort,ep,'paused','before validating inputs'),'stale observer or worker identity')
    t=project/'edited-role-recovery'/'results'/cohort/ep/'samples.csv'
    need(cl['samples_sha256']==(digest(t) if t.is_file() else None),'terminal row-table digest')
    need((cl['terminal']=='complete')==(result['public']['gate'] is not None),'scorer/collector disposition disagreement')
    need(cl['terminal'] in ('complete','excluded') and (cl['worker_returncode']==0)==(cl['terminal']=='complete'),'invalid process exit')
    return result


if __name__=='__main__':
    r=validate();o=r['scored_estimate']
    print(json.dumps(dict(cell=r['cell'],**r['public'],recorded_arms=r['recorded_arms'],metrics={k:o[k] for k in ('n_pairs','wins','losses','median_paired_reduction','rank_interval_99_21875','two_sided_sign_p','balanced_order_randomization_p','roster')} if o is not None else None),indent=2))
