"""Exercise the frozen new predicates with stored records, without opening a fixture or ELF."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import common as c
from score_result import verify_plan


def compiled(node,env):
    ast.fix_missing_locations(node)
    exec(compile(ast.Module(body=[node],type_ignores=[]),"<sealed function>","exec"),env)
    return env[node.name]


def main():
    out=verify_plan()
    reg=c.read(c.HERE/"registrations/replica-test.json")
    stock=c.read(c.HERE/"normal-uv-stock.json");key=stock["role"];rule=stock["rule"]
    rec=c.read(c.ORIGINAL/next(iter(reg["original_admission_receipts"])))
    argv=next(json.loads(s) for k,s in rec["roster"]["records"] if k=="rustc" and "/"+key+".rlink" in s)
    product=Path(next(x for x in argv if x.endswith("/"+key+".rlink"))[:-6])
    target=product.parents[len(Path(key).parts)-1]
    assert target/key==product
    raw=rule["proof"]["actual_sha256"]
    def base(*unused):
        return {key:{"permitted_fields":None,"sha256":raw,"size":rule["proof"]["bytes"]}}
    def origin(*unused):
        return copy.deepcopy(rule["proof"])
    tree=ast.parse((c.HERE/"recover.py").read_bytes())
    env={"here":c.HERE,"read":c.read,"forms":origin}
    oracle=compiled(next(f for f in tree.body if isinstance(f,ast.FunctionDef) and f.name=="oracle"),env)
    def output(a):
        return oracle("test",[{"role":"wild","key":str(product)},{"role":"rustc","argv":a}],target,{key:rule},base)
    good=output(argv)
    def rejects(fn):
        try:fn()
        except (AssertionError,ValueError):return
        raise RuntimeError("unexpectedly accepted synthetic corruption")
    rejects(lambda:output(argv+["--test"]))
    rejects(lambda:output(["rlib" if x=="bin" else x for x in argv]))
    idx=argv.index("link-only")
    rejects(lambda:output(argv[:idx-1]+["--cfg"]+argv[idx:]))
    rejects(lambda:output(["uvx" if x=="uv" else x for x in argv]))
    proof=copy.deepcopy(rule["proof"]);proof["rodata_entsize_offset"]+=1
    env["forms"]=lambda unused:proof
    rejects(lambda:output(argv))
    scope={"run":SimpleNamespace(match=lambda a,b:None)}
    study=next(f for f in tree.body if isinstance(f,ast.FunctionDef) and f.name=="study")
    pair=compiled(next(f for f in study.body if isinstance(f,ast.FunctionDef) and f.name=="compare"),scope)
    x={"files":good};y=copy.deepcopy(x)
    pair(x,y)
    y["files"][key]["permitted_fields"]["forms"]["8"]["sha256"]="a"*64
    rejects(lambda:pair(x,y))
    out.update(frozen_worker_sha256=c.sha(c.HERE/"recover.py"),checks={
        "stored_ordinary_compiler_and_wild_roles":True,"synthetic_harness_rejected":True,
        "synthetic_non_bin_rejected":True,"synthetic_wrong_crate_rejected":True,
        "synthetic_non_unstable_link_only_rejected":True,"synthetic_shifted_elf_header_rejected":True,
        "paired_entire_file_form_disagreement_rejected":True},
        limits="Uses sealed role and pair predicates with synthetic ELF receipts. The original production BLAKE3 decoder is unchanged. No ELF read, process launch, counter or fixture allocation.")
    print(json.dumps(out,indent=2))


if __name__=="__main__":
    main()
