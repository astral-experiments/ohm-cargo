#!/usr/bin/env python3
"""Sequential controller. Each endpoint and independent repeat can qualify separately."""
import json
from pathlib import Path
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
def run(*args):
    return subprocess.run([sys.executable,"-B",str(here/"run.py"),*args]).returncode
def need(ok,reason):
    if not ok:raise SystemExit(reason)

def main():
    need((here/"sealed.json").is_file(),"seal the subjects and harness first")
    for cohort in ("initial","replica"):need(run("warm",cohort)==0,f"{cohort} pristine preparation failed")
    if not (here/"calibration/PASS.json").is_file():need(run("calibrate")==0,"calibration failed")
    for ep in ("check","build","test"):
        for cohort in ("initial","replica"):
            d=here/"results"/cohort/ep
            if (d/"complete.json").exists() or (d/"rejected.json").exists():continue
            ret=run("study",cohort,ep)
            need(ret==0 or (d/"rejected.json").exists(),f"{cohort} {ep} failed without a preserved exclusion")
            subprocess.run([sys.executable,"-B",str(here/"summary.py")],check=True)
            print("Finished",cohort,ep,"with status",ret,flush=True)
    (here/"control/status.json").write_text(json.dumps({"state":"finished","utc_unix_ns":time.time_ns()})+"\n")

if __name__=="__main__":main()
