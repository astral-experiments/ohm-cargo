"""Freeze and run role-specific controls for the two rustc --test binary re-link outputs."""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here))
from stock_replay import bench,controls,paused,sha,suite,work,write
from recover_forms import forms

roles={'uv':(3,'aae246decf32691311d16083e5e2527ab757349c33a5f91eca57deedb5c4760c'),
       'uvx':(2,'ef0e705d848a218d36901eea0c8ba9610bc92b62b7cb099e5675aa158d41b834')}


def register(cohort,out,root,old):
    assert not (out/'registration.json').exists() and (old/'rejected.json').is_file() and not (old/'samples.csv').exists()
    receipts=[json.loads(f.read_text()) for f in sorted(old.glob('admit-*/receipt.json'))]
    assert len(receipts)>=2 and all(r['roster']==receipts[0]['roster'] for r in receipts)
    native=next(p for p in sorted(old.glob('admit-*-native-*')) if (p/'receipt.json').exists())
    wilds=[json.loads(p.read_text()) for p in native.glob('wild-*.json')]
    chosen={};all_sums={k:{r['files'][k]['sha256'] for r in receipts} for k in receipts[0]['files']}
    for p in native.glob('rustc-*.json'):
        a=json.loads(p.read_text())['argv']
        if '--test' not in a or 'link-only' not in a:continue
        name=a[a.index('--crate-name')+1]
        assert name in roles and name not in chosen
        matches=[q for q in wilds if Path(q['key']).parent==Path(a[a.index('--out-dir')+1])]
        assert len(matches)==1;r=matches[0];file=Path(r['key']).relative_to(root/'target');role=str(file)
        assert re.fullmatch(r'debug/build/uv/([0-9a-f]{16})/out/'+name+r'-\1',role)
        assert any(x==str(root/'target'/(role+'.rlink')) for x in a)
        proof=forms(root/'rejected-test-target'/file);possible={x['sha256'] for x in proof['forms'].values()}
        assert len(possible)==2 and all_sums[role]<=possible
        cap,symbol_sha=roles[name];symbols=next((work/'round18-linker/captures18'/str(cap)).rglob('symbols.o'))
        assert sha(symbols)==symbol_sha
        chosen[name]=dict(role=role,original_full_sha256=sorted(all_sums[role]),reconstruction=proof,
                          native_argv=r['argv'],capture_symbols=str(symbols),capture_symbols_sha256=sha(symbols),rustc_argv=a)
    assert set(chosen)==set(roles)
    other=[name for name in all_sums if name not in {v['role'] for v in chosen.values()}]
    assert all(len({r['files'][name]['canonical_sha256'] for r in receipts})==1 for name in other), 'another originally unaccepted output requires independent review'
    paths=[here/n for n in ('test_controls.py','recover_forms.py','blake-stream','stock_replay.py','PROTOCOL.md')]
    write(out/'registration.json',dict(cohort=cohort,endpoint='test',created_ns=__import__('time').time_ns(),
          original_rejection_sha256=sha(old/'rejected.json'),roles=chosen,scripts={p.name:sha(p) for p in paths},
          cpus=list(range(24,32)),tokens=[0,7,1,3,3,1,7,0]*2,
          gate='For each frozen binary unit-test role, both unchanged linkers independently reproduce both exact full SHA candidates. All earlier raw controls match a form. Stop the first third hash or incomplete finite roster; retain original exclusions.'))


def run_controls(cohort,out,root):
    cfg=json.loads((out/'registration.json').read_text())
    assert all(sha(here/k)==v for k,v in cfg['scripts'].items()) and sorted(os.sched_getaffinity(0))==cfg['cpus']
    for role,item in cfg['roles'].items():
        rw=out/role;rw.mkdir(exist_ok=True)
        temp=bench/'role-elf-calibration'/('test-'+cohort)/role;temp.mkdir(parents=True,exist_ok=True)
        product=temp/'linked';empty=temp/'empty';empty.mkdir(exist_ok=True);assert not list(empty.iterdir())
        sym=Path(item['capture_symbols']);assert sha(sym)==item['capture_symbols_sha256']
        proof=item['reconstruction'];expected={x['sha256'] for x in proof['forms'].values()};mapped=[]
        for i,x in enumerate(item['native_argv']):
            value=x.replace(str(root/'target')+'/',str(root/'rejected-test-target')+'/')
            if i and item['native_argv'][i-1]=='-o':value=str(product)
            elif x.endswith('/symbols.o') and not Path(value).exists():value=str(sym)
            elif x.startswith('-plugin-opt=-fresolution='):value='-plugin-opt=-fresolution='+str(temp/'res')
            elif x.startswith('-L') and x.endswith('/raw-dylibs'):value='-L'+str(empty)
            elif x.startswith('/'):assert Path(value).is_file(),value
            mapped.append(value)
        assert mapped.count(str(sym))==1 and mapped.count('--no-fork')==1
        write(rw/'argv.json',dict(original=item['native_argv'],replay=mapped))
        for which,(exe,identity) in controls.items():
            assert sha(exe)==identity;seen=set()
            for i,n in enumerate(cfg['tokens']):
                receipt=rw/f'{which}-{i:02}.json'
                if receipt.exists():record=json.loads(receipt.read_text())
                else:
                    if paused():print('Stopped at a stock A/A boundary.',flush=True);return
                    rd,wr=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
                    try:
                        if n:os.write(wr,b'+'*n)
                        mf=f'-j --jobserver-auth={rd},{wr}';env=dict(os.environ,CARGO_MAKEFLAGS=mf,MAKEFLAGS=mf,LC_ALL='C');product.unlink(missing_ok=True)
                        with (rw/f'{which}-{i:02}.log').open('xb') as log:
                            rc=subprocess.run([str(exe),*mapped],env=env,cwd=temp,pass_fds=(rd,wr),stdout=log,stderr=subprocess.STDOUT).returncode
                        os.close(wr);wr=None
                        record=dict(tokens=n,tokens_back=len(os.read(rd,512)),returncode=rc,control=identity,full_sha256=sha(product) if rc==0 else None)
                        write(receipt,record)
                    finally:
                        os.close(rd)
                        if wr is not None:os.close(wr)
                assert record['tokens']==record['tokens_back']==n and record['returncode']==0 and record['control']==identity and record['full_sha256'] in expected,record
                seen.add(record['full_sha256'])
                if seen==expected:break
            assert seen==expected,f'{cohort}/{role}/{which} did not reproduce both exact forms'
        write(rw/'qualified.json',dict(artifact=item['role'],cohort=cohort,endpoint='test',whole_file_sha256s=sorted(expected),
              controls={k:v[1] for k,v in controls.items()},registration_sha256=sha(out/'registration.json')))
    print(f'{cohort} both binary unit-test A/A validations passed.',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['register','run']);p.add_argument('cohort',choices=['initial','replica']);a=p.parse_args()
    out=here/('test-'+a.cohort);out.mkdir(exist_ok=True);root=bench/'role-studies-18'/a.cohort
    if a.phase=='register':register(a.cohort,out,root,suite/'edited-roles/results'/a.cohort/'test')
    else:run_controls(a.cohort,out,root)
