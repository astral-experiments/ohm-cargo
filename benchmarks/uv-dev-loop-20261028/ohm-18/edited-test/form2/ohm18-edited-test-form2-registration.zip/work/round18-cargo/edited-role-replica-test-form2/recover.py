"""Resume exactly at a verified structural predecessor with a stronger, role-specific ELF oracle."""
import argparse
import copy
import csv
import hashlib
import json
import os
import shutil
import sys
import time
import traceback
from pathlib import Path

here=Path(__file__).resolve().parent
old=here.parent/'edited-roles';cal=here.parent/'role-elf-calibration'
sys.path[:0]=[str(old),str(cal)]
import run
from recover_forms import forms


def write(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
def read(path):return json.loads(path.read_text())
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def home_files(directory):
    assert directory.is_dir() and not (directory/'registry').exists()
    return {str(f.relative_to(directory)):sha(f) for f in sorted(directory.rglob('*')) if f.is_file()}


def boundary(cohort,ep,description):
    folder=here/'control';folder.mkdir(exist_ok=True)
    def status(value):
        write(folder/'status.json',dict(state=value,cohort=cohort,endpoint=ep,boundary=description,pid=os.getpid(),utc_ns=time.time_ns()))
    pauses=[folder/'supervisor.pause',folder/'pause']
    assert (old/'control/pause').is_file() and (here.parent/'edited-role-recovery/control/pause').is_file()
    if any(f.exists() for f in pauses):
        status('paused');print(f'Parked {cohort}/{ep} at {description}',flush=True)
        while any(f.exists() for f in pauses):time.sleep(5)
    status('released')


def authority(cohort,ep):
    def validate(qualified,proof,subject):
        assert qualified['cohort']==cohort and qualified['endpoint']==ep
        assert qualified['whole_file_sha256s']==sorted(x['sha256'] for x in proof['forms'].values())
        assert qualified['registration_sha256']==sha(subject/'registration.json')
        assert set(qualified['controls'])=={'distributed','release-source'}
        assert qualified['controls']['release-source']==read(old/'sealed.json')['arms']['base']['wild']
    if ep=='build':
        p=cal/cohort;proof=read(p/'reconstruction.json');qualified=read(p/'qualified.json')
        validate(qualified,proof,cal);assert qualified['reconstruction_sha256']==sha(p/'reconstruction.json')
        return {qualified['artifact']:dict(name='uv',test=False,qualification=sha(p/'qualified.json'),proof=proof)}
    p=cal/('test-'+cohort);c=read(p/'registration.json');result={}
    for name,v in c['roles'].items():
        q=p/name/'qualified.json';qual=read(q)
        assert qual['artifact']==v['role'];validate(qual,v['reconstruction'],p)
        result[v['role']]=dict(name=name,test=True,qualification=sha(q),proof=v['reconstruction'])
    assert (cohort,ep)==('replica','test') and len(result)==2
    extra=read(here/'normal-uv-stock.json');assert extra['role'] not in result
    result[extra['role']]=extra['rule']
    return result


def freeze(cohort,ep):
    assert not (old/'control/pause').exists(), 'coordinator pause'
    out=here/'registrations';out.mkdir(exist_ok=True);reg=out/f'{cohort}-{ep}.json';assert not reg.exists()
    source=old/'results'/cohort/ep;receipts=sorted(source.glob('admit-*/receipt.json'))
    assert (source/'rejected.json').exists() and not (source/'samples.csv').exists() and len(receipts)>=2
    permits=authority(cohort,ep);reference=read(receipts[0]);sources={}
    for f in receipts:
        rec=read(f)
        assert rec['roster']==reference['roster'] and (rec['source_sha256'],rec['source_mtime_ns'])==(reference['source_sha256'],reference['source_mtime_ns'])
        sources[str(f.relative_to(old))]=sha(f)
        for k,v in rec['files'].items():
            if k in permits:assert v['sha256'] in {x['sha256'] for x in permits[k]['proof']['forms'].values()}
            else:assert (v['size'],v['canonical_sha256'])==(reference['files'][k]['size'],reference['files'][k]['canonical_sha256'])
    frozen=[here/'recover.py',here/'score.py',here/'PROTOCOL.md',old/'plan.json',old/'registered.sha256',old/'sealed.json',old/'run.py',old/'plan.py',old/'summary.py',old/'measurement-affinity.json',old/'calibration/PASS.json',cal/'recover_forms.py',cal/'blake-stream',cal/'released-snapshots.json']
    write(reg,dict(cohort=cohort,endpoint=ep,registered_ns=time.time_ns(),inputs={str(x.relative_to(here.parent)):sha(x) for x in frozen},
                original_admission_receipts=sources,source_mtime_ns=reference['source_mtime_ns'],structural=read(source/'predecessor.json'),
                home_state_sha256=home_files(run.ROOTS/cohort/('homes-'+ep)/'predecessor'),permits=permits,
                schedule=read(old/'plan.json')['schedule'][cohort][ep],cpus=read(old/'measurement-affinity.json')['actual_cpus']))
    print('Registered',reg,flush=True)


def oracle(ep,records,target,permits,original):
    result=original(ep,records,target)
    assert set(permits)<=set(result)
    for key,meta in result.items():
        rule=permits.get(key)
        if not rule and not meta['permitted_fields']:continue
        f=target/key
        if rule:
            assert sum(r['role']=='wild' and r['key']==str(f) for r in records)==1
            compilers=[r['argv'] for r in records if r['role']=='rustc' and str(f)+'.rlink' in r['argv']]
            assert len(compilers)==1;a=compilers[0]
            assert a[a.index('--crate-name')+1]==rule['name'] and ('--test' in a)==rule['test'] and 'link-only' in a and a[a.index('--out-dir')+1]==str(f.parent)
            if not rule['test'] and ep=='test':
                assert key==read(here/'normal-uv-stock.json')['role'] and a.count('--crate-type')==1 and a[a.index('--crate-type')+1]=='bin'
                assert a.count('link-only')==1 and a[a.index('link-only')-1]=='-Z'
        else:
            assert ep=='test' and any(r['role']=='rustc' and '--test' in r['argv'] and any(k.endswith('crates/uv/src/lib.rs') for k in r['argv']) and r['argv'][r['argv'].index('--out-dir')+1]==str(f.parent) for r in records)
        proof=forms(f);assert proof['actual_sha256']==meta['sha256'] and proof['bytes']==meta['size']
        if rule:
            shape=('bytes','rodata_entsize_offset','gnu_build_id_start','gnu_build_id_end')
            assert all(proof[k]==rule['proof'][k] for k in shape)
            meta['canonical_sha256']=proof['forms']['0']['sha256']
        meta['permitted_fields']=dict(original_library_test_rule=not bool(rule),qualification=rule['qualification'] if rule else None,**proof)
    return result


def study(cohort,ep):
    boundary(cohort,ep,'before validating inputs')
    reg=read(here/'registrations'/f'{cohort}-{ep}.json');p=run.checked_plan('seal');seal=run.seal(p)
    assert seal==read(old/'sealed.json') and reg['cpus']==sorted(os.sched_getaffinity(0))
    assert all(sha(here.parent/k)==v for k,v in reg['inputs'].items()) and all(sha(old/k)==v for k,v in reg['original_admission_receipts'].items())
    assert reg['permits']==authority(cohort,ep) and reg['schedule']==p['schedule'][cohort][ep]
    assert (old/'results'/cohort/'test/restore.json').exists(), 'original sampler still owns this fixture'
    cfg=reg['schedule'];root=run.ROOTS/cohort;target=root/'target';src=root/'source'/run.EDIT;before=src.stat();home=root/'cargo-home'
    pred=root/('rejected-'+ep+'-structural');original_homes=root/('homes-'+ep);state=root/('form2-recovery-homes-'+ep)
    assert home_files(original_homes/'predecessor')==reg['home_state_sha256']
    assert read(root/'common-ready.json')==run.tree_state(root/'common') and run.tree_state(pred)==reg['structural']
    assert src.read_bytes()==run.ORIGINAL and not target.exists() and not state.exists() and not any((root/('held-'+a)).exists() for a in run.ARMS)
    assert shutil.disk_usage(root).free>150*2**30, 'space reserve before new clone'
    out=here/'results'/cohort/ep;out.mkdir(parents=True);state.mkdir(mode=0o700)
    orig=run.artifact_hashes;run.artifact_hashes=lambda e,recs,t:oracle(e,recs,t,reg['permits'],orig)
    expected={e['id']:e['sha256'] for e in cfg['edits']}
    reference=copy.deepcopy(read(old/next(iter(reg['original_admission_receipts']))))
    for key,rule in reg['permits'].items():reference['files'][key]['canonical_sha256']=rule['proof']['forms']['0']['sha256']
    def edit(i):
        src.write_bytes(run.body(cfg['symbol'],i));assert sha(src)==expected[i]
    def select(arm):run.stage(root,arm,seal['arms'][arm])
    def clone(dst):
        assert shutil.disk_usage(root).free>120*2**30+reg['structural']['file_size_sum'], 'free-space reserve before clone'
        assert run.tree_state(pred)==reg['structural']
        run.clone(pred,dst);assert run.tree_state(dst)==reg['structural']
    def compare(a,b):
        run.match(a,b)
        for key,f in a['files'].items():
            if f['permitted_fields'] and 'forms' in f['permitted_fields']:
                assert f['permitted_fields']['forms']==b['files'][key]['permitted_fields']['forms']
    saved_home=state/'before-study';assert not saved_home.exists()
    run.copy_home_state(home,saved_home);home_before=home_files(saved_home)
    try:
        boundary(cohort,ep,'before four admissions');edit(1);os.utime(src,ns=(before.st_atime_ns,reg['source_mtime_ns']))
        registry=run.tree_state(home/'registry');assert registry==read(old/'results'/cohort/ep/'registry.json')
        write(out/'predecessor.json',reg['structural']);write(out/'registry.json',registry);admitted=None
        for i,(mode,arm) in enumerate(cfg['native_count_admission']):
            run.copy_home_state(original_homes/'predecessor',home);select(arm);clone(target)
            r=run.run(root,cfg['command'],ep,out/f'admit-{i}-{mode}-{arm}',mode,'admit');run.match(reference,r)
            for key,rule in reg['permits'].items():assert r['files'][key]['permitted_fields']['forms']==rule['proof']['forms']
            if admitted:compare(admitted,r)
            else:admitted=r
            run.discard(target)
        write(out/'admission.json',admitted['roster']);print('Re-admitted',cohort,ep,flush=True)
        boundary(cohort,ep,'after four admissions')
        for arm in run.ARMS:clone(root/('held-'+arm));run.copy_home_state(original_homes/'predecessor',state/arm)
        with (out/'samples.csv').open('x',newline='') as f:
            rows=csv.DictWriter(f,fieldnames=['pair','id','position','arm','cargo','rustc','wild','total','source_sha256','receipt']);rows.writeheader()
            for i,pair in enumerate(cfg['pairs']):
                edit(pair['id']);first=None
                for j,arm in enumerate(pair['order']):
                    held=root/('held-'+arm);held.rename(target);select(arm);run.copy_home_state(state/arm,home)
                    log=out/f'pair-{i}-{j}-{arm}';r=run.run(root,cfg['command'],ep,log,'count','sample');assert r['roster']==admitted['roster']
                    if first:compare(first,r)
                    else:first=r
                    target.rename(held);run.copy_home_state(home,state/arm)
                    rows.writerow(dict(pair=i,id=pair['id'],position=j,arm=arm,**r['totals'],total=sum(r['totals'].values()),source_sha256=r['source_sha256'],receipt=str(log.relative_to(out)/'receipt.json')));f.flush()
                boundary(cohort,ep,f'after pair {i+1} of 8')
        assert run.tree_state(pred)==reg['structural'] and run.tree_state(home/'registry')==registry
        assert home_files(original_homes/'predecessor')==reg['home_state_sha256']
        for arm in run.ARMS:run.discard(root/('held-'+arm))
        assert run.tree_state(root/'common')==read(root/'common-ready.json');write(out/'complete.json',dict(pairs=8,arms=16,admission_cells=4,common_unchanged=True))
    except BaseException as exc:
        write(out/'rejected.json',dict(type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc()))
        for name in ['target','held-base','held-candidate']:
            q=root/name
            if q.exists():q.rename(root/f'rejected-form2-{ep}-{name}')
        raise
    finally:
        src.write_bytes(run.ORIGINAL);os.utime(src,ns=(before.st_atime_ns,before.st_mtime_ns));select('base');run.artifact_hashes=orig
        run.copy_home_state(saved_home,home)
        verify_home=state/'returned-study';run.copy_home_state(home,verify_home);assert home_files(verify_home)==home_before
        write(out/'restore.json',dict(source_sha256=sha(src),target_vacant=not target.exists(),mutable_home_restored=True))


if __name__=='__main__':
    assert sys.argv[1:]==['measure','replica','test','--coordinator-released']
    parent=Path('/proc')/str(os.getppid())
    pa=[v.decode() for v in (parent/'cmdline').read_bytes().split(bytes(1)) if v]
    assert pa[1:]==['-I','-B',str(here/'host.py'),'start','replica-test']
    assert (parent/'exe').resolve()==Path(sys.executable).resolve()
    study('replica','test')
