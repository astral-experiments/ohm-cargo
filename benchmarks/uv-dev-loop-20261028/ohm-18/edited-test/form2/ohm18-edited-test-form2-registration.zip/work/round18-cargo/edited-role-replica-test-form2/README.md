# Separately registered edited-test replica on release -18

The previously registered replica supervisor returned in session 91078, chunk `296d24`, with status 0 after recording the worker's status 1. It excluded the first native baseline admission before a candidate ran. There were zero scored observations. Its packet SHA-256 is `62a3c431e37c34688429f4faff04a775136073e14035738729a72953e0785dd4`. Preserve that exclusion if this separate repeat passes, fails or never runs.

## Basis for reopening

Two separately launched stock controls at the identical source edit and timestamp had the same program/argv multiset, 72 test executable paths and four unchanged companions to the one differing linked artifact. The preserved counted baseline and the rejected native baseline assigned identical LLVM compiler, Cargo and Wild identities. The earlier ordinary native control also recorded the counted baseline's raw digest.

The real-host scan checked both complete 316,713,312-byte ordinary `uv` binaries against the original receipts. It found a 32-byte GNU build ID starting at 896 and one differing byte at 316,711,384 in the eight-byte `.rodata.sh_entsize` field. All 316,713,279 other bytes agree. Both inputs have SHA-256 `04a44484d4a33669e3f422190c92083f07f2aa3bf22777843f4a1288c86919e9` after zeroing the two ELF-proved fields. The scan in session 63421, chunk `6c0814`, exited 0. Its signed-by-digest input is `../replica-test-quarantine-audit/stock-comparison.json`. The separate storage proposal is in that directory's `STORAGE.md`.

## One new output rule

The new rule is restricted to `debug/build/uv/e6ac92541876a4a1/out/uv`, one corresponding Wild invocation and one rustc `--crate-name uv --crate-type bin` relink of that exact path's `.rlink` using `-Z link-only`. It requires the regular binary, its original size and the exact ELF field positions above. The two full admission SHA-256 digests and actual GNU build IDs are pinned in `normal-uv-stock.json`.

The original output verifier remains active for every other product, including its two separately calibrated binary-test-harness permits and its existing library-test rule. At each admission, both reconstructed *entire-file* forms of regular uv must match the stock controls. At each same-edit scored pair the ELF decoder accepts exactly the observed `sh_entsize` values 0 and 8, recalculates both complete files with Wild's real BLAKE3 algorithm, checks the raw on-disk GNU ID, and requires identical full SHA-256s of the reconstructed forms across arms. A third value, changed byte elsewhere, unreproducible GNU ID, changed size or offset, or different compiler role excludes the repeat. Nothing is accepted on the strength of a masked digest alone.

## Population, protocol and return

Use the original release -18 Cargo/Wild baseline and original-eight treatment, with the same distributed rustc in both. The exact executable identities, frozen arm order, same-length edit bytes, separate source roots and original structural predecessor remain bound through `registrations/replica-test.json` and `../edited-roles/{plan,sealed}.json`. Restore the registered structural target and control Cargo-home state afresh before each of the four native/counted × baseline/candidate admission cells. Both counted arms use persistent targets cloned from that same state after admission. Use one fixed visible source and target, check all 72 test executable paths and the unchanged 1 Cargo/6 rustc/5 Wild argument multisets, and compare all linked outputs. Each pair holds edit bytes and timestamp fixed. No test runs. At completion the driver verifies immutable predecessors, restores source/mtime and the pre-study mutable Cargo home, parks the tool slots, and retires only its two positively identified targets. It quarantines newly owned banks on rejection.

The eight original replica assignments were fixed before the original treatment could run. Keep four base-first and four candidate-first pairs, including any losses. Full paired Cargo + rustc + Wild **application instruction** sums require a positive median, two-sided exact sign p < .05, and the original two-sided order-balanced randomization p < .05. All per-thread raw streams, native exec evidence and zero-row/partial exclusions are kept. The separate initial cohort's qualified median was 2.096593%. GCC, shells, wrappers, kernel work and pre-exec work are outside the counter; Wild runs with `--no-fork` and rustc uses the registered wrapper, so elapsed time and uninstrumented latency are separate metrics. As the added admission rule was learned after a stock-only rejection, report any positive result as a separately registered, stock-calibrated repeat.

## Commands

The data-only verification reads stored scripts and compact JSON manifests. It does not inspect the quarantined ELF or fixtures.

```sh
study="$PWD/work/round18-cargo/edited-role-replica-test-form2"
taskset -c 29 /usr/bin/python3 -I -B "$study/score_result.py" --plan-only
```

Only after a fresh explicit coordinator allocation for this exact study on the real host, use the immediately preceding physical return receipt and the digest supplied in that allocation:

```sh
taskset -c 8-15 /usr/bin/python3 -I -B "$study/allocation.py" \
  --preceding-receipt "$receipt" --preceding-sha256 "$digest" --coordinator-released
taskset -c 8-15 /usr/bin/python3 -I -B "$study/host.py" start replica-test
taskset -c 29 /usr/bin/python3 -I -B "$study/score_result.py"
```

Record the actual parent session/chunk/status and both worker and supervisory receipts. The grant binds the physical host boot ID and expires after an hour if unused. The supervisor verifies the worker's executable, parent, PID start ticks, session and 8–15 CPU affinity. It acquires the old controller's same one-cell lock and real native lease, keeps the original two pause sentinels intact, and owns two independent pause sentinels here. Actual free space before allocation must exceed 120 GiB plus twice the recorded predecessor's logical size plus 3 GiB or 150 GiB, whichever is larger (156.58 GiB for this donor). Every clone has an independent reserve check. The live 130/124/120-GiB soft, hard and absolute thresholds remain in force. No dormant grant or target allocation is part of this registration.
