"""Source registration and one-use handoff for the separate replica-test repeat."""
import csv
import hashlib
import json
import os
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
WORK = PROJECT.parent
LAB = WORK/"round18-lab"
STUDY = HERE
ORIGINAL = PROJECT/"edited-roles"
CELLS = ("replica-test",)
PAUSES = (HERE/"control/supervisor.pause", HERE/"control/pause")
PEERS = (ORIGINAL/"control/pause", PROJECT/"edited-role-recovery/control/pause")
FLOOR = 120*2**30


def need(ok, why):
    if not ok:
        raise RuntimeError(str(why))


def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def write_new(p,obj):
    with p.open("x") as f:
        json.dump(obj,f,indent=2,sort_keys=True)
        f.write("\n")


def cell(name):
    need(name == "replica-test","only the separately named test repeat can run")
    return "replica","test"


def table_rows(p):
    if not p.is_file():
        return []
    with p.open() as stream:
        return list(csv.DictReader(stream))


def check_seal():
    p = HERE/"registration.json"
    need(sha(p) == (HERE/"registration.sha256").read_text().split()[0],"registration changed")
    data = read(p)
    for name, expected in data["frozen"].items():
        need(sha(PROJECT/name)==expected,"unsealed script or evidence: "+name)
    reg = read(HERE/"registrations/replica-test.json")
    original = read(PROJECT/"edited-role-recovery/registrations/replica-test.json")
    need(reg["schedule"]==original["schedule"],"assignment drift")
    role = data["new_role"]
    need(reg["permits"].keys()==original["permits"].keys()|{role},"additional variation rule")
    need(all(reg["permits"][n]==v for n,v in original["permits"].items()),"modified old harness rule")
    need(reg["permits"][role]==read(HERE/"normal-uv-stock.json")["rule"],"normal uv bound differs")
    failed = read(PROJECT/"edited-role-next/cells/replica-test/closure.json")
    need(failed["terminal"]=="excluded" and failed["worker_returncode"]==1 and failed["rows"]==0,
         "lost original rejected admission")
    return data


def grant(name):
    cell(name)
    reg = check_seal()
    authority = read(HERE/"control/authority.json")
    receipt = WORK/authority["preceding_receipt"]
    need(receipt.is_file() and not receipt.is_symlink() and receipt.resolve()==receipt and
         receipt.is_relative_to(WORK) and sha(receipt)==authority["preceding_sha256"],"wrong last physical handoff")
    need(authority["study"]==HERE.name and authority["only_cell"]==name and
         authority["registration"]==sha(HERE/"registration.json") and authority["coordinator_released"] is True,
         "wrong fresh allocation")
    need(authority["boot_id"]==Path("/proc/sys/kernel/random/boot_id").read_text().strip() and
         0<=time.time_ns()-authority["issued_ns"]<3_600_000_000_000,"expired or foreign allocation")
    need(all(p.is_file() and sha(p)==reg["peer_pause_sha256"][str(p.relative_to(PROJECT))] for p in PEERS),
         "older programs have resumed")
    return {"study":HERE.name,"only_cell":name,"authority_sha256":sha(HERE/"control/authority.json"),
            "preceding_sha256":authority["preceding_sha256"],"new_registration":sha(HERE/"registration.json"),
            "old_exclusion":reg["old_exclusion"],"cpu":list(range(8,16)),"floor_bytes":FLOOR}
