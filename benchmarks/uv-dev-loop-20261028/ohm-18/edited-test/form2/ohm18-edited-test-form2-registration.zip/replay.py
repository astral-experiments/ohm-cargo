"""Read-only validation of one preregistration or terminal result. Python 3.11+."""
import ast
import collections
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

NAME = "edited-role-replica-test-form2"
REG = "b2490310d1a7ff445a86e4033d32f90c900c71f2278822085d341b5dbd40342e"
SCAN = "86d0beb82377dfb476327dcc55703136b7383f89d9ac6dae4f891777a09b3ba0"
PRIOR_PACKET = "62a3c431e37c34688429f4faff04a775136073e14035738729a72953e0785dd4"
INITIAL_PACKET = "e7fa5fd8d5d9251c347a4f8726ce369f25dff255c820b10475c6d7d4545c8031"


def need(ok, reason):
    if not ok:
        raise ValueError(str(reason))


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inputs(work):
    project=work/"round18-cargo"
    study=project/NAME
    old=project/"edited-roles"
    next_ctl=project/"edited-role-next"
    recovery=project/"edited-role-recovery"
    need(sha(study/"registration.json")==REG,"published source registration")
    outer=read(study/"registration.json")
    for n,h in outer["frozen"].items():
        need(sha(project/n)==h,"pre-import source identity "+n)
    verifier=load("form2_verify",study/"score_result.py")
    out=verifier.verify_plan()
    cfg=read(study/"registrations/replica-test.json")
    for n,h in cfg["inputs"].items():
        need(sha(project/n)==h,"frozen input "+n)
    for n,h in cfg["original_admission_receipts"].items():
        need(sha(old/n)==h,"earlier source receipt "+n)
    rawref=read(next_ctl/"packets/replica-test/bundle.json")
    initref=read(next_ctl/"packets/initial-test/bundle.json")
    need((rawref["archive_sha256"],rawref["outcome"]["gate"],rawref["recorded_arms"])==(PRIOR_PACKET,None,0),"old exclusion disposition")
    need(initref["archive_sha256"]==INITIAL_PACKET and initref["outcome"]["gate"] and initref["recorded_arms"]==16,"historic initial outcome")
    terminal=next_ctl/"cells/replica-test/closure.json"
    need(sha(terminal)==outer["old_exclusion"]==read(next_ctl/"cells/replica-test/validated.json")["closure_sha256"],"prior custody")
    stockfile=project/"replica-test-quarantine-audit/stock-comparison.json"
    stock=read(stockfile)
    need(sha(stockfile)==SCAN and (stock["supervisor_session"],stock["supervisor_chunk"],stock["supervisor_exit"],
         stock["subject_exit"],stock["historical_gate"],stock["historical_scored_rows"])==(91078,"296d24",0,1,None,0),"stock or prior return")
    role=outer["new_role"]
    proof=cfg["permits"][role]["proof"]
    for f in stock["files"].values():
        box=project/f["receipt"]
        need(sha(box)==f["receipt_sha256"] and read(box)["files"][role]["sha256"]==f["actual_raw_sha256"],"stock ELF trace")
        fields=f["metadata"]["fields"]
        size=int.from_bytes(bytes.fromhex(fields["rodata_sh_entsize"][2]),"little")
        need(fields["gnu_build_id"][:2]==[896,928] and fields["rodata_sh_entsize"][:2]==[316711384,316711392] and
             proof["forms"][str(size)]=={"sha256":f["actual_raw_sha256"],"gnu_build_id":fields["gnu_build_id"][2]} and
             f["mask_40_bytes_sha256"]=="04a44484d4a33669e3f422190c92083f07f2aa3bf22777843f4a1288c86919e9","role-specific stock forms")
    need(stock["different_bytes"]==33 and stock["different_outside_mask"]==0 and stock["unchanged_bytes"]==316713279,"comparison count")
    old_blob=next_ctl/"registration.json"
    need(sha(next_ctl/"replay.py")==read(old_blob)["code"]["replay.py"],"changed original prefix/statistical gates")
    legacy=load("legacy_cell_reader",next_ctl/"replay.py")
    original_reg=read(recovery/"registrations/replica-test.json")
    legacy.qualification(project,old,original_reg)
    plan=read(old/"plan.json")
    seal=read(old/"sealed.json")
    need(sha(old/"plan.json")==seal["plan"] and sha(old/"PROTOCOL.md")==plan["protocol_sha256"],"plan or protocol")
    for n,h in seal["wrapper_inputs"].items():
        need(sha(work/n)==h,n)
    for n,h in seal["harness"].items():
        need(sha(old/n)==h,n)
    source=(work/"uv"/plan["edit"]).read_bytes()
    need(hashlib.sha256(source).hexdigest()==plan["original_sha256"],"unchanged uv file")
    code=ast.parse((old/"plan.py").read_bytes())
    item=next(f for f in code.body if isinstance(f,ast.FunctionDef) and f.name=="body")
    env={"need":need,"ORIGINAL":source,"BEFORE":b"component == cellar && next == formula"}
    exec(compile(ast.Module(body=[item],type_ignores=[]),"<frozen body>","exec"),env)
    for edit in cfg["schedule"]["edits"]:
        data=env["body"](cfg["schedule"]["symbol"],edit["id"])
        need(hashlib.sha256(data).hexdigest()==edit["sha256"],"source/edit bound")
    out.update(old_replica_archive=PRIOR_PACKET,old_worker_exit=1,initial_archive=INITIAL_PACKET,
               stock_comparison_sha256=SCAN,matched_scheduling=cfg["schedule"]["pairs"],source_edits_verified=10,
               frozen_drivers=seal["arms"],rustc_sha256=plan["rustc_sha256"])
    return out


def streams(work):
    project=work/"round18-cargo"
    study=project/NAME
    old=project/"edited-roles"
    reg=read(study/"registrations/replica-test.json")
    out=study/"results/replica/test"
    legacy=load("legacy_read",project/"edited-role-next/replay.py")
    scorer=load("form2_checked_score",study/"score.py")
    estimate=scorer.inspect("replica","test")
    public=legacy.public_outcome(estimate)
    rows=list(csv.DictReader((out/"samples.csv").open())) if (out/"samples.csv").is_file() else []
    legacy.prefix(rows,reg)
    orders=[f"admit-{i}-{mode}-{arm}" for i,(mode,arm) in enumerate(reg["schedule"]["native_count_admission"])]
    complete=[f"pair-{i}-{j}-{arm}" for i,p in enumerate(reg["schedule"]["pairs"]) for j,arm in enumerate(p["order"])]
    admissions={d.name for d in out.glob("admit-*") if d.is_dir()}
    paired={d.name for d in out.glob("pair-*") if d.is_dir()}
    need(admissions==set(orders[:len(admissions)]) and (not (rows or paired) or len(admissions)==4),"invalid admission prefix")
    need(len(rows)<=len(paired)<=len(rows)+1 and paired==set(complete[:len(paired)]),"invalid raw pair prefix")
    reference=read(old/next(iter(reg["original_admission_receipts"])))
    partial=[]
    for i,row in enumerate(rows):
        location=out/complete[i]
        if public["gate"] is None:
            r=scorer.summary.audit_run(location,row,"count")
            need(r["source_sha256"]==row["source_sha256"] and r["roster"]==reference["roster"],"unadmitted partial row")
    if public["gate"] is not None:
        need(len(rows)==16 and read(out/"admission.json")==reference["roster"],"complete cohort roster")
        for i,directory in enumerate(orders):
            receipt=read(out/directory/"receipt.json")
            need((receipt["source_sha256"],receipt["source_mtime_ns"])==(reference["source_sha256"],reference["source_mtime_ns"]),
                 "mismatched admission source or clock")
            exp={key:(f["size"],reg["permits"][key]["proof"]["forms"]["0"]["sha256"] if key in reg["permits"] else f["canonical_sha256"])
                 for key,f in reference["files"].items()}
            need({k:(v["size"],v["canonical_sha256"]) for k,v in receipt["files"].items()}==exp,"changed admission product")
    else:
        for directory in [*orders[:len(admissions)],*complete[:len(paired)]]:
            d=out/directory
            details={"directory":directory,"receipt_present":(d/"receipt.json").is_file()}
            if details["receipt_present"]:
                try:
                    scorer.summary.audit_run(d,None,"native" if "-native-" in directory else "count")
                except (AssertionError,KeyError,ValueError,RuntimeError,OSError) as exc:
                    details["raw_readback_failure"]=f"{type(exc).__name__}: {exc}"
            partial.append(details)
    return {"population":"replica/test","public":public,"recorded_arms":len(rows),
            "scored_estimate":estimate if public["gate"] is not None else None,
            "exclusion":estimate.get("reason"),"excluded_raw_readbacks":partial}


def custody(work,summary):
    study=work/"round18-cargo"/NAME
    control=study/"cells/replica-test"
    grant=study/"grants/replica-test.json"
    authority=study/"control/authority.json"
    cl=read(control/"closure.json")
    va=read(control/"validated.json")
    ad=read(control/"admitted.json")
    au=read(authority)
    g=read(grant)
    observed=read(work.parent/"outer-return.json")
    need(va["closure_sha256"]==sha(control/"closure.json") and va["admission_sha256"]==sha(control/"admitted.json"),"custody receipt")
    need(ad["grant_sha256"]==cl["issued_grant"]==sha(grant) and ad["selected_grant"]==g and
         g["authority_sha256"]==sha(authority) and g["new_registration"]==au["registration"]==REG and
         g["preceding_sha256"]==au["preceding_sha256"]==sha(work/au["preceding_receipt"]),"individual grant")
    need(au["study"]==g["study"]==NAME and au["only_cell"]==g["only_cell"]==cl["cell"]==ad["cell"]=="replica-test" and
         au["coordinator_released"] is True and au["boot_id"]==ad["boot_id"],"allocation identity")
    w=ad["worker"]; m=ad["accepted_worker_status"]
    need(w==cl["worker"] and w["pid"]==w["group"]==w["session"]==m["pid"] and w["ppid"]==ad["guardian_pid"]
         and w["cpus"]==g["cpu"]==list(range(8,16)) and m["utc_ns"]>=ad["spawn_ns"] and
         (m["cohort"],m["endpoint"],m["state"],m["boundary"])==("replica","test","paused","before validating inputs"),"stale worker")
    need(ad["plan_sha256"]==sha(study/"registrations/replica-test.json") and cl["worker_exited"] and cl["source_restored"] and cl["target_vacant"] and
         read(study/"results/replica/test/restore.json")["mutable_home_restored"] and ad["anchors"]==cl["protected_anchors"] and
         cl["minimum_free_bytes"]>=120*2**30 and ad["initial_free_bytes"]>ad["start_floor"] and
         ad["pauses"]==cl["pauses"] and not cl["guard_hard"],"unreturned worker/bank/pauses")
    for name,h in cl["pauses"].items():
        need(sha(work/name)==h,"unrestored pause "+name)
    table=study/"results/replica/test/samples.csv"
    need(cl["rows"]==summary["recorded_arms"] and cl["samples_sha256"]==(sha(table) if table.exists() else None),"terminal CSV")
    need(cl["terminal"] in ("complete","excluded") and (cl["terminal"]=="complete")==
         (summary["public"]["gate"] is not None)==(cl["worker_returncode"]==0),"collector/scorer outcome")
    need(observed["session"]>0 and len(observed["chunk"])==6 and all(x in "0123456789abcdef" for x in observed["chunk"]) and
         observed["exit_status"]==0 and observed["closure_sha256"]==sha(control/"closure.json") and
         observed["worker_returncode"]==cl["worker_returncode"],"missing outer supervisor return")
    return {"supervisor":observed,"child_exit":cl["worker_returncode"],"minimum_free_bytes":cl["minimum_free_bytes"]}


def validate(root):
    manifest=read(root/"manifest.json")
    actual={p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    need(actual==set(manifest)|{"manifest.json"},"unexpected membership")
    for key,h in manifest.items():
        p=root/key
        need(p.is_file() and p.resolve()==p and p.is_relative_to(root) and sha(p)==h,key)
    work=root/"work"
    admission=inputs(work)
    kind=read(root/"scope.json")["kind"]
    if kind=="registration":
        need(not admission["grant_present"] and not (work/"round18-cargo"/NAME/"results").exists(),"registration contains treatment observations")
        return {"kind":kind,"registration":REG,"prior_gate":None,"prior_rows":0,"normal_stock_form_sha256":SCAN,
                "original_source_edits":admission["source_edits_verified"],"pairs":8,"roster":admission["admission_roster"],
                "test_executables":72,"arm_binaries":admission["frozen_drivers"]}
    need(kind=="outcome","unknown packet kind")
    # Require the measured packet to contain the exact previously published registration.
    import zipfile
    published=root/"published-registration.zip"
    need(sha(published)==read(root/"scope.json")["registration_packet_sha256"],"published ZIP digest")
    with zipfile.ZipFile(published) as z:
        entries=read(root/"scope.json")
        sealed=json.loads(z.read("manifest.json"))
        need(json.loads(z.read("scope.json"))["kind"]=="registration" and set(z.namelist())==set(sealed)|{"manifest.json"}
             and len(z.namelist())==len(set(z.namelist())) and entries["registration"]==REG,"unexpected prior ZIP")
        for key,h in sealed.items():
            need(hashlib.sha256(z.read(key)).hexdigest()==h and (key=="scope.json" or sha(root/key)==h),"changed published input "+key)
    result=streams(work)
    need(json.loads(json.dumps(result))==read(root/"result.json"),"stored result differs from raw replay")
    returned=custody(work,result)
    q=result["scored_estimate"]
    return {"kind":kind,"registration":REG,"prior_gate":None,"prior_rows":0,"outcome":result["public"],
            "recorded_arms":result["recorded_arms"],"stats":None if q is None else {k:q[k] for k in
             ("n_pairs","wins","losses","median_paired_reduction","rank_interval_99_21875","two_sided_sign_p","balanced_order_randomization_p")},
            "custody":returned}


if __name__=="__main__":
    print(json.dumps(validate(Path(__file__).resolve().parent),sort_keys=True,indent=2))
