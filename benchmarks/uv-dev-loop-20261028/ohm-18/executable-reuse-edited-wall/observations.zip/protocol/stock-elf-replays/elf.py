from pathlib import Path
import hashlib,json,struct
def sha(b):return hashlib.sha256(b).hexdigest()
def secs(b):
 assert b[:6]==b'\x7fELF\x02\x01';offset=struct.unpack_from('<Q',b,40)[0];step,num,st=struct.unpack_from('<HHH',b,58);raw=[struct.unpack_from('<IIQQQQIIQQ',b,offset+i*step) for i in range(num)];s=raw[st][4];return [(b[s+v[0]:b.find(bytes(1),s+v[0])].decode(),v,offset+i*step) for i,v in enumerate(raw)]
def info(b):
 t=secs(b);no=next((v for n,v,p in t if n=='.note.gnu.build-id'),None);note=None
 if no:
  a=no[4];num,size,kind=struct.unpack_from('<III',b,a);assert kind==3;note=(a+12+(num+3)//4*4,size)
 return {'sha256':sha(b),'bytes':len(b),'build_id':b[note[0]:sum(note)].hex() if note else None,'build_id_offset':note[0] if note else None,'sh_entsize':{n:v[9] for n,v,p in t if n in ('.rodata','.eh_frame','.debug_str')}}
def diff(a,b):
 assert len(a)==len(b)
 v=info(a);lo=v['build_id_offset'];n=len(bytes.fromhex(v['build_id'])) if v['build_id'] else 0;tabs=secs(a);d=[]
 for off,(x,y) in enumerate(zip(a,b)):
  if x==y:continue
  names=[k for k,z,p in tabs if z[1]!=8 and z[4]<=off<z[4]+z[5]];hdr=[(k,off-p) for k,z,p in tabs if p<=off<p+64];d.append({'off':off,'a':x,'b':y,'section_data':names,'section_header_at':hdr,'build_id_payload':lo is not None and lo<=off<lo+n})
 return d
if __name__=='__main__':
 p=Path(__file__).resolve().parent;w=p.parent;root=Path('/tmp/ohm-uv-bench.0H03f2TH/round18/independent/longer-checkout-b/r18-four');key='debug/build/uv/f86773a1331ddc31/out/uvx-f86773a1331ddc31';metadata=json.loads((w/'round18-lab/r18-final/replica/test/artifact-difference.json').read_text());data={a:(root/a/key).read_bytes() for a in metadata};info_map={a:info(b) for a,b in data.items()};print(info_map)
 for k,b in data.items():
  assert info_map[k]['sha256'] in str(metadata[k]['outputs']);(p/(k+'.elf')).write_bytes(b)
 ds=diff(data['shipped'],data['stack']);j={'relative_path':key,'exact_parked':info_map,'diff':ds,'difference_count':len(ds),'outside_build_id':[v for v in ds if not v['build_id_payload']],'all_remaining_bytes_equal':len(data['shipped'])-len(ds)};(p/'parked.json').write_text(json.dumps(j,indent=2)+'\n');print('diff',len(ds),'non build-id',j['outside_build_id'])
