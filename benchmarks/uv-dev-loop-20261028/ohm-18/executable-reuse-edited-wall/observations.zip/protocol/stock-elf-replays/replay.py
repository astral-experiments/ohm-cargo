from pathlib import Path
import array,fcntl,json,os,subprocess,sys,termios,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from elf import sha,info,diff
p=Path(__file__).resolve().parent;w=p.parent;cap=w/'round18-linker/confirm18';emit=p/'replays';emit.mkdir(exist_ok=True)
bins={'shipped':w/'upstream-monitor/toolchain18/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd','pr46':w/'wild-prefix-v2/v2-wild'}
def write(f,j):f.write_text(json.dumps(j,indent=2)+'\n')
def read(f):return json.loads(f.read_text())
def avail(fd):
 a=array.array('i',[0]);fcntl.ioctl(fd,termios.FIONREAD,a,True);return a[0]
env0={k:v for k,v in os.environ.items() if not k.startswith(('OHM_','WILD_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','LD_PRELOAD','RUSTC_WRAPPER','RUSTFLAGS')}
for k in sys.argv[1:]:
 inp=cap/f'argv-{k}.json';rec=read(inp);outs={};rows={};original=read(cap/'intake.json')[k]
 for arm,binary in bins.items():
  for tokens in [0,7]:
   tag=f'{k}-{arm}-{tokens}';meta=emit/(tag+'.json');file=emit/(tag+'.elf')
   if meta.exists():
    a=read(meta);assert sha(file.read_bytes())==a['elf']['sha256'];rows[tag]=a;outs[tag]=file;continue
   argv=list(rec['args']);out=emit/'same-linked-output';out.unlink(missing_ok=True);argv[argv.index('-o')+1]=str(out);assert not any(v.startswith('--threads') or v in ('--no-fork','--fork') for v in argv)
   r,wr=os.pipe();all_tokens=b'1234567'[:tokens]
   if all_tokens:os.write(wr,all_tokens)
   env=env0|rec['env']|{'CARGO_MAKEFLAGS':f'-j --jobserver-fds={r},{wr} --jobserver-auth={r},{wr}'};before=avail(r);start=time.monotonic();q=subprocess.Popen([binary,*argv],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=(r,wr));so,se=q.communicate(timeout=120);dt=time.monotonic()-start
   limit=time.monotonic()+5
   while avail(r)!=tokens and time.monotonic()<limit:time.sleep(.005)
   after=avail(r);rest=os.read(r,after) if after else b'';os.close(r);os.close(wr);assert before==tokens==after and sorted(rest)==sorted(all_tokens)
   (emit/(tag+'.log')).write_bytes(so+se);assert q.returncode==0 and not so and not se,(tag,q.returncode,so,se)
   os.replace(out,file);data=file.read_bytes();rows[tag]={'capture':k,'original_product':original['original'],'original_sha256':original['sha256'],'arm':arm,'binary_sha256':sha(binary.read_bytes()),'captured_argv_sha256':sha(inp.read_bytes()),'capture_run_sha256':original['bundle_sha256'],'explicit_threads':False,'default_fork':True,'persistent_physical_slots':tokens,'implicit_slots':1,'jobserver_initial_bytes':all_tokens.hex(),'jobserver_restored_bytes':rest.hex(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'diagnostic_sha256':sha(so+se),'status':q.returncode,'elf':info(data)};write(meta,rows[tag]);outs[tag]=file;print(tag,rows[tag]['elf']['sha256'],rows[tag]['elf']['sh_entsize']['.rodata'],flush=True)
 # Compare complete files with mmap/C vectorized detection on large identical inputs.
 result={'rows':rows}
 def fast_diff(a,b):
  if a.read_bytes()==b.read_bytes():return []
  # Chunk-select in C; Python handles only changed 4096-byte pages.
  from elf import secs
  aa=a.read_bytes();bb=b.read_bytes();assert len(aa)==len(bb);ta=secs(aa);v=info(aa);lo=v['build_id_offset'];size=len(bytes.fromhex(v['build_id']));out=[]
  for i in range(0,len(aa),4096):
   x=aa[i:i+4096];y=bb[i:i+4096]
   if x==y:continue
   for j,(u,z) in enumerate(zip(x,y)):
    if u==z:continue
    off=i+j;out.append({'off':off,'a':u,'b':z,'build_id_payload':lo<=off<lo+size,'section_header_at':[(name,off-shoff) for name,q,shoff in ta if shoff<=off<shoff+64]})
  return out
 result['each_arm_AA']={arm:fast_diff(outs[f'{k}-{arm}-0'],outs[f'{k}-{arm}-7']) for arm in bins}
 result['same_setting_cross_arm']={str(t):fast_diff(outs[f'{k}-shipped-{t}'],outs[f'{k}-pr46-{t}']) for t in (0,7)};write(emit/(k+'-summary.json'),result)
