"""Freeze two independent high-parallelism confirmations before either checkout exists."""
from common import *
from datetime import datetime, timezone
import itertools
import random

base=json.loads((LAB/'default-v3.json').read_text())
four=json.loads((LAB/'registered-four-v3.json').read_text())
plan={k:four[k] for k in ['release','uv','cargo_pin','rustc_pin']}
plan.update(registered_utc=datetime.now(timezone.utc).isoformat(),
            discovery='default-v3 initial 16/24 and replica 18/24. These data selected the 32-core hypothesis and are excluded from all confirmatory rows. No cross-machine-size claim.',
            target_pool='r18-32-confirm',cpu=list(range(32)),endpoints=['test'],options=[],
            arms={'shipped':four['arms']['shipped'],**base['arms']},cohorts={},paired_blocks=36,
            primary='Only the ordinary full workspace cargo test --no-run at 32 available physical CPUs with no job flag. Both contrasts (scoped Wild vs shipped -18, and vs prior #46) must meet positive lower 95% median interval, sign p < .0125 and assignment-conditioned two-sided p < .0125 in each of two new checkout and target roots. The two discovery cohorts supply no scored comparisons. All 36 blocks are retained in each cohort. No extension or replacement based on results.')
for key,rel,shape,seed,prefix in [
    ('initial','confirm32/c-first','predicate',28322131,'CX'),
    ('replica','confirm32/independent-d/second-checkout','brew-help',28324623,'DX'),
]:
    root=ROOT/rel
    assert not root.exists()
    rng=random.Random(seed)
    orders=list(itertools.permutations(plan['arms']))*6
    rng.shuffle(orders)
    tags=list(range(10,46));rng.shuffle(tags)
    cfg=dict(root=str(root),cpu=list(range(32)),options=[],edit_shape=shape,endpoint_order=['test'],seed=seed,
             endpoints={'test':[dict(order=order,literal=f'{prefix}{n:02}') for n,order in zip(tags,orders)]})
    plan['cohorts'][key]=cfg
    assert all(sum(o[pos]==arm for o in orders)==12 for pos in range(3) for arm in plan['arms'])
with (LAB/'registered-32-heldout.json').open('x') as f:
    json.dump(plan,f,indent=2);f.write('\n')
print(sha(LAB/'registered-32-heldout.json'))
