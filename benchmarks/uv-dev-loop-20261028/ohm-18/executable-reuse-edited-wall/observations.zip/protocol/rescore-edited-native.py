"""Verify the saved uv command receipts, artifact equality, process traces and paired timings."""
import collections
import hashlib
import json
from pathlib import Path
import re
import sys

PROTOCOL = Path(__file__).resolve().parent
sys.path.insert(0, str(PROTOCOL))
import analyze


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def traced(directory, cargo, rustc, verify_uvx):
    wild = Path(rustc).parents[1] / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
    slots = {cargo:'cargo', rustc:'rustc', str(wild):'wild'}
    counts = collections.Counter()
    uvx_args = []
    for trace in directory.glob('exec.*'):
        for line in trace.read_text(errors='replace').splitlines():
            if not line.startswith('execve(') or not line.endswith('= 0'):
                continue
            binary = json.loads(re.match(r'execve\(("(?:[^"\\]|\\.)*")', line)[1])
            if binary in slots:
                counts[slots[binary]] += 1
                if verify_uvx and binary == rustc:
                    prefix = 'execve('+json.dumps(binary)+', '
                    args, _ = json.JSONDecoder().raw_decode(line[len(prefix):])
                    if ('--crate-name' in args and args[args.index('--crate-name')+1] == 'uvx'
                            and any(Path(x).as_posix().endswith('crates/uv/src/bin/uvx.rs') for x in args)):
                        uvx_args.append(hashlib.sha256(json.dumps(args).encode()).hexdigest())
            else:
                assert Path(binary).name not in {'cargo','rustc','rust-lld','ld','ld.bfd','wild','ld.lld'}, binary
    assert counts['cargo'] == 1 and counts['rustc'] >= 1
    return dict(counts), sorted(uvx_args)


def cell(directory, plan, cohort, ep, inputs, proof):
    schedule = plan['cohorts'][cohort]['endpoints'][ep]
    blocks = analyze.validate(directory, schedule)
    before, after = read(directory / 'admitted.json'), read(directory / 'done.json')
    assert after['rows'] == sha(directory / 'timings.csv')
    arms = plan['arms']
    assert set(before['arms']) == set(after['post']) == set(arms)
    ordered = []
    for block in blocks:
        for row in block:
            path = directory / f'm{int(row["block"]):02d}-{row["rank"]}-{row["arm"]}' / 'receipt.json'
            receipt = read(path)
            assert receipt['measured'] is True and receipt['roster'] == before['arms'][row['arm']]['roster']
            for key in ('utc_ns','elapsed_ns','seconds_user','seconds_system','voluntary_switches',
                        'involuntary_switches','input_blocks','output_blocks','major_faults','minor_faults'):
                assert str(receipt[key]) == row[key], (path,key)
            ordered.append((int(row['block']),int(row['rank']),row['arm']))
    external = [json.loads(line) for line in (directory / 'external-activity.jsonl').read_text().splitlines()]
    assert [tuple(record[1:4]) for record in external] == ordered
    quiet = [json.loads(line) for line in (directory / 'quiet.jsonl').read_text().splitlines()]
    assert len(quiet) >= 2 and quiet[-1][-1] == 2
    harness = {}
    for stage, source in [('admission',before['input_sha256']),('post',after['post_source'])]:
        products, programs, rosters, checks = [], [], [], []
        for arm in arms:
            path = directory / f'{stage}-{arm}'
            observed = read(path / 'receipt.json')
            assert not observed['measured'] and observed['roster'] == before['arms'][arm]['roster']
            assert len(observed['roster']['tests']) == (72 if ep == 'test' else 0)
            roles, uvx_args = traced(path, inputs['argv'][ep][0], inputs['compiler'], not proof)
            assert observed['roles'] == before['arms'][arm]['roles'] == roles
            if ep in plan.get('expected_roles',{}):
                assert plan['expected_roles'][ep][arm] == roles
            outputs = before['arms'][arm]['outputs'] if stage == 'admission' else after['post'][arm]
            assert observed['outputs'] == outputs and outputs
            products.append(outputs)
            rosters.append(observed['roster'])
            if proof:
                program = read(path / 'current-program.json')
                assert program['source_sha256'] == source
                programs.append((program['current_canonical_sha256'],program['behavior']))
            else:
                product = read(path / 'uvx-product.json')
                assert product['source_sha256'] == source and product['endpoint'] == ep
                assert uvx_args and sorted(product['frontend_argv_sha256']) == uvx_args
                assert re.fullmatch(r'[A-Z]{2}[0-9]{2}',product['literal'])
                if ep == 'check':
                    files = product['direct_check_outputs']
                    assert len(files) == 2 and {Path(n).suffix for n in files} == {'.d','.rmeta'}
                    assert all(re.fullmatch('[0-9a-f]{64}',v['sha256']) and v['size'] >= 0 for v in files.values())
                    checks.append(files)
                if ep == 'build':
                    assert product['diagnostic']['returncode'] == 2
                    assert product['diagnostic']['sha256'] == outputs['debug/uvx']
                    assert product['diagnostic']['stderr'].startswith(f"error: uvx could not launch uv [{product['literal']}]: Could not find the `uv` binary at ")
                if ep == 'test':
                    units = observed['raw_artifact_receipts']['uv_unit_ELFs']
                    (name, elf), = [(k,v) for k,v in units.items() if Path(k).name.startswith('uvx-')]
                    assert re.fullmatch('[0-9a-f]{64}',elf['raw_sha256']) and elf['size'] > 0
                    assert elf['canonical_sha256'] == outputs[name+'@stock-rodata-entsize-buildid']
                    harness.setdefault(stage,{})[arm] = {k:elf[k] for k in ('raw_sha256','canonical_sha256','size')}
        assert all(value == products[0] for value in products)
        assert all(value == rosters[0] for value in rosters)
        assert not programs or all(value == programs[0] for value in programs)
        assert not checks or all(value == checks[0] for value in checks)
    result = {'rows':len(ordered),'blocks':len(blocks),'foreign_samples':sum(bool(r[-1]) for r in external),
              'comparisons':{'stack-vs-base':analyze.compare(blocks,'base','stack')}}
    if 'shipped' in arms:
        result['comparisons']['stack-vs-shipped'] = analyze.compare(blocks,'shipped','stack')
    if harness:
        result['uvx_test_harness'] = harness
    return result


def main():
    root, study = Path(sys.argv[1]), sys.argv[2]
    proof = study == 'r18-proof-common-seed'
    assert proof or study == 'r18-uvx'
    protocol = root / 'protocol'
    plan_path = protocol / ('registered-proof.json' if proof else 'registered-uvx.json')
    plan = read(plan_path)
    results = {}
    for cohort, config in plan['cohorts'].items():
        folder = root / study / cohort
        inputs = read(folder / 'inputs.json')
        assert inputs['plan_sha256'] == sha(plan_path) and inputs['uv'] == plan['uv']
        assert inputs['release'] == 'ohm-1.99.0-18'
        results[cohort] = {ep:cell(folder / ep,plan,cohort,ep,inputs,proof) for ep in config['endpoints']}
    assert sum(cell['rows'] for co in results.values() for cell in co.values()) == (192 if proof else 540)
    print(json.dumps(results,indent=2))


if __name__ == '__main__':
    main()
