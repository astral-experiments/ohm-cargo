"""Run the prospectively frozen, separately parked native cohorts serially."""
from common import *
from datetime import datetime,timezone
stages=[
 ('r18-default-v3','default-v3.json','initial',list(range(8))),
 ('r18-default-v3','default-v3.json','replica',list(range(32))),
 ('r18-final','registered-four-v3.json','replica',list(range(16))),
 ('r18-final','registered-four-v3.json','initial',list(range(16))),
]
for study,file,cohort,cpus in stages:
    print(datetime.now(timezone.utc).isoformat(),study,cohort,'begin',flush=True)
    arg=','.join(map(str,cpus))
    subprocess.run(['taskset','-c',arg,sys.executable,'-E','-s','-u',str(LAB/'native.py'),cohort,'--study',study,'--plan',str(LAB/file)],check=True)
    print(datetime.now(timezone.utc).isoformat(),study,cohort,'finished',flush=True)
    with (LAB/(study+'-'+cohort+'-summary.json')).open('x') as f:
        subprocess.run([sys.executable,'-E','-s',str(LAB/'analyze.py'),str(LAB/file),str(LAB/study)],stdout=f,check=True)
