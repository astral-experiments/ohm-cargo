"""Resume fixed native assignments after byte-for-byte reproduction of stock ELF variability."""
from common import *
from datetime import datetime,timezone
import time

assert os.geteuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd'
stages=[
    ('r18-32-confirm','registered-32-heldout.json','initial'),
    ('r18-32-confirm','registered-32-heldout.json','replica'),
    ('r18-final','registered-four-v3.json','replica'),
    ('r18-final','registered-four-v3.json','initial'),
    ('r18-proof','registered-proof.json','initial'),
    ('r18-proof','registered-proof.json','replica'),
    ('r18-uvx','registered-uvx.json','initial'),
    ('r18-uvx','registered-uvx.json','replica'),
]
for study,pfile,cohort in stages:
    plan=json.loads((LAB/pfile).read_text());cfg=plan['cohorts'][cohort]
    cpus=cfg.get('cpu',plan['cpu'])
    base=LAB/study/cohort
    print(datetime.now(timezone.utc).isoformat(),study,cohort,'begin',flush=True)
    ready=Path(cfg['root'])/plan.get('target_pool',study)/'ready'
    while not ready.is_file():
        time.sleep(10)
    args=['taskset','-c',','.join(map(str,cpus)),sys.executable,'-E','-s','-u',str(LAB/'native-admitted.py'),cohort,'--study',study,'--plan',str(LAB/pfile)]
    if study=='r18-uvx':args.append('--uvx-source')
    if not all((base/ep/'done.json').exists() for ep in cfg['endpoints']):
        subprocess.run(args,check=True)
    print(datetime.now(timezone.utc).isoformat(),study,cohort,'finished',flush=True)
    summary=LAB/(study+'-'+cohort+'-summary.json')
    if not summary.exists():
        with summary.open('x') as f:subprocess.run([sys.executable,'-E','-s',str(LAB/'analyze.py'),str(LAB/pfile),str(LAB/study)],stdout=f,check=True)
