# Post-exit subreaper correction

The registered initial comparison finished all 24 pairs for the build and test-preparation commands on the first edit. Both original postflight checks completed. The worker exited zero. The dedicated Linux subreaper saw 297 adopted descendants and rejected the return before reaping them. Its pidfd history observed all 297 in state `Z`, under the same parent. Its termination loop excludes zombies from signals and reaped every remaining child. The original history did not save individual exit codes. Both endpoints failed their original statistical gates, so the two conditional wall studies are unselected regardless of the replica effect.

This amendment was prepared after those 96 unfiltered native rows and before the first replica command. It changes only post-exit custody. `initial-forensic.json` binds both real schedules, every source edit, the traced active binaries and roles, the original strict artifact and 72-test-executable checks, current program behavior, three restored original directory identities, two independently owned temporary clones, release slots, source bytes and mtimes. All original raw and guard outputs stay in place. `controller.diff` and `raw_effective.diff` show the limited substitutions compared with the previous sealed code. No initial timing entry point exists.

## Running the two authorized transitions

Use the ordinary host account on guardian CPU 31. Set `OHM_PROOF_REAPER_SHA256` to this directory's `amendment.json` SHA. Retain `OHM_PROOF_PATH_SHA256=fcd5d7b53f5568bf8da0bd52c36e4bf28901bbb95ea5b3fbd3e22b8f12084727` and `OHM_PROOF_TIMESTAMP_SHA256=7342843e38d570558219d15a29155015e6052ab1478e6ea89d436a9514e11077` for the unchanged path-view worker. All real operations keep its original coordinator markers, native lease, current host release and the 120 GiB floor. The coordinator must issue a fresh exact JSON grant before each operation. `grant` only prints the expected content.

```sh
python3 -I -B run.py preflight
python3 -I -B run.py grant initial
# Coordinator independently installs the verified output as grant-initial.json.
taskset -c 31 python3 -I -B run.py finalize-initial
python3 -I -B run.py effective-return initial
# The original separately named coordinator-release-replica.json must also be issued.
python3 -I -B run.py grant replica
# Coordinator independently installs the verified output as grant-replica.json.
taskset -c 31 python3 -I -B run.py run-replica
python3 -I -B run.py effective-return replica
python3 -I -B run.py seal-eligibility
```

The initial operation can only retire the two named disposable clones after it checks their exact device, inode, owner, mount status and lack of users. Its per-clone intent binds both full registered completion digests. A partial or interrupted retirement can resume using the same immutable grant and recognized journals. Both stock banks, active target, Cargo, Wild and sources are read-only in that operation. Its positive effective receipt is `execution/initial/returned.json` here. The first failed disposition remains at `../proof-common-seed-path-view/execution/initial/returned.json`.

The replica uses the identical original native worker, command, arms, paths, edits, ordering, sample size, quiet gate, scoring and postflight. After the worker exits zero, the guardian pins first-observed zombies using pidfds, tests each status with non-consuming `waitid`, records its actual termination status, then reaps and requires an empty child set. A live or stopped child, a changing roster or a nonzero leader still fails. The original replica receipt path is `../proof-common-seed-path-view/execution/replica/returned.json`. A new `zombie-reap.json` next to it records every child observation and termination status. Funds, scores or role requirements are not inferred from successful custody.

`effective-return` independently revalidates the raw cells and actual restored physical ownership. `report` binds the original failure and both final receipts. `seal-eligibility` writes the existing canonical `../proof-common-seed/execution/supplemental-eligibility.json` only after two complete cohorts. `counter_hook.validate_evidence(decision=None)` and `run.py verify-terminal [decision.json]` leave the old independent terminal adapter intact and resolve the initial positive return through this correction. Counter launchers still require the separate retired host marker, task authority, pauses and storage guard. All 11 synthetic tests run without Cargo, the real fixture or a real benchmark grant.
