#!/usr/bin/env python3
"""Recompute every correctness cell using only this packet's raw files."""
import hashlib
import json
from pathlib import Path
import re
import shlex

ROOT = Path(__file__).resolve().parent
PARENT = ROOT / 'work/round18-compiler'
V2 = PARENT / 'proof-native-ffi-v2'
DATA = V2 / 'observed/second'


def check(condition, reason):
    if not condition:
        raise ValueError(str(reason))


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def objects(data):
    for line in data.splitlines():
        try:
            yield json.loads(line)
        except ValueError:
            pass


def compiler_args(data):
    calls = []
    for line in data.decode().splitlines():
        if 'Running `' in line and line.endswith('`'):
            argv = shlex.split(line.split('Running `', 1)[1][:-1])
            if '--crate-name' in argv:
                calls.append(argv)
    return calls


def audit_arm(mode, endpoint, arm, seed_source):
    cell = DATA / f'{mode}-{endpoint}-{arm}'
    rows = []
    for phase in ('seed', 'edit', 'control/cold'):
        folder = cell / phase
        program = read(folder / 'program.json')
        obs = read(folder / 'observation.json')
        check(read(folder / 'exit.json') == program['exit'] == 0, (cell, phase, 'exit'))
        raw = (folder / 'program.stdout').read_bytes()
        values = re.findall(rb'\bobserved=(\d+)\b', raw)
        check(len(values) == 1 and int(values[0]) == obs['value'], (cell, phase, 'stdout'))
        src = seed_source if phase == 'seed' else seed_source.replace(b'    1\n', b'    2\n')
        check(digest(src) == obs['source_sha256'], (cell, phase, 'library source'))
        active = {x['executable'] for x in objects((folder/'cargo.stdout').read_bytes())
                  if x.get('reason') == 'compiler-artifact' and x.get('target', {}).get('name') == 'side'}
        check(active == {program['argv'][0]} and obs['program_sha256'] == program['sha256'], (cell, phase, 'active image'))
        check(program['argv'][1:] == (['--nocapture', '--test-threads=1'] if endpoint == 'test' else []), 'probe argv')
        argv = compiler_args((folder / 'cargo.stderr').read_bytes())
        check(argv == read(folder/'cargo-rustc-argv.json'), (cell, phase, 'Cargo rustc trace'))
        commands = [a for a in argv if a[a.index('--crate-name') + 1] == 'side']
        check(len(commands) == obs['side_rustc_argv_count'], (cell, phase, 'role count'))
        if arm == 'proof' and mode in ('wrapped', 'transitive-search'):
            cache = (folder/'active-manifest.json').read_bytes()
            witness = obs['manifests']
            check(len(witness) == 1 and 'proofself' in json.loads(cache)['unused_extern_names']
                  and digest(cache) == witness[0]['sha256'], (cell, phase, 'genuine cache bytes'))
        if mode == 'wrapped':
            forwarded = []
            reports = []
            for descriptor in (folder/'rustc-wrapper').glob('*.json'):
                w = read(descriptor)
                if w['native']:
                    archive = w['native']['native_archive']
                    check(w['exit'] == 0 and w['forwarded'] == w['received'] + ['--cfg=wrapper_native','-C',f'link-arg={archive}'], 'wrapper changed additional arguments')
                    check({str(Path(f).with_suffix('.rlib')) for f in w['native']['cargo_externs']} == {archive}, 'wrapper consumed other archive')
                    forwarded.append(w)
                    reports += [m['unused_extern_names'] for m in objects(descriptor.with_suffix('.stderr').read_bytes())
                                if m.get('$message_type') == 'unused_extern']
            check(len(forwarded) == len(commands) == obs['wrapped_side_calls'] and reports == obs['raw_unused_reports'], 'wrapper trace mismatch')
            if arm == 'proof' and phase != 'edit':
                check(any('proofself' in names for names in reports), 'missing real rustc diagnostic')
        if mode in ('transitive-search','own-search') and phase != 'edit':
            alias = read((folder.parent if phase == 'control/cold' else cell) / 'native-alias.json')
            externs = {str(Path(v.partition('=')[2]).with_suffix('.rlib')) for a in commands
                       for i, s in enumerate(a) if s == '--extern' for v in [a[i+1]]
                       if v.partition('=')[0].split(':')[-1] == 'proofself'}
            check(externs == {alias['archive']} and obs['native_archive'] == alias['archive'], 'unrelated native archive')
        rows.append((int(values[0]), program['sha256'], obs['native_sha256'], commands))
    seed, edit, cold = rows
    check(seed[0] == 1 and cold[0] == 2 and edit[0] in (1,2), 'invalid controls')
    if mode != 'plain':
        check(seed[2] != edit[2], 'native archive was unchanged')
    if edit[0] == 1:
        check(edit[1] == seed[1] and not edit[3], 'old value without intact previous executable')
    else:
        check(edit[1] != seed[1] and len(edit[3]) == 1 and 'link-only' in edit[3][0], 'missing matched real relink')
    return [r[0] for r in rows]


def main():
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ',1)
        path = ROOT / name
        check(path.resolve().is_relative_to(ROOT) and path.is_file() and digest(path.read_bytes()) == expected, name)
    original = PARENT/'proof-native-ffi'
    p1 = read(original/'plan.json')
    p2 = read(V2/'plan.json')
    check(p2['prior_registration'] == digest((original/'plan.json').read_bytes()), 'prior source protocol')
    for directory, plan in [(original,p1),(V2,p2)]:
        for name, h in plan['files'].items():
            check(digest((directory/name).read_bytes()) == h, name)
    prior = (original/'observed/first/summary.json').read_bytes()
    check(digest(prior) == p2['first_attempt_summary'] and len(json.loads(prior)['failed_to_admit']) == 12, 'first-attempt exclusion')
    summary = read(DATA/'summary.json')
    check(summary['failed_to_admit'] == {}, 'v2 failed condition')
    seed_source = (V2/'fixture/src/lib.rs').read_bytes()
    divergences = 0
    for mode in ('wrapped','transitive-search','plain','own-search'):
        for endpoint in ('build','test'):
            base = audit_arm(mode,endpoint,'base',seed_source)
            proof = audit_arm(mode,endpoint,'proof',seed_source)
            stale = base == [1,2,2] and proof == [1,1,2]
            check(stale == summary['outcomes'][f'{mode}-{endpoint}']['differential_stale'], 'recorded decision changed')
            check(stale == (mode in ('wrapped','transitive-search')), 'unexpected condition')
            divergences += stale
            print(f'{mode:18} {endpoint:5}  base {base}  proof {proof}')
    check(divergences == 4, 'expected four differential stale cases')
    print('Verified 48 program observations across 16 cells; four stale comparisons and four controls.')


if __name__ == '__main__':
    main()
