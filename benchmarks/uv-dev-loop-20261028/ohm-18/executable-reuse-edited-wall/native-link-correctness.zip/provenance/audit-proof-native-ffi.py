"""Verify every program oracle and read the native library search paths in the real uvx compiles."""
import hashlib
import json
from pathlib import Path
import re

LAB = Path(__file__).resolve().parent
FIXTURE = LAB.parent/'round18-compiler/proof-native-ffi-v2'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    observed = FIXTURE/'observed/second'
    assert digest(FIXTURE/'plan.json') == 'e0b45d0c986d90eac39fb0951ac18cb4ec3cb9d4dc7768d2c9344f5cad6a1ddd'
    summary = read(observed/'summary.json')
    assert not summary['failed_to_admit'] and len(summary['outcomes']) == 8
    cases = {}
    for mode in ('wrapped','plain','transitive-search','own-search'):
        for ep in ('build','test'):
            case = mode+'-'+ep
            for arm in ('base','proof'):
                root = observed/(case+'-'+arm)
                result = read(root/'result.json')
                failures = arm == 'proof' and mode in ('wrapped','transitive-search')
                values = []
                for phase,folder in [('seed',root/'seed'),('edit',root/'edit'),('cold',root/'control/cold')]:
                    stdout = (folder/'program.stdout').read_bytes()
                    value, = re.findall(rb'\bobserved=(\d+)\b',stdout)
                    program = read(folder/'program.json')
                    obs = read(folder/'observation.json')
                    assert program['exit'] == 0 and obs['program_sha256'] == program['sha256']
                    assert obs == result[phase] and obs['value'] == int(value)
                    values.append(int(value))
                assert values == [1,1 if failures else 2,2] and result['stale'] == failures
                assert summary['outcomes'][case][arm+'_stale'] == failures
                if failures:
                    a,b = result['seed'],result['edit']
                    assert a['source_sha256'] != b['source_sha256'] and a['native_sha256'] != b['native_sha256']
                    assert a['program_sha256'] == b['program_sha256'] and b['side_rustc_argv_count'] == 0
                    m, = a['manifests']
                    assert 'proofself' in m['unused']
                    if mode == 'wrapped':
                        assert any('proofself' in names for names in a['raw_unused_reports'])
                cases[case+'-'+arm] = values
    flags = {}
    for co in ('initial','replica'):
        for phase in ('admission','post'):
            for arm in ('shipped','base','stack'):
                cell = LAB/'r18-uvx'/co/'build'/(phase+'-'+arm)
                rustc = read(cell.parent.parent/'inputs.json')['compiler']
                prefix = 'execve('+json.dumps(rustc)+', '
                calls = []
                for trace in cell.glob('exec.*'):
                    for line in trace.read_text(errors='replace').splitlines():
                        if line.startswith(prefix) and line.endswith('= 0'):
                            argv, _ = json.JSONDecoder().raw_decode(line[len(prefix):])
                            if '--crate-name' in argv and argv[argv.index('--crate-name')+1] == 'uvx':
                                calls.append([argv[i+1] for i,v in enumerate(argv[:-1]) if v=='-L' and argv[i+1].startswith('native=')])
                paths, = calls
                packages = sorted(p.split('/debug/build/',1)[1].split('/',1)[0] for p in paths)
                assert packages == ['aws-lc-sys','tikv-jemalloc-sys','zstd-sys']
                flags[f'{co}/{phase}/{arm}'] = packages
    print(json.dumps(dict(state='withdrawn',plan_sha256=digest(FIXTURE/'plan.json'),summary_sha256=digest(observed/'summary.json'),
                          ordinary_program_oracles=24,test_harness_oracles=24,cases=cases,uv_native_search_paths=flags),indent=2))


if __name__=='__main__':
    main()
