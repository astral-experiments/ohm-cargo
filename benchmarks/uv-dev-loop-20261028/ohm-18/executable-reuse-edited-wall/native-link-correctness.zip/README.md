# Cargo retained a stale native executable after an unused Rust extern changed

Changing a package library’s exported C-ABI function from `1` to `2` produced a stale executable with the experimental Cargo executable-reuse patch. Both programs exited successfully. The patched Cargo reused the previous binary byte-for-byte, and it printed `1`. A clean build of the same source printed `2`. The matched unpatched Cargo performed an ordinary link-only rebuild and printed `2`.

| How the binary consumes its package library | `cargo build --bin side` base → patched | `cargo test --no-run --bin side` base → patched |
| --- | --- | --- |
| Wrapper passes the package rlib as an additional native linker input | `1/2/2` → **`1/1/2`** | `1/2/2` → **`1/1/2`** |
| Dependency build script supplies a native search path, Rust source uses `#[link]`, no wrapper | `1/2/2` → **`1/1/2`** | `1/2/2` → **`1/1/2`** |
| Rust source calls the package function directly, no wrapper | `1/2/2` → `1/2/2` | `1/2/2` → `1/2/2` |
| Owning package supplies the same native search path and Rust source uses `#[link]`, no wrapper | `1/2/2` → `1/2/2` | `1/2/2` → `1/2/2` |

The three values are the initial executable, the executable returned after an in-place library edit, and a fresh build from the edited source. All 48 program executions and their Cargo commands exited zero. For `test --no-run`, a separate invocation of the tiny probe harness observed the compiled product’s behavior. The table contains correctness observations and no timing endpoints.

In the native-search cases a fixed symbolic link references the precise package rlib that Cargo gave rustc. The rlib’s content changed while the alias stayed fixed. In the wrapped cases the wrapper forwards the original `--extern`, adds that same rlib to the native link, and forwards the compiler’s output unmodified. Rustc genuinely reported the Rust extern unused in the wrapped patched seed and clean builds. In all four stale cases the patched Cargo made zero `side` compiler/link calls after the edit. All matched controls performed one real cached-codegen relink.

The existing integration-test workspace-library check walks Rust dependency edges and inspects the build scripts exclusive to each otherwise-unused workspace dependency. Cargo has a dedicated integration test for a transitive native archive. The experimental bin extension selects the separate self-library shortcut. It checks the owning package’s native directives while Cargo forwards `-L` from all relevant packages. The wrapper case additionally bypasses Cargo’s view of command-line linker flags. These reproductions cover the normal bin and its harness on the -18 Cargo pin. They establish neither a release-19 result nor the behavior of every existing integration-test path. The current `#279` and `#280` address propagated metadata and failed builds respectively. Every Cargo build in the completed fixture succeeded. [Pinned Cargo compiler logic](https://github.com/astral-sh/ohm-cargo/blob/7caf39914da1e28a67744ecbc963a5f26361474d/src/compiler/mod.rs#L968), [integration transitive-native regression](https://github.com/astral-sh/ohm-cargo/blob/7caf39914da1e28a67744ecbc963a5f26361474d/tests/testsuite/freshness.rs#L6631), [#279](https://github.com/astral-sh/ohm-cargo/pull/279), [#280](https://github.com/astral-sh/ohm-cargo/pull/280).

The independent uv argv audit in `provenance/executable-proof-native-ffi-verdict.json` found native search paths from `zstd-sys`, `aws-lc-sys` and `tikv-jemalloc-sys` in all 12 inspected `uvx` compiler commands across two checkout paths and three toolchain arms. Rejecting every transitive native search path would also reject these measured `uvx` builds. That rules out transferring the original candidate’s performance measurements to such a guard.

## Verify the captured results

Extract the archive into an empty directory and run the following command on Python 3.11 or later. It independently checks the SHA manifest, both frozen study descriptions, every Cargo/program exit and observed value, advertised executable identity, raw `side` command lines, genuine wrapped compiler messages, active manifest digests and the old/new executable and archive digests. This path reads only the extracted evidence.

```sh
python3 rescore.py
```

`work/round18-compiler/proof-native-ffi-v2/observed/second` contains the complete results. The initial attempt in the adjacent `proof-native-ffi/observed/first` directory exited 2. Its four plain driver cells completed. The twelve native driver cells stopped at fixture assumptions about Ohm’s split target directory and duplicate `.rlib` / `.rmeta` arguments for the same package. The second, separately sealed run restored the same state gates and verified the two argument stems, archive and executable aliases against the first attempt’s real traces before running. Its driver exited zero. All first-attempt raw records are retained.

## Run the fixture with real tools

The original paired Cargo pin was `7caf39914da1e28a67744ecbc963a5f26361474d` from Ohm 1.99.0-18 on x86-64 Linux. The only production delta is `provenance/proof.patch` (SHA-256 `3d0afc4e51136eb3edc39d1059dd9fd9dd647924206ce85fc6eb84253a5cd924`). `provenance/bare-driver-ready.json` records the source, three affected file hashes before/after, original build features, and the original matched Cargo image hashes. The latter were `df678a74…` for base and `927d8f43…` for proof. The archive contains source and raw observations only.

Use the original two Cargo images if available. Alternatively, use two local checkouts of `astral-sh/ohm-cargo` at the exact pin, apply `git apply /path/to/provenance/proof.patch` only to the second checkout and build both `cargo` binaries with the same official -18 rustc, release profile and `ohm-defaults,all-static` features. With locally rebuilt images pass `--base-source` and `--proof-source` pointing to the respective checkouts. The portable driver checks the upstream commit, full tracked-file delta and touched source byte hashes. It records actual driver hashes/version and distinguishes source-matched rebuilds from the original images. Install the official -18 Linux toolchain with its shipped Wild linker.

```sh
chmod +x work/round18-compiler/proof-native-ffi-v2/wrapper.py
python3 replay.py --base /path/to/base/cargo --proof /path/to/patched/cargo \
  --toolchain /path/to/installed/ohm-1.99.0-18 --dest /tmp/fresh-ffi-replay
```

For the smallest independent demonstration, append `--mode transitive-search --endpoint build`. Every execution gets an absent destination, distinct writable targets for both source arms, and freshly compiled cold controls. The recorded subprocess environments contain only the explicit study tool paths, scratch homes, locale and Cargo settings. No compiler binaries or target directories are included.
