#!/usr/bin/env python3
"""Run the frozen v2 fixture with two supplied drivers on a fresh Linux scratch root."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
HERE = ROOT / 'work/round18-compiler/proof-native-ffi-v2'
sys.path.insert(0, str(HERE))
import run


def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args], text=True).strip()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('base','proof','toolchain','dest'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--base-source', type=Path)
    p.add_argument('--proof-source', type=Path)
    p.add_argument('--mode', nargs='+', choices=run.MODES, default=run.MODES)
    p.add_argument('--endpoint', nargs='+', choices=run.ENDPOINTS, default=run.ENDPOINTS)
    args = p.parse_args()
    plan = run.load(HERE / 'plan.json')
    source = run.load(ROOT / 'provenance/bare-driver-ready.json')
    for f, expected in plan['files'].items():
        run.check(run.sha(HERE/f) == expected, f)
    run.check(os.access(HERE/'wrapper.py', os.X_OK), 'chmod +x work/round18-compiler/proof-native-ffi-v2/wrapper.py')
    run.DIST = args.toolchain.resolve()
    run.RUSTC = run.DIST / 'bin/rustc'
    run.WILD = run.DIST / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
    run.DRIVERS = {'base': args.base.resolve(), 'proof': args.proof.resolve()}
    run.check(run.sha(run.RUSTC) == plan['tools']['rustc'] and run.sha(run.WILD) == plan['tools']['wild'], 'expected the shipped x86_64 Linux -18 compiler and Wild')
    dest = args.dest.resolve()
    run.check(not dest.exists(), 'choose a previously absent destination')
    identities = {}
    for arm, exe in run.DRIVERS.items():
        actual = run.sha(exe)
        tree = getattr(args, arm + '_source')
        if actual != plan['tools'][arm]:
            run.check(tree is not None and git(tree, 'rev-parse','HEAD') == plan['cargo_pin'], f'supply matching --{arm}-source for a locally rebuilt driver')
            expected = source['before' if arm == 'base' else 'after']
            changed = set(git(tree, 'diff', '--name-only', 'HEAD').splitlines())
            run.check(changed == (set() if arm == 'base' else set(expected)), f'unexpected tracked {arm} source changes: {changed}')
            for relative, digest in expected.items():
                run.check(run.sha(tree/relative) == digest, f'unexpected {arm} source in {relative}')
        version = subprocess.check_output([str(exe), '-Vv'], text=True)
        identities[arm] = {'path':str(exe),'sha256':actual,'exact_original_image':actual == plan['tools'][arm],
                           'verified_source':str(tree.resolve()) if tree else None,'version':version}
    dest.mkdir(parents=True)
    evidence = dest / 'observed'
    evidence.mkdir()
    run.put(evidence/'replay-inputs.json', {'drivers':identities,'compiler':str(run.RUSTC), 'compiler_sha256':run.sha(run.RUSTC),
             'wild_sha256':run.sha(run.WILD),'frozen_plan_sha256':run.sha(HERE/'plan.json')})
    for endpoint in args.endpoint:
        for mode in args.mode:
            values = {}
            for arm in run.DRIVERS:
                row = run.run_arm(dest/'private',evidence,arm,mode,endpoint)
                values[arm] = [row[x]['value'] for x in ('seed','edit','cold')]
            print(mode,endpoint,json.dumps(values),flush=True)


if __name__ == '__main__':
    main()
