#!/usr/bin/python3
"""Correctness-only reproduction. This never invokes Cargo without the study grant."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tomllib
import traceback

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
DIST = WORK / 'upstream-monitor/toolchain18'
RUSTC = DIST / 'bin/rustc'
WILD = DIST / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
DRIVERS = {'base': WORK / 'round18-cargo/fast/bin/base', 'proof': HERE.parent / 'bare-proof-driver/cargo'}
MODES = ('wrapped', 'plain', 'transitive-search', 'own-search')
ENDPOINTS = ('build', 'test')
SEED = (HERE / 'fixture/src/lib.rs').read_bytes()
EDIT = SEED.replace(b'    1\n', b'    2\n')


def check(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def put(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def load(path):
    return json.loads(path.read_text())


def events(output):
    for line in output.splitlines():
        try:
            yield json.loads(line)
        except ValueError:
            continue


def cargo_rustc_argv(stderr):
    argv = []
    for line in stderr.decode(errors='replace').splitlines():
        if 'Running `' in line and line.endswith('`'):
            args = shlex.split(line.split('Running `', 1)[1][:-1])
            if '--crate-name' in args:
                argv.append(args)
    return argv


def instance(work, case, library):
    src = work / case / 'crate'
    shutil.copytree(HERE / 'fixture', src)
    (src / 'src/lib.rs').write_bytes(library)
    home = src.parent / 'home'
    home.mkdir()
    return src, {
        'PATH': f'{DIST}/bin:/usr/bin:/bin', 'HOME': str(home), 'LANG': 'C', 'LC_ALL': 'C',
        'CARGO_HOME': str(home / '.cargo'), 'CARGO_TARGET_DIR': str(src.parent / 'target'),
        'RUSTC': str(RUSTC), 'CARGO_LOG': 'cargo::compiler=info', 'TERM': 'dumb',
    }


def invoke(cargo, src, env, mode, args, phase):
    phase.mkdir()
    env = dict(env)
    if mode == 'wrapped':
        logs = phase / 'rustc-wrapper'
        logs.mkdir()
        env.update(RUSTC_WRAPPER=str(HERE / 'wrapper.py'), FFI_REPRO_WRAPPER_LOG=str(logs))
    argv = [str(cargo), '-Zohm-defaults', *args, '--package', 'ffi-reuse-repro',
            '--locked', '--offline', '-j2', '-vv', '--color=never', '--message-format=json']
    if mode in ('transitive-search', 'own-search'):
        argv += ['--features', mode]
    put(phase / 'command.json', {'argv': argv, 'cwd': str(src), 'env': env})
    p = subprocess.run(argv, cwd=src, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (phase / 'cargo.stdout').write_bytes(p.stdout)
    (phase / 'cargo.stderr').write_bytes(p.stderr)
    put(phase / 'exit.json', p.returncode)
    put(phase / 'cargo-rustc-argv.json', cargo_rustc_argv(p.stderr))
    check(p.returncode == 0, f'Cargo exited {p.returncode}: {phase}/cargo.stderr')
    return list(events(p.stdout))


def native_search(cargo, src, env, mode, path):
    if mode not in ('transitive-search', 'own-search'):
        return None
    invoke(cargo, src, env, mode, ['build', '--lib'], path / 'bootstrap')
    archives = list((Path(env['CARGO_TARGET_DIR']) / 'debug/deps').glob('libproofself-*.rlib'))
    check(len(archives) == 1, f'unexpected package archives {archives}')
    directory = src / 'native-search/native'
    directory.mkdir()
    symlink = directory / 'libproof_native.a'
    symlink.symlink_to(archives[0])
    put(path / 'native-alias.json', {'path': str(symlink), 'archive': str(archives[0]), 'before': sha(archives[0])})
    return archives[0]


def collect(cargo, src, env, arm, mode, endpoint, path, phase, native_input):
    folder = path / phase
    args = [endpoint]
    if endpoint == 'test':
        args.append('--no-run')
    messages = invoke(cargo, src, env, mode, args + ['--bin', 'side'], folder)
    products = {m['executable'] for m in messages if m.get('reason') == 'compiler-artifact'
                and m.get('target', {}).get('name') == 'side' and m.get('executable')}
    check(len(products) == 1, f'expected one reported side executable, got {products}')
    product = Path(products.pop())
    command = [str(product)] + (['--nocapture', '--test-threads=1'] if endpoint == 'test' else [])
    run = subprocess.run(command, cwd=src, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (folder / 'program.stdout').write_bytes(run.stdout)
    (folder / 'program.stderr').write_bytes(run.stderr)
    put(folder / 'program.json', {'argv': command, 'exit': run.returncode, 'sha256': sha(product)})
    values = re.findall(rb'\bobserved=(\d+)\b', run.stdout)
    check(run.returncode == 0 and len(values) == 1, f'program oracle failed at {folder}')
    manifests = []
    for f in (Path(env['CARGO_TARGET_DIR']) / 'debug/deps').glob('side-*.rlink-cache.json'):
        body = load(f)
        if os.path.samefile(body['executable']['path'], product):
            (folder / 'active-manifest.json').write_bytes(f.read_bytes())
            manifests.append({'path': str(f), 'sha256': sha(f), 'unused': body.get('unused_extern_names')})
    check(len(manifests) <= 1, f'ambiguous side manifest: {manifests}')
    side_args = [argv for argv in load(folder / 'cargo-rustc-argv.json')
                 if argv[argv.index('--crate-name') + 1] == 'side']
    witness = []
    wrapped = []
    if mode == 'wrapped':
        for f in (folder / 'rustc-wrapper').glob('*.json'):
            row = load(f)
            if row['native']:
                wrapped.append(row)
                witness.extend(m['unused_extern_names'] for m in events(f.with_suffix('.stderr').read_bytes())
                               if m.get('$message_type') == 'unused_extern')
        if phase in ('seed', 'cold') and arm == 'proof':
            check(any('proofself' in names for names in witness), f'no real unused Rust extern diagnostic in {folder}')
    if native_input is not None and phase in ('seed', 'cold'):
        archive_alias = (src / 'native-search/native/libproof_native.a').resolve(strict=True)
        effective = {Path(spec.partition('=')[2]).with_suffix('.rlib') for argv in side_args
                     for i, arg in enumerate(argv) if arg == '--extern' for spec in [argv[i + 1]]
                     if spec.partition('=')[0].split(':')[-1] == 'proofself'}
        check(archive_alias == native_input and effective == {native_input},
              f'the native alias {archive_alias} did not match the package archives {effective} at {folder}')
    if arm == 'proof' and phase in ('seed', 'cold') and mode in ('wrapped', 'transitive-search'):
        check(len(manifests) == 1 and 'proofself' in (manifests[0]['unused'] or []), f'no active unused-extern witness at {folder}')
    result = {'value': int(values[0]), 'program': str(product), 'program_sha256': sha(product),
              'source_sha256': sha(src / 'src/lib.rs'), 'side_rustc_argv_count': len(side_args),
              'wrapped_side_calls': len(wrapped), 'raw_unused_reports': witness, 'manifests': manifests,
              'native_archive': str(native_input) if native_input else None,
              'native_sha256': sha(native_input) if native_input else None}
    if wrapped:
        archives = {row['native']['native_archive'] for row in wrapped}
        check(len(archives) == 1, 'inconsistent wrapped native input')
        archive = Path(archives.pop())
        result.update(native_archive=str(archive), native_sha256=sha(archive))
    put(folder / 'observation.json', result)
    return result


def run_arm(work, evidence, arm, mode, endpoint):
    key = f'{mode}-{endpoint}-{arm}'
    path = evidence / key
    path.mkdir()
    cargo = DRIVERS[arm]
    src, env = instance(work, key, SEED)
    native = native_search(cargo, src, env, mode, path)
    seed = collect(cargo, src, env, arm, mode, endpoint, path, 'seed', native)
    library = src / 'src/lib.rs'
    check(library.read_bytes() == SEED, 'unplanned source edit')
    library.write_bytes(EDIT)
    edit = collect(cargo, src, env, arm, mode, endpoint, path, 'edit', native)
    if mode == 'wrapped':
        archive = Path(seed['native_archive'])
        edit.update(native_archive=str(archive), native_sha256=sha(archive))
        put(path / 'edit/observation.json', edit)
    if mode != 'plain':
        check(seed['native_sha256'] != edit['native_sha256'], 'the actual native input never changed')
    clean_path = path / 'control'
    clean_path.mkdir()
    cold_src, cold_env = instance(work, key + '-cold', EDIT)
    cold_native = native_search(cargo, cold_src, cold_env, mode, clean_path)
    cold = collect(cargo, cold_src, cold_env, arm, mode, endpoint, clean_path, 'cold', cold_native)
    check(seed['value'] == 1 and cold['value'] == 2, 'seed/freshly built oracle disagreement')
    check(edit['value'] in (1, 2), 'unrecognized rebuilt value')
    result = {'case': key, 'seed': seed, 'edit': edit, 'cold': cold,
              'stale': edit['value'] != cold['value']}
    put(path / 'result.json', result)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--attempt')
    p.add_argument('--mode', nargs='+', choices=MODES, default=MODES)
    p.add_argument('--endpoint', nargs='+', choices=ENDPOINTS, default=ENDPOINTS)
    args = p.parse_args()
    check(len(SEED) == len(EDIT) and SEED != EDIT and SEED.count(b'    1\n') == 1, 'invalid fixture edit')
    if args.self_test:
        sys.path.insert(0, str(HERE))
        from wrapper import command
        argv = ['/fake/rustc', '--crate-name', 'side', '--extern', 'proofself=/x/libproofself-q.rlib']
        forwarded, native = command(argv)
        assert forwarded[-3:] == ['--cfg=wrapper_native', '-C', 'link-arg=/x/libproofself-q.rlib']
        assert native['native_archive'] == '/x/libproofself-q.rlib'
        assert command(['/fake/rustc', '--print=sysroot'])[1] is None
        assert cargo_rustc_argv(b'       Running `/x/rustc --crate-name side --extern proofself=/x/a.rlib`')[0] == ['/x/rustc','--crate-name','side','--extern','proofself=/x/a.rlib']
        for name in ('Cargo.toml', 'Cargo.lock', 'native-search/Cargo.toml'):
            tomllib.loads((HERE / 'fixture' / name).read_text())
        print('synthetic passed; no toolchain executed')
        return
    plan = load(HERE / 'plan.json')
    check(os.getenv('FFI_REPRO_HOST_RELEASE') == sha(HERE / 'plan.json'), 'no explicit study-specific coordinator grant')
    check(args.attempt and re.fullmatch(r'[a-z0-9-]+', args.attempt), 'supply a fresh attempt name')
    for rel, digest in plan['files'].items():
        check(sha(HERE / rel) == digest, f'changed study input {rel}')
    for key, binary in {**DRIVERS, 'rustc': RUSTC, 'wild': WILD}.items():
        check(sha(binary) == plan['tools'][key], f'unmatched {key}')
    scratch = Path((WORK / 'bench-home.path').read_text().strip()) / 'proof-native-ffi' / args.attempt
    evidence = HERE / 'observed' / args.attempt
    check(not scratch.exists() and not evidence.exists(), 'attempt already exists')
    scratch.mkdir(parents=True)
    evidence.mkdir(parents=True)
    put(evidence / 'inputs.json', {'plan': sha(HERE / 'plan.json'), 'scratch': str(scratch),
        'tools': plan['tools'], 'mode': args.mode, 'endpoint': args.endpoint, 'affinity': sorted(os.sched_getaffinity(0))})
    outcomes = {}
    failures = {}
    for endpoint in args.endpoint:
        for mode in args.mode:
            arms = {}
            for arm in DRIVERS:
                try:
                    arms[arm] = run_arm(scratch, evidence, arm, mode, endpoint)
                    print(arms[arm]['case'], [arms[arm][s]['value'] for s in ('seed', 'edit', 'cold')], flush=True)
                except Exception:
                    failures[f'{mode}-{endpoint}-{arm}'] = traceback.format_exc()
                    print(failures[f'{mode}-{endpoint}-{arm}'], file=sys.stderr, flush=True)
            if len(arms) == 2:
                outcomes[f'{mode}-{endpoint}'] = {'base_stale': arms['base']['stale'], 'proof_stale': arms['proof']['stale'],
                    'differential_stale': not arms['base']['stale'] and arms['proof']['stale']}
            put(evidence / 'summary.json', {'outcomes': outcomes, 'failed_to_admit': failures})
    if failures:
        sys.exit(2)


if __name__ == '__main__':
    main()
