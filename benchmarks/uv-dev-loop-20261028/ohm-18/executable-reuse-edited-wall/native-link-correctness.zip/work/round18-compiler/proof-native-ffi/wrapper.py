#!/usr/bin/python3
"""A compiler wrapper that exposes the selected Rust archive to a C-ABI caller."""
import json
import os
from pathlib import Path
import subprocess
import sys


def command(incoming):
    result = list(incoming)
    if '--crate-name' not in incoming or incoming[incoming.index('--crate-name') + 1] != 'side':
        return result, None
    externs = [incoming[i + 1] for i, arg in enumerate(incoming) if arg == '--extern']
    paths = [Path(spec.partition('=')[2]) for spec in externs if spec.partition('=')[0].split(':')[-1] == 'proofself']
    if len(paths) != 1:
        raise ValueError(f'expected one package lib, got {paths}')
    archive = paths[0].with_suffix('.rlib')
    result.extend(['--cfg=wrapper_native', '-C', f'link-arg={archive}'])
    return result, {'cargo_extern': str(paths[0]), 'native_archive': str(archive)}


if __name__ == '__main__':
    original = sys.argv[1:]
    forwarded, native = command(original)
    record = Path(os.environ['FFI_REPRO_WRAPPER_LOG']) / str(os.getpid())
    if native and not Path(native['native_archive']).is_file():
        raise ValueError(f'native archive missing: {native}')
    run = subprocess.run(forwarded, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=False)
    record.with_suffix('.stdout').write_bytes(run.stdout)
    record.with_suffix('.stderr').write_bytes(run.stderr)
    record.with_suffix('.json').write_text(json.dumps({'received': original, 'forwarded': forwarded, 'native': native, 'exit': run.returncode}, indent=2) + '\n')
    sys.stdout.buffer.write(run.stdout)
    sys.stderr.buffer.write(run.stderr)
    sys.exit(run.returncode if run.returncode >= 0 else 128 - run.returncode)
