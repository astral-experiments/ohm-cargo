// Providing a linker search path is this package's entire purpose.
