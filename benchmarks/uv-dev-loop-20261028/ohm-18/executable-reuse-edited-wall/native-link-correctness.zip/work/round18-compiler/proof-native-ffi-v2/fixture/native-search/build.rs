fn main() {
    println!("cargo::rerun-if-changed=build.rs");
    println!("cargo::rustc-link-search=native={}/native", env!("CARGO_MANIFEST_DIR"));
}
