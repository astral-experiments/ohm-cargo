fn main() {
    println!("cargo::rerun-if-changed=build.rs");
    if std::env::var_os("CARGO_FEATURE_OWN_SEARCH").is_some() {
        println!("cargo::rustc-link-search=native={}/native-search/native", env!("CARGO_MANIFEST_DIR"));
    }
}
