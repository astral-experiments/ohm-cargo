#![allow(unexpected_cfgs)]

#[cfg(any(wrapper_native, feature = "transitive-search", feature = "own-search"))]
#[cfg_attr(any(feature = "transitive-search", feature = "own-search"), link(name = "proof_native", kind = "static"))]
unsafe extern "C" {
    fn cargo_repro_native_value() -> u32;
}

fn observed() -> u32 {
    #[cfg(any(wrapper_native, feature = "transitive-search", feature = "own-search"))]
    unsafe { cargo_repro_native_value() }
    #[cfg(not(any(wrapper_native, feature = "transitive-search", feature = "own-search")))]
    { proofself::cargo_repro_native_value() }
}

fn main() {
    println!("observed={}", observed());
}

#[test]
fn report_value() {
    println!("observed={}", observed());
}
