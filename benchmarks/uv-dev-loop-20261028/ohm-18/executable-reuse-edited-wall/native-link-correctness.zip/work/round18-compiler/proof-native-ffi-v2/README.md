# Executable reuse with native input from the package rlib

This is a correctness fixture for Cargo `7caf39914da1e28a67744ecbc963a5f26361474d` and the separately source-matched executable-reuse patch. It changes only the body of an exported C-ABI function from `1` to `2`. Each driver has its own private target, with a separate empty target for a fully rebuilt control. It runs the resulting program or a tiny probe harness only to observe behavior. It does not measure time or execute uv's tests.

| Mode | How `side` consumes the package library |
| --- | --- |
| `plain` | Direct Rust path, stock wrapper-free control |
| `wrapped` | The same compiler wrapper on both Cargo drivers forwards the original `--extern proofself=…` and additionally supplies that exact rlib as `-C link-arg`. The bin calls the exported native symbol. The wrapper forwards rustc output unchanged and records both argv vectors and raw streams. |
| `transitive-search` | No wrapper. A dependency's build script provides a native search path to a fixed symbolic link pointing to the package's current hashed rlib. Rust source uses `#[link]`. |
| `own-search` | No wrapper. The owning package's build script emits the same search-path directive. Its native-output guard should force ordinary linking. |

The native search trials first build just the package library. Each then creates its single alias once. An accepted observation requires the alias target to match the exact ordinary `--extern` from the compiler argv, the native archive to change after editing the function, the initial program to return `1`, and the clean rebuilt program to return `2`. The stale condition is precisely a warm post-edit program returning `1` while its matched clean program returns `2`. A candidate-specific bug requires the same condition's source-matched baseline to return `2`. Both harness and ordinary binary emit `observed=<value>`.

The wrapper condition additionally requires the candidate's *real* rustc `unused_extern` message for `proofself` and the active output's relink manifest. The wrapper adds no fake diagnostics. The unwrapped transitive search condition requires the active manifest. Missing links, unsupported linking, absent witnesses and control mismatches are recorded as admission failures.

Run `env PYTHONDONTWRITEBYTECODE=1 python3 run.py --self-test` for an offline synthetic check. Actual invocation requires `FFI_REPRO_HOST_RELEASE` set to the SHA-256 of `plan.json` after the coordinator releases CPU time. Supply a previously unused `--attempt NAME` and optionally limit `--endpoint build test` and `--mode wrapped plain transitive-search own-search`. The pinned images are checked before any Cargo invocation. Fresh attempts store logs and receipts under `observed/NAME/`, with fixture targets beneath the task's benchmark scratch root. Each cell retains raw argv, Cargo exit/stdout/stderr, baseline/edited/cold executable digests and program output. The build-script scenarios intentionally exercise controlled local native archive aliases. They do not establish the prevalence of this pattern in uv.
