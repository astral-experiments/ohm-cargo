#!/usr/bin/python3
"""Validate the corrected path handling on the preserved first attempt, read-only."""
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run
import wrapper

first = HERE.parent / 'proof-native-ffi/observed/first'
receipt = {'first_summary_sha256': run.sha(first / 'summary.json'), 'wrappers': {}, 'archives': {}, 'manifests': {}}
for ep in ('build', 'test'):
    for arm in ('base', 'proof'):
        wrapped = first / f'wrapped-{ep}-{arm}/seed'
        args = next(a for a in run.load(wrapped/'cargo-rustc-argv.json') if a[a.index('--crate-name') + 1] == 'side')
        _, native = wrapper.command(args)
        files = [Path(f) for f in native['cargo_externs']]
        archive = Path(native['native_archive'])
        assert len(files) == 2 and set(f.suffix for f in files) == {'.rlib', '.rmeta'}
        assert all(f.is_file() and f.with_suffix('.rlib').samefile(archive) for f in files)
        receipt['wrappers'][wrapped.parent.name] = native
        try:
            wrapper.command([*args, '--extern', 'proofself=/different/other.rlib'])
        except ValueError:
            pass
        else:
            raise AssertionError('conflicting package archive accepted')
        for mode in ('transitive-search', 'own-search'):
            cell = first / f'{mode}-{ep}-{arm}/bootstrap'
            archive = run.active_archive(run.load(cell/'cargo-rustc-argv.json'), list(run.events((cell/'cargo.stdout').read_bytes())))
            receipt['archives'][cell.parent.name] = {'path': str(archive), 'sha256': run.sha(archive)}
        plain = first / f'plain-{ep}-{arm}/seed'
        args = [a for a in run.load(plain/'cargo-rustc-argv.json') if a[a.index('--crate-name') + 1] == 'side']
        product = Path(run.load(plain/'program.json')['argv'][0])
        cache = run.active_manifests(product, args, [])
        assert len(cache) == 1
        receipt['manifests'][plain.parent.name] = {'image': str(product), 'manifest': str(cache[0][0])}
        assert run.active_manifests(product, [], [{'path': str(cache[0][0])}]) == cache
wrong = receipt['manifests']['plain-build-base']
other = receipt['manifests']['plain-build-proof']
try:
    run.active_manifests(Path(wrong['image']), [], [{'path': other['manifest']}])
except ValueError:
    pass
else:
    raise AssertionError('foreign active manifest accepted')
print(json.dumps(receipt, indent=2, sort_keys=True))
