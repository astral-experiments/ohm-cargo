#[unsafe(no_mangle)]
pub extern "C" fn cargo_repro_native_value() -> u32 {
    1
}
