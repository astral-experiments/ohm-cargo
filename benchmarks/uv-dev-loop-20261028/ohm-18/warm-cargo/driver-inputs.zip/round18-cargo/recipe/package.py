#!/usr/bin/env python3
"""Collect copyable source recipes, records and the exact executables used for the uv benchmark."""
import hashlib, json, os, zipfile
from pathlib import Path
D=Path(__file__).resolve().parents[1]
assert set(os.sched_getaffinity(0))<=set(range(16,32))

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def pack(out, paths):
    assert all(p.is_file() for p in paths)
    tmp=out.with_suffix('.zip.pending')
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for p in sorted(set(paths)):z.write(p,Path('round18-cargo')/p.relative_to(D))
    with zipfile.ZipFile(tmp) as z:assert z.testzip() is None
    tmp.replace(out);return dict(path=str(out),sha256=digest(out),bytes=out.stat().st_size)

complete=json.loads((D/'drivers.json').read_text());primary=[D/'PROTOCOL.md',D/'REPRODUCE.md',D/'inputs.json',D/'drivers.json',D/'fast/audit.json',D/'pgo/audit.json',D/'pgo/commands.jsonl',D/'pgo/provenance.json',D/'pgo/prefetch.log']
for patt in ['recipe/*.py','inputs/*','receipts/*','*.sha256','*.log','fast/*/ready.json','fast/*/build.log','fast/*/*.asm','pgo/records/*/source.txt','pgo/records/*/profile-info.json','pgo/records/*/use-profile-input.json','pgo/records/*/driver.txt','pgo/records/*/*.log','pgo/records/*/*.units.jsonl']:
    primary.extend(p for p in D.glob(patt) if p.is_file())
raw={}
for arm in ('base','guard-stack'):
    d=D/f'pgo/records/{arm}';files=sorted((d/'raw').glob('*.profraw'));assert len(files)==24
    raw[arm]={'files':{p.name:digest(p) for p in files},'merged_sha256':digest(d/'merged.profdata')};assert raw[arm]['merged_sha256']==complete['arms']['pgo'][arm]['profdata_sha256']
(D/'receipts/raw-pgo-profiles.json').write_text(json.dumps(raw,indent=2)+'\n');primary.append(D/'receipts/raw-pgo-profiles.json')
executables=[]
for method,entries in complete['arms'].items():
    for arm,info in entries.items():
        p=D/method/'bin'/arm;assert digest(p)==info['sha256'];executables.append(p)
results={'inputs_and_receipts':pack(D/'driver-inputs.zip',primary),'exact_executables':pack(D/'driver-binaries.zip',[D/'drivers.json',*executables])};(D/'packages.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
