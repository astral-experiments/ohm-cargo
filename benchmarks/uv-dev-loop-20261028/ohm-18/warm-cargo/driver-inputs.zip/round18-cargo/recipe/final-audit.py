#!/usr/bin/env python3
"""Cross-check all four delivered ELF files and emit compact, offline-verifiable receipts."""
from collections import Counter
import hashlib, json, os, re, subprocess
from pathlib import Path
D=Path(__file__).resolve().parents[1]; W=D.parent; cfg=json.loads((D/'inputs.json').read_text()); assert set(os.sched_getaffinity(0))<=set(range(16,32))

def sha(f):
    with f.open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()

def verify_elf(f,word,slug):
    name=subprocess.check_output(['nm','-S','-C',f],text=True)
    s=re.search(r'^([0-9a-f]+) ([0-9a-f]+) [Tt] std::path::compare_components$',name,re.M);assert s
    addr,n=[int(v,16) for v in s.groups()];asm=subprocess.check_output(['objdump','-dC',f'--start-address={addr}',f'--stop-address={addr+n}',f],text=True)
    (D/'receipts'/f'{slug}.compare_components.asm').write_text(asm)
    scans=re.findall(r'\b(?:tzcnt|bsf)[a-z]*\b',asm);assert bool(scans)==word
    dyn=subprocess.check_output(['readelf','-d',f],text=True);needed=re.findall(r'\(NEEDED\).*?\[([^]]+)\]',dyn)
    assert not any(v.startswith('libstd-') for v in needed)
    version=subprocess.check_output([f,'-Vv'],text=True);assert cfg['cargo_pin'] in version
    return {'path':str(f),'sha256':sha(f),'needed':needed,'word_scan_instructions':scans,'compare_components_bytes':n,'version':version}

def fast_units(arm):
    u=Counter()
    for l in (D/f'fast/{arm}/build.log').open():
        m=re.search(r'/rustc[\x27\x22]? --crate-name (\w+)',l)
        if not m:continue
        target=re.search(r'--target ([\w.-]+)',l);kind=re.search(r'--crate-type ([\w-]+)',l)
        key=(re.sub(r'^autocfg_[0-9a-f]{16}_([01])$',r'autocfg_probe_\1',m[1]),target[1] if target else 'host',kind[1] if kind else '')
        u[key]+=1
    return u

(D/'receipts').mkdir(exist_ok=True)
complete={'source':cfg,'arms':{},'uv_process_scope':'Cargo links the #247 std statically. uv rustc, target sysroot and Wild binaries are separately selected by the full-stack benchmark.'}
for method in ('fast','pgo'):
    audit=json.loads((D/method/'audit.json').read_text());pair={}
    for arm in ('base','guard-stack'):
        f=D/method/'bin'/arm; info=verify_elf(f,arm=='guard-stack',f'{method}-{arm}');a=audit['arms'][arm];assert info['sha256']==a['cargo_sha256'];info['std_rlib_sha256']=a['std_rlib_sha256'];info['cargo_tree']=cfg['cargo_trees'][arm];info['std_path_sha256']=cfg['std_path_sha256'][arm]
        if method=='fast':
            receipt=json.loads(subprocess.check_output([os.sys.executable,'-B',D/'recipe/verify-fast.py',arm],text=True))
            info['retained_std']=receipt['retained_actual_linked_std_archives']
        if method=='pgo':
            actual_archives=sorted((D/f'pgo/records/{arm}/use.target/x86_64-unknown-linux-gnu/release').rglob('libstd-*.rlib'));assert actual_archives and all(sha(p)==a['std_rlib_sha256'] for p in actual_archives)
            info['retained_std']=[str(p) for p in actual_archives]
            info.update({k:a[k] for k in ['raw_files','profdata_sha256','covered_symbol_matches','training_commands_verified','compiler_unit_graph_sha256','profiled_target_units','unprofiled_std_target_units','unprofiled_host_units']});assert a['training_commands_verified']==24
        pair[arm]=info
    assert pair['base']['needed']==pair['guard-stack']['needed'] and pair['base']['std_rlib_sha256']!=pair['guard-stack']['std_rlib_sha256'] and pair['base']['sha256']!=pair['guard-stack']['sha256']
    complete['arms'][method]=pair
u=fast_units('base');assert u==fast_units('guard-stack') and sum(u.values())>350
signature='\n'.join(' '.join(k)+f' {v}' for k,v in sorted(u.items()));(D/'receipts/fast-compiler-units.txt').write_text(signature+'\n');complete['fast_compiler_units']={'count':sum(u.values()),'sha256':hashlib.sha256(signature.encode()).hexdigest()}
control=Path(cfg['release_toolchain'])/'bin/cargo';assert sha(control)==cfg['cargo_hash'];complete['distributed_control']={'path':str(control),'sha256':sha(control),'version':subprocess.check_output([control,'-Vv'],text=True)}
(D/'drivers.json').write_text(json.dumps(complete,indent=2)+'\n')
print(json.dumps({k:{a:v['sha256'] for a,v in q.items()} for k,q in complete['arms'].items()},indent=2))
