#!/usr/bin/env python3
"""Verify an already published non-PGO arm against its archived source and actual linked std."""
import json, os, sys
from pathlib import Path
D=Path(__file__).resolve().parents[1];sys.path.insert(0,str(D/'recipe'))
from prepare import digest, tree
cfg=json.loads((D/'inputs.json').read_text()); arm,=sys.argv[1:]; assert arm in ('base','guard-stack')
assert set(os.sched_getaffinity(0))<=set(range(16,32))
actual=json.loads((D/f'fast/{arm}/ready.json').read_text());lab=Path(cfg['scratch'])/'fast';park=lab/arm
assert tree(park/'cargo-src')==cfg['cargo_trees'][arm]
assert digest(park/'library/std/src/path.rs')==cfg['std_path_sha256'][arm]
assert digest(park/'library/std/tests/path.rs')==cfg['std_path_test_sha256'][arm]
assert digest(D/f'fast/bin/{arm}')==actual['cargo_sha256']
assert actual['std_path_source_sha256']==cfg['std_path_sha256'][arm]
links=[park/'target'/Path(p).relative_to(lab/'target') for p in actual['linked_std_rlibs']]
assert all(digest(p)==actual['std_rlib_sha256'] for p in links)
assert all((park/'cargo-src/git-commit-info').read_text().splitlines()[i]==v for i,v in enumerate((cfg['cargo_pin'],cfg['cargo_pin'][:9],'2026-10-28')))
receipt={'arm':arm,'binary':str(D/f'fast/bin/{arm}'),'sha256':actual['cargo_sha256'],'source_tree':cfg['cargo_trees'][arm],'retained_actual_linked_std_archives':[str(x) for x in links],'std_rlib_sha256':actual['std_rlib_sha256'],'std_source':cfg['std_path_sha256'][arm],'word_scans':actual['word_scans']}
(D/'receipts').mkdir(exist_ok=True);(D/f'receipts/fast-{arm}.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
