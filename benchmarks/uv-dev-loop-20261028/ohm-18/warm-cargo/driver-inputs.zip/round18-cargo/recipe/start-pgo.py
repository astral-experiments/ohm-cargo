#!/usr/bin/env python3
import json, os, subprocess, sys
from pathlib import Path
D=Path(__file__).resolve().parents[1]; C=json.loads((D/'inputs.json').read_text()); B=Path(C['scratch']); src=Path(C['source']);P=D/'pgo'; assert not P.exists()
assert set(os.sched_getaffinity(0))==set(range(24,32))
argv=[sys.executable,'-B',D/'recipe/pgo18.py','--scratch',P,'--materials',C['materials'],'--cargo-repo',src,'--toolchain',C['toolchain'],'--std-patch',D/'inputs/247.patch','--seed-home',C['build_registry'],'--training-seed',C['training_registry'],'--arms','base','guard-stack','--jobs','8']
subprocess.run(argv,check=True)
with (P/'audit.json').open('x') as f:subprocess.run([sys.executable,'-B',D/'recipe/audit18.py',P,src],stdout=f,check=True)
