# Rebuild the release-18 Cargo drivers

Use x86-64 Linux, Bash, a native C/C++ toolchain, Python 3.11 or newer, binutils, Git, rustup and the usual Cargo source-build prerequisites. The two methods retain separate compiler targets, trained executables, merged and raw profiles. Reserve about 35 GB. `fast/bin` contains the non-PGO drivers. `pgo/bin` contains the self-trained release-style pair.

Start in an empty directory with the archived `round18-cargo` packet extracted at `I`. `prepare.py` expects the documented release source, two private offline Cargo registry seeds and the previous release source-pin metadata. The commands below create those inputs solely from the packet and public dependencies. GitHub operations on this devbox use the OSS-routed `gh-auto`. On another Linux host, set `OHM_GH` to an authenticated `gh` executable.

```bash
set -euo pipefail
I=$(realpath /path/to/extracted/round18-cargo)
R=$(mktemp -d "${TMPDIR:-/tmp}/ohm-cargo-round18.XXXXXXXX")
W="$R/work"; D="$W/round18-cargo"; M="$W/upstream-monitor"; B="$R/bench"
mkdir -p "$D" "$M/cargo/patches" "$M/rust" "$M/download18"
install -d -m 700 "$B" "$W/pgo-confirmation-v2/build-home" "$W/pgo-confirmation-v2/seed-home"
printf '%s\n' "$B" > "$W/bench-home.path"
cp -a "$I/recipe" "$D/recipe"
cp "$I/inputs/cargo.tar.gz" "$M/cargo/base-7caf399.tar.gz"
for pr in 264 267 268 269 270; do cp "$I/inputs/$pr.patch" "$M/cargo/patches/$pr.patch"; done
cp "$I/inputs/247.patch" "$M/rust/247.diff"
python3 - "$I/inputs.json" "$M/cargo/depfile-plan.json" <<'PY'
import json, sys
old=json.load(open(sys.argv[1]));json.dump({'source_archive_sha256':old['cargo_source_archive_sha256'],'distribution_archive_sha256':old['archive_sha256'],'patch_sha256':old['cargo_patch_sha256']},open(sys.argv[2],'w'))
PY
host=x86_64-unknown-linux-gnu
asset=ohm-1.99.0-18-$host.tar.gz
OHM_GH=${OHM_GH:-gh-auto}
GH_AUTO_ACCOUNT=oss "$OHM_GH" api user --jq .login
GH_AUTO_ACCOUNT=oss "$OHM_GH" release download ohm-1.99.0-18 -R astral-sh/ohm -p "$asset" -D "$M/download18"
printf '629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8  %s\n' "$M/download18/$asset" | sha256sum -c -
tar -xzf "$M/download18/$asset" -C "$M/download18"
pack="$M/download18/rust-1.99.0-dev-$host"; T="$M/toolchain18"
"$pack/install.sh" --prefix="$T" --disable-ldconfig --components="rustc,rust-std-$host,cargo"
export PATH="$T/bin:$PATH" RUSTC="$T/bin/rustc" RUSTDOC="$T/bin/rustdoc"
"$RUSTC" -Vv; "$T/bin/cargo" -Vv
mkdir "$R/fetch-src"
tar -xzf "$M/cargo/base-7caf399.tar.gz" --strip-components=1 -C "$R/fetch-src"
for manifest in "$R/fetch-src/Cargo.toml" "$pack/rust-src/lib/rustlib/src/rust/library/Cargo.toml"; do
  CARGO_HOME="$W/pgo-confirmation-v2/build-home" "$T/bin/cargo" fetch --locked --target "$host" --manifest-path "$manifest"
done
# The local rustc-perf clone must contain pinned commit 0a054b0ead56e41a4584bfab6fdc1a5fad2aedc3.
rustup toolchain install 1.99.1 --profile minimal
stable_lib="$(rustup run 1.99.1 rustc --print sysroot)/lib"
python3 -B "$D/recipe/provision-pgo.py" "$W/pgo-materials" --oss-repo /path/to/rustc-perf --perf-repo /path/to/rustc-perf --stable-lib "$stable_lib"
for case in bitmaps-3.2.1 diesel-2.2.10; do
  CARGO_HOME="$W/pgo-confirmation-v2/seed-home" "$T/bin/cargo" fetch --locked --target "$host" --manifest-path "$W/pgo-materials/corpus/$case/Cargo.toml"
done
```

The historical CPU sets are enforced in the recipe. For a host with differently numbered CPUs, set the affinity assertions in the replay copies of `prepare.py`, `build-fast-v2.py`, `pgo18.py`, `start-pgo.py`, `verify-fast.py` and `final-audit.py` to your two disjoint sets of eight CPUs, and use those sets below. The offline build commands are then independent.

```bash
taskset -c 16-31 python3 -B "$D/recipe/prepare.py"
taskset -c 16-23 python3 -B "$D/recipe/build-fast-v2.py" & nonpgo=$!
taskset -c 24-31 python3 -B "$D/recipe/start-pgo.py" & pgo=$!
wait "$nonpgo"; wait "$pgo"
taskset -c 16-31 python3 -B "$D/recipe/final-audit.py"
```

The original non-PGO control’s verbose log contained a newline in Cargo’s package description. The initial verifier incorrectly treated that newline as the end of the compiler command. The build had completed, and the staged binary agreed with the target binary. `build-fast-v2.py` checks the actual rustc command on its continuation line. The recorded control was recovered from that existing output and passed the same source, disassembly and archive checks as the treatment. A fresh replay uses the corrected parser on both arms.

The trained PGO profiles can vary across rebuilds. `pgo/commands.jsonl`, the `generate`/`use` compiler-unit rosters, source manifests, tool hashes, local profile hashes and final executable hashes establish exactly which inputs produced the measured local binaries. The on-host `drivers.json` records the one-to-one mapping from the retained ELF to its linked standard library.
