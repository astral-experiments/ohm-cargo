
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-cargo/fast/bin/.base.next:     file format elf64-x86-64


Disassembly of section .text:

00000000019bd130 <std::path::compare_components>:
 19bd130:	55                   	push   %rbp
 19bd131:	41 57                	push   %r15
 19bd133:	41 56                	push   %r14
 19bd135:	41 55                	push   %r13
 19bd137:	41 54                	push   %r12
 19bd139:	53                   	push   %rbx
 19bd13a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
 19bd141:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
 19bd145:	0f 85 e8 00 00 00    	jne    19bd233 <std::path::compare_components+0x103>
 19bd14b:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
 19bd14f:	0f 85 de 00 00 00    	jne    19bd233 <std::path::compare_components+0x103>
 19bd155:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
 19bd159:	3a 46 38             	cmp    0x38(%rsi),%al
 19bd15c:	0f 85 d1 00 00 00    	jne    19bd233 <std::path::compare_components+0x103>
 19bd162:	4c 8b 2f             	mov    (%rdi),%r13
 19bd165:	4c 8b 77 08          	mov    0x8(%rdi),%r14
 19bd169:	4c 8b 26             	mov    (%rsi),%r12
 19bd16c:	4c 8b 46 08          	mov    0x8(%rsi),%r8
 19bd170:	4d 39 f0             	cmp    %r14,%r8
 19bd173:	4d 89 f7             	mov    %r14,%r15
 19bd176:	4d 0f 42 f8          	cmovb  %r8,%r15
 19bd17a:	4d 85 ff             	test   %r15,%r15
 19bd17d:	74 25                	je     19bd1a4 <std::path::compare_components+0x74>
 19bd17f:	31 d2                	xor    %edx,%edx
 19bd181:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 19bd188:	0f 1f 84 00 00 00 00 
 19bd18f:	00 
 19bd190:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
 19bd196:	41 3a 04 14          	cmp    (%r12,%rdx,1),%al
 19bd19a:	75 33                	jne    19bd1cf <std::path::compare_components+0x9f>
 19bd19c:	48 ff c2             	inc    %rdx
 19bd19f:	49 39 d7             	cmp    %rdx,%r15
 19bd1a2:	75 ec                	jne    19bd190 <std::path::compare_components+0x60>
 19bd1a4:	48 89 f5             	mov    %rsi,%rbp
 19bd1a7:	48 89 fb             	mov    %rdi,%rbx
 19bd1aa:	4c 89 04 24          	mov    %r8,(%rsp)
 19bd1ae:	e8 a1 c3 00 00       	call   19c9554 <<core::ops::control_flow::ControlFlow<(&addr2line::unit::ResUnit<gimli::read::endian_slice::EndianSlice<gimli::endianity::LittleEndian>>, &gimli::read::rnglists::Range)> as core::ops::try_trait::Try>::from_output>
 19bd1b3:	4c 8b 04 24          	mov    (%rsp),%r8
 19bd1b7:	48 89 df             	mov    %rbx,%rdi
 19bd1ba:	48 89 ee             	mov    %rbp,%rsi
 19bd1bd:	a8 01                	test   $0x1,%al
 19bd1bf:	74 17                	je     19bd1d8 <std::path::compare_components+0xa8>
 19bd1c1:	4c 39 f2             	cmp    %r14,%rdx
 19bd1c4:	0f 87 f4 02 00 00    	ja     19bd4be <std::path::compare_components+0x38e>
 19bd1ca:	49 89 d7             	mov    %rdx,%r15
 19bd1cd:	eb 15                	jmp    19bd1e4 <std::path::compare_components+0xb4>
 19bd1cf:	b8 01 00 00 00       	mov    $0x1,%eax
 19bd1d4:	a8 01                	test   $0x1,%al
 19bd1d6:	75 e9                	jne    19bd1c1 <std::path::compare_components+0x91>
 19bd1d8:	4d 39 c6             	cmp    %r8,%r14
 19bd1db:	75 07                	jne    19bd1e4 <std::path::compare_components+0xb4>
 19bd1dd:	31 c0                	xor    %eax,%eax
 19bd1df:	e9 c8 02 00 00       	jmp    19bd4ac <std::path::compare_components+0x37c>
 19bd1e4:	4d 85 ff             	test   %r15,%r15
 19bd1e7:	74 4a                	je     19bd233 <std::path::compare_components+0x103>
 19bd1e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 19bd1f0:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
 19bd1f6:	74 07                	je     19bd1ff <std::path::compare_components+0xcf>
 19bd1f8:	49 ff cf             	dec    %r15
 19bd1fb:	75 f3                	jne    19bd1f0 <std::path::compare_components+0xc0>
 19bd1fd:	eb 34                	jmp    19bd233 <std::path::compare_components+0x103>
 19bd1ff:	4c 89 f0             	mov    %r14,%rax
 19bd202:	4c 29 f8             	sub    %r15,%rax
 19bd205:	0f 82 c8 02 00 00    	jb     19bd4d3 <std::path::compare_components+0x3a3>
 19bd20b:	4d 01 fd             	add    %r15,%r13
 19bd20e:	4c 89 2f             	mov    %r13,(%rdi)
 19bd211:	48 89 47 08          	mov    %rax,0x8(%rdi)
 19bd215:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
 19bd219:	4c 89 c0             	mov    %r8,%rax
 19bd21c:	4c 29 f8             	sub    %r15,%rax
 19bd21f:	0f 82 c4 02 00 00    	jb     19bd4e9 <std::path::compare_components+0x3b9>
 19bd225:	4d 01 fc             	add    %r15,%r12
 19bd228:	4c 89 26             	mov    %r12,(%rsi)
 19bd22b:	48 89 46 08          	mov    %rax,0x8(%rsi)
 19bd22f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
 19bd233:	0f 10 07             	movups (%rdi),%xmm0
 19bd236:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
 19bd23a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
 19bd23e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
 19bd242:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
 19bd249:	00 
 19bd24a:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
 19bd251:	00 
 19bd252:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
 19bd259:	00 
 19bd25a:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
 19bd261:	00 
 19bd262:	48 8b 06             	mov    (%rsi),%rax
 19bd265:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 19bd269:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
 19bd26d:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
 19bd271:	48 8b 56 30          	mov    0x30(%rsi),%rdx
 19bd275:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
 19bd27a:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
 19bd27e:	88 54 24 48          	mov    %dl,0x48(%rsp)
 19bd282:	8b 56 39             	mov    0x39(%rsi),%edx
 19bd285:	89 54 24 49          	mov    %edx,0x49(%rsp)
 19bd289:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
 19bd28d:	66 89 54 24 4d       	mov    %dx,0x4d(%rsp)
 19bd292:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
 19bd296:	88 54 24 4f          	mov    %dl,0x4f(%rsp)
 19bd29a:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
 19bd29f:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
 19bd2a4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 19bd2a9:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
 19bd2ae:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
 19bd2b3:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
 19bd2ba:	00 
 19bd2bb:	ff 15 f7 75 86 00    	call   *0x8675f7(%rip)        # 22248b8 <_DYNAMIC+0x7f8>
 19bd2c1:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
 19bd2c7:	41 80 fc ff          	cmp    $0xff,%r12b
 19bd2cb:	0f 84 b7 01 00 00    	je     19bd488 <std::path::compare_components+0x358>
 19bd2d1:	48 8b 05 e0 75 86 00 	mov    0x8675e0(%rip),%rax        # 22248b8 <_DYNAMIC+0x7f8>
 19bd2d8:	eb 2f                	jmp    19bd309 <std::path::compare_components+0x1d9>
 19bd2da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 19bd2e0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
 19bd2e5:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
 19bd2ec:	00 
 19bd2ed:	48 8b 1d c4 75 86 00 	mov    0x8675c4(%rip),%rbx        # 22248b8 <_DYNAMIC+0x7f8>
 19bd2f4:	ff d3                	call   *%rbx
 19bd2f6:	48 89 d8             	mov    %rbx,%rax
 19bd2f9:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
 19bd2ff:	41 80 fc ff          	cmp    $0xff,%r12b
 19bd303:	0f 84 7f 01 00 00    	je     19bd488 <std::path::compare_components+0x358>
 19bd309:	44 0f b6 7c 24 51    	movzbl 0x51(%rsp),%r15d
 19bd30f:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
 19bd314:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
 19bd319:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
 19bd31e:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
 19bd323:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
 19bd32a:	00 
 19bd32b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 19bd330:	ff d0                	call   *%rax
 19bd332:	0f b6 bc 24 88 00 00 	movzbl 0x88(%rsp),%edi
 19bd339:	00 
 19bd33a:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
 19bd341:	0f 84 63 01 00 00    	je     19bd4aa <std::path::compare_components+0x37a>
 19bd347:	41 0f b6 cc          	movzbl %r12b,%ecx
 19bd34b:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
 19bd34f:	80 f9 06             	cmp    $0x6,%cl
 19bd352:	ba 00 00 00 00       	mov    $0x0,%edx
 19bd357:	4c 0f 42 c2          	cmovb  %rdx,%r8
 19bd35b:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
 19bd35f:	40 80 ff 06          	cmp    $0x6,%dil
 19bd363:	48 0f 42 c2          	cmovb  %rdx,%rax
 19bd367:	49 39 c0             	cmp    %rax,%r8
 19bd36a:	0f 9c c2             	setl   %dl
 19bd36d:	0f 9f c0             	setg   %al
 19bd370:	0f 85 8a 00 00 00    	jne    19bd400 <std::path::compare_components+0x2d0>
 19bd376:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
 19bd37d:	00 
 19bd37e:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
 19bd385:	00 
 19bd386:	41 83 f8 04          	cmp    $0x4,%r8d
 19bd38a:	74 4a                	je     19bd3d6 <std::path::compare_components+0x2a6>
 19bd38c:	4d 85 c0             	test   %r8,%r8
 19bd38f:	0f 85 4b ff ff ff    	jne    19bd2e0 <std::path::compare_components+0x1b0>
 19bd395:	40 80 ff 05          	cmp    $0x5,%dil
 19bd399:	0f 87 41 ff ff ff    	ja     19bd2e0 <std::path::compare_components+0x1b0>
 19bd39f:	48 39 f9             	cmp    %rdi,%rcx
 19bd3a2:	41 0f 9c c0          	setl   %r8b
 19bd3a6:	0f 9f c0             	setg   %al
 19bd3a9:	41 38 fc             	cmp    %dil,%r12b
 19bd3ac:	75 6c                	jne    19bd41a <std::path::compare_components+0x2ea>
 19bd3ae:	0f b6 84 24 89 00 00 	movzbl 0x89(%rsp),%eax
 19bd3b5:	00 
 19bd3b6:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
 19bd3bd:	00 
 19bd3be:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
 19bd3c5:	00 
 19bd3c6:	48 8d 3d 0f 41 9a fe 	lea    -0x165bef1(%rip),%rdi        # 3614dc <anon.7b0b136b753808bd20c1ec7ce1bdb704.0.llvm.5681693328607113006+0x4670>
 19bd3cd:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
 19bd3d1:	48 01 f9             	add    %rdi,%rcx
 19bd3d4:	ff e1                	jmp    *%rcx
 19bd3d6:	4c 89 f3             	mov    %r14,%rbx
 19bd3d9:	48 29 d3             	sub    %rdx,%rbx
 19bd3dc:	49 0f 42 d6          	cmovb  %r14,%rdx
 19bd3e0:	48 89 ef             	mov    %rbp,%rdi
 19bd3e3:	ff 15 27 71 86 00    	call   *0x867127(%rip)        # 2224510 <memcmp@GLIBC_2.2.5>
 19bd3e9:	48 98                	cltq
 19bd3eb:	85 c0                	test   %eax,%eax
 19bd3ed:	48 0f 45 d8          	cmovne %rax,%rbx
 19bd3f1:	48 85 db             	test   %rbx,%rbx
 19bd3f4:	0f 98 c1             	sets   %cl
 19bd3f7:	0f 9f c0             	setg   %al
 19bd3fa:	28 c8                	sub    %cl,%al
 19bd3fc:	eb 04                	jmp    19bd402 <std::path::compare_components+0x2d2>
 19bd3fe:	66 90                	xchg   %ax,%ax
 19bd400:	28 d0                	sub    %dl,%al
 19bd402:	3c fe                	cmp    $0xfe,%al
 19bd404:	0f 84 d6 fe ff ff    	je     19bd2e0 <std::path::compare_components+0x1b0>
 19bd40a:	0f b6 c8             	movzbl %al,%ecx
 19bd40d:	85 c9                	test   %ecx,%ecx
 19bd40f:	0f 84 cb fe ff ff    	je     19bd2e0 <std::path::compare_components+0x1b0>
 19bd415:	e9 92 00 00 00       	jmp    19bd4ac <std::path::compare_components+0x37c>
 19bd41a:	44 28 c0             	sub    %r8b,%al
 19bd41d:	eb e3                	jmp    19bd402 <std::path::compare_components+0x2d2>
 19bd41f:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
 19bd424:	4c 89 04 24          	mov    %r8,(%rsp)
 19bd428:	4d 89 f7             	mov    %r14,%r15
 19bd42b:	49 29 d7             	sub    %rdx,%r15
 19bd42e:	49 0f 42 d6          	cmovb  %r14,%rdx
 19bd432:	48 89 ef             	mov    %rbp,%rdi
 19bd435:	4c 8b 25 d4 70 86 00 	mov    0x8670d4(%rip),%r12        # 2224510 <memcmp@GLIBC_2.2.5>
 19bd43c:	41 ff d4             	call   *%r12
 19bd43f:	48 98                	cltq
 19bd441:	85 c0                	test   %eax,%eax
 19bd443:	4c 0f 45 f8          	cmovne %rax,%r15
 19bd447:	4d 85 ff             	test   %r15,%r15
 19bd44a:	0f 98 c1             	sets   %cl
 19bd44d:	0f 9f c0             	setg   %al
 19bd450:	75 a8                	jne    19bd3fa <std::path::compare_components+0x2ca>
 19bd452:	49 89 de             	mov    %rbx,%r14
 19bd455:	48 8b 14 24          	mov    (%rsp),%rdx
 19bd459:	49 29 d6             	sub    %rdx,%r14
 19bd45c:	48 0f 42 d3          	cmovb  %rbx,%rdx
 19bd460:	4c 89 ef             	mov    %r13,%rdi
 19bd463:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 19bd468:	41 ff d4             	call   *%r12
 19bd46b:	48 98                	cltq
 19bd46d:	85 c0                	test   %eax,%eax
 19bd46f:	4c 0f 45 f0          	cmovne %rax,%r14
 19bd473:	4d 85 f6             	test   %r14,%r14
 19bd476:	e9 79 ff ff ff       	jmp    19bd3f4 <std::path::compare_components+0x2c4>
 19bd47b:	41 38 c7             	cmp    %al,%r15b
 19bd47e:	0f 97 c0             	seta   %al
 19bd481:	1c 00                	sbb    $0x0,%al
 19bd483:	e9 7a ff ff ff       	jmp    19bd402 <std::path::compare_components+0x2d2>
 19bd488:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
 19bd48f:	00 
 19bd490:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 19bd495:	ff 15 1d 74 86 00    	call   *0x86741d(%rip)        # 22248b8 <_DYNAMIC+0x7f8>
 19bd49b:	80 bc 24 88 00 00 00 	cmpb   $0xff,0x88(%rsp)
 19bd4a2:	ff 
 19bd4a3:	0f 95 c0             	setne  %al
 19bd4a6:	f6 d8                	neg    %al
 19bd4a8:	eb 02                	jmp    19bd4ac <std::path::compare_components+0x37c>
 19bd4aa:	b0 01                	mov    $0x1,%al
 19bd4ac:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
 19bd4b3:	5b                   	pop    %rbx
 19bd4b4:	41 5c                	pop    %r12
 19bd4b6:	41 5d                	pop    %r13
 19bd4b8:	41 5e                	pop    %r14
 19bd4ba:	41 5f                	pop    %r15
 19bd4bc:	5d                   	pop    %rbp
 19bd4bd:	c3                   	ret
 19bd4be:	48 8d 0d fb eb 7d 00 	lea    0x7debfb(%rip),%rcx        # 219c0c0 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.8911308631352431538+0x48>
 19bd4c5:	31 ff                	xor    %edi,%edi
 19bd4c7:	48 89 d6             	mov    %rdx,%rsi
 19bd4ca:	4c 89 f2             	mov    %r14,%rdx
 19bd4cd:	ff 15 8d 6e 86 00    	call   *0x866e8d(%rip)        # 2224360 <_DYNAMIC+0x2a0>
 19bd4d3:	48 8d 0d ce eb 7d 00 	lea    0x7debce(%rip),%rcx        # 219c0a8 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.8911308631352431538+0x30>
 19bd4da:	4c 89 ff             	mov    %r15,%rdi
 19bd4dd:	4c 89 f6             	mov    %r14,%rsi
 19bd4e0:	4c 89 f2             	mov    %r14,%rdx
 19bd4e3:	ff 15 77 6e 86 00    	call   *0x866e77(%rip)        # 2224360 <_DYNAMIC+0x2a0>
 19bd4e9:	48 8d 0d a0 eb 7d 00 	lea    0x7deba0(%rip),%rcx        # 219c090 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.8911308631352431538+0x18>
 19bd4f0:	4c 89 ff             	mov    %r15,%rdi
 19bd4f3:	4c 89 c6             	mov    %r8,%rsi
 19bd4f6:	4c 89 c2             	mov    %r8,%rdx
 19bd4f9:	ff 15 61 6e 86 00    	call   *0x866e61(%rip)        # 2224360 <_DYNAMIC+0x2a0>
