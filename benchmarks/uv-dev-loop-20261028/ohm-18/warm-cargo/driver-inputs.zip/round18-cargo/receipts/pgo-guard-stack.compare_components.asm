
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-cargo/pgo/bin/guard-stack:     file format elf64-x86-64


Disassembly of section .text:

0000000000c56a40 <std::path::compare_components>:
  c56a40:	55                   	push   %rbp
  c56a41:	41 57                	push   %r15
  c56a43:	41 56                	push   %r14
  c56a45:	41 55                	push   %r13
  c56a47:	41 54                	push   %r12
  c56a49:	53                   	push   %rbx
  c56a4a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
  c56a51:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
  c56a55:	0f 85 28 02 00 00    	jne    c56c83 <std::path::compare_components+0x243>
  c56a5b:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
  c56a5f:	0f 85 1e 02 00 00    	jne    c56c83 <std::path::compare_components+0x243>
  c56a65:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
  c56a69:	3a 46 38             	cmp    0x38(%rsi),%al
  c56a6c:	0f 85 11 02 00 00    	jne    c56c83 <std::path::compare_components+0x243>
  c56a72:	4c 8b 2f             	mov    (%rdi),%r13
  c56a75:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  c56a79:	4c 8b 26             	mov    (%rsi),%r12
  c56a7c:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
  c56a80:	4c 39 f3             	cmp    %r14,%rbx
  c56a83:	4d 89 f7             	mov    %r14,%r15
  c56a86:	4c 0f 42 fb          	cmovb  %rbx,%r15
  c56a8a:	49 83 ff 07          	cmp    $0x7,%r15
  c56a8e:	0f 87 d7 00 00 00    	ja     c56b6b <std::path::compare_components+0x12b>
  c56a94:	4d 85 ff             	test   %r15,%r15
  c56a97:	0f 84 91 01 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56a9d:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
  c56aa2:	41 3a 04 24          	cmp    (%r12),%al
  c56aa6:	0f 85 55 01 00 00    	jne    c56c01 <std::path::compare_components+0x1c1>
  c56aac:	49 83 ff 01          	cmp    $0x1,%r15
  c56ab0:	0f 84 78 01 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56ab6:	41 0f b6 45 01       	movzbl 0x1(%r13),%eax
  c56abb:	ba 01 00 00 00       	mov    $0x1,%edx
  c56ac0:	41 3a 44 24 01       	cmp    0x1(%r12),%al
  c56ac5:	0f 85 48 01 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56acb:	49 83 ff 02          	cmp    $0x2,%r15
  c56acf:	0f 84 59 01 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56ad5:	41 0f b6 45 02       	movzbl 0x2(%r13),%eax
  c56ada:	ba 02 00 00 00       	mov    $0x2,%edx
  c56adf:	41 3a 44 24 02       	cmp    0x2(%r12),%al
  c56ae4:	0f 85 29 01 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56aea:	49 83 ff 03          	cmp    $0x3,%r15
  c56aee:	0f 84 3a 01 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56af4:	41 0f b6 45 03       	movzbl 0x3(%r13),%eax
  c56af9:	ba 03 00 00 00       	mov    $0x3,%edx
  c56afe:	41 3a 44 24 03       	cmp    0x3(%r12),%al
  c56b03:	0f 85 0a 01 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56b09:	49 83 ff 04          	cmp    $0x4,%r15
  c56b0d:	0f 84 1b 01 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56b13:	41 0f b6 45 04       	movzbl 0x4(%r13),%eax
  c56b18:	ba 04 00 00 00       	mov    $0x4,%edx
  c56b1d:	41 3a 44 24 04       	cmp    0x4(%r12),%al
  c56b22:	0f 85 eb 00 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56b28:	49 83 ff 05          	cmp    $0x5,%r15
  c56b2c:	0f 84 fc 00 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56b32:	41 0f b6 45 05       	movzbl 0x5(%r13),%eax
  c56b37:	ba 05 00 00 00       	mov    $0x5,%edx
  c56b3c:	41 3a 44 24 05       	cmp    0x5(%r12),%al
  c56b41:	0f 85 cc 00 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56b47:	49 83 ff 06          	cmp    $0x6,%r15
  c56b4b:	0f 84 dd 00 00 00    	je     c56c2e <std::path::compare_components+0x1ee>
  c56b51:	41 0f b6 45 06       	movzbl 0x6(%r13),%eax
  c56b56:	ba 06 00 00 00       	mov    $0x6,%edx
  c56b5b:	41 3a 44 24 06       	cmp    0x6(%r12),%al
  c56b60:	0f 85 ad 00 00 00    	jne    c56c13 <std::path::compare_components+0x1d3>
  c56b66:	e9 c3 00 00 00       	jmp    c56c2e <std::path::compare_components+0x1ee>
  c56b6b:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
  c56b70:	41 3a 04 24          	cmp    (%r12),%al
  c56b74:	0f 85 82 00 00 00    	jne    c56bfc <std::path::compare_components+0x1bc>
  c56b7a:	4c 89 f9             	mov    %r15,%rcx
  c56b7d:	48 c1 e9 03          	shr    $0x3,%rcx
  c56b81:	74 27                	je     c56baa <std::path::compare_components+0x16a>
  c56b83:	31 c0                	xor    %eax,%eax
  c56b85:	31 d2                	xor    %edx,%edx
  c56b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  c56b8e:	00 00 
  c56b90:	4d 8b 44 d5 00       	mov    0x0(%r13,%rdx,8),%r8
  c56b95:	4d 8b 0c d4          	mov    (%r12,%rdx,8),%r9
  c56b99:	4d 39 c8             	cmp    %r9,%r8
  c56b9c:	75 67                	jne    c56c05 <std::path::compare_components+0x1c5>
  c56b9e:	48 ff c2             	inc    %rdx
  c56ba1:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  c56ba5:	48 39 d1             	cmp    %rdx,%rcx
  c56ba8:	75 e6                	jne    c56b90 <std::path::compare_components+0x150>
  c56baa:	49 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r8
  c56bb1:	ff ff 7f 
  c56bb4:	4d 21 f8             	and    %r15,%r8
  c56bb7:	44 89 f8             	mov    %r15d,%eax
  c56bba:	83 e0 07             	and    $0x7,%eax
  c56bbd:	74 15                	je     c56bd4 <std::path::compare_components+0x194>
  c56bbf:	43 0f b6 4c 05 00    	movzbl 0x0(%r13,%r8,1),%ecx
  c56bc5:	43 3a 0c 04          	cmp    (%r12,%r8,1),%cl
  c56bc9:	75 56                	jne    c56c21 <std::path::compare_components+0x1e1>
  c56bcb:	83 f8 01             	cmp    $0x1,%eax
  c56bce:	0f 85 3a 03 00 00    	jne    c56f0e <std::path::compare_components+0x4ce>
  c56bd4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  c56bd9:	48 89 fd             	mov    %rdi,%rbp
  c56bdc:	4c 89 04 24          	mov    %r8,(%rsp)
  c56be0:	e8 af 96 c3 00       	call   1890294 <<core::ops::control_flow::ControlFlow<(&addr2line::unit::ResUnit<gimli::read::endian_slice::EndianSlice<gimli::endianity::LittleEndian>>, &gimli::read::rnglists::Range)> as core::ops::try_trait::Try>::from_output>
  c56be5:	4c 8b 04 24          	mov    (%rsp),%r8
  c56be9:	48 89 ef             	mov    %rbp,%rdi
  c56bec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  c56bf1:	48 83 f8 01          	cmp    $0x1,%rax
  c56bf5:	75 37                	jne    c56c2e <std::path::compare_components+0x1ee>
  c56bf7:	4c 01 c2             	add    %r8,%rdx
  c56bfa:	eb 17                	jmp    c56c13 <std::path::compare_components+0x1d3>
  c56bfc:	45 31 ff             	xor    %r15d,%r15d
  c56bff:	eb 39                	jmp    c56c3a <std::path::compare_components+0x1fa>
  c56c01:	31 d2                	xor    %edx,%edx
  c56c03:	eb 0e                	jmp    c56c13 <std::path::compare_components+0x1d3>
  c56c05:	4d 31 c1             	xor    %r8,%r9
  c56c08:	f3 49 0f bc d1       	tzcnt  %r9,%rdx
  c56c0d:	c1 ea 03             	shr    $0x3,%edx
  c56c10:	48 29 c2             	sub    %rax,%rdx
  c56c13:	4c 39 f2             	cmp    %r14,%rdx
  c56c16:	0f 87 a8 03 00 00    	ja     c56fc4 <std::path::compare_components+0x584>
  c56c1c:	49 89 d7             	mov    %rdx,%r15
  c56c1f:	eb 19                	jmp    c56c3a <std::path::compare_components+0x1fa>
  c56c21:	31 d2                	xor    %edx,%edx
  c56c23:	b8 01 00 00 00       	mov    $0x1,%eax
  c56c28:	48 83 f8 01          	cmp    $0x1,%rax
  c56c2c:	74 c9                	je     c56bf7 <std::path::compare_components+0x1b7>
  c56c2e:	49 39 de             	cmp    %rbx,%r14
  c56c31:	75 07                	jne    c56c3a <std::path::compare_components+0x1fa>
  c56c33:	31 c0                	xor    %eax,%eax
  c56c35:	e9 c2 02 00 00       	jmp    c56efc <std::path::compare_components+0x4bc>
  c56c3a:	4d 85 ff             	test   %r15,%r15
  c56c3d:	74 44                	je     c56c83 <std::path::compare_components+0x243>
  c56c3f:	90                   	nop
  c56c40:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
  c56c46:	74 07                	je     c56c4f <std::path::compare_components+0x20f>
  c56c48:	49 ff cf             	dec    %r15
  c56c4b:	75 f3                	jne    c56c40 <std::path::compare_components+0x200>
  c56c4d:	eb 34                	jmp    c56c83 <std::path::compare_components+0x243>
  c56c4f:	4c 89 f0             	mov    %r14,%rax
  c56c52:	4c 29 f8             	sub    %r15,%rax
  c56c55:	0f 82 7e 03 00 00    	jb     c56fd9 <std::path::compare_components+0x599>
  c56c5b:	4d 01 fd             	add    %r15,%r13
  c56c5e:	4c 89 2f             	mov    %r13,(%rdi)
  c56c61:	48 89 47 08          	mov    %rax,0x8(%rdi)
  c56c65:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
  c56c69:	48 89 d8             	mov    %rbx,%rax
  c56c6c:	4c 29 f8             	sub    %r15,%rax
  c56c6f:	0f 82 7a 03 00 00    	jb     c56fef <std::path::compare_components+0x5af>
  c56c75:	4d 01 fc             	add    %r15,%r12
  c56c78:	4c 89 26             	mov    %r12,(%rsi)
  c56c7b:	48 89 46 08          	mov    %rax,0x8(%rsi)
  c56c7f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
  c56c83:	0f 10 07             	movups (%rdi),%xmm0
  c56c86:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  c56c8a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  c56c8e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
  c56c92:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  c56c99:	00 
  c56c9a:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  c56ca1:	00 
  c56ca2:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  c56ca9:	00 
  c56caa:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  c56cb1:	00 
  c56cb2:	48 8b 06             	mov    (%rsi),%rax
  c56cb5:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  c56cb9:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
  c56cbd:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
  c56cc1:	48 8b 56 30          	mov    0x30(%rsi),%rdx
  c56cc5:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  c56cca:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
  c56cce:	88 54 24 48          	mov    %dl,0x48(%rsp)
  c56cd2:	8b 56 39             	mov    0x39(%rsi),%edx
  c56cd5:	89 54 24 49          	mov    %edx,0x49(%rsp)
  c56cd9:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
  c56cdd:	66 89 54 24 4d       	mov    %dx,0x4d(%rsp)
  c56ce2:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
  c56ce6:	88 54 24 4f          	mov    %dl,0x4f(%rsp)
  c56cea:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  c56cef:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  c56cf4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  c56cf9:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  c56cfe:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  c56d03:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
  c56d0a:	00 
  c56d0b:	ff 15 2f ca 45 01    	call   *0x145ca2f(%rip)        # 20b3740 <_DYNAMIC+0x9a0>
  c56d11:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
  c56d17:	41 80 fc ff          	cmp    $0xff,%r12b
  c56d1b:	0f 84 b7 01 00 00    	je     c56ed8 <std::path::compare_components+0x498>
  c56d21:	48 8b 05 18 ca 45 01 	mov    0x145ca18(%rip),%rax        # 20b3740 <_DYNAMIC+0x9a0>
  c56d28:	eb 2f                	jmp    c56d59 <std::path::compare_components+0x319>
  c56d2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  c56d30:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  c56d35:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
  c56d3c:	00 
  c56d3d:	48 8b 1d fc c9 45 01 	mov    0x145c9fc(%rip),%rbx        # 20b3740 <_DYNAMIC+0x9a0>
  c56d44:	ff d3                	call   *%rbx
  c56d46:	48 89 d8             	mov    %rbx,%rax
  c56d49:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
  c56d4f:	41 80 fc ff          	cmp    $0xff,%r12b
  c56d53:	0f 84 7f 01 00 00    	je     c56ed8 <std::path::compare_components+0x498>
  c56d59:	44 0f b6 7c 24 51    	movzbl 0x51(%rsp),%r15d
  c56d5f:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
  c56d64:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  c56d69:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
  c56d6e:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  c56d73:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  c56d7a:	00 
  c56d7b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  c56d80:	ff d0                	call   *%rax
  c56d82:	0f b6 bc 24 88 00 00 	movzbl 0x88(%rsp),%edi
  c56d89:	00 
  c56d8a:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
  c56d91:	0f 84 63 01 00 00    	je     c56efa <std::path::compare_components+0x4ba>
  c56d97:	41 0f b6 cc          	movzbl %r12b,%ecx
  c56d9b:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
  c56d9f:	80 f9 06             	cmp    $0x6,%cl
  c56da2:	ba 00 00 00 00       	mov    $0x0,%edx
  c56da7:	4c 0f 42 c2          	cmovb  %rdx,%r8
  c56dab:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
  c56daf:	40 80 ff 06          	cmp    $0x6,%dil
  c56db3:	48 0f 42 c2          	cmovb  %rdx,%rax
  c56db7:	49 39 c0             	cmp    %rax,%r8
  c56dba:	0f 9c c2             	setl   %dl
  c56dbd:	0f 9f c0             	setg   %al
  c56dc0:	0f 85 8a 00 00 00    	jne    c56e50 <std::path::compare_components+0x410>
  c56dc6:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  c56dcd:	00 
  c56dce:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  c56dd5:	00 
  c56dd6:	41 83 f8 04          	cmp    $0x4,%r8d
  c56dda:	74 4a                	je     c56e26 <std::path::compare_components+0x3e6>
  c56ddc:	4d 85 c0             	test   %r8,%r8
  c56ddf:	0f 85 4b ff ff ff    	jne    c56d30 <std::path::compare_components+0x2f0>
  c56de5:	40 80 ff 05          	cmp    $0x5,%dil
  c56de9:	0f 87 41 ff ff ff    	ja     c56d30 <std::path::compare_components+0x2f0>
  c56def:	48 39 f9             	cmp    %rdi,%rcx
  c56df2:	41 0f 9c c0          	setl   %r8b
  c56df6:	0f 9f c0             	setg   %al
  c56df9:	41 38 fc             	cmp    %dil,%r12b
  c56dfc:	75 6c                	jne    c56e6a <std::path::compare_components+0x42a>
  c56dfe:	0f b6 84 24 89 00 00 	movzbl 0x89(%rsp),%eax
  c56e05:	00 
  c56e06:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
  c56e0d:	00 
  c56e0e:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
  c56e15:	00 
  c56e16:	48 8d 3d 87 8e 71 ff 	lea    -0x8e7179(%rip),%rdi        # 36fca4 <sharded_slab::tid::REGISTRY+0x17c4>
  c56e1d:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
  c56e21:	48 01 f9             	add    %rdi,%rcx
  c56e24:	ff e1                	jmp    *%rcx
  c56e26:	4c 89 f3             	mov    %r14,%rbx
  c56e29:	48 29 d3             	sub    %rdx,%rbx
  c56e2c:	49 0f 42 d6          	cmovb  %r14,%rdx
  c56e30:	48 89 ef             	mov    %rbp,%rdi
  c56e33:	ff 15 ff c1 45 01    	call   *0x145c1ff(%rip)        # 20b3038 <memcmp@GLIBC_2.2.5>
  c56e39:	48 98                	cltq
  c56e3b:	85 c0                	test   %eax,%eax
  c56e3d:	48 0f 45 d8          	cmovne %rax,%rbx
  c56e41:	48 85 db             	test   %rbx,%rbx
  c56e44:	0f 98 c1             	sets   %cl
  c56e47:	0f 9f c0             	setg   %al
  c56e4a:	28 c8                	sub    %cl,%al
  c56e4c:	eb 04                	jmp    c56e52 <std::path::compare_components+0x412>
  c56e4e:	66 90                	xchg   %ax,%ax
  c56e50:	28 d0                	sub    %dl,%al
  c56e52:	3c fe                	cmp    $0xfe,%al
  c56e54:	0f 84 d6 fe ff ff    	je     c56d30 <std::path::compare_components+0x2f0>
  c56e5a:	0f b6 c8             	movzbl %al,%ecx
  c56e5d:	85 c9                	test   %ecx,%ecx
  c56e5f:	0f 84 cb fe ff ff    	je     c56d30 <std::path::compare_components+0x2f0>
  c56e65:	e9 92 00 00 00       	jmp    c56efc <std::path::compare_components+0x4bc>
  c56e6a:	44 28 c0             	sub    %r8b,%al
  c56e6d:	eb e3                	jmp    c56e52 <std::path::compare_components+0x412>
  c56e6f:	4c 89 0c 24          	mov    %r9,(%rsp)
  c56e73:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  c56e78:	4d 89 f7             	mov    %r14,%r15
  c56e7b:	49 29 d7             	sub    %rdx,%r15
  c56e7e:	49 0f 42 d6          	cmovb  %r14,%rdx
  c56e82:	48 89 ef             	mov    %rbp,%rdi
  c56e85:	4c 8b 25 ac c1 45 01 	mov    0x145c1ac(%rip),%r12        # 20b3038 <memcmp@GLIBC_2.2.5>
  c56e8c:	41 ff d4             	call   *%r12
  c56e8f:	48 98                	cltq
  c56e91:	85 c0                	test   %eax,%eax
  c56e93:	4c 0f 45 f8          	cmovne %rax,%r15
  c56e97:	4d 85 ff             	test   %r15,%r15
  c56e9a:	0f 98 c1             	sets   %cl
  c56e9d:	0f 9f c0             	setg   %al
  c56ea0:	75 a8                	jne    c56e4a <std::path::compare_components+0x40a>
  c56ea2:	49 89 de             	mov    %rbx,%r14
  c56ea5:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  c56eaa:	49 29 d6             	sub    %rdx,%r14
  c56ead:	48 0f 42 d3          	cmovb  %rbx,%rdx
  c56eb1:	4c 89 ef             	mov    %r13,%rdi
  c56eb4:	48 8b 34 24          	mov    (%rsp),%rsi
  c56eb8:	41 ff d4             	call   *%r12
  c56ebb:	48 98                	cltq
  c56ebd:	85 c0                	test   %eax,%eax
  c56ebf:	4c 0f 45 f0          	cmovne %rax,%r14
  c56ec3:	4d 85 f6             	test   %r14,%r14
  c56ec6:	e9 79 ff ff ff       	jmp    c56e44 <std::path::compare_components+0x404>
  c56ecb:	41 38 c7             	cmp    %al,%r15b
  c56ece:	0f 97 c0             	seta   %al
  c56ed1:	1c 00                	sbb    $0x0,%al
  c56ed3:	e9 7a ff ff ff       	jmp    c56e52 <std::path::compare_components+0x412>
  c56ed8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  c56edf:	00 
  c56ee0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  c56ee5:	ff 15 55 c8 45 01    	call   *0x145c855(%rip)        # 20b3740 <_DYNAMIC+0x9a0>
  c56eeb:	80 bc 24 88 00 00 00 	cmpb   $0xff,0x88(%rsp)
  c56ef2:	ff 
  c56ef3:	0f 95 c0             	setne  %al
  c56ef6:	f6 d8                	neg    %al
  c56ef8:	eb 02                	jmp    c56efc <std::path::compare_components+0x4bc>
  c56efa:	b0 01                	mov    $0x1,%al
  c56efc:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
  c56f03:	5b                   	pop    %rbx
  c56f04:	41 5c                	pop    %r12
  c56f06:	41 5d                	pop    %r13
  c56f08:	41 5e                	pop    %r14
  c56f0a:	41 5f                	pop    %r15
  c56f0c:	5d                   	pop    %rbp
  c56f0d:	c3                   	ret
  c56f0e:	43 0f b6 4c 05 01    	movzbl 0x1(%r13,%r8,1),%ecx
  c56f14:	ba 01 00 00 00       	mov    $0x1,%edx
  c56f19:	43 3a 4c 04 01       	cmp    0x1(%r12,%r8,1),%cl
  c56f1e:	0f 85 ff fc ff ff    	jne    c56c23 <std::path::compare_components+0x1e3>
  c56f24:	83 f8 02             	cmp    $0x2,%eax
  c56f27:	0f 84 a7 fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56f2d:	43 0f b6 4c 05 02    	movzbl 0x2(%r13,%r8,1),%ecx
  c56f33:	ba 02 00 00 00       	mov    $0x2,%edx
  c56f38:	43 3a 4c 04 02       	cmp    0x2(%r12,%r8,1),%cl
  c56f3d:	0f 85 e0 fc ff ff    	jne    c56c23 <std::path::compare_components+0x1e3>
  c56f43:	83 f8 03             	cmp    $0x3,%eax
  c56f46:	0f 84 88 fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56f4c:	43 0f b6 4c 05 03    	movzbl 0x3(%r13,%r8,1),%ecx
  c56f52:	ba 03 00 00 00       	mov    $0x3,%edx
  c56f57:	43 3a 4c 04 03       	cmp    0x3(%r12,%r8,1),%cl
  c56f5c:	0f 85 c1 fc ff ff    	jne    c56c23 <std::path::compare_components+0x1e3>
  c56f62:	83 f8 04             	cmp    $0x4,%eax
  c56f65:	0f 84 69 fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56f6b:	43 0f b6 4c 05 04    	movzbl 0x4(%r13,%r8,1),%ecx
  c56f71:	ba 04 00 00 00       	mov    $0x4,%edx
  c56f76:	43 3a 4c 04 04       	cmp    0x4(%r12,%r8,1),%cl
  c56f7b:	0f 85 a2 fc ff ff    	jne    c56c23 <std::path::compare_components+0x1e3>
  c56f81:	83 f8 05             	cmp    $0x5,%eax
  c56f84:	0f 84 4a fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56f8a:	43 0f b6 4c 05 05    	movzbl 0x5(%r13,%r8,1),%ecx
  c56f90:	ba 05 00 00 00       	mov    $0x5,%edx
  c56f95:	43 3a 4c 04 05       	cmp    0x5(%r12,%r8,1),%cl
  c56f9a:	0f 85 83 fc ff ff    	jne    c56c23 <std::path::compare_components+0x1e3>
  c56fa0:	83 f8 06             	cmp    $0x6,%eax
  c56fa3:	0f 84 2b fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56fa9:	43 0f b6 44 05 06    	movzbl 0x6(%r13,%r8,1),%eax
  c56faf:	ba 06 00 00 00       	mov    $0x6,%edx
  c56fb4:	43 3a 44 04 06       	cmp    0x6(%r12,%r8,1),%al
  c56fb9:	0f 84 15 fc ff ff    	je     c56bd4 <std::path::compare_components+0x194>
  c56fbf:	e9 5f fc ff ff       	jmp    c56c23 <std::path::compare_components+0x1e3>
  c56fc4:	48 8d 0d 85 37 3d 01 	lea    0x13d3785(%rip),%rcx        # 202a750 <anon.27e520e72b4dbf5de48359dc0653d79c.351.llvm.11618474209152089197>
  c56fcb:	31 ff                	xor    %edi,%edi
  c56fcd:	48 89 d6             	mov    %rdx,%rsi
  c56fd0:	4c 89 f2             	mov    %r14,%rdx
  c56fd3:	ff 15 3f c0 45 01    	call   *0x145c03f(%rip)        # 20b3018 <_DYNAMIC+0x278>
  c56fd9:	48 8d 0d 58 37 3d 01 	lea    0x13d3758(%rip),%rcx        # 202a738 <anon.27e520e72b4dbf5de48359dc0653d79c.350.llvm.11618474209152089197>
  c56fe0:	4c 89 ff             	mov    %r15,%rdi
  c56fe3:	4c 89 f6             	mov    %r14,%rsi
  c56fe6:	4c 89 f2             	mov    %r14,%rdx
  c56fe9:	ff 15 29 c0 45 01    	call   *0x145c029(%rip)        # 20b3018 <_DYNAMIC+0x278>
  c56fef:	48 8d 0d 2a 37 3d 01 	lea    0x13d372a(%rip),%rcx        # 202a720 <anon.27e520e72b4dbf5de48359dc0653d79c.349.llvm.11618474209152089197>
  c56ff6:	4c 89 ff             	mov    %r15,%rdi
  c56ff9:	48 89 de             	mov    %rbx,%rsi
  c56ffc:	48 89 da             	mov    %rbx,%rdx
  c56fff:	ff 15 13 c0 45 01    	call   *0x145c013(%rip)        # 20b3018 <_DYNAMIC+0x278>
