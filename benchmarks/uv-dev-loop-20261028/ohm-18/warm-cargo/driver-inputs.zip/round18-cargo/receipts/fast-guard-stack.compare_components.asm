
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-cargo/fast/bin/guard-stack:     file format elf64-x86-64


Disassembly of section .text:

00000000019bcdc0 <std::path::compare_components>:
 19bcdc0:	55                   	push   %rbp
 19bcdc1:	41 57                	push   %r15
 19bcdc3:	41 56                	push   %r14
 19bcdc5:	41 55                	push   %r13
 19bcdc7:	41 54                	push   %r12
 19bcdc9:	53                   	push   %rbx
 19bcdca:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
 19bcdd1:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
 19bcdd5:	0f 85 28 02 00 00    	jne    19bd003 <std::path::compare_components+0x243>
 19bcddb:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
 19bcddf:	0f 85 1e 02 00 00    	jne    19bd003 <std::path::compare_components+0x243>
 19bcde5:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
 19bcde9:	3a 46 38             	cmp    0x38(%rsi),%al
 19bcdec:	0f 85 11 02 00 00    	jne    19bd003 <std::path::compare_components+0x243>
 19bcdf2:	4c 8b 2f             	mov    (%rdi),%r13
 19bcdf5:	4c 8b 77 08          	mov    0x8(%rdi),%r14
 19bcdf9:	4c 8b 26             	mov    (%rsi),%r12
 19bcdfc:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
 19bce00:	4c 39 f3             	cmp    %r14,%rbx
 19bce03:	4d 89 f7             	mov    %r14,%r15
 19bce06:	4c 0f 42 fb          	cmovb  %rbx,%r15
 19bce0a:	49 83 ff 07          	cmp    $0x7,%r15
 19bce0e:	0f 87 d7 00 00 00    	ja     19bceeb <std::path::compare_components+0x12b>
 19bce14:	4d 85 ff             	test   %r15,%r15
 19bce17:	0f 84 91 01 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bce1d:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
 19bce22:	41 3a 04 24          	cmp    (%r12),%al
 19bce26:	0f 85 55 01 00 00    	jne    19bcf81 <std::path::compare_components+0x1c1>
 19bce2c:	49 83 ff 01          	cmp    $0x1,%r15
 19bce30:	0f 84 78 01 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bce36:	41 0f b6 45 01       	movzbl 0x1(%r13),%eax
 19bce3b:	ba 01 00 00 00       	mov    $0x1,%edx
 19bce40:	41 3a 44 24 01       	cmp    0x1(%r12),%al
 19bce45:	0f 85 48 01 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bce4b:	49 83 ff 02          	cmp    $0x2,%r15
 19bce4f:	0f 84 59 01 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bce55:	41 0f b6 45 02       	movzbl 0x2(%r13),%eax
 19bce5a:	ba 02 00 00 00       	mov    $0x2,%edx
 19bce5f:	41 3a 44 24 02       	cmp    0x2(%r12),%al
 19bce64:	0f 85 29 01 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bce6a:	49 83 ff 03          	cmp    $0x3,%r15
 19bce6e:	0f 84 3a 01 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bce74:	41 0f b6 45 03       	movzbl 0x3(%r13),%eax
 19bce79:	ba 03 00 00 00       	mov    $0x3,%edx
 19bce7e:	41 3a 44 24 03       	cmp    0x3(%r12),%al
 19bce83:	0f 85 0a 01 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bce89:	49 83 ff 04          	cmp    $0x4,%r15
 19bce8d:	0f 84 1b 01 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bce93:	41 0f b6 45 04       	movzbl 0x4(%r13),%eax
 19bce98:	ba 04 00 00 00       	mov    $0x4,%edx
 19bce9d:	41 3a 44 24 04       	cmp    0x4(%r12),%al
 19bcea2:	0f 85 eb 00 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bcea8:	49 83 ff 05          	cmp    $0x5,%r15
 19bceac:	0f 84 fc 00 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bceb2:	41 0f b6 45 05       	movzbl 0x5(%r13),%eax
 19bceb7:	ba 05 00 00 00       	mov    $0x5,%edx
 19bcebc:	41 3a 44 24 05       	cmp    0x5(%r12),%al
 19bcec1:	0f 85 cc 00 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bcec7:	49 83 ff 06          	cmp    $0x6,%r15
 19bcecb:	0f 84 dd 00 00 00    	je     19bcfae <std::path::compare_components+0x1ee>
 19bced1:	41 0f b6 45 06       	movzbl 0x6(%r13),%eax
 19bced6:	ba 06 00 00 00       	mov    $0x6,%edx
 19bcedb:	41 3a 44 24 06       	cmp    0x6(%r12),%al
 19bcee0:	0f 85 ad 00 00 00    	jne    19bcf93 <std::path::compare_components+0x1d3>
 19bcee6:	e9 c3 00 00 00       	jmp    19bcfae <std::path::compare_components+0x1ee>
 19bceeb:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
 19bcef0:	41 3a 04 24          	cmp    (%r12),%al
 19bcef4:	0f 85 82 00 00 00    	jne    19bcf7c <std::path::compare_components+0x1bc>
 19bcefa:	4c 89 f9             	mov    %r15,%rcx
 19bcefd:	48 c1 e9 03          	shr    $0x3,%rcx
 19bcf01:	74 27                	je     19bcf2a <std::path::compare_components+0x16a>
 19bcf03:	31 c0                	xor    %eax,%eax
 19bcf05:	31 d2                	xor    %edx,%edx
 19bcf07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 19bcf0e:	00 00 
 19bcf10:	4d 8b 44 d5 00       	mov    0x0(%r13,%rdx,8),%r8
 19bcf15:	4d 8b 0c d4          	mov    (%r12,%rdx,8),%r9
 19bcf19:	4d 39 c8             	cmp    %r9,%r8
 19bcf1c:	75 67                	jne    19bcf85 <std::path::compare_components+0x1c5>
 19bcf1e:	48 ff c2             	inc    %rdx
 19bcf21:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
 19bcf25:	48 39 d1             	cmp    %rdx,%rcx
 19bcf28:	75 e6                	jne    19bcf10 <std::path::compare_components+0x150>
 19bcf2a:	49 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r8
 19bcf31:	ff ff 7f 
 19bcf34:	4d 21 f8             	and    %r15,%r8
 19bcf37:	44 89 f8             	mov    %r15d,%eax
 19bcf3a:	83 e0 07             	and    $0x7,%eax
 19bcf3d:	74 15                	je     19bcf54 <std::path::compare_components+0x194>
 19bcf3f:	43 0f b6 4c 05 00    	movzbl 0x0(%r13,%r8,1),%ecx
 19bcf45:	43 3a 0c 04          	cmp    (%r12,%r8,1),%cl
 19bcf49:	75 56                	jne    19bcfa1 <std::path::compare_components+0x1e1>
 19bcf4b:	83 f8 01             	cmp    $0x1,%eax
 19bcf4e:	0f 85 3a 03 00 00    	jne    19bd28e <std::path::compare_components+0x4ce>
 19bcf54:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
 19bcf59:	48 89 fd             	mov    %rdi,%rbp
 19bcf5c:	4c 89 04 24          	mov    %r8,(%rsp)
 19bcf60:	e8 6f c4 00 00       	call   19c93d4 <<core::ops::control_flow::ControlFlow<(&addr2line::unit::ResUnit<gimli::read::endian_slice::EndianSlice<gimli::endianity::LittleEndian>>, &gimli::read::rnglists::Range)> as core::ops::try_trait::Try>::from_output>
 19bcf65:	4c 8b 04 24          	mov    (%rsp),%r8
 19bcf69:	48 89 ef             	mov    %rbp,%rdi
 19bcf6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 19bcf71:	48 83 f8 01          	cmp    $0x1,%rax
 19bcf75:	75 37                	jne    19bcfae <std::path::compare_components+0x1ee>
 19bcf77:	4c 01 c2             	add    %r8,%rdx
 19bcf7a:	eb 17                	jmp    19bcf93 <std::path::compare_components+0x1d3>
 19bcf7c:	45 31 ff             	xor    %r15d,%r15d
 19bcf7f:	eb 39                	jmp    19bcfba <std::path::compare_components+0x1fa>
 19bcf81:	31 d2                	xor    %edx,%edx
 19bcf83:	eb 0e                	jmp    19bcf93 <std::path::compare_components+0x1d3>
 19bcf85:	4d 31 c1             	xor    %r8,%r9
 19bcf88:	f3 49 0f bc d1       	tzcnt  %r9,%rdx
 19bcf8d:	c1 ea 03             	shr    $0x3,%edx
 19bcf90:	48 29 c2             	sub    %rax,%rdx
 19bcf93:	4c 39 f2             	cmp    %r14,%rdx
 19bcf96:	0f 87 a8 03 00 00    	ja     19bd344 <std::path::compare_components+0x584>
 19bcf9c:	49 89 d7             	mov    %rdx,%r15
 19bcf9f:	eb 19                	jmp    19bcfba <std::path::compare_components+0x1fa>
 19bcfa1:	31 d2                	xor    %edx,%edx
 19bcfa3:	b8 01 00 00 00       	mov    $0x1,%eax
 19bcfa8:	48 83 f8 01          	cmp    $0x1,%rax
 19bcfac:	74 c9                	je     19bcf77 <std::path::compare_components+0x1b7>
 19bcfae:	49 39 de             	cmp    %rbx,%r14
 19bcfb1:	75 07                	jne    19bcfba <std::path::compare_components+0x1fa>
 19bcfb3:	31 c0                	xor    %eax,%eax
 19bcfb5:	e9 c2 02 00 00       	jmp    19bd27c <std::path::compare_components+0x4bc>
 19bcfba:	4d 85 ff             	test   %r15,%r15
 19bcfbd:	74 44                	je     19bd003 <std::path::compare_components+0x243>
 19bcfbf:	90                   	nop
 19bcfc0:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
 19bcfc6:	74 07                	je     19bcfcf <std::path::compare_components+0x20f>
 19bcfc8:	49 ff cf             	dec    %r15
 19bcfcb:	75 f3                	jne    19bcfc0 <std::path::compare_components+0x200>
 19bcfcd:	eb 34                	jmp    19bd003 <std::path::compare_components+0x243>
 19bcfcf:	4c 89 f0             	mov    %r14,%rax
 19bcfd2:	4c 29 f8             	sub    %r15,%rax
 19bcfd5:	0f 82 7e 03 00 00    	jb     19bd359 <std::path::compare_components+0x599>
 19bcfdb:	4d 01 fd             	add    %r15,%r13
 19bcfde:	4c 89 2f             	mov    %r13,(%rdi)
 19bcfe1:	48 89 47 08          	mov    %rax,0x8(%rdi)
 19bcfe5:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
 19bcfe9:	48 89 d8             	mov    %rbx,%rax
 19bcfec:	4c 29 f8             	sub    %r15,%rax
 19bcfef:	0f 82 7a 03 00 00    	jb     19bd36f <std::path::compare_components+0x5af>
 19bcff5:	4d 01 fc             	add    %r15,%r12
 19bcff8:	4c 89 26             	mov    %r12,(%rsi)
 19bcffb:	48 89 46 08          	mov    %rax,0x8(%rsi)
 19bcfff:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
 19bd003:	0f 10 07             	movups (%rdi),%xmm0
 19bd006:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
 19bd00a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
 19bd00e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
 19bd012:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
 19bd019:	00 
 19bd01a:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
 19bd021:	00 
 19bd022:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
 19bd029:	00 
 19bd02a:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
 19bd031:	00 
 19bd032:	48 8b 06             	mov    (%rsi),%rax
 19bd035:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 19bd039:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
 19bd03d:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
 19bd041:	48 8b 56 30          	mov    0x30(%rsi),%rdx
 19bd045:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
 19bd04a:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
 19bd04e:	88 54 24 48          	mov    %dl,0x48(%rsp)
 19bd052:	8b 56 39             	mov    0x39(%rsi),%edx
 19bd055:	89 54 24 49          	mov    %edx,0x49(%rsp)
 19bd059:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
 19bd05d:	66 89 54 24 4d       	mov    %dx,0x4d(%rsp)
 19bd062:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
 19bd066:	88 54 24 4f          	mov    %dl,0x4f(%rsp)
 19bd06a:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
 19bd06f:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
 19bd074:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 19bd079:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
 19bd07e:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
 19bd083:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
 19bd08a:	00 
 19bd08b:	ff 15 87 76 86 00    	call   *0x867687(%rip)        # 2224718 <_DYNAMIC+0x7f8>
 19bd091:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
 19bd097:	41 80 fc ff          	cmp    $0xff,%r12b
 19bd09b:	0f 84 b7 01 00 00    	je     19bd258 <std::path::compare_components+0x498>
 19bd0a1:	48 8b 05 70 76 86 00 	mov    0x867670(%rip),%rax        # 2224718 <_DYNAMIC+0x7f8>
 19bd0a8:	eb 2f                	jmp    19bd0d9 <std::path::compare_components+0x319>
 19bd0aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 19bd0b0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
 19bd0b5:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
 19bd0bc:	00 
 19bd0bd:	48 8b 1d 54 76 86 00 	mov    0x867654(%rip),%rbx        # 2224718 <_DYNAMIC+0x7f8>
 19bd0c4:	ff d3                	call   *%rbx
 19bd0c6:	48 89 d8             	mov    %rbx,%rax
 19bd0c9:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
 19bd0cf:	41 80 fc ff          	cmp    $0xff,%r12b
 19bd0d3:	0f 84 7f 01 00 00    	je     19bd258 <std::path::compare_components+0x498>
 19bd0d9:	44 0f b6 7c 24 51    	movzbl 0x51(%rsp),%r15d
 19bd0df:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
 19bd0e4:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
 19bd0e9:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
 19bd0ee:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
 19bd0f3:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
 19bd0fa:	00 
 19bd0fb:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 19bd100:	ff d0                	call   *%rax
 19bd102:	0f b6 bc 24 88 00 00 	movzbl 0x88(%rsp),%edi
 19bd109:	00 
 19bd10a:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
 19bd111:	0f 84 63 01 00 00    	je     19bd27a <std::path::compare_components+0x4ba>
 19bd117:	41 0f b6 cc          	movzbl %r12b,%ecx
 19bd11b:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
 19bd11f:	80 f9 06             	cmp    $0x6,%cl
 19bd122:	ba 00 00 00 00       	mov    $0x0,%edx
 19bd127:	4c 0f 42 c2          	cmovb  %rdx,%r8
 19bd12b:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
 19bd12f:	40 80 ff 06          	cmp    $0x6,%dil
 19bd133:	48 0f 42 c2          	cmovb  %rdx,%rax
 19bd137:	49 39 c0             	cmp    %rax,%r8
 19bd13a:	0f 9c c2             	setl   %dl
 19bd13d:	0f 9f c0             	setg   %al
 19bd140:	0f 85 8a 00 00 00    	jne    19bd1d0 <std::path::compare_components+0x410>
 19bd146:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
 19bd14d:	00 
 19bd14e:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
 19bd155:	00 
 19bd156:	41 83 f8 04          	cmp    $0x4,%r8d
 19bd15a:	74 4a                	je     19bd1a6 <std::path::compare_components+0x3e6>
 19bd15c:	4d 85 c0             	test   %r8,%r8
 19bd15f:	0f 85 4b ff ff ff    	jne    19bd0b0 <std::path::compare_components+0x2f0>
 19bd165:	40 80 ff 05          	cmp    $0x5,%dil
 19bd169:	0f 87 41 ff ff ff    	ja     19bd0b0 <std::path::compare_components+0x2f0>
 19bd16f:	48 39 f9             	cmp    %rdi,%rcx
 19bd172:	41 0f 9c c0          	setl   %r8b
 19bd176:	0f 9f c0             	setg   %al
 19bd179:	41 38 fc             	cmp    %dil,%r12b
 19bd17c:	75 6c                	jne    19bd1ea <std::path::compare_components+0x42a>
 19bd17e:	0f b6 84 24 89 00 00 	movzbl 0x89(%rsp),%eax
 19bd185:	00 
 19bd186:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
 19bd18d:	00 
 19bd18e:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
 19bd195:	00 
 19bd196:	48 8d 3d 7f 43 9a fe 	lea    -0x165bc81(%rip),%rdi        # 36151c <anon.7b0b136b753808bd20c1ec7ce1bdb704.0.llvm.5681693328607113006+0x4670>
 19bd19d:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
 19bd1a1:	48 01 f9             	add    %rdi,%rcx
 19bd1a4:	ff e1                	jmp    *%rcx
 19bd1a6:	4c 89 f3             	mov    %r14,%rbx
 19bd1a9:	48 29 d3             	sub    %rdx,%rbx
 19bd1ac:	49 0f 42 d6          	cmovb  %r14,%rdx
 19bd1b0:	48 89 ef             	mov    %rbp,%rdi
 19bd1b3:	ff 15 b7 71 86 00    	call   *0x8671b7(%rip)        # 2224370 <memcmp@GLIBC_2.2.5>
 19bd1b9:	48 98                	cltq
 19bd1bb:	85 c0                	test   %eax,%eax
 19bd1bd:	48 0f 45 d8          	cmovne %rax,%rbx
 19bd1c1:	48 85 db             	test   %rbx,%rbx
 19bd1c4:	0f 98 c1             	sets   %cl
 19bd1c7:	0f 9f c0             	setg   %al
 19bd1ca:	28 c8                	sub    %cl,%al
 19bd1cc:	eb 04                	jmp    19bd1d2 <std::path::compare_components+0x412>
 19bd1ce:	66 90                	xchg   %ax,%ax
 19bd1d0:	28 d0                	sub    %dl,%al
 19bd1d2:	3c fe                	cmp    $0xfe,%al
 19bd1d4:	0f 84 d6 fe ff ff    	je     19bd0b0 <std::path::compare_components+0x2f0>
 19bd1da:	0f b6 c8             	movzbl %al,%ecx
 19bd1dd:	85 c9                	test   %ecx,%ecx
 19bd1df:	0f 84 cb fe ff ff    	je     19bd0b0 <std::path::compare_components+0x2f0>
 19bd1e5:	e9 92 00 00 00       	jmp    19bd27c <std::path::compare_components+0x4bc>
 19bd1ea:	44 28 c0             	sub    %r8b,%al
 19bd1ed:	eb e3                	jmp    19bd1d2 <std::path::compare_components+0x412>
 19bd1ef:	4c 89 0c 24          	mov    %r9,(%rsp)
 19bd1f3:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
 19bd1f8:	4d 89 f7             	mov    %r14,%r15
 19bd1fb:	49 29 d7             	sub    %rdx,%r15
 19bd1fe:	49 0f 42 d6          	cmovb  %r14,%rdx
 19bd202:	48 89 ef             	mov    %rbp,%rdi
 19bd205:	4c 8b 25 64 71 86 00 	mov    0x867164(%rip),%r12        # 2224370 <memcmp@GLIBC_2.2.5>
 19bd20c:	41 ff d4             	call   *%r12
 19bd20f:	48 98                	cltq
 19bd211:	85 c0                	test   %eax,%eax
 19bd213:	4c 0f 45 f8          	cmovne %rax,%r15
 19bd217:	4d 85 ff             	test   %r15,%r15
 19bd21a:	0f 98 c1             	sets   %cl
 19bd21d:	0f 9f c0             	setg   %al
 19bd220:	75 a8                	jne    19bd1ca <std::path::compare_components+0x40a>
 19bd222:	49 89 de             	mov    %rbx,%r14
 19bd225:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 19bd22a:	49 29 d6             	sub    %rdx,%r14
 19bd22d:	48 0f 42 d3          	cmovb  %rbx,%rdx
 19bd231:	4c 89 ef             	mov    %r13,%rdi
 19bd234:	48 8b 34 24          	mov    (%rsp),%rsi
 19bd238:	41 ff d4             	call   *%r12
 19bd23b:	48 98                	cltq
 19bd23d:	85 c0                	test   %eax,%eax
 19bd23f:	4c 0f 45 f0          	cmovne %rax,%r14
 19bd243:	4d 85 f6             	test   %r14,%r14
 19bd246:	e9 79 ff ff ff       	jmp    19bd1c4 <std::path::compare_components+0x404>
 19bd24b:	41 38 c7             	cmp    %al,%r15b
 19bd24e:	0f 97 c0             	seta   %al
 19bd251:	1c 00                	sbb    $0x0,%al
 19bd253:	e9 7a ff ff ff       	jmp    19bd1d2 <std::path::compare_components+0x412>
 19bd258:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
 19bd25f:	00 
 19bd260:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 19bd265:	ff 15 ad 74 86 00    	call   *0x8674ad(%rip)        # 2224718 <_DYNAMIC+0x7f8>
 19bd26b:	80 bc 24 88 00 00 00 	cmpb   $0xff,0x88(%rsp)
 19bd272:	ff 
 19bd273:	0f 95 c0             	setne  %al
 19bd276:	f6 d8                	neg    %al
 19bd278:	eb 02                	jmp    19bd27c <std::path::compare_components+0x4bc>
 19bd27a:	b0 01                	mov    $0x1,%al
 19bd27c:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
 19bd283:	5b                   	pop    %rbx
 19bd284:	41 5c                	pop    %r12
 19bd286:	41 5d                	pop    %r13
 19bd288:	41 5e                	pop    %r14
 19bd28a:	41 5f                	pop    %r15
 19bd28c:	5d                   	pop    %rbp
 19bd28d:	c3                   	ret
 19bd28e:	43 0f b6 4c 05 01    	movzbl 0x1(%r13,%r8,1),%ecx
 19bd294:	ba 01 00 00 00       	mov    $0x1,%edx
 19bd299:	43 3a 4c 04 01       	cmp    0x1(%r12,%r8,1),%cl
 19bd29e:	0f 85 ff fc ff ff    	jne    19bcfa3 <std::path::compare_components+0x1e3>
 19bd2a4:	83 f8 02             	cmp    $0x2,%eax
 19bd2a7:	0f 84 a7 fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd2ad:	43 0f b6 4c 05 02    	movzbl 0x2(%r13,%r8,1),%ecx
 19bd2b3:	ba 02 00 00 00       	mov    $0x2,%edx
 19bd2b8:	43 3a 4c 04 02       	cmp    0x2(%r12,%r8,1),%cl
 19bd2bd:	0f 85 e0 fc ff ff    	jne    19bcfa3 <std::path::compare_components+0x1e3>
 19bd2c3:	83 f8 03             	cmp    $0x3,%eax
 19bd2c6:	0f 84 88 fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd2cc:	43 0f b6 4c 05 03    	movzbl 0x3(%r13,%r8,1),%ecx
 19bd2d2:	ba 03 00 00 00       	mov    $0x3,%edx
 19bd2d7:	43 3a 4c 04 03       	cmp    0x3(%r12,%r8,1),%cl
 19bd2dc:	0f 85 c1 fc ff ff    	jne    19bcfa3 <std::path::compare_components+0x1e3>
 19bd2e2:	83 f8 04             	cmp    $0x4,%eax
 19bd2e5:	0f 84 69 fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd2eb:	43 0f b6 4c 05 04    	movzbl 0x4(%r13,%r8,1),%ecx
 19bd2f1:	ba 04 00 00 00       	mov    $0x4,%edx
 19bd2f6:	43 3a 4c 04 04       	cmp    0x4(%r12,%r8,1),%cl
 19bd2fb:	0f 85 a2 fc ff ff    	jne    19bcfa3 <std::path::compare_components+0x1e3>
 19bd301:	83 f8 05             	cmp    $0x5,%eax
 19bd304:	0f 84 4a fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd30a:	43 0f b6 4c 05 05    	movzbl 0x5(%r13,%r8,1),%ecx
 19bd310:	ba 05 00 00 00       	mov    $0x5,%edx
 19bd315:	43 3a 4c 04 05       	cmp    0x5(%r12,%r8,1),%cl
 19bd31a:	0f 85 83 fc ff ff    	jne    19bcfa3 <std::path::compare_components+0x1e3>
 19bd320:	83 f8 06             	cmp    $0x6,%eax
 19bd323:	0f 84 2b fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd329:	43 0f b6 44 05 06    	movzbl 0x6(%r13,%r8,1),%eax
 19bd32f:	ba 06 00 00 00       	mov    $0x6,%edx
 19bd334:	43 3a 44 04 06       	cmp    0x6(%r12,%r8,1),%al
 19bd339:	0f 84 15 fc ff ff    	je     19bcf54 <std::path::compare_components+0x194>
 19bd33f:	e9 5f fc ff ff       	jmp    19bcfa3 <std::path::compare_components+0x1e3>
 19bd344:	48 8d 0d c5 eb 7d 00 	lea    0x7debc5(%rip),%rcx        # 219bf10 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.1357200743070147231+0x48>
 19bd34b:	31 ff                	xor    %edi,%edi
 19bd34d:	48 89 d6             	mov    %rdx,%rsi
 19bd350:	4c 89 f2             	mov    %r14,%rdx
 19bd353:	ff 15 67 6e 86 00    	call   *0x866e67(%rip)        # 22241c0 <_DYNAMIC+0x2a0>
 19bd359:	48 8d 0d 98 eb 7d 00 	lea    0x7deb98(%rip),%rcx        # 219bef8 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.1357200743070147231+0x30>
 19bd360:	4c 89 ff             	mov    %r15,%rdi
 19bd363:	4c 89 f6             	mov    %r14,%rsi
 19bd366:	4c 89 f2             	mov    %r14,%rdx
 19bd369:	ff 15 51 6e 86 00    	call   *0x866e51(%rip)        # 22241c0 <_DYNAMIC+0x2a0>
 19bd36f:	48 8d 0d 6a eb 7d 00 	lea    0x7deb6a(%rip),%rcx        # 219bee0 <anon.dfe37e5ecae2f21a6254b7bcd337d222.345.llvm.1357200743070147231+0x18>
 19bd376:	4c 89 ff             	mov    %r15,%rdi
 19bd379:	48 89 de             	mov    %rbx,%rsi
 19bd37c:	48 89 da             	mov    %rbx,%rdx
 19bd37f:	ff 15 3b 6e 86 00    	call   *0x866e3b(%rip)        # 22241c0 <_DYNAMIC+0x2a0>
