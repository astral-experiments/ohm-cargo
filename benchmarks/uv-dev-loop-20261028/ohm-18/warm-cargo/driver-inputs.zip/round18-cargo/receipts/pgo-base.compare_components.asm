
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-cargo/pgo/bin/base:     file format elf64-x86-64


Disassembly of section .text:

0000000000b05a90 <std::path::compare_components>:
  b05a90:	55                   	push   %rbp
  b05a91:	41 57                	push   %r15
  b05a93:	41 56                	push   %r14
  b05a95:	41 55                	push   %r13
  b05a97:	41 54                	push   %r12
  b05a99:	53                   	push   %rbx
  b05a9a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
  b05aa1:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
  b05aa5:	0f 85 e8 00 00 00    	jne    b05b93 <std::path::compare_components+0x103>
  b05aab:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
  b05aaf:	0f 85 de 00 00 00    	jne    b05b93 <std::path::compare_components+0x103>
  b05ab5:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
  b05ab9:	3a 46 38             	cmp    0x38(%rsi),%al
  b05abc:	0f 85 d1 00 00 00    	jne    b05b93 <std::path::compare_components+0x103>
  b05ac2:	4c 8b 2f             	mov    (%rdi),%r13
  b05ac5:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  b05ac9:	4c 8b 26             	mov    (%rsi),%r12
  b05acc:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  b05ad0:	4d 39 f0             	cmp    %r14,%r8
  b05ad3:	4d 89 f7             	mov    %r14,%r15
  b05ad6:	4d 0f 42 f8          	cmovb  %r8,%r15
  b05ada:	4d 85 ff             	test   %r15,%r15
  b05add:	74 25                	je     b05b04 <std::path::compare_components+0x74>
  b05adf:	31 d2                	xor    %edx,%edx
  b05ae1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  b05ae8:	0f 1f 84 00 00 00 00 
  b05aef:	00 
  b05af0:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
  b05af6:	41 3a 04 14          	cmp    (%r12,%rdx,1),%al
  b05afa:	75 33                	jne    b05b2f <std::path::compare_components+0x9f>
  b05afc:	48 ff c2             	inc    %rdx
  b05aff:	49 39 d7             	cmp    %rdx,%r15
  b05b02:	75 ec                	jne    b05af0 <std::path::compare_components+0x60>
  b05b04:	48 89 f5             	mov    %rsi,%rbp
  b05b07:	48 89 fb             	mov    %rdi,%rbx
  b05b0a:	4c 89 04 24          	mov    %r8,(%rsp)
  b05b0e:	e8 81 83 d8 00       	call   188de94 <<core::ops::control_flow::ControlFlow<(&addr2line::unit::ResUnit<gimli::read::endian_slice::EndianSlice<gimli::endianity::LittleEndian>>, &gimli::read::rnglists::Range)> as core::ops::try_trait::Try>::from_output>
  b05b13:	4c 8b 04 24          	mov    (%rsp),%r8
  b05b17:	48 89 df             	mov    %rbx,%rdi
  b05b1a:	48 89 ee             	mov    %rbp,%rsi
  b05b1d:	a8 01                	test   $0x1,%al
  b05b1f:	74 17                	je     b05b38 <std::path::compare_components+0xa8>
  b05b21:	4c 39 f2             	cmp    %r14,%rdx
  b05b24:	0f 87 f4 02 00 00    	ja     b05e1e <std::path::compare_components+0x38e>
  b05b2a:	49 89 d7             	mov    %rdx,%r15
  b05b2d:	eb 15                	jmp    b05b44 <std::path::compare_components+0xb4>
  b05b2f:	b8 01 00 00 00       	mov    $0x1,%eax
  b05b34:	a8 01                	test   $0x1,%al
  b05b36:	75 e9                	jne    b05b21 <std::path::compare_components+0x91>
  b05b38:	4d 39 c6             	cmp    %r8,%r14
  b05b3b:	75 07                	jne    b05b44 <std::path::compare_components+0xb4>
  b05b3d:	31 c0                	xor    %eax,%eax
  b05b3f:	e9 c8 02 00 00       	jmp    b05e0c <std::path::compare_components+0x37c>
  b05b44:	4d 85 ff             	test   %r15,%r15
  b05b47:	74 4a                	je     b05b93 <std::path::compare_components+0x103>
  b05b49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  b05b50:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
  b05b56:	74 07                	je     b05b5f <std::path::compare_components+0xcf>
  b05b58:	49 ff cf             	dec    %r15
  b05b5b:	75 f3                	jne    b05b50 <std::path::compare_components+0xc0>
  b05b5d:	eb 34                	jmp    b05b93 <std::path::compare_components+0x103>
  b05b5f:	4c 89 f0             	mov    %r14,%rax
  b05b62:	4c 29 f8             	sub    %r15,%rax
  b05b65:	0f 82 c8 02 00 00    	jb     b05e33 <std::path::compare_components+0x3a3>
  b05b6b:	4d 01 fd             	add    %r15,%r13
  b05b6e:	4c 89 2f             	mov    %r13,(%rdi)
  b05b71:	48 89 47 08          	mov    %rax,0x8(%rdi)
  b05b75:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
  b05b79:	4c 89 c0             	mov    %r8,%rax
  b05b7c:	4c 29 f8             	sub    %r15,%rax
  b05b7f:	0f 82 c4 02 00 00    	jb     b05e49 <std::path::compare_components+0x3b9>
  b05b85:	4d 01 fc             	add    %r15,%r12
  b05b88:	4c 89 26             	mov    %r12,(%rsi)
  b05b8b:	48 89 46 08          	mov    %rax,0x8(%rsi)
  b05b8f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
  b05b93:	0f 10 07             	movups (%rdi),%xmm0
  b05b96:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  b05b9a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  b05b9e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
  b05ba2:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  b05ba9:	00 
  b05baa:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  b05bb1:	00 
  b05bb2:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  b05bb9:	00 
  b05bba:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  b05bc1:	00 
  b05bc2:	48 8b 06             	mov    (%rsi),%rax
  b05bc5:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  b05bc9:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
  b05bcd:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
  b05bd1:	48 8b 56 30          	mov    0x30(%rsi),%rdx
  b05bd5:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  b05bda:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
  b05bde:	88 54 24 48          	mov    %dl,0x48(%rsp)
  b05be2:	8b 56 39             	mov    0x39(%rsi),%edx
  b05be5:	89 54 24 49          	mov    %edx,0x49(%rsp)
  b05be9:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
  b05bed:	66 89 54 24 4d       	mov    %dx,0x4d(%rsp)
  b05bf2:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
  b05bf6:	88 54 24 4f          	mov    %dl,0x4f(%rsp)
  b05bfa:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  b05bff:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  b05c04:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  b05c09:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  b05c0e:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  b05c13:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
  b05c1a:	00 
  b05c1b:	ff 15 ff b7 5a 01    	call   *0x15ab7ff(%rip)        # 20b1420 <_DYNAMIC+0x9a0>
  b05c21:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
  b05c27:	41 80 fc ff          	cmp    $0xff,%r12b
  b05c2b:	0f 84 b7 01 00 00    	je     b05de8 <std::path::compare_components+0x358>
  b05c31:	48 8b 05 e8 b7 5a 01 	mov    0x15ab7e8(%rip),%rax        # 20b1420 <_DYNAMIC+0x9a0>
  b05c38:	eb 2f                	jmp    b05c69 <std::path::compare_components+0x1d9>
  b05c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  b05c40:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  b05c45:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
  b05c4c:	00 
  b05c4d:	48 8b 1d cc b7 5a 01 	mov    0x15ab7cc(%rip),%rbx        # 20b1420 <_DYNAMIC+0x9a0>
  b05c54:	ff d3                	call   *%rbx
  b05c56:	48 89 d8             	mov    %rbx,%rax
  b05c59:	44 0f b6 64 24 50    	movzbl 0x50(%rsp),%r12d
  b05c5f:	41 80 fc ff          	cmp    $0xff,%r12b
  b05c63:	0f 84 7f 01 00 00    	je     b05de8 <std::path::compare_components+0x358>
  b05c69:	44 0f b6 7c 24 51    	movzbl 0x51(%rsp),%r15d
  b05c6f:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
  b05c74:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  b05c79:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
  b05c7e:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  b05c83:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  b05c8a:	00 
  b05c8b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  b05c90:	ff d0                	call   *%rax
  b05c92:	0f b6 bc 24 88 00 00 	movzbl 0x88(%rsp),%edi
  b05c99:	00 
  b05c9a:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
  b05ca1:	0f 84 63 01 00 00    	je     b05e0a <std::path::compare_components+0x37a>
  b05ca7:	41 0f b6 cc          	movzbl %r12b,%ecx
  b05cab:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
  b05caf:	80 f9 06             	cmp    $0x6,%cl
  b05cb2:	ba 00 00 00 00       	mov    $0x0,%edx
  b05cb7:	4c 0f 42 c2          	cmovb  %rdx,%r8
  b05cbb:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
  b05cbf:	40 80 ff 06          	cmp    $0x6,%dil
  b05cc3:	48 0f 42 c2          	cmovb  %rdx,%rax
  b05cc7:	49 39 c0             	cmp    %rax,%r8
  b05cca:	0f 9c c2             	setl   %dl
  b05ccd:	0f 9f c0             	setg   %al
  b05cd0:	0f 85 8a 00 00 00    	jne    b05d60 <std::path::compare_components+0x2d0>
  b05cd6:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  b05cdd:	00 
  b05cde:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  b05ce5:	00 
  b05ce6:	41 83 f8 04          	cmp    $0x4,%r8d
  b05cea:	74 4a                	je     b05d36 <std::path::compare_components+0x2a6>
  b05cec:	4d 85 c0             	test   %r8,%r8
  b05cef:	0f 85 4b ff ff ff    	jne    b05c40 <std::path::compare_components+0x1b0>
  b05cf5:	40 80 ff 05          	cmp    $0x5,%dil
  b05cf9:	0f 87 41 ff ff ff    	ja     b05c40 <std::path::compare_components+0x1b0>
  b05cff:	48 39 f9             	cmp    %rdi,%rcx
  b05d02:	41 0f 9c c0          	setl   %r8b
  b05d06:	0f 9f c0             	setg   %al
  b05d09:	41 38 fc             	cmp    %dil,%r12b
  b05d0c:	75 6c                	jne    b05d7a <std::path::compare_components+0x2ea>
  b05d0e:	0f b6 84 24 89 00 00 	movzbl 0x89(%rsp),%eax
  b05d15:	00 
  b05d16:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
  b05d1d:	00 
  b05d1e:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
  b05d25:	00 
  b05d26:	48 8d 3d 77 a0 86 ff 	lea    -0x795f89(%rip),%rdi        # 36fda4 <sharded_slab::tid::REGISTRY+0x17c4>
  b05d2d:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
  b05d31:	48 01 f9             	add    %rdi,%rcx
  b05d34:	ff e1                	jmp    *%rcx
  b05d36:	4c 89 f3             	mov    %r14,%rbx
  b05d39:	48 29 d3             	sub    %rdx,%rbx
  b05d3c:	49 0f 42 d6          	cmovb  %r14,%rdx
  b05d40:	48 89 ef             	mov    %rbp,%rdi
  b05d43:	ff 15 cf af 5a 01    	call   *0x15aafcf(%rip)        # 20b0d18 <memcmp@GLIBC_2.2.5>
  b05d49:	48 98                	cltq
  b05d4b:	85 c0                	test   %eax,%eax
  b05d4d:	48 0f 45 d8          	cmovne %rax,%rbx
  b05d51:	48 85 db             	test   %rbx,%rbx
  b05d54:	0f 98 c1             	sets   %cl
  b05d57:	0f 9f c0             	setg   %al
  b05d5a:	28 c8                	sub    %cl,%al
  b05d5c:	eb 04                	jmp    b05d62 <std::path::compare_components+0x2d2>
  b05d5e:	66 90                	xchg   %ax,%ax
  b05d60:	28 d0                	sub    %dl,%al
  b05d62:	3c fe                	cmp    $0xfe,%al
  b05d64:	0f 84 d6 fe ff ff    	je     b05c40 <std::path::compare_components+0x1b0>
  b05d6a:	0f b6 c8             	movzbl %al,%ecx
  b05d6d:	85 c9                	test   %ecx,%ecx
  b05d6f:	0f 84 cb fe ff ff    	je     b05c40 <std::path::compare_components+0x1b0>
  b05d75:	e9 92 00 00 00       	jmp    b05e0c <std::path::compare_components+0x37c>
  b05d7a:	44 28 c0             	sub    %r8b,%al
  b05d7d:	eb e3                	jmp    b05d62 <std::path::compare_components+0x2d2>
  b05d7f:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  b05d84:	4c 89 04 24          	mov    %r8,(%rsp)
  b05d88:	4d 89 f7             	mov    %r14,%r15
  b05d8b:	49 29 d7             	sub    %rdx,%r15
  b05d8e:	49 0f 42 d6          	cmovb  %r14,%rdx
  b05d92:	48 89 ef             	mov    %rbp,%rdi
  b05d95:	4c 8b 25 7c af 5a 01 	mov    0x15aaf7c(%rip),%r12        # 20b0d18 <memcmp@GLIBC_2.2.5>
  b05d9c:	41 ff d4             	call   *%r12
  b05d9f:	48 98                	cltq
  b05da1:	85 c0                	test   %eax,%eax
  b05da3:	4c 0f 45 f8          	cmovne %rax,%r15
  b05da7:	4d 85 ff             	test   %r15,%r15
  b05daa:	0f 98 c1             	sets   %cl
  b05dad:	0f 9f c0             	setg   %al
  b05db0:	75 a8                	jne    b05d5a <std::path::compare_components+0x2ca>
  b05db2:	49 89 de             	mov    %rbx,%r14
  b05db5:	48 8b 14 24          	mov    (%rsp),%rdx
  b05db9:	49 29 d6             	sub    %rdx,%r14
  b05dbc:	48 0f 42 d3          	cmovb  %rbx,%rdx
  b05dc0:	4c 89 ef             	mov    %r13,%rdi
  b05dc3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  b05dc8:	41 ff d4             	call   *%r12
  b05dcb:	48 98                	cltq
  b05dcd:	85 c0                	test   %eax,%eax
  b05dcf:	4c 0f 45 f0          	cmovne %rax,%r14
  b05dd3:	4d 85 f6             	test   %r14,%r14
  b05dd6:	e9 79 ff ff ff       	jmp    b05d54 <std::path::compare_components+0x2c4>
  b05ddb:	41 38 c7             	cmp    %al,%r15b
  b05dde:	0f 97 c0             	seta   %al
  b05de1:	1c 00                	sbb    $0x0,%al
  b05de3:	e9 7a ff ff ff       	jmp    b05d62 <std::path::compare_components+0x2d2>
  b05de8:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  b05def:	00 
  b05df0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  b05df5:	ff 15 25 b6 5a 01    	call   *0x15ab625(%rip)        # 20b1420 <_DYNAMIC+0x9a0>
  b05dfb:	80 bc 24 88 00 00 00 	cmpb   $0xff,0x88(%rsp)
  b05e02:	ff 
  b05e03:	0f 95 c0             	setne  %al
  b05e06:	f6 d8                	neg    %al
  b05e08:	eb 02                	jmp    b05e0c <std::path::compare_components+0x37c>
  b05e0a:	b0 01                	mov    $0x1,%al
  b05e0c:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
  b05e13:	5b                   	pop    %rbx
  b05e14:	41 5c                	pop    %r12
  b05e16:	41 5d                	pop    %r13
  b05e18:	41 5e                	pop    %r14
  b05e1a:	41 5f                	pop    %r15
  b05e1c:	5d                   	pop    %rbp
  b05e1d:	c3                   	ret
  b05e1e:	48 8d 0d 03 26 52 01 	lea    0x1522603(%rip),%rcx        # 2028428 <anon.27e520e72b4dbf5de48359dc0653d79c.351.llvm.7576718222322155228>
  b05e25:	31 ff                	xor    %edi,%edi
  b05e27:	48 89 d6             	mov    %rdx,%rsi
  b05e2a:	4c 89 f2             	mov    %r14,%rdx
  b05e2d:	ff 15 c5 ae 5a 01    	call   *0x15aaec5(%rip)        # 20b0cf8 <_DYNAMIC+0x278>
  b05e33:	48 8d 0d d6 25 52 01 	lea    0x15225d6(%rip),%rcx        # 2028410 <anon.27e520e72b4dbf5de48359dc0653d79c.350.llvm.7576718222322155228>
  b05e3a:	4c 89 ff             	mov    %r15,%rdi
  b05e3d:	4c 89 f6             	mov    %r14,%rsi
  b05e40:	4c 89 f2             	mov    %r14,%rdx
  b05e43:	ff 15 af ae 5a 01    	call   *0x15aaeaf(%rip)        # 20b0cf8 <_DYNAMIC+0x278>
  b05e49:	48 8d 0d a8 25 52 01 	lea    0x15225a8(%rip),%rcx        # 20283f8 <anon.27e520e72b4dbf5de48359dc0653d79c.349.llvm.7576718222322155228>
  b05e50:	4c 89 ff             	mov    %r15,%rdi
  b05e53:	4c 89 c6             	mov    %r8,%rsi
  b05e56:	4c 89 c2             	mov    %r8,%rdx
  b05e59:	ff 15 99 ae 5a 01    	call   *0x15aae99(%rip)        # 20b0cf8 <_DYNAMIC+0x278>
