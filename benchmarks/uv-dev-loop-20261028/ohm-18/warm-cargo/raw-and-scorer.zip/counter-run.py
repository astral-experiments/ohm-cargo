from common import *
import fcntl
spec=json.loads((LAB/'counter-plan.json').read_text()); label=sys.argv[1];c=spec['studies'][label]
out=LAB/'driver-counters'/label;out.parent.mkdir(exist_ok=True);assert not out.exists()
assert sorted(os.sched_getaffinity(0))==spec['cpus']
src=OLD/c['source']
before=subprocess.check_output(['git','-C',WORK/'uv','show',REVISION+':'+str(EDIT_PATH)])
assert (src/EDIT_PATH).read_bytes()==before
bins=WORK/'round18-cargo'/c['driver']/'bin'
en=dict(os.environ,PATH='/usr/bin:/bin:/usr/local/bin',OHM_TOOLCHAIN_BIN=str(DIST/'bin'),TZ='UTC',LC_ALL='C.UTF-8')
cmd=[sys.executable,'-E','-s',str(WORK/'measure.py'),'--base',str(bins/'base'),'--candidate',str(bins/'guard-stack'),'--result',str(out),'--source',str(src),'--cargo-home',str(OLD/c['home']),'--target',c['target'],'--mode',c['mode'],'--pairs',str(c['pairs']),'--seed',str(c['seed']),'--endpoints',*spec['endpoint_order'],'--ordinary','--settle-counter']
if label=='replica':
    cmd[3]=str(LAB/'measure-pause.py')
    en.update(OHM_BENCH_WORK=str(WORK),OHM_COUNTS_PAUSE=str(LAB/'pgo-cachegrind.pause'))
with (ROOT/('counter-'+c['target']+'.lock')).open('a') as f:
    fcntl.flock(f,fcntl.LOCK_EX)
    subprocess.run(cmd,env=en,check=True)
    assert (src/EDIT_PATH).read_bytes()==before
csvp=out/'pairs.csv'
import csv
with csvp.open() as f:rows=list(csv.DictReader(f))
for ep,order in c['orders'].items():
    rr=[x for x in rows if x['endpoint']==ep];assert len(rr)==2*len(order)
    assert [x['arm'] for x in rr]==[a for pair in order for a in pair]
    for x in rr:
        log=(out/f"{ep}-{x['pair']}-{x['arm']}.log").read_text()
        ro=rosters(log);assert not ro['compiled'] and len(ro['tests'])==(72 if ep=='test' else 0)
(out/'audited.json').write_text(json.dumps(dict(plan_sha256=sha(LAB/'counter-plan.json'),rows_sha256=sha(csvp),rows=len(rows),uv=REVISION,source_sha256=sha(src/EDIT_PATH)),indent=2)+'\n')
