from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

LAB = Path(__file__).resolve().parent
WORK = LAB.parent
sys.path.insert(0, str(WORK))
from edit_holdout import BEFORE, EDIT_PATH, REVISION
DIST = WORK / 'upstream-monitor/toolchain18'
OLD = Path((WORK/'bench-home.path').read_text().strip())
ROOT = OLD / 'round18'
LINK = Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')
COMMANDS = {'check':['check'], 'build':['build'], 'test':['test','--no-run']}


def fixture(study):
    return ROOT / {'initial':'a', 'replica':'independent/longer-checkout-b', 'pilot':'pilot', 'third':'third'}[study]


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def command(ep, options=None):
    return [str(ROOT/'tools/bin/cargo'), *COMMANDS[ep], *(['--locked','--offline','-j8'] if options is None else options)]


def env(root):
    tool = ROOT/'tools/bin'
    return dict(HOME=os.environ['HOME'], PATH=f"{tool}:/usr/local/bin:/usr/bin:/bin",
                LANG='C.UTF-8', LC_ALL='C.UTF-8', TZ='UTC', CARGO_TERM_COLOR='never',
                CARGO_HOME=str(root/'cargo-home'), CARGO_TARGET_DIR=str(root/'target'), CARGO_NET_OFFLINE='true',
                RUSTC=str(tool/'rustc'), RUSTDOC=str(tool/'rustdoc'), SSL_CERT_DIR='/etc/ssl/certs')


def edit(root, tag, shape='predicate'):
    path = root/'uv'/EDIT_PATH
    pristine = (root/'original').read_bytes()
    assert pristine.count(BEFORE.encode()) == 1
    after = ('{\n                component == cellar && (next == formula || next == OsStr::new('
             f'"uv-preview-{tag}"))\n            }}')
    if shape == 'predicate':
        content = pristine.replace(BEFORE.encode(), after.encode())
    elif shape == 'brew-help':
        before = b'brew update && brew upgrade uv'
        assert pristine.count(before) == 1
        content = pristine.replace(before, before + f' # edit {tag}'.encode())
    else:
        raise ValueError(shape)
    path.write_bytes(content)
    return hashlib.sha256(content).hexdigest()


def rosters(body):
    import re
    if not re.search(r'^\s*Finished ',body,re.M) or re.search(r'^\s*(Running|Updating|Downloading|Blocking) |^running \d+ tests?',body,re.M):
        raise RuntimeError(body[-500:])
    return {'compiled': sorted(re.findall(r'^\s*(?:Checking|Compiling) (.+)$',body,re.M)),
            'tests': sorted(re.findall(r'^\s*Executable (.+)$',body,re.M))}


def run(root, ep, log, *, extra=(), overrides=None, prefix=()):
    import time
    e=env(root)
    e.update(overrides or {})
    with log.open('x') as f:
        start=time.monotonic_ns()
        p=subprocess.Popen([*prefix,*command(ep),*extra],cwd=root/'uv',env=e,
                          stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        rc=p.wait()
        elapsed=time.monotonic_ns()-start
    if rc: raise RuntimeError(f'{log}: {log.read_text()[-1500:]}')
    return elapsed, rosters(log.read_text(errors='replace'))
