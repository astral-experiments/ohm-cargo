"""Prepare dedicated pre-existing release-18 fixtures for independent driver counters."""
from common import *
import datetime,time
which=sys.argv[1]; oldplan=json.loads((WORK/'upstream-monitor/cargo/depfile-plan.json').read_text())
c=oldplan['cohorts'][which]
src=OLD/c['source']; home=OLD/c['cargo_home']; target=OLD/('target-'+c['target'])
stable=subprocess.check_output(['git','-C',WORK/'uv','show',REVISION+':'+str(EDIT_PATH)])
assert (src/EDIT_PATH).read_bytes()==stable
out=LAB/'counter-prep'/which;out.mkdir(parents=True)
tenv=dict(HOME=os.environ['HOME'],PATH=f"{DIST/'bin'}:/usr/local/bin:/usr/bin:/bin",LANG='C.UTF-8',LC_ALL='C.UTF-8',CARGO_NET_OFFLINE='true',CARGO_HOME=str(home),CARGO_TARGET_DIR=str(target),CARGO_TERM_COLOR='never',RUSTC=str(DIST/'bin/rustc'),RUSTDOC=str(DIST/'bin/rustdoc'))
rows=[]
for ep in ['build','test','check']:
    for i in range(2):
        t=time.monotonic()
        with (out/f'{ep}-{i}.log').open('x') as f:subprocess.run([DIST/'bin/cargo',*COMMANDS[ep]],env=tenv,cwd=src,stdout=f,stderr=subprocess.STDOUT,check=True)
        result=rosters((out/f'{ep}-{i}.log').read_text())
        assert len(result['tests'])==(72 if ep=='test' else 0) and (i==0 or not result['compiled'])
        rows.append([ep,i,time.monotonic()-t,len(result['compiled']),len(result['tests'])])
        print(rows[-1],flush=True)
assert (src/EDIT_PATH).read_bytes()==stable
(out/'ready.json').write_text(json.dumps(rows,indent=2)+'\n')
