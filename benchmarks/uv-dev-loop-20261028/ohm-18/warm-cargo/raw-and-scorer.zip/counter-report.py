import json
from pathlib import Path
LAB = Path(__file__).resolve().parent
from analyze import signed_histogram,two_sided_sign,median_interval
import collections,csv,statistics
p=json.loads((LAB/'counter-plan.json').read_text());agg={}
for name,c in p['studies'].items():
    d=LAB/'driver-counters'/name
    if not (d/'pairs.csv').is_file():continue
    with (d/'pairs.csv').open() as f:allrows=list(csv.DictReader(f))
    by={}
    for ep in p['endpoint_order']:
        rows=[r for r in allrows if r['endpoint']==ep]
        if len(rows)!=c['pairs']*2:continue
        vals=[];periods=[];obs=collections.defaultdict(list)
        for i,order in enumerate(c['orders'][ep]):
            pair=rows[2*i:2*i+2];assert [r['arm'] for r in pair]==order
            v={r['arm']:int(r['value']) for r in pair}
            for arm,n in v.items():obs[arm].append(n)
            vals.append(100*(1-v['candidate']/v['base']))
            change=int(pair[0]['value'])-int(pair[1]['value']);periods.append((change>0)-(change<0))
        wins=sum(v>0 for v in vals);losses=sum(v<0 for v in vals);hist=signed_histogram(periods,len(vals)//2)
        by[ep]=dict(n=len(vals),wins=wins,losses=losses,median_improvement_pct=statistics.median(vals),median_interval=median_interval(vals),
                    control_instructions=statistics.median(obs['base']),treatment_instructions=statistics.median(obs['candidate']),
                    exact_sign_p=two_sided_sign(wins,losses),conditioned_p=sum(n for v,n in hist.items() if abs(v)>=abs(wins-losses))/sum(hist.values()))
    agg[name]=by
print(json.dumps(agg,indent=2))
