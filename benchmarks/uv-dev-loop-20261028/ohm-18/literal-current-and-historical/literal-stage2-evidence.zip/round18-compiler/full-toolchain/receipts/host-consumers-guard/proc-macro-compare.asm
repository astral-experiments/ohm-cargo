
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/receipts/host-consumers-guard/libhost_macro.so:     file format elf64-x86-64


Disassembly of section .text:

000000000002f6b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
   2f6b0:	55                   	push   %rbp
   2f6b1:	48 89 e5             	mov    %rsp,%rbp
   2f6b4:	41 57                	push   %r15
   2f6b6:	41 56                	push   %r14
   2f6b8:	41 55                	push   %r13
   2f6ba:	41 54                	push   %r12
   2f6bc:	53                   	push   %rbx
   2f6bd:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   2f6c4:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
   2f6c8:	0f 85 25 02 00 00    	jne    2f8f3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   2f6ce:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
   2f6d2:	0f 85 1b 02 00 00    	jne    2f8f3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   2f6d8:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
   2f6dc:	3a 46 38             	cmp    0x38(%rsi),%al
   2f6df:	0f 85 0e 02 00 00    	jne    2f8f3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   2f6e5:	4c 8b 2f             	mov    (%rdi),%r13
   2f6e8:	4c 8b 77 08          	mov    0x8(%rdi),%r14
   2f6ec:	4c 8b 26             	mov    (%rsi),%r12
   2f6ef:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   2f6f3:	4c 39 f3             	cmp    %r14,%rbx
   2f6f6:	4d 89 f7             	mov    %r14,%r15
   2f6f9:	4c 0f 42 fb          	cmovb  %rbx,%r15
   2f6fd:	49 83 ff 07          	cmp    $0x7,%r15
   2f701:	0f 87 d7 00 00 00    	ja     2f7de <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x12e>
   2f707:	4d 85 ff             	test   %r15,%r15
   2f70a:	0f 84 8e 01 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f710:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   2f715:	41 3a 04 24          	cmp    (%r12),%al
   2f719:	0f 85 52 01 00 00    	jne    2f871 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c1>
   2f71f:	49 83 ff 01          	cmp    $0x1,%r15
   2f723:	0f 84 75 01 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f729:	41 0f b6 45 01       	movzbl 0x1(%r13),%eax
   2f72e:	ba 01 00 00 00       	mov    $0x1,%edx
   2f733:	41 3a 44 24 01       	cmp    0x1(%r12),%al
   2f738:	0f 85 45 01 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f73e:	49 83 ff 02          	cmp    $0x2,%r15
   2f742:	0f 84 56 01 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f748:	41 0f b6 45 02       	movzbl 0x2(%r13),%eax
   2f74d:	ba 02 00 00 00       	mov    $0x2,%edx
   2f752:	41 3a 44 24 02       	cmp    0x2(%r12),%al
   2f757:	0f 85 26 01 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f75d:	49 83 ff 03          	cmp    $0x3,%r15
   2f761:	0f 84 37 01 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f767:	41 0f b6 45 03       	movzbl 0x3(%r13),%eax
   2f76c:	ba 03 00 00 00       	mov    $0x3,%edx
   2f771:	41 3a 44 24 03       	cmp    0x3(%r12),%al
   2f776:	0f 85 07 01 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f77c:	49 83 ff 04          	cmp    $0x4,%r15
   2f780:	0f 84 18 01 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f786:	41 0f b6 45 04       	movzbl 0x4(%r13),%eax
   2f78b:	ba 04 00 00 00       	mov    $0x4,%edx
   2f790:	41 3a 44 24 04       	cmp    0x4(%r12),%al
   2f795:	0f 85 e8 00 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f79b:	49 83 ff 05          	cmp    $0x5,%r15
   2f79f:	0f 84 f9 00 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f7a5:	41 0f b6 45 05       	movzbl 0x5(%r13),%eax
   2f7aa:	ba 05 00 00 00       	mov    $0x5,%edx
   2f7af:	41 3a 44 24 05       	cmp    0x5(%r12),%al
   2f7b4:	0f 85 c9 00 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f7ba:	49 83 ff 06          	cmp    $0x6,%r15
   2f7be:	0f 84 da 00 00 00    	je     2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f7c4:	41 0f b6 45 06       	movzbl 0x6(%r13),%eax
   2f7c9:	ba 06 00 00 00       	mov    $0x6,%edx
   2f7ce:	41 3a 44 24 06       	cmp    0x6(%r12),%al
   2f7d3:	0f 85 aa 00 00 00    	jne    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f7d9:	e9 c0 00 00 00       	jmp    2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f7de:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   2f7e3:	41 3a 04 24          	cmp    (%r12),%al
   2f7e7:	0f 85 7f 00 00 00    	jne    2f86c <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1bc>
   2f7ed:	4c 89 f9             	mov    %r15,%rcx
   2f7f0:	48 c1 e9 03          	shr    $0x3,%rcx
   2f7f4:	74 24                	je     2f81a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x16a>
   2f7f6:	31 c0                	xor    %eax,%eax
   2f7f8:	31 d2                	xor    %edx,%edx
   2f7fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f800:	4d 8b 44 d5 00       	mov    0x0(%r13,%rdx,8),%r8
   2f805:	4d 8b 0c d4          	mov    (%r12,%rdx,8),%r9
   2f809:	4d 39 c8             	cmp    %r9,%r8
   2f80c:	75 67                	jne    2f875 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c5>
   2f80e:	48 ff c2             	inc    %rdx
   2f811:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
   2f815:	48 39 d1             	cmp    %rdx,%rcx
   2f818:	75 e6                	jne    2f800 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x150>
   2f81a:	49 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r8
   2f821:	ff ff 7f 
   2f824:	4d 21 f8             	and    %r15,%r8
   2f827:	44 89 f8             	mov    %r15d,%eax
   2f82a:	83 e0 07             	and    $0x7,%eax
   2f82d:	74 15                	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2f82f:	43 0f b6 4c 05 00    	movzbl 0x0(%r13,%r8,1),%ecx
   2f835:	43 3a 0c 04          	cmp    (%r12,%r8,1),%cl
   2f839:	75 56                	jne    2f891 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e1>
   2f83b:	83 f8 01             	cmp    $0x1,%eax
   2f83e:	0f 85 31 03 00 00    	jne    2fb75 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4c5>
   2f844:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
   2f848:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
   2f84c:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
   2f850:	e8 cb 29 00 00       	call   32220 <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
   2f855:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
   2f859:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
   2f85d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
   2f861:	48 83 f8 01          	cmp    $0x1,%rax
   2f865:	75 37                	jne    2f89e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   2f867:	4c 01 c2             	add    %r8,%rdx
   2f86a:	eb 17                	jmp    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f86c:	45 31 ff             	xor    %r15d,%r15d
   2f86f:	eb 39                	jmp    2f8aa <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   2f871:	31 d2                	xor    %edx,%edx
   2f873:	eb 0e                	jmp    2f883 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   2f875:	4d 31 c1             	xor    %r8,%r9
   2f878:	f3 49 0f bc d1       	tzcnt  %r9,%rdx
   2f87d:	c1 ea 03             	shr    $0x3,%edx
   2f880:	48 29 c2             	sub    %rax,%rdx
   2f883:	4c 39 f2             	cmp    %r14,%rdx
   2f886:	0f 87 9f 03 00 00    	ja     2fc2b <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x57b>
   2f88c:	49 89 d7             	mov    %rdx,%r15
   2f88f:	eb 19                	jmp    2f8aa <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   2f891:	31 d2                	xor    %edx,%edx
   2f893:	b8 01 00 00 00       	mov    $0x1,%eax
   2f898:	48 83 f8 01          	cmp    $0x1,%rax
   2f89c:	74 c9                	je     2f867 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1b7>
   2f89e:	49 39 de             	cmp    %rbx,%r14
   2f8a1:	75 07                	jne    2f8aa <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   2f8a3:	31 c0                	xor    %eax,%eax
   2f8a5:	e9 b9 02 00 00       	jmp    2fb63 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   2f8aa:	4d 85 ff             	test   %r15,%r15
   2f8ad:	74 44                	je     2f8f3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   2f8af:	90                   	nop
   2f8b0:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
   2f8b6:	74 07                	je     2f8bf <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x20f>
   2f8b8:	49 ff cf             	dec    %r15
   2f8bb:	75 f3                	jne    2f8b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x200>
   2f8bd:	eb 34                	jmp    2f8f3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   2f8bf:	4c 89 f0             	mov    %r14,%rax
   2f8c2:	4c 29 f8             	sub    %r15,%rax
   2f8c5:	0f 82 75 03 00 00    	jb     2fc40 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x590>
   2f8cb:	4d 01 fd             	add    %r15,%r13
   2f8ce:	4c 89 2f             	mov    %r13,(%rdi)
   2f8d1:	48 89 47 08          	mov    %rax,0x8(%rdi)
   2f8d5:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
   2f8d9:	48 89 d8             	mov    %rbx,%rax
   2f8dc:	4c 29 f8             	sub    %r15,%rax
   2f8df:	0f 82 71 03 00 00    	jb     2fc56 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x5a6>
   2f8e5:	4d 01 fc             	add    %r15,%r12
   2f8e8:	4c 89 26             	mov    %r12,(%rsi)
   2f8eb:	48 89 46 08          	mov    %rax,0x8(%rsi)
   2f8ef:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
   2f8f3:	0f 10 07             	movups (%rdi),%xmm0
   2f8f6:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
   2f8fa:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
   2f8fe:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
   2f902:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
   2f909:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
   2f910:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
   2f917:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
   2f91e:	48 8b 06             	mov    (%rsi),%rax
   2f921:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   2f925:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
   2f929:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
   2f92d:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   2f931:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
   2f935:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
   2f939:	88 55 b8             	mov    %dl,-0x48(%rbp)
   2f93c:	8b 56 39             	mov    0x39(%rsi),%edx
   2f93f:	89 55 b9             	mov    %edx,-0x47(%rbp)
   2f942:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
   2f946:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
   2f94a:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
   2f94e:	88 55 bf             	mov    %dl,-0x41(%rbp)
   2f951:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
   2f955:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
   2f959:	48 89 45 80          	mov    %rax,-0x80(%rbp)
   2f95d:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
   2f961:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   2f968:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   2f96f:	ff 15 4b b0 02 00    	call   *0x2b04b(%rip)        # 5a9c0 <_GLOBAL_OFFSET_TABLE_+0x280>
   2f975:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   2f97c:	ff 
   2f97d:	41 80 fc ff          	cmp    $0xff,%r12b
   2f981:	0f 84 bb 01 00 00    	je     2fb42 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
   2f987:	48 8d 05 b2 40 00 00 	lea    0x40b2(%rip),%rax        # 33a40 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   2f98e:	eb 2c                	jmp    2f9bc <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x30c>
   2f990:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   2f997:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   2f99e:	48 8d 1d 9b 40 00 00 	lea    0x409b(%rip),%rbx        # 33a40 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   2f9a5:	ff d3                	call   *%rbx
   2f9a7:	48 89 d8             	mov    %rbx,%rax
   2f9aa:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   2f9b1:	ff 
   2f9b2:	41 80 fc ff          	cmp    $0xff,%r12b
   2f9b6:	0f 84 86 01 00 00    	je     2fb42 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
   2f9bc:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
   2f9c3:	ff 
   2f9c4:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
   2f9cb:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
   2f9d2:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
   2f9d9:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   2f9dd:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
   2f9e4:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   2f9eb:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   2f9ef:	ff d0                	call   *%rax
   2f9f1:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
   2f9f8:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
   2f9ff:	0f 84 5c 01 00 00    	je     2fb61 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b1>
   2fa05:	41 0f b6 cc          	movzbl %r12b,%ecx
   2fa09:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
   2fa0d:	80 f9 06             	cmp    $0x6,%cl
   2fa10:	ba 00 00 00 00       	mov    $0x0,%edx
   2fa15:	4c 0f 42 c2          	cmovb  %rdx,%r8
   2fa19:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
   2fa1d:	40 80 ff 06          	cmp    $0x6,%dil
   2fa21:	48 0f 42 c2          	cmovb  %rdx,%rax
   2fa25:	49 39 c0             	cmp    %rax,%r8
   2fa28:	0f 9c c2             	setl   %dl
   2fa2b:	0f 9f c0             	setg   %al
   2fa2e:	0f 85 8c 00 00 00    	jne    2fac0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x410>
   2fa34:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
   2fa3b:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
   2fa42:	41 83 f8 04          	cmp    $0x4,%r8d
   2fa46:	74 47                	je     2fa8f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3df>
   2fa48:	4d 85 c0             	test   %r8,%r8
   2fa4b:	0f 85 3f ff ff ff    	jne    2f990 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   2fa51:	40 80 ff 05          	cmp    $0x5,%dil
   2fa55:	0f 87 35 ff ff ff    	ja     2f990 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   2fa5b:	48 39 f9             	cmp    %rdi,%rcx
   2fa5e:	41 0f 9c c0          	setl   %r8b
   2fa62:	0f 9f c0             	setg   %al
   2fa65:	41 38 fc             	cmp    %dil,%r12b
   2fa68:	75 70                	jne    2fada <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x42a>
   2fa6a:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
   2fa71:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
   2fa78:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
   2fa7f:	48 8d 3d d2 c9 01 00 	lea    0x1c9d2(%rip),%rdi        # 4c458 <_fini+0x67c4>
   2fa86:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
   2fa8a:	48 01 f9             	add    %rdi,%rcx
   2fa8d:	ff e1                	jmp    *%rcx
   2fa8f:	49 89 de             	mov    %rbx,%r14
   2fa92:	49 29 d6             	sub    %rdx,%r14
   2fa95:	48 0f 42 d3          	cmovb  %rbx,%rdx
   2fa99:	4c 89 ff             	mov    %r15,%rdi
   2fa9c:	ff 15 2e b0 02 00    	call   *0x2b02e(%rip)        # 5aad0 <memcmp@GLIBC_2.2.5>
   2faa2:	48 98                	cltq
   2faa4:	85 c0                	test   %eax,%eax
   2faa6:	4c 0f 45 f0          	cmovne %rax,%r14
   2faaa:	4d 85 f6             	test   %r14,%r14
   2faad:	0f 98 c1             	sets   %cl
   2fab0:	0f 9f c0             	setg   %al
   2fab3:	28 c8                	sub    %cl,%al
   2fab5:	eb 0b                	jmp    2fac2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   2fab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2fabe:	00 00 
   2fac0:	28 d0                	sub    %dl,%al
   2fac2:	3c fe                	cmp    $0xfe,%al
   2fac4:	0f 84 c6 fe ff ff    	je     2f990 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   2faca:	0f b6 c8             	movzbl %al,%ecx
   2facd:	85 c9                	test   %ecx,%ecx
   2facf:	0f 84 bb fe ff ff    	je     2f990 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   2fad5:	e9 89 00 00 00       	jmp    2fb63 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   2fada:	44 28 c0             	sub    %r8b,%al
   2fadd:	eb e3                	jmp    2fac2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   2fadf:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
   2fae3:	4d 89 c5             	mov    %r8,%r13
   2fae6:	49 89 dc             	mov    %rbx,%r12
   2fae9:	49 29 d4             	sub    %rdx,%r12
   2faec:	48 0f 42 d3          	cmovb  %rbx,%rdx
   2faf0:	4c 89 ff             	mov    %r15,%rdi
   2faf3:	4c 8b 3d d6 af 02 00 	mov    0x2afd6(%rip),%r15        # 5aad0 <memcmp@GLIBC_2.2.5>
   2fafa:	41 ff d7             	call   *%r15
   2fafd:	48 98                	cltq
   2faff:	85 c0                	test   %eax,%eax
   2fb01:	4c 0f 45 e0          	cmovne %rax,%r12
   2fb05:	4d 85 e4             	test   %r12,%r12
   2fb08:	0f 98 c1             	sets   %cl
   2fb0b:	0f 9f c0             	setg   %al
   2fb0e:	75 a3                	jne    2fab3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x403>
   2fb10:	4c 89 f3             	mov    %r14,%rbx
   2fb13:	4c 89 ea             	mov    %r13,%rdx
   2fb16:	4c 29 eb             	sub    %r13,%rbx
   2fb19:	49 0f 42 d6          	cmovb  %r14,%rdx
   2fb1d:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   2fb21:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   2fb25:	41 ff d7             	call   *%r15
   2fb28:	48 98                	cltq
   2fb2a:	85 c0                	test   %eax,%eax
   2fb2c:	48 0f 45 d8          	cmovne %rax,%rbx
   2fb30:	48 85 db             	test   %rbx,%rbx
   2fb33:	e9 75 ff ff ff       	jmp    2faad <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3fd>
   2fb38:	41 38 c5             	cmp    %al,%r13b
   2fb3b:	0f 97 c0             	seta   %al
   2fb3e:	1c 00                	sbb    $0x0,%al
   2fb40:	eb 80                	jmp    2fac2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   2fb42:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   2fb49:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   2fb4d:	ff 15 6d ae 02 00    	call   *0x2ae6d(%rip)        # 5a9c0 <_GLOBAL_OFFSET_TABLE_+0x280>
   2fb53:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
   2fb5a:	0f 95 c0             	setne  %al
   2fb5d:	f6 d8                	neg    %al
   2fb5f:	eb 02                	jmp    2fb63 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   2fb61:	b0 01                	mov    $0x1,%al
   2fb63:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   2fb6a:	5b                   	pop    %rbx
   2fb6b:	41 5c                	pop    %r12
   2fb6d:	41 5d                	pop    %r13
   2fb6f:	41 5e                	pop    %r14
   2fb71:	41 5f                	pop    %r15
   2fb73:	5d                   	pop    %rbp
   2fb74:	c3                   	ret
   2fb75:	43 0f b6 4c 05 01    	movzbl 0x1(%r13,%r8,1),%ecx
   2fb7b:	ba 01 00 00 00       	mov    $0x1,%edx
   2fb80:	43 3a 4c 04 01       	cmp    0x1(%r12,%r8,1),%cl
   2fb85:	0f 85 08 fd ff ff    	jne    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fb8b:	83 f8 02             	cmp    $0x2,%eax
   2fb8e:	0f 84 b0 fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fb94:	43 0f b6 4c 05 02    	movzbl 0x2(%r13,%r8,1),%ecx
   2fb9a:	ba 02 00 00 00       	mov    $0x2,%edx
   2fb9f:	43 3a 4c 04 02       	cmp    0x2(%r12,%r8,1),%cl
   2fba4:	0f 85 e9 fc ff ff    	jne    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fbaa:	83 f8 03             	cmp    $0x3,%eax
   2fbad:	0f 84 91 fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fbb3:	43 0f b6 4c 05 03    	movzbl 0x3(%r13,%r8,1),%ecx
   2fbb9:	ba 03 00 00 00       	mov    $0x3,%edx
   2fbbe:	43 3a 4c 04 03       	cmp    0x3(%r12,%r8,1),%cl
   2fbc3:	0f 85 ca fc ff ff    	jne    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fbc9:	83 f8 04             	cmp    $0x4,%eax
   2fbcc:	0f 84 72 fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fbd2:	43 0f b6 4c 05 04    	movzbl 0x4(%r13,%r8,1),%ecx
   2fbd8:	ba 04 00 00 00       	mov    $0x4,%edx
   2fbdd:	43 3a 4c 04 04       	cmp    0x4(%r12,%r8,1),%cl
   2fbe2:	0f 85 ab fc ff ff    	jne    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fbe8:	83 f8 05             	cmp    $0x5,%eax
   2fbeb:	0f 84 53 fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fbf1:	43 0f b6 4c 05 05    	movzbl 0x5(%r13,%r8,1),%ecx
   2fbf7:	ba 05 00 00 00       	mov    $0x5,%edx
   2fbfc:	43 3a 4c 04 05       	cmp    0x5(%r12,%r8,1),%cl
   2fc01:	0f 85 8c fc ff ff    	jne    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fc07:	83 f8 06             	cmp    $0x6,%eax
   2fc0a:	0f 84 34 fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fc10:	43 0f b6 44 05 06    	movzbl 0x6(%r13,%r8,1),%eax
   2fc16:	ba 06 00 00 00       	mov    $0x6,%edx
   2fc1b:	43 3a 44 04 06       	cmp    0x6(%r12,%r8,1),%al
   2fc20:	0f 84 1e fc ff ff    	je     2f844 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   2fc26:	e9 68 fc ff ff       	jmp    2f893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   2fc2b:	48 8d 0d 7e 95 02 00 	lea    0x2957e(%rip),%rcx        # 591b0 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x890>
   2fc32:	31 ff                	xor    %edi,%edi
   2fc34:	48 89 d6             	mov    %rdx,%rsi
   2fc37:	4c 89 f2             	mov    %r14,%rdx
   2fc3a:	ff 15 d0 ac 02 00    	call   *0x2acd0(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
   2fc40:	48 8d 0d 51 95 02 00 	lea    0x29551(%rip),%rcx        # 59198 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x878>
   2fc47:	4c 89 ff             	mov    %r15,%rdi
   2fc4a:	4c 89 f6             	mov    %r14,%rsi
   2fc4d:	4c 89 f2             	mov    %r14,%rdx
   2fc50:	ff 15 ba ac 02 00    	call   *0x2acba(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
   2fc56:	48 8d 0d 23 95 02 00 	lea    0x29523(%rip),%rcx        # 59180 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x860>
   2fc5d:	4c 89 ff             	mov    %r15,%rdi
   2fc60:	48 89 de             	mov    %rbx,%rsi
   2fc63:	48 89 da             	mov    %rbx,%rdx
   2fc66:	ff 15 a4 ac 02 00    	call   *0x2aca4(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
