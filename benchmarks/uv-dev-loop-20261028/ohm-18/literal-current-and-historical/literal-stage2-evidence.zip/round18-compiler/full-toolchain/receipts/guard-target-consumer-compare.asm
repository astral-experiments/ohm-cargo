
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/stage2-smoke-guard-20261028T233510/target/debug/stage2_consumer:     file format elf64-x86-64


Disassembly of section .text:

00000000000365d0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
   365d0:	55                   	push   %rbp
   365d1:	48 89 e5             	mov    %rsp,%rbp
   365d4:	41 57                	push   %r15
   365d6:	41 56                	push   %r14
   365d8:	41 55                	push   %r13
   365da:	41 54                	push   %r12
   365dc:	53                   	push   %rbx
   365dd:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   365e4:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
   365e8:	0f 85 25 02 00 00    	jne    36813 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   365ee:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
   365f2:	0f 85 1b 02 00 00    	jne    36813 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   365f8:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
   365fc:	3a 46 38             	cmp    0x38(%rsi),%al
   365ff:	0f 85 0e 02 00 00    	jne    36813 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   36605:	4c 8b 2f             	mov    (%rdi),%r13
   36608:	4c 8b 77 08          	mov    0x8(%rdi),%r14
   3660c:	4c 8b 26             	mov    (%rsi),%r12
   3660f:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   36613:	4c 39 f3             	cmp    %r14,%rbx
   36616:	4d 89 f7             	mov    %r14,%r15
   36619:	4c 0f 42 fb          	cmovb  %rbx,%r15
   3661d:	49 83 ff 07          	cmp    $0x7,%r15
   36621:	0f 87 d7 00 00 00    	ja     366fe <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x12e>
   36627:	4d 85 ff             	test   %r15,%r15
   3662a:	0f 84 8e 01 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   36630:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   36635:	41 3a 04 24          	cmp    (%r12),%al
   36639:	0f 85 52 01 00 00    	jne    36791 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c1>
   3663f:	49 83 ff 01          	cmp    $0x1,%r15
   36643:	0f 84 75 01 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   36649:	41 0f b6 45 01       	movzbl 0x1(%r13),%eax
   3664e:	ba 01 00 00 00       	mov    $0x1,%edx
   36653:	41 3a 44 24 01       	cmp    0x1(%r12),%al
   36658:	0f 85 45 01 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   3665e:	49 83 ff 02          	cmp    $0x2,%r15
   36662:	0f 84 56 01 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   36668:	41 0f b6 45 02       	movzbl 0x2(%r13),%eax
   3666d:	ba 02 00 00 00       	mov    $0x2,%edx
   36672:	41 3a 44 24 02       	cmp    0x2(%r12),%al
   36677:	0f 85 26 01 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   3667d:	49 83 ff 03          	cmp    $0x3,%r15
   36681:	0f 84 37 01 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   36687:	41 0f b6 45 03       	movzbl 0x3(%r13),%eax
   3668c:	ba 03 00 00 00       	mov    $0x3,%edx
   36691:	41 3a 44 24 03       	cmp    0x3(%r12),%al
   36696:	0f 85 07 01 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   3669c:	49 83 ff 04          	cmp    $0x4,%r15
   366a0:	0f 84 18 01 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   366a6:	41 0f b6 45 04       	movzbl 0x4(%r13),%eax
   366ab:	ba 04 00 00 00       	mov    $0x4,%edx
   366b0:	41 3a 44 24 04       	cmp    0x4(%r12),%al
   366b5:	0f 85 e8 00 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   366bb:	49 83 ff 05          	cmp    $0x5,%r15
   366bf:	0f 84 f9 00 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   366c5:	41 0f b6 45 05       	movzbl 0x5(%r13),%eax
   366ca:	ba 05 00 00 00       	mov    $0x5,%edx
   366cf:	41 3a 44 24 05       	cmp    0x5(%r12),%al
   366d4:	0f 85 c9 00 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   366da:	49 83 ff 06          	cmp    $0x6,%r15
   366de:	0f 84 da 00 00 00    	je     367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   366e4:	41 0f b6 45 06       	movzbl 0x6(%r13),%eax
   366e9:	ba 06 00 00 00       	mov    $0x6,%edx
   366ee:	41 3a 44 24 06       	cmp    0x6(%r12),%al
   366f3:	0f 85 aa 00 00 00    	jne    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   366f9:	e9 c0 00 00 00       	jmp    367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   366fe:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   36703:	41 3a 04 24          	cmp    (%r12),%al
   36707:	0f 85 7f 00 00 00    	jne    3678c <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1bc>
   3670d:	4c 89 f9             	mov    %r15,%rcx
   36710:	48 c1 e9 03          	shr    $0x3,%rcx
   36714:	74 24                	je     3673a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x16a>
   36716:	31 c0                	xor    %eax,%eax
   36718:	31 d2                	xor    %edx,%edx
   3671a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   36720:	4d 8b 44 d5 00       	mov    0x0(%r13,%rdx,8),%r8
   36725:	4d 8b 0c d4          	mov    (%r12,%rdx,8),%r9
   36729:	4d 39 c8             	cmp    %r9,%r8
   3672c:	75 67                	jne    36795 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c5>
   3672e:	48 ff c2             	inc    %rdx
   36731:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
   36735:	48 39 d1             	cmp    %rdx,%rcx
   36738:	75 e6                	jne    36720 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x150>
   3673a:	49 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r8
   36741:	ff ff 7f 
   36744:	4d 21 f8             	and    %r15,%r8
   36747:	44 89 f8             	mov    %r15d,%eax
   3674a:	83 e0 07             	and    $0x7,%eax
   3674d:	74 15                	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   3674f:	43 0f b6 4c 05 00    	movzbl 0x0(%r13,%r8,1),%ecx
   36755:	43 3a 0c 04          	cmp    (%r12,%r8,1),%cl
   36759:	75 56                	jne    367b1 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e1>
   3675b:	83 f8 01             	cmp    $0x1,%eax
   3675e:	0f 85 31 03 00 00    	jne    36a95 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4c5>
   36764:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
   36768:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
   3676c:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
   36770:	e8 07 e1 00 00       	call   4487c <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
   36775:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
   36779:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
   3677d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
   36781:	48 83 f8 01          	cmp    $0x1,%rax
   36785:	75 37                	jne    367be <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
   36787:	4c 01 c2             	add    %r8,%rdx
   3678a:	eb 17                	jmp    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   3678c:	45 31 ff             	xor    %r15d,%r15d
   3678f:	eb 39                	jmp    367ca <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   36791:	31 d2                	xor    %edx,%edx
   36793:	eb 0e                	jmp    367a3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
   36795:	4d 31 c1             	xor    %r8,%r9
   36798:	f3 49 0f bc d1       	tzcnt  %r9,%rdx
   3679d:	c1 ea 03             	shr    $0x3,%edx
   367a0:	48 29 c2             	sub    %rax,%rdx
   367a3:	4c 39 f2             	cmp    %r14,%rdx
   367a6:	0f 87 9f 03 00 00    	ja     36b4b <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x57b>
   367ac:	49 89 d7             	mov    %rdx,%r15
   367af:	eb 19                	jmp    367ca <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   367b1:	31 d2                	xor    %edx,%edx
   367b3:	b8 01 00 00 00       	mov    $0x1,%eax
   367b8:	48 83 f8 01          	cmp    $0x1,%rax
   367bc:	74 c9                	je     36787 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1b7>
   367be:	49 39 de             	cmp    %rbx,%r14
   367c1:	75 07                	jne    367ca <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
   367c3:	31 c0                	xor    %eax,%eax
   367c5:	e9 b9 02 00 00       	jmp    36a83 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   367ca:	4d 85 ff             	test   %r15,%r15
   367cd:	74 44                	je     36813 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   367cf:	90                   	nop
   367d0:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
   367d6:	74 07                	je     367df <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x20f>
   367d8:	49 ff cf             	dec    %r15
   367db:	75 f3                	jne    367d0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x200>
   367dd:	eb 34                	jmp    36813 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
   367df:	4c 89 f0             	mov    %r14,%rax
   367e2:	4c 29 f8             	sub    %r15,%rax
   367e5:	0f 82 75 03 00 00    	jb     36b60 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x590>
   367eb:	4d 01 fd             	add    %r15,%r13
   367ee:	4c 89 2f             	mov    %r13,(%rdi)
   367f1:	48 89 47 08          	mov    %rax,0x8(%rdi)
   367f5:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
   367f9:	48 89 d8             	mov    %rbx,%rax
   367fc:	4c 29 f8             	sub    %r15,%rax
   367ff:	0f 82 71 03 00 00    	jb     36b76 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x5a6>
   36805:	4d 01 fc             	add    %r15,%r12
   36808:	4c 89 26             	mov    %r12,(%rsi)
   3680b:	48 89 46 08          	mov    %rax,0x8(%rsi)
   3680f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
   36813:	0f 10 07             	movups (%rdi),%xmm0
   36816:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
   3681a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
   3681e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
   36822:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
   36829:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
   36830:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
   36837:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
   3683e:	48 8b 06             	mov    (%rsi),%rax
   36841:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   36845:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
   36849:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
   3684d:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   36851:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
   36855:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
   36859:	88 55 b8             	mov    %dl,-0x48(%rbp)
   3685c:	8b 56 39             	mov    0x39(%rsi),%edx
   3685f:	89 55 b9             	mov    %edx,-0x47(%rbp)
   36862:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
   36866:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
   3686a:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
   3686e:	88 55 bf             	mov    %dl,-0x41(%rbp)
   36871:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
   36875:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
   36879:	48 89 45 80          	mov    %rax,-0x80(%rbp)
   3687d:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
   36881:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   36888:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   3688f:	ff 15 23 1d 02 00    	call   *0x21d23(%rip)        # 585b8 <_GLOBAL_OFFSET_TABLE_+0x1c8>
   36895:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   3689c:	ff 
   3689d:	41 80 fc ff          	cmp    $0xff,%r12b
   368a1:	0f 84 bb 01 00 00    	je     36a62 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
   368a7:	48 8d 05 52 52 00 00 	lea    0x5252(%rip),%rax        # 3bb00 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   368ae:	eb 2c                	jmp    368dc <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x30c>
   368b0:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   368b7:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   368be:	48 8d 1d 3b 52 00 00 	lea    0x523b(%rip),%rbx        # 3bb00 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   368c5:	ff d3                	call   *%rbx
   368c7:	48 89 d8             	mov    %rbx,%rax
   368ca:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   368d1:	ff 
   368d2:	41 80 fc ff          	cmp    $0xff,%r12b
   368d6:	0f 84 86 01 00 00    	je     36a62 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
   368dc:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
   368e3:	ff 
   368e4:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
   368eb:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
   368f2:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
   368f9:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   368fd:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
   36904:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   3690b:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   3690f:	ff d0                	call   *%rax
   36911:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
   36918:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
   3691f:	0f 84 5c 01 00 00    	je     36a81 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b1>
   36925:	41 0f b6 cc          	movzbl %r12b,%ecx
   36929:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
   3692d:	80 f9 06             	cmp    $0x6,%cl
   36930:	ba 00 00 00 00       	mov    $0x0,%edx
   36935:	4c 0f 42 c2          	cmovb  %rdx,%r8
   36939:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
   3693d:	40 80 ff 06          	cmp    $0x6,%dil
   36941:	48 0f 42 c2          	cmovb  %rdx,%rax
   36945:	49 39 c0             	cmp    %rax,%r8
   36948:	0f 9c c2             	setl   %dl
   3694b:	0f 9f c0             	setg   %al
   3694e:	0f 85 8c 00 00 00    	jne    369e0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x410>
   36954:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
   3695b:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
   36962:	41 83 f8 04          	cmp    $0x4,%r8d
   36966:	74 47                	je     369af <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3df>
   36968:	4d 85 c0             	test   %r8,%r8
   3696b:	0f 85 3f ff ff ff    	jne    368b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   36971:	40 80 ff 05          	cmp    $0x5,%dil
   36975:	0f 87 35 ff ff ff    	ja     368b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   3697b:	48 39 f9             	cmp    %rdi,%rcx
   3697e:	41 0f 9c c0          	setl   %r8b
   36982:	0f 9f c0             	setg   %al
   36985:	41 38 fc             	cmp    %dil,%r12b
   36988:	75 70                	jne    369fa <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x42a>
   3698a:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
   36991:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
   36998:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
   3699f:	48 8d 3d 42 04 fd ff 	lea    -0x2fbbe(%rip),%rdi        # 6de8 <__abi_tag+0x6a2c>
   369a6:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
   369aa:	48 01 f9             	add    %rdi,%rcx
   369ad:	ff e1                	jmp    *%rcx
   369af:	49 89 de             	mov    %rbx,%r14
   369b2:	49 29 d6             	sub    %rdx,%r14
   369b5:	48 0f 42 d3          	cmovb  %rbx,%rdx
   369b9:	4c 89 ff             	mov    %r15,%rdi
   369bc:	ff 15 1e 22 02 00    	call   *0x2221e(%rip)        # 58be0 <memcmp@GLIBC_2.2.5>
   369c2:	48 98                	cltq
   369c4:	85 c0                	test   %eax,%eax
   369c6:	4c 0f 45 f0          	cmovne %rax,%r14
   369ca:	4d 85 f6             	test   %r14,%r14
   369cd:	0f 98 c1             	sets   %cl
   369d0:	0f 9f c0             	setg   %al
   369d3:	28 c8                	sub    %cl,%al
   369d5:	eb 0b                	jmp    369e2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   369d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   369de:	00 00 
   369e0:	28 d0                	sub    %dl,%al
   369e2:	3c fe                	cmp    $0xfe,%al
   369e4:	0f 84 c6 fe ff ff    	je     368b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   369ea:	0f b6 c8             	movzbl %al,%ecx
   369ed:	85 c9                	test   %ecx,%ecx
   369ef:	0f 84 bb fe ff ff    	je     368b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
   369f5:	e9 89 00 00 00       	jmp    36a83 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   369fa:	44 28 c0             	sub    %r8b,%al
   369fd:	eb e3                	jmp    369e2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   369ff:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
   36a03:	4d 89 c5             	mov    %r8,%r13
   36a06:	49 89 dc             	mov    %rbx,%r12
   36a09:	49 29 d4             	sub    %rdx,%r12
   36a0c:	48 0f 42 d3          	cmovb  %rbx,%rdx
   36a10:	4c 89 ff             	mov    %r15,%rdi
   36a13:	4c 8b 3d c6 21 02 00 	mov    0x221c6(%rip),%r15        # 58be0 <memcmp@GLIBC_2.2.5>
   36a1a:	41 ff d7             	call   *%r15
   36a1d:	48 98                	cltq
   36a1f:	85 c0                	test   %eax,%eax
   36a21:	4c 0f 45 e0          	cmovne %rax,%r12
   36a25:	4d 85 e4             	test   %r12,%r12
   36a28:	0f 98 c1             	sets   %cl
   36a2b:	0f 9f c0             	setg   %al
   36a2e:	75 a3                	jne    369d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x403>
   36a30:	4c 89 f3             	mov    %r14,%rbx
   36a33:	4c 89 ea             	mov    %r13,%rdx
   36a36:	4c 29 eb             	sub    %r13,%rbx
   36a39:	49 0f 42 d6          	cmovb  %r14,%rdx
   36a3d:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   36a41:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   36a45:	41 ff d7             	call   *%r15
   36a48:	48 98                	cltq
   36a4a:	85 c0                	test   %eax,%eax
   36a4c:	48 0f 45 d8          	cmovne %rax,%rbx
   36a50:	48 85 db             	test   %rbx,%rbx
   36a53:	e9 75 ff ff ff       	jmp    369cd <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3fd>
   36a58:	41 38 c5             	cmp    %al,%r13b
   36a5b:	0f 97 c0             	seta   %al
   36a5e:	1c 00                	sbb    $0x0,%al
   36a60:	eb 80                	jmp    369e2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
   36a62:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   36a69:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   36a6d:	ff 15 45 1b 02 00    	call   *0x21b45(%rip)        # 585b8 <_GLOBAL_OFFSET_TABLE_+0x1c8>
   36a73:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
   36a7a:	0f 95 c0             	setne  %al
   36a7d:	f6 d8                	neg    %al
   36a7f:	eb 02                	jmp    36a83 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
   36a81:	b0 01                	mov    $0x1,%al
   36a83:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   36a8a:	5b                   	pop    %rbx
   36a8b:	41 5c                	pop    %r12
   36a8d:	41 5d                	pop    %r13
   36a8f:	41 5e                	pop    %r14
   36a91:	41 5f                	pop    %r15
   36a93:	5d                   	pop    %rbp
   36a94:	c3                   	ret
   36a95:	43 0f b6 4c 05 01    	movzbl 0x1(%r13,%r8,1),%ecx
   36a9b:	ba 01 00 00 00       	mov    $0x1,%edx
   36aa0:	43 3a 4c 04 01       	cmp    0x1(%r12,%r8,1),%cl
   36aa5:	0f 85 08 fd ff ff    	jne    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36aab:	83 f8 02             	cmp    $0x2,%eax
   36aae:	0f 84 b0 fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36ab4:	43 0f b6 4c 05 02    	movzbl 0x2(%r13,%r8,1),%ecx
   36aba:	ba 02 00 00 00       	mov    $0x2,%edx
   36abf:	43 3a 4c 04 02       	cmp    0x2(%r12,%r8,1),%cl
   36ac4:	0f 85 e9 fc ff ff    	jne    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36aca:	83 f8 03             	cmp    $0x3,%eax
   36acd:	0f 84 91 fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36ad3:	43 0f b6 4c 05 03    	movzbl 0x3(%r13,%r8,1),%ecx
   36ad9:	ba 03 00 00 00       	mov    $0x3,%edx
   36ade:	43 3a 4c 04 03       	cmp    0x3(%r12,%r8,1),%cl
   36ae3:	0f 85 ca fc ff ff    	jne    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36ae9:	83 f8 04             	cmp    $0x4,%eax
   36aec:	0f 84 72 fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36af2:	43 0f b6 4c 05 04    	movzbl 0x4(%r13,%r8,1),%ecx
   36af8:	ba 04 00 00 00       	mov    $0x4,%edx
   36afd:	43 3a 4c 04 04       	cmp    0x4(%r12,%r8,1),%cl
   36b02:	0f 85 ab fc ff ff    	jne    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36b08:	83 f8 05             	cmp    $0x5,%eax
   36b0b:	0f 84 53 fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36b11:	43 0f b6 4c 05 05    	movzbl 0x5(%r13,%r8,1),%ecx
   36b17:	ba 05 00 00 00       	mov    $0x5,%edx
   36b1c:	43 3a 4c 04 05       	cmp    0x5(%r12,%r8,1),%cl
   36b21:	0f 85 8c fc ff ff    	jne    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36b27:	83 f8 06             	cmp    $0x6,%eax
   36b2a:	0f 84 34 fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36b30:	43 0f b6 44 05 06    	movzbl 0x6(%r13,%r8,1),%eax
   36b36:	ba 06 00 00 00       	mov    $0x6,%edx
   36b3b:	43 3a 44 04 06       	cmp    0x6(%r12,%r8,1),%al
   36b40:	0f 84 1e fc ff ff    	je     36764 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
   36b46:	e9 68 fc ff ff       	jmp    367b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
   36b4b:	48 8d 0d b6 01 02 00 	lea    0x201b6(%rip),%rcx        # 56d08 <__fini_array_end+0xa78>
   36b52:	31 ff                	xor    %edi,%edi
   36b54:	48 89 d6             	mov    %rdx,%rsi
   36b57:	4c 89 f2             	mov    %r14,%rdx
   36b5a:	ff 15 f0 1c 02 00    	call   *0x21cf0(%rip)        # 58850 <_GLOBAL_OFFSET_TABLE_+0x460>
   36b60:	48 8d 0d 89 01 02 00 	lea    0x20189(%rip),%rcx        # 56cf0 <__fini_array_end+0xa60>
   36b67:	4c 89 ff             	mov    %r15,%rdi
   36b6a:	4c 89 f6             	mov    %r14,%rsi
   36b6d:	4c 89 f2             	mov    %r14,%rdx
   36b70:	ff 15 da 1c 02 00    	call   *0x21cda(%rip)        # 58850 <_GLOBAL_OFFSET_TABLE_+0x460>
   36b76:	48 8d 0d 5b 01 02 00 	lea    0x2015b(%rip),%rcx        # 56cd8 <__fini_array_end+0xa48>
   36b7d:	4c 89 ff             	mov    %r15,%rdi
   36b80:	48 89 de             	mov    %rbx,%rsi
   36b83:	48 89 da             	mov    %rbx,%rdx
   36b86:	ff 15 c4 1c 02 00    	call   *0x21cc4(%rip)        # 58850 <_GLOBAL_OFFSET_TABLE_+0x460>
