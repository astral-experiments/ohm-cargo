extern crate host_macro;
/// The macro expands while compiling and documenting the crate.
pub const PAIRS: usize = host_macro::pairs!(96);
fn main() { assert_eq!(PAIRS, 10404); println!("{PAIRS}"); }
