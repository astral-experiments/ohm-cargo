extern crate proc_macro;
use proc_macro::TokenStream;
use std::{cmp::Ordering, ffi::OsStr, os::unix::ffi::OsStrExt, path::Path};
#[inline(never)] fn compare(a: &Path, b: &Path) -> Ordering { a.cmp(b) }
#[proc_macro] pub fn pairs(n: TokenStream) -> TokenStream {
    let width: usize = n.to_string().parse().unwrap();
    let mut cases = vec![b"".to_vec(), b".".to_vec(), b"a//b/./".to_vec(), b"a/b".to_vec(), vec![0xff], vec![0]];
    for i in 0..width { let mut bytes = vec![b'a'; width]; bytes[i] = 0; cases.push(bytes); }
    for a in &cases { for b in &cases {
        let (a, b) = (Path::new(OsStr::from_bytes(a)), Path::new(OsStr::from_bytes(b)));
        assert_eq!(compare(a, b), a.components().collect::<Vec<_>>().cmp(&b.components().collect::<Vec<_>>()));
    } }
    let n = cases.len() * cases.len();
    std::fs::write(std::env::var_os("OHM_STAGE2_PRIVATE_PROOF").unwrap(), n.to_string()).unwrap();
    n.to_string().parse().unwrap()
}
