
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/stage2-smoke-base-20261028T232444/target/debug/stage2_consumer:     file format elf64-x86-64


Disassembly of section .text:

00000000000365d0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
   365d0:	55                   	push   %rbp
   365d1:	48 89 e5             	mov    %rsp,%rbp
   365d4:	41 57                	push   %r15
   365d6:	41 56                	push   %r14
   365d8:	41 55                	push   %r13
   365da:	41 54                	push   %r12
   365dc:	53                   	push   %rbx
   365dd:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   365e4:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
   365e8:	0f 85 e5 00 00 00    	jne    366d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   365ee:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
   365f2:	0f 85 db 00 00 00    	jne    366d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   365f8:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
   365fc:	3a 46 38             	cmp    0x38(%rsi),%al
   365ff:	0f 85 ce 00 00 00    	jne    366d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   36605:	4c 8b 2f             	mov    (%rdi),%r13
   36608:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
   3660c:	4c 8b 26             	mov    (%rsi),%r12
   3660f:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   36613:	49 39 d8             	cmp    %rbx,%r8
   36616:	49 89 df             	mov    %rbx,%r15
   36619:	4d 0f 42 f8          	cmovb  %r8,%r15
   3661d:	4d 85 ff             	test   %r15,%r15
   36620:	74 22                	je     36644 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x74>
   36622:	31 d2                	xor    %edx,%edx
   36624:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   3662b:	00 00 00 00 00 
   36630:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
   36636:	41 3a 04 14          	cmp    (%r12,%rdx,1),%al
   3663a:	75 35                	jne    36671 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xa1>
   3663c:	48 ff c2             	inc    %rdx
   3663f:	49 39 d7             	cmp    %rdx,%r15
   36642:	75 ec                	jne    36630 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x60>
   36644:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
   36648:	49 89 fe             	mov    %rdi,%r14
   3664b:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   3664f:	e8 38 e0 00 00       	call   4468c <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
   36654:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   36658:	4c 89 f7             	mov    %r14,%rdi
   3665b:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   3665f:	a8 01                	test   $0x1,%al
   36661:	74 17                	je     3667a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xaa>
   36663:	48 39 da             	cmp    %rbx,%rdx
   36666:	0f 87 e9 02 00 00    	ja     36955 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x385>
   3666c:	49 89 d7             	mov    %rdx,%r15
   3666f:	eb 15                	jmp    36686 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
   36671:	b8 01 00 00 00       	mov    $0x1,%eax
   36676:	a8 01                	test   $0x1,%al
   36678:	75 e9                	jne    36663 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x93>
   3667a:	4c 39 c3             	cmp    %r8,%rbx
   3667d:	75 07                	jne    36686 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
   3667f:	31 c0                	xor    %eax,%eax
   36681:	e9 bd 02 00 00       	jmp    36943 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   36686:	4d 85 ff             	test   %r15,%r15
   36689:	74 48                	je     366d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   3668b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   36690:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
   36696:	74 07                	je     3669f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xcf>
   36698:	49 ff cf             	dec    %r15
   3669b:	75 f3                	jne    36690 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xc0>
   3669d:	eb 34                	jmp    366d3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   3669f:	48 89 d8             	mov    %rbx,%rax
   366a2:	4c 29 f8             	sub    %r15,%rax
   366a5:	0f 82 bf 02 00 00    	jb     3696a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x39a>
   366ab:	4d 01 fd             	add    %r15,%r13
   366ae:	4c 89 2f             	mov    %r13,(%rdi)
   366b1:	48 89 47 08          	mov    %rax,0x8(%rdi)
   366b5:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
   366b9:	4c 89 c0             	mov    %r8,%rax
   366bc:	4c 29 f8             	sub    %r15,%rax
   366bf:	0f 82 bb 02 00 00    	jb     36980 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3b0>
   366c5:	4d 01 fc             	add    %r15,%r12
   366c8:	4c 89 26             	mov    %r12,(%rsi)
   366cb:	48 89 46 08          	mov    %rax,0x8(%rsi)
   366cf:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
   366d3:	0f 10 07             	movups (%rdi),%xmm0
   366d6:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
   366da:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
   366de:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
   366e2:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
   366e9:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
   366f0:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
   366f7:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
   366fe:	48 8b 06             	mov    (%rsi),%rax
   36701:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   36705:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
   36709:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
   3670d:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   36711:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
   36715:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
   36719:	88 55 b8             	mov    %dl,-0x48(%rbp)
   3671c:	8b 56 39             	mov    0x39(%rsi),%edx
   3671f:	89 55 b9             	mov    %edx,-0x47(%rbp)
   36722:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
   36726:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
   3672a:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
   3672e:	88 55 bf             	mov    %dl,-0x41(%rbp)
   36731:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
   36735:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
   36739:	48 89 45 80          	mov    %rax,-0x80(%rbp)
   3673d:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
   36741:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   36748:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   3674f:	ff 15 73 1c 02 00    	call   *0x21c73(%rip)        # 583c8 <_GLOBAL_OFFSET_TABLE_+0x1c8>
   36755:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   3675c:	ff 
   3675d:	41 80 fc ff          	cmp    $0xff,%r12b
   36761:	0f 84 bb 01 00 00    	je     36922 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
   36767:	48 8d 05 a2 51 00 00 	lea    0x51a2(%rip),%rax        # 3b910 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   3676e:	eb 2c                	jmp    3679c <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1cc>
   36770:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   36777:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   3677e:	48 8d 1d 8b 51 00 00 	lea    0x518b(%rip),%rbx        # 3b910 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   36785:	ff d3                	call   *%rbx
   36787:	48 89 d8             	mov    %rbx,%rax
   3678a:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   36791:	ff 
   36792:	41 80 fc ff          	cmp    $0xff,%r12b
   36796:	0f 84 86 01 00 00    	je     36922 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
   3679c:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
   367a3:	ff 
   367a4:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
   367ab:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
   367b2:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
   367b9:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   367bd:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
   367c4:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   367cb:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   367cf:	ff d0                	call   *%rax
   367d1:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
   367d8:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
   367df:	0f 84 5c 01 00 00    	je     36941 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x371>
   367e5:	41 0f b6 cc          	movzbl %r12b,%ecx
   367e9:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
   367ed:	80 f9 06             	cmp    $0x6,%cl
   367f0:	ba 00 00 00 00       	mov    $0x0,%edx
   367f5:	4c 0f 42 c2          	cmovb  %rdx,%r8
   367f9:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
   367fd:	40 80 ff 06          	cmp    $0x6,%dil
   36801:	48 0f 42 c2          	cmovb  %rdx,%rax
   36805:	49 39 c0             	cmp    %rax,%r8
   36808:	0f 9c c2             	setl   %dl
   3680b:	0f 9f c0             	setg   %al
   3680e:	0f 85 8c 00 00 00    	jne    368a0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d0>
   36814:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
   3681b:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
   36822:	41 83 f8 04          	cmp    $0x4,%r8d
   36826:	74 47                	je     3686f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x29f>
   36828:	4d 85 c0             	test   %r8,%r8
   3682b:	0f 85 3f ff ff ff    	jne    36770 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   36831:	40 80 ff 05          	cmp    $0x5,%dil
   36835:	0f 87 35 ff ff ff    	ja     36770 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   3683b:	48 39 f9             	cmp    %rdi,%rcx
   3683e:	41 0f 9c c0          	setl   %r8b
   36842:	0f 9f c0             	setg   %al
   36845:	41 38 fc             	cmp    %dil,%r12b
   36848:	75 70                	jne    368ba <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2ea>
   3684a:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
   36851:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
   36858:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
   3685f:	48 8d 3d 82 05 fd ff 	lea    -0x2fa7e(%rip),%rdi        # 6de8 <__abi_tag+0x6a2c>
   36866:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
   3686a:	48 01 f9             	add    %rdi,%rcx
   3686d:	ff e1                	jmp    *%rcx
   3686f:	49 89 de             	mov    %rbx,%r14
   36872:	49 29 d6             	sub    %rdx,%r14
   36875:	48 0f 42 d3          	cmovb  %rbx,%rdx
   36879:	4c 89 ff             	mov    %r15,%rdi
   3687c:	ff 15 6e 21 02 00    	call   *0x2216e(%rip)        # 589f0 <memcmp@GLIBC_2.2.5>
   36882:	48 98                	cltq
   36884:	85 c0                	test   %eax,%eax
   36886:	4c 0f 45 f0          	cmovne %rax,%r14
   3688a:	4d 85 f6             	test   %r14,%r14
   3688d:	0f 98 c1             	sets   %cl
   36890:	0f 9f c0             	setg   %al
   36893:	28 c8                	sub    %cl,%al
   36895:	eb 0b                	jmp    368a2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   36897:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3689e:	00 00 
   368a0:	28 d0                	sub    %dl,%al
   368a2:	3c fe                	cmp    $0xfe,%al
   368a4:	0f 84 c6 fe ff ff    	je     36770 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   368aa:	0f b6 c8             	movzbl %al,%ecx
   368ad:	85 c9                	test   %ecx,%ecx
   368af:	0f 84 bb fe ff ff    	je     36770 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   368b5:	e9 89 00 00 00       	jmp    36943 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   368ba:	44 28 c0             	sub    %r8b,%al
   368bd:	eb e3                	jmp    368a2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   368bf:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
   368c3:	4d 89 c5             	mov    %r8,%r13
   368c6:	49 89 dc             	mov    %rbx,%r12
   368c9:	49 29 d4             	sub    %rdx,%r12
   368cc:	48 0f 42 d3          	cmovb  %rbx,%rdx
   368d0:	4c 89 ff             	mov    %r15,%rdi
   368d3:	4c 8b 3d 16 21 02 00 	mov    0x22116(%rip),%r15        # 589f0 <memcmp@GLIBC_2.2.5>
   368da:	41 ff d7             	call   *%r15
   368dd:	48 98                	cltq
   368df:	85 c0                	test   %eax,%eax
   368e1:	4c 0f 45 e0          	cmovne %rax,%r12
   368e5:	4d 85 e4             	test   %r12,%r12
   368e8:	0f 98 c1             	sets   %cl
   368eb:	0f 9f c0             	setg   %al
   368ee:	75 a3                	jne    36893 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2c3>
   368f0:	4c 89 f3             	mov    %r14,%rbx
   368f3:	4c 89 ea             	mov    %r13,%rdx
   368f6:	4c 29 eb             	sub    %r13,%rbx
   368f9:	49 0f 42 d6          	cmovb  %r14,%rdx
   368fd:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   36901:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   36905:	41 ff d7             	call   *%r15
   36908:	48 98                	cltq
   3690a:	85 c0                	test   %eax,%eax
   3690c:	48 0f 45 d8          	cmovne %rax,%rbx
   36910:	48 85 db             	test   %rbx,%rbx
   36913:	e9 75 ff ff ff       	jmp    3688d <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2bd>
   36918:	41 38 c5             	cmp    %al,%r13b
   3691b:	0f 97 c0             	seta   %al
   3691e:	1c 00                	sbb    $0x0,%al
   36920:	eb 80                	jmp    368a2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   36922:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   36929:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   3692d:	ff 15 95 1a 02 00    	call   *0x21a95(%rip)        # 583c8 <_GLOBAL_OFFSET_TABLE_+0x1c8>
   36933:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
   3693a:	0f 95 c0             	setne  %al
   3693d:	f6 d8                	neg    %al
   3693f:	eb 02                	jmp    36943 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   36941:	b0 01                	mov    $0x1,%al
   36943:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   3694a:	5b                   	pop    %rbx
   3694b:	41 5c                	pop    %r12
   3694d:	41 5d                	pop    %r13
   3694f:	41 5e                	pop    %r14
   36951:	41 5f                	pop    %r15
   36953:	5d                   	pop    %rbp
   36954:	c3                   	ret
   36955:	48 8d 0d bc 01 02 00 	lea    0x201bc(%rip),%rcx        # 56b18 <__fini_array_end+0xa78>
   3695c:	31 ff                	xor    %edi,%edi
   3695e:	48 89 d6             	mov    %rdx,%rsi
   36961:	48 89 da             	mov    %rbx,%rdx
   36964:	ff 15 f6 1c 02 00    	call   *0x21cf6(%rip)        # 58660 <_GLOBAL_OFFSET_TABLE_+0x460>
   3696a:	48 8d 0d 8f 01 02 00 	lea    0x2018f(%rip),%rcx        # 56b00 <__fini_array_end+0xa60>
   36971:	4c 89 ff             	mov    %r15,%rdi
   36974:	48 89 de             	mov    %rbx,%rsi
   36977:	48 89 da             	mov    %rbx,%rdx
   3697a:	ff 15 e0 1c 02 00    	call   *0x21ce0(%rip)        # 58660 <_GLOBAL_OFFSET_TABLE_+0x460>
   36980:	48 8d 0d 61 01 02 00 	lea    0x20161(%rip),%rcx        # 56ae8 <__fini_array_end+0xa48>
   36987:	4c 89 ff             	mov    %r15,%rdi
   3698a:	4c 89 c6             	mov    %r8,%rsi
   3698d:	4c 89 c2             	mov    %r8,%rdx
   36990:	ff 15 ca 1c 02 00    	call   *0x21cca(%rip)        # 58660 <_GLOBAL_OFFSET_TABLE_+0x460>
