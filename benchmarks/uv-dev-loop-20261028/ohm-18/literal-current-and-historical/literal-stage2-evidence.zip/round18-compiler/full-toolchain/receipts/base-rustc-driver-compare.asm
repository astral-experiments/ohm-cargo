
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/arms/base.pending-20261028T232444/lib/librustc_driver-86064a118cfef3be.so:     file format elf64-x86-64


Disassembly of section .text:

000000000491eb30 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
 491eb30:	55                   	push   %rbp
 491eb31:	48 89 e5             	mov    %rsp,%rbp
 491eb34:	41 57                	push   %r15
 491eb36:	41 56                	push   %r14
 491eb38:	41 55                	push   %r13
 491eb3a:	41 54                	push   %r12
 491eb3c:	53                   	push   %rbx
 491eb3d:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
 491eb44:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
 491eb48:	0f 85 e5 00 00 00    	jne    491ec33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
 491eb4e:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
 491eb52:	0f 85 db 00 00 00    	jne    491ec33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
 491eb58:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
 491eb5c:	3a 46 38             	cmp    0x38(%rsi),%al
 491eb5f:	0f 85 ce 00 00 00    	jne    491ec33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
 491eb65:	4c 8b 2f             	mov    (%rdi),%r13
 491eb68:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
 491eb6c:	4c 8b 26             	mov    (%rsi),%r12
 491eb6f:	4c 8b 46 08          	mov    0x8(%rsi),%r8
 491eb73:	49 39 d8             	cmp    %rbx,%r8
 491eb76:	49 89 df             	mov    %rbx,%r15
 491eb79:	4d 0f 42 f8          	cmovb  %r8,%r15
 491eb7d:	4d 85 ff             	test   %r15,%r15
 491eb80:	74 22                	je     491eba4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x74>
 491eb82:	31 d2                	xor    %edx,%edx
 491eb84:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 491eb8b:	00 00 00 00 00 
 491eb90:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
 491eb96:	41 3a 04 14          	cmp    (%r12,%rdx,1),%al
 491eb9a:	75 35                	jne    491ebd1 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xa1>
 491eb9c:	48 ff c2             	inc    %rdx
 491eb9f:	49 39 d7             	cmp    %rdx,%r15
 491eba2:	75 ec                	jne    491eb90 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x60>
 491eba4:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 491eba8:	49 89 fe             	mov    %rdi,%r14
 491ebab:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 491ebaf:	e8 24 f6 00 00       	call   492e1d8 <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
 491ebb4:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
 491ebb8:	4c 89 f7             	mov    %r14,%rdi
 491ebbb:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 491ebbf:	a8 01                	test   $0x1,%al
 491ebc1:	74 17                	je     491ebda <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xaa>
 491ebc3:	48 39 da             	cmp    %rbx,%rdx
 491ebc6:	0f 87 e9 02 00 00    	ja     491eeb5 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x385>
 491ebcc:	49 89 d7             	mov    %rdx,%r15
 491ebcf:	eb 15                	jmp    491ebe6 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
 491ebd1:	b8 01 00 00 00       	mov    $0x1,%eax
 491ebd6:	a8 01                	test   $0x1,%al
 491ebd8:	75 e9                	jne    491ebc3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x93>
 491ebda:	4c 39 c3             	cmp    %r8,%rbx
 491ebdd:	75 07                	jne    491ebe6 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
 491ebdf:	31 c0                	xor    %eax,%eax
 491ebe1:	e9 bd 02 00 00       	jmp    491eea3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
 491ebe6:	4d 85 ff             	test   %r15,%r15
 491ebe9:	74 48                	je     491ec33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
 491ebeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 491ebf0:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
 491ebf6:	74 07                	je     491ebff <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xcf>
 491ebf8:	49 ff cf             	dec    %r15
 491ebfb:	75 f3                	jne    491ebf0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xc0>
 491ebfd:	eb 34                	jmp    491ec33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
 491ebff:	48 89 d8             	mov    %rbx,%rax
 491ec02:	4c 29 f8             	sub    %r15,%rax
 491ec05:	0f 82 bf 02 00 00    	jb     491eeca <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x39a>
 491ec0b:	4d 01 fd             	add    %r15,%r13
 491ec0e:	4c 89 2f             	mov    %r13,(%rdi)
 491ec11:	48 89 47 08          	mov    %rax,0x8(%rdi)
 491ec15:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
 491ec19:	4c 89 c0             	mov    %r8,%rax
 491ec1c:	4c 29 f8             	sub    %r15,%rax
 491ec1f:	0f 82 bb 02 00 00    	jb     491eee0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3b0>
 491ec25:	4d 01 fc             	add    %r15,%r12
 491ec28:	4c 89 26             	mov    %r12,(%rsi)
 491ec2b:	48 89 46 08          	mov    %rax,0x8(%rsi)
 491ec2f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
 491ec33:	0f 10 07             	movups (%rdi),%xmm0
 491ec36:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
 491ec3a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
 491ec3e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
 491ec42:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
 491ec49:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
 491ec50:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
 491ec57:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
 491ec5e:	48 8b 06             	mov    (%rsi),%rax
 491ec61:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 491ec65:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
 491ec69:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
 491ec6d:	48 8b 56 30          	mov    0x30(%rsi),%rdx
 491ec71:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 491ec75:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
 491ec79:	88 55 b8             	mov    %dl,-0x48(%rbp)
 491ec7c:	8b 56 39             	mov    0x39(%rsi),%edx
 491ec7f:	89 55 b9             	mov    %edx,-0x47(%rbp)
 491ec82:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
 491ec86:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
 491ec8a:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
 491ec8e:	88 55 bf             	mov    %dl,-0x41(%rbp)
 491ec91:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
 491ec95:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
 491ec99:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 491ec9d:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
 491eca1:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
 491eca8:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
 491ecaf:	ff 15 9b c0 2d 00    	call   *0x2dc09b(%rip)        # 4bfad50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75b0>
 491ecb5:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
 491ecbc:	ff 
 491ecbd:	41 80 fc ff          	cmp    $0xff,%r12b
 491ecc1:	0f 84 bb 01 00 00    	je     491ee82 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
 491ecc7:	48 8b 05 82 c0 2d 00 	mov    0x2dc082(%rip),%rax        # 4bfad50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75b0>
 491ecce:	eb 2c                	jmp    491ecfc <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1cc>
 491ecd0:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
 491ecd7:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
 491ecde:	48 8b 1d 6b c0 2d 00 	mov    0x2dc06b(%rip),%rbx        # 4bfad50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75b0>
 491ece5:	ff d3                	call   *%rbx
 491ece7:	48 89 d8             	mov    %rbx,%rax
 491ecea:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
 491ecf1:	ff 
 491ecf2:	41 80 fc ff          	cmp    $0xff,%r12b
 491ecf6:	0f 84 86 01 00 00    	je     491ee82 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
 491ecfc:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
 491ed03:	ff 
 491ed04:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 491ed0b:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
 491ed12:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
 491ed19:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 491ed1d:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
 491ed24:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
 491ed2b:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
 491ed2f:	ff d0                	call   *%rax
 491ed31:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
 491ed38:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
 491ed3f:	0f 84 5c 01 00 00    	je     491eea1 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x371>
 491ed45:	41 0f b6 cc          	movzbl %r12b,%ecx
 491ed49:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
 491ed4d:	80 f9 06             	cmp    $0x6,%cl
 491ed50:	ba 00 00 00 00       	mov    $0x0,%edx
 491ed55:	4c 0f 42 c2          	cmovb  %rdx,%r8
 491ed59:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
 491ed5d:	40 80 ff 06          	cmp    $0x6,%dil
 491ed61:	48 0f 42 c2          	cmovb  %rdx,%rax
 491ed65:	49 39 c0             	cmp    %rax,%r8
 491ed68:	0f 9c c2             	setl   %dl
 491ed6b:	0f 9f c0             	setg   %al
 491ed6e:	0f 85 8c 00 00 00    	jne    491ee00 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d0>
 491ed74:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
 491ed7b:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 491ed82:	41 83 f8 04          	cmp    $0x4,%r8d
 491ed86:	74 47                	je     491edcf <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x29f>
 491ed88:	4d 85 c0             	test   %r8,%r8
 491ed8b:	0f 85 3f ff ff ff    	jne    491ecd0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
 491ed91:	40 80 ff 05          	cmp    $0x5,%dil
 491ed95:	0f 87 35 ff ff ff    	ja     491ecd0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
 491ed9b:	48 39 f9             	cmp    %rdi,%rcx
 491ed9e:	41 0f 9c c0          	setl   %r8b
 491eda2:	0f 9f c0             	setg   %al
 491eda5:	41 38 fc             	cmp    %dil,%r12b
 491eda8:	75 70                	jne    491ee1a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2ea>
 491edaa:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
 491edb1:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 491edb8:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
 491edbf:	48 8d 3d 8a 41 08 fc 	lea    -0x3f7be76(%rip),%rdi        # 9a2f50 <_RNvNtCsk1QeC065jZ4_12sharded_slab3tid8REGISTRY+0x186d>
 491edc6:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
 491edca:	48 01 f9             	add    %rdi,%rcx
 491edcd:	ff e1                	jmp    *%rcx
 491edcf:	49 89 de             	mov    %rbx,%r14
 491edd2:	49 29 d6             	sub    %rdx,%r14
 491edd5:	48 0f 42 d3          	cmovb  %rbx,%rdx
 491edd9:	4c 89 ff             	mov    %r15,%rdi
 491eddc:	ff 15 e6 62 2d 00    	call   *0x2d62e6(%rip)        # 4bf50c8 <memcmp@GLIBC_2.2.5>
 491ede2:	48 98                	cltq
 491ede4:	85 c0                	test   %eax,%eax
 491ede6:	4c 0f 45 f0          	cmovne %rax,%r14
 491edea:	4d 85 f6             	test   %r14,%r14
 491eded:	0f 98 c1             	sets   %cl
 491edf0:	0f 9f c0             	setg   %al
 491edf3:	28 c8                	sub    %cl,%al
 491edf5:	eb 0b                	jmp    491ee02 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
 491edf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 491edfe:	00 00 
 491ee00:	28 d0                	sub    %dl,%al
 491ee02:	3c fe                	cmp    $0xfe,%al
 491ee04:	0f 84 c6 fe ff ff    	je     491ecd0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
 491ee0a:	0f b6 c8             	movzbl %al,%ecx
 491ee0d:	85 c9                	test   %ecx,%ecx
 491ee0f:	0f 84 bb fe ff ff    	je     491ecd0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
 491ee15:	e9 89 00 00 00       	jmp    491eea3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
 491ee1a:	44 28 c0             	sub    %r8b,%al
 491ee1d:	eb e3                	jmp    491ee02 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
 491ee1f:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 491ee23:	4d 89 c5             	mov    %r8,%r13
 491ee26:	49 89 dc             	mov    %rbx,%r12
 491ee29:	49 29 d4             	sub    %rdx,%r12
 491ee2c:	48 0f 42 d3          	cmovb  %rbx,%rdx
 491ee30:	4c 89 ff             	mov    %r15,%rdi
 491ee33:	4c 8b 3d 8e 62 2d 00 	mov    0x2d628e(%rip),%r15        # 4bf50c8 <memcmp@GLIBC_2.2.5>
 491ee3a:	41 ff d7             	call   *%r15
 491ee3d:	48 98                	cltq
 491ee3f:	85 c0                	test   %eax,%eax
 491ee41:	4c 0f 45 e0          	cmovne %rax,%r12
 491ee45:	4d 85 e4             	test   %r12,%r12
 491ee48:	0f 98 c1             	sets   %cl
 491ee4b:	0f 9f c0             	setg   %al
 491ee4e:	75 a3                	jne    491edf3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2c3>
 491ee50:	4c 89 f3             	mov    %r14,%rbx
 491ee53:	4c 89 ea             	mov    %r13,%rdx
 491ee56:	4c 29 eb             	sub    %r13,%rbx
 491ee59:	49 0f 42 d6          	cmovb  %r14,%rdx
 491ee5d:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 491ee61:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 491ee65:	41 ff d7             	call   *%r15
 491ee68:	48 98                	cltq
 491ee6a:	85 c0                	test   %eax,%eax
 491ee6c:	48 0f 45 d8          	cmovne %rax,%rbx
 491ee70:	48 85 db             	test   %rbx,%rbx
 491ee73:	e9 75 ff ff ff       	jmp    491eded <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2bd>
 491ee78:	41 38 c5             	cmp    %al,%r13b
 491ee7b:	0f 97 c0             	seta   %al
 491ee7e:	1c 00                	sbb    $0x0,%al
 491ee80:	eb 80                	jmp    491ee02 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
 491ee82:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
 491ee89:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
 491ee8d:	ff 15 bd be 2d 00    	call   *0x2dbebd(%rip)        # 4bfad50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75b0>
 491ee93:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
 491ee9a:	0f 95 c0             	setne  %al
 491ee9d:	f6 d8                	neg    %al
 491ee9f:	eb 02                	jmp    491eea3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
 491eea1:	b0 01                	mov    $0x1,%al
 491eea3:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
 491eeaa:	5b                   	pop    %rbx
 491eeab:	41 5c                	pop    %r12
 491eead:	41 5d                	pop    %r13
 491eeaf:	41 5e                	pop    %r14
 491eeb1:	41 5f                	pop    %r15
 491eeb3:	5d                   	pop    %rbp
 491eeb4:	c3                   	ret
 491eeb5:	48 8d 0d 2c 9b 2a 00 	lea    0x2a9b2c(%rip),%rcx        # 4bc89e8 <anon.6429032ee2eb37635272542406ebb090.345.llvm.6828008530337351080+0x90>
 491eebc:	31 ff                	xor    %edi,%edi
 491eebe:	48 89 d6             	mov    %rdx,%rsi
 491eec1:	48 89 da             	mov    %rbx,%rdx
 491eec4:	ff 15 26 60 2d 00    	call   *0x2d6026(%rip)        # 4bf4ef0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41300>
 491eeca:	48 8d 0d ff 9a 2a 00 	lea    0x2a9aff(%rip),%rcx        # 4bc89d0 <anon.6429032ee2eb37635272542406ebb090.345.llvm.6828008530337351080+0x78>
 491eed1:	4c 89 ff             	mov    %r15,%rdi
 491eed4:	48 89 de             	mov    %rbx,%rsi
 491eed7:	48 89 da             	mov    %rbx,%rdx
 491eeda:	ff 15 10 60 2d 00    	call   *0x2d6010(%rip)        # 4bf4ef0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41300>
 491eee0:	48 8d 0d d1 9a 2a 00 	lea    0x2a9ad1(%rip),%rcx        # 4bc89b8 <anon.6429032ee2eb37635272542406ebb090.345.llvm.6828008530337351080+0x60>
 491eee7:	4c 89 ff             	mov    %r15,%rdi
 491eeea:	4c 89 c6             	mov    %r8,%rsi
 491eeed:	4c 89 c2             	mov    %r8,%rdx
 491eef0:	ff 15 fa 5f 2d 00    	call   *0x2d5ffa(%rip)        # 4bf4ef0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41300>
