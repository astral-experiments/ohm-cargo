
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/arms/guard.pending-20261028T233510/lib/librustc_driver-86064a118cfef3be.so:     file format elf64-x86-64


Disassembly of section .text:

000000000491eb30 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
 491eb30:	55                   	push   %rbp
 491eb31:	48 89 e5             	mov    %rsp,%rbp
 491eb34:	41 57                	push   %r15
 491eb36:	41 56                	push   %r14
 491eb38:	41 55                	push   %r13
 491eb3a:	41 54                	push   %r12
 491eb3c:	53                   	push   %rbx
 491eb3d:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
 491eb44:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
 491eb48:	0f 85 25 02 00 00    	jne    491ed73 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
 491eb4e:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
 491eb52:	0f 85 1b 02 00 00    	jne    491ed73 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
 491eb58:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
 491eb5c:	3a 46 38             	cmp    0x38(%rsi),%al
 491eb5f:	0f 85 0e 02 00 00    	jne    491ed73 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
 491eb65:	4c 8b 2f             	mov    (%rdi),%r13
 491eb68:	4c 8b 77 08          	mov    0x8(%rdi),%r14
 491eb6c:	4c 8b 26             	mov    (%rsi),%r12
 491eb6f:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
 491eb73:	4c 39 f3             	cmp    %r14,%rbx
 491eb76:	4d 89 f7             	mov    %r14,%r15
 491eb79:	4c 0f 42 fb          	cmovb  %rbx,%r15
 491eb7d:	49 83 ff 07          	cmp    $0x7,%r15
 491eb81:	0f 87 d7 00 00 00    	ja     491ec5e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x12e>
 491eb87:	4d 85 ff             	test   %r15,%r15
 491eb8a:	0f 84 8e 01 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491eb90:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
 491eb95:	41 3a 04 24          	cmp    (%r12),%al
 491eb99:	0f 85 52 01 00 00    	jne    491ecf1 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c1>
 491eb9f:	49 83 ff 01          	cmp    $0x1,%r15
 491eba3:	0f 84 75 01 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491eba9:	41 0f b6 45 01       	movzbl 0x1(%r13),%eax
 491ebae:	ba 01 00 00 00       	mov    $0x1,%edx
 491ebb3:	41 3a 44 24 01       	cmp    0x1(%r12),%al
 491ebb8:	0f 85 45 01 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ebbe:	49 83 ff 02          	cmp    $0x2,%r15
 491ebc2:	0f 84 56 01 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ebc8:	41 0f b6 45 02       	movzbl 0x2(%r13),%eax
 491ebcd:	ba 02 00 00 00       	mov    $0x2,%edx
 491ebd2:	41 3a 44 24 02       	cmp    0x2(%r12),%al
 491ebd7:	0f 85 26 01 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ebdd:	49 83 ff 03          	cmp    $0x3,%r15
 491ebe1:	0f 84 37 01 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ebe7:	41 0f b6 45 03       	movzbl 0x3(%r13),%eax
 491ebec:	ba 03 00 00 00       	mov    $0x3,%edx
 491ebf1:	41 3a 44 24 03       	cmp    0x3(%r12),%al
 491ebf6:	0f 85 07 01 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ebfc:	49 83 ff 04          	cmp    $0x4,%r15
 491ec00:	0f 84 18 01 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ec06:	41 0f b6 45 04       	movzbl 0x4(%r13),%eax
 491ec0b:	ba 04 00 00 00       	mov    $0x4,%edx
 491ec10:	41 3a 44 24 04       	cmp    0x4(%r12),%al
 491ec15:	0f 85 e8 00 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ec1b:	49 83 ff 05          	cmp    $0x5,%r15
 491ec1f:	0f 84 f9 00 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ec25:	41 0f b6 45 05       	movzbl 0x5(%r13),%eax
 491ec2a:	ba 05 00 00 00       	mov    $0x5,%edx
 491ec2f:	41 3a 44 24 05       	cmp    0x5(%r12),%al
 491ec34:	0f 85 c9 00 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ec3a:	49 83 ff 06          	cmp    $0x6,%r15
 491ec3e:	0f 84 da 00 00 00    	je     491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ec44:	41 0f b6 45 06       	movzbl 0x6(%r13),%eax
 491ec49:	ba 06 00 00 00       	mov    $0x6,%edx
 491ec4e:	41 3a 44 24 06       	cmp    0x6(%r12),%al
 491ec53:	0f 85 aa 00 00 00    	jne    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ec59:	e9 c0 00 00 00       	jmp    491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ec5e:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
 491ec63:	41 3a 04 24          	cmp    (%r12),%al
 491ec67:	0f 85 7f 00 00 00    	jne    491ecec <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1bc>
 491ec6d:	4c 89 f9             	mov    %r15,%rcx
 491ec70:	48 c1 e9 03          	shr    $0x3,%rcx
 491ec74:	74 24                	je     491ec9a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x16a>
 491ec76:	31 c0                	xor    %eax,%eax
 491ec78:	31 d2                	xor    %edx,%edx
 491ec7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 491ec80:	4d 8b 44 d5 00       	mov    0x0(%r13,%rdx,8),%r8
 491ec85:	4d 8b 0c d4          	mov    (%r12,%rdx,8),%r9
 491ec89:	4d 39 c8             	cmp    %r9,%r8
 491ec8c:	75 67                	jne    491ecf5 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1c5>
 491ec8e:	48 ff c2             	inc    %rdx
 491ec91:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
 491ec95:	48 39 d1             	cmp    %rdx,%rcx
 491ec98:	75 e6                	jne    491ec80 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x150>
 491ec9a:	49 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%r8
 491eca1:	ff ff 7f 
 491eca4:	4d 21 f8             	and    %r15,%r8
 491eca7:	44 89 f8             	mov    %r15d,%eax
 491ecaa:	83 e0 07             	and    $0x7,%eax
 491ecad:	74 15                	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491ecaf:	43 0f b6 4c 05 00    	movzbl 0x0(%r13,%r8,1),%ecx
 491ecb5:	43 3a 0c 04          	cmp    (%r12,%r8,1),%cl
 491ecb9:	75 56                	jne    491ed11 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e1>
 491ecbb:	83 f8 01             	cmp    $0x1,%eax
 491ecbe:	0f 85 31 03 00 00    	jne    491eff5 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4c5>
 491ecc4:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 491ecc8:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
 491eccc:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 491ecd0:	e8 f3 f6 00 00       	call   492e3c8 <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
 491ecd5:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 491ecd9:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 491ecdd:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 491ece1:	48 83 f8 01          	cmp    $0x1,%rax
 491ece5:	75 37                	jne    491ed1e <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1ee>
 491ece7:	4c 01 c2             	add    %r8,%rdx
 491ecea:	eb 17                	jmp    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ecec:	45 31 ff             	xor    %r15d,%r15d
 491ecef:	eb 39                	jmp    491ed2a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
 491ecf1:	31 d2                	xor    %edx,%edx
 491ecf3:	eb 0e                	jmp    491ed03 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1d3>
 491ecf5:	4d 31 c1             	xor    %r8,%r9
 491ecf8:	f3 49 0f bc d1       	tzcnt  %r9,%rdx
 491ecfd:	c1 ea 03             	shr    $0x3,%edx
 491ed00:	48 29 c2             	sub    %rax,%rdx
 491ed03:	4c 39 f2             	cmp    %r14,%rdx
 491ed06:	0f 87 9f 03 00 00    	ja     491f0ab <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x57b>
 491ed0c:	49 89 d7             	mov    %rdx,%r15
 491ed0f:	eb 19                	jmp    491ed2a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
 491ed11:	31 d2                	xor    %edx,%edx
 491ed13:	b8 01 00 00 00       	mov    $0x1,%eax
 491ed18:	48 83 f8 01          	cmp    $0x1,%rax
 491ed1c:	74 c9                	je     491ece7 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1b7>
 491ed1e:	49 39 de             	cmp    %rbx,%r14
 491ed21:	75 07                	jne    491ed2a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1fa>
 491ed23:	31 c0                	xor    %eax,%eax
 491ed25:	e9 b9 02 00 00       	jmp    491efe3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
 491ed2a:	4d 85 ff             	test   %r15,%r15
 491ed2d:	74 44                	je     491ed73 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
 491ed2f:	90                   	nop
 491ed30:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
 491ed36:	74 07                	je     491ed3f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x20f>
 491ed38:	49 ff cf             	dec    %r15
 491ed3b:	75 f3                	jne    491ed30 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x200>
 491ed3d:	eb 34                	jmp    491ed73 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x243>
 491ed3f:	4c 89 f0             	mov    %r14,%rax
 491ed42:	4c 29 f8             	sub    %r15,%rax
 491ed45:	0f 82 75 03 00 00    	jb     491f0c0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x590>
 491ed4b:	4d 01 fd             	add    %r15,%r13
 491ed4e:	4c 89 2f             	mov    %r13,(%rdi)
 491ed51:	48 89 47 08          	mov    %rax,0x8(%rdi)
 491ed55:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
 491ed59:	48 89 d8             	mov    %rbx,%rax
 491ed5c:	4c 29 f8             	sub    %r15,%rax
 491ed5f:	0f 82 71 03 00 00    	jb     491f0d6 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x5a6>
 491ed65:	4d 01 fc             	add    %r15,%r12
 491ed68:	4c 89 26             	mov    %r12,(%rsi)
 491ed6b:	48 89 46 08          	mov    %rax,0x8(%rsi)
 491ed6f:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
 491ed73:	0f 10 07             	movups (%rdi),%xmm0
 491ed76:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
 491ed7a:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
 491ed7e:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
 491ed82:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
 491ed89:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
 491ed90:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
 491ed97:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
 491ed9e:	48 8b 06             	mov    (%rsi),%rax
 491eda1:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
 491eda5:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
 491eda9:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
 491edad:	48 8b 56 30          	mov    0x30(%rsi),%rdx
 491edb1:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 491edb5:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
 491edb9:	88 55 b8             	mov    %dl,-0x48(%rbp)
 491edbc:	8b 56 39             	mov    0x39(%rsi),%edx
 491edbf:	89 55 b9             	mov    %edx,-0x47(%rbp)
 491edc2:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
 491edc6:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
 491edca:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
 491edce:	88 55 bf             	mov    %dl,-0x41(%rbp)
 491edd1:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
 491edd5:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
 491edd9:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 491eddd:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
 491ede1:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
 491ede8:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
 491edef:	ff 15 5b c1 2d 00    	call   *0x2dc15b(%rip)        # 4bfaf50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75c0>
 491edf5:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
 491edfc:	ff 
 491edfd:	41 80 fc ff          	cmp    $0xff,%r12b
 491ee01:	0f 84 bb 01 00 00    	je     491efc2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
 491ee07:	48 8b 05 42 c1 2d 00 	mov    0x2dc142(%rip),%rax        # 4bfaf50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75c0>
 491ee0e:	eb 2c                	jmp    491ee3c <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x30c>
 491ee10:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
 491ee17:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
 491ee1e:	48 8b 1d 2b c1 2d 00 	mov    0x2dc12b(%rip),%rbx        # 4bfaf50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75c0>
 491ee25:	ff d3                	call   *%rbx
 491ee27:	48 89 d8             	mov    %rbx,%rax
 491ee2a:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
 491ee31:	ff 
 491ee32:	41 80 fc ff          	cmp    $0xff,%r12b
 491ee36:	0f 84 86 01 00 00    	je     491efc2 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x492>
 491ee3c:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
 491ee43:	ff 
 491ee44:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 491ee4b:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
 491ee52:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
 491ee59:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 491ee5d:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
 491ee64:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
 491ee6b:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
 491ee6f:	ff d0                	call   *%rax
 491ee71:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
 491ee78:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
 491ee7f:	0f 84 5c 01 00 00    	je     491efe1 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b1>
 491ee85:	41 0f b6 cc          	movzbl %r12b,%ecx
 491ee89:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
 491ee8d:	80 f9 06             	cmp    $0x6,%cl
 491ee90:	ba 00 00 00 00       	mov    $0x0,%edx
 491ee95:	4c 0f 42 c2          	cmovb  %rdx,%r8
 491ee99:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
 491ee9d:	40 80 ff 06          	cmp    $0x6,%dil
 491eea1:	48 0f 42 c2          	cmovb  %rdx,%rax
 491eea5:	49 39 c0             	cmp    %rax,%r8
 491eea8:	0f 9c c2             	setl   %dl
 491eeab:	0f 9f c0             	setg   %al
 491eeae:	0f 85 8c 00 00 00    	jne    491ef40 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x410>
 491eeb4:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
 491eebb:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 491eec2:	41 83 f8 04          	cmp    $0x4,%r8d
 491eec6:	74 47                	je     491ef0f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3df>
 491eec8:	4d 85 c0             	test   %r8,%r8
 491eecb:	0f 85 3f ff ff ff    	jne    491ee10 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
 491eed1:	40 80 ff 05          	cmp    $0x5,%dil
 491eed5:	0f 87 35 ff ff ff    	ja     491ee10 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
 491eedb:	48 39 f9             	cmp    %rdi,%rcx
 491eede:	41 0f 9c c0          	setl   %r8b
 491eee2:	0f 9f c0             	setg   %al
 491eee5:	41 38 fc             	cmp    %dil,%r12b
 491eee8:	75 70                	jne    491ef5a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x42a>
 491eeea:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
 491eef1:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 491eef8:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
 491eeff:	48 8d 3d 4a 40 08 fc 	lea    -0x3f7bfb6(%rip),%rdi        # 9a2f50 <_RNvNtCsk1QeC065jZ4_12sharded_slab3tid8REGISTRY+0x186d>
 491ef06:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
 491ef0a:	48 01 f9             	add    %rdi,%rcx
 491ef0d:	ff e1                	jmp    *%rcx
 491ef0f:	49 89 de             	mov    %rbx,%r14
 491ef12:	49 29 d6             	sub    %rdx,%r14
 491ef15:	48 0f 42 d3          	cmovb  %rbx,%rdx
 491ef19:	4c 89 ff             	mov    %r15,%rdi
 491ef1c:	ff 15 a6 63 2d 00    	call   *0x2d63a6(%rip)        # 4bf52c8 <memcmp@GLIBC_2.2.5>
 491ef22:	48 98                	cltq
 491ef24:	85 c0                	test   %eax,%eax
 491ef26:	4c 0f 45 f0          	cmovne %rax,%r14
 491ef2a:	4d 85 f6             	test   %r14,%r14
 491ef2d:	0f 98 c1             	sets   %cl
 491ef30:	0f 9f c0             	setg   %al
 491ef33:	28 c8                	sub    %cl,%al
 491ef35:	eb 0b                	jmp    491ef42 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
 491ef37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 491ef3e:	00 00 
 491ef40:	28 d0                	sub    %dl,%al
 491ef42:	3c fe                	cmp    $0xfe,%al
 491ef44:	0f 84 c6 fe ff ff    	je     491ee10 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
 491ef4a:	0f b6 c8             	movzbl %al,%ecx
 491ef4d:	85 c9                	test   %ecx,%ecx
 491ef4f:	0f 84 bb fe ff ff    	je     491ee10 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2e0>
 491ef55:	e9 89 00 00 00       	jmp    491efe3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
 491ef5a:	44 28 c0             	sub    %r8b,%al
 491ef5d:	eb e3                	jmp    491ef42 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
 491ef5f:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 491ef63:	4d 89 c5             	mov    %r8,%r13
 491ef66:	49 89 dc             	mov    %rbx,%r12
 491ef69:	49 29 d4             	sub    %rdx,%r12
 491ef6c:	48 0f 42 d3          	cmovb  %rbx,%rdx
 491ef70:	4c 89 ff             	mov    %r15,%rdi
 491ef73:	4c 8b 3d 4e 63 2d 00 	mov    0x2d634e(%rip),%r15        # 4bf52c8 <memcmp@GLIBC_2.2.5>
 491ef7a:	41 ff d7             	call   *%r15
 491ef7d:	48 98                	cltq
 491ef7f:	85 c0                	test   %eax,%eax
 491ef81:	4c 0f 45 e0          	cmovne %rax,%r12
 491ef85:	4d 85 e4             	test   %r12,%r12
 491ef88:	0f 98 c1             	sets   %cl
 491ef8b:	0f 9f c0             	setg   %al
 491ef8e:	75 a3                	jne    491ef33 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x403>
 491ef90:	4c 89 f3             	mov    %r14,%rbx
 491ef93:	4c 89 ea             	mov    %r13,%rdx
 491ef96:	4c 29 eb             	sub    %r13,%rbx
 491ef99:	49 0f 42 d6          	cmovb  %r14,%rdx
 491ef9d:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 491efa1:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 491efa5:	41 ff d7             	call   *%r15
 491efa8:	48 98                	cltq
 491efaa:	85 c0                	test   %eax,%eax
 491efac:	48 0f 45 d8          	cmovne %rax,%rbx
 491efb0:	48 85 db             	test   %rbx,%rbx
 491efb3:	e9 75 ff ff ff       	jmp    491ef2d <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3fd>
 491efb8:	41 38 c5             	cmp    %al,%r13b
 491efbb:	0f 97 c0             	seta   %al
 491efbe:	1c 00                	sbb    $0x0,%al
 491efc0:	eb 80                	jmp    491ef42 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x412>
 491efc2:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
 491efc9:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
 491efcd:	ff 15 7d bf 2d 00    	call   *0x2dbf7d(%rip)        # 4bfaf50 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next@@Base+0x2b75c0>
 491efd3:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
 491efda:	0f 95 c0             	setne  %al
 491efdd:	f6 d8                	neg    %al
 491efdf:	eb 02                	jmp    491efe3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x4b3>
 491efe1:	b0 01                	mov    $0x1,%al
 491efe3:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
 491efea:	5b                   	pop    %rbx
 491efeb:	41 5c                	pop    %r12
 491efed:	41 5d                	pop    %r13
 491efef:	41 5e                	pop    %r14
 491eff1:	41 5f                	pop    %r15
 491eff3:	5d                   	pop    %rbp
 491eff4:	c3                   	ret
 491eff5:	43 0f b6 4c 05 01    	movzbl 0x1(%r13,%r8,1),%ecx
 491effb:	ba 01 00 00 00       	mov    $0x1,%edx
 491f000:	43 3a 4c 04 01       	cmp    0x1(%r12,%r8,1),%cl
 491f005:	0f 85 08 fd ff ff    	jne    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f00b:	83 f8 02             	cmp    $0x2,%eax
 491f00e:	0f 84 b0 fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f014:	43 0f b6 4c 05 02    	movzbl 0x2(%r13,%r8,1),%ecx
 491f01a:	ba 02 00 00 00       	mov    $0x2,%edx
 491f01f:	43 3a 4c 04 02       	cmp    0x2(%r12,%r8,1),%cl
 491f024:	0f 85 e9 fc ff ff    	jne    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f02a:	83 f8 03             	cmp    $0x3,%eax
 491f02d:	0f 84 91 fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f033:	43 0f b6 4c 05 03    	movzbl 0x3(%r13,%r8,1),%ecx
 491f039:	ba 03 00 00 00       	mov    $0x3,%edx
 491f03e:	43 3a 4c 04 03       	cmp    0x3(%r12,%r8,1),%cl
 491f043:	0f 85 ca fc ff ff    	jne    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f049:	83 f8 04             	cmp    $0x4,%eax
 491f04c:	0f 84 72 fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f052:	43 0f b6 4c 05 04    	movzbl 0x4(%r13,%r8,1),%ecx
 491f058:	ba 04 00 00 00       	mov    $0x4,%edx
 491f05d:	43 3a 4c 04 04       	cmp    0x4(%r12,%r8,1),%cl
 491f062:	0f 85 ab fc ff ff    	jne    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f068:	83 f8 05             	cmp    $0x5,%eax
 491f06b:	0f 84 53 fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f071:	43 0f b6 4c 05 05    	movzbl 0x5(%r13,%r8,1),%ecx
 491f077:	ba 05 00 00 00       	mov    $0x5,%edx
 491f07c:	43 3a 4c 04 05       	cmp    0x5(%r12,%r8,1),%cl
 491f081:	0f 85 8c fc ff ff    	jne    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f087:	83 f8 06             	cmp    $0x6,%eax
 491f08a:	0f 84 34 fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f090:	43 0f b6 44 05 06    	movzbl 0x6(%r13,%r8,1),%eax
 491f096:	ba 06 00 00 00       	mov    $0x6,%edx
 491f09b:	43 3a 44 04 06       	cmp    0x6(%r12,%r8,1),%al
 491f0a0:	0f 84 1e fc ff ff    	je     491ecc4 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x194>
 491f0a6:	e9 68 fc ff ff       	jmp    491ed13 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1e3>
 491f0ab:	48 8d 0d 36 9b 2a 00 	lea    0x2a9b36(%rip),%rcx        # 4bc8be8 <anon.6429032ee2eb37635272542406ebb090.345.llvm.10595971969026219501+0x90>
 491f0b2:	31 ff                	xor    %edi,%edi
 491f0b4:	48 89 d6             	mov    %rdx,%rsi
 491f0b7:	4c 89 f2             	mov    %r14,%rdx
 491f0ba:	ff 15 30 60 2d 00    	call   *0x2d6030(%rip)        # 4bf50f0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41500>
 491f0c0:	48 8d 0d 09 9b 2a 00 	lea    0x2a9b09(%rip),%rcx        # 4bc8bd0 <anon.6429032ee2eb37635272542406ebb090.345.llvm.10595971969026219501+0x78>
 491f0c7:	4c 89 ff             	mov    %r15,%rdi
 491f0ca:	4c 89 f6             	mov    %r14,%rsi
 491f0cd:	4c 89 f2             	mov    %r14,%rdx
 491f0d0:	ff 15 1a 60 2d 00    	call   *0x2d601a(%rip)        # 4bf50f0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41500>
 491f0d6:	48 8d 0d db 9a 2a 00 	lea    0x2a9adb(%rip),%rcx        # 4bc8bb8 <anon.6429032ee2eb37635272542406ebb090.345.llvm.10595971969026219501+0x60>
 491f0dd:	4c 89 ff             	mov    %r15,%rdi
 491f0e0:	48 89 de             	mov    %rbx,%rsi
 491f0e3:	48 89 da             	mov    %rbx,%rdx
 491f0e6:	ff 15 04 60 2d 00    	call   *0x2d6004(%rip)        # 4bf50f0 <_RNvNtNtCs6dXFfYvh3zM_4core5slice5index16slice_index_fail@@Base+0x3a41500>
