
/home/dev-user/Documents/Codex/2026-10-28/i-want-you-to-hillclimb-on/work/round18-compiler/full-toolchain/receipts/host-consumers-base/libhost_macro.so:     file format elf64-x86-64


Disassembly of section .text:

000000000002f6b0 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components>:
   2f6b0:	55                   	push   %rbp
   2f6b1:	48 89 e5             	mov    %rsp,%rbp
   2f6b4:	41 57                	push   %r15
   2f6b6:	41 56                	push   %r14
   2f6b8:	41 55                	push   %r13
   2f6ba:	41 54                	push   %r12
   2f6bc:	53                   	push   %rbx
   2f6bd:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   2f6c4:	80 7f 10 ff          	cmpb   $0xff,0x10(%rdi)
   2f6c8:	0f 85 e5 00 00 00    	jne    2f7b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   2f6ce:	80 7e 10 ff          	cmpb   $0xff,0x10(%rsi)
   2f6d2:	0f 85 db 00 00 00    	jne    2f7b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   2f6d8:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
   2f6dc:	3a 46 38             	cmp    0x38(%rsi),%al
   2f6df:	0f 85 ce 00 00 00    	jne    2f7b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   2f6e5:	4c 8b 2f             	mov    (%rdi),%r13
   2f6e8:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
   2f6ec:	4c 8b 26             	mov    (%rsi),%r12
   2f6ef:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   2f6f3:	49 39 d8             	cmp    %rbx,%r8
   2f6f6:	49 89 df             	mov    %rbx,%r15
   2f6f9:	4d 0f 42 f8          	cmovb  %r8,%r15
   2f6fd:	4d 85 ff             	test   %r15,%r15
   2f700:	74 22                	je     2f724 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x74>
   2f702:	31 d2                	xor    %edx,%edx
   2f704:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f70b:	00 00 00 00 00 
   2f710:	41 0f b6 44 15 00    	movzbl 0x0(%r13,%rdx,1),%eax
   2f716:	41 3a 04 14          	cmp    (%r12,%rdx,1),%al
   2f71a:	75 35                	jne    2f751 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xa1>
   2f71c:	48 ff c2             	inc    %rdx
   2f71f:	49 39 d7             	cmp    %rdx,%r15
   2f722:	75 ec                	jne    2f710 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x60>
   2f724:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
   2f728:	49 89 fe             	mov    %rdi,%r14
   2f72b:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   2f72f:	e8 fc 28 00 00       	call   32030 <_RNvXNtNtCs6dXFfYvh3zM_4core3ops12control_flowINtB2_11ControlFlowTRINtNtCs6kI715cJ891_9addr2line4unit7ResUnitINtNtNtCs11sHDhhO5s2_5gimli4read12endian_slice11EndianSliceNtNtB1P_9endianity12LittleEndianEERNtNtB1N_8rnglists5RangeEENtNtB4_9try_trait3Try11from_outputCsiQYcVP9ELT8_3std>
   2f734:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   2f738:	4c 89 f7             	mov    %r14,%rdi
   2f73b:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   2f73f:	a8 01                	test   $0x1,%al
   2f741:	74 17                	je     2f75a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xaa>
   2f743:	48 39 da             	cmp    %rbx,%rdx
   2f746:	0f 87 e9 02 00 00    	ja     2fa35 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x385>
   2f74c:	49 89 d7             	mov    %rdx,%r15
   2f74f:	eb 15                	jmp    2f766 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
   2f751:	b8 01 00 00 00       	mov    $0x1,%eax
   2f756:	a8 01                	test   $0x1,%al
   2f758:	75 e9                	jne    2f743 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x93>
   2f75a:	4c 39 c3             	cmp    %r8,%rbx
   2f75d:	75 07                	jne    2f766 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xb6>
   2f75f:	31 c0                	xor    %eax,%eax
   2f761:	e9 bd 02 00 00       	jmp    2fa23 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   2f766:	4d 85 ff             	test   %r15,%r15
   2f769:	74 48                	je     2f7b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   2f76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2f770:	43 80 7c 3d ff 2f    	cmpb   $0x2f,-0x1(%r13,%r15,1)
   2f776:	74 07                	je     2f77f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xcf>
   2f778:	49 ff cf             	dec    %r15
   2f77b:	75 f3                	jne    2f770 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0xc0>
   2f77d:	eb 34                	jmp    2f7b3 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x103>
   2f77f:	48 89 d8             	mov    %rbx,%rax
   2f782:	4c 29 f8             	sub    %r15,%rax
   2f785:	0f 82 bf 02 00 00    	jb     2fa4a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x39a>
   2f78b:	4d 01 fd             	add    %r15,%r13
   2f78e:	4c 89 2f             	mov    %r13,(%rdi)
   2f791:	48 89 47 08          	mov    %rax,0x8(%rdi)
   2f795:	c6 47 38 02          	movb   $0x2,0x38(%rdi)
   2f799:	4c 89 c0             	mov    %r8,%rax
   2f79c:	4c 29 f8             	sub    %r15,%rax
   2f79f:	0f 82 bb 02 00 00    	jb     2fa60 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x3b0>
   2f7a5:	4d 01 fc             	add    %r15,%r12
   2f7a8:	4c 89 26             	mov    %r12,(%rsi)
   2f7ab:	48 89 46 08          	mov    %rax,0x8(%rsi)
   2f7af:	c6 46 38 02          	movb   $0x2,0x38(%rsi)
   2f7b3:	0f 10 07             	movups (%rdi),%xmm0
   2f7b6:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
   2f7ba:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
   2f7be:	0f 10 5f 30          	movups 0x30(%rdi),%xmm3
   2f7c2:	0f 29 9d 00 ff ff ff 	movaps %xmm3,-0x100(%rbp)
   2f7c9:	0f 29 95 f0 fe ff ff 	movaps %xmm2,-0x110(%rbp)
   2f7d0:	0f 29 8d e0 fe ff ff 	movaps %xmm1,-0x120(%rbp)
   2f7d7:	0f 29 85 d0 fe ff ff 	movaps %xmm0,-0x130(%rbp)
   2f7de:	48 8b 06             	mov    (%rsi),%rax
   2f7e1:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   2f7e5:	0f 10 46 10          	movups 0x10(%rsi),%xmm0
   2f7e9:	0f 10 4e 20          	movups 0x20(%rsi),%xmm1
   2f7ed:	48 8b 56 30          	mov    0x30(%rsi),%rdx
   2f7f1:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
   2f7f5:	0f b6 56 38          	movzbl 0x38(%rsi),%edx
   2f7f9:	88 55 b8             	mov    %dl,-0x48(%rbp)
   2f7fc:	8b 56 39             	mov    0x39(%rsi),%edx
   2f7ff:	89 55 b9             	mov    %edx,-0x47(%rbp)
   2f802:	0f b7 56 3d          	movzwl 0x3d(%rsi),%edx
   2f806:	66 89 55 bd          	mov    %dx,-0x43(%rbp)
   2f80a:	0f b6 56 3f          	movzbl 0x3f(%rsi),%edx
   2f80e:	88 55 bf             	mov    %dl,-0x41(%rbp)
   2f811:	0f 29 4d a0          	movaps %xmm1,-0x60(%rbp)
   2f815:	0f 29 45 90          	movaps %xmm0,-0x70(%rbp)
   2f819:	48 89 45 80          	mov    %rax,-0x80(%rbp)
   2f81d:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
   2f821:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   2f828:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   2f82f:	ff 15 8b b1 02 00    	call   *0x2b18b(%rip)        # 5a9c0 <_GLOBAL_OFFSET_TABLE_+0x280>
   2f835:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   2f83c:	ff 
   2f83d:	41 80 fc ff          	cmp    $0xff,%r12b
   2f841:	0f 84 bb 01 00 00    	je     2fa02 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
   2f847:	48 8d 05 02 40 00 00 	lea    0x4002(%rip),%rax        # 33850 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   2f84e:	eb 2c                	jmp    2f87c <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1cc>
   2f850:	48 8d bd 48 ff ff ff 	lea    -0xb8(%rbp),%rdi
   2f857:	48 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%rsi
   2f85e:	48 8d 1d eb 3f 00 00 	lea    0x3feb(%rip),%rbx        # 33850 <_RNvXsi_NtCsiQYcVP9ELT8_3std4pathNtB5_10ComponentsNtNtNtNtCs6dXFfYvh3zM_4core4iter6traits8iterator8Iterator4next>
   2f865:	ff d3                	call   *%rbx
   2f867:	48 89 d8             	mov    %rbx,%rax
   2f86a:	44 0f b6 a5 48 ff ff 	movzbl -0xb8(%rbp),%r12d
   2f871:	ff 
   2f872:	41 80 fc ff          	cmp    $0xff,%r12b
   2f876:	0f 84 86 01 00 00    	je     2fa02 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x352>
   2f87c:	44 0f b6 ad 49 ff ff 	movzbl -0xb7(%rbp),%r13d
   2f883:	ff 
   2f884:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
   2f88b:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
   2f892:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
   2f899:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   2f89d:	4c 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%r14
   2f8a4:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   2f8ab:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   2f8af:	ff d0                	call   *%rax
   2f8b1:	0f b6 bd 10 ff ff ff 	movzbl -0xf0(%rbp),%edi
   2f8b8:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
   2f8bf:	0f 84 5c 01 00 00    	je     2fa21 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x371>
   2f8c5:	41 0f b6 cc          	movzbl %r12b,%ecx
   2f8c9:	4c 8d 41 fb          	lea    -0x5(%rcx),%r8
   2f8cd:	80 f9 06             	cmp    $0x6,%cl
   2f8d0:	ba 00 00 00 00       	mov    $0x0,%edx
   2f8d5:	4c 0f 42 c2          	cmovb  %rdx,%r8
   2f8d9:	48 8d 47 fb          	lea    -0x5(%rdi),%rax
   2f8dd:	40 80 ff 06          	cmp    $0x6,%dil
   2f8e1:	48 0f 42 c2          	cmovb  %rdx,%rax
   2f8e5:	49 39 c0             	cmp    %rax,%r8
   2f8e8:	0f 9c c2             	setl   %dl
   2f8eb:	0f 9f c0             	setg   %al
   2f8ee:	0f 85 8c 00 00 00    	jne    2f980 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d0>
   2f8f4:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
   2f8fb:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
   2f902:	41 83 f8 04          	cmp    $0x4,%r8d
   2f906:	74 47                	je     2f94f <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x29f>
   2f908:	4d 85 c0             	test   %r8,%r8
   2f90b:	0f 85 3f ff ff ff    	jne    2f850 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   2f911:	40 80 ff 05          	cmp    $0x5,%dil
   2f915:	0f 87 35 ff ff ff    	ja     2f850 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   2f91b:	48 39 f9             	cmp    %rdi,%rcx
   2f91e:	41 0f 9c c0          	setl   %r8b
   2f922:	0f 9f c0             	setg   %al
   2f925:	41 38 fc             	cmp    %dil,%r12b
   2f928:	75 70                	jne    2f99a <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2ea>
   2f92a:	0f b6 85 11 ff ff ff 	movzbl -0xef(%rbp),%eax
   2f931:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
   2f938:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
   2f93f:	48 8d 3d 12 cb 01 00 	lea    0x1cb12(%rip),%rdi        # 4c458 <_fini+0x69b4>
   2f946:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
   2f94a:	48 01 f9             	add    %rdi,%rcx
   2f94d:	ff e1                	jmp    *%rcx
   2f94f:	49 89 de             	mov    %rbx,%r14
   2f952:	49 29 d6             	sub    %rdx,%r14
   2f955:	48 0f 42 d3          	cmovb  %rbx,%rdx
   2f959:	4c 89 ff             	mov    %r15,%rdi
   2f95c:	ff 15 6e b1 02 00    	call   *0x2b16e(%rip)        # 5aad0 <memcmp@GLIBC_2.2.5>
   2f962:	48 98                	cltq
   2f964:	85 c0                	test   %eax,%eax
   2f966:	4c 0f 45 f0          	cmovne %rax,%r14
   2f96a:	4d 85 f6             	test   %r14,%r14
   2f96d:	0f 98 c1             	sets   %cl
   2f970:	0f 9f c0             	setg   %al
   2f973:	28 c8                	sub    %cl,%al
   2f975:	eb 0b                	jmp    2f982 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   2f977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2f97e:	00 00 
   2f980:	28 d0                	sub    %dl,%al
   2f982:	3c fe                	cmp    $0xfe,%al
   2f984:	0f 84 c6 fe ff ff    	je     2f850 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   2f98a:	0f b6 c8             	movzbl %al,%ecx
   2f98d:	85 c9                	test   %ecx,%ecx
   2f98f:	0f 84 bb fe ff ff    	je     2f850 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x1a0>
   2f995:	e9 89 00 00 00       	jmp    2fa23 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   2f99a:	44 28 c0             	sub    %r8b,%al
   2f99d:	eb e3                	jmp    2f982 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   2f99f:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
   2f9a3:	4d 89 c5             	mov    %r8,%r13
   2f9a6:	49 89 dc             	mov    %rbx,%r12
   2f9a9:	49 29 d4             	sub    %rdx,%r12
   2f9ac:	48 0f 42 d3          	cmovb  %rbx,%rdx
   2f9b0:	4c 89 ff             	mov    %r15,%rdi
   2f9b3:	4c 8b 3d 16 b1 02 00 	mov    0x2b116(%rip),%r15        # 5aad0 <memcmp@GLIBC_2.2.5>
   2f9ba:	41 ff d7             	call   *%r15
   2f9bd:	48 98                	cltq
   2f9bf:	85 c0                	test   %eax,%eax
   2f9c1:	4c 0f 45 e0          	cmovne %rax,%r12
   2f9c5:	4d 85 e4             	test   %r12,%r12
   2f9c8:	0f 98 c1             	sets   %cl
   2f9cb:	0f 9f c0             	setg   %al
   2f9ce:	75 a3                	jne    2f973 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2c3>
   2f9d0:	4c 89 f3             	mov    %r14,%rbx
   2f9d3:	4c 89 ea             	mov    %r13,%rdx
   2f9d6:	4c 29 eb             	sub    %r13,%rbx
   2f9d9:	49 0f 42 d6          	cmovb  %r14,%rdx
   2f9dd:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   2f9e1:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   2f9e5:	41 ff d7             	call   *%r15
   2f9e8:	48 98                	cltq
   2f9ea:	85 c0                	test   %eax,%eax
   2f9ec:	48 0f 45 d8          	cmovne %rax,%rbx
   2f9f0:	48 85 db             	test   %rbx,%rbx
   2f9f3:	e9 75 ff ff ff       	jmp    2f96d <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2bd>
   2f9f8:	41 38 c5             	cmp    %al,%r13b
   2f9fb:	0f 97 c0             	seta   %al
   2f9fe:	1c 00                	sbb    $0x0,%al
   2fa00:	eb 80                	jmp    2f982 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x2d2>
   2fa02:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
   2fa09:	48 8d 75 80          	lea    -0x80(%rbp),%rsi
   2fa0d:	ff 15 ad af 02 00    	call   *0x2afad(%rip)        # 5a9c0 <_GLOBAL_OFFSET_TABLE_+0x280>
   2fa13:	80 bd 10 ff ff ff ff 	cmpb   $0xff,-0xf0(%rbp)
   2fa1a:	0f 95 c0             	setne  %al
   2fa1d:	f6 d8                	neg    %al
   2fa1f:	eb 02                	jmp    2fa23 <_RNvNtCsiQYcVP9ELT8_3std4path18compare_components+0x373>
   2fa21:	b0 01                	mov    $0x1,%al
   2fa23:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   2fa2a:	5b                   	pop    %rbx
   2fa2b:	41 5c                	pop    %r12
   2fa2d:	41 5d                	pop    %r13
   2fa2f:	41 5e                	pop    %r14
   2fa31:	41 5f                	pop    %r15
   2fa33:	5d                   	pop    %rbp
   2fa34:	c3                   	ret
   2fa35:	48 8d 0d 74 97 02 00 	lea    0x29774(%rip),%rcx        # 591b0 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x890>
   2fa3c:	31 ff                	xor    %edi,%edi
   2fa3e:	48 89 d6             	mov    %rdx,%rsi
   2fa41:	48 89 da             	mov    %rbx,%rdx
   2fa44:	ff 15 c6 ae 02 00    	call   *0x2aec6(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
   2fa4a:	48 8d 0d 47 97 02 00 	lea    0x29747(%rip),%rcx        # 59198 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x878>
   2fa51:	4c 89 ff             	mov    %r15,%rdi
   2fa54:	48 89 de             	mov    %rbx,%rsi
   2fa57:	48 89 da             	mov    %rbx,%rdx
   2fa5a:	ff 15 b0 ae 02 00    	call   *0x2aeb0(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
   2fa60:	48 8d 0d 19 97 02 00 	lea    0x29719(%rip),%rcx        # 59180 <__rustc_proc_macro_decls_2fef3da1e844fc4f__+0x860>
   2fa67:	4c 89 ff             	mov    %r15,%rdi
   2fa6a:	4c 89 c6             	mov    %r8,%rsi
   2fa6d:	4c 89 c2             	mov    %r8,%rdx
   2fa70:	ff 15 9a ae 02 00    	call   *0x2ae9a(%rip)        # 5a910 <_GLOBAL_OFFSET_TABLE_+0x1d0>
