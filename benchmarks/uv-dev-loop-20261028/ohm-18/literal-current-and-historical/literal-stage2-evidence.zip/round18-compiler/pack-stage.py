"""Freeze a finished stage-2 host and target sysroot, restore official linkers, and exercise all compiler consumers."""
import argparse,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('arm',choices=['base','guard']);p.add_argument('cargo',type=Path);a=p.parse_args();a.cargo=a.cargo.resolve();lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';host='x86_64-unknown-linux-gnu';src=root/'src';build=root/'paired-build'/host/'stage2';release=lab.parent/'upstream-monitor/toolchain18';r=root/'receipts';out=root/'arms'/a.arm;tag=time.strftime('%Y%m%dT%H%M%S', time.gmtime());tmp=out.with_name(a.arm+'.pending-'+tag);assert not out.exists();tmp.parent.mkdir(exist_ok=True);tmp.mkdir();log=r/('package-'+a.arm+'.log');receipt={'arm':a.arm,'cargo_source_file':str(a.cargo),'config':str(root/'bootstrap-paired-release-dylib.toml')}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def capture(args,**kw):
 with log.open('a') as f:f.write('$ '+' '.join(map(str,args))+'\n')
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,**kw)
 with log.open('a') as f:f.write(result.stdout+'\n')
 if result.returncode:raise subprocess.CalledProcessError(result.returncode,args,output=result.stdout)
 return result.stdout
receipts=[json.loads(v.read_text()) for v in sorted(r.glob('bootstrap-'+a.arm+'-*/status.json'))];complete=next((v for v in reversed(receipts) if v['status']=='complete'),None);assert complete and sha(src/'library/std/src/path.rs')==complete['source_library_path_sha256'];assert sha(receipt['config'])==complete['config_sha256'];receipt['bootstrap']=complete
sources=json.loads((root/'source-status.json').read_text());known=json.loads((lab/'literal-native/known-binaries.json').read_text());arm_name={'base':'base','guard':'stack'}[a.arm]
assert complete['source_library_path_sha256']==sources['guarded_std_path' if a.arm=='guard' else 'baseline_std_path']
assert sha(a.cargo)==known[arm_name]['cargo'];receipt.update(expected_cargo_sha256=known[arm_name]['cargo'],source_rust_commit=sources['rust'],source_coordinator_commit=sources['coordinator'])
link_proof=json.loads((r/'bootstrap-release-lld/receipt.json').read_text());assert sha(receipt['config'])==link_proof['paired_config_sha256'] and sha(link_proof['wrapper'])==link_proof['wrapper_sha256']
expected_lld=release/'lib/rustlib'/host/'bin/rust-lld';actual_driver_links=[]
for vector in sorted((Path(complete['attempt'])/'link-processes').glob('*rust-lld.json')):
 recorded=json.loads(vector.read_text());argv=recorded['argv'];outputs=[Path(argv[i+1]) for i,x in enumerate(argv[:-1]) if x=='-o']
 if any('stage2-rustc' in o.parts and re.fullmatch(r'librustc_driver-[0-9a-f]+\.so',o.name) for o in outputs):
  assert Path(recorded['exe']).resolve()==expected_lld.resolve() and sha(expected_lld)==link_proof['release_rust_lld_sha256'];actual_driver_links.append({'file':str(vector),'sha256':sha(vector),'executable':recorded['exe']})
assert actual_driver_links,'no receipt for the final stage2 driver link';receipt['bootstrap_link']={'config_sha256':link_proof['paired_config_sha256'],'cc_wrapper_sha256':link_proof['wrapper_sha256'],'lld_sha256':link_proof['release_rust_lld_sha256'],'actual_stage2_driver':actual_driver_links}
bridge,=list((build.parent/'stage1/lib').glob('librustc_driver-*.so'));receipt['stage1_bridge_sha256']=sha(bridge)
if a.arm=='guard':
 baseline_manifest=json.loads((root/'arms/base/ohm-matched-ready.json').read_text());assert receipt['stage1_bridge_sha256']==baseline_manifest['stage1_bridge_sha256'], 'the external-stage0 bridge unexpectedly changed'
def check_runtime(linkage,expected):
 assert 'not found' not in linkage,linkage
 candidates=[line.split(' => ',1)[1].rsplit(' (',1)[0].strip() for line in linkage.splitlines() if line.strip().startswith(expected.name+' => ')]
 assert len(candidates)==1 and Path(candidates[0]).resolve()==expected.resolve(),(candidates,expected)
# The stage directory contains two developer source links to the *entire* checkout.
# The installed release has neither optional source component. Copy the runtime first,
# then remove exactly those two verified symlinks from this independent package.
source_links = ('lib/rustlib/src/rust', 'lib/rustlib/rustc-src/rust')
for rel in source_links:
 assert (build/rel).is_symlink() and (build/rel).resolve() == src.resolve()
 assert not (release/rel).exists()
capture(['cp','-a','--reflink=auto',str(build)+'/.',tmp])
for rel in source_links:
 target = tmp/rel
 assert target.is_symlink() and target.resolve()==src.resolve()
 target.unlink()
 target.parent.rmdir()
assert all(p.resolve().is_relative_to(tmp) for p in tmp.rglob('*') if p.is_symlink())
receipt['omitted_optional_source_links'] = list(source_links)
dest=tmp/'lib/rustlib'/host/'bin';frombin=release/'lib/rustlib'/host/'bin';dest.mkdir(parents=True,exist_ok=True);capture(['cp','-aL','--reflink=auto',str(frombin)+'/.',dest]);receipt['released_linker_bundle']={str(p.relative_to(frombin)):sha(p) for p in sorted(frombin.rglob('*')) if p.is_file()};assert all(sha(dest/k)==v for k,v in receipt['released_linker_bundle'].items());shutil.copy2(a.cargo,tmp/'bin/cargo');rustc=tmp/'bin/rustc';rustdoc=tmp/'bin/rustdoc';cargo=tmp/'bin/cargo';driver,=list((tmp/'lib').glob('librustc_driver-*.so'));stdlib,=list((tmp/'lib/rustlib'/host/'lib').glob('libstd-*.rlib'));receipt['hashes']={str(p.relative_to(tmp)):sha(p) for p in (cargo,rustc,rustdoc,driver,stdlib)};linked=next((release/'lib').glob('libLLVM.so.*'));newllvm=tmp/'lib'/linked.name
if not newllvm.is_file():shutil.copy2(linked,newllvm)
assert sha(newllvm)==sha(linked)=='43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51';receipt['release_llvm_runtime_sha256']=sha(newllvm);env={k:v for k,v in os.environ.items() if k not in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC','RUSTDOC','CARGO_TARGET_DIR','LD_LIBRARY_PATH')};env.update(PATH=str(tmp/'bin')+':'+env['PATH'],RUSTC=str(rustc),RUSTDOC=str(rustdoc),CARGO_HOME=str(root/'cargo-home'),CARGO_NET_OFFLINE='true');receipt['rustc_version']=capture([rustc,'-Vv'],env=env);receipt['cargo_version']=capture([cargo,'-Vv'],env=env);receipt['rustdoc_version']=capture([rustdoc,'-Vv'],env=env);assert capture([rustc,'--print','sysroot'],env=env).strip()==str(tmp);receipt['target_libdir']=capture([rustc,'--print','target-libdir'],env=env).strip();assert Path(receipt['target_libdir']).resolve()==stdlib.parent.resolve();dyn=capture(['ldd',driver],env=env);check_runtime(dyn,newllvm);receipt['driver_linkage']=dyn
smoke=root/('stage2-smoke-'+a.arm+'-'+tag);smoke.mkdir();(smoke/'src').mkdir();(smoke/'mac/src').mkdir(parents=True);(smoke/'Cargo.toml').write_text('[package]\nname="stage2_consumer"\nversion="0.1.0"\nedition="2024"\n[dependencies]\nmac={path="mac"}\n');(smoke/'mac/Cargo.toml').write_text('[package]\nname="mac"\nversion="0.1.0"\nedition="2024"\n[lib]\nproc-macro=true\n');(smoke/'mac/src/lib.rs').write_text('extern crate proc_macro; #[proc_macro] pub fn answer(_:proc_macro::TokenStream)->proc_macro::TokenStream { "42u32".parse().unwrap() }\n');(smoke/'src/main.rs').write_text('''use std::{ffi::OsStr, os::unix::ffi::OsStrExt, path::Path};
#[inline(never)] fn check(a:&Path,b:&Path) { assert_eq!(a.cmp(b),a.components().collect::<Vec<_>>().cmp(&b.components().collect::<Vec<_>>())); }
fn main() { assert_eq!(mac::answer!(),42); let a=vec![b'a';96]; let mut inputs=vec![b"".to_vec(), b".".to_vec(), b"a/./b".to_vec(), b"a/b".to_vec(),b"/../a".to_vec(), vec![0xff],vec![0]]; for i in 0..a.len() { let mut b=a.clone(); b[i]=0; inputs.push(b); } for a in &inputs { for b in &inputs { check(Path::new(OsStr::from_bytes(a)),Path::new(OsStr::from_bytes(b))); } } println!("{} pairs",inputs.len()*inputs.len()); }
#[test] fn works() { main(); }
''');commands=[['generate-lockfile'],['check','--locked'],['build','--locked'],['test','--locked','--no-run']];
for sub in commands:capture([cargo,*sub,'--offline'],cwd=smoke,env=env)
consumer=smoke/'target/debug/stage2_consumer';receipt['consumer_result']=capture([consumer],cwd=smoke,env=env).strip();assert receipt['consumer_result']=='10609 pairs';receipt['commands']=['cargo '+' '.join(x)+' --offline' for x in commands]
# Record the selected implementation in a real rustc driver and a normal target executable.
def path_symbol(binary,label):
 proc=subprocess.Popen(['nm','-S','--defined-only',binary],stdout=subprocess.PIPE,text=True);rows=[s.split() for s in proc.stdout if 'compare_components' in s and '.cold' not in s];assert proc.wait()==0;rows=[u for u in rows if len(u)==4 and u[2].lower()=='t'];assert rows,(binary,label);sym=max(rows,key=lambda u:int(u[1],16));addr,n=int(sym[0],16),int(sym[1],16);asm=subprocess.check_output(['objdump','-d',f'--start-address={addr}',f'--stop-address={addr+n}',binary],text=True);(r/f'{a.arm}-{label}-compare.asm').write_text(asm);return {'symbol':sym[3],'bytes':n,'word_mismatch_bit_scan':bool(re.search(r'\b(?:tzcnt|bsf)\w*\b',asm))}
receipt['implementation']={'rustc_driver':path_symbol(driver,'rustc-driver'),'target_consumer':path_symbol(consumer,'target-consumer')};assert all(v['word_mismatch_bit_scan']==(a.arm=='guard') for v in receipt['implementation'].values());tmp.rename(out);receipt['final_sysroot']=subprocess.check_output([out/'bin/rustc','--print','sysroot'],text=True).strip();assert receipt['final_sysroot']==str(out);receipt['relocated_linkage']=capture(['ldd',out/driver.relative_to(tmp)]);check_runtime(receipt['relocated_linkage'],out/'lib'/linked.name);receipt['final_target_libdir']=capture([out/'bin/rustc','--print','target-libdir']).strip();assert Path(receipt['final_target_libdir']).resolve()==(out/'lib/rustlib'/host/'lib').resolve();ready=out/'ohm-matched-ready.json';pending=ready.with_suffix('.pending');pending.write_text(json.dumps(receipt,indent=2)+'\n');pending.replace(ready);print(str(out),flush=True)
