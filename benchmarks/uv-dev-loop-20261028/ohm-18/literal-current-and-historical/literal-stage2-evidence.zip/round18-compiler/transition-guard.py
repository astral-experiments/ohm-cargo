"""After a verified full base, switch only published std source and freshen all outputs that depend on it."""
from pathlib import Path
import hashlib,json,subprocess,time
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';src=root/'src';host='x86_64-unknown-linux-gnu';stage=root/'paired-build'/host;receipt=root/'receipts/guard-source-transition.json';park=root/'frozen-base-build-state';base=root/'arms/base/ohm-matched-ready.json';patch=lab.parent/'upstream-monitor/rust/247.diff';assert base.is_file() and not receipt.exists() and not park.exists();assert json.loads((root/'bootstrap-worker.json').read_text())['status']=='complete';assert json.loads(base.read_text())['arm']=='base';path=src/'library/std/src/path.rs';old='a41beffcf2ecd2b331c71cc7d6d2e7ca18f85e613106abee770821dd0e53be14';want='2a7b704c60ddf54ac1d9f82a9a50aa3edefe4a0e04b0f8fd3531a1d565b1f444'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(2**20),b''):h.update(block)
 return h.hexdigest()
assert sha(path)==old;subprocess.run(['git','apply','--no-index','--check',patch],cwd=src,check=True);driver,=list((stage/'stage1/lib').glob('librustc_driver-*.so'));stage1_hash=sha(driver);keep=stage/'stage1-rustc';assert keep.is_dir();names=sorted(x.name for x in stage.iterdir() if x!=keep and (x.name=='stage1' or x.name.startswith('stage1-') or x.name=='stage2' or x.name.startswith('stage2-')));assert 'stage1' in names and 'stage2' in names and 'stage2-rustc' in names;park.mkdir();state={'status':'started','published_diff':str(patch),'published_diff_sha256':sha(patch),'old_std_sha256':old,'expected_guarded_std_sha256':want,'base_ready':str(base),'stage1_bootstrap_driver_sha256':stage1_hash,'retained_compiler_target':str(keep),'explanation':'Rust bootstrap stage0 on its host uses downloaded stage0 std. Only its input-independent Cargo target (stage1-rustc) is reused. Stage1 std, both stage sysroots, the full stage2-producing Cargo target and all associated tool caches are parked. Common prepared native dependencies, bootstrap and downloaded compiler remain identical.','parked':names,'done':[]}
def record():
 t=receipt.with_suffix('.pending');t.write_text(json.dumps(state,indent=2)+'\n');t.replace(receipt)
record()
for name in names:(stage/name).rename(park/name);state['done'].append(name);record()
subprocess.run(['git','apply','--no-index',patch],cwd=src,check=True);assert sha(path)==want;state.update(status='ready',actual_std_sha256=sha(path));record();print('guard source and clean stage2 target ready',flush=True)
