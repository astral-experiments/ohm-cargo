"""Configure genuine monolithic-link llvm-config after pausing the separately resumable source LLVM fallback."""
from pathlib import Path
import datetime,json,os,shlex,subprocess,time
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';r=root/'receipts';old=r/'sdk-window-213210';assert os.sched_getaffinity(0)==set(range(16,24));deadline=datetime.datetime.fromisoformat('2026-10-28T21:48:40+00:00').timestamp()
while json.loads((old/'status.json').read_text())['status']=='running':
 assert time.time()<deadline;time.sleep(.3)
(root/'sdk-stop').rename(old/'requested-stop');(root/'prefer-release-dylib').touch();(r/'sdk-verify-component-library.log').write_bytes((r/'sdk-verify.log').read_bytes());orig=(r/'sdk-cmake-command').read_text();args=shlex.split(orig);assert '-DLLVM_LINK_LLVM_DYLIB=OFF' in args;args[args.index('-DLLVM_LINK_LLVM_DYLIB=OFF')]='-DLLVM_LINK_LLVM_DYLIB=ON';(r/'sdk-cmake-shared-command').write_text(shlex.join(args)+'\n')
with (r/'sdk-cmake-shared.log').open('xb') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=deadline-time.time())
subprocess.run(['python3',lab/'sdk-window.py','2026-10-28T21:48:40+00:00'],check=True)
subprocess.run(['python3',lab/'verify-sdk.py'],check=True,timeout=deadline-time.time());print('release library/SDK ABI probe passed')
