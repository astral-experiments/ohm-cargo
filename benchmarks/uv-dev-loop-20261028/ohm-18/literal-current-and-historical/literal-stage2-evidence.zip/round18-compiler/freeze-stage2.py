"""Attest the two materialized release-18 Rust runtime packages and freeze their compact provenance."""
from hashlib import file_digest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

lab = Path(__file__).resolve().parent
root = lab / 'full-toolchain'
receipts = root / 'receipts'
known = json.loads((lab / 'literal-native/known-binaries.json').read_text())
sources = json.loads((root / 'source-status.json').read_text())
release = lab.parent / 'upstream-monitor/toolchain18'

def sha(p):
    with p.open('rb') as f:
        return file_digest(f, 'sha256').hexdigest()

def load(p):
    return json.loads(p.read_text())

names = ['base', 'guard']
summary = {'release': sources['release'], 'rust_commit': sources['rust'], 'coordinator_commit': sources['coordinator'],
           'rust_pr': 'https://github.com/astral-sh/ohm-rust/pull/247',
           'arm_difference': 'Same x.py paths, source input, compiled bridge, LLVM, bootstrap linker, ThinLTO, and one CGU. The guard has the published std patch. Independently self-trained PGO Cargo drivers are packaged for the multi-component study.',
           'optimizer_provenance': 'Both local stage-2 compilers use no rustc-specific PGO or BOLT. The release uses both. Each Cargo executable uses its own self-trained profile. The actual installed release is a separate arm.',
           'runtime_scope': 'Stage-2 rustc driver and rustdoc, target and proc-macro sysroot, distributed LLVM and linker bundle. Wild is independently packaged by Ohm. Actual uv timings use the selected linker and an invariant relocated sysroot path.',
           'arms': {}}
paths = set()
for arm in names:
    installed = root / 'arms' / arm
    ready_path = installed / 'ohm-matched-ready.json'
    ready = load(ready_path)
    assert ready['source_rust_commit'] == sources['rust']
    expected = ready['implementation']
    assert set(expected) == {'rustc_driver','target_consumer'}
    assert all(info['word_mismatch_bit_scan'] == (arm == 'guard') for info in expected.values())
    assert ready['consumer_result'] == '10609 pairs'
    assert {cmd.split()[1] for cmd in ready['commands']} == {'check','build','test','generate-lockfile'}
    assert any('test --locked --no-run' in cmd for cmd in ready['commands'])
    assert ready['bootstrap']['config_sha256'] == sha(root / 'bootstrap-paired-release-dylib.toml')
    assert ready['hashes']['bin/cargo'] == known[{'guard':'stack','base':'base'}[arm]]['cargo']
    assert all(sha(installed / rel) == value for rel, value in ready['hashes'].items())
    assert all(sha(release / 'lib/rustlib/x86_64-unknown-linux-gnu/bin' / rel) == value for rel, value in ready['released_linker_bundle'].items())
    driver, = [v for k,v in ready['hashes'].items() if '/librustc_driver-' in k]
    std, = [v for k,v in ready['hashes'].items() if '/libstd-' in k]
    summary['arms'][arm] = {'ready_sha256': sha(ready_path), 'hashes': ready['hashes'], 'driver_sha256':driver,
        'std_sha256':std, 'stage1_bridge_sha256':ready['stage1_bridge_sha256'],
        'llvm_runtime_sha256': ready['release_llvm_runtime_sha256'], 'config_sha256':ready['bootstrap']['config_sha256'],
        'implementation':expected,'smoke':ready['consumer_result'], 'rustc_version':ready['rustc_version'].splitlines()[0],
        'cargo_version':ready['cargo_version'].splitlines()[0], 'std_source_sha256':ready['bootstrap']['source_library_path_sha256']}
    host_dir = receipts / ('host-consumers-'+arm)
    host_proof = load(host_dir/'ready.json')
    assert host_proof['package_sha256'] == sha(ready_path)
    assert host_proof['real_proc_macro_expansion_pairs'] == {'rustc':10404, 'rustdoc':10404}
    assert host_proof['host_macro_compare']['word_mismatch_bit_scan'] == (arm == 'guard')
    summary['arms'][arm]['host_proof'] = host_proof['host_macro_compare']
    summary['arms'][arm]['host_macro_source_sha256'] = host_proof['macro_source_sha256']
    summary['arms'][arm]['rustc_and_rustdoc_proc_macro_expansions'] = host_proof['real_proc_macro_expansion_pairs']
    for rel in ('ready.json','commands.log','host_macro.rs','consumer.rs','proc-macro-compare.asm','rustc-macro-actual.txt','rustdoc-macro-actual.txt'):
        paths.add(host_dir/rel)
    attempt = Path(ready['bootstrap']['attempt'])
    paths.update([ready_path, attempt/'build.log', attempt/'status.json', attempt/'link-processes/complete.json',
                  receipts/f'package-{arm}.log', receipts/f'{arm}-rustc-driver-compare.asm', receipts/f'{arm}-target-consumer-compare.asm'])
    paths.update(Path(v['file']) for v in ready['bootstrap_link']['actual_stage2_driver'])
base, guard = (summary['arms'][arm] for arm in names)
for key in ('stage1_bridge_sha256','llvm_runtime_sha256','config_sha256','host_macro_source_sha256'):
    assert base[key] == guard[key]
for key in ('driver_sha256','std_sha256','std_source_sha256'):
    assert base[key] != guard[key]
assert base['std_source_sha256']==sources['baseline_std_path'] and guard['std_source_sha256']==sources['guarded_std_path']

target_specs={};link_proofs={}
for arm in ('shipped','base','guard'):
    d = receipts / ('default-linker-'+arm)
    verified=load(d/'ready.json');target_specs[arm]=load(d/'target-spec.json')
    link_proofs[arm] = {'receipt_sha256':sha(d/'ready.json'), 'standalone_linker_flavor':verified['standalone_linker_flavor'],
                         'cargo_default_linker_sha256':verified['actual_linker_sha256'], 'actual_child':verified['actual_linker_execve']}
    assert len(verified['actual_linker_execve'])==1 and verified['actual_linker_execve'][0].endswith('/bin/wild-ld/ld.bfd')
    for rel in ('ready.json','cargo.log','execve.log','target-spec.json'): paths.add(d/rel)
assert target_specs['base']==target_specs['guard']
keys=set(target_specs['base'])|set(target_specs['shipped'])
differences=sorted(k for k in keys if target_specs['base'].get(k)!=target_specs['shipped'].get(k))
assert differences==['crt-objects-fallback','link-self-contained','linker-flavor']
assert len({rec['cargo_default_linker_sha256'] for rec in link_proofs.values()})==1
summary['linker_selection']={'standalone_target_spec_release_differences':differences,
    'scope':'Bootstrap external LLVM uses rust.lld=false. Direct standalone rustc defaults to GNU ld in both rebuilt arms and bundled LLD in the release. Ohm Cargo explicitly disables the target defaults and selects packaged Wild in its normal Linux configuration, verified by actual execve in all three supplied packages. The timed study separately installs each prescribed Wild and checks the observed linker role.', 'arms':link_proofs}
for rel in ('source-status.json','manifest.json','STATUS.md','bootstrap-paired-release-dylib.toml','release-bootstrap.toml','release-build.sh','bootstrap-linker/cc'):
    paths.add(root/rel)
for rel in ('source-materials.json','llvm-source.json','sdk-verified.json','stage0-downloads.json','coordinator-overlays.json','guard-source-transition.json','runtime-package-layout.json','separate-wild-payload.json','official-job.json','bootstrap-release-lld/receipt.json','bootstrap-release-lld/official-linux-job-linkage.json','bootstrap-release-lld/driver-execve.log'):
    paths.add(receipts/rel)
for rel in ('provision-full.py','complete-source.py','provision-llvm-source.py','complete-llvm-libc.py','configure-full.py','external-llvm-config.py','sdk-window.py','repair-sdk.py','verify-sdk.py','prepare-bootstrap-linker.py','bootstrap-window.py','observe-bootstrap-link.py','transition-guard.py','pack-stage.py','verify-default-linker.py','verify-host-consumers.py','freeze-stage2.py','literal-native-amended/input-lock.json'):
    paths.add(lab/rel)
for rel in ('upstream-monitor/rust/247.diff','round18-linker/current-pr46/ready.json'):
    paths.add(lab.parent/rel)
# No production binaries, registry caches, or source code are copied into the evidence archive.
report = root/'paired-stage2-verified.json'
encoded = json.dumps(summary,indent=2)+'\n'
if report.exists(): assert report.read_text()==encoded
else: report.write_text(encoded)
paths.add(report)
archive=lab/'literal-stage2-evidence.zip'
assert not archive.exists()
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as out:
    sums=[]
    for f in sorted(paths):
        rel = str(f.relative_to(lab.parent))
        out.write(f, rel); sums.append(f'{sha(f)}  {rel}\n')
    out.writestr('SHA256SUMS',''.join(sums))
with ZipFile(archive) as check:
    assert check.testzip() is None
    import hashlib
    for line in check.read('SHA256SUMS').decode().splitlines():
        digest, name=line.split('  ',1)
        assert hashlib.sha256(check.read(name)).hexdigest()==digest
print(sha(archive),archive.stat().st_size,str(archive),flush=True)
