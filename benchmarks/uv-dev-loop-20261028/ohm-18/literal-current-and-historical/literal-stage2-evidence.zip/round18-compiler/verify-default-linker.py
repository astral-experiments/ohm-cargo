"""Trace the actual untouched Cargo default linker for an isolated one-file target in each runtime."""
from pathlib import Path
from hashlib import file_digest
import argparse,json,os,re,subprocess

arg=argparse.ArgumentParser();arg.add_argument('arm',choices=('shipped','base','guard'));arm=arg.parse_args().arm
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';host='x86_64-unknown-linux-gnu'
installed=lab.parent/'upstream-monitor/toolchain18' if arm=='shipped' else root/'arms'/arm
if arm!='shipped':assert (installed/'ohm-matched-ready.json').is_file()
receipts=root/'receipts';out=receipts/('default-linker-'+arm);out.mkdir();fixture=receipts/'default-linker-tiny-fixture';fixture.mkdir(exist_ok=True)
fixtures={'Cargo.toml':'[package]\nname="ohm_linker_scope"\nversion="0.1.0"\nedition="2024"\n','Cargo.lock':'version = 4\n\n[[package]]\nname = "ohm_linker_scope"\nversion = "0.1.0"\n','main.rs':'fn main() { println!("linker probe"); }\n'}
(fixture/'src').mkdir(exist_ok=True)
for name,content in fixtures.items():
    path=(fixture/'src' if name=='main.rs' else fixture)/name
    if path.exists():assert path.read_text()==content
    else:path.write_text(content)

def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
cargo=installed/'bin/cargo';rustc=installed/'bin/rustc';release=lab.parent/'upstream-monitor/toolchain18';relative=Path('lib/rustlib')/host/'bin/wild-ld/ld.bfd';expected=installed/relative
assert sha(expected)==sha(release/relative)
env={'HOME':os.environ['HOME'],'PATH':f"{installed/'bin'}:/usr/local/bin:/usr/bin:/bin",'CARGO_HOME':str(out/'cargo-home'),'CARGO_TARGET_DIR':str(out/'target'),'CARGO_NET_OFFLINE':'true','RUSTC':str(rustc),'RUSTDOC':str(installed/'bin/rustdoc'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','CARGO_TERM_COLOR':'never'}
spec=subprocess.check_output([rustc,'-Zunstable-options','--print','target-spec-json'],env=env);(out/'target-spec.json').write_bytes(spec);data=json.loads(spec)
cmd=[str(cargo),'build','--locked','--offline','-j1','-vv'];trace=out/'execve.log';trace_cmd=['strace','-f','-qq','-s','16384','-e','trace=execve','-o',str(trace),*cmd]
with (out/'cargo.log').open('x') as log:subprocess.run(trace_cmd,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
flags=['-Clinker-features=-lld','-Clink-self-contained=-linker','-Clink-arg=-B'+str(expected.parent),'-Clink-arg=-fuse-ld=bfd'];body=(out/'cargo.log').read_text();rows=[line for line in body.splitlines() if '--crate-name ohm_linker_scope' in line];assert len(rows)==1 and all(f in rows[0] for f in flags),rows
successful=[]
for line in trace.read_text().splitlines():
    m=re.match(r'^\s*\d+\s+execve\("([^"\\]+)",.*\)\s+= 0$',line)
    if m:successful.append(m.group(1))
links=[s for s in successful if Path(s).name in ('ld.bfd','ld.lld','rust-lld','ld','lld','wild')];assert links==[str(expected)],links
program=out/'target/debug/ohm_linker_scope';actual=subprocess.check_output([program],text=True).strip();assert actual=='linker probe'
receipt={'arm':arm,'cargo_sha256':sha(cargo),'rustc_sha256':sha(rustc),'standalone_target_spec_sha256':sha(out/'target-spec.json'),'standalone_linker_flavor':data['linker-flavor'],'standalone_link_self_contained':data.get('link-self-contained'),'standalone_crt_objects_fallback':data.get('crt-objects-fallback'),'cargo_command':cmd,'default_cargo_rustflags':flags,'actual_linker_execve':links,'actual_linker_sha256':sha(expected),'all_successful_execve':successful,'run_output':actual,'execve_log_sha256':sha(trace),'cargo_log_sha256':sha(out/'cargo.log')};dest=out/'ready.json';tmp=dest.with_suffix('.pending');tmp.write_text(json.dumps(receipt,indent=2)+'\n');tmp.replace(dest);print(arm,sha(dest))
