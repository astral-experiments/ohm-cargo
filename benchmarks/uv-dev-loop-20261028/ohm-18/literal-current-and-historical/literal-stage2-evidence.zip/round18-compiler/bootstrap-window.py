"""Build the paired Ohm compiler interruptibly at invariant paths and freeze each attempted phase."""
from pathlib import Path
from datetime import datetime, timezone
import argparse,hashlib,json,os,signal,subprocess,time
p=argparse.ArgumentParser();p.add_argument('arm',choices=['base','guard']);p.add_argument('cutoff');p.add_argument('--cpus',default='16-23');a=p.parse_args();lo,hi=map(int,a.cpus.split('-'));cpus=list(range(lo,hi+1));assert set(cpus)==os.sched_getaffinity(0);deadline=datetime.fromisoformat(a.cutoff).timestamp();assert time.time()<deadline
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';src=root/'src';r=root/'receipts';tag=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S');attempt=r/f'bootstrap-{a.arm}-{tag}';attempt.mkdir();stop=root/'bootstrap-stop';assert not stop.exists();marker=root/'bootstrap-worker.json';cfg=root/'bootstrap-paired-release-dylib.toml';build=root/'paired-build';build.mkdir(exist_ok=True);host='x86_64-unknown-linux-gnu';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();actual=sha(src/'library/std/src/path.rs');want={'base':'a41beffcf2ecd2b331c71cc7d6d2e7ca18f85e613106abee770821dd0e53be14','guard':'2a7b704c60ddf54ac1d9f82a9a50aa3edefe4a0e04b0f8fd3531a1d565b1f444'}[a.arm];assert actual==want;(r/'sdk-verified.json').stat();env=dict(os.environ)
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN'):env.pop(k,None)
controlled={'CARGO_HOME':str(root/'cargo-home'),'CARGO_NET_OFFLINE':'true','CC':'clang-18','CXX':'clang++-18','LD_LIBRARY_PATH':str(root/'sdk-release-llvm/lib')};env.update(controlled);cmd=['python3','x.py','build','--stage','2','--config',str(cfg),'--build-dir',str(build),'--host',host,'--target',host,'-j'+str(min(8,len(cpus))),'compiler/rustc','library','src/librustdoc'];s={'arm':a.arm,'started':datetime.now(timezone.utc).isoformat(),'deadline':a.cutoff,'source_commit':'a4fa11bcd38280639cb94daacc125472657db6c3','source_library_path_sha256':actual,'cpus':cpus,'cwd':str(src),'config':str(cfg),'config_sha256':sha(cfg),'command':cmd,'env':controlled,'status':'starting','attempt':str(attempt)}
def rec():
 for target in (attempt/'status.json',marker):
  t=target.with_suffix('.tmp');t.write_text(json.dumps(s,indent=2)+'\n');t.replace(target)
def request(*_):stop.touch()
signal.signal(signal.SIGTERM,request);signal.signal(signal.SIGINT,request);rec()
with (attempt/'build.log').open('xb') as f:
 proc=subprocess.Popen(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);s.update(pgid=proc.pid,status='running');rec()
 while proc.poll() is None:
  if time.time()>=deadline or stop.exists():
   s['stop_reason']='cutoff' if time.time()>=deadline else 'requested';rec();os.killpg(proc.pid,signal.SIGINT)
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   break
  time.sleep(.45)
 s.update(exit=proc.returncode,ended=datetime.now(timezone.utc).isoformat(),status='stopped' if 'stop_reason' in s else ('complete' if proc.returncode==0 else 'failed'));rec();print(json.dumps(s),flush=True)
