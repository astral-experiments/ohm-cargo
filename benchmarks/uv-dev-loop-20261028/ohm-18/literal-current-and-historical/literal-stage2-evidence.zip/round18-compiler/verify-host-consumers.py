"""Exercise the compared standard-library Path code inside a loaded proc macro in rustc and rustdoc."""
from pathlib import Path
from hashlib import file_digest
import argparse,json,os,re,subprocess

p=argparse.ArgumentParser();p.add_argument('arm',choices=('base','guard'));arm=p.parse_args().arm
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';installed=root/'arms'/arm;ready=json.loads((installed/'ohm-matched-ready.json').read_text());assert ready['arm']==arm
out=root/'receipts'/('host-consumers-'+arm);out.mkdir()
macro=out/'host_macro.rs';consumer=out/'consumer.rs';dll=out/'libhost_macro.so';exe=out/'consumer'
macro.write_text('''extern crate proc_macro;
use proc_macro::TokenStream;
use std::{cmp::Ordering, ffi::OsStr, os::unix::ffi::OsStrExt, path::Path};
#[inline(never)] fn compare(a: &Path, b: &Path) -> Ordering { a.cmp(b) }
#[proc_macro] pub fn pairs(n: TokenStream) -> TokenStream {
    let width: usize = n.to_string().parse().unwrap();
    let mut cases = vec![b"".to_vec(), b".".to_vec(), b"a//b/./".to_vec(), b"a/b".to_vec(), vec![0xff], vec![0]];
    for i in 0..width { let mut bytes = vec![b'a'; width]; bytes[i] = 0; cases.push(bytes); }
    for a in &cases { for b in &cases {
        let (a, b) = (Path::new(OsStr::from_bytes(a)), Path::new(OsStr::from_bytes(b)));
        assert_eq!(compare(a, b), a.components().collect::<Vec<_>>().cmp(&b.components().collect::<Vec<_>>()));
    } }
    let n = cases.len() * cases.len();
    std::fs::write(std::env::var_os("OHM_STAGE2_PRIVATE_PROOF").unwrap(), n.to_string()).unwrap();
    n.to_string().parse().unwrap()
}
''');consumer.write_text('''extern crate host_macro;
/// The macro expands while compiling and documenting the crate.
pub const PAIRS: usize = host_macro::pairs!(96);
fn main() { assert_eq!(PAIRS, 10404); println!("{PAIRS}"); }
''')
commands=[];env={k:v for k,v in os.environ.items() if k not in ('LD_LIBRARY_PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTUP_TOOLCHAIN')}
def invoke(argv, marker=None):
    proc_env=env.copy()
    if marker:proc_env['OHM_STAGE2_PRIVATE_PROOF']=str(out/marker)
    argv=list(map(str,argv));commands.append(argv);process=subprocess.run(argv,cwd=out,env=proc_env,capture_output=True,text=True);(out/'commands.log').open('a').write('$ '+' '.join(argv)+'\n'+process.stdout+process.stderr);process.check_returncode()
    if marker:assert (out/marker).read_text()=='10404'
    return process.stdout
rustc=installed/'bin/rustc';rustdoc=installed/'bin/rustdoc';invoke([rustc,'--edition=2024','--crate-type=proc-macro','--crate-name=host_macro',macro,'-o',dll]);extern='host_macro='+str(dll)
invoke([rustc,'--edition=2024','--extern',extern,consumer,'-o',exe],marker='rustc-macro-actual.txt');assert invoke([exe]).strip()=='10404';invoke([rustdoc,'--edition=2024','--crate-name=consumer','--extern',extern,consumer,'-o',out/'docs'],marker='rustdoc-macro-actual.txt');assert (out/'docs/consumer/constant.PAIRS.html').is_file()
# Confirm that the loaded host macro actually contains the selected implementation.
symbols=subprocess.check_output(['nm','-S','--defined-only',dll],text=True);rows=[line.split() for line in symbols.splitlines() if 'compare_components' in line and '.cold' not in line];rows=[v for v in rows if len(v)==4 and v[2].lower()=='t'];assert rows
sym=max(rows,key=lambda r:int(r[1],16));addr,length=int(sym[0],16),int(sym[1],16);listing=subprocess.check_output(['objdump','-d',f'--start-address={addr}',f'--stop-address={addr+length}',dll],text=True);(out/'proc-macro-compare.asm').write_text(listing);word=bool(re.search(r'\b(?:tzcnt|bsf)\w*\b',listing));assert word==(arm=='guard')
def sha(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
receipt={'arm':arm,'sysroot':str(installed),'package_sha256':sha(installed/'ohm-matched-ready.json'),'macro_source_sha256':sha(macro),'consumer_source_sha256':sha(consumer),'macro_dylib_sha256':sha(dll),'target_program_sha256':sha(exe),'host_macro_compare':{'symbol':sym[3],'bytes':length,'word_mismatch_bit_scan':word},'real_proc_macro_expansion_pairs':{'rustc':10404,'rustdoc':10404},'native_program_stdout':'10404','commands':commands};dest=out/'ready.json';pending=dest.with_suffix('.pending');pending.write_text(json.dumps(receipt,indent=2)+'\n');pending.replace(dest);print(sha(dest))
