"""Materialize the remaining coordinator gitlinks and fetch the locked host Rust workspaces."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
import json,os,shutil,subprocess
from pathlib import Path
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';src=root/'src';d=root/'downloads';r=root/'receipts';manifest=json.loads((root/'manifest.json').read_text());co='885faf0af725074adc31080a1c732c60965d8bbe';gh='/home/dev-user/.local/bin/gh-auto';route='/home/dev-user/code/oss/relic';h='x86_64-unknown-linux-gnu';backup=root/'coordinator-overlay-original';backup.mkdir(exist_ok=True)
def api(repo,key,raw=False):return subprocess.check_output([gh,'api',f'repos/{repo}/{key}']+(['-H','Accept: application/vnd.github.raw+json'] if raw else []),cwd=route)
def freeze(name):
 info=manifest['sources'][name];repo=info['repository'].removeprefix('https://github.com/');sha=info['revision'];arc=d/(name+'-'+sha+'.tar.gz');p=src/'src/tools'/name
 if not arc.exists():
  with arc.with_suffix('.partial').open('wb') as f:subprocess.run([gh,'api',f'repos/{repo}/tarball/{sha}'],cwd=route,stdout=f,check=True)
  arc.with_suffix('.partial').rename(arc)
 if not (backup/name).exists():p.rename(backup/name);p.mkdir();subprocess.run(['tar','-xzf',arc,'--strip-components=1','-C',p],check=True)
 with arc.open('rb') as f:digest=file_digest(f,'sha256').hexdigest()
 return {'component':name,'revision':sha,'sha256':digest,'archive':str(arc)}
with ThreadPoolExecutor(2) as ex:logs=list(ex.map(freeze,['clippy','rustfmt']))
(r/'coordinator-overlays.json').write_text(json.dumps(logs,indent=2)+'\n');(root/'release-build.sh').write_bytes(api('astral-sh/ohm','contents/scripts/build-optimized-dist.sh?ref='+co,True));(root/'release-workflow.yml').write_bytes(api('astral-sh/ohm','contents/.github/workflows/release.yml?ref='+co,True));
for name,tree in [('rust',src),('cargo',src/'src/tools/cargo')]:
 pin=manifest['sources'][name]['revision'];repo=manifest['sources'][name]['repository'].removeprefix('https://github.com/');commit=json.loads(api(repo,'git/commits/'+pin));(tree/'git-commit-info').write_text(pin+'\n'+pin[:9]+'\n'+commit['committer']['date'][:10]+'\n')
ch=root/'cargo-home';ch.mkdir(mode=0o700,exist_ok=True);env={**os.environ,'CARGO_HOME':str(ch),'PATH':str(root/'stage0/bin')+':'+os.environ['PATH'],'RUSTC':str(root/'stage0/bin/rustc'),'CARGO_NET_RETRY':'3','RUSTC_BOOTSTRAP':'1'}
for name,mp in [('bootstrap',src/'src/bootstrap/Cargo.toml'),('library',src/'library/Cargo.toml'),('rust',src/'Cargo.toml')]:
 receipt=r/(name+'-fetch.json');
 if receipt.exists():continue
 cmd=[str(root/'stage0/bin/cargo'),'fetch','--locked','--target',h,'--manifest-path',str(mp)];
 with (r/(name+'-fetch.log')).open('wb') as log:subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 (r/(name+'-fetch.json')).write_text(json.dumps({'command':cmd,'CARGO_HOME':str(ch),'workspace':str(mp),'success':True},indent=2)+'\n')
print('Source overlays and pinned host Cargo dependencies verified.',flush=True)
