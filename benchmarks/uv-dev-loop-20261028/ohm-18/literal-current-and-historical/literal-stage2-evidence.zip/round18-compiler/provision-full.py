"""Stage immutable Ohm sources and verified bootstrap tools without running a build."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json,os,re,shutil,subprocess,tarfile,urllib.request
from pathlib import Path
lab=Path(__file__).resolve().parent;root=lab/'full-toolchain';root.mkdir(exist_ok=True);src=root/'src';downloads=root/'downloads';receipts=root/'receipts';downloads.mkdir(exist_ok=True);receipts.mkdir(exist_ok=True);gh='/home/dev-user/.local/bin/gh-auto';route='/home/dev-user/code/oss/relic';rust='a4fa11bcd38280639cb94daacc125472657db6c3';host='x86_64-unknown-linux-gnu';co='885faf0af725074adc31080a1c732c60965d8bbe';cargo='7caf39914da1e28a67744ecbc963a5f26361474d'
def api(path,raw=False):return subprocess.check_output([gh,'api',path]+(['-H','Accept: application/vnd.github.raw+json'] if raw else []),cwd=route)
def sha(path):
 h=sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1<<21),b''):h.update(block)
 return h.hexdigest()
def get(url,path,expected=None):
 if not path.exists():
  tmp=path.with_name(path.name+'.partial')
  with urllib.request.urlopen(url,timeout=90) as response,tmp.open('wb') as f:shutil.copyfileobj(response,f,1024*1024)
  if expected and sha(tmp)!=expected:raise ValueError('bad downloaded digest: '+str(tmp))
  tmp.rename(path)
 digest=sha(path)
 if expected and digest!=expected:raise ValueError('bad saved digest: '+str(path))
 return {'url':url,'path':str(path),'bytes':path.stat().st_size,'sha256':digest}
node=json.loads(api('repos/astral-sh/ohm-rust/git/commits/'+rust)); (receipts/'rust-commit.json').write_text(json.dumps({k:node[k] for k in ['sha','tree','parents','committer']},indent=2)+'\n');(root/'release-bootstrap.toml').write_bytes(api('repos/astral-sh/ohm/contents/release/bootstrap.toml?ref='+co,True));(root/'stage0.txt').write_bytes(api('repos/astral-sh/ohm-rust/contents/src/stage0?ref='+rust,True));(root/'manifest.json').write_bytes(api('repos/astral-sh/ohm/contents/toolchains/1.99.0/18.json?ref='+co,True))
assert json.loads((root/'manifest.json').read_text())['sources']['rust']['revision']==rust
stage=dict(line.split('=',1) for line in (root/'stage0.txt').read_text().splitlines() if '=' in line and not line.startswith('#'));ver=stage['compiler_version']; commands=[]
def stages():
 components=['rustc','cargo','rust-std'];files=[f"dist/{stage['compiler_date']}/{tool}-{ver}-{host}.tar.xz" for tool in components]
 with ThreadPoolExecutor(3) as ex:logs=list(ex.map(lambda fn:get(stage['dist_server']+'/'+fn,downloads/Path(fn).name,stage[fn]),files))
 (receipts/'stage0-downloads.json').write_text(json.dumps(logs,indent=2)+'\n');unpack=root/'stage0-unpacked';unpack.mkdir(exist_ok=True);prefix=root/'stage0';
 for log in logs:
  p=Path(log['path']);component=unpack/p.name.removesuffix('.tar.xz');tool=p.name.split('-'+ver)[0]; done=receipts/('installed-'+tool)
  if not done.is_file():
   subprocess.run(['tar','-xf',p,'-C',unpack],check=True);cmd=[str(component/'install.sh'),'--prefix='+str(prefix),'--disable-ldconfig'];subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL);done.write_text(json.dumps(cmd)+'\n')
 for tool in ('rustc','cargo'):(receipts/(tool+'-stage0-version.txt')).write_bytes(subprocess.check_output([prefix/'bin'/tool,'-Vv']))
def sources():
 archive=downloads/('ohm-rust-'+rust+'.tar.gz')
 if not archive.exists():
  tmp=archive.with_suffix('.partial');
  with tmp.open('wb') as f:subprocess.run([gh,'api','repos/astral-sh/ohm-rust/tarball/'+rust],cwd=route,stdout=f,check=True)
  tmp.rename(archive)
 if not src.exists():
  src.mkdir();subprocess.run(['tar','-xf',archive,'--strip-components=1','-C',src],check=True)
 crate=src/'src/tools/cargo';p=lab.parent/'upstream-monitor/cargo/base-7caf399.tar.gz';assert p.is_file()
 if not (crate/'Cargo.toml').is_file():crate.mkdir(exist_ok=True,parents=True);subprocess.run(['tar','-xf',p,'--strip-components=1','-C',crate],check=True)
 library=src/'library';shipped=next((lab.parent/'upstream-monitor/download18').glob('rust-*/rust-src/lib/rustlib/src/rust/library'));backtrace=library/'backtrace';backtrace.mkdir(exist_ok=True)
 if not (backtrace/'Cargo.toml').exists():shutil.copytree(shipped/'backtrace',backtrace,dirs_exist_ok=True,symlinks=True)
 assert sha(library/'std/src/path.rs')=='a41beffcf2ecd2b331c71cc7d6d2e7ca18f85e613106abee770821dd0e53be14'
 (receipts/'source-materials.json').write_text(json.dumps({'rust_commit':rust,'rust_tree':node['tree']['sha'],'rust_source_archive_sha256':sha(archive),'cargo_commit':cargo,'cargo_archive_sha256':sha(p),'shipped_component_backtrace_source':str(shipped/'backtrace'),'library_path_sha256':sha(library/'std/src/path.rs')},indent=2)+'\n')
with ThreadPoolExecutor(2) as ex:
 futures=[ex.submit(stages),ex.submit(sources)]
 for f in futures:f.result()
print('source and stage0 verified',flush=True)
