from pathlib import Path
import json,subprocess,tarfile
root=Path(__file__).resolve().parent/'full-toolchain';p=root/'receipts/llvm-source.json';m=json.loads(p.read_text());archive=next((root/'downloads').glob('llvm-project-*.tar.gz'));tree=Path(m['tree']);
if 'libc' not in m['subtrees']:
 with tarfile.open(archive) as f:name=next(iter(f)).name
 subprocess.run(['tar','-xzf',archive,'--strip-components=1','-C',tree,name+'/libc'],check=True);m['subtrees'].append('libc');p.write_text(json.dumps(m,indent=2)+'\n')
