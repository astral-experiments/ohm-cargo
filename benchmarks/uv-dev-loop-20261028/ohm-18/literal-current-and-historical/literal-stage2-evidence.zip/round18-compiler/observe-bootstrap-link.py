"""Read only this private bootstrap's long-lived final compiler linker processes on the ordinary host."""
import argparse,json,os,re,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('arm',choices=('base','guard'));args=p.parse_args();root=(Path(__file__).resolve().parent/'full-toolchain');worker=root/'bootstrap-worker.json';record=json.loads(worker.read_text());assert record['arm']==args.arm and record['status']=='running';attempt=Path(record['attempt']);out=attempt/'link-processes';out.mkdir();saved={};assert os.geteuid()!=0 and Path('/proc/1/comm').read_text().strip()=='systemd'
while True:
    for entry in os.scandir('/proc'):
        if not entry.name.isdecimal():continue
        proc=Path(entry.path)
        try:
            exe=Path(os.readlink(proc/'exe'));name=exe.name
            if not (name in ('cc','collect2','rust-lld','ld.lld','rustc_codegen_llvm') or re.fullmatch(r'(?:[\w-]+-)?(?:g?cc|gcc|clang)(?:-[0-9.]+)?',name)):continue
            cwd=Path(os.readlink(proc/'cwd'))
            if not cwd.is_relative_to(root):continue
            started=(proc/'stat').read_text().rsplit(')',1)[1].split()[19];key=(entry.name,started,str(exe))
            if key in saved:continue
            vec=[os.fsdecode(x) for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
        except (OSError,ValueError,IndexError):continue
        if not vec:continue
        response={}
        for arg in vec:
            if not arg.startswith('@'):continue
            rp=Path(arg[1:]);rp=rp if rp.is_absolute() else cwd/rp
            if not rp.is_relative_to(root):continue
            try:
                if rp.stat().st_size<30_000_000:response[str(rp)]=rp.read_bytes()
            except OSError:continue
        joined=' '.join(vec)+' '+ ' '.join(v.decode(errors='replace') for v in response.values())
        if not re.search(r'(?:/|^)librustc_driver-[0-9a-f]+\.so\b',joined):continue
        child=f'{entry.name}-{name}';rsp={}
        for i,(path,data) in enumerate(response.items()):
            dst=out/f'{child}-{i}.rsp';dst.write_bytes(data);rsp[path]=str(dst)
        captured={'pid':int(entry.name),'start_ticks':started,'exe':str(exe),'cwd':str(cwd),'argv':vec,'relevant_response_files':rsp,'time_ns':time.time_ns()};dst=out/(child+'.json');dst.write_text(json.dumps(captured,indent=2)+'\n');saved[key]=str(dst)
    state=json.loads(worker.read_text())
    if state['attempt']!=str(attempt) or state['status']!='running':break
    time.sleep(.25)
(out/'complete.json').write_text(json.dumps({'arm':args.arm,'bootstrap_status':state['status'],'captured':list(saved.values())},indent=2)+'\n')
