"""Stage the exact recorded Ohm Rust LLVM gitlink for the compiler build fallback."""
from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent/'full-toolchain';source=root/'src/src/llvm-project';downloads=root/'downloads';receipts=root/'receipts';gh='/home/dev-user/.local/bin/gh-auto';route='/home/dev-user/code/oss/relic';rust='a4fa11bcd38280639cb94daacc125472657db6c3';link=json.loads(subprocess.check_output([gh,'api',f'repos/astral-sh/ohm-rust/contents/src/llvm-project?ref={rust}'],cwd=route));rev=link['sha'];assert rev=='1b9c0d5ff9bbe7634aead059efe6b11a7eeba145';archive=downloads/('llvm-project-'+rev+'.tar.gz')
if not archive.is_file():
 tmp=archive.with_suffix('.partial')
 with tmp.open('wb') as f:subprocess.run([gh,'api',f'repos/rust-lang/llvm-project/tarball/{rev}'],cwd=route,stdout=f,check=True)
 tmp.rename(archive)
subtrees=['cmake','compiler-rt','libunwind','lld','llvm','third-party'];source.mkdir(exist_ok=True)
with tarfile.open(archive) as t:top=next(iter(t)).name
if not (receipts/'llvm-source.json').exists():
 subprocess.run(['tar','-xzf',archive,'--strip-components=1','-C',source,*[top+'/'+p for p in subtrees]],check=True)
 with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 (receipts/'llvm-source.json').write_text(json.dumps({'ohm_rust_commit':rust,'submodule':link['html_url'],'gitlink':rev,'archive_sha256':digest,'bytes':archive.stat().st_size,'subtrees':subtrees,'tree':str(source)},indent=2)+'\n')
print('Exact LLVM source ready.',flush=True)
