"""Run exact-source Ninja stages on the assigned cores, stopping the entire process group at the gate."""
from datetime import datetime,timezone
from pathlib import Path
import json,os,signal,subprocess,sys,time
root=Path(__file__).resolve().parent/'full-toolchain';rec=root/'receipts';build=root/'sdk-build';stop=root/'sdk-stop';deadline=datetime.fromisoformat(sys.argv[1]).timestamp();assert os.sched_getaffinity(0)==set(range(16,24));assert time.time()<deadline;tag=datetime.now(timezone.utc).strftime('%H%M%S');out=rec/('sdk-window-'+tag);out.mkdir();(out/'controller.pid').write_text(str(os.getpid())+'\n')
def record(s):
 tmp=out/'status.tmp';tmp.write_text(json.dumps(s,indent=2)+'\n');tmp.replace(out/'status.json')
# The earlier configure runs pinned to CPUs 0-3; this controller owns only Ninja jobs.
while not (rec/'configs.json').exists():
 if stop.exists() or time.time()>=deadline:record({'status':'stopped awaiting config'});sys.exit(0)
 if (rec/'sdk-cmake.log').exists() and 'Configuring incomplete' in (rec/'sdk-cmake.log').read_text():raise RuntimeError('CMake configure failed')
 time.sleep(0.6)
state={'cutoff':sys.argv[1],'cpus':list(range(16,24)),'jobs':8,'commands':[]};active=None
def signalstop(*_):stop.touch()
signal.signal(signal.SIGTERM,signalstop);signal.signal(signal.SIGINT,signalstop)
for name,targets in [('headers',['llvm-config','llvm-headers']),('llvm',['LLVM','lld'])]:
 if name=='llvm' and (root/'prefer-release-dylib').is_file():break
 if stop.exists() or time.time()>=deadline:state['status']='stopped';record(state);break
 cmd=['ninja','-C',str(build),'-j8',*targets];info={'name':name,'command':cmd,'started':datetime.now(timezone.utc).isoformat()};state['commands'].append(info);state['status']='running';record(state)
 with (out/(name+'.log')).open('wb') as f:
  active=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);info['pgid']=active.pid;record(state)
  while active.poll() is None and not stop.exists() and time.time()<deadline:time.sleep(1)
  stopped=active.poll() is None
  if stopped:
   os.killpg(active.pid,signal.SIGINT)
   try:active.wait(timeout=7)
   except subprocess.TimeoutExpired:
    os.killpg(active.pid,signal.SIGTERM)
    try:active.wait(timeout=4)
    except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
  info['exit']=active.returncode;info['ended']=datetime.now(timezone.utc).isoformat();state['status']=('stopped' if stopped else 'failed' if active.returncode else 'ready-'+name);record(state)
  if stopped:break
  if active.returncode:raise SystemExit(active.returncode)
print(state['status'],out,flush=True)
