import hashlib,json,mmap,sys
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));from elf import secs
def read(x):return json.loads(x.read_text())
def canon(file):
 with file.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
  st=secs(m);_,note,_=next(r for r in st if r[0]=='.note.gnu.build-id');_,r,sh=next(r for r in st if r[0]=='.rodata');a=note[4]+16;spans=[(a,a+32),(sh+56,sh+64)];h=hashlib.sha256();end=0
  for i,k in sorted(spans):h.update(memoryview(m)[end:i]);h.update(bytes(k-i));end=k
  h.update(memoryview(m)[end:]);return h.hexdigest()
results={}
for k in map(str,range(5)):
 d=read(p/'replays'/(k+'-summary.json'));s0=d['rows'][k+'-shipped-0'];s7=d['rows'][k+'-shipped-7'];a=d['each_arm_AA']['shipped'];assert d['each_arm_AA']['pr46']==a and all(not v for v in d['same_setting_cross_arm'].values())
 assert s0['elf']['bytes']==s7['elf']['bytes'];diff=[v for v in a if not v['build_id_payload']];assert len(diff)<=1 and all(row['section_header_at']==[['.rodata',56]] for row in diff)
 c1=canon(p/'replays'/(k+'-shipped-0.elf'));c2=canon(p/'replays'/(k+'-shipped-7.elf'));assert c1==c2
 results[k]={'product':s0['original_product'],'bytes':s0['elf']['bytes'],'original':s0['original_sha256'],'one_slot':s0['elf']['sha256'],'eight_slots':s7['elf']['sha256'],'single_entsize':s0['elf']['sh_entsize']['.rodata'],'multi_entsize':s7['elf']['sh_entsize']['.rodata'],'all_four_canonical_sha256':c1,'exact_differing_bytes':len(a),'non_buildid':diff,'all_rows_match_between_binaries_at_each_setting':True}
assert results['2']['all_four_canonical_sha256']=='f804714723ffc4494f58c757fc2b3e00a650c5a3193482e37c2853142c13f4c3';j={'all_role_summaries':results,'stock_settings':'Unchanged actual linker argv; zero or seven physical extras on an inherited GNU jobserver pipe, same ELF interpreter checked from original capture, no explicit --threads or fork overrides, original bytes returned. All child processes pinned to CPUs 0–3. Eight slots describes jobserver availability, not number of physical cores used.','canonicalization':'Zero only .note.gnu.build-id descriptor bytes and the entire 8-byte .rodata section-header sh_entsize field. Byte-level before/after audit included for every tested arm, so this canonical identity does not mask any other change.','parked':read(p/'parked.json')['exact_parked']};(p/'summary.json').write_text(json.dumps(j,indent=2)+'\n')
print([(k,v['bytes'],v['single_entsize'],v['multi_entsize'],v['exact_differing_bytes']) for k,v in results.items()])
