# Which edited Ohm -18 uv products reproduce the stock ELF metadata variation?

An actual second fixture produced two digests of the 1,068,096-byte uvx test harness. We compared all four parked files and replayed all five real captured links, once per unchanged linker and physical jobserver setting. No native benchmark target, compiler, or linker slot was modified. The shipped linker and frozen #46 each reproduced the two exact parked uvx harness digests.

| Captured link | Bytes | GNU jobserver offers 0 extras | Offers 7 extras | Changed bytes |
| --- | ---: | ---: | ---: | ---: |
| uv lib/test harness | 181,196,328 | 8 | 0 | 33 |
| uv executable | 316,558,984 | 0 | 8 | 33 |
| uvx test harness | 1,068,096 | 0 | 8 | 33 |
| uv binary test harness | 10,398,144 | 8 | 0 | 33 |
| uvx executable | 646,640 | 0 | 0 | 0 |

The middle columns are `.rodata.sh_entsize` values. The 33 bytes comprise the low byte of this ELF64 section-header field and all 32 GNU build-ID descriptor bytes. Both unchanged linkers produced the same complete file at each same setting. The uvx harness's section-header byte sits at file offset 1,066,232, outside every PT_LOAD segment. All four uvx harness files have identical program-header bytes and 63,377-byte `.rodata` contents. The GNU identity note is observable metadata inside PT_NOTE and the read-only PT_LOAD, and every harness prints the same `0 tests, 0 benchmarks` with `--list`. No tests were run.

The change is consistent with the existing linker group merge. Group-local section attributes clear mixed input entry sizes, then ELF section attribute propagation assigns the last group's value. The real jobserver offers different grouping widths while the input set and linker binary stay fixed. This evidence supports only the four demonstrated products, exact 0/8 `.rodata` field, and their dependent GNU note. No masker is needed for a fixed-setting candidate/control comparison because the output pairs were byte-identical.

`summary.json` contains full SHA-256s, ELF byte counts, canonical hashes and the single non-build-ID offset for each shape. `replays/*-summary.json` independently enumerates every differing byte in both per-binary A/A comparisons and both same-setting cross-binary comparisons. The per-run JSON pins input argv, binary and output digests, exact physical tokens returned, and CPU affinity. All replays used the actual argv, default fork, no explicit thread override, and all processes bound to CPUs 0–3; a populated jobserver is distinct from physical core availability. The independent input manifest and saved argv live under `../round18-linker/confirm18`.

Run `python3 replay.py 2 4 3 0 1` with the original capture tree and matching binaries. Run `python3 summarize.py` and `python3 semantics.py` to recompute every complete-file comparison and inspect the uvx harness ELF and listing. The compact archive includes raw audit receipts and source, omitting the large full ELF captures. The parked and replayed raw ELFs remain in this local study directory.
