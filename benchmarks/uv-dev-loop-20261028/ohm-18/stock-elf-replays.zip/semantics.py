from pathlib import Path
import json,struct,subprocess,sys
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p));from elf import secs,info,sha
rows={}
for k in ('2-shipped-0','2-shipped-7','2-pr46-0','2-pr46-7'):
 f=p/'replays'/(k+'.elf');b=f.read_bytes();ss=secs(b);rr=next(x for x in ss if x[0]=='.rodata');v=rr[1];phoff=struct.unpack_from('<Q',b,32)[0];size,num=struct.unpack_from('<HH',b,54);pg=b[phoff:phoff+size*num]
 note=info(b)['build_id_offset'];overlaps=[]
 for i in range(num):
  t,flags,pos,va,pa,z,ms,al=struct.unpack_from('<IIQQQQQQ',pg,i*size)
  if pos<=note<pos+z:overlaps.append({'program_header':i,'p_type':t,'flags':flags})
 fpos=rr[2]+56;outer=any(z[0]==1 and z[2]<=fpos<z[2]+z[5] for z in (struct.unpack_from('<IIQQQQQQ',pg,i*size) for i in range(num)))
 l=subprocess.run([f,'--list'],capture_output=True,timeout=8);(p/'replays'/(k+'-list.stdout')).write_bytes(l.stdout);(p/'replays'/(k+'-list.stderr')).write_bytes(l.stderr)
 rows[k]={'program_header_table_sha256':sha(pg),'rodata_payload_sha256':sha(b[v[4]:v[4]+v[5]]),'rodata_bytes':v[5],'rodata_flags':v[2],'rodata_type':v[1],'entsize_header_inside_PT_LOAD':outer,'note_in_program_headers':overlaps,'list_status':l.returncode,'list_stdout':l.stdout.decode(),'list_stderr':l.stderr.decode()}
assert all(v==next(iter(rows.values())) for v in rows.values());(p/'semantics.json').write_text(json.dumps(rows,indent=2)+'\n');print(next(iter(rows.values())))
