# One rustc frontend thread for a warm, edited uvx binary

On the Ohm 1.99.0-18 Linux x86-64 release, the original rustc commands compiled this small edited binary 38–44 ms faster at one frontend thread than at eight. All three compiler roles passed their prespecified elapsed gate in two independently warmed uv checkouts. These direct measurements select a whole-Cargo experiment. They do not measure the elapsed time of an unwrapped `cargo build` or `cargo test --no-run`. Test preparation can run its two compiler roles concurrently.

| Actual released compiler role | First edit, paired median saved | Second edit, paired median saved | Foreground rustc instructions saved, first / second |
| --- | ---: | ---: | ---: |
| Ordinary binary in build | 43.68 ms (23.65%) | 41.96 ms (23.17%) | 13.39% / 13.24% |
| Ordinary binary in test preparation | 40.61 ms (22.87%) | 39.72 ms (22.24%) | 13.37% / 13.19% |
| Test harness in test preparation | 42.75 ms (27.66%) | 38.44 ms (25.68%) | 18.47% / 18.94% |

Each elapsed cell kept all 48 paired commands. Each count cell kept all eight pairs. Percentages are paired savings. `results.csv` includes rank intervals, order-conditioned randomization p values and win counts. Elapsed is the foreground stock rustc invocation from launch through its normal return and includes its wait for the stock linker. Every run subsequently recovered the same seven physical jobserver permits and confirmed no live owned process remained. DynamoRIO counts user-mode instructions in the foreground rustc process across all of its threads and excludes the linker, Cargo and kernel instructions. The eight count pairs diagnose compiler work. Native time sets the promotion gate.

Each checkout used one genuine edit shape with a fresh five-character tag per block. Admission and postflight required identical raw executable and depfile bytes across arm outputs at a common active path, then checked the actual produced program or listed the harness outside timing. `gate-breakdown.json` records every role requirement. `observer-summary.json` retains the physical and per-thread observer rollups. The full inputs and zero-row premeasurement observer amendment are under `work/`.

## Rescore the original result

Use Python 3.12 and NumPy (the original used 2.3.5). A clean extraction outside the recorded workspace and benchmark tree exercises the syscall audit boundary. The replay reads packet members and its installed Python/NumPy runtime, and rejects subprocess launches and access to the original host paths.

```sh
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python3 portable.py --deny-recorded-host
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python3 fresh-selftest.py
```

The first rescorer reconstructs the original 576 foreground elapsed rows, 96 per-thread instruction rows and 768 observer closures from raw argument, source, log and jobserver evidence. It reruns the original order-conditioned median randomization and verifies that the six role gates and summary artifacts match. For new measurements on a separate checkout and toolchain prefix, follow [the fresh-host procedure](FRESH-HOST.md). The archive includes the release binaries' SHA-256 identities and excludes build products and binaries.

The first supplementary host-return verifier compared the random path in a temporary-directory diagnostic literally. Its original rejection and verifier are preserved alongside the subsequent successful verifier and physical return. The frozen product verification accepted every pre/post ELF, depfile and current-behavior check. The separate count host-return receipt binds the earlier native return.
