"""Reproduce the owning-module scan from the authenticated current refs and cached source blobs."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import re

here=Path(__file__).resolve().parent
old=here.parents[1]/"upstream-monitor/cargo-history"
index=json.loads((old/"source-index.json").read_text())
branches=[json.loads(line) for line in (here/"current-branches.jsonl").read_text().splitlines()]
mapping={sha:row.get("blobs",{}).get("compiler") for sha,row in index["refs"].items()}
mapping.update({sha:row["compiler_blob"] for sha,row in json.loads((here/"new-branch-source.json").read_text()).items()})
blobs={}
for sha in sorted(set(mapping.values())-{None}):
    raw=gzip.decompress((old/"blobs"/(sha+".rs.gz")).read_bytes())
    assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==sha
    body=raw.decode()
    flagged=sorted(set(re.findall(r"(?:-Z)?threads\s*=\s*[^\s\"']+",body)))
    assert set(flagged)<={"-Zthreads=1","-Zthreads=8"}, (sha,flagged)
    sites=[]
    for m in re.finditer(r"-Zthreads=1(?!\d)",body):
        before=body[max(0,m.start()-900):m.start()]
        region=before[before.rfind("if cfg!"):]
        assert "matches!(unit.mode, CompileMode::Check { test: false })" in region
        assert "CompileMode::Build" not in region and "CompileMode::Test" not in region
        sites.append("small-check-only")
    blobs[sha]={"flags":flagged,"serial_sites":sites}
result={"current_count":len(branches),"historic_source_count":len(index["refs"]),
        "current_source_branches":sum(bool(mapping[b["sha"]]) for b in branches),"compiler_blobs":blobs,"new_uncached":[],
        "current_branches":{b["name"]:mapping[b["sha"]] for b in branches}}
assert result==json.loads((here/"existing-branch-scan.json").read_text())
print(len(branches),result["current_source_branches"],len(blobs),sum(len(v["serial_sites"]) for v in blobs.values()))
