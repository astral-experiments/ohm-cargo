"""Read the frozen shipped uvx traces and the exact released fingerprint files only."""
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
LAB = WORK / 'round18-lab'
plan = json.loads((LAB/'registered-uvx.json').read_text())
trace_set = {}
for cohort in ('initial','replica'):
    cohort_dir = LAB/'r18-uvx'/cohort
    info = json.loads((cohort_dir/'inputs.json').read_text())
    canonical = Path(info['target'])
    parked = Path(plan['cohorts'][cohort]['root']) / plan['target_pool'] / 'shipped'
    prefix = 'execve(' + json.dumps(info['compiler']) + ', '
    for endpoint in ('check','build','test'):
        for stage in ('admission','post'):
            case = cohort_dir/endpoint/(stage+'-shipped')
            rows = []
            for receipt in sorted(case.glob('exec.*')):
                raw = receipt.read_bytes()
                for line in raw.decode(errors='replace').splitlines():
                    if not line.startswith(prefix) or not line.endswith('= 0'):
                        continue
                    argv, _ = json.JSONDecoder().raw_decode(line[len(prefix):])
                    if '--crate-name' not in argv or argv[argv.index('--crate-name')+1] != 'uvx':
                        continue
                    out = Path(argv[argv.index('--out-dir')+1]); assert out.name == 'out'
                    harness = '--test' in argv
                    dep = parked/out.relative_to(canonical).parent/'fingerprint'/('dep-test-bin-uvx' if harness else 'dep-bin-uvx')
                    head = dep.read_bytes(); assert stat.S_ISREG(dep.stat().st_mode)
                    options = [a.split('=',1)[1] for a in argv if a.startswith('-Zthreads=')]
                    options += [v.split('=',1)[1] for i,v in enumerate(argv) if i and argv[i-1] == '-Z' and v.startswith('threads=')]
                    libs = {Path(v.partition('=')[2]) for i,v in enumerate(argv) if i and argv[i-1]=='--extern' and v.startswith('uv=')}
                    hints = []
                    for lib in sorted({f.parent for f in libs}):
                        info_file = parked/lib.relative_to(canonical).parent/'fingerprint'/'dep-lib-uv'
                        if info_file.is_file():
                            hints.append({'path':str(info_file),'bytes':info_file.stat().st_size})
                    rows.append({'raw':str(receipt.relative_to(WORK)),'raw_sha256':hashlib.sha256(raw).hexdigest(),
                                 'argv_sha256':hashlib.sha256(json.dumps(argv,separators=(',',':')).encode()).hexdigest(),
                                 'thread_flags':options,'harness':harness,'out':str(out),'dep_info':str(dep),
                                 'dep_info_bytes':len(head),'dep_info_sha256':hashlib.sha256(head).hexdigest(),
                                 'incremental':[a for a in argv if a.startswith('incremental=')],
                                 'emit':[a for a in argv if a.startswith('--emit=')], 'target':[argv[i+1] for i,a in enumerate(argv) if a=='--target'],
                                 'uv_lib_hints':hints})
            assert len(rows) == (2 if endpoint=='test' else 1), (cohort,endpoint,stage,len(rows))
            trace_set[f'{cohort}/{endpoint}/{stage}'] = rows
print(json.dumps(trace_set,indent=2,sort_keys=True))
