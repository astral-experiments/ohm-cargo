"""Write-once prospectively fixed orders and integrity seal. Never grants an actual run."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *

schedule={}
for label,size in (("direct-wall",48),("direct-count",8)):
    schedule[label]={c:{r:orders(DIRECT,size,0x19918000+1000*(label=="direct-count")+ci*100+ri)
                        for ri,r in enumerate(ROLES)} for ci,c in enumerate(COHORTS)}
schedule["normal"]={c:{ep:orders(NORMAL,480,0x19918600+ci*100+ei)
                       for ei,ep in enumerate(ENDPOINTS)} for ci,c in enumerate(COHORTS)}
schedule["risk"]=orders(NORMAL,24,0x19918700)
if __name__=="__main__":
    path=HERE/"schedule.json"
    if path.exists():
        require(read(path)==schedule,"previous assignment differs")
    else:
        save(path,schedule)
    deps=[HERE/s for s in ("study.py","direct.py","normal.py","controls.py","score.py","selftest.py",
                            "register.py","README.md","schedule.json")]
    deps+=[LAB/n for n in ("common.py","native-uvx.py","native-admitted.py","rlib_equivalence.py","elf_equivalence.py",
                           "stock-elf-forms.json","analyze.py","subsecond-design-calibration.json","calibrate-subsecond-walls.py")]
    deps+=[AUDIT/n for n in ("trace.py","scan-branches.py","current-branches.jsonl","new-branch-source.json","uvx-traces.json","existing-branch-scan.json","ohm-prs.json","ohm-pins.json",
                             "pin-blobs.json","pr251-benchmark.md")]
    deps += [WORK/"edit-link-profile/native-instrument/count.py",WORK/"round18-cargo/fast/base/ready.json",
             WORK/"round18-cargo/recipe/build-fast-v2.py",WORK/"dynamorio/README.md",WORK/"dynamorio/calibration.csv"]
    save(HERE/"registration.json",{"schema":1,"study":"ohm-18-small-frontend", "files":{str(f.relative_to(WORK)):sha(f) for f in deps},
         "original_uvx_sha256":sha(ORIGINAL),"grants_issued":False,
         "source_delta":"Cargo only. No candidate has been implemented or measured at registration.",
         "uv_git":"c22e6b71933443e9cd299d4b6ac8de035ed4825b","cargo_parent":"7caf39914da1e28a67744ecbc963a5f26361474d"})
