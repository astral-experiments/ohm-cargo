"""Only this direct observer entrypoint is eligible for fresh grants."""
import argparse
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import verifier
sys.path.insert(0,str(HERE))
import worker

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("wall","count","score","score-with-counts","check-seal"))
    parser.add_argument("cohort",nargs="?",choices=verifier.s.COHORTS)
    args=parser.parse_args()
    verifier.verify_seal()
    if args.action in ("wall","count"):
        verifier.s.require(args.cohort is not None,"missing cohort")
        verifier.direct.compile_once=worker.execute
        verifier.direct.RESULT=verifier.RESULT
        verifier.direct.authorized=verifier.authority
        verifier.score.direct_result=verifier.direct_result
        verifier.direct.run(args.action,args.cohort)
    elif args.action.startswith("score"):
        print(json.dumps(verifier.direct_result(args.action=="score-with-counts"),sort_keys=True,indent=2))
    else:
        print("Original and observer seals verified.")
