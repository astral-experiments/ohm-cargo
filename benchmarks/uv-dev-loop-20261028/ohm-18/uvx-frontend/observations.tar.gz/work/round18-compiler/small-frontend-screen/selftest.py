"""Source-only and synthetic protocol checks. Never invokes an actual executable."""
import ast
import collections
import sys
from unittest.mock import patch
from pathlib import Path
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *
import direct
import normal
import controls
import score
register=normal.load("small_frontend_orders", HERE/"register.py")


def rejected(fn):
    try:
        fn()
    except (ValueError,FileNotFoundError):
        return
    raise AssertionError("negative control was accepted")


def main():
    for f in HERE.glob("*.py"):
        ast.parse(f.read_text(), filename=str(f))
    original=ORIGINAL.read_bytes()
    require(len(original)==3984,"wrong uv revision")
    for c in COHORTS:
        for role in ROLES:
            a=direct.captured(c,role)
            root=fixture(c)
            b=direct.relocate(a,root,Path("/synthetic/active"),False,validate=False)
            h=direct.relocate(a,root,Path("/synthetic/active"),True,validate=False)
            require([x for x in h if x!="-Zthreads=1"]==b and controls.flags(b)==["8"] and controls.flags(h)==["8","1"],"not a sole flag delta")
            require(not any(str(root/"target")+"/" in x for x in b),"writable escaped path")
            rejected(lambda:direct.relocate(a+["--unknown",str(root/"target")+"/untouched"],root,Path("/synthetic/active"),False,validate=False))
        for ep in ENDPOINTS:
            one=changed(original,c,tag(c,ep,0))
            two=changed(original,c,tag(c,ep,479))
            require(one!=two and len(one)==len(two) and tag(c,ep,479).encode() in two,"unstable edit length")
            rejected(lambda:changed(b"no matching source",c,tag(c,ep,0)))
            data=register.schedule["normal"][c][ep]
            require(len(data)==480 and set(collections.Counter(map(tuple,data)).values())=={80},"orientation not balanced")
    for kind,n in (("direct-wall",48),("direct-count",8)):
        for c in COHORTS:
            for r in ROLES:
                require(list(sorted(collections.Counter(map(tuple,register.schedule[kind][c][r])).values()))==[n//2,n//2],
                        "direct orientation")
    heavy=controls.substantial()
    require(len(heavy.encode())>300*1024 and heavy.count("#[inline(never)]")==4096 and
            "OPS[(v as usize) & 4095](v)" in heavy,"not genuine live one-file control")
    assert controls.flags(["-Zthreads=8","-Zthreads=1","-Z","threads=4"])==["8","1","4"]
    source=original
    assert changed(source,"initial","EB000") != changed(source,"replica","VB000")
    require(len(orders(NORMAL,24,1))==24,"large-introduction fixture")
    # No measurements; purely synthetic six-permutation scorer controls.
    cells=orders(NORMAL,24,201)
    rows=[]
    for i,order in enumerate(cells):
        for rank,arm in enumerate(order):
            rows.append({"block":i,"rank":rank,"arm":arm,"elapsed_ns":100000000 if arm=="head" else 120000000+1000000*i,
                         "source_sha256":"synthetic"})
    blocks=score.assigned(rows,cells)
    s=score.compare(blocks,"base","head",369,draws=999)
    require(s["median_saved_ms"]==31.5 and s["one_sided_sign_p"]<.01 and
            s["raw_paired_median_one_sided_conditional_mc_p"]<.01,"positive scoring control")
    swapped=score.compare(blocks,"head","base",369,draws=999)
    require(swapped["median_saved_ms"]==-31.5 and swapped["raw_paired_median_one_sided_conditional_mc_p"]==1,
            "one-sided negative control")
    rejected(lambda:score.assigned(rows[:-1],cells))
    # With no per-phase grant, the gate must fail before opening a lease, hash-loading tools or allocating banks.
    with patch.dict(os.environ,{"SMALL_FRONTEND_GRANT_SHA256":""}),patch("study.verify_registration",return_value={}):
        rejected(lambda:authorized("direct-wall","initial",5).__enter__())
    return {"synthetic_only":True,"tools_launched":0,"frozen_real_argvs_checked":6,"normal_blocks_per_endpoint":480,
            "direct_wall_pairs_per_role":48,"direct_count_pairs_per_role":8,"live_source_bytes":len(heavy.encode()),
            "generated_reachable_functions":4096,"new_module_risk_blocks":24,
            "negative_controls":["unregistered output","unknown source","missing sample","adverse timing","no grant"]}


if __name__=="__main__":
    print(json.dumps(main(),sort_keys=True,indent=2))
