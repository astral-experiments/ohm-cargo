"""Postflight-only Linux physical custody record for the two completed direct wall grants."""
import fcntl
import hashlib
import json
import os
import re
from pathlib import Path
import sys
import time
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here))
import verifier as v
s=v.s
expected={"initial":("8b740af052dbbd943e32aa5bb14c87adfd3c1f6b771233961948491bcfde570e",96057),
          "replica":("7fc0b95c5daa4f2d20091bf33ebaf2a46a4bf864f3c350bb39742bd954528bfe",32306)}
releases={}
obs_values=[]
for cohort,(digest,session) in expected.items():
    issued=here/"grants"/("direct-wall-"+cohort+".json")
    assert s.sha(issued)==digest
    root=here/"observed/direct-wall"/cohort
    assert s.read(root/"done.json")=={"roles":list(s.ROLES),"mode":"wall","cohort":cohort}
    roles={}
    for name in s.ROLES:
        f=root/name
        assert (s.SCRATCH/"direct-wall"/cohort/name/"eight").is_dir() and (s.SCRATCH/"direct-wall"/cohort/name/"one").is_dir()
        assert not (s.SCRATCH/"direct-wall"/cohort/name/"active").exists()
        r=v.verify_role("wall",cohort,name)
        assert r["rows"]==96
        observers=[s.read(p) for p in f.glob("*.observer.json")]
        assert len(observers)==104 and all(o["accepted"] and o["foreground_exit"]==0 and o["final_token_count"]==7 and
            o["after_drain_available"]==0 and o["returned_tokens_hex"]==b"+++++++".hex() and not o["final_live_owned"] for o in observers)
        for phase,block in (("admit",992),("post",999)):
            products=s.read(f/(phase+"-products.json"))
            for arm,product in products.items():
                assert all(product[k]==products["eight"][k] for k in ("raw_sha256","size","dep_sha256"))
                x=product["behavior"]
                if cohort=="initial" and name!="test-harness":
                    tag=s.tag(cohort,"build" if name=="build-bin" else "test",block)
                    parent=s.SCRATCH/"direct-wall"/cohort
                    prefix=f"error: uvx could not launch uv [{tag}]: Could not find the `uv` binary at either of:"+chr(10)
                    assert x["stderr"].startswith(prefix) and x["exit"]==2 and not x["stdout"] and x["raw_sha256"]==product["raw_sha256"]
                    paths=x["stderr"][len(prefix):].splitlines()
                    assert len(paths)==2 and paths[0]==paths[1] and paths[0].startswith("  ")
                    uri=Path(paths[0][2:])
                    assert uri.name=="uv" and uri.parent.parent==parent and re.fullmatch("tmp[a-z0-9_]{8}",uri.parent.name)
                else:
                    assert x==products["eight"]["behavior"]
        roles[name]={"timed_rows":96,"timed_sha256":r["rows_sha256"],"observers":104,"role_returned":True,
              "argv_sha256":s.sha(f/"argv.json"),"admit_sha256":s.sha(f/"admit-products.json"),"post_sha256":s.sha(f/"post-products.json")}
        obs_values.extend(observers)
    releases[cohort]={"exec_session":session,"foreground_process_exit":0,"grant_sha256":digest,"closure_sha256":s.sha(root/"done.json"),"roles":roles}
all_pgids={o["pgid"] for o in obs_values}
owned_live=[]
unrelated_live_tools=[]
for p in Path("/proc").iterdir():
    if not p.name.isdecimal():continue
    try:stat=(p/"stat").read_text()
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    c=stat.rfind(")");comm=stat[stat.find("(")+1:c];tail=stat[c+2:].split()
    if tail[0] in ("Z","X"):continue
    if int(tail[2]) in all_pgids or int(tail[3]) in all_pgids:owned_live.append([int(p.name),comm])
    if comm in {"rustc","cargo","wild","ld.bfd","rust-lld","ld.lld","drrun","drconfig","valgrind","cachegrind"}:
        unrelated_live_tools.append([int(p.name),comm])
assert not owned_live and not unrelated_live_tools,(owned_live,unrelated_live_tools)
path=s.ROOT/"native-lease"
with path.open("r") as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fcntl.flock(lock,fcntl.LOCK_UN)
dist={str(rel):s.sha(s.DIST/rel) for rel in [Path("bin/cargo"),Path("bin/rustc"),s.LINK]}
for rel,h in dist.items():assert s.sha(s.TOOLS/rel)==h
assert (s.TOOLS/"bin/cargo").samefile(s.ROOT/"official-original-cargo") and (s.TOOLS/s.LINK).samefile(s.ROOT/"official-original-wild")
sources={}
for cohort in s.COHORTS:
    root=s.fixture(cohort)/"uv"
    assert s.sha(root/s.SOURCE)==s.sha(s.ORIGINAL) and s.sha(root/"Cargo.lock")==s.sha(s.WORK/"uv"/"Cargo.lock")
    sources[cohort]={str(f):{"sha256":s.sha(f),"inode":f.stat().st_ino,"mtime_ns":f.stat().st_mtime_ns} for f in (root/s.SOURCE,root/"Cargo.lock")}
final={"host_returned":True,"unix_ns":time.time_ns(),"host_boot_id":Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
       "study_scope":"two direct wall grants; no counter or later stage authorized","observer_amendment_sha256":s.sha(here/"amendment.json"),
       "total_measured":576,"all_observer_commands":len(obs_values),"final_all_seven_permits":True,
       "final_no_owned_live_descendant":True,"live_recorded_pgids_or_sessions":owned_live,"live_active_compiler_linker_dbi":unrelated_live_tools,
       "native_lease_reacquired_then_released":True,"all_private_active_bank_names_absent":True,
       "released_tool_slots":dist,"original_source_and_lock":sources,
       "cohorts":releases,"first_supplemental_postflight_sha256":s.sha(here/"physical-host-return-first-rejection.json"),"postflight_implementation_sha256":s.sha(Path(__file__))}
s.save(here/"physical-host-return.json",final)
print(s.sha(here/"physical-host-return.json"))
