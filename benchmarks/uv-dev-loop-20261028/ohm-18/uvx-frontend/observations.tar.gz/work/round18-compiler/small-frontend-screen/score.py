"""Rescore raw, fixed schedules. A compiler timing is only a screen for whole-Cargo timing."""
import argparse
import statistics
import sys
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *
sys.path.insert(0, str(LAB))
import analyze


def assigned(rows, schedule):
    n = len(schedule[0])
    require(len(rows) == n * len(schedule), "missing or extra measurements")
    blocks = []
    for i, expected in enumerate(schedule):
        block = rows[i*n:i*n+n]
        require([r["arm"] for r in block] == expected and
                [int(r["rank"]) for r in block] == list(range(n)) and
                all(int(r["block"]) == i and int(r["elapsed_ns"]) > 0 for r in block) and
                len({r["source_sha256"] for r in block}) == 1, f"schedule drift at block {i}")
        blocks.append(block)
    return blocks


def median_p(blocks, control, head, seed, draws=99999):
    """Randomize treatment orientation conditional on the other arm and all position quotas."""
    import numpy as np
    strata = {}
    observed = []
    for rows in blocks:
        pair = [r for r in rows if r["arm"] in (control,head)]
        delta = int(pair[0]["elapsed_ns"]) - int(pair[1]["elapsed_ns"])
        positive_orientation = pair[0]["arm"] == control
        observed.append(delta if positive_orientation else -delta)
        key = tuple((i,r["arm"]) for i,r in enumerate(rows) if r["arm"] not in (control, head))
        strata.setdefault(key, []).append((delta, positive_orientation))
    model = []
    for items in strata.values():
        directions = np.array([1 if is_control else -1 for _,is_control in items])
        require(directions.sum() == 0, "not balanced within a third-arm position")
        model.append((np.array([x for x,_ in items],dtype=np.int64), directions))
    rng = np.random.default_rng(seed)
    counted = 0
    cutoff = statistics.median(observed)
    for offset in range(0, draws, 256):
        size = min(256, draws-offset)
        samples = []
        for deltas, directions in model:
            permuted = rng.permuted(np.tile(directions, (size,1)), axis=1)
            samples.append(permuted*deltas)
        counted += int((np.median(np.concatenate(samples,axis=1),axis=1) >= cutoff).sum())
    return (counted + 1)/(draws + 1)


def compare(blocks, control, head, seed, draws=99999):
    out = analyze.compare(blocks,control,head)
    out["raw_paired_median_one_sided_conditional_mc_p"] = median_p(blocks,control,head,seed,draws)
    positive = out["wins"] > out["losses"]
    out["one_sided_sign_p"] = out["exact_two_sided_sign_p"]/2 if positive else 1
    out["one_sided_conditional_direction_p"] = out["conditional_two_sided_p"]/2 if positive else 1
    out.pop("possible_assignments")
    out.pop("conditional_extreme")
    return out


def passes(r, direct):
    alpha = .05/3 if direct else .05/4
    return (r["median_saved_ms"] >= (8 if direct else 10) and r["median_saved_pct"] >= 1 and
            r["median_saved_ms_interval"]["lower"] > 0 and
            min(r["median_saved_pct_by_order"].values()) > 0 and
            r["raw_paired_median_one_sided_conditional_mc_p"] <= alpha and
            r["one_sided_sign_p"] <= .05 and r["one_sided_conditional_direction_p"] <= .05)


def direct_result(counts):
    schedules = read(HERE/"schedule.json")
    result = {}
    for ci, cohort in enumerate(COHORTS):
        result[cohort] = {}
        for ri, role in enumerate(ROLES):
            folder = RESULT/"direct-wall"/cohort/role
            require((folder/"post-products.json").is_file() and (folder/"admit-products.json").is_file() and
                    read(folder/"done.json")["sha256"] == sha(folder/"trial.jsonl"), "direct admission unfinished")
            rows = [json.loads(l) for l in (folder/"trial.jsonl").read_text().splitlines()]
            blocks = assigned(rows, schedules["direct-wall"][cohort][role])
            stats = compare(blocks,"eight","one",9100+ci*100+ri)
            cell = {"native": stats,"passed": passes(stats,True)}
            if counts:
                folder = RESULT/"direct-count"/cohort/role
                require((folder/"post-products.json").is_file() and (folder/"admit-products.json").is_file() and
                        read(folder/"done.json")["sha256"] == sha(folder/"trial.jsonl"), "count admission unfinished")
                rows = [json.loads(l) for l in (folder/"trial.jsonl").read_text().splitlines()]
                blocks = assigned(rows, schedules["direct-count"][cohort][role])
                deltas = []
                for block in blocks:
                    arms = {r["arm"]:r for r in block}
                    c, v = arms["eight"]["instructions"], arms["one"]["instructions"]
                    require(all(x["instructions"] == sum(x["threads"].values()) > 0 for x in block),
                            "missing per-thread count")
                    deltas.append(100*(c-v)/c)
                cell["count"] = {"pairs":len(deltas), "median_saved_pct":statistics.median(deltas),
                                 "positive_pairs":sum(d>0 for d in deltas),
                                 "interval":analyze.median_interval(deltas)}
            result[cohort][role] = cell
    selected = [r for r in ROLES if all(result[c][r]["passed"] for c in COHORTS)]
    # One strongly regressed active role blocks promotion even if the other role individually wins.
    harm = [(c,r) for c in COHORTS for r in ROLES
            if result[c][r]["native"]["median_saved_ms"] <= -5 and
            result[c][r]["native"]["median_saved_ms_interval"]["upper"] < 0]
    return {"cohorts":result, "replicated_roles":selected, "material_losses":harm,
            "eligible":bool(selected) and not harm, "includes_counts":counts}


def normal_result():
    import csv
    schedule = read(HERE/"schedule.json")["normal"]
    result = {}
    for ci,cohort in enumerate(COHORTS):
        result[cohort] = {}
        home=RESULT/"normal"/cohort
        require(read(home/"inputs.json")["registration_sha256"]==sha(HERE/"registration.json") and
                read(home/"returned.json")["source_sha256"]==sha(ORIGINAL),"unfinished native custody")
        for ei,ep in enumerate(ENDPOINTS):
            folder = RESULT/"normal"/cohort/ep
            require((folder/"admitted.json").exists() and read(folder/"done.json")["rows"] == sha(folder/"timings.csv"),
                    "normal pre/post receipt or complete timing digest missing")
            with (folder/"timings.csv").open() as f:
                blocks = assigned(list(csv.DictReader(f)),schedule[cohort][ep])
            original=read(folder/"admitted.json")
            last=read(folder/"done.json")["post"]
            for phase,records in (("admission",original),("post",last)):
                arms=records["arms"]
                require(set(arms)==set(NORMAL) and all(a==arms["base"] for a in arms.values()),
                        "registered pre/post products or roles differ")
                for arm in NORMAL:
                    got=read(folder/(phase+"-"+arm)/"receipt.json")
                    require(not got["measured"] and all(got[k]==arms[arm][k] for k in ("roles","roster","outputs")),
                            "raw admission differs from combined oracle")
            for block in blocks:
                for row in block:
                    i,rank,arm=int(row["block"]),int(row["rank"]),row["arm"]
                    require(row["literal"]==tag(cohort,ep,i) and row["source_sha256"]==
                            hbytes(changed(ORIGINAL.read_bytes(),cohort,row["literal"])),"wrong scheduled source edit")
                    recorded=read(folder/f"m{i:03}-{rank}-{arm}"/"receipt.json")
                    require(recorded["measured"] and recorded["roster"]==original["arms"][arm]["roster"] and
                            all(str(recorded[k])==row[k] for k in ("elapsed_ns","utc_ns","seconds_user","seconds_system")),
                            "native timing or actual roster differs from original receipt")
            telemetry=[json.loads(l)[:3] for l in (folder/"external.jsonl").read_text().splitlines()]
            require(telemetry==[[int(r["block"]),int(r["rank"]),r["arm"]] for b in blocks for r in b],
                    "missing unfiltered activity record")
            result[cohort][ep] = {}
            for ai,arm in enumerate(("shipped","base")):
                stats = compare(blocks,arm,"head",12000+ci*100+ei*10+ai)
                result[cohort][ep][arm] = {"statistics":stats, "passed":passes(stats,False)}
    return {"cohorts":result,"qualified_endpoints":[ep for ep in ENDPOINTS if
            all(result[c][ep][a]["passed"] for c in COHORTS for a in ("shipped","base"))]}


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("mode",choices=("direct","direct-with-counts","normal"))
    args=p.parse_args()
    verify_registration()
    print(json.dumps(normal_result() if args.mode == "normal" else direct_result(args.mode == "direct-with-counts"),
                     indent=2,sort_keys=True))
