"""Pure row negatives and two bounded Linux fork/pipe controls; no exe, benchmark or instrumenter."""
import copy
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import verifier as v
sys.path.insert(0,str(HERE))
import worker as w


def reject(fn):
    try:
        fn()
    except (ValueError,TimeoutError):
        return
    raise AssertionError("bad control admitted")


def inside(escape):
    # Hold an actual child in D/S on an independent handshake until we have observed the parent exit.
    w.kernel_subreaper()
    assert not w.owner_snapshot(-1)
    r,wr=os.pipe()
    hand_r,hand_w=os.pipe()
    go_r,go_w=os.pipe()
    os.write(wr,b"++++++")
    leader=os.fork()
    if leader==0:
        try:
            os.setsid()
            child=os.fork()
            if child:
                os._exit(0)
            if escape:
                os.setsid()
            os.write(hand_w,(str(os.getpid())+"\n").encode())
            os.read(go_r,1)
            time.sleep(.025)
            os.write(wr,b"+")
            time.sleep(.015)
        finally:
            os._exit(0)
    _,status=os.waitpid(leader,0)
    assert os.waitstatus_to_exitcode(status)==0
    child=int(os.read(hand_r,32))
    assert w.count(r)==6
    initial=w.owner_snapshot(leader)
    member,=[p for p in initial if p["pid"]==child]
    assert member["ppid"]==os.getpid() and (member["pgrp"]!=leader)==escape and member["state"] not in ("X","Z")
    os.write(go_w,b"y")
    log={"foreground_token_count":6}
    w.drain(r,leader,log)
    assert log["final_token_count"]==7 and log["after_drain_available"]==0 and log["returned_tokens_hex"]==w.TOKENS.hex()
    assert not log["final_live_owned"] and log["reaped"] and not w.owner_snapshot(-1)
    for fd in (r,wr,hand_r,hand_w,go_r,go_w):
        os.close(fd)
    return {"escaped_session":escape,"physical_return":len(bytes.fromhex(log["returned_tokens_hex"])),
            "foreground_count":log["foreground_token_count"],"confirmed_reaped":len(log["reaped"]),
            "ended_with_no_live_owned":True}


def matrix():
    good={"pid":241,"pgid":241,"session":241,"accepted":True,"foreground_exit":0,"foreground_elapsed_ns":123,
          "argv_sha256":"arg","foreground_token_count":6,"drain_start_token_count":6,"expected_tokens_hex":w.TOKENS.hex(),
          "final_token_count":7,"returned_tokens_hex":w.TOKENS.hex(),"after_drain_available":0,"drain_ns":27,
          "final_live_owned":[],"final_owned_processes":[],"confirmed_zombies":[],"reaped":[],"token_observations":[[0,6],[26,7]]}
    row={"block":3,"rank":0,"arm":"one","literal":"EB003","source_sha256":"src","argv_sha256":"arg","raw_sha256":"raw",
         "observer_sha256":"obs","exit":0,"elapsed_ns":123}
    def check(r,o):
        v.checked_observer(r,o,"raw","obs","src","arg",(3,0,"one","EB003"))
    check(row,good)
    mutated=[]
    for k in ("block","rank","arm","literal","source_sha256","argv_sha256","raw_sha256","observer_sha256","exit","elapsed_ns"):
        r=copy.deepcopy(row)
        r[k]="tampered"
        reject(lambda:check(r,good))
        mutated.append("row."+k)
    for k,value in (("foreground_exit",1),("returned_tokens_hex",b"++++++!".hex()),("final_token_count",6),
                    ("final_live_owned",[{"pid":1,"state":"S"}]),("final_owned_processes",[{"pid":1,"state":"T"}]),
                    ("confirmed_zombies",[{"pid":1,"state":"I"}])):
        o=copy.deepcopy(good)
        o[k]=value
        reject(lambda:check(row,o))
        mutated.append("observer."+k)
    for buf in (b"++++++!",b"++++++++",b"++++++"):
        r,wr=os.pipe()
        os.write(wr,buf)
        clock=iter(range(0,1000000,10000))
        try:
            reject(lambda:w.drain(r,55,{},clock=lambda:next(clock),sleep=lambda _:None,snapshot=lambda _:[],
                                   budget_ns=15000))
        finally:
            os.close(r)
            os.close(wr)
    unsupported={"pid":991,"state":"T","ppid":1,"session":64,"pgrp":64,"start_ticks":55}
    r,wr=os.pipe()
    os.write(wr,w.TOKENS)
    clock=iter(range(0,1000000,10000))
    try:
        reject(lambda:w.drain(r,64,{},clock=lambda:next(clock),sleep=lambda _:None,
                              snapshot=lambda _:[unsupported],budget_ns=15000))
    finally:
        os.close(r)
        os.close(wr)
    return mutated


if __name__=="__main__":
    negatives=matrix()
    controls=[inside(False),inside(True)]
    print(json.dumps({"source_only_and_synthetic":True,"compiler_or_linker_launches":0,"timed_study_rows":0,
                      "normal_or_DBI_commands":0,"row_and_observer_negatives":negatives,
                      "pipe_negatives":["missing","extra","substituted","all tokens present while stopped child remains"],
                      "fork_controls":controls},sort_keys=True,indent=2))
