"""Parent-side foreground timing and bounded child/token cleanup; product inputs remain frozen."""
import array
import ctypes
import fcntl
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import termios
import time

BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE))
import direct
import study as s

TOKENS=b"+++++++"  # byte-for-byte identical to the original study
BUDGET=15
POLL_SECONDS=.002


def count(fd):
    value=array.array("i",[0])
    fcntl.ioctl(fd,termios.FIONREAD,value,True)
    return value[0]


def kernel_subreaper():
    if sys.platform!="linux":
        raise RuntimeError("Linux child-subreaper support required")
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0:
        raise OSError(ctypes.get_errno(),"PR_SET_CHILD_SUBREAPER")
    flag=ctypes.c_int()
    if libc.prctl(37,ctypes.byref(flag),0,0,0)!=0 or flag.value!=1:
        raise RuntimeError("subreaper is not active")


def parse_stat(line):
    pid=int(line.split(" (",1)[0])
    fields=line.rsplit(")",1)[1].split()
    return {"pid":pid,"state":fields[0],"ppid":int(fields[1]),"pgrp":int(fields[2]),
            "session":int(fields[3]),"start_ticks":int(fields[19])}


def owner_snapshot(group, owner=None):
    # Discover both the named process group and children that reparented to the subreaper.
    # A descendant with a new session can no longer hide its work after the foreground exits.
    owner=os.getpid() if owner is None else owner
    processes={}
    for directory in Path("/proc").glob("[0-9]*"):
        try:
            r=parse_stat((directory/"stat").read_text())
        except (FileNotFoundError,ProcessLookupError):
            continue
        processes[r["pid"]]=r
    found={r["pid"] for r in processes.values() if r["pgrp"]==group}
    parents={owner}|found
    while True:
        children={r["pid"] for r in processes.values() if r["ppid"] in parents}
        if children<=parents:
            break
        parents.update(children)
    found.update(parents-{owner})
    return [processes[p] for p in sorted(found) if p in processes]


def reap_confirmed(entries):
    reaped=[]
    for r in entries:
        if r["ppid"]==os.getpid() and r["state"] in ("Z","X"):
            try:
                pid,status=os.waitpid(r["pid"],os.WNOHANG)
            except ChildProcessError:
                continue
            if pid:
                reaped.append({"pid":pid,"raw_wait_status":status,"observed":r})
    return reaped


def summarize(entries):
    return [r for r in entries if r["state"] not in ("Z","X")]


def drain(readfd, group, log, *, clock=time.monotonic_ns, sleep=time.sleep, snapshot=owner_snapshot,
          available=count, reaper=reap_confirmed, read=os.read, budget_ns=BUDGET*1_000_000_000):
    start=clock()
    for_initial=available(readfd)
    log.setdefault("foreground_token_count",for_initial)
    log.update(expected_tokens_hex=TOKENS.hex(),drain_start_token_count=for_initial,pgid=group,
               token_observations=[],initial_owned_processes=None,reaped=[],confirmed_zombies=[])
    s.require(0 <= log["foreground_token_count"] <= len(TOKENS) and 0 <= for_initial <= len(TOKENS), "unexpected initial token count")
    while True:
        n=available(readfd)
        current=snapshot(group)
        if log["initial_owned_processes"] is None:
            log["initial_owned_processes"]=current
        spent=clock()-start
        if not log["token_observations"] or n!=log["token_observations"][-1][1]:
            log["token_observations"].append([spent,n])
        ignored=[p for p in current if p["state"] in ("Z","X")]
        log["confirmed_zombies"].extend(p for p in ignored if p not in log["confirmed_zombies"])
        log["reaped"].extend(reaper(ignored))
        live=summarize(current)
        log.update(drain_ns=spent,final_token_count=n,final_owned_processes=current,final_live_owned=live)
        if spent>budget_ns:
            raise TimeoutError("out-of-timer cleanup exceeded its bounded window")
        if n>len(TOKENS):
            raise ValueError("jobserver gained unexpected physical bytes")
        if n==len(TOKENS) and not live:
            physical=read(readfd,len(TOKENS))
            log["returned_tokens_hex"]=physical.hex()
            log["after_drain_available"]=available(readfd)
            if sorted(physical)!=sorted(TOKENS) or log["after_drain_available"]!=0:
                raise ValueError("unexpected jobserver byte multiset")
            # A second complete process census closes the reaping/exit interval.
            final=snapshot(group)
            log["confirmed_zombies"].extend(p for p in final if p["state"] in ("Z","X") and p not in log["confirmed_zombies"])
            log["reaped"].extend(reaper([p for p in final if p["state"] in ("Z","X")]))
            log["final_owned_processes"]=final
            log["final_live_owned"]=summarize(final)
            if log["final_live_owned"]:
                raise ValueError("live process appeared in final closed interval")
            log["drain_ns"]=clock()-start
            s.require(log["drain_ns"]<=budget_ns,"final process census exceeded its bounded window")
            return
        if spent>=budget_ns:
            raise TimeoutError("timed out waiting for all physical tokens and an empty live process group")
        sleep(POLL_SECONDS)


def stop_owned(pgid, evidence):
    """Only used after a failed observation; no subsequent arm is admitted."""
    evidence["cleanup_after_rejection"]=[]
    for sig in (signal.SIGTERM,signal.SIGKILL):
        live=summarize(owner_snapshot(pgid))
        if not live:
            break
        sent=[]
        for p in live:
            try:
                fd=os.pidfd_open(p["pid"])
            except ProcessLookupError:
                continue
            try:
                current=next((r for r in owner_snapshot(pgid) if r["pid"]==p["pid"] and
                              r["start_ticks"]==p["start_ticks"] and r["state"] not in ("Z","X")),None)
                if current:
                    signal.pidfd_send_signal(fd,sig)
                    sent.append(current)
            except ProcessLookupError:
                pass
            finally:
                os.close(fd)
        evidence["cleanup_after_rejection"].append({"signal":int(sig),"sent":sent})
        end=time.monotonic()+2
        while time.monotonic()<end and summarize(owner_snapshot(pgid)):
            time.sleep(.02)
    final=owner_snapshot(pgid)
    evidence["cleanup_after_rejection"].append({"final":final,"reaped":reap_confirmed(final)})
    s.require(not summarize(final),"owned descendant still live after rejection")


def execute(args, srcroot, stage, mode, log):
    kernel_subreaper()
    s.require(not owner_snapshot(-1),"new command would inherit a prior owned child")
    env={"HOME":str(stage/"home"),"TMPDIR":str(stage/"tmp"),"LANG":"C.UTF-8","LC_ALL":"C.UTF-8",
         "TZ":"UTC","PATH":f"{s.TOOLS}/bin:/usr/bin:/bin"}
    rd,wr=os.pipe()
    record={}
    process=None
    observer=log.with_suffix(".observer.json")
    s.require(not observer.exists() and not log.exists(),"existing original observation")
    try:
        s.require(os.write(wr,TOKENS)==len(TOKENS),"cannot seed private jobserver")
        env["CARGO_MAKEFLAGS"]=f"-j --jobserver-auth={rd},{wr}"
        tool=[sys.executable,str(s.WORK/"edit-link-profile/native-instrument/count.py"),"--"]
        command=[*(tool if mode=="count" else []),*args]
        before=resource.getrusage(resource.RUSAGE_CHILDREN)
        with log.open("xb") as dst:
            start=time.perf_counter_ns()
            with subprocess.Popen(command,cwd=srcroot,env=env,pass_fds=(rd,wr),stdout=dst,
                                  stderr=subprocess.STDOUT,start_new_session=True) as process:
                process.communicate()
            stop=time.perf_counter_ns()
            foreground_tokens=count(rd)
        after=resource.getrusage(resource.RUSAGE_CHILDREN)
        record.update(pid=process.pid,foreground_exit=process.returncode,foreground_elapsed_ns=stop-start,
                      foreground_token_count=foreground_tokens,session=process.pid,argv_sha256=direct.sha_args(args))
        drain(rd,process.pid,record)
        s.require(process.returncode==0,f"direct rustc exited {process.returncode}: {log}")
        record["accepted"]=True
    except BaseException as exc:
        record["accepted"]=False
        record["rejection"]=repr(exc)
        if process is not None:
            stop_owned(process.pid,record)
        raise
    finally:
        os.close(rd)
        os.close(wr)
        s.save(observer,record)
    obs={"elapsed_ns":record["foreground_elapsed_ns"],"argv_sha256":direct.sha_args(args),"exit":process.returncode,
         "cpu_user_s":after.ru_utime-before.ru_utime,"cpu_system_s":after.ru_stime-before.ru_stime,
         "raw_sha256":s.sha(log),"observer_sha256":s.sha(observer)}
    if mode=="count":
        receipt,=[json.loads(line[len("DynamoRIO "):]) for line in log.read_text().splitlines() if line.startswith("DynamoRIO ")]
        s.require(receipt["instructions"]==sum(receipt["threads"].values())>0 and str(receipt["pid"]) in receipt["threads"],
                  "invalid per-thread foreground count")
        obs.update(instructions=receipt["instructions"],threads=receipt["threads"],pid=receipt["pid"])
    return obs
