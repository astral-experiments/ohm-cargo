"""Post-measurement physical return for the separate DynamoRIO cohort grants."""
import fcntl
import json
import os
from pathlib import Path
import sys
import time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import verifier as v
s=v.s
NATIVE_SHA="14eabc346e65f6d5f609648b81fad543213f93b877b90b7b1c3040ed279e2703"


def finish():
    v.verify_seal()
    orig=HERE/"physical-host-return.json"
    assert s.sha(orig)==NATIVE_SHA and s.read(orig)["host_returned"]
    previous=s.read(orig)
    closures={};pids=set();timed=0;observed=0
    for cohort in s.COHORTS:
        outer=HERE/"exec-returns"/("direct-count-"+cohort+".json")
        receipt=s.read(outer)
        grant=HERE/"grants"/("direct-count-"+cohort+".json")
        assert receipt["foreground_exit"]==0 and receipt["scope"]=="direct-count-"+cohort and receipt["grant_sha256"]==s.sha(grant)
        root=v.RESULT/"direct-count"/cohort
        assert s.read(root/"done.json")=={"roles":list(s.ROLES),"mode":"count","cohort":cohort}
        assert receipt["cohort_closure_sha256"]==s.sha(root/"done.json")
        items={}
        for role in s.ROLES:
            d=root/role;bank=s.SCRATCH/"direct-count"/cohort/role
            assert not (bank/"active").exists() and all((bank/a).is_dir() for a in s.DIRECT)
            r=v.verify_role("count",cohort,role)
            assert r["rows"]==16
            rows=[s.read(p) for p in d.glob("*.observer.json")]
            assert len(rows)==24 and all(x["accepted"] and x["foreground_exit"]==0 and x["final_token_count"]==7
                    and x["after_drain_available"]==0 and x["returned_tokens_hex"]==b"+++++++".hex()
                    and not x["final_live_owned"] for x in rows)
            for phase,block in (("admit",992),("post",999)):
                pp=s.read(d/(phase+"-products.json"))
                for a,x in pp.items():
                    assert all(x[k]==pp["eight"][k] for k in ("raw_sha256","size","dep_sha256"))
                    beh=x["behavior"]
                    if role=="test-harness":assert beh=={"exit":0,"listed":"0 tests, 0 benchmarks\n"}
                    elif cohort=="replica":
                        assert (beh["exit"],beh["stdout"],beh["stderr"],beh["raw_sha256"])==(0,"tool\nuvx\nfixed-argument\n","",x["raw_sha256"])
                    else:
                        tag=s.tag(cohort,"build" if role=="build-bin" else "test",block)
                        prefix=f"error: uvx could not launch uv [{tag}]: Could not find the `uv` binary at either of:\n"
                        assert beh["exit"]==2 and not beh["stdout"] and beh["stderr"].startswith(prefix) and beh["raw_sha256"]==x["raw_sha256"]
                        arms=beh["stderr"][len(prefix):].splitlines()
                        assert len(arms)==2 and arms[0]==arms[1] and arms[0].startswith("  ")
                        where=Path(arms[0][2:]);assert where.name=="uv" and where.parent.parent==s.SCRATCH/"direct-count"/cohort
                        assert s.re.fullmatch(r"tmp[a-z0-9_]{8}",where.parent.name)
            pids.update(x["pgid"] for x in rows);observed+=len(rows);timed+=r["rows"]
            items[role]={"rows":r["rows"],"sha256":r["rows_sha256"],"all_observers":len(rows),
                         "admit_sha256":s.sha(d/"admit-products.json"),"post_sha256":s.sha(d/"post-products.json")}
        closures[cohort]={"exec_return_sha256":s.sha(outer),"issued_grant_sha256":s.sha(grant),"roles":items}
    global_tools=[];owned=[]
    for p in Path("/proc").iterdir():
        if not p.name.isdecimal():continue
        try:stat=(p/"stat").read_text()
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        c=stat.rfind(")");comm=stat[stat.find("(")+1:c];tail=stat[c+2:].split()
        if tail[0] in ("Z","X"):continue
        if int(tail[2]) in pids or int(tail[3]) in pids:owned.append([int(p.name),comm])
        if comm in {"rustc","cargo","wild","ld.bfd","rust-lld","ld.lld","drrun","drconfig","valgrind","cachegrind"}:global_tools.append([int(p.name),comm])
    assert not owned and not global_tools,(owned,global_tools)
    with (s.ROOT/"native-lease").open("r") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
    for rel,expected in previous["released_tool_slots"].items():assert s.sha(s.DIST/rel)==s.sha(s.TOOLS/rel)==expected
    assert (s.TOOLS/"bin/cargo").samefile(s.ROOT/"official-original-cargo") and (s.TOOLS/s.LINK).samefile(s.ROOT/"official-original-wild")
    for cohort,paths in previous["original_source_and_lock"].items():
        for name,values in paths.items():
            p=Path(name);assert {"sha256":s.sha(p),"inode":p.stat().st_ino,"mtime_ns":p.stat().st_mtime_ns}==values
    assert timed==96 and observed==144
    out={"host_returned":True,"unix_ns":time.time_ns(),"scope":"two registered direct-count stages completed",
         "host_boot_id":Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"total_counted_rows":timed,
         "observed_all_commands":observed,"all_raw_thread_sums_verified":True,"all_seven_permits_conserved":True,
         "live_owned_processes":owned,"live_global_compiler_linker_dbi":global_tools,
         "native_lease_reacquired_and_released":True,"native_physical_return_sha256":NATIVE_SHA,"cohorts":closures,
         "released_stock_tools_unchanged":True,"source_lock_inode_sha_and_mtime_unchanged":True,
         "postflight_verifier_sha256":s.sha(Path(__file__))}
    destination=HERE/"physical-counter-return.json"
    s.save(destination,out);print(s.sha(destination))


if __name__=="__main__":finish()
