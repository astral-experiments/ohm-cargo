"""Bind the observed external shell return to the completed immutable inner role records."""
import argparse
import json
from pathlib import Path
import sys
import time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import verifier as v
s=v.s
def main():
    p=argparse.ArgumentParser();p.add_argument("cohort",choices=s.COHORTS);p.add_argument("grant_sha256")
    p.add_argument("exec_session",type=int);p.add_argument("foreground_exit",type=int);a=p.parse_args()
    issued=HERE/"grants"/("direct-count-"+a.cohort+".json")
    assert s.sha(issued)==a.grant_sha256 and a.foreground_exit==0 and a.exec_session>0
    root=v.RESULT/"direct-count"/a.cohort
    assert s.read(root/"done.json")=={"roles":list(s.ROLES),"mode":"count","cohort":a.cohort}
    roles={n:v.verify_role("count",a.cohort,n) for n in s.ROLES}
    assert all(v["rows"]==16 for v in roles.values())
    folder=HERE/"exec-returns";folder.mkdir(exist_ok=True)
    out=folder/("direct-count-"+a.cohort+".json")
    s.save(out,{"scope":"direct-count-"+a.cohort,"grant_sha256":a.grant_sha256,"external_tool_session":a.exec_session,
                "foreground_exit":a.foreground_exit,"receipt_recorded_ns":time.time_ns(),"roles":roles,
                "cohort_closure_sha256":s.sha(root/"done.json"),"verifier_sha256":s.sha(Path(__file__))})
    print(s.sha(out))
if __name__=="__main__":main()
