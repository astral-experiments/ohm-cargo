"""Small source, real Cargo controls. No third-party dependencies, test payload execution or wrappers."""
import argparse
import contextlib
import sys
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from study import *
import normal

CASES = {
    "tiny-build": ("tiny","build",None), "tiny-test":("tiny","test",None),
    "large-one-file":("large","build",None),"large-one-file-test":("large","test",None),
    "small-root-large-module":("module","build",None),"small-root-module-test":("module","test",None),
    "new-module":("transition","build",None), "new-module-test":("transition","test",None),
    "user-joined":("tiny","build","joined"), "user-split":("tiny","test","split"),
    "no-incremental":("tiny","build","no-incremental"), "explicit-target":("tiny","build","target"),
    "dev-library":("library","build",None),
}
COLD_PROGRAM = 'fn main() { println!("front-PLACE"); }\n#[test] fn works() { assert_eq!(2 + 2, 4); }\n'


def substantial():
    # Each of the 4,096 functions is reachable via an indirect call indexed by a runtime input.
    fn = ''.join(f'#[inline(never)] fn f{i}(v: u64) -> u64 {{ v.wrapping_mul({2*i+1}).rotate_left({i%63}) ^ {i} }}\n'
                 for i in range(4096))
    table = ','.join(f'f{i}' for i in range(4096))
    return fn + 'static OPS: [fn(u64)->u64; 4096] = ['+table+'];\npub fn eval(v:u64)->u64 { OPS[(v as usize) & 4095](v) }\n'


def source_at(project, kind, mark, heavy):
    src = project/"src"
    lib = src/"lib.rs"
    root = src/("lib.rs" if kind=="library" else "main.rs")
    if kind=="library":
        text=f'pub const VALUE: &str = "{mark}";\n'
    elif kind=="tiny":
        text=COLD_PROGRAM.replace("PLACE",mark)
    else:
        core = 'fn main() { let v = std::env::args_os().count() as u64; println!("front-PLACE {}", EVAL(v)); }\n' +                '#[test] fn works() { assert_eq!(EVAL(0),0); }\n'
        if kind=="large":
            text=heavy+core.replace("EVAL","eval")
        else:
            (src/"heavy.rs").write_text(heavy)
            text="mod heavy;\n"+core.replace("EVAL","heavy::eval")
        text=text.replace("PLACE",mark)
    root.write_text(text)
    return root


def flags(args):
    vals=[]
    for i,arg in enumerate(args):
        if arg.startswith("-Zthreads=") or i>0 and args[i-1]=="-Z" and arg.startswith("threads="):
            vals.append(arg.split("=",1)[1])
    return vals


def command(case, ep, override, path, active, driver, observe, out, package):
    env={"HOME":str(case/"home"),"PATH":f"{TOOLS}/bin:/usr/bin:/bin","CARGO_HOME":str(case/"cargo-home"),
         "CARGO_TARGET_DIR":str(active),"CARGO_NET_OFFLINE":"true","RUSTC":str(TOOLS/"bin/rustc"),
         "RUSTDOC":str(TOOLS/"bin/rustdoc"),"LANG":"C.UTF-8","LC_ALL":"C.UTF-8","TZ":"UTC","CARGO_TERM_COLOR":"never"}
    options=[]
    if override=="joined":
        env["RUSTFLAGS"]="-Zthreads=4"
    if override=="split":
        env["CARGO_ENCODED_RUSTFLAGS"]="-Z"+chr(31)+"threads=4"
    if override=="no-incremental":
        env["CARGO_INCREMENTAL"]="0"
    if override=="target":
        options=["--target","x86_64-unknown-linux-gnu"]
    argv=[str(driver),ep,*(["--no-run"] if ep=="test" else []),"--offline","--locked","-j8",
          *options,"--message-format=json"]
    out.mkdir()
    launch=["strace","-ff","-qq","-s","4096","-e","trace=execve,execveat","-o",str(out/"exec"),*argv] if observe else argv
    with (out/"stdout").open("xb") as stdout,(out/"stderr").open("xb") as stderr:
        start=time.perf_counter_ns()
        proc=subprocess.run(launch,cwd=path,env=env,stdout=stdout,stderr=stderr)
        elapsed=time.perf_counter_ns()-start
    require(proc.returncode==0,f"fixture Cargo failed at {out}; all raw files retained")
    artifacts=[json.loads(l) for l in (out/"stdout").read_text().splitlines() if l.startswith("{")]
    products={}
    for message in artifacts:
        if message.get("reason")!="compiler-artifact" or message["target"]["src_path"] not in [str(path/"src/main.rs"),str(path/"src/lib.rs")]:
            continue
        paths=[Path(p) for p in message["filenames"]]
        products[(message["target"]["name"],message["profile"]["test"])]={
            p.name:(normal.canon.native.archive(p)["normalized_sha256"] if p.suffix==".rlib" else sha(p)) for p in paths if p.is_file()}
    require(products,"fixture did not emit target")
    raw_products={p:sha(Path(p)) for m in artifacts if m.get("reason")=="compiler-artifact"
                  and m["target"]["src_path"] in [str(path/"src/main.rs"),str(path/"src/lib.rs")]
                  for p in m["filenames"] if Path(p).is_file()}
    receipt={"elapsed_ns":elapsed,"argv":argv,"products":{str(k):v for k,v in products.items()},"raw_products":raw_products}
    if observe:
        prefix="execve("+json.dumps(str(TOOLS/"bin/rustc"))+", "
        target=[]
        for f in sorted(out.glob("exec.*")):
            for line in f.read_text().splitlines():
                if not line.startswith(prefix) or not line.endswith("= 0"):
                    continue
                args,_=json.JSONDecoder().raw_decode(line[len(prefix):])
                if "--crate-name" not in args or args[args.index("--crate-name")+1] != package:
                    continue
                main="src/lib.rs" if package=="frontlib" else "src/main.rs"
                require(main in args and "--out-dir" in args, "wrong fixture frontend")
                emitted=Path(args[args.index("--out-dir")+1])
                harness="--test" in args
                stem=("test-" if harness else "")+("lib-" if package=="frontlib" else "bin-")+package
                hint=emitted.parent/"fingerprint"/("dep-"+stem)
                require(hint.is_file() and 0<hint.stat().st_size<=16*1024,"fixture must actually have small translated dep-info")
                target.append({"harness":harness,"flags":flags(args),"dep_info_bytes":hint.stat().st_size,
                               "dep_info_sha256":sha(hint),"source_bytes":(path/main).stat().st_size,
                               "argv_sha256":hbytes(json.dumps(args).encode())})
        require(sorted(r["harness"] for r in target)==([False,True] if ep=="test" else [False]),
                ("odd genuine binary/harness roster",target))
        receipt["targets"]=target
    save(out/"receipt.json",receipt)
    return receipt


def fixture_files(case, kind):
    project=case/"project"
    (project/"src").mkdir(parents=True)
    for x in ("home","cargo-home"):
        (case/x).mkdir()
    base='[package]\nname="frontfixture"\nversion="0.1.0"\nedition="2024"\n[workspace]\n'
    base+=('[lib]\nname="frontlib"\npath="src/lib.rs"\n' if kind=="library" else
           '[[bin]]\nname="frontprobe"\npath="src/main.rs"\n')
    (project/"Cargo.toml").write_text(base)
    (project/"Cargo.lock").write_text('version = 4\n\n[[package]]\nname = "frontfixture"\nversion = "0.1.0"\n')
    if kind!="library":
        (project/"tests").mkdir()
        (project/"tests/use_bin.rs").write_text('#[test] fn named() { let _ = env!("CARGO_BIN_EXE_frontprobe"); }\n')
    return project


def run():
    from score import direct_result, assigned, compare
    with authorized("controls","initial",16) as grant:
        require(direct_result(True)["eligible"],"direct screen must qualify before building controls")
        variants=normal.drivers(grant)
        root=SCRATCH/"controls"
        out=RESULT/"controls"
        require(not root.exists() and not out.exists(),"control run already attempted")
        root.mkdir(parents=True)
        out.mkdir(parents=True)
        staged={}
        for arm,driver in variants.items():
            dest=root/("driver-"+arm)
            shutil.copy2(driver,dest)
            require(sha(dest)==sha(driver),"fixture input driver drift")
            staged[arm]=dest
        heavy=substantial()
        require(len(heavy.encode())>300*1024,"one-source control is too small")
        frozen=read(HERE/"schedule.json")["risk"]
        for name,(kind,ep,override) in CASES.items():
            case=root/name
            cell=out/name
            cell.mkdir()
            project=fixture_files(case,kind)
            active=case/"target"
            tool=case/"cargo"
            snaps={}
            for arm in NORMAL:
                (case/arm).mkdir()
                os.link(staged[arm],case/("driver-"+arm))
            @contextlib.contextmanager
            def using(arm, bank=None):
                held=case/arm if bank is None else bank
                require(not active.exists() and held.is_dir(),"occupied control target")
                held.rename(active)
                try:
                    normal.worker.select(case/("driver-"+arm),tool)
                    yield
                finally:
                    active.rename(held)
            for index,phase in enumerate(("cold","edit","next")):
                effective="tiny" if kind=="transition" and phase=="cold" else ("module" if kind=="transition" else kind)
                src=source_at(project,effective,f"T{index:03}",heavy)
                require((src.stat().st_size>16*1024)==(effective=="large"),"source size guard does not distinguish the controls")
                outcomes={}
                for arm in NORMAL:
                    with using(arm):
                        one=command(case,ep,override,project,active,tool,True,cell/(phase+"-"+arm),"frontlib" if kind=="library" else "frontprobe")
                    should_use=(phase!="cold" and (kind=="tiny" or kind=="transition" and phase=="edit") and
                                override not in ("no-incremental","target") and arm=="head")
                    expected=["8"]+(["1"] if should_use else [])+(["4"] if override in ("joined","split") else [])
                    require(all(r["flags"]==expected for r in one["targets"]),("incorrect user override or eligibility",name,phase,arm,expected,one))
                    outcomes[arm]=one["products"]
                    if name=="new-module" and phase=="cold":
                        donor=case/("small-seed-"+arm)
                        normal.copy_bank(case/arm,donor)
                        snaps[arm]=donor
                require(all(p==outcomes["base"] for p in outcomes.values()),("fixture ELF/rlib discrepancy",name,phase))
            if name=="new-module":
                rows=[]
                normal.quiet(grant,cell)
                for i,order in enumerate(frozen):
                    src=source_at(project,"module",f"R{i:03}",heavy)
                    checks=[]
                    for rank,arm in enumerate(order):
                        # A new copy of the original tiny predecessor each time, never yesterday's large graph.
                        assert_floor(6)
                        tmp=case/f"disposable-{i:03}-{rank}-{arm}"
                        normal.copy_bank(snaps[arm],tmp)
                        original_ino=tmp.stat().st_ino
                        with using(arm,tmp):
                            one=command(case,"build",None,project,active,tool,False,cell/f"m{i:03}-{rank}-{arm}","frontprobe")
                        require(tmp.parent==case and tmp.stat().st_ino==original_ino and tmp.name.startswith("disposable-"),
                                "unrecognized disposable fixture")
                        shutil.rmtree(tmp)
                        checks.append(one["products"])
                        rows.append(dict(block=i,rank=rank,arm=arm,source_sha256=sha(src),elapsed_ns=one["elapsed_ns"]))
                    require(checks[0]==checks[1]==checks[2],"first-introduction products differ")
                save(cell/"timings.json",rows)
                blocks=assigned(rows,frozen)
                # Reject a cliff on the newly discovered heavy input. Exact correct target flags alone cannot protect this case.
                risk={a:compare(blocks,a,"head",33120+i) for i,a in enumerate(("base","shipped"))}
                save(cell/"risk.json",risk)
            save(cell/"done.json",{"all_control_flags_and_products_match":True})
        risk=read(out/"new-module/risk.json")
        # Exclude a 5% or 10 ms slowdown at the 95% lower rank bound relative to each control.
        admissible=all(r["median_saved_pct_interval"]["lower"] > -5 or r["median_saved_ms_interval"]["lower"] > -10
                       for r in risk.values())
        save(out/"done.json",{"eligible":admissible,"risk":risk,"cases":list(CASES)})


if __name__=="__main__":
    run()
