"""Reconstruct every direct row from its saved source tag, captured argv, log and drain receipt."""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

HERE=Path(__file__).resolve().parent
ORIGINAL=HERE.parent
sys.path.insert(0,str(ORIGINAL))
import study as s
import direct
import score
ORIGINAL_SCORE=score.direct_result
PRIOR="26ae47b01f7718ee999e79ca346af02906aa08a43c594955002fd4f6684f7c74"
EXPECTED=b"+++++++"
RESULT=HERE/"observed"


def verify_seal():
    s.require(s.sha(ORIGINAL/"registration.json")==PRIOR,"prior seal changed")
    s.verify_registration()
    amendment=s.read(HERE/"amendment.json")
    s.require(amendment["prior_sha256"]==PRIOR and amendment["prior_attempt"]["timed_rows"]==0 and
              amendment["prior_attempt"]["original_results_absent"] and amendment["prior_attempt"]["original_grants"]==[],
              "prior zero-row registration")
    for name,digest in amendment["files"].items():
        s.require(s.sha(s.WORK/name)==digest,"observer drift: "+name)


@contextlib.contextmanager
def authority(phase,cohort,extra_gib):
    verify_seal()
    s.require(phase in ("direct-wall","direct-count") and cohort in s.COHORTS,"observer scope")
    path=HERE/"grants"/f"{phase}-{cohort}.json"
    expected=os.getenv("SMALL_FRONTEND_GRANT_SHA256")
    s.require(expected and path.is_file() and s.sha(path)==expected,"no amended, stage-specific coordinator grant")
    g=s.read(path)
    s.require(set(g)=={"phase","cohort","registration_sha256","host_boot_id","cpus","release","release_sha256",
                       "expires_utc_ns","drivers_sha256"},"grant schema")
    s.require(g["phase"]==phase and g["cohort"]==cohort and g["registration_sha256"]==s.sha(HERE/"amendment.json")
              and g["drivers_sha256"] is None and g["host_boot_id"]==Path("/proc/sys/kernel/random/boot_id").read_text().strip()
              and time.time_ns()<g["expires_utc_ns"],"authority scope/expiry")
    s.require(tuple(g["cpus"])==s.NATIVE_CPUS and sorted(os.sched_getaffinity(0))==list(s.NATIVE_CPUS),"CPU grant")
    release=Path(g["release"])
    s.require(release.is_absolute() and release.parent==s.LAB and s.sha(release)==g["release_sha256"],"live host release")
    with (s.ROOT/"native-lease").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        s.require(shutil.disk_usage(s.BENCH).free >= (120+extra_gib)*s.GIB,"reserve")
        for path in (Path("bin/rustc"),s.LINK):
            s.require(s.sha(s.TOOLS/path)==s.sha(s.DIST/path),"shipped tool drift")
        yield g


def checked_observer(row,obs,raw_sha,observer_sha,source_sha,arg_sha,entry):
    block,rank,arm,literal=entry
    s.require((row["block"],row["rank"],row["arm"],row["literal"])==(block,rank,arm,literal),
              "row assignment or literal diverged")
    s.require(row["source_sha256"]==source_sha and row["argv_sha256"]==arg_sha and
              row["raw_sha256"]==raw_sha and row["observer_sha256"]==observer_sha,"source/argv/raw log drift")
    s.require(obs["accepted"] and row["exit"]==obs["foreground_exit"]==0 and
              obs["foreground_elapsed_ns"]==row["elapsed_ns"]>0 and obs["argv_sha256"]==arg_sha and
              0<obs["pid"]==obs["pgid"]==obs["session"],"wrong foreground job, argv or timer")
    s.require(0<=obs["foreground_token_count"]<=7 and 0<=obs["drain_start_token_count"]<=7 and
              obs["expected_tokens_hex"]==EXPECTED.hex() and obs["final_token_count"]==7 and
              sorted(bytes.fromhex(obs["returned_tokens_hex"]))==sorted(EXPECTED) and obs["after_drain_available"]==0,
              "incomplete physical jobserver conservation")
    s.require(0<=obs["drain_ns"]<=15_000_000_000 and not obs["final_live_owned"] and
              all(p["state"] in ("Z","X") for p in obs["final_owned_processes"]) and
              all(p["state"] in ("Z","X") for p in obs["confirmed_zombies"]), "overlapping live process")
    s.require(len(obs["token_observations"])>=1 and obs["token_observations"][-1][1]==7 and
              all(0<=n<=7 for _,n in obs["token_observations"]), "invalid bounded-wait observations")
    s.require(all(r["observed"]["state"] in ("Z","X") and r["pid"]==r["observed"]["pid"] for r in obs["reaped"]),
              "non-zombie classified as reaped")


def verify_role(mode, cohort, role):
    phase_key="direct-"+mode
    directory=RESULT/phase_key/cohort/role
    start=s.read(directory.parent/"start.json")
    s.require(start["registration"]==PRIOR and start["grant"]["registration_sha256"]==s.sha(HERE/"amendment.json")
              and start["source_sha256"]==s.sha(s.ORIGINAL) and start["mode"]==mode and
              start["grant"]["phase"]==phase_key and start["grant"]["cohort"]==cohort,"wrong cohort registration")
    issued=HERE/"grants"/f"{phase_key}-{cohort}.json"
    s.require(s.read(issued)==start["grant"],"launch grant differs from the actual issued receipt")
    expected_dir=s.SCRATCH/phase_key/cohort/role/"active"
    args=direct.captured(cohort,role)
    variants={arm:direct.relocate(args,s.fixture(cohort),expected_dir,arm=="one",validate=False) for arm in s.DIRECT}
    s.require(s.read(directory/"argv.json")==variants,"different protected direct invocation")
    plan=s.read(ORIGINAL/"schedule.json")[phase_key][cohort][role]
    ep="build" if role=="build-bin" else "test"
    original=s.ORIGINAL.read_bytes()
    phase_blocks={"cold":[(990,s.DIRECT)],"settle":[(991,s.DIRECT[::-1])],"admit":[(992,s.DIRECT)],
                  "trial":list(enumerate(plan)),"post":[(999,s.DIRECT[::-1])]}
    for phase,trials in phase_blocks.items():
        observations=[json.loads(l) for l in (directory/(phase+".jsonl")).read_text().splitlines()]
        s.require(len(observations)==2*len(trials),"missing or surplus direct observations")
        expected_logs=set()
        for sequence,(i,order) in enumerate(trials):
            tag=s.tag(cohort,ep,i)
            source_sha=s.hbytes(s.changed(original,cohort,tag))
            for rank,arm in enumerate(order):
                raw=directory/f"{phase}-{i:03}-{rank}-{arm}.log"
                expected_logs.add(raw.name)
                observer=raw.with_suffix(".observer.json")
                row=observations[sequence*2+rank]
                argv=variants["eight" if phase=="cold" else arm]
                checked_observer(row,s.read(observer),s.sha(raw),s.sha(observer),source_sha,direct.sha_args(argv),
                                 (i,rank,arm,tag))
                if phase=="trial" and mode=="count":
                    counter,=[json.loads(l[len("DynamoRIO "):]) for l in raw.read_text().splitlines() if l.startswith("DynamoRIO ")]
                    s.require(all(row[k]==counter[k] for k in ("instructions","threads","pid")) and
                              sum(counter["threads"].values())==counter["instructions"]>0,"raw per-thread count drift")
        s.require({p.name for p in directory.glob(phase+"-*.log")}==expected_logs,"unregistered raw trial log")
    for phase in ("admit","post"):
        products=s.read(directory/(phase+"-products.json"))
        s.require(set(products)==set(s.DIRECT) and
                  all(products["eight"][k]==products["one"][k] for k in ("raw_sha256","size","dep_sha256")),
                  "original strict peri-phase product mismatch")
    fin=s.read(directory/"done.json")
    s.require(fin["rows"]==2*len(plan) and fin["sha256"]==s.sha(directory/"trial.jsonl"),"incomplete role")
    return {"rows":fin["rows"],"rows_sha256":fin["sha256"]}


def direct_result(counts):
    verify_seal()
    checked={}
    for mode in (("wall","count") if counts else ("wall",)):
        for cohort in s.COHORTS:
            checked[mode+"-"+cohort]={r:verify_role(mode,cohort,r) for r in s.ROLES}
            done=s.read(RESULT/("direct-"+mode)/cohort/"done.json")
            s.require(done=={"roles":list(s.ROLES),"mode":mode,"cohort":cohort},"cohort still open")
    score.RESULT=RESULT
    output=ORIGINAL_SCORE(counts)
    output["observer_verification"]=checked
    output["original_registration_sha256"]=PRIOR
    output["observer_amendment_sha256"]=s.sha(HERE/"amendment.json")
    return output
