"""Plan a new measurement using the completed uvx control arms exclusively."""

import csv
import json
import random
import statistics
from pathlib import Path


root = Path(__file__).resolve().parents[2]
with (root / 'outputs/ohm-18-further-edited-timings.csv').open() as f:
    rows = [row for row in csv.DictReader(f) if row['study'] == 'r18-uvx' and row['arm'] in {'shipped', 'base'}]

result = {'method': 'Within each historical block randomly orient and resample the shipped and matched controls. Estimate the one-sided 1.25% null threshold separately for each statistic. Then inject exact additive savings into the same simulated null distribution. These approximate design sensitivities use 30 historical blocks and do not estimate an effect of a new treatment.', 'cohorts': {}}
rng = random.Random(0x297cf890)
replicates = 2000
for cohort in ('initial', 'replica'):
    result['cohorts'][cohort] = {}
    for command in ('cargo build', 'cargo test --no-run'):
        by_block = {}
        for row in rows:
            if (row['checkout'], row['command']) == (cohort, command):
                by_block.setdefault(int(row['block']), {})[row['arm']] = int(row['elapsed_ns']) / 1e6
        assert len(by_block) == 30 and all(set(pair) == {'shipped', 'base'} for pair in by_block.values())
        control_pairs = [(p['shipped'], p['base']) for _, p in sorted(by_block.items())]
        orientations = [pair for a, b in control_pairs for pair in ((a, b), (b, a))]
        by_size = {}
        for count in (60, 120, 240, 480):
            estimates = {'difference_of_raw_medians': [], 'median_of_paired_differences': []}
            for _ in range(replicates):
                drawn = rng.choices(orientations, k=count)
                before, after = zip(*drawn)
                estimates['difference_of_raw_medians'].append(statistics.median(before) - statistics.median(after))
                estimates['median_of_paired_differences'].append(statistics.median(a-b for a, b in drawn))
            record = {}
            for name, values in estimates.items():
                critical = sorted(values)[int((1 - .0125) * len(values))]
                record[name] = {'null_threshold_ms': round(critical, 2), 'approx_power': {str(delta): round(sum(v + delta > critical for v in values) / replicates, 3) for delta in (10, 20, 35)}}
            by_size[str(count)] = record
        result['cohorts'][cohort][command] = by_size

destination = Path(__file__).with_name('subsecond-design-calibration.json')
destination.write_text(json.dumps(result, indent=2) + '\n')
