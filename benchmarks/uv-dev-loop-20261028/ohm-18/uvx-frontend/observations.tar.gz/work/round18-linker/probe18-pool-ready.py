from pathlib import Path
from itertools import combinations
import argparse,array,csv,fcntl,hashlib,json,math,os,random,re,select,statistics,subprocess,termios,time
p=Path(__file__).resolve().parent;w=p.parent;root=p/'confirm18-scoped-pool-ready';root.mkdir(exist_ok=True)
bins={'parent':w/'wild-prefix-v2/v2-wild','refresh':p/'js-refresh-v3','shipped':w/'upstream-monitor/toolchain18/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'}
env0={k:v for k,v in os.environ.items() if not k.startswith(('OHM_','WILD_')) and k not in ('CARGO_MAKEFLAGS','MFLAGS','MAKEFLAGS','RUSTFLAGS','RUSTC_WRAPPER','LD_PRELOAD')}
def digest(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(f,value):f.write_text(json.dumps(value,indent=2)+'\n')
def read(f):return json.loads(f.read_text())
def make_intake():
 audit=read(p/'captures18/audit.json');files=[];cache={};cs={}
 for d in sorted((p/'captures18').iterdir()):
  if not d.is_dir():continue
  tag=d.name;cp=d/'run-with';script=cp.read_text();out=next(x.split(': ',1)[1] for x in script.splitlines() if x.startswith('# Original output file: '));key=out.split('/target/',1)[1]
  assert digest(cp)==audit['bundles'][tag]['run_sha256']
  recorder=root/f'argv-{tag}.json';subprocess.run(['bash',cp,p/'grab-args.py'],env=env0|{'WILD_REPLAY_ARGS':str(recorder),'OUT':str(root/'linked-output')},check=True)
  # Wild's capture script rebases the literal ELF interpreter along with real input paths.
  # Verify the original ELF's PT_INTERP before restoring that literal in the replay argv.
  data=read(recorder);raw=root/f'argv-{tag}-as-saved.json';write(raw,data)
  interp=data['args'].index('-dynamic-linker')+1;literal='/'+str(Path(data['args'][interp]).relative_to(d))
  headers=subprocess.check_output(['readelf','-l',out],text=True)
  observed=re.search(r'Requesting program interpreter: ([^]]+)',headers).group(1)
  assert literal==observed,(tag,literal,observed)
  data['args'][interp]=literal;write(recorder,data)
  cs[tag]={'original':key,'sha256':audit['emitted'][key],'bundle_sha256':digest(cp),'saved_argv_sha256':digest(raw),'recorded_elf_interpreter':observed,'recorded_argv_sha256':digest(recorder)}
  for f in sorted(d.rglob('*')):
   name=str(f.relative_to(p/'captures18'))
   if f.is_symlink():files.append([name,'link',os.readlink(f)]);continue
   if not f.is_file():continue
   st=f.stat();inode=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
   if inode not in cache:cache[inode]=digest(f)
   files.append([name,st.st_size,cache[inode]])
 write(root/'inputs.json',files);write(root/'intake.json',cs);print('input files',len(files),'unique regular',len(cache),flush=True)
def schedule(trace):
 d=w/'round18-lab'/trace;j=read(d/'summary.json');xs=[json.loads(line) for line in (d/'observations.jsonl').open()];pids={int(pid) for pid,(role,out) in j['child_processes'].items() if role=='ld.bfd' and out[-1].endswith('/uv')};active=[q for q in pids if any(child[0]==q and child[3]>1 for _,_,ls in xs for child in ls)];assert len(active)==1
 pid=active[0];ticks=[(t,a) for t,a,ls in xs if a is not None and any(row[0]==pid for row in ls)];s=[];prev=0
 for t,a in ticks:
  if a<=prev:continue
  s.append([round((t-ticks[0][0])/1e6,3),a]);prev=a
  if prev==7:break
 assert [n for _,n in s]==[6,7],s
 return {'trace_source':trace,'raw_sha256':digest(d/'observations.jsonl'),'schedule':s,'link_pid':pid,'sampled_interval_ms':(ticks[-1][0]-ticks[0][0])/1e6}
def register():
 cs=read(root/'intake.json');idx=[k for k,v in cs.items() if v['original'].endswith('/uv')];assert len(idx)==1;idx=idx[0]
 cohorts=[]
 for nm,seed in [('probe-stock-native',429853),('probe-stock-steady',613489)]:
  order=['parent,refresh','refresh,parent']*4;random.Random(seed).shuffle(order)
  cohorts.append(schedule(nm)|{'seed':seed,'orders':[v.split(',') for v in order]})
 plan={'generation':'frozen before the first scoped-pool v3 replay of any -18 link','endpoint':'default forked Wild time from Popen through process completion, milliseconds. One physical shared jobserver pipe, no tokens at startup then six and one supplied at times observed on this actual Ohm -18 uv link. CPUs 8-15. Hash and token collection after the timed window; output has a hard-link alias to match Cargo replacing its prior output, and each trial streams report the previous ELF independently; the previous output is aliased so Wild follows its ordinary replacement route.', 'source_sha256':digest(p/'v3.patch'),'binaries':{a:{'path':str(b),'sha256':digest(b)} for a,b in bins.items()},'inputs_manifest_sha256':digest(root/'inputs.json'),'intake':cs,'primary_bundle':idx,'cohorts':cohorts,'acceptance':'Both independent order schedules must pass two-sided exact sign and position-randomization p <= 0.05, improve paired geometric wall time by >=8%, preserve every physical byte identity by multiset, and produce one of the two whole-file SHA256 values independently demonstrated on both stock distributed -18 and #46; those files differ at exactly the 32 GNU-ID bytes and one .rodata.sh_entsize byte. Report whole-file original parity separately. Before each event clock starts, observe the actual Wild fork child has exactly two threads (implicit one-worker Rayon pool plus main); original arms must never take later tokens and scoped arm must visibly borrow at least two. This repairs the earlier strict attempt that stopped on an incompletely initialized baseline process. Fixed-affinity isolated replay; no actual whole-command effect inferred. No retries or exclusions. Shape/failure controls are reported separately, with no native performance inference.','script_sha256':digest(Path(__file__))}
 assert not (root/'plan.json').exists();write(root/'plan.json',plan);print('registered',digest(root/'plan.json'),flush=True)
def populated_pool(pid):
 try:
  children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
  if not children:return None
  assert len(children)==1,children
  child=int(children[0]);threads=len(tuple(Path(f'/proc/{child}/task').iterdir()))
  if threads>1:
   assert threads==2,(child,threads)
   return child
 except FileNotFoundError:pass
 return None
def stock_family(value):
 return value in ('0b1e9f9f0f2f037c1e19f707e40ee7991bc5ed0a1d05c9d92639f9d8a193746d','62d23ad7e901961af6e003e5d179d3058e728af86a42e60e4b82da770a5a844b')
def avail(r):
 q=array.array('i',[0]);fcntl.ioctl(r,termios.FIONREAD,q,True);return q[0]
def run(arm,idx,initial,returns,explicit,label,logdetails=False):
 plan=read(root/'plan.json');row=plan['intake'][str(idx)];rec=read(root/f'argv-{idx}.json');argv=rec['args'];out=root/'linked-output';alias=root/'linked-alias'
 if alias.exists():alias.unlink()
 if out.exists():os.link(out,alias)
 argv[argv.index('-o')+1]=str(out)
 if explicit:argv+=['--threads='+str(explicit)]
 r,wr=os.pipe();allbytes=b'7654321';given=initial
 if given:os.write(wr,allbytes[:given])
 env=env0|rec['env']|{'CARGO_MAKEFLAGS':f'-j --jobserver-auth={r},{wr}'}
 if logdetails:env['WILD_LOG']='jobserver=trace'
 synchronized=label.startswith(('cohort','admit'))
 ready_ms=None;pool_pid=None; samples=[];i=0;directory=root/label;directory.parent.mkdir(parents=True,exist_ok=True);log=directory.with_suffix('.log')
 with log.open('xb') as stream:
  begin=time.monotonic_ns();process=subprocess.Popen([bins[arm],*argv],env=env,stdout=stream,stderr=stream,pass_fds=(r,wr));pidfd=os.pidfd_open(process.pid);poll=select.poll();poll.register(pidfd,select.POLLIN)
  while True:
   ms=(time.monotonic_ns()-begin)/1e6
   if ms>45_000:process.kill();raise TimeoutError(label)
   if synchronized and ready_ms is None:
    pool_pid=populated_pool(process.pid)
    if pool_pid is not None:ready_ms=ms
   schedule_ms=ms-(ready_ms if ready_ms is not None else float('inf')) if synchronized else ms
   while i<len(returns) and schedule_ms>=returns[i][0]:
    n=returns[i][1];os.write(wr,allbytes[given:n]);given=n;i+=1
   left=avail(r)
   if not samples or [left,given]!=samples[-1][1:]:samples.append([round(ms,3),left,given])
   if poll.poll(1):break
  wall=(time.monotonic_ns()-begin)/1e6;os.close(pidfd);status=process.wait();assert status==0,(label,status,log)
 total=returns[-1][1] if returns else initial
 if given<total:os.write(wr,allbytes[given:total])
 limit=time.monotonic()+15
 while avail(r)!=total and time.monotonic()<limit:time.sleep(.002)
 assert avail(r)==total,(label,'missing tokens',avail(r),total)
 restored=os.read(r,total) if total else b'';os.close(r);os.close(wr);assert sorted(restored)==sorted(allbytes[:total])
 sha=digest(out);result={'label':label,'arm':arm,'bundle':idx,'initial':initial,'returns':returns,'explicit_threads':explicit,'wall_ms':wall,'pipe_observations_ms_free_given':samples,'original_token_bytes':allbytes[:total].hex(),'restored_bytes':restored.hex(),'output':sha,'pool_ready_ms':ready_ms,'pool_pid':pool_pid,'stock_artifact_family':stock_family(sha),'original':row['sha256'],'bytes':out.stat().st_size,'identical_to_original':sha==row['sha256'],'diagnostic_sha256':digest(log)}
 if synchronized:
  assert ready_ms is not None and pool_pid is not None and i==len(returns),label
  if arm in ('shipped','parent'):assert all(free==n for _,free,n in samples),(label,samples)
  else:assert any(n-free>=2 for _,free,n in samples),(label,samples)
 write(directory.with_suffix('.json'),result);print(label,round(wall),sha[:12],result['identical_to_original'],samples,flush=True);return result
def controls():
 plan=read(root/'plan.json');cs=plan['intake'];idx=plan['primary_bundle'];rel=plan['cohorts'][1]['schedule']
 # Before scoring, admit native replay integrity. For fixtures outside the primary endpoint,
 # establish exact same-concurrency artifacts in shipped, matched source parent and candidate.
 for i,row in cs.items():
  healthy=6 if row['original'].endswith('uv-7244341c90b6d7a6') else 0
  r=[run(a,i,healthy,[],0,f'controls/oracle-{i}-{a}') for a in ('shipped','parent','refresh')]
  assert len({v['output'] for v in r})==1,(i,'matched concurrency',[(v['arm'],v['output']) for v in r])
  if i==idx:assert all(v['identical_to_original'] for v in r)
 for tag,initial,ret,explicit in [('j1',0,[],0),('one-extra',0,[[100,1]],0),('explicit',0,rel,1),('all-initial',7,[],0)]:
  rs=[run(a,idx,initial,ret,explicit,f'controls/{tag}-{a}',True) for a in ('parent','refresh')]
  assert rs[0]['output']==rs[1]['output']
 # Prime the output inode and filesystem cache with the exact primary artifact for both cohorts.
 z=run('parent',idx,0,[],0,'controls/prime');assert z['identical_to_original']
def calc(cohort,raw):
 pairs=[raw[i*2:i*2+2] for i in range(len(raw)//2)];effects=[];pos=[]
 for pair in pairs:
  v={r['arm']:r for r in pair};effects.append(math.log(v['parent']['wall_ms']/v['refresh']['wall_ms']));pos.append(math.log(pair[0]['wall_ms']/pair[1]['wall_ms']))
 E=sum(effects)/len(effects);n=len(effects);win=sum(e>0 for e in effects);tail=sum(math.comb(n,i) for i in range(min(win,n-win)+1));ps=min(1,2*tail/2**n)
 axes=[]
 for group in combinations(range(n),n//2):
  A=set(group);axes.append(sum(v if i in A else -v for i,v in enumerate(pos))/n)
 pord=sum(abs(v)>=abs(E)-1e-12 for v in axes)/len(axes);red=1-math.exp(-E)
 return {'orders':cohort['orders'],'pairs':n,'parent_ms_geomean':statistics.geometric_mean(r['wall_ms'] for r in raw if r['arm']=='parent'),'refresh_ms_geomean':statistics.geometric_mean(r['wall_ms'] for r in raw if r['arm']=='refresh'),'geomean_reduction':red,'wins':win,'sign_p_two_sided':ps,'balanced_position_permutation_p_two_sided':pord,'all_original_bytes':all(r['identical_to_original'] for r in raw),'full_bytes_original_trials':sum(r['identical_to_original'] for r in raw),'all_stock_family':all(r['stock_artifact_family'] for r in raw),'all_tokens_returned':all(sorted(bytes.fromhex(r['restored_bytes']))==sorted(bytes.fromhex(r['original_token_bytes'])) for r in raw),'qualified':ps<=.05 and pord<=.05 and red>=.08 and all(r['stock_artifact_family'] for r in raw)}
def trials():
 plan=read(root/'plan.json');idx=plan['primary_bundle'];rows=[];summaries=[]
 with (root/'samples.csv').open('x') as csvfile:
  cols=['cohort','block','position','label','arm','wall_ms','output','identical_to_original','restored_bytes'];writer=csv.DictWriter(csvfile,fieldnames=cols,extrasaction='ignore');writer.writeheader()
  for c,cohort in enumerate(plan['cohorts']):
   cr=[]
   for i,ords in enumerate(cohort['orders']):
    for pos,arm in enumerate(ords):
     r=run(arm,idx,0,cohort['schedule'],0,f'cohort{c}/block-{i}-{pos}-{arm}');cr.append(r);rows.append(r);writer.writerow(r|{'cohort':c,'block':i,'position':pos});csvfile.flush();assert r['stock_artifact_family']
   summaries.append(calc(cohort,cr));write(root/f'cohort{c}/summary.json',summaries[-1])
 write(root/'summary.json',{'cohorts':summaries,'qualified':all(r['qualified'] for r in summaries)})
def admit():
 plan=read(root/'plan.json')
 for i,c in enumerate(plan['cohorts']):
  for arm in ('shipped','parent','refresh'):
   record=run(arm,plan['primary_bundle'],0,c['schedule'],0,f'admit/schedule-{i}-{arm}');assert record['stock_artifact_family']
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('action',choices=['intake','register','controls','admit','trials']);args=parser.parse_args();{'intake':make_intake,'register':register,'controls':controls,'admit':admit,'trials':trials}[args.action]()
