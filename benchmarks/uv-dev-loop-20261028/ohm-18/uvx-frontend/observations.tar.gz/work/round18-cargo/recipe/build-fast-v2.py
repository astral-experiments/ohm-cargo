#!/usr/bin/env python3
"""Produce matched release-style Cargo drivers with uninstrumented, source-built std."""
import hashlib, json, os, re, shutil, subprocess, time
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from prepare import digest, tree
D=Path(__file__).resolve().parents[1]; W=D.parent
cfg=json.loads((D/'inputs.json').read_text());B=Path(cfg['scratch']);tool=Path(cfg['toolchain'])/'bin';host='x86_64-unknown-linux-gnu'
assert set(os.sched_getaffinity(0))==set(range(16,24))
resume=sys.argv[1:]==['--resume-compiled-base'];assert resume or len(sys.argv)==1
lab=B/'fast';lab.mkdir(mode=0o700,exist_ok=resume); out=D/'fast';out.mkdir(exist_ok=resume); bins=out/'bin';bins.mkdir(exist_ok=resume);cache=lab/'cargo-home';cache.mkdir(mode=0o700,exist_ok=resume)
if resume:
    assert (bins/'.base.next').is_file() and not (bins/'base').exists() and not (out/'guard-stack').exists()
else:subprocess.run(['cp','-a','--reflink=auto',Path(cfg['build_registry'])/'registry',cache/'registry'],check=True)
started=time.monotonic();results={}
baseenv={k:v for k,v in os.environ.items() if k not in ('RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','LLVM_PROFILE_FILE') and not k.startswith(('CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','OHM_'))}
env=dict(baseenv,PATH=str(tool)+':'+baseenv['PATH'],RUSTC=str(tool/'rustc'),RUSTDOC=str(tool/'rustdoc'),CARGO_HOME=str(cache),CARGO_TARGET_DIR=str(lab/'target'),__CARGO_TESTS_ONLY_SRC_ROOT=str(lab/'library'),CARGO_PROFILE_RELEASE_LTO='thin',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_DEBUG='false',CARGO_PROFILE_RELEASE_INCREMENTAL='false',CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS='false',CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='false',CARGO_NET_OFFLINE='true',LIBZ_SYS_STATIC='1',CARGO_TERM_COLOR='never',CFG_RELEASE='1.99.0-dev',CFG_RELEASE_CHANNEL='dev',CFG_VER_DESCRIPTION=cfg['release'])
cmd=[tool/'cargo','-Zohm-defaults=no','-Zbuild-std','build','--target',host,'--release','--offline','--locked','--bin','cargo','--features','ohm-defaults,all-static','-j8','-vv']
for arm in ('base','guard-stack'):
    reuse=resume and arm=='base'
    dest=out/arm;dest.mkdir(exist_ok=reuse); park=lab/arm;park.mkdir(exist_ok=reuse); begin=time.monotonic();src=lab/'cargo-src'; library=lab/'library'
    for origin,to in [(Path(cfg['source'])/arm,src),((Path(cfg['toolchain'])/'lib/rustlib/src/rust/library') if arm=='base' else B/'guarded-std/library',library)]:
        if reuse:assert to.is_dir()
        else:
            assert not to.exists();subprocess.run(['cp','-a','--reflink=auto',origin,to],check=True)
    assert tree(src)==cfg['cargo_trees'][arm]
    assert digest(library/'std/src/path.rs')==cfg['std_path_sha256'][arm]
    assert digest(library/'std/tests/path.rs')==cfg['std_path_test_sha256'][arm]
    if reuse:
        assert 'Finished `release` profile [optimized] target(s)' in (dest/'build.log').read_text()
    else:
        assert not (lab/'target').exists()
        with (dest/'build.log').open('x') as f:subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    binary=lab/'target'/host/'release/cargo';staged=bins/('.'+arm+'.next')
    if reuse:assert digest(binary)==digest(staged)
    else:shutil.copy2(binary,staged)
    version=subprocess.check_output([staged,'-Vv'],text=True);assert cfg['cargo_pin'] in version
    names=subprocess.check_output(['nm','-S','-C',staged],text=True);symbol=re.search(r'^([0-9a-f]+) ([0-9a-f]+) [Tt] std::path::compare_components$',names,re.M);assert symbol
    addr,length=[int(v,16) for v in symbol.groups()];asm=subprocess.check_output(['objdump','-dC',f'--start-address={addr}',f'--stop-address={addr+length}',staged],text=True);(dest/'compare_components.asm').write_text(asm)
    words=re.findall(r'\b(?:tzcnt|bsf)[a-z]*\b',asm);assert bool(words)==(arm=='guard-stack'),(arm,words)
    actual=set()
    for line in (dest/'build.log').open():
        if '--crate-name cargo ' not in line:continue
        actual.update(re.findall(r'(?<![a-zA-Z])std=([^\s\x27\x22]+?\.rlib)\b',line))
    assert actual, 'missing cargo --extern std link records';rlibs=[Path(f) for f in actual];stds={digest(f) for f in rlibs};assert len(stds)==1
    graph=set()
    for line in (dest/'build.log').open():
        m=re.search(r'/rustc[\x27\x22]? --crate-name (\w+)',line)
        if m:graph.add(m.group(1))
    assert {'cargo','std','core','alloc'}<=graph
    result=dict(cargo_sha256=digest(staged),elapsed_s=time.monotonic()-begin,compiler_version=version,source_tree=cfg['cargo_trees'][arm],std_rlib_sha256=stds.pop(),linked_std_rlibs=sorted(actual),std_path_source_sha256=cfg['std_path_sha256'][arm],std_path_test_sha256=cfg['std_path_test_sha256'][arm],word_scans=words,crate_names=sorted(graph),ldd=subprocess.check_output(['ldd',staged],text=True),command=[str(x) for x in cmd],cpus=sorted(os.sched_getaffinity(0)))
    if reuse:
        m=re.search(r'Finished `release` profile \[optimized\] target\(s\) in (?:(\d+)m )?([\d.]+)s',(dest/'build.log').read_text());assert m
        result['elapsed_s']=60*int(m[1] or 0)+float(m[2]);result['recovered_completed_build']=True
    for old in (lab/'target',src,library):old.rename(park/old.name)
    staged.chmod(0o555);staged.replace(bins/arm);results[arm]=result;(dest/'ready.json').write_text(json.dumps(result,indent=2)+'\n');print('ready',arm,digest(bins/arm),flush=True)
assert results['base']['std_rlib_sha256']!=results['guard-stack']['std_rlib_sha256']
(out/'audit.json').write_text(json.dumps({'arms':results,'elapsed_s':time.monotonic()-started},indent=2)+'\n')
