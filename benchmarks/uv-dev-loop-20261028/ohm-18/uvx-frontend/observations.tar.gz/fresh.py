"""Comparable fresh-host wall replay. Never uses or substitutes for the original coordinator grants."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

PACK=Path(__file__).resolve().parent
V2=PACK/"work/round18-compiler/small-frontend-screen/observer-v2"
sys.path.insert(0,str(V2))
import verifier as v
import worker
s=v.s
direct=v.direct
UV="c22e6b71933443e9cd299d4b6ac8de035ed4825b"
ROLES=s.ROLES


def tools(prefix):
    expected=s.read(V2/"physical-host-return.json")["released_tool_slots"]
    for rel,h in expected.items():
        s.require(s.sha(prefix/rel)==h,"install the exact official -18 Cargo/rustc/Wild: "+rel)
    return expected


def safe_root(root):
    dist=Path(s.read(V2/"grants/direct-wall-initial.json")["release"]).parents[2]
    old=Path((PACK/"work/bench-home.path").read_text().strip())
    s.require(not root.is_relative_to(old) and not root.is_relative_to(dist) and not root.is_relative_to(PACK),
              "supply a new external disposable checkout root, never the original benchmark or packet")
    s.require(root.is_absolute() and (root/"uv/.git").exists(),"fresh root must contain its own uv checkout")
    s.require(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root/"uv",text=True).strip()==UV,"unexpected uv checkout")
    s.require(not subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=root/"uv"),
              "tracked uv contents already differ")
    for rel in (s.SOURCE,Path("Cargo.lock")):s.require(s.sha(root/"uv"/rel)==s.sha(PACK/"work/uv"/rel),"unexpected cloned inputs")


def parse_exec(path):
    for f in path.glob("exec.*"):
        for line in f.read_text().splitlines():
            if not line.startswith("execve(") or not line.endswith("= 0"):continue
            decoder=json.JSONDecoder()
            executable,index=decoder.raw_decode(line[len("execve("):])
            rest=line[len("execve(")+index:]
            if not rest.startswith(", "):continue
            yield Path(executable),rest[2:],f


def capture(root,label,prefix,home):
    safe_root(root);stock=tools(prefix)
    out=root/"fresh-capture";target=root/"target";donor=root/"r18-four/shipped"
    s.require(not out.exists() and not target.exists() and not donor.exists(),"fresh capture is single-shot")
    out.mkdir();(out/"home").mkdir()
    project=root/"uv";source=project/s.SOURCE
    original=source.read_bytes();stat=source.stat();lock=s.sha(project/"Cargo.lock")
    env={"PATH":str(prefix/"bin")+":/usr/local/bin:/usr/bin:/bin","HOME":str(out/"home"),"CARGO_HOME":str(home),
         "CARGO_TARGET_DIR":str(target),"RUSTC":str(prefix/"bin/rustc"),"RUSTDOC":str(prefix/"bin/rustdoc"),
         "CARGO_TERM_COLOR":"never","CARGO_NET_OFFLINE":"true","LANG":"C.UTF-8","LC_ALL":"C.UTF-8","TZ":"UTC"}
    collected={}
    try:
        for phase in ("warm","capture"):
            for ep in ("build","test"):
                path=out/(phase+"-"+ep);path.mkdir()
                cargo=[str(prefix/"bin/cargo"),ep,*(["--no-run"] if ep=="test" else []),"--locked","--offline","-j8"]
                argv=cargo
                if phase=="capture":
                    cargo.append("-vv")
                    source.write_bytes(s.changed(original,label,s.tag(label,ep,998)))
                    argv=["strace","-ff","-qq","-s","2048","-e","trace=execve,execveat","-o",str(path/"exec"),*cargo]
                with (path/"cargo.log").open("xb") as log:
                    subprocess.run(argv,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
                if phase=="warm":continue
                seen={};links=[]
                for exe,tail,f in parse_exec(path):
                    if exe.name in ("ld.bfd","wild") and exe.is_file() and exe.samefile(prefix/s.LINK):
                        links.append(s.sha(f))
                    if exe!=prefix/"bin/rustc" or '"--crate-name", "uvx"' not in tail:continue
                    args,_=json.JSONDecoder().raw_decode(tail)
                    s.require(args[0]==str(exe) and args.count(str(s.SOURCE))==1 and args.count("-Zthreads=8")==1 and
                              "-Zthreads=1" not in args and "--out-dir" in args and "--emit=dep-info,link" in args,
                              "unexpected normal binary compiler vector")
                    role="test-harness" if "--test" in args else ("test-bin" if ep=="test" else "build-bin")
                    s.require(role not in seen,"duplicate compiler role")
                    seen[role]={"argv":args,"argv_sha256":direct.sha_args(args),"raw":str(f.relative_to(out)),"raw_sha256":s.sha(f)}
                s.require(set(seen)==({"build-bin"} if ep=="build" else {"test-bin","test-harness"}) and bool(links),
                          "missing actual uvx compiler role or shipped Wild")
                collected.update(seen)
    finally:
        source.write_bytes(original);os.utime(source,ns=(stat.st_atime_ns,stat.st_mtime_ns))
    s.require(s.sha(source)==s.sha(s.ORIGINAL) and s.sha(project/"Cargo.lock")==lock,"source or lock changed")
    donor.parent.mkdir(exist_ok=True);target.rename(donor)
    s.save(out/"done.json",{"cohort":label,"stock":stock,"uv":UV,"source_sha256":s.sha(source),"lock_sha256":lock,
                           "donor":str(donor),"cpus":sorted(os.sched_getaffinity(0)),"roles":collected})


def host():
    cpus={f"cpu{x}" for x in os.sched_getaffinity(0)}
    rows=[list(map(int,l.split()[1:9])) for l in Path("/proc/stat").read_text().splitlines() if l.split()[0] in cpus]
    mem={x.split()[0][:-1]:int(x.split()[1]) for x in Path("/proc/meminfo").read_text().splitlines()}
    live=[]
    for p in Path("/proc").glob("[0-9]*/stat"):
        try:stat=p.read_text()
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        end=stat.rfind(")");name=stat[stat.find("(")+1:end]
        if stat[end+2:].split()[0] in ("Z","X"):continue
        if name in {"cargo","rustc","drrun","wild","ld","ld.bfd","ld.lld","rust-lld","clang","cc1","ninja","valgrind","llvm-profdata"}:
            live.append([int(p.parent.name),name])
    return {"cpu":list(map(sum,zip(*rows))),"dirty":mem["Dirty"],"writeback":mem["Writeback"],"live":live}


def quiet(path):
    require=s.require;start=time.monotonic();ok=0
    with path.open("x") as f:
        while ok<2:
            require(time.monotonic()-start<600,"quiet host gate did not open within ten minutes")
            a=host();time.sleep(5);b=host();diff=[y-x for x,y in zip(a["cpu"],b["cpu"])]
            busy=1-(diff[3]+diff[4])/sum(diff);wait=diff[4]/sum(diff)
            clean=busy<.05 and wait<.02 and b["dirty"]<65536 and b["writeback"]<8192 and not b["live"]
            ok=ok+1 if clean else 0;print(json.dumps([time.time_ns(),busy,wait,b["dirty"],b["writeback"],b["live"],ok]),file=f,flush=True)


def replay(root,label,prefix):
    safe_root(root);stock=tools(prefix);s.TOOLS=prefix
    capture_dir=root/"fresh-capture";cap=s.read(capture_dir/"done.json")
    s.require(cap["cohort"]==label and cap["stock"]==stock and cap["uv"]==UV and set(cap["roles"])==set(ROLES),"wrong capture")
    s.require(len(os.sched_getaffinity(0))==16 and shutil.disk_usage(root).free>5*(1<<30),"use 16 available logical CPUs and at least 5 GiB beyond the warm donor")
    stage=root/"fresh-replay";s.require(not stage.exists(),"fresh replay already attempted");stage.mkdir()
    for n in ("home","tmp"):(stage/n).mkdir()
    srcroot=stage/"uv";source=srcroot/s.SOURCE;source.parent.mkdir(parents=True)
    schedule=s.read(V2.parent/"schedule.json")["direct-wall"][label]
    all_results={}
    for role in ROLES:
        cell=stage/role;cell.mkdir();active=cell/"active"
        for arm in s.DIRECT:
            for part in ("inc","out"):(cell/arm/part).mkdir(parents=True)
        original=cap["roles"][role];args=original["argv"]
        s.require(s.sha(capture_dir/original["raw"])==original["raw_sha256"] and direct.sha_args(args)==original["argv_sha256"],"captured argv changed")
        variants={a:direct.relocate(args,root,active,a=="one",validate=True) for a in s.DIRECT}
        s.save(cell/"argv.json",variants);quiet(cell/"quiet.jsonl")
        ep="build" if role=="build-bin" else "test"
        for phase,i,order in [("cold",990,s.DIRECT),("settle",991,s.DIRECT[::-1]),("admit",992,s.DIRECT),
                *[("trial",j,arms) for j,arms in enumerate(schedule[role])],("post",999,s.DIRECT[::-1])]:
            tag=s.tag(label,ep,i);data=s.changed(s.ORIGINAL.read_bytes(),label,tag);source.write_bytes(data);prods={}
            for rank,arm in enumerate(order):
                parked=cell/arm;parked.rename(active)
                try:
                    av=variants["eight" if phase=="cold" else arm];log=cell/f"{phase}-{i:03}-{rank}-{arm}.log"
                    row=worker.execute(av,srcroot,stage,"wall",log)
                    row.update(block=i,rank=rank,arm=arm,literal=tag,source_sha256=s.hbytes(data))
                    v.checked_observer(row,s.read(log.with_suffix(".observer.json")),s.sha(log),s.sha(log.with_suffix(".observer.json")),
                                       s.hbytes(data),direct.sha_args(av),(i,rank,arm,tag))
                    if phase in ("admit","post"):prods[arm]=direct.product(av,active,label,tag,role,stage)
                    with (cell/(phase+".jsonl")).open("a") as f:print(json.dumps(row),file=f)
                finally:active.rename(parked)
            if prods:
                s.require(all(prods["one"][k]==prods["eight"][k] for k in ("raw_sha256","dep_sha256","size")),"products differ")
                s.save(cell/(phase+"-products.json"),prods)
        rows=[json.loads(x) for x in (cell/"trial.jsonl").read_text().splitlines()]
        ci=s.COHORTS.index(label);ri=s.ROLES.index(role)
        result=v.score.compare(v.score.assigned(rows,schedule[role]),"eight","one",9100+ci*100+ri)
        all_results[role]={"statistics":result,"passed":v.score.passes(result,True),"rows_sha256":s.sha(cell/"trial.jsonl")}
    s.save(stage/"done.json",{"comparable_only":True,"cohort":label,"roles":all_results,"stock":stock,"uv":UV})
    print(json.dumps(all_results,sort_keys=True,indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("capture","replay"));parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--cohort",choices=s.COHORTS,required=True);parser.add_argument("--toolchain",type=Path,required=True)
    parser.add_argument("--cargo-home",type=Path,help="prepared registry/Git cache, required for capture")
    args=parser.parse_args();root=args.root.resolve();prefix=args.toolchain.resolve()
    if args.action=="capture":
        s.require(args.cargo_home and args.cargo_home.is_dir(),"provide the Cargo cache for offline warming")
        capture(root,args.cohort,prefix,args.cargo_home.resolve())
    else:replay(root,args.cohort,prefix)
