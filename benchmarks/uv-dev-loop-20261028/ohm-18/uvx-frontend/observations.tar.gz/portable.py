"""Independently rebuild the frozen direct wall/count result and validate the compact evidence packet."""
import argparse
import collections
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
WORK=ROOT/"work"
V2=WORK/"round18-compiler/small-frontend-screen/observer-v2"
def digest(path):
    with path.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def decode(path):return json.loads(path.read_text())
def canonical(obj):return json.dumps(obj,indent=2,sort_keys=True)+"\n"
def require(x,desc):
    if not x:raise ValueError(desc)


def deny_external_inputs():
    scratch=Path((WORK/"bench-home.path").read_text().strip())
    rel=Path(decode(V2/"grants/direct-wall-initial.json")["release"])
    former_workspace=rel.parents[2]
    require(not ROOT.is_relative_to(former_workspace) and not ROOT.is_relative_to(scratch),
            "extract outside the prior workspace and its scratch to exercise independent isolation")
    def guard(event,args):
        if event in ("subprocess.Popen","os.posix_spawn","os.system","os.fork","os.exec","os.forkpty"):
            raise RuntimeError("standalone analysis forbids starting other programs")
        if event in ("open","os.listdir","os.scandir") and args and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.path.abspath(os.fsdecode(args[0])))
            if p.is_relative_to(scratch) or p.is_relative_to(former_workspace):
                raise RuntimeError("unexpected access to the original host input: "+str(p))
    sys.addaudithook(guard)


def verify_manifest():
    listed=set()
    manifest=ROOT/"SHA256SUMS"
    for line in manifest.read_text().splitlines():
        checksum,name=line.split("  ",1)
        p=ROOT/name
        require(not Path(name).is_absolute() and ".." not in Path(name).parts and not p.is_symlink()
                and p.is_file() and name not in listed and digest(p)==checksum,"input checksum mismatch: "+name)
        listed.add(name)
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
    require(actual==listed|{"SHA256SUMS"},"unlisted or missing packet file")


def verify_tool_capture(origs):
    d=decode(WORK/"round18-compiler/small-frontend-audit/uvx-traces.json")
    count=0
    for k,rows in d.items():
        for row in rows:
            raw=WORK/row["raw"]
            require(digest(raw)==row["raw_sha256"],"source strace hash changed")
            count+=1
    require(count==16,"missing independent release argv captures")
    for mode in ("wall","count"):
        for cohort in ("initial","replica"):
            p=V2/"grants"/f"direct-{mode}-{cohort}.json"
            g=decode(p);release=WORK/"round18-lab"/Path(g["release"]).name
            require(digest(release)==g["release_sha256"] and decode(release)["competing_tool_processes"]==[] and
                    tuple(g["cpus"])==tuple(range(16)),"host grant/foreign process mismatch")
    require(origs["original_registration_sha256"]==digest(V2.parent/"registration.json")
            and origs["observer_amendment_sha256"]==digest(V2/"amendment.json"),"wrong frozen scope")


def derived(combined):
    tests={};sheet=io.StringIO();writer=csv.writer(sheet,lineterminator="\n")
    writer.writerow(["cohort","compiler_role","native_pairs","wins_one","wins_eight","median_saved_ms","rank95_lo_ms","rank95_hi_ms",
                     "median_saved_pct","raw_order_randomization_one_sided_p","count_pairs","count_pairs_one_fewer","median_instruction_saving_pct","all_gates"])
    for cohort in ("initial","replica"):
        tests[cohort]={}
        for role in ("build-bin","test-bin","test-harness"):
            cell=combined["cohorts"][cohort][role];v=cell["native"];c=cell["count"]
            gate={"at_least_8_ms":v["median_saved_ms"]>=8,"at_least_1_percent":v["median_saved_pct"]>=1,
                "positive_rank95_lower_bound_ms":v["median_saved_ms_interval"]["lower"]>0,
                "positive_in_both_execution_orders":min(v["median_saved_pct_by_order"].values())>0,
                "conditional_raw_median_p_at_most_0_05_over_3":v["raw_paired_median_one_sided_conditional_mc_p"]<=.05/3,
                "one_sided_sign_p_at_most_0_05":v["one_sided_sign_p"]<=.05,
                "one_sided_position_conditioned_direction_p_at_most_0_05":v["one_sided_conditional_direction_p"]<=.05}
            require(all(gate.values())==cell["passed"] and v["n"]==48 and c["pairs"]==8,"wrong role gate")
            tests[cohort][role]=gate
            writer.writerow([cohort,role,v["n"],v["wins"],v["losses"],v["median_saved_ms"],v["median_saved_ms_interval"]["lower"],
                v["median_saved_ms_interval"]["upper"],v["median_saved_pct"],v["raw_paired_median_one_sided_conditional_mc_p"],
                c["pairs"],c["positive_pairs"],c["median_saved_pct"],cell["passed"]])
    gateout={"role_requirements":tests,"replicated_roles":combined["replicated_roles"],"material_loss_vetoes":combined["material_losses"],
             "direct_native_selected":combined["eligible"],"counts_are_diagnostic":True,"whole_Cargo_measurements_in_packet":0}
    return gateout,sheet.getvalue()


def observers():
    totals={};percohort={}
    for mode in ("wall","count"):
        percohort[mode]={}
        for cohort in ("initial","replica"):
            percohort[mode][cohort]={}
            for role in ("build-bin","test-bin","test-harness"):
                path=V2/"observed"/("direct-"+mode)/cohort/role
                obs=[decode(p) for p in path.glob("*.observer.json")]
                require(len(obs)==(104 if mode=="wall" else 24),"wrong observer count")
                require(all(o["accepted"] and o["foreground_exit"]==0 and o["final_token_count"]==7 and
                    o["after_drain_available"]==0 and not o["final_live_owned"] and
                    o["returned_tokens_hex"]=="2b"*7 for o in obs),"invalid token/process return")
                row={"all_observers":len(obs),"all_seven_physical_tokens_returned":True,"live_owned_at_final":0,
                     "foreground_token_counts":dict(sorted(collections.Counter(str(o["foreground_token_count"]) for o in obs).items()))}
                if mode=="count":
                    timed=[json.loads(x) for x in (path/"trial.jsonl").read_text().splitlines()]
                    row["count_rows"]=len(timed)
                    row["thread_stream_count_by_arm"]={a:dict(sorted(collections.Counter(str(len(r["threads"]))
                         for r in timed if r["arm"]==a).items())) for a in ("one","eight")}
                    require(all(sum(r["threads"].values())==r["instructions"]>0 for r in timed),"invalid thread sum")
                percohort[mode][cohort][role]=row
        totals[mode]=sum(z["all_observers"] for co in percohort[mode].values() for z in co.values())
    native=decode(V2/"physical-host-return.json");counter=decode(V2/"physical-counter-return.json")
    require(totals=={"wall":624,"count":144} and native["host_returned"] and counter["host_returned"] and
            counter["native_physical_return_sha256"]==digest(V2/"physical-host-return.json") and
            native["native_lease_reacquired_then_released"] and counter["native_lease_reacquired_and_released"] and
            not counter["live_owned_processes"] and not counter["live_global_compiler_linker_dbi"],"incomplete physical custody")
    return {"observed_all":totals,"timed_native_rows":576,"counted_rows":96,"cohorts":percohort}


def calculate():
    sys.path.insert(0,str(V2))
    import verifier
    # These are the original frozen decoder, assignment, randomization and gate functions.
    actual=verifier.direct_result(True)
    # Convert to wire types so an empty Python tuple/list distinction cannot affect a receipt.
    actual=json.loads(canonical(actual))
    require(actual==decode(V2/"combined-result.json"),"combined result does not reproduce archived bytes")
    wall=decode(V2/"native-wall-score.json")
    require(wall["eligible"]==actual["eligible"] and wall["material_losses"]==actual["material_losses"] and
            wall["replicated_roles"]==actual["replicated_roles"],"native result changed after counters")
    for c in actual["cohorts"]:
        for role,x in actual["cohorts"][c].items():
            require({k:v for k,v in x.items() if k!="count"}==wall["cohorts"][c][role],"native data drift")
    verify_tool_capture(actual)
    gates,sheet=derived(actual)
    return {"gate-breakdown.json":canonical(gates),"observer-summary.json":canonical(observers()),"results.csv":sheet}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--deny-recorded-host",action="store_true")
    parser.add_argument("--emit",action="store_true",help="for initial archive assembly, before the manifest is written")
    args=parser.parse_args()
    sys.dont_write_bytecode=True
    if args.deny_recorded_host:deny_external_inputs()
    if not args.emit:verify_manifest()
    for name,result in calculate().items():
        p=ROOT/name
        if args.emit:
            with p.open("x") as f:f.write(result)
        else:require(p.read_text()==result,"summary differs: "+name)
    print("Verified 16 original compiler argv captures, 576 elapsed compiler rows, 96 per-thread instruction rows, 768 completed observer checks and all six frozen role gates.")
