"""Exercise fresh-host parsing and relocation against six real recorded released argv. No processes are started."""
import sys
import json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fresh import direct, s, parse_exec, V2

catalog=s.read(s.AUDIT/"uvx-traces.json")
for label in s.COHORTS:
    for role in s.ROLES:
        ep="build" if role=="build-bin" else "test"
        row,=[r for r in catalog[f"{label}/{ep}/admission"] if r["harness"]==(role=="test-harness")]
        trace=s.WORK/row["raw"]
        args,=[json.JSONDecoder().raw_decode(tail)[0] for exe,tail,f in parse_exec(trace.parent)
               if exe==s.TOOLS/"bin/rustc" and f==trace and '"--crate-name", "uvx"' in tail]
        assert args==direct.captured(label,role) and direct.sha_args(args)==row["argv_sha256"]
        assert args.count(str(s.SOURCE))==1 and args.count("-Zthreads=8")==1 and "-Zthreads=1" not in args
        assert "--emit=dep-info,link" in args and ("--test" in args)==(role=="test-harness")
        active=s.SCRATCH/"direct-wall"/label/role/"active"
        inferred={a:direct.relocate(args,s.fixture(label),active,a=="one",validate=False) for a in s.DIRECT}
        assert inferred==s.read(V2/"observed/direct-wall"/label/role/"argv.json")
print("Reconstructed all 6 release role captures and all 12 wall argv vectors from raw execve input.")
