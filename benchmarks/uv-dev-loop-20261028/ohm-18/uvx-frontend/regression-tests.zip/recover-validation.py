"""Complete custody after the preserved successful suite and false line-boundary rejection."""
import inspect
import json
import os
from pathlib import Path
import runpy
import shutil
import sys


BASE = Path(__file__).resolve().parent
S = runpy.run_path(str(BASE / "test-custody.py"))
C = S["package"].__globals__
R, OUT, ROOT = C["RELEASE"], C["OUT"], C["PRIVATE"]
sha, require = R["sha"], R["require"]
REG = json.loads((BASE / "custody-registration.json").read_bytes())
ERROR = "RuntimeError: missing real compiler invocation for rustflags::ohm_parallel_frontend_user_flags_take_precedence"


def derive():
    for name, value in REG["files_sha256"].items():
        require(sha(BASE/name) == value, name)
    require(sha(BASE/"custody-registration.json") == "13dcf15f8efb700cbafafff5004a0ad6c828397b5164c67b7caafb152f56ad26", "registration")
    run = S["read"]("runner-return.json")
    require(run["exit"] == 1 and run["protected_unchanged"], "unexpected validator disposition")
    require((OUT/"runner.log").read_text().rstrip().endswith(ERROR), "unexpected rejection")
    live = S["read"]("session.json")
    require(live["host_grant_sha256"] == "2deca4ca203eaf37d04d2226a5b43c34fdd61387ed528de1bd1e7e95fb9df7c1", "host grant")
    require(live["host_boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip(), "new host session")
    require(not any(Path("/proc",str(a["pid"])).exists() for a in live["actors"]), "original supervisor must have returned")
    R["verify_sources"]()
    commands = json.loads((ROOT/"command.json").read_bytes())
    require(commands["argv"] == R["COMMAND"], "original command")
    log = ROOT/"test.log"
    text = log.read_text()
    require(R["passed"](text), "all three exact non-ignored tests must be green")
    binaries = {}
    for line in text.splitlines():
        if not line.startswith('{"reason":"compiler-artifact",'):
            continue
        row = json.loads(line)
        name = row["target"]["name"]
        if (name,row["target"]["kind"]) not in [("cargo",["bin"]),("testsuite",["test"])]:
            continue
        p = Path(row["executable"]).resolve(strict=True)
        require(name not in binaries and not row["fresh"] and p.is_relative_to(R["TARGET"]), "wrong build artifact")
        binaries[name] = {"path": str(p), "sha256": sha(p)}
    require(set(binaries) == {"cargo","testsuite"}, "missing fresh artifact")
    details, wrappers = {}, {}
    for i,test in enumerate(R["TESTS"]):
        p = R["TARGET"]/"tmp/cit/testsuite/rustflags"/test.split("::")[1]/"foo/ohm-defaults.log"
        content = p.read_text()
        matches = [(index,args) for index,line in enumerate(content.splitlines(),1) for args in [line.split("\t")]
                   if any(args[k:k+2] == ["--crate-name","foo"] for k in range(len(args)))]
        require(len(matches) == 1, test)
        line, args = matches[0]
        original = "\t--crate-name\tfoo\t" in "\t"+content
        require(original == (i != 2), "original guard rejection not reproduced exactly")
        flags = [a for a in args if a.startswith("-Zthreads=")]
        require(flags == [("-Zthreads=8","-Zthreads=8","-Zthreads=1")[i]], "unexpected final wrapper flags")
        if i == 2:
            require(line == 4 and args[:2] == ["--crate-name","foo"], "expected exact start-of-line case")
        details[test] = {"source_line":line,"matched_rows":1,"final_frontend_flags":flags,"original_guard":original}
        wrappers[test] = sha(p)
    seed = sum(int(line.split("\t",1)[0]) for line in (ROOT/"seed-sizes.tsv").read_text().splitlines())
    diagnosis = dict(original_validator_exit=1,raw_final_error=ERROR,original_observations_unchanged=True,
                     repeated_cargo_or_test_commands=0,final_wrapper_rows=details,source_sha256=sha(Path(__file__)),
                     original_runner_sha256=sha(OUT/"runner.log"),original_return_sha256=sha(OUT/"runner-return.json"))
    result = dict(tests=list(R["TESTS"]),passed=3,ignored=0,wrapper_logs=wrappers,binaries=binaries,
                  seed_logical_bytes=seed,free_bytes_after=shutil.disk_usage(ROOT).free,
                  log_sha256=sha(log),recovered_postflight=diagnosis)
    return result,diagnosis


def overlay(function, *changes):
    original = inspect.getsource(S[function])
    for before, after in changes:
        require(original.count(before) == 1, "original custody source changed")
        original = original.replace(before, after)
    exec(compile(original, str(BASE/"recover-validation.py"), "exec"), C)


def main():
    require(sys.argv[1:] == ["--existing-fixture-only"] and os.getuid() != 0, "only real-host offline recovery")
    result,why = derive()
    if not (ROOT/"passed.json").exists():
        with (ROOT/"passed.json").open("x") as file: json.dump(result,file,indent=2)
    else:
        old = json.loads((ROOT/"passed.json").read_bytes())
        require((old | {"free_bytes_after": result["free_bytes_after"]}) == result, "changed verification on retry")
    if not (OUT/"postflight-recovered.json").exists():
        S["save"]("postflight-recovered.json",why)
    require(S["read"]("postflight-recovered.json") == why, "recovery changed")
    overlay("audit_owned",('result["exit"] == 0 and result["protected_unchanged"]',
            'result["exit"] == 1 and result["protected_unchanged"] and read("postflight-recovered.json") == recovery_findings'))
    C["recovery_findings"] = why
    overlay("package",('("before.json", "runner.log", "runner-return.json")',
            '("before.json", "runner.log", "runner-return.json", "session.json", "postflight-recovered.json")'),
            ('"validate-tests.py", "test-custody.py", "verify-validation.py")',
             '"validate-tests.py", "test-custody.py", "verify-validation.py", "recover-validation.py", "custody-registration.json", "CUSTODY.md")'))
    # The recovery's checks and original nonzero return are both recorded in
    # passed.json and separate receipts inside the portable packet.
    C["package"]()
    C["retire"]()
    print(json.dumps(S["read"]("physical-return.json"),indent=2))


if __name__ == "__main__":
    main()
