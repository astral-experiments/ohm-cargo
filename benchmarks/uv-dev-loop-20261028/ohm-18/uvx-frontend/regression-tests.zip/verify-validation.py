"""Verify a compact Cargo test packet offline. Optionally check the retained ELFs."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile


TESTS = [
    "rustflags::ohm_small_incremental_bins_use_one_frontend_thread",
    "rustflags::ohm_small_incremental_checks_use_one_frontend_thread",
    "rustflags::ohm_parallel_frontend_user_flags_take_precedence",
]


def verify(packet, elf_dir=None):
    if not __debug__:
        raise RuntimeError("verification requires Python assertions")
    with zipfile.ZipFile(packet) as archive:
        manifest = json.loads(archive.read("SHA256.json"))
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(manifest) | {"SHA256.json"}
        for name, digest in manifest.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
        source = json.loads(archive.read("candidate.json"))
        assert source["candidate_tree"] == "d4228f784fe81df111defbd85cb5f3b238d93da6"
        assert source["patch_sha256"] == manifest["small-bin-frontend.patch"]
        for path, entry in source["sources"].items():
            assert entry["candidate_sha256"] == manifest["sources/" + path]
        result = json.loads(archive.read("passed.json"))
        assert result["tests"] == TESTS and result["passed"] == 3 and result["ignored"] == 0
        text = archive.read("test.log").decode()
        assert manifest["test.log"] == result["log_sha256"]
        assert sorted(re.findall(r"^test (\S+) \.\.\. ok$", text, re.M)) == sorted(TESTS)
        assert len(re.findall(r"^test result: ok\. 3 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out;", text, re.M)) == 1
        commands = json.loads(archive.read("command.json"))
        assert commands["sources"] == source and commands["argv"][-3:] == TESTS
        retained_rows = {}
        for test in TESTS:
            name = f"wrapper/{test.split('::')[1]}.log"
            assert manifest[name] == result["wrapper_logs"][test]
            args = [line.split("\t") for line in archive.read(name).decode().splitlines()]
            retained_rows[test] = sum(any(row[i:i+2] == ["--crate-name", "foo"] for i in range(len(row))) for row in args)
            assert retained_rows[test] >= 1
        assert set(result["binaries"]) == {"cargo", "testsuite"}
        for name, entry in result["binaries"].items():
            assert re.fullmatch("[0-9a-f]{64}", entry["sha256"])
            if elf_dir:
                with (elf_dir / name).open("rb") as binary:
                    assert binary.read(4) == b"\x7fELF"
                    binary.seek(0)
                    assert hashlib.file_digest(binary, "sha256").hexdigest() == entry["sha256"]
        return {"named_passes": 3, "ignored": 0, "final_wrapper_foo_rows": retained_rows,
                "full_earlier_argv_saved": False, "optional_elf_images_verified": bool(elf_dir)}


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1]), Path(sys.argv[2]) if len(sys.argv) > 2 else None), indent=2))
