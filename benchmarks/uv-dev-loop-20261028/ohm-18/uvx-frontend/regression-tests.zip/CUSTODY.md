# Test validation custody

The test launch is unchanged. After an individual grant, the following command records the starting identities and invokes the sealed validator once on the granted CPUs.

```sh
taskset -c <granted-cpus> python3 -I -B work/round18-cargo/small-frontend-review/test-custody.py run --coordinator-released
```

The wrapper adds no trace or compiler flags. It records the validator exit and the four allocated directory identities. It verifies the 3 named, non-ignored passes using the raw build/test log. The portable ZIP includes the source diff and source bytes, exact command and seed size, stdout/stderr, each final retained wrapper log, and both executable hashes. The same filesystem retains the two completed ELF images by hard link outside the disposable target. The test wrapper clears its file before each internal step. Counts computed from its retained logs describe the final step only. Earlier assertions, including the per-step role and thread flag checks in the new test, are established by the three real test bodies.

The packet's own standard-library verifier is rerun from an empty temporary working directory, using the packet alone and then optionally checking the retained ELF files. The fixture and donor paths embedded in the logs are not read by that verifier. Package and retire can be resumed from the saved outputs after a separate host release. They never launch Cargo or repeat a test. A green libtest result remains preserved on an auxiliary custody rejection.

The sole retirement allow-list is the exact newly created `round18-small-bin-cargo-tests` root and its recorded `home`, `cargo-home`, and `target` directories, plus the four detached result files. Source and donor identities, the archive and both ELF hashes are rechecked. The finalizer rejects unexpected top-level names, replaced directories and any same-owner live process with a cwd, executable, descriptor or mapping in the private root. An inaccessible process or other incomplete check leaves the files in place.

The result location is `work/round18-cargo/small-frontend-review/validation-result/`. The final `physical-return.json` includes the actual before/after free space, retired device/inodes and verified archive identity.
