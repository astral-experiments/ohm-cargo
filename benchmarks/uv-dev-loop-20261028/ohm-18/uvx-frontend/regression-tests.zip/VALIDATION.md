# Focused Cargo regression validation

The released testsuite donor predates the new integration test. It was built with release Cargo and rustc, the `ohm-defaults` crate feature, `-Zohm-defaults=no` on the outer build and both development/test debug information set to zero. The validator reuses its registry dependency directories under `round18-proof-cargo-tests/target-release-control/debug/build` and its populated private registry. It copies them into a fresh private target/Cargo home, excluding every workspace package name in the lockfile. Cargo, its test support and the actual integration harness are rebuilt against the exact reviewed checkout. The implementation and test delta are checked before and after the run. The old test executable and driver stay at their original paths.

The no-argument command performs a source and path preflight. It invokes neither Cargo nor any compiler and allocates no fixtures.

```sh
taskset -c 26 python3 -I -B work/round18-cargo/small-frontend-review/validate-tests.py
```

After a separate host grant, restrict the command to the granted CPUs and append `--coordinator-released`. The runner needs the real non-root host used by the existing Cargo test harness. It creates a single private root beside the donor, at `$(cat work/bench-home.path)/round18-small-bin-cargo-tests`. A prior root is an error. Source, compiler and registry inputs are taken from this task. Ordinary test execution is equivalent to changing into `work/ohm-cargo` and running the following with the isolated home and target from the script.

```sh
../upstream-monitor/toolchain18/bin/cargo -Zohm-defaults=no test \
  --locked --offline -j3 --features ohm-defaults --test testsuite \
  --message-format=json-render-diagnostics -- --exact --test-threads=1 \
  rustflags::ohm_small_incremental_bins_use_one_frontend_thread \
  rustflags::ohm_small_incremental_checks_use_one_frontend_thread \
  rustflags::ohm_parallel_frontend_user_flags_take_precedence
```

All three functions use plain `#[cargo_test]`. The macro always adds `#[test]`; conditional ignore rules require explicit macro attributes. The host satisfies the Linux x86-64 cfg on the new and existing small-input tests. The macro initializes a private test directory under compiled-in `CARGO_TARGET_TMPDIR`. `CargoProjectExt::cargo` selects the integration test's Cargo binary through `snapbox::cmd::cargo_bin!("cargo")`. The validator checks the two fresh compiler-artifact identities, exactly three distinct named libtest passes, zero ignored tests, and a real wrapper log containing a foo-crate rustc invocation in each test's own sandbox. It preserves raw output and checksums even when scores cannot be accepted. Revision 2 asserts one selected foo compiler invocation per step and discriminates a regular bin, rustc test harness and custom harness from their actual argv. It also verifies a second bin receives the serial default, then substitutes its genuine dep-info while making foo dirty. A single tracked path that differs from foo’s source must keep eight. The existing test wrapper records and removes the -Zthreads arguments before invoking rustc. The regression validates Cargo’s emitted argv, nested compilation and fixture output. Unwrapped, genuinely flagged binary behavior belongs to the separate normal-Cargo controls. Check-only argument ordering remains covered by the existing override test. No uv tests run.

At the read-only preflight the filesystem had 188.8 GiB free. The validator requires the 120 GiB reserve, the measured apparent size of all prospective copies with duplicate links counted, and a further 24 GiB for rebuilt workspace outputs and the test projects. This permits up to 44.8 GiB of inputs at the observed free space. The actual input size is measured only under a grant. A live 122 GiB stop guard leaves two GiB above the global floor. Relative paths, package-level reuse decisions and linker cache hits remain under the normal Cargo build. Measured durations cannot be inferred before running.

Historical inputs are `work/round18-lab/release-proof-test.py` and `work/round18-proof-tests/release-control/caught-regression.json`. Macro and executable selection are in `work/ohm-cargo/crates/cargo-test-macro/src/lib.rs` and `work/ohm-cargo/tests/testsuite/utils/ext.rs`. The dry-run selector rejected zero tests, an ignored case, duplicate names and incorrect result summaries on synthetic inputs.
