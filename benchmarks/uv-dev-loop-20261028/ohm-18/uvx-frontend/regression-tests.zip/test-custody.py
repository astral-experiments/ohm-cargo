"""Package the unmodified, untimed validator and retire only its own private root."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

HERE = Path(__file__).resolve().parent
VALIDATOR = HERE / "validate-tests.py"
RELEASE = runpy.run_path(str(VALIDATOR))
PRIVATE, DONOR, TARGET, REPO = [RELEASE[name] for name in ("PRIVATE", "DONOR", "TARGET", "REPO")]
OUT = HERE / "validation-result"
PACKET = OUT / "cargo-small-frontend-regressions.zip"
DIRECTORIES = ("home", "cargo-home", "target")
RAW = ("command.json", "passed.json", "seed-sizes.tsv", "test.log")
sha, require = RELEASE["sha"], RELEASE["require"]


def save(name, value):
    with (OUT / name).open("x") as file:
        json.dump(value, file, indent=2)
        file.write("\n")


def read(name):
    return json.loads((OUT / name).read_bytes())


def identity(path):
    st = path.lstat()
    require(path.is_dir() and not path.is_symlink() and st.st_uid == os.getuid(), f"unexpected directory: {path}")
    return [st.st_dev, st.st_ino, st.st_uid]


def protected():
    donor = DONOR / "target-release-control"
    suite, = (donor / "debug/build/cargo").glob("*/out/testsuite-????????????????")
    paths = (DONOR, donor, donor / "debug/cargo", suite, DONOR / "cargo-home/registry")
    return {str(p): [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns] for p in paths for s in [p.stat()]}


def launch():
    require(not PRIVATE.exists() and not OUT.exists(), "existing custody must be recovered instead of repeating tests")
    RELEASE["verify_sources"]()
    OUT.mkdir(mode=0o700)
    save("before.json", {"private_root_absent": True, "protected": protected(),
                         "validator_sha256": sha(VALIDATOR), "free_bytes": shutil.disk_usage(PRIVATE.parent).free})
    owned = {}
    with (OUT / "runner.log").open("x") as file:
        process = subprocess.Popen([sys.executable, "-I", "-B", VALIDATOR, "--coordinator-released"],
                                   stdout=file, stderr=subprocess.STDOUT)
        while True:
            for path in (PRIVATE, *(PRIVATE / name for name in DIRECTORIES)):
                if path.exists():
                    old = owned.setdefault(str(path), identity(path))
                    require(identity(path) == old, f"allocated root replaced: {path}")
            if process.poll() is not None:
                break
            time.sleep(.2)
    save("runner-return.json", {"pid": process.pid, "exit": process.returncode, "owned": owned,
                                "protected_unchanged": protected() == read("before.json")["protected"]})
    require(process.returncode == 0, "validator returned an error; original logs and any green libtest result are retained")


def audit_owned():
    result = read("runner-return.json")
    require(result["exit"] == 0 and result["protected_unchanged"], "successful driver return and donor custody required")
    require(str(PRIVATE.parent.resolve() / "round18-small-bin-cargo-tests") == str(PRIVATE), "unexpected private root")
    paths = [PRIVATE, *(PRIVATE / name for name in DIRECTORIES)]
    require(result["owned"] == {str(p): identity(p) for p in paths}, "private directory identity changed")
    require(set(p.name for p in PRIVATE.iterdir()) == set(DIRECTORIES) | set(RAW), "unexpected private root contents")
    require(protected() == read("before.json")["protected"], "donor changed")
    RELEASE["verify_sources"]()


def package():
    audit_owned()
    passed = json.loads((PRIVATE / "passed.json").read_bytes())
    images = OUT / "elf"
    images.mkdir(exist_ok=True)
    for name, entry in passed["binaries"].items():
        require(name in {"cargo", "testsuite"}, "unexpected executable")
        source = Path(entry["path"]).resolve(strict=True)
        require(source.is_relative_to(TARGET) and sha(source) == entry["sha256"], "private ELF mismatch")
        keep = images / name
        if not keep.exists():
            # Both locations are on the same scratch filesystem. The completed
            # executable survives target retirement without allocating a second copy.
            os.link(source, keep)
        require(source.samefile(keep), "retained ELF identity changed")
    files = {name: PRIVATE / name for name in RAW}
    for name in ("before.json", "runner.log", "runner-return.json"):
        files[name] = OUT / name
    for name in ("candidate.json", "validation-preflight.json", "small-bin-frontend.patch", "VALIDATION.md",
                 "validate-tests.py", "test-custody.py", "verify-validation.py"):
        files[name] = HERE / name
    for rel in json.loads((HERE / "candidate.json").read_bytes())["sources"]:
        files["sources/" + rel] = REPO / rel
    for test in RELEASE["TESTS"]:
        name = test.split("::")[1]
        files["wrapper/" + name + ".log"] = TARGET / "tmp/cit/testsuite/rustflags" / name / "foo/ohm-defaults.log"
    if not PACKET.exists():
        with tempfile.NamedTemporaryFile(dir=OUT) as tmp:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, source in files.items():
                    archive.write(source, name)
                archive.writestr("SHA256.json", json.dumps({name: sha(p) for name, p in files.items()}, sort_keys=True))
            tmp.flush()
            os.link(tmp.name, PACKET)
    with tempfile.TemporaryDirectory(dir=OUT) as fresh:
        fresh = Path(fresh)
        with zipfile.ZipFile(PACKET) as archive:
            (fresh / "verify.py").write_bytes(archive.read("verify-validation.py"))
        results = []
        for extra in ([], [images]):
            run = subprocess.check_output([sys.executable, "-I", "-B", fresh / "verify.py", PACKET, *extra], cwd=fresh)
            results.append(json.loads(run))
    record = {"archive_sha256": sha(PACKET), "archive_bytes": PACKET.stat().st_size,
              "replays": results, "executable_hashes": {n:e["sha256"] for n,e in passed["binaries"].items()}}
    if (OUT / "packet-verified.json").exists():
        require(record == read("packet-verified.json"), "verified packet changed")
    else:
        save("packet-verified.json", record)


def active_users():
    active = []
    for proc in Path("/proc").glob("[0-9]*"):
        try:
            if proc.stat().st_uid != os.getuid() or proc.joinpath("stat").read_text().rsplit(")",1)[1].split()[0] == "Z":
                continue
            for link in (proc / "cwd", proc / "exe", *(proc / "fd").iterdir()):
                try:
                    if Path(os.readlink(link)).is_relative_to(PRIVATE):
                        active.append(str(link))
                except FileNotFoundError:
                    pass
            if str(PRIVATE) + "/" in (proc / "maps").read_text(errors="replace"):
                active.append(str(proc / "maps"))
        except FileNotFoundError:
            pass
    return active


def retire():
    audit_owned()
    record = read("packet-verified.json")
    require(sha(PACKET) == record["archive_sha256"], "packet changed")
    require(all(sha(OUT / "elf" / n) == h for n,h in record["executable_hashes"].items()), "ELF copy changed")
    require(not active_users(), "validation directory is still in use")
    require(shutil.rmtree.avoids_symlink_attacks, "safe recursive unlink unavailable")
    free = shutil.disk_usage(PRIVATE).free
    shutil.rmtree(PRIVATE)
    require(not PRIVATE.exists() and protected() == read("before.json")["protected"], "private return failed")
    RELEASE["verify_sources"]()
    save("physical-return.json", {"custody_returned": True, "retired_root": str(PRIVATE),
                                 "identities": read("runner-return.json")["owned"], "free_bytes_before": free,
                                 "free_bytes_after": shutil.disk_usage(PRIVATE.parent).free,
                                 "archive_sha256": sha(PACKET), "source_and_donor_rechecked": True})


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[2] != "--coordinator-released":
        print("No action. Use run, package or retire only after a host release.")
    else:
        require(os.geteuid() != 0 and Path("/proc/1/comm").read_text().strip() == "systemd", "real non-root host required")
        if sys.argv[1] == "run":
            launch()
            package()
            retire()
        elif sys.argv[1] == "package":
            package()
        elif sys.argv[1] == "retire":
            retire()
        else:
            raise SystemExit("unknown action")
