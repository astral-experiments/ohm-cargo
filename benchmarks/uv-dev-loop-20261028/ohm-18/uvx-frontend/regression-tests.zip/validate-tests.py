"""Run three exact Cargo integration tests against the sealed -18 candidate."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import tomllib


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / "ohm-cargo"
DIST = WORK / "upstream-monitor/toolchain18/bin"
BENCH = Path((WORK / "bench-home.path").read_text().strip())
DONOR = BENCH / "round18-proof-cargo-tests"
PRIVATE = BENCH / "round18-small-bin-cargo-tests"
TARGET = PRIVATE / "target"
PACKAGES = DONOR / "target-release-control/debug/build"
REGISTRY = DONOR / "cargo-home/registry"
TESTS = (
    "rustflags::ohm_small_incremental_bins_use_one_frontend_thread",
    "rustflags::ohm_small_incremental_checks_use_one_frontend_thread",
    "rustflags::ohm_parallel_frontend_user_flags_take_precedence",
)
COMMAND = [
    str(DIST / "cargo"), "-Zohm-defaults=no", "test", "--locked", "--offline",
    "-j3", "--features", "ohm-defaults", "--test", "testsuite",
    "--message-format=json-render-diagnostics", "--", "--exact", "--test-threads=1", *TESTS,
]
GIB = 1024**3
FLOOR = 120 * GIB


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def verify_sources():
    receipt = json.loads((HERE / "candidate.json").read_bytes())
    require(receipt["revision"] == 2 and receipt["candidate_tree"] == "d4228f784fe81df111defbd85cb5f3b238d93da6", "wrong candidate tree")
    require(receipt["patch_sha256"] == "24b37fff288137bc2a846ecf2bb5350e096802e39b7ba72097cbf52825a9b112", "wrong candidate patch")
    patch = subprocess.check_output(["git", "-C", REPO, "diff", "--binary", "--full-index",
                                     "--no-ext-diff", receipt["base_commit"], "--"])
    require(hashlib.sha256(patch).hexdigest() == receipt["patch_sha256"], "candidate delta changed")
    untracked = subprocess.check_output(["git", "-C", REPO, "ls-files", "--others", "--exclude-standard"])
    require(not untracked, "unexpected untracked candidate source")
    for name, values in receipt["sources"].items():
        require(sha(REPO / name) == values["candidate_sha256"], name)
    return receipt


def passed(text):
    successes = re.findall(r"^test (\S+) \.\.\. ok$", text, re.M)
    summary = re.findall(r"^test result: ok\. 3 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out;", text, re.M)
    return sorted(successes) == sorted(TESTS) and len(summary) == 1


def guarded(command, **kwargs):
    process = subprocess.Popen(command, start_new_session=True, **kwargs)
    try:
        while process.poll() is None:
            require(shutil.disk_usage(BENCH).free > FLOOR + 2 * GIB, "approaching the 120 GiB floor")
            time.sleep(0.5)
        require(process.returncode == 0, f"exit {process.returncode}: {command[0]}")
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()


def main():
    receipt = verify_sources()
    require(sys.platform == "linux" and os.uname().machine == "x86_64", "the two gated tests require Linux x86_64")
    require(REGISTRY.is_dir() and PACKAGES.is_dir(), "release test dependencies missing")
    free = shutil.disk_usage(BENCH).free
    if sys.argv[1:] != ["--coordinator-released"]:
        require(not sys.argv[1:], "only a separately released host may run the tests")
        print(json.dumps(dict(command=COMMAND, candidate_tree=receipt["candidate_tree"],
                              private_root=str(PRIVATE), free_gib=free/GIB, floor_gib=120,
                              max_seed_gib=(free-FLOOR)/GIB-24, executed=False), indent=2))
        return
    require(os.geteuid() != 0 and Path("/proc/1/comm").read_text().strip() == "systemd", "real non-root host required")
    require(not PRIVATE.exists(), "the private validation root must be new")
    lock = tomllib.loads((REPO / "Cargo.lock").read_text())["package"]
    workspace = {p["name"] for p in lock if "source" not in p}
    registry = {p["name"] for p in lock if p.get("source", "").startswith("registry+")} - workspace
    seeds = sorted(p for p in PACKAGES.iterdir() if p.name in registry and p.is_dir() and not p.is_symlink())
    require(seeds and all(p.name != "cargo" for p in seeds), "no Cargo package or old harness may be seeded")
    sizes = subprocess.check_output(["du", "--summarize", "--apparent-size", "--count-links", "--block-size=1",
                                     "--", REGISTRY, *seeds], text=True)
    seed_bytes = sum(int(line.split("\t", 1)[0]) for line in sizes.splitlines())
    require(shutil.disk_usage(BENCH).free > FLOOR + seed_bytes + 24*GIB, "insufficient copy and rebuild headroom")
    os.umask(0o077)
    PRIVATE.mkdir(mode=0o700)
    (PRIVATE / "seed-sizes.tsv").write_text(sizes)
    home = PRIVATE / "home"
    cargo_home = PRIVATE / "cargo-home"
    home.mkdir()
    cargo_home.mkdir()
    build = TARGET / "debug/build"
    build.mkdir(parents=True)
    guarded(["cp", "-a", "--reflink=auto", "--", REGISTRY, cargo_home])
    guarded(["cp", "-a", "--reflink=auto", "--", *seeds, build])
    env = dict(HOME=str(home), PATH=f"{DIST}:/usr/local/bin:/usr/bin:/bin", LC_ALL="C",
               CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(TARGET), CARGO_NET_OFFLINE="true",
               CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0", CARGO_TERM_COLOR="never",
               RUSTC=str(DIST / "rustc"), RUSTDOC=str(DIST / "rustdoc"), RUSTC_BOOTSTRAP="1")
    (PRIVATE / "command.json").write_text(json.dumps(dict(argv=COMMAND, env=env, sources=receipt), indent=2))
    log = PRIVATE / "test.log"
    with log.open("x") as output:
        guarded(COMMAND, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
    text = log.read_text()
    require(passed(text), "expected three named passing tests and zero ignored")
    binaries = {}
    for line in text.splitlines():
        if not line.startswith("{"):
            continue
        row = json.loads(line)
        if row.get("reason") != "compiler-artifact":
            continue
        name = row["target"]["name"]
        if (name, row["target"]["kind"]) not in [("cargo", ["bin"]), ("testsuite", ["test"])]:
            continue
        path = Path(row["executable"]).resolve()
        require(not row["fresh"] and path.is_relative_to(TARGET) and path.is_file(), f"{name} must be rebuilt in isolation")
        binaries[name] = {"path": str(path), "sha256": sha(path)}
    require(set(binaries) == {"cargo", "testsuite"}, "candidate driver and rebuilt testsuite are required")
    wrappers = {}
    for name in TESTS:
        directory = TARGET / "tmp/cit/testsuite/rustflags" / name.split("::")[1]
        wrapper_log = directory / "foo/ohm-defaults.log"
        require("\t--crate-name\tfoo\t" in "\t" + wrapper_log.read_text(), f"missing real compiler invocation for {name}")
        wrappers[name] = sha(wrapper_log)
    verify_sources()
    result = dict(tests=list(TESTS), passed=3, ignored=0, wrapper_logs=wrappers, binaries=binaries,
                  seed_logical_bytes=seed_bytes, free_bytes_after=shutil.disk_usage(BENCH).free, log_sha256=sha(log))
    (PRIVATE / "passed.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
