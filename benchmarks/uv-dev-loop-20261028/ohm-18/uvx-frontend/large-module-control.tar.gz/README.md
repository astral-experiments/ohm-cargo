# The small-binary heuristic failed its first-large-module control

The candidate extended Ohm Cargo's one-frontend-thread policy to selected incremental debug binary and test units. The policy used the current root file's size and the previous compile's sole source input. A genuine 83-byte binary qualified. Its next edit added `mod heavy;` in a 165-byte root with 4,096 reachable functions in a new file. The candidate appended `-Zthreads=1` for that first edit. Both controls stayed at eight threads. All three drivers saw both files in the new dep-info, and the candidate returned to eight threads on the following edit.

| Comparison against the candidate | Median saved time | Median saved percent | Rank interval, ms | Candidate wins |
| --- | ---: | ---: | ---: | ---: |
| Source-matched, independently PGO-trained baseline | −479.12 ms | −57.78% | [−729.40, −239.57] | 3 / 24 |
| Shipped Ohm 1.99.0-18 | −233.96 ms | −27.31% | [−576.54, −127.92] | 3 / 24 |

Positive savings favor the candidate. For each control, the registered rule required the median's 95% lower rank bound to exceed either −5% or −10 ms. The observed rank interval has 97.73% discrete coverage at 24 pairs. Both comparisons failed both margins. All 72 whole `cargo build` commands are included. Each used a fresh independent copy of that arm's genuine tiny predecessor and a fixed tag for the new large module. Original orders balance all six three-arm permutations. All three arms emitted the same current executable per edit, and the 24 edits emitted 24 distinct executable hashes.

Twelve structural cases completed, spanning genuine normal/test roles, cold programs, a large single-file binary, an established multi-file binary, module introduction, both explicit rustc-option forms, disabled incremental compilation and an explicit target. A separate fixture-oracle error stopped the thirteenth case on cold shipped Cargo. Cargo successfully built a library named `frontlib`; the existing uv rlib normalizer expects nonce-bearing members with the literal crate prefix `uv-`. The packet retains the 4,520-byte original archive, 2,267-byte standalone metadata, successful Cargo JSON and raw tool exit. Running the unchanged normalizer on the archive reproduces its assertion at line 23. The original control runner exited 1 and did not issue a complete all-controls receipt. The prior independent safety veto was already measured. No macro-control or complete-command uv experiment followed for this implementation.

The earlier direct uvx compiler screen remains positive. Across the two real uv edits, one frontend thread saved 38–44 ms in each of the three compiler roles, and 13–19% of foreground rustc user-mode instructions. The separate direct packet contains that screen's 576 elapsed rows, 96 instruction rows and full fresh-host instructions. Its SHA-256 is `d8f6e7ce8ce19b18f89d9b779ff364d2491da700b71686e0b6b7a71d471319bd`. The uvx result covers those small direct compiler invocations. It does not outweigh the independently registered broader policy veto.

## Offline replay

Use Python 3.12 and NumPy. The original used NumPy 2.3.5. Extract the packet outside the original workspace and benchmark tree.

```sh
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python3 rescore.py --deny-recorded-host
```

The rescorer checks the original registration and PGO source/driver receipts, all 12 completed control fixtures' real captured compiler arguments, all fixed block assignments, the per-command elapsed values, the 72 actual dirty Cargo artifact observations and every tagged executable identity. It decodes the genuine before/after donor dep-info, regenerates the original Rust inputs in memory, reruns the frozen paired statistics, evaluates the original noninferiority expression, and invokes the original archive oracle on the failed library bytes. It denies subprocess launches or access to the actual historical checkout and scratch directories. `verdict.json` records its full result.

The build used base Cargo source `7caf39914da1e28a67744ecbc963a5f26361474d`, candidate tree `d4228f784fe81df111defbd85cb5f3b238d93da6`, and the exact source patch under `work/round18-compiler/small-frontend-screen/normal-pgo-v3/source-proposals/revision-2/`. The matched binaries used unmodified std, ThinLTO, one codegen unit and their own 24-command bitmap/Diesel training profiles. Shipped, matched and candidate native measurements used the same distributed rustc and Wild. `audited-drivers.json` records both matched binary/profile hashes and the exact stock compiler. Every donated input directory remained parked locally. The archive includes proof of their identities and the two bounded original library artifacts; it omits large toolchains, PGO driver executables and build targets. [Ohm release](https://github.com/astral-sh/ohm/releases/tag/ohm-1.99.0-18)
