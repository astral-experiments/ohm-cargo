"""Reproduce the prospective first-large-module veto and the independent terminal fixture rejection."""
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import struct
import sys
import traceback

ROOT=Path(__file__).resolve().parent
WORK=ROOT/"work"
SCREEN=WORK/"round18-compiler/small-frontend-screen";V3=SCREEN/"normal-pgo-v3"
CONTROLS=V3/"observed/j8/controls"
def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def read(p):return json.loads(p.read_text())
def require(ok,why):
    if not ok:raise RuntimeError(why)
def check_files():
    seen=set()
    for line in (ROOT/"SHA256SUMS").read_text().splitlines():
        h,n=line.split("  ",1);p=ROOT/n
        require(n not in seen and not Path(n).is_absolute() and ".." not in Path(n).parts and not p.is_symlink() and sha(p)==h,n);seen.add(n)
    require(seen|{"SHA256SUMS"}=={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts},"extra or missing evidence")
def deny():
    former=Path(read(V3/"grants/pgo-controls-initial.json")["release"]).parents[2]
    scratch=Path((WORK/"bench-home.path").read_text().strip())
    require(not ROOT.is_relative_to(former) and not ROOT.is_relative_to(scratch),"extract outside the recorded host")
    def filter(event,args):
        if event in ("subprocess.Popen","os.posix_spawn","os.fork","os.system","os.exec","os.forkpty"):raise RuntimeError("no process launches in this rescore")
        if event in ("open","os.listdir","os.scandir") and args and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0])).absolute()
            require(not p.is_relative_to(former) and not p.is_relative_to(scratch),"attempted original-host read")
    sys.addaudithook(filter)


class VirtualSource:
    def __init__(self,names,path=Path()):self.names=names;self.path=path
    def __truediv__(self,part):return VirtualSource(self.names,self.path/part)
    def write_text(self,text):self.names[str(self.path)]=text.encode()


def fixture():
    path=SCREEN/"controls.py";tree=ast.parse(path.read_text());sel=[];gate=None
    for n in tree.body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ("CASES","COLD_PROGRAM"):sel.append(n)
        if isinstance(n,ast.FunctionDef) and n.name in ("substantial","source_at","flags"):sel.append(n)
        if isinstance(n,ast.FunctionDef) and n.name=="run":
            gate,=[m.value for m in ast.walk(n) if isinstance(m,ast.Assign) and isinstance(m.targets[0],ast.Name) and m.targets[0].id=="admissible"]
    context={};exec(compile(ast.Module(body=sel,type_ignores=[]),str(path),"exec"),context)
    return context,compile(ast.Expression(gate),str(path),"eval")


def sources(c,kind,tag):
    d={};c["source_at"](VirtualSource(d),kind,tag,c["substantial"]());return d


def artifacts(cell):
    r=[json.loads(x) for x in (cell/"stdout").read_text().splitlines() if x.startswith("{")]
    require(len([x for x in r if x["reason"]=="build-finished" and x["success"]])==1,"Cargo did not finish successfully")
    return [x for x in r if x["reason"]=="compiler-artifact"]


def verify_struct(c,s):
    recognized={}
    for name,(kind,ep,override) in c["CASES"].items():
        if name=="dev-library":continue
        cell=CONTROLS/name;require(read(cell/"done.json")=={"all_control_flags_and_products_match":True},name)
        rolecount=0
        for i,phase in enumerate(("cold","edit","next")):
            projected="tiny" if kind=="transition" and phase=="cold" else ("module" if kind=="transition" else kind)
            src=sources(c,projected,f"T{i:03}")["src/main.rs"];products=[]
            for arm in s.NORMAL:
                q=cell/(phase+"-"+arm);r=read(q/"receipt.json")
                command=[str(s.SCRATCH/"controls"/name/"cargo"),ep,*(["--no-run"] if ep=="test" else []),"--offline","--locked","-j8",
                         *(["--target","x86_64-unknown-linux-gnu"] if override=="target" else []),"--message-format=json"]
                require(r["argv"]==command,"wrong actual Cargo command")
                enter=phase!="cold" and (kind=="tiny" or kind=="transition" and phase=="edit") and override not in ("no-incremental","target") and arm=="head"
                expected=["8"]+(["1"] if enter else [])+(["4"] if override in ("joined","split") else [])
                observed=[]
                prefix="execve("+json.dumps(str(s.TOOLS/"bin/rustc"))+", "
                for trace in sorted(q.glob("exec.*")):
                    for line in trace.read_text().splitlines():
                        if line.startswith(prefix) and line.endswith("= 0"):
                            args=json.JSONDecoder().raw_decode(line[len(prefix):])[0]
                            if "--crate-name" in args and args[args.index("--crate-name")+1]=="frontprobe":
                                require("src/main.rs" in args and c["flags"](args)==expected,"wrong frontend role or effective options")
                                observed.append(("--test" in args,s.hbytes(json.dumps(args).encode())))
                require(observed==[(t["harness"],t["argv_sha256"]) for t in r["targets"]],"original rustc digest or harness drift")
                require(sorted(h for h,_ in observed)==([False,True] if ep=="test" else [False]),"wrong real target roster")
                require(all(t["source_bytes"]==len(src) and t["flags"]==expected and 0<t["dep_info_bytes"]<=16384 for t in r["targets"]),"wrong source or hint")
                a=[m for m in artifacts(q) if m["target"]["name"]=="frontprobe"]
                require(len(a)==len(observed) and all(not x["fresh"] for x in a),"Cargo skipped a requested frontend")
                products.append(r["products"]);rolecount+=len(observed)
            require(products.count(products[0])==3,"unequal structural products")
        recognized[name]=rolecount
    return recognized


def hint(raw):
    require(raw[:6]==b"\x01\x00\x00\x00\xff\x04","unexpected serialized dep-info")
    at=6
    def take(n):
        nonlocal at
        b=raw[at:at+n];require(len(b)==n,"truncated hint");at+=n;return b
    u32=lambda:int.from_bytes(take(4),"little")
    count=u32();paths={}
    for _ in range(count):
        require(take(1)==b"\x00","unexpected dep-info kind");p=take(u32()).decode()
        require(take(1)==b"\x01","missing source checksum");size=int.from_bytes(take(8),"little");h=take(u32()).decode()
        require(re.fullmatch("blake3=[a-f0-9]{64}",h),"missing BLAKE3");paths[p]=size
    require(u32()==0 and at==len(raw),"unexpected additional dependencies");return paths


def failed_src(s):
    capsule=ROOT/"failed-library";meta=read(capsule/"source.json")
    require(meta["first_failing_case"]=="dev-library/cold-shipped" and meta["terminal_tool_exit"]==1,"wrong rejection")
    files=[f for f in artifacts(CONTROLS/"dev-library/cold-shipped") if f["target"]["name"]=="frontlib"]
    require(len(files)==1 and files[0]["fresh"] is False and meta["named_artifacts"]==files[0]["filenames"],"failed command did not compile the real library")
    for item in meta["files"]:
        p=capsule/item["name"];require(p.stat().st_size==item["size"] and sha(p)==item["sha256"],"raw library changed")
    archive=capsule/"libfrontlib.rlib";sys.path.insert(0,str(WORK/"round18-lab"))
    from rlib_equivalence import archive as original
    try:original(archive)
    except AssertionError as exc:
        frame=traceback.extract_tb(exc.__traceback__)[-1];require(frame.name=="archive" and frame.lineno==23,"different failure")
    else:raise ValueError("frozen archive assertion unexpectedly succeeded")
    raw=archive.read_bytes();require(raw.startswith(b"!<arch>\n"),"wrong archive magic");at=8;members={}
    while at<len(raw):
        h=raw[at:at+60];n=int(h[48:58]);payload=raw[at+60:at+60+n];members[h[:16].strip().decode()]=payload;at+=60+n+n%2
    pat=rb"(frontlib-[a-f0-9]{16}\.[a-z0-9]+\.[a-z0-9]{7}\.rcgu\.o)"
    name=re.findall(pat,members["//"]);require(len(name)==1 and re.findall(pat,members["lib.rmeta-link/"])==name,"different archive symbol names")
    require(b"uv-" not in members["//"] and not (CONTROLS/"dev-library/done.json").exists() and not (CONTROLS/"done.json").exists(),"original gate was not rejected")
    return {"case":meta["first_failing_case"],"cargo_build_success":True,"runner_exit":1,"original_accepted_final_gate":False,
            "archive_sha256":sha(archive),"standalone_rmeta_sha256":sha(capsule/Path(meta["named_artifacts"][1]).name),
            "archive_object":name[0].decode(),"frozen_normalizer_traceback":"rlib_equivalence.py:23"}


def result():
    sys.path.insert(0,str(SCREEN));import study as s, score
    v3=read(V3/"registration.json");require(sha(V3/"registration.json")=="fb785a0136c541c9dde74002db2c83bfc00a1cc34b67e95feb95acf8bda2ce62","experimental registration")
    for p,h in v3["files"].items():require(sha(WORK/p)==h,p)
    cert=read(V3/"audited-drivers.json");g=read(V3/"grants/pgo-controls-initial.json")
    require(g["drivers_sha256"]==sha(V3/"audited-drivers.json") and g["registration_sha256"]==sha(V3/"registration.json")
            and sha(WORK/"round18-lab"/Path(g["release"]).name)==g["release_sha256"],"wrong grant or driver")
    build=read(V3/"physical-build/returned.json");returned=read(V3/"physical-controls/returned.json")
    require(build["build_exit"]==build["watcher_exit"]==0 and build["head_sha256"]==cert["audit"]["head_sha256"] and
            build["merged_profile_sha256"]==cert["audit"]["head_profile_sha256"] and len(cert["audit"]["training_commands"])==24
            and len(cert["audit"]["raw_profiles"])==24 and cert["audit"]["uv_training_commands"]==0,"wrong PGO evidence")
    require(returned["actual_exit"]==1 and returned["lease_reacquired_then_released"] and not returned["global_and_owned_live_native"]
            and returned["all_case_active_targets_vacant"] and returned["private_targets_retained"] and returned["free_after_bytes"]>120*s.GIB,"wrong terminal custody")
    c,gate=fixture();statements=verify_struct(c,s);cell=CONTROLS/"new-module"
    rows=read(cell/"timings.json");schedule=read(V3/"schedule.json")["risk"];blocks=score.assigned(rows,schedule)
    require(len(blocks)==24 and len(rows)==72,"risk block count")
    allocations={tuple(order):schedule.count(order) for order in schedule}
    require(len(allocations)==6 and set(allocations.values())=={4},"three-arm orders were not balanced")
    products_seen=set()
    for block,group in enumerate(blocks):
        content=sources(c,"module",f"R{block:03}")["src/main.rs"];products=[]
        for row in group:
            p=cell/f'm{block:03}-{row["rank"]}-{row["arm"]}';receipt=read(p/"receipt.json")
            require(receipt["elapsed_ns"]==row["elapsed_ns"]>0 and row["source_sha256"]==s.hbytes(content),"timed row drift")
            require(receipt["argv"]==[str(s.SCRATCH/"controls/new-module/cargo"),"build","--offline","--locked","-j8","--message-format=json"],"different timed invocation")
            arts=artifacts(p);require(len(arts)==1 and arts[0]["target"]["name"]=="frontprobe" and arts[0]["fresh"] is False,"compiled target was fresh")
            path,=arts[0]["filenames"];require({x for z in receipt["products"].values() for x in z.values()}=={receipt["raw_products"][path]},"wrong compiled executable identity")
            products.append(receipt["raw_products"][path])
        require(len(set(products))==1,"different emitted products for this source");products_seen.add(products[0])
    require(len(products_seen)==24,"each tagged edit must produce a distinct executable")
    seeds={}
    for arm in s.NORMAL:
        z={k:hint((ROOT/"donor-hints"/(k+"-"+arm+".bin")).read_bytes()) for k in ("cold","after")}
        require(z["cold"]=={k:len(b) for k,b in sources(c,"tiny","T000").items()} and
                z["after"]=={k:len(b) for k,b in sources(c,"module","T002").items()},"wrong real donor paths or sizes")
        seeds[arm]=z
    risk={a:score.compare(blocks,a,"head",33120+i) for i,a in enumerate(("base","shipped"))}
    require(json.loads(json.dumps(risk))==read(cell/"risk.json"),"numeric score did not reproduce")
    eligible=eval(gate,{"risk":risk});require(eligible is False,"the frozen noninferiority gate selected this candidate")
    direct=read(SCREEN/"observer-v2/combined-result.json")
    require(direct["eligible"] and len(direct["replicated_roles"])==3 and not direct["material_losses"],"wrong earlier positive direct screen")
    return {"structural_cases_verified":statements,"risk_pairs":24,"all_72_compiler_artifacts_explicitly_dirty":True,"distinct_tagged_products":24,
            "real_donor_input_sizes":seeds,"risk":risk,"registered_module_noninferiority_gate":eligible,"terminal":failed_src(s),
            "normal_uv_timing_rows":0,"supplemental_macro_rows":0,"earlier_direct_screen_unchanged":direct["replicated_roles"],
            "earlier_direct_rows":{"native":576,"count":96},"receipt_sha256":sha(V3/"physical-controls/returned.json")}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--emit",action="store_true");p.add_argument("--deny-recorded-host",action="store_true")
    a=p.parse_args();sys.dont_write_bytecode=True
    if a.deny_recorded_host:deny()
    if not a.emit:check_files()
    value=json.dumps(result(),indent=2,sort_keys=True)+"\n";out=ROOT/"verdict.json"
    if a.emit:out.write_text(value)
    else:require(out.read_text()==value,"portable verdict differs")
    print("Verified 12 structural cases, all 72 foreground commands in 24 fixed matched blocks, 24 distinct current products, the failed noninferiority gate, and the separate exact terminal archive assertion.")
