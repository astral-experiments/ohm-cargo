"""Check frozen provenance and control routing without building, allocating a target or invoking tools."""
import ast
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
main=load("small_frontend_pgo_run",HERE/"run.py")
s=main.s
pgo=main.pgo
builder=main.build_head


def rejected(fn):
    try:fn()
    except (ValueError,AssertionError):return
    raise AssertionError("negative control accepted")


def main_test():
    for f in HERE.glob("*.py"):ast.parse(f.read_text(),filename=str(f))
    observed=main.s.read(HERE/"training-plan.json")
    rows=[json.loads(x) for x in (pgo.PGO/"commands.jsonl").read_text().splitlines()]
    assert pgo.training(rows,pgo.BASEREC)==observed["training_commands"]
    assert observed["base_audit"]["cargo_sha256"]==pgo.BASE_SHA and observed["base_audit"]["profdata_sha256"]==pgo.BASE_PROFILE
    fake=[dict(r) for r in rows]
    i=next(i for i,r in enumerate(fake) if r.get("start") and r["log"].startswith(str(pgo.BASEREC/"train.")))
    fake[i]["command"]=fake[i]["command"].replace(str(pgo.BASEREC/"generate.bin"),"/not/the/driver")
    rejected(lambda:pgo.training(fake,pgo.BASEREC))
    fake=[r for r in rows if r.get("log")!=rows[i]["log"]]
    rejected(lambda:pgo.training(fake,pgo.BASEREC))
    assert pgo.graph(pgo.BASEREC/"generate.units.jsonl","generate")==pgo.graph(pgo.BASEREC/"use.units.jsonl","use")
    original=(s.HERE/"normal.py").read_text()
    needle='            order=("check","build","test") if cohort=="initial" else ("check","test","build")'
    assert original.count(needle)==1 and (HERE/"normal-runtime.py").read_text()==original.replace(needle,'            order=endpoint_order(cohort)')
    baseline=s.read(s.HERE/"schedule.json")
    amended=s.read(HERE/"schedule.json")
    optional=s.read(HERE/"default-plan/schedule.json")
    assert amended["normal"]==baseline["normal"] and amended["risk"]==baseline["risk"]
    for cohort in s.COHORTS:
        for ep in s.ENDPOINTS:
            order=optional["normal"][cohort][ep]
            assert len(order)==480 and set(collections.Counter(map(tuple,order)).values())=={80}
            assert order!=amended["normal"][cohort][ep]
            assert s.tag(cohort,ep,1)!=main.default_tag(cohort,ep,1)
            assert main.default_argv(ep)==[str(s.TOOLS/"bin/cargo"),ep,*(["--no-run"] if ep=="test" else []),"--locked","--offline"]
            rejected(lambda:main.default_argv(ep,["-j8"]))
    assert main.native_order("replica",("test",))==("check","test")
    assert main.native_order("initial",("build",))==("check","build")
    assert main.native_order("replica",s.ENDPOINTS)==("check","test","build")
    tools=Path(observed["build_argv"][0]).parent
    inp={"suite":Path("/synthetic-suite"),"lab":pgo.STABLE,"tool":tools,"wrapper":builder.WRAPPER,
         "profiler":Path("/synthetic-profiler"),"prof":Path("/synthetic/profdata"),"a":SimpleNamespace(jobs=8,materials=pgo.MATERIAL,intermediate_output=None)}
    core=builder.core(inp)
    env=core["cargo_env"]("generate",Path("/example/trace"))
    assert set(builder.FUNCTIONS)<set(core) and env["CARGO_PROFILE_RELEASE_LTO"]=="thin" and env["CARGO_PROFILE_RELEASE_CODEGEN_UNITS"]=="1"
    assert env["CARGO_PROFILE_RELEASE_OPT_LEVEL"]=="3" and env["RUSTC"]==str(tools/"rustc") and env["__CARGO_TESTS_ONLY_SRC_ROOT"]==str(pgo.STABLE/"library")
    prior=(main.score.HERE,main.score.RESULT,main.score.tag)
    with patch.object(main.observer,"direct_result",side_effect=lambda _: {"root":str(main.score.HERE),"results":str(main.score.RESULT)}):
        reply=main.qualified_direct(True)
        assert reply=={"root":str(s.HERE),"results":str(main.observer.RESULT)}
    assert prior==(main.score.HERE,main.score.RESULT,main.score.tag)
    with patch.dict(s.os.environ,{"SMALL_FRONTEND_GRANT_SHA256":""}),patch.object(main,"seal",return_value=None):
        rejected(lambda:main.authorized("pgo-build-head","initial",35).__enter__())
    return {"compiler_or_Cargo_or_counter_launches":0,"allocations":0,"audited_reference_profiled_target_units":315,
            "reference_std_units_unprofiled":22,"reference_host_units_unprofiled":78,"canonical_training_commands":24,
            "j8_assignments_unchanged":True,"default_blocks_per_eligible_endpoint":480,"default_source_tags_and_orders_independent":True,
            "reference_exact_environment_and_six_recipe_functions_exercised":True,
            "negatives":["wrong training binary","missing training row","explicit job count in default confirmation","no fresh grant"]}


if __name__=="__main__":print(json.dumps(main_test(),indent=2,sort_keys=True))
