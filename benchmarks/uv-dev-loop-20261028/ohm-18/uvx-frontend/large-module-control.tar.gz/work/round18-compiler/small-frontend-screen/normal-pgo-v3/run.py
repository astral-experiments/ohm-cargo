"""Conditional normal-Cargo PGO confirmation and an independently ordered default-jobs holdout."""
import argparse
import contextlib
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time
import tomllib

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(HERE))
import pgo
import build_head
s=pgo.s
sys.path.insert(0,str(BASE/"observer-v2"))
import verifier as observer
sys.path.insert(0,str(BASE))
import controls
import normal as original
import score

runtime=original.load("amended_pgo_native_runtime",HERE/"normal-runtime.py")
RESULT=HERE/"observed"
PLAN=HERE/"registration.json"
V2="d9027d2f09a69a776a0dc20ec81c4ea215055808d73be578e6fa56e59857786e"


def seal():
    observer.verify_seal()
    s.require(s.sha(BASE/"observer-v2/amendment.json")==V2,"direct observer changed")
    plan=s.read(PLAN)
    for path,checksum in plan["files"].items():
        s.require(s.sha(s.WORK/path)==checksum,"normal PGO registration drift: "+path)
    s.require(s.read(HERE/"schedule.json")["normal"]==s.read(BASE/"schedule.json")["normal"] and
              s.read(HERE/"schedule.json")["risk"]==s.read(BASE/"schedule.json")["risk"],"j8 order changed")


@contextlib.contextmanager
def authorized(phase,cohort,extra_gib):
    seal()
    grant=HERE/"grants"/f"{phase}-{cohort}.json"
    checksum=os.getenv("SMALL_FRONTEND_GRANT_SHA256")
    s.require(checksum and grant.is_file() and s.sha(grant)==checksum,"normal PGO grant missing")
    g=s.read(grant)
    s.require(set(g)=={"phase","cohort","registration_sha256","host_boot_id","cpus","release","release_sha256",
                       "expires_utc_ns","drivers_sha256"},"invalid grant schema")
    s.require(phase==g["phase"] and cohort==g["cohort"] and g["registration_sha256"]==s.sha(PLAN) and
              g["host_boot_id"]==Path("/proc/sys/kernel/random/boot_id").read_text().strip() and
              time.time_ns()<g["expires_utc_ns"],"wrong normal grant authority")
    wanted=tuple(range(24,32)) if phase=="pgo-build-head" else s.NATIVE_CPUS
    s.require(tuple(g["cpus"])==wanted and tuple(sorted(os.sched_getaffinity(0)))==wanted,"registered affinity required")
    release=Path(g["release"])
    s.require(release.is_absolute() and release.parent==s.LAB and s.sha(release)==g["release_sha256"],
              "host release no longer matches")
    with (s.ROOT/"native-lease").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        s.require(shutil.disk_usage(s.BENCH).free>=(120+extra_gib)*s.GIB,"reserve")
        for rel in (Path("bin/rustc"),s.LINK):
            s.require(s.sha(s.DIST/rel)==s.sha(s.TOOLS/rel),"stock tool drift")
        yield g


def qualified_direct(counts):
    # The original scoring function owns its module's path globals. Keep its direct input roots
    # at the original registration while a different normal-jobs view is installed in this process.
    prior=(score.HERE,score.RESULT,score.ENDPOINTS,score.tag)
    try:
        score.HERE=BASE
        score.RESULT=observer.RESULT
        score.ENDPOINTS=s.ENDPOINTS
        score.tag=s.tag
        return observer.direct_result(counts)
    finally:
        score.HERE,score.RESULT,score.ENDPOINTS,score.tag=prior


def audit_head():
    with authorized("pgo-audit","initial",4) as grant:
        s.require(qualified_direct(True)["eligible"],"no qualifying replicated direct screen")
        request=HERE/"candidate-request.json"
        s.require(s.sha(request)==grant["drivers_sha256"],"wrong proposed source/driver")
        checked=pgo.verify_candidate(s.read(request))
        s.save(HERE/"audited-drivers.json",{"request_file_sha256":s.sha(request),
               "registration_sha256":s.sha(PLAN),"audit":checked})


def variants(grant):
    receipt=HERE/"audited-drivers.json"
    s.require(s.sha(receipt)==grant["drivers_sha256"],"wrong independently audited PGO pair")
    receipt=s.read(receipt)
    a=receipt["audit"]
    s.require(receipt["registration_sha256"]==s.sha(PLAN) and
              receipt["request_file_sha256"]==s.sha(HERE/"candidate-request.json"),"candidate custody changed")
    h=Path(a["head"])
    s.require(s.sha(h)==a["head_sha256"]!=pgo.BASE_SHA and s.sha(pgo.BASE_BIN)==a["base_sha256"]==pgo.BASE_SHA and
              a["std_sha256"]==pgo.STD_SHA and a["head_profile_sha256"]!=a["base_profile_sha256"]==pgo.BASE_PROFILE,
              "not the two verified independently trained Cargo drivers")
    return {"shipped":s.DIST/"bin/cargo","head":h,"base":pgo.BASE_BIN}


def native_order(cohort,selected):
    order=("build","test") if cohort=="initial" else ("test","build")
    return ("check",*(ep for ep in order if ep in selected))


def default_tag(cohort,endpoint,block):
    return ("Q" if cohort=="initial" else "Z")+endpoint[0].upper()+f"{block:03}"


def default_argv(endpoint,options=None):
    s.require(options is None,"default jobs mode forbids overriding command options")
    return [str(s.TOOLS/"bin/cargo"),*{"check":["check"],"build":["build"],"test":["test","--no-run"]}[endpoint],
            "--locked","--offline"]


def default_scope(cohort):
    root=s.fixture(cohort)
    e=runtime.worker.env(root)
    s.require(not any(k in e for k in ("CARGO_BUILD_JOBS","NUM_JOBS","CARGO_MAKEFLAGS","MAKEFLAGS")),
              "ambient job policy present")
    candidates=[root/"cargo-home/config",root/"cargo-home/config.toml"]
    for p in (root/"uv",*(root/"uv").parents):
        candidates.extend((p/".cargo/config",p/".cargo/config.toml"))
    hashes={}
    for p in candidates:
        if not p.is_file():continue
        cfg=tomllib.loads(p.read_text())
        s.require("jobs" not in cfg.get("build",{}) and "include" not in cfg and
                  not ({"CARGO_BUILD_JOBS","NUM_JOBS","CARGO_MAKEFLAGS","MAKEFLAGS"}&cfg.get("env",{}).keys()),
                  "implicit-jobs command has an unresolved external Cargo job limit")
        hashes[str(p)]=s.sha(p)
    return {"cpu_affinity":sorted(os.sched_getaffinity(0)),"cpu_max":Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
            "cargo_config_files":hashes,"job_argument_omitted":True,"job_env_variables_absent":True}


def selected_previous():
    result=score_normal("j8",s.ENDPOINTS)
    trusted=HERE/"j8-qualified.json"
    s.require(trusted.is_file() and s.read(trusted)==result,"qualified endpoint receipt does not match raw -j8 cohorts")
    selected=result["qualified_endpoints"]
    s.require(selected,"no -j8 endpoint actually promoted")
    return tuple(selected)


def install(mode,selected):
    new=mode=="default"
    active_plan=HERE/"default-plan" if new else HERE
    runtime.HERE=active_plan
    runtime.RESULT=RESULT/mode
    runtime.drivers=variants
    runtime.pool=lambda co:s.fixture(co)/("small-frontend-pgo-"+mode+"-common-v3")
    runtime.endpoint_order=lambda co:native_order(co,selected)
    runtime.ENDPOINTS=tuple(selected)
    runtime.tag=default_tag if new else s.tag
    runtime.worker.command=default_argv if new else normal_command
    score.direct_result=qualified_direct
    # The current helper consults the original structural/correctness gate at RESULT/controls.
    # Keep each independently named root and expose it by a verified plain receipt, never a symlink.
    def enter(phase,cohort,extra):
        return authorized(f"pgo-{mode}-{phase.removeprefix('normal-')}",cohort,extra)
    runtime.authorized=enter
    score.RESULT=RESULT/mode
    score.HERE=active_plan
    score.ENDPOINTS=tuple(selected)
    score.tag=default_tag if new else s.tag


normal_command=runtime.worker.command


def score_normal(mode,selected):
    install(mode,selected)
    out=score.normal_result()
    receipt=s.read(HERE/"audited-drivers.json")
    ready=receipt["audit"]
    for cohort in s.COHORTS:
        root=RESULT/mode/"normal"/cohort
        info=s.read(root/"inputs.json")
        s.require(info["arms"]=={"shipped":s.sha(s.DIST/"bin/cargo"),"base":pgo.BASE_SHA,
                                  "head":ready["head_sha256"]},"timed wrong Cargo variants")
        s.require(info["released_rustc"]==s.sha(s.DIST/"bin/rustc") and
                  info["released_wild"]==s.sha(s.DIST/s.LINK),"timed wrong compiler or linker")
        expected=default_argv if mode=="default" else normal_command
        s.require(all(info["commands"][ep]==expected(ep) for ep in ("check",*selected)),"different whole command")
        s.require(info["grant"]["drivers_sha256"]==s.sha(HERE/"audited-drivers.json") and
                  info["grant"]["registration_sha256"]==s.sha(PLAN),"timed ungranted drivers")
        if mode=="default":
            env_receipt=s.read(RESULT/mode/"jobs"/(cohort+".json"))
            s.require(env_receipt["job_argument_omitted"] and env_receipt["job_env_variables_absent"],"explicit jobs found")
    out.update(mode=mode,registration_sha256=s.sha(PLAN),drivers_sha256=s.sha(HERE/"audited-drivers.json"),
               inputs={"shipped":s.sha(s.DIST/"bin/cargo"),"matched":pgo.BASE_SHA,"head":ready["head_sha256"]},
               per_driver_profiles={"matched":pgo.BASE_PROFILE,"head":ready["head_profile_sha256"]})
    return out


def controls_run():
    controls.authorized=lambda _,c,n:authorized("pgo-controls",c,n)
    controls.RESULT=RESULT/"j8"
    controls.HERE=HERE
    controls.normal.drivers=variants
    score.direct_result=qualified_direct
    controls.run()


def retire(mode,cohort):
    """Separate lease, original inode identity and complete raw evidence required for one's own three banks."""
    with authorized("pgo-"+mode+"-retire",cohort,2) as grant:
        variants(grant)
        root=s.fixture(cohort)
        bank=runtime.pool(cohort)
        out=RESULT/mode/"normal"/cohort
        ready=s.read(bank/"ready.json")
        returned=s.read(out/"returned.json")
        selected=s.ENDPOINTS if mode=="j8" else selected_previous()
        s.require(all((out/ep/"done.json").is_file() for ep in selected) and (out/"check/unchanged.json").is_file(),
                  "native cohort unfinished")
        s.require((root/"target").stat().st_ino==returned["original_target_ino"] and
                  sha_live_source(root,returned) and not (bank/"original-target").exists(),"unrestored normal custody")
        s.require(ready["drivers"]=={a:s.sha(v) for a,v in variants(grant).items()},"wrong banks")
        for arm in s.NORMAL:
            path=bank/arm
            s.require(not path.is_symlink() and path.is_dir() and path.stat().st_ino==
                      ready["checks"][str(path)]["dir_ino"]==returned["banks"][arm],"supplied target is not the registered clone")
        s.save(out/"allocation-copy.json",ready)
        for arm in s.NORMAL:
            shutil.rmtree(bank/arm)
        s.save(out/"retired.json",{"returned_sha256":s.sha(out/"returned.json"),"names":list(s.NORMAL),
                                   "reserve_bytes":shutil.disk_usage(s.BENCH).free})


def sha_live_source(root,r):
    f=root/"uv"/s.SOURCE
    return (s.sha(f)==r["source_sha256"] and f.stat().st_mtime_ns==r["source_mtime_ns"] and
            s.sha(root/"uv/Cargo.lock")==r["lock_sha256"] and (s.TOOLS/"bin/cargo").samefile(s.ROOT/"official-original-cargo"))


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("build-head","audit-head","controls","prepare","time","retire","score","seal-j8","check-seal"))
    p.add_argument("--mode",choices=("j8","default"),default="j8")
    p.add_argument("--cohort",choices=s.COHORTS)
    a=p.parse_args()
    seal()
    if a.action=="check-seal":
        print("PGO and direct observer registrations verified.")
        return
    if a.action=="build-head":
        with authorized("pgo-build-head","initial",35) as grant:
            s.require(qualified_direct(True)["eligible"],"direct gate did not qualify")
            request=HERE/"candidate-source.json"
            s.require(s.sha(request)==grant["drivers_sha256"],"ungranted source implementation")
            build_head.build(s.read(request))
        return
    if a.action=="audit-head":
        audit_head()
        return
    if a.action=="controls":
        controls_run()
        return
    selected=selected_previous() if a.mode=="default" else s.ENDPOINTS
    install(a.mode,selected)
    if a.action in ("score","seal-j8"):
        value=score_normal(a.mode,selected)
        if a.action=="seal-j8":
            s.require(a.mode=="j8","only the registered -j8 study can open default-jobs eligibility")
            s.save(HERE/"j8-qualified.json",value)
        print(json.dumps(value,indent=2,sort_keys=True))
        return
    s.require(a.cohort,"specify an actual cohort")
    if a.mode=="default" and a.action=="prepare":
        # Gate with the same approved lease used by the native worker, before allocating any new bank.
        original_auth=runtime.authorized
        @contextlib.contextmanager
        def default_auth(phase,cohort,extra):
            with original_auth(phase,cohort,extra) as grant:
                inherited=s.read(RESULT/"j8/controls/done.json")
                s.require(inherited["eligible"],"registered synthetic inputs did not qualify")
                landing=RESULT/"default/controls"
                landing.mkdir(exist_ok=True,parents=True)
                target=landing/"done.json"
                if not target.exists():s.save(target,inherited)
                s.require(s.read(target)==inherited,"different inherited common structural gate")
                dest=RESULT/"default/jobs"
                dest.mkdir(parents=True,exist_ok=True)
                s.save(dest/(cohort+".json"),default_scope(cohort))
                yield grant
        runtime.authorized=default_auth
    if a.action=="prepare":runtime.prepare(a.cohort)
    elif a.action=="time":runtime.execute(a.cohort)
    else:retire(a.mode,a.cohort)


if __name__=="__main__":
    main()
