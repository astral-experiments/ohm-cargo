"""Verify physical return and independently reconstruct the original structural controls and risk rows."""
import argparse, fcntl, hashlib, json, os, runpy, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;V3=HERE.parent
sys.path.insert(0,str(V3.parent))
import study as s, controls, score
d=V3/"observed/j8/controls"
own=s.read(HERE/"owner.json");ben=s.BENCH
def live():
    group=own["owner"]["pgid"]
    tools={"cargo","rustc","rustdoc","rust-lld","ld.bfd","ld.lld","wild","llvm-profdata","drrun","valgrind","collect2","cc1","cc1plus","clang","clang++"}
    active=[]
    for p in Path("/proc").glob("[0-9]*/stat"):
        try:
            raw=p.read_text();e=raw.rfind(")");row=raw[e+2:].split();name=raw[raw.find("(")+1:e]
            if row[0] in ("Z","X") or p.parent.stat().st_uid!=os.getuid():continue
            exe=os.readlink(p.parent/"exe")
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if name in tools or exe.startswith(str(s.SCRATCH/"controls")+"/") or int(row[2])==group or int(row[3])==group:active.append([int(p.parent.name),name,row[0],exe])
    return active
def behavioral(dir):
    rows=[json.loads(ln) for ln in (dir/"stdout").read_text().splitlines() if ln.startswith("{")]
    arts=[r for r in rows if r["reason"]=="compiler-artifact" and r["target"]["name"]=="frontprobe"]
    assert len(arts)==1 and arts[0]["fresh"] is False
    assert any(r["reason"]=="build-finished" and r["success"] for r in rows)
    return arts[0]["filenames"]
def body(code):
    grant=V3/"grants/pgo-controls-initial.json";g=s.read(grant)
    assert s.sha(grant)=="ce7f03d41bbe0916b82414102818ab4a66adfb70522bede7e7e50b92367f8e68" and s.sha(Path(g["release"]))==g["release_sha256"]
    assert g["drivers_sha256"]==s.sha(V3/"audited-drivers.json") and own["external_tool_session"]==50170
    assert not live(),"live owned or foreign native tools"
    before=s.read(V3.parent/"observer-v2/physical-host-return.json")
    shared={}
    for co,paths in before["original_source_and_lock"].items():
        for path,want in paths.items():
            p=Path(path);st=p.stat()
            got={"inode":st.st_ino,"mtime_ns":st.st_mtime_ns,"sha256":s.sha(p)}
            assert got==want;shared[path]=got
    slots={}
    for rel,digest in before["released_tool_slots"].items():
        p=s.TOOLS/rel;assert s.sha(p)==s.sha(s.DIST/rel)==digest
        if rel=="bin/cargo" or rel==str(s.LINK):assert p.samefile(s.ROOT/("official-original-cargo" if rel=="bin/cargo" else "official-original-wild"))
        slots[rel]=digest
    current={p.name:p for p in d.iterdir() if p.is_dir()};bank=s.SCRATCH/"controls"
    assert not any((bank/n/"target").exists() for n in current),"control target still checked out"
    with (s.ROOT/"native-lease").open("a") as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(f,fcntl.LOCK_UN)
    x=os.statvfs(ben);available=x.f_bavail*x.f_frsize;assert available>=120*s.GIB
    ret={"external_tool_session":50170,"actual_exit":code,"grant_sha256":s.sha(grant),"driver_receipt_sha256":g["drivers_sha256"],
         "release_sha256":g["release_sha256"],"owner":own,"global_and_owned_live_native":[],"lease_reacquired_then_released":True,
         "official_slot_hashes":slots,"source_and_lock_unchanged":shared,"all_case_active_targets_vacant":True,
         "free_after_bytes":available,"private_targets_retained":True,"cases_seen":list(current),"closed_ns":time.time_ns()}
    if code==0:
        done=s.read(d/"done.json");assert done["cases"]==list(controls.CASES)
        structural={}
        for name,(kind,ep,override) in controls.CASES.items():
            c=d/name;assert s.read(c/"done.json")=={"all_control_flags_and_products_match":True}
            by={}
            for phase in ("cold","edit","next"):
                products=[]
                for arm in s.NORMAL:
                    q=c/(phase+"-"+arm)/"receipt.json";r=s.read(q)
                    one=phase!="cold" and (kind=="tiny" or kind=="transition" and phase=="edit") and override not in ("no-incremental","target") and arm=="head"
                    expected=["8"]+(["1"] if one else [])+(["4"] if override in ("joined","split") else [])
                    assert all(t["flags"]==expected for t in r["targets"]) and sorted(t["harness"] for t in r["targets"])==([False,True] if ep=="test" else [False])
                    by[phase+"-"+arm]=s.sha(q);products.append(r["products"])
                assert products.count(products[0])==3
            structural[name]=by
        rdir=d/"new-module";rows=s.read(rdir/"timings.json");frozen=s.read(V3/"schedule.json")["risk"]
        blocks=score.assigned(rows,frozen);assert len(blocks)==24
        block_digests=[];fixed={}
        for i,block in enumerate(blocks):
            products=[];hashes=[]
            for row in block:
                f=rdir/f'm{i:03}-{row["rank"]}-{row["arm"]}';receipt=s.read(f/"receipt.json")
                assert receipt["elapsed_ns"]==row["elapsed_ns"] and len(behavioral(f))==1
                products.append(receipt["products"]);hashes.append(s.sha(f/"receipt.json"))
            assert products.count(products[0])==3
            block_digests.append(s.hbytes(json.dumps(products[0],sort_keys=True).encode()));fixed[str(i)]=hashes
        assert len(set(block_digests))==24,"distinct genuine edits did not yield distinct executables"
        risk={arm:score.compare(blocks,arm,"head",33120+i) for i,arm in enumerate(("base","shipped"))}
        assert json.loads(json.dumps(risk))==s.read(rdir/"risk.json")==done["risk"]
        gate=all(z["median_saved_pct_interval"]["lower"]>-5 or z["median_saved_ms_interval"]["lower"]>-10 for z in risk.values())
        assert gate==done["eligible"]
        ret.update(gate=gate,raw_done_sha256=s.sha(d/"done.json"),raw_risk_sha256=s.sha(rdir/"risk.json"),
                   raw_timing_sha256=s.sha(rdir/"timings.json"),risk=risk,all_72_real_rebuilds=True,all_24_distinct_edits_and_products=True,
                   risk_command_receipt_hashes=fixed,structural_receipt_hashes=structural)
    return ret
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--actual-exit",type=int,required=True);r=body(p.parse_args().actual_exit)
    s.save(HERE/"returned.json",r);print(json.dumps({k:r.get(k) for k in ("actual_exit","gate","free_after_bytes","raw_done_sha256")}))
