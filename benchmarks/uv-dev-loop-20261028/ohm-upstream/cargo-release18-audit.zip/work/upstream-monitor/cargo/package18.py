#!/usr/bin/env python3
"""Collect compact public-source inputs, receipts, complete measured command logs and replay code."""
import hashlib, json, zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parents[1]
root = work.parent
names = ['REPORT.md','reproduce.md','base-7caf399.tar.gz','depfile-plan.json','depfile-registration.sha256','measurement-harness.sha256','exec-admission-harness.sha256','release18-apply.json','depfile-results.json','release18-audit.json','counter-identities.json','drivers.json','snapshot.json','terminal-status.json','review-feedback.json','all-prs.json','all-pr-paths.json','posted-hunks.json','posted-legacy-hunks.json','open-pr-index.json','register.py','build18.py','warm18.py','run18.py','verify-processes18.py','finish18.py','execute18.sh','package18.py','posted.py','posted-legacy.py','snapshot.py','execution.log']
files = {here / n for n in names}
for patt in ['near-*','stats-*.json','count-*.log','build-logs/*.log','patches/*.patch','warm-*/*','native-exec-*/*','admission-*/*','count-*/*']:
    files.update(p for p in here.glob(patt) if p.is_file())
files.update([work/'measure.py', work/'dynamorio/count.py', here.parent/'toolchain18-binaries.sha256', here.parent/'cargo-history/README.md', here.parent/'cargo-history/audit-receipts.zip'])
files.update((here.parent/'download18').glob('*provenance.json'))
files.update((here.parent/'download18').glob('*.tar.gz.sha256'))
assert all(p.is_file() for p in files)
assert len([p for p in files if p.name=='pairs.csv'])==2
assert len([p for p in files if p.name.endswith('.log') and p.parent.name.startswith('count-') and 'warm' not in p.name])==40
output=here.parent/'cargo-release18-audit.zip'; tmp=output.with_suffix('.zip.next')
with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(files):z.write(f,f.relative_to(root))
with zipfile.ZipFile(tmp) as z:
    assert z.testzip() is None
    assert all(p.relative_to(root).as_posix() in z.namelist() for p in files)
tmp.replace(output)
with output.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
print(f'{sha}  {output.name}')
(here.parent/'cargo-release18-audit.sha256').write_text(f'{sha}  {output.name}\n')
