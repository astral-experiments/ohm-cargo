#!/usr/bin/env python3
"""Read public upstream metadata through the OSS-routed GitHub client; retain compact receipts."""
import base64
import concurrent.futures as cf
import datetime
import json
from pathlib import Path
import re
import subprocess
import tempfile
import urllib.parse

HERE = Path(__file__).resolve().parent
W = HERE.parents[1]
GIT = W/'ohm-cargo'
GH = '/home/dev-user/.local/bin/gh-auto'
OSS = '/home/dev-user/code/oss/relic'
OHM = 'astral-sh/ohm-cargo'
NUMS = [264,267,268,269,270]
APIPR = 'number,title,url,state,isDraft,headRefName,headRefOid,baseRefName,baseRefOid,mergeable,mergeStateStatus,reviewDecision,updatedAt,statusCheckRollup,reviews,comments,files'

def gh(*args):
    return subprocess.check_output([GH,*args],cwd=OSS,text=True)

def api(path):
    return json.loads(gh('api',path))

def git(*args):
    return subprocess.check_output(['git','-C',str(GIT),*args],text=True)

def save(name,value):
    (HERE/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def slim_compare(j):
    return dict(status=j['status'], ahead=j['ahead_by'],behind=j['behind_by'],
        merge_base=j['merge_base_commit']['sha'],url=j['html_url'],
        files=[f['filename'] for f in j['files']],
        commits=[dict(sha=c['sha'],title=c['commit']['message'].splitlines()[0],url=c['html_url']) for c in j['commits']])

def main():
    receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    reqs={'release':('api','repos/astral-sh/ohm/releases/latest'),
          'ohm':('api',f'repos/{OHM}'),
          'release18_source':('api','-H','Accept: application/vnd.github.raw+json','repos/astral-sh/ohm/contents/toolchains/1.99.0/18.json?ref=ohm-1.99.0-18'),
          'release17_source':('api','-H','Accept: application/vnd.github.raw+json','repos/astral-sh/ohm/contents/toolchains/1.99.0/17.json?ref=ohm-1.99.0-17'),
          'provenance':('api','-H','Accept: application/octet-stream','repos/astral-sh/ohm/releases/assets/686166614')}
    for n in NUMS:
        reqs[n]=('pr','view',str(n),'--repo',OHM,'--json',APIPR)
    with cf.ThreadPoolExecutor(8) as pool:
        results={k:pool.submit(gh,*v) for k,v in reqs.items()}
        j={k:json.loads(f.result()) for k,f in results.items()}
    receipt['release']={f:j['release'][f] for f in ('tag_name','published_at','html_url','target_commitish')}
    receipt['ohm']={f:j['ohm'][f] for f in ('full_name','default_branch','pushed_at','html_url')}
    receipt.update(release18_source=j['release18_source'],release17_source=j['release17_source'],provenance=j['provenance'])
    prs={}
    for n in NUMS:
        v=j[n]
        prs[n]={k:v[k] for k in v if k not in ('statusCheckRollup','reviews','comments','files')}
        prs[n]['files']=[f['path'] for f in v['files']]
        prs[n]['checks']=[{k:c.get(k) for k in ('name','workflowName','status','conclusion','detailsUrl') } for c in v['statusCheckRollup']]
        prs[n]['reviews']=[{k:r.get(k) for k in ('state','author','submittedAt','url')} for r in v['reviews']]
        prs[n]['comments']=[{k:r.get(k) for k in ('author','createdAt','url')} for r in v['comments']]
        assert git('rev-parse',prs[n]['headRefName']).strip()==v['headRefOid']
        assert git('rev-parse',v['headRefOid']+'^').strip()==v['baseRefOid']
    receipt['drafts']=prs
    q={'ohm_default':f'repos/{OHM}/branches/'+receipt['ohm']['default_branch'],'ohm_199':f'repos/{OHM}/branches/ohm-1.99.0'}
    with cf.ThreadPoolExecutor(5) as pool:
        f={k:pool.submit(api,x) for k,x in q.items()}; br={k:v.result() for k,v in f.items()}
    receipt['refs']={k:dict(sha=v['commit']['sha'],title=v['commit']['commit']['message'].splitlines()[0],url=v['commit']['html_url']) for k,v in br.items()}
    for ver in ('17','18'):
        sha=j['release'+ver+'_source']['sources']['cargo']['revision']
        receipt['refs']['ohm_'+ver]=dict(sha=sha,url=f'https://github.com/{OHM}/commit/{sha}')
    base=receipt['refs']['ohm_17']['sha']
    receipt['comparisons']={}
    with cf.ThreadPoolExecutor(6) as pool:
        fut={label:pool.submit(api,f'repos/{OHM}/compare/{base}...'+receipt['refs'][label]['sha']) for label in ['ohm_18','ohm_default','ohm_199']}
        receipt['comparisons']={k:slim_compare(v.result()) for k,v in fut.items()}
    save('snapshot.json',receipt)
    print({k:v['sha'] for k,v in receipt['refs'].items()})
    print('wrote five verified draft parents/heads, branch tips, checks and exact -17/-18 metadata')

if __name__=='__main__':
    main()
