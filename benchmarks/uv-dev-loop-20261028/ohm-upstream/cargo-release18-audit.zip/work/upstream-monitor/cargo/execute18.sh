#!/bin/sh
set -eu
# Run once after base exec admission. Reproduction from a fresh root runs both exec admissions.
cargo_study_dir=$(cd "$(dirname "$0")" && pwd)
cd "$cargo_study_dir/../../.."
sha256sum -c "$cargo_study_dir/depfile-registration.sha256"
sha256sum -c "$cargo_study_dir/measurement-harness.sha256"
sha256sum -c "$cargo_study_dir/exec-admission-harness.sha256"
python3 -B - "$cargo_study_dir/drivers.json" <<'PY'
import json, sys, time
from pathlib import Path
path = Path(sys.argv[1]); deadline = time.monotonic() + 1800
while time.monotonic() < deadline:
    try:
        if 'candidate' in json.loads(path.read_text())['arms']:
            break
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    time.sleep(3)
else:
    raise SystemExit('The matched candidate driver did not finish within 30 minutes')
PY
test -f "$cargo_study_dir/native-exec-base/rosters.json"
taskset -c 24-27 python3 -B "$cargo_study_dir/verify-processes18.py" candidate
taskset -c 24-27 python3 -B "$cargo_study_dir/run18.py"
