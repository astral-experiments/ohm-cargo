#!/usr/bin/env python3
"""Record the full successful exec roster on each admitted, already fresh target before counting."""
import hashlib, json, os, re, subprocess, sys
from pathlib import Path

here = Path(__file__).resolve().parent
work = here.parents[1]
release = here.parent / 'toolchain18' / 'bin'
plan = json.loads((here / 'depfile-plan.json').read_text())
drivers = json.loads((here / 'drivers.json').read_text())
arm, = sys.argv[1:]
assert arm in ('base', 'candidate')
assert sorted(os.sched_getaffinity(0)) == plan['measurement_cpus']
with (here / 'bin' / arm).open('rb') as f:
    assert hashlib.file_digest(f, 'sha256').hexdigest() == drivers['arms'][arm]['sha256']
out = here / ('native-exec-' + arm)
out.mkdir()
rosters = {}
for label, cfg in plan['cohorts'].items():
    ready = json.loads((here / f'warm-{label}/ready.json').read_text())
    slot = work / 'bin' / ('measured-' + cfg['target']) / 'cargo'
    temp = slot.with_suffix('.exec-audit-next')
    os.link(here / 'bin' / arm, temp)
    os.replace(temp, slot)
    env = dict(os.environ, PATH=str(release) + ':' + os.environ['PATH'],
               RUSTC=str(release/'rustc'), RUSTDOC=str(release/'rustdoc'),
               CARGO_TARGET_DIR=ready['target'], CARGO_HOME=ready['cargo_home'],
               CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never')
    trace = out / f'{label}.trace'
    with (out / f'{label}.log').open('x') as f:
        subprocess.run(['strace', '-f', '-qq', '-s', '4096', '-e', 'trace=execve,execveat',
                        '-o', trace, slot, 'build'], cwd=ready['source'], env=env,
                       stdout=f, stderr=subprocess.STDOUT, check=True)
    entries = [s for s in trace.read_text().splitlines() if re.search(r'= 0$', s)]
    rosters[label] = entries
    if len(entries) != 1 or 'execve("' + str(slot) + '", ' not in entries[0]:
        raise SystemExit(f'unexpected executable roster in {trace}: {entries}')
    log = (out / f'{label}.log').read_text()
    if not re.search(r'^\s*Finished ', log, re.M) or re.search(r'^\s*(Checking|Compiling|Blocking|Running|Updating|Downloading) ', log, re.M):
        raise SystemExit(f'non-fresh native execution in {label}/{arm}')
(out / 'rosters.json').write_text(json.dumps(rosters, indent=2) + '\n')
