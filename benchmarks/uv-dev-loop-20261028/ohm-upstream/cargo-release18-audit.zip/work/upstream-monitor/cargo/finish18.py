#!/usr/bin/env python3
"""Recompute saved results from raw paired rows and append the bounded release-18 finding."""
import json, sys
from pathlib import Path
here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
import run18
plan = run18.P
drivers = run18.DRIVERS
results = json.loads((here/'depfile-results.json').read_text())
def count(v):return f'{v:,.1f}'.removesuffix('.0')

rows=[]; audit={}; depfiles={}; results_pass=True
for name,c in plan['cohorts'].items():
    raw=run18.summarize(here/f'count-{name}',c)
    assert raw==results['cohorts'][name]
    assert raw==json.loads((here/f'stats-{name}.json').read_text())
    results_pass &= raw['passed']
    s=raw; ci=s['rank_interval']; tool='DynamoRIO' if c['mode']=='dynamorio' else 'Cachegrind'
    rows.append(f"| {tool} | {s['n']} | {count(s['median_base'])} | {count(s['median_candidate'])} | {s['median_reduction']:.3%} | {ci[0]:.3%} to {ci[1]:.3%} | {s['wins']}/{s['n']} | {s['sign_p']:.6g} | {s['balanced_order_p']:.6g} |")
    admission=json.loads((here/f'admission-{name}/admitted.json').read_text()); a,b=admission['base'],admission['candidate']
    assert a['uv_d_sha256']==b['uv_d_sha256'] and a['all_public_depfiles']==b['all_public_depfiles']
    for arm,data in admission.items():
        assert data['ordinary_successful_uv_d_reads'] and data['sha256']==drivers['arms'][arm]['sha256']
        assert len(json.loads((here/f'native-exec-{arm}/rosters.json').read_text())[name])==1
    depfiles[name]=(len(a['all_public_depfiles']),a['regenerated_bytes']);audit[name]={'reduced_statistics_match_saved_summary':True,'public_depfile_hashes_match_for_both_arms':True,'uv_d_bytes':a['regenerated_bytes'],'successful_native_programs_per_command':1,'raw_csv_sha256':s['raw_sha256']}
assert results_pass==results['replicated']
section='''## Release-18 measurement of #269 on top of the shipped collector

We selected ordinary full-workspace `cargo build` after warming unmodified uv `c22e6b71`. Both Cargo drivers used Ohm’s distributed release-18 compiler `a4fa11bc` and the same release-style flags. The predecessor applies #264, #267 and #268 to `7caf3991`. The candidate adds precisely #269. Ohm’s shipping PGO profile was unavailable. The comparisons use one stable Cargo executable path per cohort and independent source, registry and target roots for the two counters.

| Counter | Pairs | Parent median instructions | #269 median instructions | Median paired reduction | Median rank interval | Pairs improved | Sign p | Balanced-order p |
|---|---:|---:|---:|---:|---|---:|---:|---:|
'''+'\n'.join(rows)+'\n\n'
qualified='The incremental reduction passed the prespecified gate in both setups.' if results_pass else 'The incremental reduction did not meet every prespecified gate.'
section+=f"{qualified} The intervals have at least 95% coverage. Each native exec trace showed Cargo as the only program, and every counted command remained fresh. Native `strace` recorded successful reads of `target/debug/uv.d` in both arms of each cohort. Forcing its removal and regeneration preserved all {depfiles['initial'][0]} public depfiles byte for byte on the initial root and all {depfiles['replica'][0]} on the replica. The regenerated `uv.d` files were {depfiles['initial'][1]:,} and {depfiles['replica'][1]:,} bytes, respectively, because their absolute source and dependency paths differ. The numbers describe the Cargo process and its threads on a warm default build. [Shipped collector](https://github.com/astral-sh/ohm-cargo/pull/262), [renderer draft](https://github.com/astral-sh/ohm-cargo/pull/269)\n"
p=here/'REPORT.md';body=p.read_text().partition('\n## Release-18 measurement')[0];p.write_text(body.rstrip()+'\n\n'+section)
(here/'release18-audit.json').write_text(json.dumps({'replicated':results_pass,'cohorts':audit},indent=2)+'\n')
print(section)
