#!/usr/bin/env python3
"""Audit posted Ohm Cargo changes, including landed sources from formally open pull requests."""
import concurrent.futures as cf
import datetime,json,re,time
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from snapshot import api,gh,OHM,save

ROOT=Path(__file__).resolve().parent
SNAP=json.loads((ROOT/'snapshot.json').read_text())
OUR={int(n):v for n,v in SNAP['drafts'].items()}
EXACT={f for v in OUR.values() for f in v['files']}
# Match modified source lines and the surrounding hunk's original function, even when the full
# historical branch diff contained unrelated compiler changes.
WATCH={
    'src/compiler/build_runner/mod.rs':r'\bfn unit_deps\b|unit_deps.*\[UnitDep\]',
    'src/compiler/fingerprint/mod.rs':r'Vec::from\(build_runner\.unit_deps|DepFingerprint::new|fn calculate_normal\b|fn new\(.*BuildRunner',
    'src/compiler/mod.rs':r'Vec::from\(build_runner\.unit_deps|for dep in build_runner\.unit_deps',
    'src/workspace/parser/mod.rs':r'fn validate_dependencies|unused_dep_keys|table_in_toml|\.unused_keys\(\)',
    'src/resolver/features.rs':r'fn deps_for_features|struct FeatureResolver|activate_dep_feature|activate_dependency|deps_for_features|filtered_deps',
    'src/compiler/output_depinfo.rs':r'render_filename|wrap_path|Cow::Borrowed|Cow::Owned|dep_bytes|single_output|write!\(contents|write_if_changed|add_deps_for_unit|fn output_depinfo',
    'src/util/semver_ext.rs':r'OptVersionReq|fn (lock_to|precise_to)|\.clone\(\)|mem::take',
}

def main():
    query='query($cursor:String){repository(owner:"astral-sh",name:"ohm-cargo"){pullRequests(first:80,after:$cursor,orderBy:{field:CREATED_AT,direction:DESC}){pageInfo{hasNextPage endCursor}nodes{number title url state mergedAt closedAt isDraft baseRefName headRefOid updatedAt files(first:100){totalCount pageInfo{hasNextPage}nodes{path}}}}}}'
    rows=[];cursor=None
    while True:
        cmd=['api','graphql','-f','query='+query]
        if cursor:cmd+=['-f','cursor='+cursor]
        x=json.loads(gh(*cmd))['data']['repository']['pullRequests']
        rows+=x['nodes']
        if not x['pageInfo']['hasNextPage']:break
        cursor=x['pageInfo']['endCursor']
    pairs={}
    for row in rows:
        files=row.pop('files')
        names=[f['path'] for f in files['nodes']]
        if files['pageInfo']['hasNextPage']:
            names=[f['filename'] for pg in json.loads(gh('api','--paginate','--slurp',f"repos/{OHM}/pulls/{row['number']}/files?per_page=100")) for f in pg]
        row['file_count']=len(names)
        row['matched_files']=sorted(n for n in names if n in EXACT)
        if row['matched_files']:pairs[row['number']]=row
    save('all-prs.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'total':len(rows),'open':sum(r['state']=='OPEN' for r in rows),'touched_any_exact_file':len(pairs),'prs':rows})
    cache=ROOT/'hunk-cache';cache.mkdir(exist_ok=True)
    def inspect(pair):
        num,row=pair
        cached=cache/f"{num}-{row['headRefOid']}.json"
        if cached.is_file():return num,json.loads(cached.read_text())
        for attempt in range(3):
            try:
                if row['file_count']>100:
                    raw=[f for pg in json.loads(gh('api','--paginate','--slurp',f'repos/{OHM}/pulls/{num}/files?per_page=100')) for f in pg]
                else:raw=api(f'repos/{OHM}/pulls/{num}/files?per_page=100')
                break
            except Exception:
                if attempt==2:raise
                time.sleep(2**attempt)
        found={}
        for f in raw:
            path=f['filename']
            if path not in EXACT:continue
            chunks=re.split('(?m)(?=^@@)',f.get('patch') or '')
            records=[]
            for h in chunks:
                if not h:continue
                lines=h.splitlines();rx=WATCH[path]
                added_removed=[s for s in lines[1:] if s[:1] in '+-']
                related=[s for s in added_removed if re.search(rx,s)]
                if related or re.search(rx,lines[0]):
                    records.append(dict(header=lines[0],match_lines=related,additions=sum(s.startswith('+') for s in added_removed),deletions=sum(s.startswith('-') for s in added_removed)))
            found[path]={'head_blob':f['sha'],'patch_returned':bool(f.get('patch')),'matched_hunks':records}
        cached.write_text(json.dumps(found,indent=2)+'\n')
        return num,found
    with cf.ThreadPoolExecutor(4) as pool:
        results=dict(pool.map(inspect,pairs.items()))
    save('posted-hunks.json',results)
    print('posted',len(rows),'open',sum(r['state']=='OPEN' for r in rows),'touched',len(results),'matched',sum(any(f['matched_hunks'] for f in v.values()) for v in results.values()))

if __name__=='__main__':main()
