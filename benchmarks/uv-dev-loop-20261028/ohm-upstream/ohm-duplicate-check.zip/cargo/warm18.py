#!/usr/bin/env python3
"""Prepare isolated, offline uv fixtures on the installed Ohm release."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent
W=D.parents[1]
B=Path((W/'bench-home.path').read_text().strip())
T=D.parent/'toolchain18/bin'
P=json.loads((D/'depfile-plan.json').read_text())
assert sorted(os.sched_getaffinity(0))==P['measurement_cpus']
for label,c in P['cohorts'].items():
    out=D/f'warm-{label}';out.mkdir()
    src=B/c['source'];src.mkdir(parents=True)
    reg=B/c['cargo_home'];reg.mkdir(mode=0o700)
    target=B/('target-'+c['target']);assert not target.exists()
    subprocess.run(['cp','-a','--reflink=auto',str(B/'cargo/registry'),str(reg/'registry')],check=True)
    with subprocess.Popen(['git','-C',str(W/'uv'),'archive',P['uv']],stdout=subprocess.PIPE) as archive:
        subprocess.run(['tar','-x','-C',str(src)],stdin=archive.stdout,check=True)
        if archive.wait(): raise RuntimeError('uv archive failed')
    slot=W/'bin'/('measured-'+c['target'])/'cargo';slot.parent.mkdir()
    os.link(T/'cargo',slot)
    env=dict(os.environ,PATH=str(T)+':'+os.environ['PATH'],CARGO_HOME=str(reg),CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',RUSTC=str(T/'rustc'),RUSTDOC=str(T/'rustdoc'))
    for stage in ['warm','fresh']:
        with (out/f'{stage}.log').open('x') as f:
            subprocess.run([slot,'build','--locked','--offline','-j4'],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    fresh=(out/'fresh.log').read_text()
    if 'Compiling ' in fresh or 'Checking ' in fresh or 'Finished ' not in fresh:raise ValueError('release-18 warmup did not settle')
    public=sorted(p for p in (target/'debug').glob('*.d') if p.is_file())
    if not (target/'debug/uv.d').is_file():raise RuntimeError('missing public uv.d output')
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    (out/'ready.json').write_text(json.dumps(dict(source=str(src),target=str(target),cargo_home=str(reg),uv_lock_sha256=sha(src/'Cargo.lock'),actual_public_depfiles={p.name:sha(p) for p in public}),indent=2)+'\n')
    print(label,'official warm and fresh; public output depfiles',len(public),flush=True)
