#!/usr/bin/env python3
"""Verify actual default Cargo depfile handling and run the two registered fresh-build cohorts."""
import csv,hashlib,json,math,os,re,statistics,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent
W=D.parents[1]
B=Path((W/'bench-home.path').read_text().strip())
T=D.parent/'toolchain18/bin'
P=json.loads((D/'depfile-plan.json').read_text())
DRIVERS=json.loads((D/'drivers.json').read_text())

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')

def summarize(out,cfg):
    rows=list(csv.DictReader((out/'pairs.csv').open()))
    if len(rows)!=cfg['pairs']*2:raise ValueError('wrong observed sample count')
    arms={'base':[],'candidate':[]};gains=[];periods=[]
    for i,order in enumerate(cfg['order']):
        pair=rows[2*i:2*i+2]
        if [r['arm'] for r in pair]!=order or [int(r['order']) for r in pair]!=[0,1] or any(r['endpoint']!='build' or int(r['pair'])!=i for r in pair):raise ValueError('order mismatch')
        for r in pair:
            arm=r['arm'];arms[arm].append(int(r['value']))
            log=(out/f'build-{i}-{arm}.log').read_text()
            if not re.search(r'^\s*Finished ',log,re.M) or re.search(r'^\s*(Checking|Compiling|Blocking|Running|Downloading|Updating) ',log,re.M):raise ValueError('workload changed')
        gains.append(1-arms['candidate'][-1]/arms['base'][-1])
        diff=int(pair[0]['value'])-int(pair[1]['value']);periods.append((diff>0)-(diff<0))
    n=len(gains);gains.sort();wins=sum(v>0 for v in gains);losses=sum(v<0 for v in gains);noties=wins+losses
    sign=min(1,2*sum(math.comb(noties,j) for j in range(min(wins,losses)+1))/2**noties)
    rank=max(k for k in range(1,n//2+1) if 2*sum(math.comb(n,j) for j in range(k))/2**n<=.05)
    confidence=1-2*sum(math.comb(n,j) for j in range(rank))/2**n
    positive=periods.count(1);negative=periods.count(-1);ties=periods.count(0); extreme=0
    for p in range(positive+1):
        for q in range(negative+1):
            z=n//2-p-q
            w=p+negative-q
            if 0<=z<=ties and abs(2*w-positive-negative)>=abs(wins-losses):
                extreme+=math.comb(positive,p)*math.comb(negative,q)*math.comb(ties,z)
    randomized=extreme/math.comb(n,n//2)
    med=statistics.median(gains)
    return dict(n=n,median_base=statistics.median(arms['base']),median_candidate=statistics.median(arms['candidate']),median_reduction=med,rank_interval=[gains[rank-1],gains[n-rank]],coverage=confidence,wins=wins,ties=n-noties,sign_p=sign,balanced_order_p=randomized,passed=med>0 and gains[rank-1]>0 and sign<.05 and randomized<.05,raw_sha256=digest(out/'pairs.csv'))

def fresh(cmd,src,env,log):
    with log.open('x') as f:subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    body=log.read_text()
    if not re.search(r'^\s*Finished ',body,re.M) or re.search(r'^\s*(Checking|Compiling|Blocking|Running|Downloading|Updating) ',body,re.M):raise ValueError('Cargo was not fresh: '+str(log))

def main():
    if sorted(os.sched_getaffinity(0))!=P['measurement_cpus']:raise ValueError('wrong CPUs')
    if digest(T/'rustc')!=P['released_rustc_sha256']:raise ValueError('wrong compiler')
    for k in ['base','candidate']:
        if digest(D/'bin'/k)!=DRIVERS['arms'][k]['sha256']:raise ValueError('unverified driver '+k)
    summary={}
    for name,c in P['cohorts'].items():
        warm=json.loads((D/f'warm-{name}/ready.json').read_text());src=Path(warm['source']);target=Path(warm['target']);home=Path(warm['cargo_home'])
        slot=W/'bin'/('measured-'+c['target'])/'cargo';public=target/'debug/uv.d';out=D/f'admission-{name}';out.mkdir()
        env=dict(os.environ,PATH=str(T)+':'+os.environ['PATH'],RUSTC=str(T/'rustc'),RUSTDOC=str(T/'rustdoc'),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',CARGO_HOME=str(home),CARGO_TARGET_DIR=str(target))
        public_set=lambda:{p.name:digest(p) for p in sorted((target/'debug').glob('*.d'))}
        expected=public_set()
        if expected!=warm['actual_public_depfiles']:raise ValueError('warm outputs no longer match')
        receipt={}
        for arm in ['base','candidate']:
            temp=slot.with_suffix('.next');os.link(D/'bin'/arm,temp);os.replace(temp,slot);temp.unlink(missing_ok=True)
            tr=out/f'{arm}-public-open.trace'
            cmd=['strace','-f','-qq','-s','4096','-e','trace=open,openat,openat2','-P',str(public),'-o',str(tr),str(slot),'build']
            fresh(cmd,src,env,out/f'{arm}-ordinary.log')
            successful=[line for line in tr.read_text().splitlines() if str(public) in line and 'O_RDONLY' in line and re.search(r'= \d+$',line)]
            if not successful:raise ValueError('default build did not read public uv.d')
            parked=public.with_suffix('.saved-release18')
            if os.path.lexists(parked):raise ValueError('occupied depfile parking slot')
            public.rename(parked)
            try:
                fresh([str(slot),'build'],src,env,out/f'{arm}-regenerate.log')
                if digest(public)!=digest(parked) or public_set()!=expected:raise ValueError('public output depfiles differ')
                receipt[arm]=dict(sha256=digest(D/'bin'/arm),uv_d_sha256=digest(public),ordinary_successful_uv_d_reads=successful,regenerated_bytes=public.stat().st_size,all_public_depfiles=expected)
            finally:
                if public.exists():public.unlink()
                parked.rename(public)
        if digest(src/'Cargo.lock')!=warm['uv_lock_sha256']:raise ValueError('uv Cargo.lock changed')
        save(out/'admitted.json',receipt)
        result=D/f'count-{name}';env.update(OHM_BENCH_WORK=str(W),OHM_BENCH_ROOT=str(B),OHM_TOOLCHAIN_BIN=str(T))
        cmd=[sys.executable,'-B',str(W/'measure.py'),'--base',str(D/'bin/base'),'--candidate',str(D/'bin/candidate'),'--result',str(result),'--target',c['target'],'--source',str(src),'--cargo-home',str(home),'--mode',c['mode'],'--endpoints','build','--pairs',str(c['pairs']),'--seed',str(c['seed']),'--ordinary','--settle-counter']
        with (D/f'count-{name}.log').open('x') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
        summary[name]=summarize(result,c)
        if public_set()!=expected or digest(src/'Cargo.lock')!=warm['uv_lock_sha256']:raise ValueError('counted run changed public depfiles or lock')
        save(D/f'stats-{name}.json',summary[name]);print(name,summary[name],flush=True)
    save(D/'depfile-results.json',dict(replicated=all(x['passed'] for x in summary.values()),cohorts=summary))

if __name__=='__main__':main()
