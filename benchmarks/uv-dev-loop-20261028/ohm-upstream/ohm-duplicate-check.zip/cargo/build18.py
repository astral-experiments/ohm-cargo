#!/usr/bin/env python3
"""Build the two adjacent release-18 source snapshots using one stable path and matched release flags."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
D=Path(__file__).resolve().parent
W=D.parents[1]
B=Path((W/'bench-home.path').read_text().strip())
T=D.parent/'toolchain18/bin'
P=json.loads((D/'depfile-plan.json').read_text())
L=B/'cargo-18-depfile-driver'

def run(args, **kwargs):
    return subprocess.run([str(x) for x in args],check=True,**kwargs)

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

assert sorted(os.sched_getaffinity(0))==P['build_cpus']
assert digest(T/'cargo')==P['released_cargo_sha256'] and digest(T/'rustc')==P['released_rustc_sha256']
assert digest(D/'base-7caf399.tar.gz')==P['source_archive_sha256']
L.mkdir(mode=0o700);src=L/'src';src.mkdir()
home=L/'cargo-home'; home.mkdir(mode=0o700)
run(['cp','-a','--reflink=auto',W/'release-like/cargo-home/registry',home/'registry'])
run(['tar','-xzf',D/'base-7caf399.tar.gz','--strip-components=1','-C',src])
(src/'git-commit-info').write_text(P['cargo_pin']+'\n'+P['cargo_pin'][:9]+'\n2026-10-28\n')
binout=D/'bin';binout.mkdir()
logs=D/'build-logs';logs.mkdir()
env=dict(os.environ,PATH=str(T)+':'+os.environ['PATH'],CARGO_HOME=str(home),RUSTC=str(T/'rustc'),RUSTDOC=str(T/'rustdoc'),CARGO_TARGET_DIR=str(L/'target'),CARGO_NET_OFFLINE='true',CARGO_PROFILE_RELEASE_LTO='thin',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_INCREMENTAL='false',CARGO_PROFILE_RELEASE_DEBUG='false',CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS='false',CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='false',LIBZ_SYS_STATIC='1',CARGO_TERM_COLOR='never',CFG_RELEASE='1.99.0-dev',CFG_RELEASE_CHANNEL='dev',CFG_VER_DESCRIPTION='ohm-1.99.0-18')
argv=[T/'cargo','-Zohm-defaults=no','build','--target','x86_64-unknown-linux-gnu','--release','--locked','--offline','--bin','cargo','--features','ohm-defaults,all-static','-j8']
record={'source':str(src),'target':str(L/'target'),'registry':str(home),'cargo_lock_sha256':digest(src/'Cargo.lock'),'command':[str(x) for x in argv],'controlled_env':{k:v for k,v in env.items() if k.startswith(('CARGO_PROFILE_','CFG_')) or k in ('LIBZ_SYS_STATIC','RUSTC','RUSTDOC','CARGO_HOME','CARGO_TARGET_DIR')},'arms':{}}
for arm,extra in [('base',[264,267,268]),('candidate',[269])]:
    for n in extra:
        patch=D/f'patches/{n}.patch';assert digest(patch)==P['patch_sha256'][str(n)]
        run(['git','apply','--check',patch],cwd=src);run(['git','apply',patch],cwd=src)
    print(arm,'build started',flush=True);start=time.time()
    with (logs/f'{arm}.log').open('x') as f:run(argv,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
    dst=binout/arm;shutil.copy2(L/'target/x86_64-unknown-linux-gnu/release/cargo',dst);dst.chmod(0o555)
    version=subprocess.check_output([dst,'-Vv'],text=True); assert P['cargo_pin'][:9] in version and P['release'] in version
    record['arms'][arm]=dict(patches=P['variants'][arm],sha256=digest(dst),version=version,elapsed_s=time.time()-start,output_depinfo_sha256=digest(src/'src/compiler/output_depinfo.rs'),ldd=subprocess.check_output(['ldd',dst],text=True));(D/'drivers.json').write_text(json.dumps(record,indent=2)+'\n')
    print(arm,'complete',dst,flush=True)
