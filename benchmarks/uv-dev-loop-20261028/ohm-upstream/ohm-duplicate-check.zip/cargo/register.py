#!/usr/bin/env python3
"""Freeze the one release-18 question before collecting its observations."""
from pathlib import Path
import datetime,hashlib,json,random

D=Path(__file__).resolve().parent
W=D.parents[1]
B=Path((W/'bench-home.path').read_text().strip())
T=D.parent/'toolchain18'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
cfg={'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':'ohm-1.99.0-18','cargo_pin':'7caf39914da1e28a67744ecbc963a5f26361474d','rustc_pin':'a4fa11bcd38280639cb94daacc125472657db6c3','distribution_archive_sha256':'629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8','released_cargo_sha256':sha(T/'bin/cargo'),'released_rustc_sha256':sha(T/'bin/rustc'),'source_archive_sha256':sha(D/'base-7caf399.tar.gz'),'uv':'c22e6b71933443e9cd299d4b6ac8de035ed4825b','variants':{'base':[264,267,268],'candidate':[264,267,268,269]},'patch_sha256':{str(n):sha(D/f'patches/{n}.patch') for n in [264,267,268,269,270]},'command':['cargo','build'],'environment':'ordinary full workspace invocation; CARGO_NET_OFFLINE=true; no package/job flags during measurement, pinned four CPU affinity','scope':'parent Cargo PID and its threads; fresh uv graph, no rustc, linker, tests, downloads or ignored samples','driver':'matched -18 rustc; ThinLTO, one codegen unit, opt=3, all-static, ohm-defaults, fixed version metadata, no PGO','build_cpus':list(range(16,24)),'measurement_cpus':list(range(24,28)),'entry_admission':'actual shipped-default .d reader, forced public uv.d regeneration byte-equal in both arms and restored, plus settled fresh instrumented runs','gate':'positive median, two-sided sign p<.05, positive lower symmetric median rank interval, and two-sided order-balanced randomization p<.05 in each independent cohort','cohorts':{}}
for name,mode,n,seed,source in [('initial','dynamorio',12,11206929,'u18'),('replica','instructions',8,285190561,'release18-depfile-independent-root/source')]:
 o=[['base','candidate'],['candidate','base']]*(n//2);random.Random(seed).shuffle(o)
 cfg['cohorts'][name]=dict(mode=mode,pairs=n,seed=seed,order=o,source=source,target='release18-render-'+name,cargo_home='cargo-18-render-'+name)
with (D/'depfile-plan.json').open('x') as f:json.dump(cfg,f,indent=2);f.write('\n')
