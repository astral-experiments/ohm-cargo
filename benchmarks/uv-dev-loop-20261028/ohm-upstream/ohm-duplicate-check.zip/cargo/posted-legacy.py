#!/usr/bin/env python3
"""Complete the PR file inventory across both old and current Cargo source layouts."""
import concurrent.futures as cf
import datetime, json, re, sys
from pathlib import Path
here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
from snapshot import api, gh
from posted import EXACT, WATCH
legacy = dict(zip(['src/cargo/core/compiler/build_runner/mod.rs','src/cargo/core/compiler/fingerprint/mod.rs','src/cargo/core/compiler/mod.rs','src/cargo/util/toml/mod.rs','src/cargo/core/resolver/features.rs','src/cargo/core/compiler/output_depinfo.rs','src/cargo/util/semver_ext.rs'],['src/compiler/build_runner/mod.rs','src/compiler/fingerprint/mod.rs','src/compiler/mod.rs','src/workspace/parser/mod.rs','src/resolver/features.rs','src/compiler/output_depinfo.rs','src/util/semver_ext.rs']))
assert set(legacy.values()) == EXACT
q='query($cursor:String){repository(owner:"astral-sh",name:"ohm-cargo"){pullRequests(first:80,after:$cursor,orderBy:{field:CREATED_AT,direction:DESC}){totalCount pageInfo{hasNextPage endCursor} nodes{number state headRefOid files(first:100){totalCount pageInfo{hasNextPage} nodes{path}}}}}}'
rows={}; cursor=None
while True:
    args=['api','graphql','-f','query='+q]
    if cursor: args+=['-f','cursor='+cursor]
    page=json.loads(gh(*args))['data']['repository']['pullRequests']
    for r in page['nodes']:
        fs=r.pop('files')
        names=[n['path'] for n in fs['nodes']]
        if fs['pageInfo']['hasNextPage'] or len(names) != fs['totalCount']:
            pages=json.loads(gh('api','--paginate','--slurp',f"repos/astral-sh/ohm-cargo/pulls/{r['number']}/files?per_page=100"))
            names=[f['filename'] for file_page in pages for f in file_page]
        assert len(names)==fs['totalCount'], (r['number'],len(names),fs['totalCount'])
        r['paths']=sorted(names); rows[r['number']]=r
    if not page['pageInfo']['hasNextPage']:break
    cursor=page['pageInfo']['endCursor']
assert len(rows)==page['totalCount']
(here/'all-pr-paths.json').write_text(json.dumps(rows,indent=2)+'\n')
old={n:sorted(set(r['paths'])&set(legacy)) for n,r in rows.items() if set(r['paths'])&set(legacy)}

def inspect(n_paths):
    n,paths=n_paths; matches={}
    endpoint=f'repos/astral-sh/ohm-cargo/pulls/{n}/files?per_page=100'
    allfiles = [f for page in json.loads(gh('api','--paginate','--slurp',endpoint)) for f in page] if len(rows[n]['paths'])>100 else api(endpoint)
    for f in allfiles:
        path=f['filename']
        if path not in paths: continue
        assert f.get('patch'), (n,path)
        terms=WATCH[legacy[path]]
        if path.endswith('/resolver/features.rs'):terms += r'|\bfn deps\b|self\.deps\(|deps_cache|PackageFeaturesKey'
        matched=[]
        for h in re.split('(?m)(?=^@@)',f['patch']):
            if not h:continue
            ls=h.splitlines()
            hits=[s for s in ls[1:] if s[:1] in '+-' and re.search(terms,s)]
            if hits or re.search(terms,ls[0]):matched.append({'header':ls[0],'matched':hits})
        matches[path]={'head_blob':f['sha'],'hunks':matched}
    assert set(matches)==set(paths)
    return n,matches
with cf.ThreadPoolExecutor(3) as e:records=dict(e.map(inspect,old.items()))
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_prs':len(rows),'old_to_current':legacy,'old_layout_prs':records}
(here/'posted-legacy-hunks.json').write_text(json.dumps(out,indent=2)+'\n')
print('all',len(rows),'old',len(old),'union',len({n for n,r in rows.items() if set(r['paths'])&(set(legacy)|EXACT)}),'old feature and semver',[(n,fs) for n,fs in old.items() if any('/resolver/features.rs' in f or f.endswith('/semver_ext.rs') for f in fs)],flush=True)
