"""Check the original work in each affected Cargo hot path, and detect the five published alternatives."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import gzip
import json
import re

OUT=Path(__file__).resolve().parent
index=json.loads((OUT/'source-index.json').read_text()); cache=OUT/'blobs'
snap=json.loads((OUT.parent/'cargo/snapshot.json').read_text()); drafts=snap['drafts']
prs=['264','267','268','269','270']; ranks={drafts[n]['headRefOid']:i for i,n in enumerate(prs)}
files={}
def digest(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=1)+'\n')
def lines(text,pred):return [dict(line=i,text=s.strip()) for i,s in enumerate(text.splitlines(),1) if pred(s)]
def decide(legacy,optimized):return 'original-work-present' if legacy and not optimized else 'optimization-present' if optimized and not legacy else 'inspect'
def function(text,pattern):
 line=re.search(pattern,text,re.M);assert line is not None,(pattern,text[:250]); indent=line.group(1)
 end=re.search('^'+indent+r'\}\s*$',text[line.start():],re.M);assert end
 return text[line.start():line.start()+end.end()].rstrip()+'\n'
for oid,item in index['blobs'].items():
 label=item['label']; data=gzip.decompress((cache/(oid+'.rs.gz')).read_bytes());text=data.decode('utf-8'); norm=' '.join(text.split()); src=[]; signs={}; status='inspect'
 if label=='runner':
  fn=function(text,r'^( *)pub fn unit_deps\(');decl=fn.splitlines()[0].strip();status=decide('-> &[UnitDep]' in decl,"-> &'a [UnitDep]" in decl);signs={'returns':decl,'unit_graph_borrow':'&self.bcx.unit_graph[unit]' in fn};src=lines(text,lambda s:'pub fn unit_deps(' in s)
 elif label=='fingerprint':
  clones=norm.count('Vec::from(build_runner.unit_deps(unit))'); borrows=norm.count('DepFingerprint::new(build_runner, unit, dep)');byref=norm.count('DepFingerprint::new(build_runner, unit, &dep)');status=decide(clones>=2 and byref>=2,clones==0 and borrows>=2);signs={'unit_dependency_vec_copies':clones,'fingerprints_from_iterated_reference':borrows,'references_to_copied_dependency':byref};src=lines(text,lambda s:'Vec::from(build_runner.unit_deps(unit))' in s or 'DepFingerprint::new(build_runner, unit,' in s)
 elif label=='compiler':
  source=text.splitlines(); marker='Be sure to compile all dependencies of this target as well.'; pos,=[i for i,line in enumerate(source) if marker in line]; region=' '.join(x.strip() for x in source[pos+1:pos+3]); clones='Vec::from(build_runner.unit_deps(unit))' in region; borrow='for dep in build_runner.unit_deps(unit)' in region
  status=decide(clones and 'for dep in deps {' in region,borrow);signs={'copies_unit_dependencies_before_compile_loop':clones,'iterates_borrowed_dependencies_in_compile_loop':borrow};src=[{'line':pos+i+1,'text':source[pos+i].strip()} for i in (1,2)]
 elif label=='warning':
  call='unused_dep_keys(name_in_toml, &table_in_toml,'; i=norm.index(call); loop=norm.rfind('for (name_in_toml, v) in dependencies.iter() {',0,i);assert loop>=0
  stop=norm.index(';',i)+1;region=norm[loop:stop];legacy=call+' v.unused_keys(), warnings)' in region and region.count('unused_keys()')==1 and ('kind_name.to_string()' in region or 'kind_name.to_owned()' in region)
  guard='let unused_keys = v.unused_keys(); if unused_keys.is_empty() { continue; }'; optimized=guard in region and region.index(guard)<region.index('let kind_name') and call+' unused_keys, warnings)' in region
  status=decide(legacy,optimized);signs={'constructs_table_before_evaluating_unused_keys':legacy,'checks_empty_before_table':optimized,'entire_loop_body_sha256':digest(region.encode())};src=lines(text,lambda s:('unused_dep_keys(name_in_toml, &table_in_toml,' in s or 'if unused_keys.is_empty()' in s or 'let unused_keys = v.unused_keys();' in s))
 elif label=='features':
  fn=function(text,r'^( *)fn deps\('); compact=' '.join(fn.split()); callers=norm.count('self.deps(pkg_id, fk)?'); edges='.deps(pkg_id)' in compact; cached='self.deps_cache.get(&(pkg_id, fk))' in compact and 'self.deps_cache.insert((pkg_id, fk)' in compact
  owned_return='CargoResult<Vec<(PackageId,' in compact; legacy=edges and '.collect()' in compact and 'self .resolve' in compact.replace('self.resolve','self .resolve') and not 'cache' in compact and owned_return
  optimized=edges and cached and 'Ok(Rc::clone(deps))' in compact;status=decide(legacy and callers==3,optimized and callers==3);signs={'fresh_owned_vec_return':owned_return,'requeries_resolve_edges':edges,'per_context_lookup_and_insert':cached,'call_sites':callers,'deps_function_sha256':digest(fn.encode())};src=lines(text,lambda s:'fn deps(' in s or '.deps(pkg_id)' in s or 'self.deps(pkg_id, fk)?' in s or 'self.deps_cache' in s)
 elif label=='depfile':
  fn=function(text,r'^( *)fn render_filename'); compact=' '.join(fn.split());allocating='CargoResult<String>' in compact and 'f.replace(" ",' in compact;borrow='Cow::Borrowed' in compact and 'contains(&b\' \')' in compact
  formatted=bool(re.search(r'write!\((?:contents|outfile|output|file), " \{\}", dep\)',norm));direct="contents.extend_from_slice(dep.as_bytes())" in norm and "contents.extend_from_slice(target_fn.as_bytes())" in norm and 'Vec::with_capacity(' in norm
  status=decide(allocating and formatted and not direct,borrow and direct);signs={'always_allocates_rendered_string':allocating,'borrows_unescaped_paths':borrow,'formats_one_dependency_at_a_time_in_output':formatted,'single_output_preallocates_and_copies_bytes':direct,'render_function_sha256':digest(fn.encode()),'path_only_sorted_collection':'fingerprint::dep_info_paths(' in norm and 'deps.sort()' in norm and 'deps.dedup()' in norm};src=lines(text,lambda s:'fn render_filename' in s or 'f.replace(' in s or 'Cow::Borrowed(' in s or 'write!(contents, " {}", dep)' in s or 'write!(outfile, " {}", dep)' in s or 'contents.extend_from_slice(dep.as_bytes())' in s)
 elif label=='semver':
  legacy={k:norm.count(k+'(version, req.clone())') for k in ('Locked','Precise')}; moved={k:norm.count(k+'(version, std::mem::take(req))') for k in ('Locked','Precise')};status=decide(all(legacy.values()),all(moved.values()));signs={'clone_in_each_transition':legacy,'moves_in_each_transition':moved};src=lines(text,lambda s:'req.clone())' in s or 'std::mem::take(req)' in s)
 files[oid]={'label':label,'status':status,'observed':signs,'locations':src,'representative_source':f'https://github.com/astral-sh/ohm-cargo/blob/{item["ref"]}/{item["path"]}'}
save(OUT/'site-findings.json',files)
assign={'264':['runner','compiler','fingerprint'],'267':['warning'],'268':['features'],'269':['depfile'],'270':['semver']}
by_ref={}; unexpected=[];unknown=[]
for ref,entry in index['refs'].items():
 if not entry.get('layout'):continue
 states={}
 for n,sites in assign.items():
  observed={files[entry['blobs'][label]]['status'] for label in sites}
  state=next(iter(observed)) if len(observed)==1 else 'mixed'
  if state in ('inspect','mixed'):unknown.append({'sha':ref,'pr':n,'blobs':{l:entry['blobs'][l] for l in sites},'states':sorted(observed)})
  if state=='optimization-present' and (ref not in ranks or ranks[ref]<prs.index(n)):unexpected.append({'sha':ref,'pr':n,'refs':entry})
  states[n]=state
 by_ref[ref]=states
save(OUT/'commit-states.json',by_ref)
summary={'as_of':datetime.now(timezone.utc).isoformat(),'recognized_commits':len(by_ref),'named_branches':sum(len(e.get('branches',[])) for e in index['refs'].values()),'open_prs':sum(len(e.get('open_prs',[])) for e in index['refs'].values()),'released_tags':sum(len(e.get('releases',[])) for e in index['refs'].values()),'absent_sources':{k:v for k,v in index['refs'].items() if not v.get('layout')},'unexpected_optimized_sites':unexpected,'need_manual_inspection':unknown,'variants':{}}
for n in prs:
 present=[ref for ref,s in by_ref.items() if s[n]=='optimization-present']; rel=[r for ref,s in by_ref.items() for r in index['refs'][ref].get('releases',[]) if s[n]=='optimization-present'];summary['variants'][n]={'head':drafts[n]['headRefOid'],'title':drafts[n]['title'],'released_tags_containing_equivalent':rel,'branches_containing_change':[b for ref in present for b in index['refs'][ref].get('branches',[])],'open_prs_containing_change':[i for ref in present for i in index['refs'][ref].get('open_prs',[])],'current_release':by_ref[snap['refs']['ohm_18']['sha']][n],'ohm_1_99_tip':by_ref[snap['refs']['ohm_199']['sha']][n],'ohm_default_tip':by_ref[snap['refs']['ohm_default']['sha']][n]}
save(OUT/'summary.json',summary)
print('sites',Counter(v['status'] for v in files.values()),'manual',len(unknown),'unexpected',[(v['pr'],v['sha']) for v in unexpected],'absent',len(summary['absent_sources']));print('unique unknown',[(item['label'],oid,item['observed']) for oid,item in files.items() if item['status']=='inspect']); print('variants',{pr:len(item['branches_containing_change']) for pr,item in summary['variants'].items()})
