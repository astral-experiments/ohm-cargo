"""Fetch only unique Ohm Cargo source blobs needed to audit the five proposed optimizations."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
from threading import Lock

OUT=Path(__file__).resolve().parent
MON=OUT.parent
WORK=MON.parent
GH='/home/dev-user/.local/bin/gh-auto'
ROUTE='/home/dev-user/code/oss/relic'
REPO='astral-sh/ohm-cargo'
GIT=WORK/'ohm-cargo'
P={
 'new': {'runner':'src/compiler/build_runner/mod.rs','fingerprint':'src/compiler/fingerprint/mod.rs','compiler':'src/compiler/mod.rs','warning':'src/workspace/parser/mod.rs','features':'src/resolver/features.rs','depfile':'src/compiler/output_depinfo.rs','semver':'src/util/semver_ext.rs'},
 'old': {'runner':'src/cargo/core/compiler/build_runner/mod.rs','fingerprint':'src/cargo/core/compiler/fingerprint/mod.rs','compiler':'src/cargo/core/compiler/mod.rs','warning':'src/cargo/util/toml/mod.rs','features':'src/cargo/core/resolver/features.rs','depfile':'src/cargo/core/compiler/output_depinfo.rs','semver':'src/cargo/util/semver_ext.rs'}}
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1')
def save(p,x):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=1)+'\n');t.replace(p)
def gh(*args):return subprocess.check_output([GH,*args],cwd=ROUTE)
def git_sha(text):return hashlib.sha1(b'blob '+str(len(text)).encode()+b'\0'+text).hexdigest()
def graph(group):
 query='{repository(owner:"astral-sh",name:"ohm-cargo"){'+ ' '.join(f'a{i}:object(expression:{json.dumps(ref+":"+path)}){{... on Blob{{oid byteSize}}}}' for i,(ref,path) in enumerate(group)) + '}}'
 obj=json.loads(gh('api','graphql','-f','query='+query))['data']['repository'];return {x:obj[f'a{i}'] for i,x in enumerate(group)}
def query(items):
 items=list(dict.fromkeys(items)); groups=[items[i:i+75] for i in range(0,len(items),75)]
 with ThreadPoolExecutor(max_workers=3) as pool:return {k:v for group in pool.map(graph,groups) for k,v in group.items()}
assert gh('api','user','--jq','.login').decode().strip()=='charliermarsh'
start=datetime.now(timezone.utc).isoformat()
if os.environ.get('OHM_AUDIT_RESUME_INDEX') == '1':
 index=json.loads((OUT/'source-index.json').read_text()); refs=index['refs']; blobs=index['blobs']
else:
 print('inventory',flush=True)
 branches=[json.loads(line) for line in gh('api','--paginate',f'repos/{REPO}/branches?per_page=100','--jq','.[]|{name,sha:.commit.sha}|tojson').decode().splitlines()]
 prs=json.loads((MON/'cargo/open-pr-index.json').read_text())['all']
 releases=json.loads((MON/'rust/release-history.json').read_text())['releases']
 latest=gh('api','repos/astral-sh/ohm/releases/latest','--jq','.tag_name').decode().strip()
 assert latest==releases[0]['tag_name'],(latest,releases[0]['tag_name'])
 refs={}
 for collection,key,label,field in [(branches,'sha','branches','name'),(prs,'headRefOid','open_prs','number'),(releases,'cargo','releases','tag_name')]:
  for x in collection:refs.setdefault(x[key],{}).setdefault(label,[]).append(x[field])
 print('layouts for',len(refs),'revisions',flush=True)
 probe=query((ref,P[g]['semver']) for ref in refs for g in P)
 ls={}
 for ref in refs:
  keys=[g for g in P if probe.get((ref,P[g]['semver']))];assert len(keys)<=1,(ref,keys)
  refs[ref]['layout']=keys[0] if keys else None
 print('scanning seven sites for verified layouts',flush=True)
 located=query((ref,path) for ref,item in refs.items() if item['layout'] for label,path in P[item['layout']].items() if label!='semver'); located.update(probe)
 blobs={}
 for ref,entry in refs.items():
  if g:=entry['layout']:
   entry['blobs']={}
   for label,path in P[g].items():
    value=located[ref,path];assert value,(ref,label,path)
    oid=value['oid'];entry['blobs'][label]=oid
    b=blobs.setdefault(oid,{'label':label,'path':path,'ref':ref,'bytes':value['byteSize']});assert b['bytes']==value['byteSize']
  else:
   root=json.loads(gh('api',f'repos/{REPO}/git/trees/{ref}','--jq','[.tree[].path]'));entry['root_files']=root
 save(OUT/'source-index.json',dict(as_of=start,repo=REPO,latest_release=latest,path_layouts=P,refs=refs,blobs=blobs))
print('unique blobs',len(blobs),'raw bytes',sum(b['bytes'] for b in blobs.values()),flush=True)
cache=OUT/'blobs';cache.mkdir(exist_ok=True)
local={}
for directory in [GIT,WORK/'pgo-confirmation-v2/records/base/cargo-src',*(WORK/'pgo-intermediates/records').glob('*/cargo-src'),Path((MON/'cargo/scratch-application.path').read_text().strip())]:
 for sites in P.values():
  for path in sites.values():
   file=directory/path
   if file.is_file():
    content=file.read_bytes();local[git_sha(content)]=content
lock=Lock();counts={}
def fetch(oid):
 item=blobs[oid]; dst=cache/(oid+'.rs.gz')
 if dst.exists():content=gzip.decompress(dst.read_bytes());source='private-cache'
 elif oid in local:content=local[oid];source='existing-verified-export'
 else:
  proc=subprocess.run(['git','-C',str(GIT),'cat-file','blob',oid],env=ENV,capture_output=True)
  if proc.returncode==0:content=proc.stdout;source='local-git-object'
  else:
   content=gh('api','-H','Accept: application/vnd.github.raw+json',f'repos/{REPO}/git/blobs/{oid}');source='unique-remote-blob'
 assert git_sha(content)==oid and len(content)==item['bytes'],(oid,len(content),item,source)
 if not dst.exists():dst.write_bytes(gzip.compress(content,compresslevel=4,mtime=0))
 with lock:counts[source]=counts.get(source,0)+1
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(fetch,blobs))
save(OUT/'fetch-summary.json',dict(as_of=start,end=datetime.now(timezone.utc).isoformat(),distinct_commits=len(refs),distinct_blobs=len(blobs),source_counts=counts,bytes=sum(b['bytes'] for b in blobs.values())))
print('verified',counts,flush=True)
