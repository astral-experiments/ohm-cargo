#!/usr/bin/env bash
set -euo pipefail
lab=$(cd "$(dirname "$0")" && pwd -P)
work=$(dirname "$lab")
mkdir "$lab/driver-src" "$lab/driver-bin"
tar -xzf "$lab/266.tgz" --strip-components=1 -C "$lab/driver-src"
git -C "$work/ohm-cargo" show -s --format='%H%n%h%n%cs' --abbrev=9 a0c7d08c8 > "$lab/driver-src/git-commit-info"
export CARGO_HOME="$work/cargohome" CARGO_TARGET_DIR="$lab/driver-target" CARGO_NET_OFFLINE=true
export CFG_RELEASE_CHANNEL=dev
if [[ -n ${OHM_CACHED_TARGET:-} ]]; then cp -a --reflink=auto "$OHM_CACHED_TARGET" "$CARGO_TARGET_DIR"; fi
cd "$lab/driver-src"
build() {
    cargo +stable build -j6 --release --locked --offline --bin cargo --features ohm-defaults
    cp "$CARGO_TARGET_DIR/release/cargo" "$lab/driver-bin/$1"
    "$lab/driver-bin/$1" -Vv
}
build parent
git apply --check "$lab/stack.patch"
git apply "$lab/stack.patch"
build candidate
sha256sum "$lab/driver-bin/"{parent,candidate}
