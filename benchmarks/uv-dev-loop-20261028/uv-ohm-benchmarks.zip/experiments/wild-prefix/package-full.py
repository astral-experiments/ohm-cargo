from pathlib import Path
import sys,zipfile
base=Path(__file__).resolve().parent;root=Path(sys.argv[1]).resolve();out=root/'evidence-full.zip'
paths={'screen/*.log','holdout/*.log','pilot/*.log','links/*.log','fallback/control-*.log','fallback/prepare.sh','actual/*-*-*/*.log','actual/*-*-*/*.outpath'}
with zipfile.ZipFile(root/'evidence.zip','r') as old,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as new:
    present=set(old.namelist())
    for name in sorted(present):
        new.writestr(name,(root/name).read_bytes() if name in ('README.md','RESULTS.md') else old.read(name))
    for name in sorted({p.relative_to(root).as_posix() for pat in paths for p in root.glob(pat) if p.is_file()}-present):
        new.write(root/name,name)
print(out,out.stat().st_size)
