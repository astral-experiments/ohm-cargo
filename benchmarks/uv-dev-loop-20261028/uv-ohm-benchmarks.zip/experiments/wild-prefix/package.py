import sys,zipfile
from pathlib import Path
d=Path(sys.argv[1]).resolve();out=d/'evidence.zip'
fixed=['README.md','RESULTS.md','candidate.patch','regression-test.patch','plan.json','screen-plan.json','gate.json','binary-sha256.txt','patch-sha256.txt','replay-summary.json','replay.py','summarize.py','compare-artifacts.py','byte-differences.py','digests-tsv.py','actual.py','fixtures.py','attribution.py','attribution.json','qa.sh','profile.sh','capture.py','canonical.py','pilot.py','confirm-links.py','summarize-links.py','summarize-pilot.py','post-profile.sh','release-with-test.sh']
patterns=['actual/*.json','actual/*.csv','actual/*.tsv','actual/*.txt','actual/*-*-*.log','screen/*.csv','screen/*.json','holdout/*.csv','holdout/*.json','fallback/*.py','fallback/*.csv','fallback/*.json','fallback/override.ld','fixtures/checks.csv','fixtures/*.stderr','fixtures/*.stdout','fixtures/in.s','fixtures/override.ld','logs/*.log','logs/*.sha256','logs/*.txt','pilot/*.csv','pilot/*.json','links/*.csv','links/*.json','captures/*.json','captures/source.*.rs']
paths={d/n for n in fixed if (d/n).is_file()}
for pat in patterns:paths.update(f for f in d.glob(pat) if f.is_file() and not f.name.endswith('-interim.json'))
if (d/'candidate.callgrind').is_file(): paths.add(d/'candidate.callgrind')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    for path in sorted(paths):z.write(path,path.relative_to(d))
print(len(paths),out.stat().st_size,out)
