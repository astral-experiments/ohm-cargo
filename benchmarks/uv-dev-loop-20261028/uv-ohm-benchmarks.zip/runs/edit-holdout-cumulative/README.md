# Full-workspace private-body edit holdout

This prospective comparison starts from release builds of Ohm Cargo with `--features ohm-defaults`. The baseline is `a0c7d08c898d3fdff992f2f431dec57d2486add2`. The cumulative candidate additionally borrows unit dependencies, defers unused-key warning formatting, caches resolved feature-dependency lookups, borrows dependency-file paths, and moves version requirements when locking them. Each `protocol.json` records both binary digests, the exact invocation, the source, the target, the Cargo home and the eight-pair order before measurement.

The workload is an archive of uv at `c22e6b71933443e9cd299d4b6ac8de035ed4825b`, using Ohm rustc `bfa236f639034f61ec884c15bd1f4e0b75e508ac` and the bundled Wild 0.11.0 linker on x86-64 Linux. The three default-workspace commands use `--locked --offline -j8`. Test construction adds `--no-run`.

From the study workspace, run the following with a fresh study identifier and private Cargo homes. Each Cargo home can be initially absent. The harness creates it with mode 0700 and copies only the staged registry payload into it. Cargo creates its SQLite databases, private Ohm registry cache and locks. The reproduction below uses the observed study identifiers and can be run in a clean workspace.

```sh
bench_root=$(cat work/bench-home.path)
holdout() {
    for phase in warm measure; do
        python3 -B work/edit_holdout.py "$phase" "$1" --study cumulative \
            --result work/edit-holdout-cumulative --base work/bin/matched-base \
            --candidate work/bin/semver --seed "$2" --workspace \
            --cargo-home "$bench_root/cargo-edit-cumulative-$1"
    done
}
holdout check 1080811
holdout build 1080812
holdout test 1080813
```

Each command has its own archive, Cargo home and live target path. Both Cargo binaries and both arms' persistent target trees rotate through identical visible paths within that endpoint. The first build of a pristine archive is followed by a second fresh invocation. The settled target is copied into independent baseline and candidate trees. Each of the eight pairs changes the same `crates/uv/src/install_source.rs` file once. Pair XX accepts `uv-preview-XX` as the Homebrew formula. Both arms see the same bytes and filesystem timestamp, then retain their own resulting build artifacts. Four pairs in each command use each order.

Every measured invocation must compile or check uv, exit successfully and run no tests. The harness checks for matching sorted multisets of compiled or checked packages and matching sorted test-executable lists between arms. `pairs.csv` records these multisets and the edited file's SHA-256 per invocation. Per-command logs preserve the original Cargo output, PID, thread counters and aggregate instructions. The primary endpoint is `check`. The paired proportional reduction is `1 - candidate / baseline`. A two-sided exact sign test and a distribution-free interval for the median accompany the individual observations.

DynamoRIO 11.3.0 counts application instructions across threads of the Cargo process itself. Child-process instructions including the compiler and linker are excluded. The three endpoints ran concurrently with independent homes. Elapsed time under instrumentation is excluded from inference.

| Command | Baseline median instructions | Median paired instruction saving | Median paired reduction | 99.22% median interval |
| --- | ---: | ---: | ---: | ---: |
| `cargo check` | 889.27M | 22.07M | 2.473% | 2.388%–2.567% |
| `cargo build` | 1,038.65M | 40.52M | 3.901% | 3.398%–3.945% |
| `cargo test --no-run` | 1,656.24M | 25.24M | 1.524% | 1.482%–1.607% |

All eight pairs favored the cumulative candidate for each command (two-sided exact sign-test p = 0.0078125 each). All 48 measured invocations rebuilt exactly the uv package and emitted zero package-cache lock diagnostics. The test commands listed the same 72 executables from 53 packages in all 16 invocations. This includes 15 uv executables, three from uv-keyring, two each from uv-client, uv-globfilter and uv-trampoline-builder, and one for each of the other 48 packages. The sorted executable paths are in `test/executables-0.txt`.

The three archived source files were restored and independently matched to the pinned git revision after measurement (SHA-256 `338cddc82f4cc55a1ecdc6b02edd5c28544cd19233d8cb54a7afa9f2b02a7082`). The private Cargo homes had mode 0700 and distinct database inodes. Run `python3 -B work/edit_holdout_summary.py work/edit-holdout-cumulative` to audit the raw logs against their CSV values and regenerate the unrounded `summary.json` and test roster. These measurements estimate the combined effect of the five changes.
