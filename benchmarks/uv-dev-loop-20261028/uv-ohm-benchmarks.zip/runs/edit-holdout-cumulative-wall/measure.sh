#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
bench_root=$(cat work/bench-home.path)

measure() {
    python3 -B work/edit_holdout.py measure "$1" --study cumulative-wall \
        --result work/edit-holdout-cumulative-wall --base work/bin/matched-base \
        --candidate work/bin/semver --seed "$2" --workspace --mode wall \
        --cargo-home "$bench_root/cargo-edit-cumulative-wall-$1"
}

measure check 493821
measure build 493822
measure test 493823
python3 -B work/edit_holdout_summary.py work/edit-holdout-cumulative-wall
