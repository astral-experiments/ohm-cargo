#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
bench_root=$(cat work/bench-home.path)

measure() {
    python3 -B work/edit_holdout.py measure "$1" --study cumulative-wall-replica \
        --result work/edit-holdout-cumulative-wall-replica --base work/bin/matched-base \
        --candidate work/bin/semver --seed "$2" --workspace --mode wall \
        --cargo-home "$bench_root/cargo-edit-cumulative-wall-replica-$1"
}

measure check 720931
measure build 720932
measure test 720933
python3 -B work/edit_holdout_summary.py work/edit-holdout-cumulative-wall-replica
