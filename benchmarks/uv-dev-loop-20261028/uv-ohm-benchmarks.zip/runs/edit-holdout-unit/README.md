# Paired real-edit holdout

The fixture is an archive of uv at `c22e6b71933443e9cd299d4b6ac8de035ed4825b`. Each endpoint has its own archive and target directory under the private benchmark directory recorded in `work/bench-home.path`. The primary endpoint is `cargo check -p uv --lib`. The additional endpoints are `cargo build -p uv` and `cargo test -p uv --test it --no-run`.

Use the following commands from the study workspace. The three warmups ran concurrently. The baseline is Ohm Cargo at `a0c7d08c898d3fdff992f2f431dec57d2486add2`. The candidate adds the first Cargo unit-dependency change. Both Cargo binaries use the release profile and `--features ohm-defaults`. uv was compiled by Ohm rustc at `bfa236f639034f61ec884c15bd1f4e0b75e508ac` with the bundled Wild 0.11.0 linker. Instructions were collected with DynamoRIO 11.3.0 on x86-64 Linux.

```sh
holdout() {
    python3 -B work/edit_holdout.py warm "$1" --study unit \
        --result work/edit-holdout-unit --base work/bin/matched-base \
        --candidate work/bin/unit-deps --seed "$2"
    python3 -B work/edit_holdout.py measure "$1" --study unit \
        --result work/edit-holdout-unit --base work/bin/matched-base \
        --candidate work/bin/unit-deps --seed "$2"
}
holdout check 3301067
holdout build 3301068
holdout test 3301069
```

Run each phase once per endpoint. For another candidate choose a new study name, result directory and candidate binary. Each `protocol.json` records the binary SHA-256 digests and shuffled eight-pair schedule before any measurements. Four pairs run baseline first and four run candidate first.

The harness warms a pristine archive twice, verifies the second command is fresh, and copies the settled target to both arms with `cp -a --reflink=auto`. It parks the targets between trials. Both binaries see the same source path, executable path, dependency cache and target path. Each pair uses one physical edit of `crates/uv/src/install_source.rs` for both arms. Pair XX recognizes `uv-preview-XX` in the private Homebrew-install-source function using the official Ohm direct-edit change. Each arm retains the artifacts produced by its previous edit.

Each measured command must exit successfully, compile or check uv, match its partner's sorted list of (action, package), and launch no tests. The integration-test endpoint additionally requires the executable in the output. Each pair's logs and `pairs.csv` in its endpoint directory record what Cargo built. The CSV also records the edited source SHA-256 and the process-wide dynamic instruction count from DynamoRIO. Child-process work, including rustc and the linker, is excluded. The three concurrent warming/measuring processes and separate concurrent experiments make elapsed time unsuitable for comparison.

| Command | Baseline median instructions | Median paired instruction saving | Median paired reduction | 99.22% median interval |
| --- | ---: | ---: | ---: | ---: |
| `check -p uv --lib` | 803.34M | 2.14M | 0.266% | 0.186%–0.327% |
| `build -p uv` | 878.46M | 2.57M | 0.292% | 0.214%–0.343% |
| `test -p uv --test it --no-run` | 882.54M | 2.39M | 0.271% | 0.251%–0.296% |

All eight pairs favored the candidate for each command, giving an exact two-sided sign-test p-value of 0.0078125 per endpoint. All 48 commands rebuilt exactly the uv package. All 16 test builds emitted the integration-test executable. The archived source bytes were restored and independently checked against the pinned revision after each cohort. `summary.json` contains the unrounded results and each invocation's count of package-cache lock diagnostics.
