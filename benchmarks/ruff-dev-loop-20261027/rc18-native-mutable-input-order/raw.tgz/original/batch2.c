/* Private Linux/x86-64 validation screen for a fixed set of real, individually named inputs. */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <linux/openat2.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <unistd.h>
extern int link_check_fd(int fd, unsigned char out[32], uint64_t *n);
struct item { const char *name; const char *resolved; const unsigned char *digest; uint64_t size; unsigned flags; };
enum { MISSING=1, FILEONLY=2, OUTPUT=4 };
struct observed { int fd; struct stat stamp; };
struct work { const struct item *items; const struct observed *observed; unsigned *tasks; unsigned ntasks; atomic_uint next; atomic_int failure; };
struct counts { uint64_t bytes, files, names, missing; };
static int rooted(int root,const char *n,int flags) {
    struct open_how how={.flags=(unsigned long)flags|O_CLOEXEC,.resolve=RESOLVE_IN_ROOT};return syscall(SYS_openat2,root,n,&how,sizeof(how));
}
static int same(const struct stat *a,const struct stat *b) {
    return a->st_dev==b->st_dev && a->st_ino==b->st_ino && a->st_mode==b->st_mode && a->st_uid==b->st_uid &&
       a->st_gid==b->st_gid && a->st_nlink==b->st_nlink && a->st_size==b->st_size &&
       a->st_mtim.tv_sec==b->st_mtim.tv_sec && a->st_mtim.tv_nsec==b->st_mtim.tv_nsec &&
       a->st_ctim.tv_sec==b->st_ctim.tv_sec && a->st_ctim.tv_nsec==b->st_ctim.tv_nsec;
}
static int location(int fd,const char *expect) {
    char f[48],actual[PATH_MAX+1];snprintf(f,sizeof(f),"/proc/self/fd/%d",fd);
    ssize_t n=readlink(f,actual,sizeof(actual)-1);
    return n>=0 && (size_t)n==strlen(expect) && !memcmp(actual,expect,n);
}
static void *hash_worker(void *env) {
    struct work *w=env;unsigned ax;
    while((ax=atomic_fetch_add(&w->next,1))<w->ntasks){unsigned i=w->tasks[ax];unsigned char b3[32];uint64_t length;
        if(link_check_fd(w->observed[i].fd,b3,&length) || length!=w->items[i].size || memcmp(w->items[i].digest,b3,32)) {
            int zero=0;atomic_compare_exchange_strong(&w->failure,&zero,(int)i+1);break;
        }
    }
    return NULL;
}
int check_named(int root,const struct item *v,unsigned n,unsigned jobs,struct counts *facts,unsigned *bad) {
    if(!n || n>60000 || !jobs || jobs>8)return 1;
    struct observed *cur=calloc(n,sizeof(*cur)); unsigned *tasks=calloc(n,sizeof(*tasks));unsigned htlen=1;
    while(htlen<n*2)htlen*=2;
    unsigned *ht=calloc(htlen,sizeof(*ht)); int rc=0;unsigned i=0,m=0;
    if(!cur||!tasks||!ht){free(cur);free(tasks);free(ht);return 2;}
    for(i=0;i<n;i++)cur[i].fd=-1;
    memset(facts,0,sizeof(*facts)); facts->names=n;
    for(i=0;i<n;i++){
        const struct item *e=&v[i];
        int flags=e->flags&(MISSING|FILEONLY)?O_PATH:(O_RDONLY|O_NONBLOCK|O_NOCTTY|O_NOATIME);
        int fd=rooted(root,e->name,flags);
        if(fd<0 && errno==EPERM && !e->flags && (flags&O_NOATIME)) {
            /* Ordinary read-only system inputs may be owned by root. The
               destination and every type/path/EOF check retain their strict rules. */
            fd=rooted(root,e->name,flags&~O_NOATIME);
        }
        if(e->flags&MISSING){if(fd>=0){close(fd);rc=3;goto done;}if(errno!=ENOENT){rc=4;goto done;}facts->missing++;continue;}
        if(fd<0){rc=5;goto done;}cur[i].fd=fd;
        struct stat *p=&cur[i].stamp;
        if(fstat(fd,p)||!S_ISREG(p->st_mode)||!location(fd,e->resolved)){rc=6;goto done;}
        if(e->flags&FILEONLY)continue;
        if((uint64_t)p->st_size!=e->size){rc=7;goto done;}
        if(e->flags&OUTPUT){if((p->st_mode&07777)!=0775||p->st_nlink!=1||p->st_uid!=geteuid()||flistxattr(fd,NULL,0)!=0){rc=8;goto done;}}
        uint64_t mix=(uint64_t)p->st_ino*11400714819323198485ull ^ (uint64_t)p->st_dev*0x9e3779b9u;
        unsigned at=(mix^(mix>>32))&(htlen-1);
        while(ht[at]){
            unsigned old=ht[at]-1;
            if(p->st_ino==cur[old].stamp.st_ino && p->st_dev==cur[old].stamp.st_dev) {
                if(v[old].size!=e->size||memcmp(v[old].digest,e->digest,32)){rc=9;goto done;}
                break;
            }
            at=(at+1)&(htlen-1);
        }
        if(!ht[at]){ht[at]=i+1;tasks[m++]=i;facts->bytes+=e->size;}
    }
    {
        struct work work={.items=v,.observed=cur,.tasks=tasks,.ntasks=m,.next=0,.failure=0};
        pthread_t threads[7];unsigned count=0;
        while(count+1<jobs && count+1<m){if(pthread_create(&threads[count],NULL,hash_worker,&work)){rc=10;break;}count++;}
        hash_worker(&work);while(count)pthread_join(threads[--count],NULL);
        int failed=atomic_load(&work.failure);if(failed){i=failed-1;rc=11;goto done;}if(rc)goto done;
    }
    facts->files=m;
    for(i=0;i<n;i++){
        const struct item *e=&v[i]; int fd=rooted(root,e->name,O_PATH);
        if(e->flags&MISSING){if(fd>=0){close(fd);rc=12;goto done;}if(errno!=ENOENT){rc=13;goto done;}continue;}
        if(fd<0){rc=14;goto done;}
        struct stat st,held;
        int ok=!fstat(fd,&st)&&same(&st,&cur[i].stamp)&&location(fd,e->resolved)&&!fstat(cur[i].fd,&held)&&same(&st,&held);
        close(fd);if(!ok){rc=15;goto done;}
    }
done:
    *bad=i;for(i=0;i<n;i++)if(cur[i].fd>=0)close(cur[i].fd);
    free(cur);free(tasks);free(ht);return rc;
}
