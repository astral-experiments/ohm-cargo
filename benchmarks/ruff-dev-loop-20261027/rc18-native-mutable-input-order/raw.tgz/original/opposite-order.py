"""Bounded native reader-order counterexample, using the exact generic batch validator and stock Wild."""
import ctypes as C
import errno
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys

root=Path(__file__).resolve().parent
work=root/"case";work.mkdir();os.umask(0o002)
native=work/"native";native.mkdir()
router=native/"z-router.so"; old_body=native/"a0.so";alternate=native/"a1.so"
payload=[native/f"value-{i}.o" for i in range(3)]
lib=C.CDLL(str(root/"libguard2.so"),use_errno=True)
K=C.CDLL(None,use_errno=True);K.ptrace.restype=C.c_long
class Item(C.Structure):
    _fields_=[("name",C.c_char_p),("resolved",C.c_char_p),("digest",C.c_char_p),("size",C.c_uint64),("flags",C.c_uint)]
class Stats(C.Structure):_fields_=[(s,C.c_uint64) for s in ("bytes","files","names","missing")]
class Regs(C.Structure):
    _fields_=[(s,C.c_ulonglong) for s in "r15 r14 r13 r12 rbp rbx r11 r10 r9 r8 rax rcx rdx rsi rdi orig_rax rip cs eflags rsp ss fs_base gs_base ds es fs gs".split()]
lib.link_check_fd.argtypes=[C.c_int,C.c_void_p,C.POINTER(C.c_uint64)]
lib.check_named.argtypes=[C.c_int,C.POINTER(Item),C.c_uint,C.c_uint,C.POINTER(Stats),C.POINTER(C.c_uint)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,doc):p.write_text(json.dumps(doc,sort_keys=True,indent=2)+"\n")
def b3(p):
    fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC);val=C.create_string_buffer(32);n=C.c_uint64()
    try:assert lib.link_check_fd(fd,val,C.byref(n))==0 and n.value==p.stat().st_size
    finally:os.close(fd)
    return val.raw
def stamp(p):
    s=p.stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
for dest,value in zip(payload,(41,83,97)):
    code=native/(dest.stem+".c");code.write_text(f"int native_value(void) {{ return {value}; }}\n")
    subprocess.run(["/usr/bin/cc","-fPIC","-c",code,"-o",dest],check=True)
def script(dest):return f"INPUT ( {dest} )\n".encode()
a0=script(old_body);a1=script(alternate);b0=script(payload[0]);b1=script(payload[1])
alternate.write_bytes(script(payload[2]))
def offset(x,y):
    changes=[i for i,(u,v) in enumerate(zip(x,y)) if u!=v]
    assert len(x)==len(y) and len(changes)==1
    return changes[0]
ia,ib=offset(a0,a1),offset(b0,b1)
src=work/"workspace";(src/"src").mkdir(parents=True)
(src/"Cargo.toml").write_text('[package]\nname="native-router"\nversion="0.1.0"\nedition="2021"\n')
(src/"Cargo.lock").write_text('# manual manifest-only lockfile\nversion = 4\n\n[[package]]\nname="native-router"\nversion="0.1.0"\n')
(src/"build.rs").write_text('fn main() { println!("cargo:rustc-link-arg='+str(router)+'"); }\n')
(src/"src/main.rs").write_text('extern "C" {fn native_value() -> i32;} fn main() {println!("{}",unsafe {native_value()});}\n')
store=Path("/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027")
sdk=work/"sdk";sdk.mkdir();ru=work/"rustup";(ru/"toolchains").mkdir(parents=True);(ru/"toolchains/ohm").symlink_to(sdk)
lower=store/"frozen-toolchain";d=store/"mixed-module-children-17-v1-20261028/tool-rc18-export-r2/candidate-driver.so"
cargo=Path("/mnt/devbox-scratch/dev-user/ohm-rc18-pgo-qualification-20261028/cargo")
stock=lower/"lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd"
so=next((lower/"lib").glob("librustc_driver-*.so")).name
assert sha(stock)=="0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5"
assert sha(d)=="22abce6921b46f93f387c7d3d99cefa4df9c0a866619447077699ef81a73827f"
assert sha(cargo)=="cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8"
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO_","WILD_","OHM_QA")) and k not in ("RUSTFLAGS","RUSTC","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","LD_PRELOAD","LD_AUDIT")}
env.update(RUSTUP_HOME=str(ru),RUSTUP_AUTO_INSTALL="0",PATH=str(Path.home()/".cargo/bin")+":"+os.environ["PATH"],
           CARGO_HOME=str(work/"cargo-home"),CARGO_TARGET_DIR=str(work/"target"),CARGO_BUILD_BUILD_DIR=str(work/"shared"),CARGO_NET_OFFLINE="true")
cmd=[str(Path.home()/".cargo/bin/cargo"),"+ohm","build","--locked","--offline","-j1","--message-format=json"]
refs={}
for av,bv,value in [(0,0,41),(1,0,97),(1,1,97),(0,1,83)]:
    router.write_bytes((a0,a1)[av]);old_body.write_bytes((b0,b1)[bv]);name=f"A{av}B{bv}"
    results=root/name;results.mkdir()
    ns=["bwrap","--ro-bind","/","/","--dev","/dev","--proc","/proc","--bind",str(work),str(work),
        "--bind",str(results),str(results),"--tmpfs","/tmp","--ro-bind",str(lower),str(sdk),"--ro-bind",str(d),str(sdk/"lib"/so),
        "--ro-bind",str(cargo),str(sdk/"bin/cargo"),"--chdir",str(src),"--"]
    # Files are created at the same logical locations in four independent empty build stores.
    trace=results/"trace"
    p=subprocess.run(ns+["strace","-f","-qq","-s","32768","-e","trace=execve,openat,openat2,statx","-o",str(trace),"--",*cmd],env=env,capture_output=True,timeout=120)
    (results/"stdout").write_bytes(p.stdout);(results/"stderr").write_bytes(p.stderr)
    assert p.returncode==0,p.stderr[-1200:]
    log=[json.loads(l) for l in p.stdout.splitlines() if l];exe,=[Path(o["executable"]) for o in log if o.get("executable") and o["target"]["name"]=="native-router"]
    run=subprocess.run([exe],capture_output=True,timeout=5);assert run.returncode==0 and int(run.stdout)==value
    lines=trace.read_text(errors="replace").splitlines()
    wild=[(n,l) for n,l in enumerate(lines) if "execve(" in l and "wild-ld/ld.bfd\"" in l and l.endswith("= 0")]
    assert len(wild)==2,(name,len(wild))
    start,last=wild[-1];fact=lambda k,rex:[(n,hashlib.sha256(l.encode()).hexdigest()) for n,l in enumerate(lines) if n>start and ('"'+str(k)+'"')in l and re.search(rex,l)]
    re_open=r"openat2?\(.*= [0-9]+$"
    rf=fact(router,re_open);bf=fact(old_body,re_open);alt=fact(alternate,re_open)
    assert rf and (bf and not alt and rf[0][0]<bf[0][0] if av==0 else alt and not bf and rf[0][0]<alt[0][0]),(name,rf,bf,alt)
    if name=="A0B0":
        image=work/"gold";shutil.copyfile(exe,image);image.chmod(0o775)
    refs[name]={"runtime":value,"sha256":sha(exe),"cargo":cmd,"rustc_driver":sha(d),"wild":sha(stock),
                "wild_count":len(wild),"true_native_exec_line":hashlib.sha256(last.encode()).hexdigest(),"router_opens":rf,
                "body0_opens":bf,"alternate_opens":alt,"oracle_source_sha256":sha(src/"src/main.rs")}
    for folder in ("target","shared"):
        if (work/folder).is_dir():(work/folder).rename(work/(name+"-"+folder))
save(root/"native-states.json",refs)
router.write_bytes(a0);old_body.write_bytes(b0)
# The unchanging inputs can be added anywhere. The recipe rows use exactly the name order of emit2.py.
paths=sorted([router,old_body,*payload,alternate,image])
wire=[(os.fsencode(p),os.fsencode(p),b3(p),p.stat().st_size,4 if p==image else 0) for p in paths]
table=(Item*len(wire))(*(Item(*q) for q in wire))
def verify():
    rootfd=os.open("/",os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    output=Stats();bad=C.c_uint()
    try:status=lib.check_named(rootfd,table,len(table),1,C.byref(output),C.byref(bad))
    finally:os.close(rootfd)
    return {"status":status,"bad":bad.value if status else None,"files":output.files,"bytes":output.bytes}
assert verify()["status"]==0
fd=[os.open(p,os.O_RDWR)for p in (router,old_body)]
am,bm=(mmap.mmap(f,0,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE)for f in fd)
def pstat():return {"A":stamp(router),"B":stamp(old_body)}
def state():return [am[ia],bm[ib]]
am[ia],bm[ib]=a1[ia],b0[ib]
primed=pstat()
assert verify()["status"]!=0
def ptrace(req,pid,data=None):
    ret=K.ptrace(C.c_ulong(req),C.c_ulong(pid),None,data)
    if ret==-1:raise OSError(C.get_errno(),os.strerror(C.get_errno()))
left,right=os.pipe();pid=os.fork()
if pid==0:
    os.close(left);ptrace(0,0);os.kill(os.getpid(),signal.SIGSTOP)
    ans=verify();os.write(right,json.dumps(ans).encode());os._exit(0)
os.close(right);st=os.waitpid(pid,0)[1];assert os.WIFSTOPPED(st)
ptrace(0x4200,pid,C.c_void_p(1));enter=True;changed=False;events=[];order=[]
while True:
    ptrace(24,pid);st=os.waitpid(pid,0)[1]
    if os.WIFEXITED(st):assert os.WEXITSTATUS(st)==0;break
    assert os.WIFSTOPPED(st) and os.WSTOPSIG(st)==(signal.SIGTRAP|128),st
    regs=Regs();ptrace(12,pid,C.byref(regs))
    if enter and regs.orig_rax==17: # Linux x86_64 pread64 entry.
        try:where=os.readlink(f"/proc/{pid}/fd/{regs.rdi}")
        except OSError:where=None
        if where in (str(old_body),str(router)):
            order.append((Path(where).name,regs.r10))
        if not changed and where==str(router):
            assert any(path==old_body.name and off>0 for path,off in order)
            events.append(("A1B0",state(),pstat()));bm[ib]=b1[ib];events.append(("A1B1",state(),pstat()))
            am[ia]=a0[ia];events.append(("A0B1",state(),pstat()));changed=True
    enter=not enter
claim=json.loads(os.read(left,4096));os.close(left)
assert changed and claim["status"]==0,(order,claim,events)
assert all(e[2]==primed for e in events) and pstat()==primed,(primed,events,pstat())
assert [q[1] for q in events]==[[a1[ia],b0[ib]],[a1[ia],b1[ib]],[a0[ia],b1[ib]]]
late=verify();assert late["status"]!=0
save(root/"impossible-hit.json",{"original":refs["A0B0"],"reachable_states":[{"name":e[0],"visible_value":refs[e[0]]["runtime"]}for e in events],
     "fd_reads":order,"observer_edges":events,"held_before":primed,"held_after":pstat(),"batch_claim":claim,"stable_end_recheck":late,
     "checked_image_sha256":sha(image),"actual_lib":sha(root/"libguard2.so"),"rows":[{"name":p[0].decode(),"blake3":p[2].hex(),"bytes":p[3],"flags":p[4]}for p in wire],
     "input_paths":{"router":str(router),"body":str(old_body)},"script_toggles":[a0.decode(),a1.decode(),b0.decode(),b1.decode()]})
for x in (am,bm):x.close()
for n in fd:os.close(n)
print("actual Cargo values", [r["runtime"] for r in refs.values()],"accepted",claim,"next stable",late)
