extern "C" {fn native_value() -> i32;} fn main() {println!("{}",unsafe {native_value()});}
