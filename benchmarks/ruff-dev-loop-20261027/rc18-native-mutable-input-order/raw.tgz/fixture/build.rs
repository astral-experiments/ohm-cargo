fn main() { println!("cargo:rustc-link-arg=/mnt/devbox-scratch/dev-user/ohm-rust-native-fresh-handoff-r2-20261028/opposed-native-query-v1/case/native/z-router.so"); }
