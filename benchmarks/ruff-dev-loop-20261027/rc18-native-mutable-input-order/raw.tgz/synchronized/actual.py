"""Place the same two writes at real stock Wild syscalls under ordinary cargo +ohm."""
import argparse, ctypes as C, errno, fcntl, hashlib, json, mmap, os, select, shutil, signal, subprocess
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument("original",type=Path);p.add_argument("output",type=Path);a=p.parse_args()
srcroot=a.original.resolve();root=a.output.resolve();logical=srcroot/"case";root.mkdir(exist_ok=True)
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+"\n")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(p):
    s=p.stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def offset(x,y):
    ds=[i for i,(u,v) in enumerate(zip(x,y))if u!=v];assert len(x)==len(y) and len(ds)==1;return ds[0]
def script(p):return f"INPUT ( {p} )\n".encode()
gold=json.loads((srcroot/"native-states.json").read_bytes())
exref=json.loads((srcroot/"impossible-hit.json").read_bytes())
gate=root/"gate";subprocess.run(["cc","-std=gnu11","-O2","-Wall","-Wextra","-Werror",Path(__file__).with_name("gate.c"),"-o",gate],check=True)
case=logical;nsrc=case/"native";stockbase=Path("/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027")
lower=stockbase/"frozen-toolchain";drv=stockbase/"mixed-module-children-17-v1-20261028/tool-rc18-export-r2/candidate-driver.so"
cargo=Path("/mnt/devbox-scratch/dev-user/ohm-rc18-pgo-qualification-20261028/cargo")
stock=lower/"lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd";soname=next((lower/"lib").glob("librustc_driver-*.so")).name
bind={"stock_wild":sha(stock),"candidate_driver":sha(drv),"cargo":sha(cargo),"supervisor":sha(gate),"supervisor_source":sha(Path(__file__).with_name("gate.c"))}
assert bind["stock_wild"]==gold["A0B0"]["wild"] and bind["candidate_driver"]==gold["A0B0"]["rustc_driver"]
assert bind["cargo"]=="cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8"
SDK=case/"sdk";ru=case/"rustup"
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO_","WILD_","OHM_QA")) and k not in ("RUSTFLAGS","RUSTC","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","LD_PRELOAD","LD_AUDIT")}
env.update(RUSTUP_HOME=str(ru),RUSTUP_AUTO_INSTALL="0",PATH=str(Path.home()/".cargo/bin")+":"+os.environ["PATH"],
           CARGO_HOME=str(case/"cargo-home"),CARGO_TARGET_DIR=str(case/"target"),CARGO_BUILD_BUILD_DIR=str(case/"shared"),CARGO_NET_OFFLINE="true")
allrows={}
cmd=gold["A0B0"]["cargo"]
K=C.CDLL(None,use_errno=True);K.mmap.restype=C.c_void_p;K.mmap.argtypes=[C.c_void_p,C.c_size_t,C.c_int,C.c_int,C.c_int,C.c_long]
K.munmap.argtypes=[C.c_void_p,C.c_size_t]
def map_no_fd(path):
    fd=os.open(path,os.O_RDWR);n=os.fstat(fd).st_size
    try:
        ptr=K.mmap(None,n,mmap.PROT_READ|mmap.PROT_WRITE,mmap.MAP_SHARED,fd,0)
        assert ptr not in(None,C.c_void_p(-1).value),(path,C.get_errno())
        return (C.c_ubyte*n).from_address(ptr),ptr,n
    finally:os.close(fd)
def writable_fds(paths):
    ids={(p.stat().st_dev,p.stat().st_ino)for p in paths};out=[]
    for node in Path("/proc/self/fd").iterdir():
        try:
            fd=int(node.name);st=os.fstat(fd)
            if (st.st_dev,st.st_ino) in ids and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE in (os.O_RDWR,os.O_WRONLY):out.append(fd)
        except OSError:pass
    return out
def try_read_lease(p):
    fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC)
    try:
        try:fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_RDLCK)
        except OSError as e:return {"accepted":False,"errno":errno.errorcode[e.errno]}
        fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_UNLCK);return {"accepted":True}
    finally:os.close(fd)
for name in ("before-router","after-router","before-object","after-object"):
    d=root/name; d.mkdir();physical=d/"state";physical.mkdir()
    shutil.copytree(case/"workspace",physical/"workspace");shutil.copytree(nsrc,physical/"native")
    (physical/"sdk").mkdir();(physical/"rustup/toolchains").mkdir(parents=True)
    (physical/"rustup/toolchains/ohm").symlink_to(SDK)
    router=physical/"native/z-router.so";body=physical/"native/a0.so";obj=physical/"native/value-0.o"
    logical_output=next(l.split('"')[1] for l in (srcroot/"A1B0/trace").read_text().splitlines()if "O_CREAT|O_TRUNC" in l and '/out/native_router"' in l)
    if name.endswith("router"):
        pa=(script(nsrc/"a0.so"),script(nsrc/"a1.so"));pb=tuple(script(nsrc/f"value-{i}.o")for i in (0,1))
        ia,ib=offset(*pa),offset(*pb);router.write_bytes(pa[1]);body.write_bytes(pb[0]);watched=(router,body)
        maps=[map_no_fd(path) for path in watched];ma,mb=(r[0]for r in maps)
        ma[ia]=pa[1][ia];mb[ib]=pb[0][ib]
        want=(nsrc/("z-router.so" if name=="before-router" else "a1.so"));expected=83 if name=="before-router" else 97
    else:
        (physical/"workspace/build.rs").write_text('fn main() { println!("cargo:rustc-link-arg='+str(nsrc/"value-0.o")+'"); }\n')
        old=obj.read_bytes();needle=bytes.fromhex("b829000000");assert old.count(needle)==1
        imm=old.index(needle)+1; watched=(obj,);maps=[map_no_fd(obj)];mo=maps[0][0];mo[imm]=41
        want=nsrc/"value-0.o" if name=="before-object" else Path(logical_output);expected=83 if name=="before-object" else None
    assert not writable_fds(watched)
    leases=[try_read_lease(path)for path in watched];assert all(o=={"accepted":False,"errno":"EAGAIN"} for o in leases),leases
    for n in ("ready","ack"):os.mkfifo(d/n)
    r,w=(os.open(d/n,os.O_RDWR|os.O_CLOEXEC|os.O_NONBLOCK)for n in("ready","ack"))
    ns=["bwrap","--ro-bind","/","/","--dev","/dev","--proc","/proc","--bind",str(physical),str(case),"--bind",str(d),str(d),"--tmpfs","/tmp","--ro-bind",str(lower),str(SDK),"--ro-bind",str(drv),str(SDK/"lib"/soname),"--ro-bind",str(cargo),str(SDK/"bin/cargo"),"--chdir",str(case/"workspace"),"--"]
    worker=ns+[str(gate),str(stock),str(want),str(nsrc)+"/",str(d/"ready"),str(d/"ack"),str(d/"kernel.tsv"),logical_output,"--",*cmd]
    with (d/"stdout").open("wb")as stdout,(d/"stderr").open("wb")as stderr:
        proc=subprocess.Popen(worker,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            assert select.select([r],[],[],35)[0],(name,proc.poll(),(d/"kernel.tsv").read_text()[-500:])
            assert os.read(r,1)==b"K"
            events=[]
            def event(label):
                vs=[ma[ia],mb[ib]]if name.endswith("router")else[mo[imm]]
                events.append({"state":label,"byte_values":vs,"stamps":[stamp(o)for o in watched]})
            if name.endswith("router"):
                event("A1B0");mb[ib]=pb[1][ib];event("A1B1");ma[ia]=pa[0][ia];event("A0B1")
            else:event("41");mo[imm]=83;event("83")
            assert all(t["stamps"]==events[0]["stamps"] for t in events)
            assert os.write(w,b"A")==1;status=proc.wait(timeout=35);assert status==0,(name,status,(d/"stderr").read_text()[-600:])
        finally:
            if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            os.close(r);os.close(w)
    for _,pmap,n in maps:assert K.munmap(pmap,n)==0
    after_leases=[try_read_lease(o)for o in watched];assert all(q["accepted"] for q in after_leases),after_leases
    prod=[o for o in map(json.loads,(d/"stdout").read_bytes().splitlines()) if o.get("executable") and o["target"]["name"]=="native-router"]
    assert len(prod)==1;display=Path(prod[0]["executable"])
    actual=physical/display.relative_to(case);run=subprocess.run([actual],capture_output=True,timeout=5);value=int(run.stdout)
    assert not run.returncode and not run.stderr and (value==expected if expected is not None else value in (41,83))
    events_log=(d/"kernel.tsv").read_text().splitlines();native=[l for l in events_log if l.startswith("native\t")]
    barr,=[l for l in events_log if l.startswith("barrier\t")];assert barr.endswith(str(want))
    assert events_log[-1]=="exit\t0\t1"
    if name.endswith("router"):
        assert sha(actual)==gold["A0B1" if expected==83 else "A1B1"]["sha256"]
    datum={"name":name,"cargo_argv":cmd,"native_trigger":str(want),"supervisor_status":status,"events":events,"actual_output":str(display),"physical_rel":str(actual.relative_to(root)),"value":value,"program_exit":run.returncode,"program_stdout":run.stdout.decode(),"elf_sha256":sha(actual),"watched_host_write_fds":[],"read_leases_while_mapped":leases,"read_leases_after_unmap":after_leases,"native_events":native,"exec_lines":[k for k in events_log if k.startswith("exec\t")],"kernel_tsv_sha256":sha(d/"kernel.tsv")}
    save(d/"receipt.json",datum);allrows[name]=datum;print(name,value,flush=True)
save(root/"synchronized.json",{"subjects":bind,"rows":allrows,"original_native_sha256":sha(srcroot/"native-states.json"),"impossible_claim_sha256":sha(srcroot/"impossible-hit.json")})
