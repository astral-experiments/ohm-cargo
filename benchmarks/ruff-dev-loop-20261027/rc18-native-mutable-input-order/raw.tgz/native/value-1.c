int native_value(void) { return 83; }
