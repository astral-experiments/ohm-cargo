#[test] fn value() {
 let saved=observer::observed!(); let now=std::fs::read(env!("CARGO_BIN_EXE_worker")).unwrap().iter().fold(0u64,|h,&b|h.wrapping_mul(257).wrapping_add(u64::from(b)));
 assert_eq!(saved,now);
}
