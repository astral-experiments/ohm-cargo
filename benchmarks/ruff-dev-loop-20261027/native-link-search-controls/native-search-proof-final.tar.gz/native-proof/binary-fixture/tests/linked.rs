#[test] fn value() { println!("linked={}",terminal::api()); }
