#[test] fn value() {
 let path=env!("CARGO_BIN_EXE_worker"); let saved=include_bytes!(env!("CARGO_BIN_EXE_worker")); 
 assert_eq!(saved.as_slice()==std::fs::read(path).unwrap(),true);
}
