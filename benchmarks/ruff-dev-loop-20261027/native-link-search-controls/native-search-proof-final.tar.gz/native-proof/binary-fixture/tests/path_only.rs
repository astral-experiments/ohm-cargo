#[test] fn value() {
 let out=std::process::Command::new(env!("CARGO_BIN_EXE_worker")).output().unwrap();
 println!("runtime={}",String::from_utf8(out.stdout).unwrap().trim());
}
