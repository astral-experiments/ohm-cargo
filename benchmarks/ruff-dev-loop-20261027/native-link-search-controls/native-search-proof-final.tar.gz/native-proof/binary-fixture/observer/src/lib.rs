#![feature(proc_macro_tracked_path)]
extern crate proc_macro;
#[proc_macro] pub fn observed(_: proc_macro::TokenStream) -> proc_macro::TokenStream {
 let path=std::env::var("CARGO_BIN_EXE_worker").unwrap();
 proc_macro::tracked::path(&path);
 let data=std::fs::read(path).unwrap();
 let h=data.iter().fold(0u64, |h,&b| h.wrapping_mul(257).wrapping_add(u64::from(b)));
 format!("{h}u64").parse().unwrap()
}
