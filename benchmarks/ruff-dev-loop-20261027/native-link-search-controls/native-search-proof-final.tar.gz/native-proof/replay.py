"""Proof of one Wil­d input lookup closure, using the actual released process's file trace.

This is a resolver experiment in a private, single-writer filesystem. It is not a Cargo or driver
link certificate. A product writer must gather the observation and hash from the linker file handle,
and must use a comparable immutable filesystem or change journal for the validation window.
"""
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess

D=Path(__file__).resolve().parent
C=D/'case'
OLD=D/'actual-release14.trace'
W=Path('/home/dev-user/.cache/ohm-lint-cli-scout-20261026/release14-comparisons/published-toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')
ARGS=[str(W),'--no-fork','--threads=1','--build-id=sha1','--gc-sections','-m','elf_x86_64','-o','out','start.o','-Lblocked/child','-Lblank','-Learly','-Llate','-Lscripts','-Linner','-ldispatch']
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def emit(name,object):
    (D/name).write_text(json.dumps(object,indent=2)+'\n')
def run(command,**kwargs):
    return subprocess.run(command,cwd=C,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},capture_output=True,**kwargs)
def read_path(path):
    """Return the first missing component or the SHA of a regular file without following any link."""
    assert path.is_absolute() and '..' not in path.parts
    directory=os.open('/',os.O_DIRECTORY|os.O_RDONLY|os.O_CLOEXEC)
    try:
        for idx,name in enumerate(path.parts[1:]):
            last=idx==len(path.parts[1:])-1
            try:
                found=os.stat(name,dir_fd=directory,follow_symlinks=False)
                if stat.S_ISLNK(found.st_mode):return ('unsupported','symlink')
                if last:
                    if not stat.S_ISREG(found.st_mode):return ('unsupported','nonregular')
                    fd=os.open(name,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory)
                    with os.fdopen(fd,'rb') as f:
                        st=os.fstat(fd)
                        if st.st_dev!=found.st_dev or st.st_ino!=found.st_ino or not stat.S_ISREG(st.st_mode):
                            return ('unsupported','raced before open')
                        digest=hashlib.file_digest(f,'sha256').hexdigest()
                        after=os.fstat(fd)
                        if (st.st_mtime_ns,st.st_ctime_ns,st.st_size)!=(after.st_mtime_ns,after.st_ctime_ns,after.st_size):
                            return ('unsupported','raced while reading')
                        return ('regular',digest)
                if not stat.S_ISDIR(found.st_mode): return ('absent','ENOTDIR')
                current=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC|os.O_NOFOLLOW,dir_fd=directory)
                st=os.fstat(current)
                if (found.st_dev,found.st_ino)!=(st.st_dev,st.st_ino):
                    os.close(current);return ('unsupported','raced during traversal')
                os.close(directory);directory=current
            except OSError as exception:
                if exception.errno in (errno.ENOENT,errno.ENOTDIR):return ('absent',errno.errorcode[exception.errno])
                return ('unsupported',errno.errorcode.get(exception.errno,'unknown'))
    finally:
        os.close(directory)
    return ('unsupported','empty path')
def capture():
    events=[];names=set();all_opened=set()
    for line in OLD.read_text().splitlines():
        m=re.search(r'(statx|openat)\(AT_FDCWD, "([^"]+)", (.*)\)\s+= (.*)$',line)
        if not m:continue
        op,raw,flags,result=m.groups()
        p=Path(raw);p=p if p.is_absolute() else C/p
        if not p.is_relative_to(C):continue
        assert '..' not in p.parts
        if p==C/'out':continue
        rel=str(p.relative_to(C))
        if op=='openat' and not flags.startswith('O_RDONLY'):raise ValueError(line)
        if re.search(r'^-1 (ENOENT|ENOTDIR)\b',result):
            outcome=('absent',result.split()[1]);assert op=='statx' and read_path(p)==outcome,(p,result,read_path(p))
        elif result.startswith('-'):raise ValueError(f'intermittent or unsupported error: {rel} {result}')
        else:
            outcome=read_path(p);assert outcome[0]=='regular',(p,outcome)
            if op=='openat':all_opened.add(rel)
            else:names.add(rel)
        events.append({'op':op,'path':rel,'state':list(outcome)})
    assert names==all_opened and all_opened=={'start.o','scripts/libdispatch.so','inner/libinner.so','late/libauditffi.a'}
    return events
def check(receipt,argv=ARGS):
    if argv!=receipt['argv'] or str(C)!=receipt['cwd'] or sha(W)!=receipt['wild']:return (False,'executable/arguments/cwd')
    for e in receipt['lookup_events']:
        p=C/e['path'];v=read_path(p)
        if v!=tuple(e['state']) or v[0]=='unsupported':return (False,f"{e['path']} {v[0]} {v[1] if v[0]!='regular' else v[1][:10]}")
    out=C/'out';v=read_path(out)
    if v!=tuple(receipt['output']) or out.stat().st_nlink!=1:return (False,'output')
    return (True,'same resolution and regular output')
def normal():
    r=run(ARGS);assert not r.returncode,r.stderr;out=run([C/'out']);return out.returncode,sha(C/'out')
def restore_inputs():
    for n in ['blocked','late','scripts','inner','early','blank']:
        p=C/n
        if p.is_symlink() or p.is_file():p.unlink()
        elif p.is_dir():p.chmod(0o755);shutil.rmtree(p)
    for n in ['late','scripts','inner','early','blank']:(C/n).mkdir()
    (C/'blocked').write_text('a regular non-directory prefix\n')
    (C/'scripts/libdispatch.so').write_text('GROUP ( -linner )\n')
    (C/'inner/libinner.so').write_text('INPUT ( -lauditffi )\n')
    shutil.copyfile(C/'input-41.a',C/'late/libauditffi.a')
restore_inputs()
value,baseline=normal();assert value==41
events=capture()
receipt={'scope':'single-threaded direct, fixed x86-64 Wild, regular normalized paths, exact process argv fixed, closed private tree','wild':sha(W),'cwd':str(C),'argv':ARGS,'lookup_events':events,'output':list(read_path(C/'out'))}
emit('native-lookup-certificate.json',receipt)
rows=[]
def arm(name,change,want_hit,want_value,custom_argv=None):
    restore_inputs();assert normal()==(41,baseline);change()
    before=check(receipt,ARGS if custom_argv is None else custom_argv)
    got,elf=normal()
    assert before[0]==want_hit and got==want_value,(name,before,got)
    rows.append(dict(case=name,accepted=before[0],why=before[1],real_wild_value=got,real_output_sha256=elf))
def empty():pass
def replace(src,dst):shutil.copyfile(C/src,C/dst)
arm('unchanged',empty,True,41)
arm('unqueried unrelated regular file',lambda:(C/'early/unused.a').write_text('unused'),True,41)
arm('earlier static archive now exists',lambda:replace('input-83.a','early/libauditffi.a'),False,83)
arm('earlier shared-name linker script now exists',lambda:(C/'early/libauditffi.so').write_text('INPUT ( ../input-83.a )\n'),False,83)
arm('selected archive bytes changed',lambda:replace('input-83.a','late/libauditffi.a'),False,83)
arm('nested archive script changed',lambda:(C/'inner/libinner.so').write_text('INPUT ( ../input-83.a )\n'),False,83)
def changed_prefix():
    (C/'blocked').unlink();(C/'blocked/child').mkdir(parents=True);replace('input-83.a','blocked/child/libauditffi.a')
arm('ENOTDIR prefix becomes an earlier directory',changed_prefix,False,83)
arm('missing parent added without provider',lambda:(C/'blocked').unlink(),False,41)
arm('earlier dangling symlink',lambda:(C/'early/libauditffi.so').symlink_to(C/'does-not-exist'),False,41)
def live_alias():
    (C/'late/libauditffi.a').unlink();(C/'late/libauditffi.a').symlink_to(C/'input-83.a')
arm('selected archive symlink retarget',live_alias,False,83)
arm('unexpected EACCES in lookup',lambda:(C/'early').chmod(0),False,41)
arm('different list of flags',empty,False,41,ARGS+['-v'])
restore_inputs();assert normal()==(41,baseline)
emit('results.json',{'subject':receipt['wild'],'event_count':len(events),'search_calls':sum(e['op']=='statx' for e in events),'opened_regular':sum(e['op']=='openat' for e in events),'missing':sum(e['state'][0]=='absent' for e in events),'truth':rows})
print(len(events),'events',len(rows),'cases','positive',sum(x['accepted'] for x in rows))
