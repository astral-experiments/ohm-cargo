use std::{env, path::Path,process::Command};
fn main() {
 println!("cargo:rerun-if-changed=src/v.c");
 let dir=env::var("OUT_DIR").unwrap();let p=Path::new(&dir);
 assert!(Command::new("cc").args(["-c","src/v.c","-o"]).arg(p.join("v.o")).status().unwrap().success());
 assert!(Command::new("ar").arg("crs").arg(p.join("libauditffi.a")).arg(p.join("v.o")).status().unwrap().success());
 println!("cargo:rustc-link-search=native={dir}");
}
