int audit_ffi(void){return 41;}
