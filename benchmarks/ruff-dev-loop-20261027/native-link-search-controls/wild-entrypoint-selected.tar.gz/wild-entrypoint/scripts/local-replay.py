"""Replay retained Ruff compiler link plans while placing every writable output in this private directory."""
from pathlib import Path
import json,os,subprocess,shutil,sys,hashlib
D=Path(__file__).resolve().parent
if sys.argv[1:]==['all-frozen']:
 for name in ['config','direxist_guard','resolve_files','analyze_graph']:
  for phase in ['capture','repeat1','repeat2','repeat3']:
   if (D/name/phase/'real-link.json').is_file():continue
   subprocess.run([sys.executable,__file__,name,phase],check=True)
 raise SystemExit(0)
R=Path.home()/'.cache/ohm-wild-regular-reloc-20261026';B=D.parent/'unused-link-audit-20261027'
S=json.loads((B/'independent-native-layouts.json').read_bytes()); n=sys.argv[1]; out=D/n; out.mkdir(exist_ok=True)
l=Path(next(z['layout'] for k,z in S.items() if k.rsplit('-',1)[0]==n)); parent=l.parent;exe=l.stem;rl=l.with_suffix('.rlink');orig=json.loads(l.with_suffix('.rlink-cache.json').read_bytes())['rlink']['path'];p=out/'output';p.mkdir(exist_ok=True);shutil.copyfile(rl,p/rl.name);objects=l.with_suffix('.rlink-objects');shutil.copytree(objects,p/objects.name,dirs_exist_ok=True)
seq=sys.argv[2] if len(sys.argv)>2 else '0'; w=out/seq;w.mkdir(exist_ok=False); current=out/'active';current.write_text(seq)
base=R/'full/toolchain'; linker_tool=base/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'; actual=hashlib.file_digest(linker_tool.open('rb'),'sha256').hexdigest(); assert actual=='0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'
cpus=next(('26,27' for _ in range(1) if {26,27}<=os.sched_getaffinity(0)),str(min(os.sched_getaffinity(0))));
args=['taskset','-c',cpus,'bwrap','--die-with-parent','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--bind',str(D),str(D),'--tmpfs','/tmp','--bind',str(p),str(parent),'--setenv','RUSTUP_HOME',str(R/'combined-test/rustup'),'--setenv','WILD_PROBE_ROOT',str(out),'--setenv','WILD_PROBE_STOCK',str(linker_tool),'--setenv','PATH','/usr/bin:/bin','--chdir',str(out),str(Path.home()/'.cargo/bin/rustc'),'+ohm','--edition=2024','--crate-name',n,'--test','-Zlink-only',orig,'-C','linker='+str(D/'gcc-probe'),'-C','debuginfo=2','-C','link-arg=-fuse-ld=bfd']
native_base=orig.split('/ruff/')[0]
args.extend(['-L','native='+native_base+'/psm/75592682b0d1f2fd/out','-L','native='+native_base+'/zstd-sys/f935fd70e86ba182/out','-L','native='+native_base+'/tikv-jemalloc-sys/2aa41c618fcb122b/out/build/lib'])
(w/'launch.json').write_text(json.dumps(args));z=subprocess.run(args,capture_output=True);(w/'stdout').write_bytes(z.stdout);(w/'stderr').write_bytes(z.stderr);print(z.returncode,z.stderr.decode(errors='replace')[:2800]);sys.exit(z.returncode)
