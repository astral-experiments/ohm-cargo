"""Require real ELF GCC plugin and linker-script cases to miss the restricted frozen recipe."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
D=Path(__file__).resolve().parent;C=D/('unsupported'+('-verified' if sys.argv[1:]==['--trace'] else ''));C.mkdir(exist_ok=False);B=D.parent/'unused-link-audit-20261027/compact-native-proof';W=Path(json.loads((B/'toolchains.json').read_bytes())['published-1.99.0-14']['physical']['lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd']['real_path']);env=dict(PATH='/usr/bin:/bin',LC_ALL='C');sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def cmd(a,check=True):return subprocess.run(a,cwd=C,env=env,capture_output=True,check=check)
(C/'plugin.c').write_text('int auditffi(void) { return 83; }\n');cmd(['gcc','-flto','-fno-fat-lto-objects','-c','plugin.c','-o','ir.o']);cmd(['ar','crs','libir.a','ir.o']);native=D/'entry-controls';ptr=C/'prefix';ptr.mkdir();(ptr/'ld.bfd').write_text('#!/bin/sh\nexec /usr/bin/strace -ff -s 1024 -e trace=%file -o '+str(C/'plugin.trace')+' '+str(W)+' "$@"\n');(ptr/'ld.bfd').chmod(0o755)
z=cmd(['/usr/bin/gcc','-B'+str(ptr)+'/', '-fuse-ld=bfd','-nostdlib','-nostartfiles','-nodefaultlibs','-static','-no-pie',native/'start.o',C/'libir.a','-o',C/'lto'],False);tr=[s for p in C.glob('plugin.trace.*') for s in p.read_text().splitlines()];res={'link_exit':z.returncode,'diagnostics':z.stderr.decode(errors='replace').splitlines()[:4], 'plugin_open_count':sum('openat(' in s and 'liblto_plugin.so"' in s and ' = -1' not in s for s in tr),'gcc_resolution_file_observed':any('.res"' in s for s in tr),'has_gcc_lto':b'.gnu.lto_' in (C/'ir.o').read_bytes()};
if z.returncode==0:res['result']=subprocess.run([C/'lto']).returncode; assert res['result']==83
assert res['has_gcc_lto'] and not any('PTRACE' in l for l in res['diagnostics']),res;
(C/'script-start.s').write_text('.global _start\n.text\n_start:\n mov $external_value,%edi\n mov $60,%eax\n syscall\n');cmd(['as','-o','script-start.o','script-start.s']);sr=[]
for i in (41,83):
 (C/'layout.ld').write_text('ENTRY(_start)\nSECTIONS { . = 0x400000; .text : { *(.text) } external_value = '+str(i)+'; }\n');z=cmd([W,'-T','layout.ld','script-start.o','-o','script-elf'],False);row={'link_exit':z.returncode,'script_sha':sha(C/'layout.ld'),'diagnostics':z.stderr.decode(errors='replace')[:270]};
 if z.returncode==0:row['result']=subprocess.run([C/'script-elf']).returncode; row['ELF_sha256']=sha(C/'script-elf');assert row['result']==i
 sr.append(row)
(C/'results.json').write_text(json.dumps({'stock_wild':sha(W),'GCC_LTO':res,'linker_script':sr},indent=2)+'\n');print(json.dumps({'LTO plugin opened':res['plugin_open_count'],'LTO exit':res['link_exit'],'script actuals':[x.get('result') for x in sr]}))
