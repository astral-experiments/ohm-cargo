#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include "blake3.h"
/* Diagnostic only, ordered SHA-sized BLAKE3 inputs. Capture evidence while rustc owns temporary files. */
int main(int argc,char **argv) { char *p=0;size_t n=0;unsigned char *buf=malloc(262144);if (!buf) return 1;
 while(getdelim(&p,&n,0,stdin)>0) {int fd=open(p,O_RDONLY|O_CLOEXEC|O_NONBLOCK|O_NOCTTY);struct stat s,t;if(fd<0 || fstat(fd,&s) || !S_ISREG(s.st_mode)) return 2;
 blake3_hasher h;blake3_hasher_init(&h);ssize_t nr;while((nr=read(fd,buf,262144))>0)blake3_hasher_update(&h,buf,nr);if(nr<0||fstat(fd,&t)||s.st_ctim.tv_sec!=t.st_ctim.tv_sec||s.st_ctim.tv_nsec!=t.st_ctim.tv_nsec||s.st_size!=t.st_size)return 3;close(fd);unsigned char digest[32];blake3_hasher_finalize(&h,digest,32);for(int i=0;i<32;i++)printf("%02x",digest[i]);printf(" %ld %s\n",(long)s.st_size,p);}
 return 0;}
