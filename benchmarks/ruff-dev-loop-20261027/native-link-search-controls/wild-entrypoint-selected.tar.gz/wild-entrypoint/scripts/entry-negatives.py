"""Observe real GCC expansion and defeat stat-only signatures with a real ELF archive and a shared mapping."""
import os,pathlib,shutil,hashlib,json,mmap,subprocess,sys,stat
D=pathlib.Path(__file__).resolve().parent;C=D/'entry-controls';C.mkdir(exist_ok=False);P=D.parent/'unused-link-audit-20261027/compact-native-proof';W=pathlib.Path(json.loads((P/'toolchains.json').read_bytes())['published-1.99.0-14']['physical']['lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd']['real_path']);sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert sha(W)=='0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'
for name in ('prefix','late','early','other','fn41','fn83'): (C/name).mkdir()
for name in ('start.s','fn-41.s','fn-83.s'):shutil.copyfile(P/'resolver-fixture'/name,C/name)
env=dict(PATH='/usr/bin:/bin',LC_ALL='C');call=lambda args:subprocess.run(args,env=env,cwd=C,capture_output=True,check=True)
call(['as','-o','start.o','start.s'])
for val in (41,83):
 call(['as','-o',f'fn{val}/fn.o',f'fn-{val}.s']);call(['ar','crs',f'fn{val}/libauditffi.a',f'fn{val}/fn.o'])
first=C/'fn41/libauditffi.a';second=C/'fn83/libauditffi.a';raw=[p.read_bytes() for p in (first,second)];assert len(raw[0])==len(raw[1]);diff=[i for i,(a,b) in enumerate(zip(*raw)) if a!=b];assert len(diff)==1,diff;i,=diff
archive=C/'late/libauditffi.a';shutil.copyfile(first,archive);shutil.copyfile(second,C/'other/libauditffi.a');(C/'prefix/ld.bfd').write_text('#!/usr/bin/python3\nimport os,sys,json,pathlib\nD=pathlib.Path(__file__).resolve().parent.parent\n(D/"entry.json").write_text(json.dumps(sys.argv[1:]))\nos.execv('+repr(str(W))+',[str('+repr(str(W))+'),*sys.argv[1:]])\n');(C/'prefix/ld.bfd').chmod(0o755)
command=['/usr/bin/gcc','-B'+str(C/'prefix')+'/','-fuse-ld=bfd','-nostdlib','-nostartfiles','-nodefaultlibs','-static','-no-pie','-Wl,--build-id=sha1','-o',str(C/'out'),str(C/'start.o'),'-L'+str(C/'early'),'-L'+str(C/'late'),'-lauditffi'];
def st(p):s=p.stat();return {n:getattr(s,n) for n in ('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
def run(name,expected):
 call(command);actual=subprocess.run([C/'out'],cwd=C).returncode;assert actual==expected; a=json.loads((C/'entry.json').read_bytes()); assert any(v.startswith('-plugin-opt=-fresolution=') for v in a)
 normalized=[v if not v.startswith('-plugin-opt=-fresolution=') else '-plugin-opt=-fresolution=<GCC temp>' for v in a]
 return dict(phase=name,value=actual,ELF_sha256=sha(C/'out'),ordered_args_sha256=hashlib.sha256(b'\0'.join(x.encode() for x in normalized)).hexdigest(),search_order=[v for v in normalized if v.startswith('-L')],selected_archive_sha256=sha(archive))
rows=[];rows.append(run('before',41));shutil.copyfile(second,C/'early/libauditffi.a');rows.append(run('earlier previously missing libauditffi.a',83));assert rows[0]['ordered_args_sha256']==rows[-1]['ordered_args_sha256'];(C/'early/libauditffi.a').unlink()
(C/'prefix/specs').write_text('*link:\n-L'+str(C/'other')+'\n\n');rows.append(run('added GCC specs',83));assert rows[0]['ordered_args_sha256']!=rows[-1]['ordered_args_sha256'];(C/'prefix/specs').unlink();rows.append(run('removed GCC specs',41));assert rows[0]['ordered_args_sha256']==rows[-1]['ordered_args_sha256']
with archive.open('r+b') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_WRITE) as mm:
 mm[i]=raw[0][i];stats_before=st(archive); hash_before=sha(archive);rows.append(run('primed dirty HASH with original value',41));mm[i]=raw[1][i];stats_after=st(archive); hash_after=sha(archive);rows.append(run('mmap write after prior receipt',83));assert stats_before==stats_after and hash_before!=hash_after,(stats_before,stats_after)
# A distinct named ELF candidate is authentically different even when its size and old mtime are restored.
exe=C/'out';oldst=st(exe);oldhash=sha(exe);real=exe.read_bytes(); offset=len(real)-1
with exe.open('r+b') as f:f.seek(offset);f.write(bytes([real[offset]^1]));
os.utime(exe,ns=(exe.stat().st_atime_ns,oldst['st_mtime_ns']));newst=st(exe);newhash=sha(exe);assert oldst['st_size']==newst['st_size'] and oldst['st_mtime_ns']==newst['st_mtime_ns'] and oldhash!=newhash;rows.append(run('after corrupt output, stock repairs it',83));assert rows[-1]['ELF_sha256']==oldhash
q=dict(linker=sha(W),gcc=sha(pathlib.Path('/usr/bin/gcc')),rows=rows,mmap_control={'archive_bytes':stats_before['st_size'],'changed_byte_offset':i,'old_sha256':hash_before,'new_sha256':hash_after,'per_file_stat_equal':stats_before==stats_after,'equal_fields':list(stats_before)},backdated_output={'same_size_mtime':True,'old_sha256':oldhash,'interfered_sha256':newhash,'stock_fixed':True});(D/'entry-negatives.json').write_text(json.dumps(q,indent=2)+'\n');print([(r['phase'],r['value']) for r in rows]);print('mmap fingerprint equality',stats_before==stats_after)
