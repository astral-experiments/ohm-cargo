"""Public selected fields from historical traces and private stock GNU/ELF replays."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,tarfile,statistics,re
D=Path(__file__).resolve().parent;H=Path.home()/'.cache/ohm-ruff-whole-skips-20261027/position-integrated';f=H/'ruff-doc-four-wild-argv.private.json';sumfile=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest(); load=lambda p:json.loads(p.read_bytes()); js=load(f); phase=['candidate-verify-edit','candidate-verify-final-edit'];assert sorted(js)==phase; P=H/'native-qualified-results/doc-test.tar.gz';controls={};registered={};
with tarfile.open(P) as tf:
 for p in phase:
  members=json.load(tf.extractfile(f'pairs-posobs4fmt-c3-doc-test/{p}/physical-execs.json'))
  registered[p]={(e[0],e[1]) for e in members if e[2]=='wild'}
 for arm in ('candidate','parent'):
  q={}
  for p in ('before','verify-edit','verify-final-edit','final-fresh'):
   files=json.load(tf.extractfile(f'pairs-posobs4fmt-c3-doc-test/{arm}-{p}/sections.json'))
   q[p]={Path(k).name:v for k,v in files.items() if k.startswith('ruff/') and any(Path(k).name==r['target'] for r in js[phase[0]])}
  controls[arm]={}
  for p in q:
   controls[arm][p]={};
   for k,x in q[p].items():
    prev=q['before'][k];fields={section:sorted(f for f in x['sections'][section] if x['sections'][section][f]!=prev['sections'][section][f]) for section in x['sections'] if x['sections'][section]!=prev['sections'][section]};controls[arm][p][k]={'ELF_sha256':x['raw_sha256'],'changed_section_fields_vs_before':fields}
def typ(x):
 if x.startswith('-plugin-opt=-fresolution=/tmp/'): return 'GCC resolution file'
 if re.search(r'/rustc[A-Za-z0-9]{6}/raw-dylibs$',x):return 'Rust raw-dylibs search directory'
 if re.search(r'/rustc[A-Za-z0-9]{6}/symbols\.o$',x):return 'Rust symbols.o'
 return 'other'
rows={}
for p,vals in js.items():
 for row in vals:
  a=ast.literal_eval(row['argv_strace']);assert all(isinstance(v,str) for v in a);k=row['target'];kind=row['kind'];e=rows.setdefault(k,{}).setdefault(kind,{'phases':{}});e['phases'][p]={'native_args':a,'trace_file_sha256':row['trace_file_sha256'],'trace_line_sha256':row['line_sha256']};
  if kind=='Wild':assert (row['trace_file'],row['line_sha256']) in registered[p]
for k,v in rows.items():
 for kind,item in v.items():
  p=[item['phases'][x].pop('native_args') for x in phase];a,b=p;assert len(a)==len(b); item.update(argc=len(a),**{'differences':[{'index':i,'argument_class':typ(x)} for i,(x,y) in enumerate(zip(a,b)) if x!=y],'exact_all_equal':a==b});assert all(typ(x)==typ(y) for x,y in zip(a,b) if x!=y)
  if kind=='Wild':
   item['positive_files']={'explicit_rlibs':sum(arg.endswith('.rlib') for arg in a),'explicit_objects':sum(arg.endswith('.o') for arg in a),'linter_in_argv':any('libruff_linter-' in arg for arg in a),'build_id':next(x for x in a if x.startswith('--build-id')),'named_libraries':[x[2:] for x in a if x.startswith('-l')],'static_and_dynamic_order':[x for x in a if x in ('-Bstatic','-Bdynamic')],'search_directories':sum(x.startswith('-L') for x in a),'has_plugin':any(x=='-plugin' for x in a),'response_files':sum(x.startswith('@') for x in a)}
local={}
for n in ('config','direxist_guard','resolve_files','analyze_graph'):
 p=D/n;cap=load(p/'capture/real-link.json'); ds=load(p/'capture/digests.json');ob=load(p/'capture/observations.json');reps=[load(p/f'repeat{i}/real-link.json') for i in (1,2,3)];assert all(r['normalized_args_sha']==cap['normalized_args_sha'] and r['symbols_sha256']==cap['symbols_sha256'] and all(Path(d[0]).name.startswith(n+'-') and not Path(d[0]).suffix and d[1:]==['present','ENOENT'] for d in r['negative_delta']) and r['sha']==cap['sha'] and not r['resolution_accessed'] for r in reps)
 assert all(load(p/f'repeat{i}/digests.json')==ds for i in (1,2,3))
 sys=[{'op':o,'errno':e,'count':n} for (o,e),n in sorted(Counter((x['op'],x['errno'] or 'success') for x in ob).items())];sy=[k for k in ds if Path(k).is_symlink()];cs=[x for x in ob if x['op']=='openat' and x['errno']==None and Path(x['path']).name in ('libgcc_s.so','libm.so','libc.so')];rawabs=[x for x in ob if '$raw-dylibs' in x['path']];
 local[n]={'declarations_qualified':False,'replay':'Existing physical Ruff test rlink and retained objects; common release-14 compiler, GNU GCC and packaged release-14 Wild. Private two-core read-only mount, same linker arguments/inputs repeated; no historical Ruff source edit applied.','capture_positive_total':cap['input_count'],'input_and_output_bytes_hashed':cap['hashed_bytes'],'prior_missing_input_or_startup_paths':cap['negative_paths']-len(cap['negative_delta']),'every_prior_missing_input_still_absent':True,'initially_absent_output_distinguished':bool(cap['negative_delta']),'all_observation_counts':sys,'known_linker_scripts_observed_open':sorted(set(Path(x['path']).name for x in cs)),'raw_dylibs_queried_failures':sum(bool(x['errno']) for x in rawabs),'raw_dylibs_queried_successes':sum(not x['errno'] for x in rawabs),'gcc_resolution_used':cap['resolution_accessed'],'direct_symlinks_in_positive_paths':len(sy),'active_plugin_dso_open':any('liblto_plugin' in x['path'] and x['op']=='openat' and not x['errno'] for x in ob),'symbols.o_SHA256':cap['symbols_sha256'],'normalized_argv_SHA256':cap['normalized_args_sha'],'retained_ELF_SHA256':cap['sha'],'untraced_real_wild_ns':[r['ns'] for r in reps],'complete_two_worker_BLAKE3_ns':[r['blake3_ns']['2'] for r in reps],'complete_single_worker_BLAKE3_ns':[r['blake3_ns']['1'] for r in reps],'failed_lookup_lstat_ns':[r['negative_ns'] for r in reps],'BLAKE3_includes_output_and_wild_binary':True,'fingerprints_all_equal_for_four_repetitions':True,'raw_local_hash_inventory_sha256':sumfile(p/'capture/digests.json')}
pack={'historical_source':'36029f1c9a48 reversed at 93526150df','H2_private_argv_sha256':sumfile(f),'H2_public_companion_archive_sha256':sumfile(P),'actual_H2_post_driver_argv':rows,'actual_H2_complete_ELF_and_section_changes':controls,'local_frozen_physical_replays':local};(D/'selected.json').write_text(json.dumps(pack,indent=2)+'\n')
for k,v in rows.items():print(k,'wild',v['Wild']['argc'],v['Wild']['differences'],v['Wild']['positive_files'])
for k,v in local.items(): print(k,'bytes',v['input_and_output_bytes_hashed'],'neg',v['prior_missing_input_or_startup_paths'],'source/files',v['capture_positive_total'],'median link/hash2/hash1',*(round(statistics.median(v[field])/1e6) for field in ('untraced_real_wild_ns','complete_two_worker_BLAKE3_ns','complete_single_worker_BLAKE3_ns')))
