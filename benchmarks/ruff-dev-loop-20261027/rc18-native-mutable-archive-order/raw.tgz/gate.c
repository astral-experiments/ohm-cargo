#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>
#include <linux/ptrace.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>
/* QA only. Accept triggers only from the actual stock ELF inode. Never inject data or syscalls. */
static int get_name(pid_t pid, unsigned long long addr, char buf[4096]) {
    struct iovec local={buf,4095}, remote={(void*)(uintptr_t)addr,4095};
    ssize_t n=process_vm_readv(pid,&local,1,&remote,1,0);
    return n>0 && memchr(buf,0,n)!=NULL;
}
int main(int argc,char **argv) {
    if(argc<10 || strcmp(argv[8],"--"))return 86;
    const char *trigger=argv[2], *native_parent=argv[3], *ready=argv[4], *ack=argv[5];
    struct stat gold; if(stat(argv[1],&gold))return 87;
    FILE *log=fopen(argv[6],"wx"); if(!log)return 88;setvbuf(log,NULL,_IOLBF,0);
    pid_t first=fork();if(first<0)return 89;
    if(!first){fclose(log);if(ptrace(PTRACE_TRACEME,0,0,0))_exit(90);raise(SIGSTOP);execv(argv[9],argv+9);_exit(91);}
    int st,rc=1,triggered=0;if(waitpid(first,&st,0)!=first || !WIFSTOPPED(st))return 92;
    long opts=PTRACE_O_TRACESYSGOOD|PTRACE_O_TRACECLONE|PTRACE_O_TRACEFORK|PTRACE_O_TRACEVFORK|PTRACE_O_TRACEEXEC|PTRACE_O_EXITKILL;
    if(ptrace(PTRACE_SETOPTIONS,first,0,opts)||ptrace(PTRACE_SYSCALL,first,0,0))return 93;
    for(;;){
        pid_t p=waitpid(-1,&st,__WALL);if(p<0){if(errno==EINTR)continue;if(errno==ECHILD)break;return 94;}
        if(WIFEXITED(st)||WIFSIGNALED(st)){if(p==first)rc=WIFEXITED(st)?WEXITSTATUS(st):128+WTERMSIG(st);continue;}
        int sig=WSTOPSIG(st);unsigned event=(unsigned)st>>16;
        if(event==PTRACE_EVENT_EXEC) {
            char proc[96],exe[4096];snprintf(proc,sizeof(proc),"/proc/%d/exe",p);
            ssize_t n=readlink(proc,exe,sizeof(exe)-1);if(n>0){exe[n]=0;fprintf(log,"exec\t%d\t%s\n",p,exe);}
        }
        if(sig==(SIGTRAP|0x80)){
            struct ptrace_syscall_info info;
            if(ptrace(PTRACE_GET_SYSCALL_INFO,p,sizeof(info),&info)<0){
                if(errno==ESRCH){fprintf(log,"exited-before-inspection\t%d\n",p);continue;}
                perror("PTRACE_GET_SYSCALL_INFO");return 95;
            }
            const int kind=info.op==PTRACE_SYSCALL_INFO_ENTRY ? (int)info.entry.nr : -1;
            if(kind==SYS_openat || kind==SYS_statx || kind==SYS_mmap){
                char path[4096],proc[96];int named=0;
                if(kind==SYS_mmap){
                    snprintf(proc,sizeof(proc),"/proc/%d/fd/%d",p,(int)info.entry.args[4]);
                    ssize_t n=readlink(proc,path,sizeof(path)-1);if(n>0){path[n]=0;named=1;}
                }else named=get_name(p,info.entry.args[1],path);
                int scoped=named && (!strncmp(path,native_parent,strlen(native_parent)) || !strcmp(path,argv[7]));
                if(scoped){
                    snprintf(proc,sizeof(proc),"/proc/%d/exe",p);struct stat current;
                    if(!stat(proc,&current)&&current.st_dev==gold.st_dev&&current.st_ino==gold.st_ino){
                        const char *op=kind==SYS_mmap?"mmap":kind==SYS_statx?"statx":"openat";
                        fprintf(log,"native\t%d\t%s\t%llu\t%llu\t%s\n",p,op,(unsigned long long)current.st_dev,(unsigned long long)current.st_ino,path);
                        if(!triggered && kind==SYS_openat && !strcmp(path,trigger)){
                            fprintf(log,"barrier\t%s\t%s\n",op,path);
                            int w=open(ready,O_WRONLY|O_CLOEXEC),r=open(ack,O_RDONLY|O_CLOEXEC);char c='K';
                            if(w<0||r<0||write(w,&c,1)!=1||read(r,&c,1)!=1||c!='A')return 96;
                            close(w);close(r);triggered=1;fprintf(log,"resumed\n");
                        }
                    }
                }
            }
        }
        if(sig==(SIGTRAP|0x80)||event||sig==SIGSTOP||sig==SIGTRAP)sig=0;
        if(ptrace(PTRACE_SYSCALL,p,0,sig)<0&&errno!=ESRCH)return 97;
    }
    fprintf(log,"exit\t%d\t%d\n",rc,triggered);fclose(log);return triggered?rc:98;
}
