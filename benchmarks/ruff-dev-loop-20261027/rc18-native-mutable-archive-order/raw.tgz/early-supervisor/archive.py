"""Real call from Rust through a relocatable ELF undefined symbol to one ordinary archive member."""
import ctypes as C,fcntl,hashlib,json,mmap,os,select,shutil,signal,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;original=Path(sys.argv[1]).resolve();case=root/"case";native=case/"native";logical_src=case/"workspace"
case.mkdir();native.mkdir();(logical_src/"src").mkdir(parents=True);os.umask(0o002)
sha=lambda b:hashlib.sha256(b).hexdigest()
def doc(path,data):path.write_text(json.dumps(data,sort_keys=True,indent=2)+"\n")
def stamp(p):
    s=p.stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
for f in ("Cargo.toml","Cargo.lock","src/main.rs"):shutil.copyfile(original/"case/workspace"/f,logical_src/f)
router=native/"z-dispatch.o";library=native/"a-branches.a"
(logical_src/"build.rs").write_text('fn main() {\n'+''.join('println!("cargo:rustc-link-arg='+str(p)+'");\n'for p in (router,library))+'}\n')
def obj(filename,body):
    src=native/(filename+".S");out=native/(filename+".o")
    src.write_text(".text\n"+body+'\n.section .note.GNU-stack,"",@progbits\n')
    subprocess.run(["cc","-c",src,"-o",out],check=True)
def fun(name,code):return f".globl {name}\n.type {name},@function\n{name}:\n {code}\n.size {name},.-{name}"
obj("z-dispatch",fun("native_value","jmp branch0@PLT"))
obj("branch-zero",fun("branch0","mov $41,%eax\n ret"))
obj("branch-one",fun("branch1","mov $97,%eax\n ret"))
subprocess.run(["ar","rcsD",library,native/"branch-zero.o",native/"branch-one.o"],check=True)
a0=router.read_bytes();needle=b"branch0\x00";assert a0.count(needle)==1;ia=a0.index(needle)+6;a1=a0[:ia]+b"1"+a0[ia+1:]
b0=library.read_bytes();needle=bytes.fromhex("b829000000c3");assert b0.count(needle)==1;ib=b0.index(needle)+1;b1=b0[:ib]+bytes([83])+b0[ib+1:]
for name,b in (("A0",a0),("A1",a1),("B0",b0),("B1",b1)):(root/(name+".input")).write_bytes(b)
base=Path("/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027");lower=base/"frozen-toolchain";sdk=case/"sdk";sdk.mkdir();ru=case/"rustup";(ru/"toolchains").mkdir(parents=True);(ru/"toolchains/ohm").symlink_to(sdk)
drv=base/"mixed-module-children-17-v1-20261028/tool-rc18-export-r2/candidate-driver.so";cargo=Path("/mnt/devbox-scratch/dev-user/ohm-rc18-pgo-qualification-20261028/cargo");stock=lower/"lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd";so=next((lower/"lib").glob("librustc_driver-*.so")).name
prior=json.loads((original/"native-states.json").read_bytes())["A0B0"];assert sha(stock.read_bytes())==prior["wild"] and sha(drv.read_bytes())==prior["rustc_driver"]
env={k:v for k,v in os.environ.items() if not k.startswith(("CARGO_","WILD_","OHM_QA")) and k not in ("RUSTFLAGS","RUSTC","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","LD_PRELOAD","LD_AUDIT")}
env.update(RUSTUP_HOME=str(ru),RUSTUP_AUTO_INSTALL="0",PATH=str(Path.home()/".cargo/bin")+":"+os.environ["PATH"],CARGO_HOME=str(case/"cargo-home"),CARGO_TARGET_DIR=str(case/"target"),CARGO_BUILD_BUILD_DIR=str(case/"shared"),CARGO_NET_OFFLINE="true")
cmd=prior["cargo"];gate=root/"gate";subprocess.run(["cc","-std=gnu11","-O2","-Wall","-Wextra","-Werror",root/"gate.c","-o",gate],check=True)
facts={};states={};true_out=None
for name,av,bv,want in [("A0B0",0,0,41),("A1B0",1,0,97),("A1B1",1,1,97),("A0B1",0,1,83),("before-router",1,0,83),("after-selection",1,0,None),("archive-late",0,0,83)]:
    router.write_bytes((a0,a1)[av]);library.write_bytes((b0,b1)[bv]);r=root/name;r.mkdir()
    ns=["bwrap","--ro-bind","/","/","--dev","/dev","--proc","/proc","--bind",str(case),str(case),"--bind",str(r),str(r),"--tmpfs","/tmp","--ro-bind",str(lower),str(sdk),"--ro-bind",str(drv),str(sdk/"lib"/so),"--ro-bind",str(cargo),str(sdk/"bin/cargo"),"--chdir",str(logical_src),"--"]
    log=r/"trace";events=[]
    if name[0]=="A":
        worker=ns+["strace","-f","-qq","-s","65535","-e","trace=execve,openat,mmap,statx","-o",str(log),"--",*cmd]
        out=subprocess.run(worker,env=env,capture_output=True,timeout=60)
        (r/"stdout").write_bytes(out.stdout);(r/"stderr").write_bytes(out.stderr);status=out.returncode
    else:
        mm=[]
        for path in (router,library):
            fd=os.open(path,os.O_RDWR);mm.append(mmap.mmap(fd,0,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE));os.close(fd)
        ma,mb=mm;ma[ia]=a1[ia] if av else a0[ia];mb[ib]=b0[ib]
        for n in ("ready","ack"):os.mkfifo(r/n)
        rd,wr=[os.open(r/n,os.O_RDWR|os.O_NONBLOCK|os.O_CLOEXEC)for n in("ready","ack")]
        trigger=str(router) if name=="before-router" else true_out;assert true_out
        worker=ns+[str(gate),str(stock),trigger,str(native)+"/",str(r/"ready"),str(r/"ack"),str(log),true_out,"--",*cmd]
        with (r/"stdout").open("wb")as o,(r/"stderr").open("wb")as e:
            proc=subprocess.Popen(worker,env=env,stdout=o,stderr=e,start_new_session=True)
            try:
                assert select.select([rd],[],[],35)[0] and os.read(rd,1)==b"K",(name,proc.poll(),(r/"stderr").read_bytes()[-1200:])
                ev=lambda:[ma[ia],mb[ib],stamp(router),stamp(library)]
                events.append(ev());mb[ib]=b1[ib];events.append(ev())
                if av:ma[ia]=a0[ia];events.append(ev())
                assert all(ev[2:]==events[0][2:]for ev in events)
                assert os.write(wr,b"A")==1;status=proc.wait(timeout=35)
            finally:
                for m in mm:m.close()
                os.close(rd);os.close(wr)
                if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    assert status==0,(name,status,(r/"stderr").read_bytes()[-1200:])
    rows=[x for x in map(json.loads,(r/"stdout").read_bytes().splitlines())if x.get("executable") and x["target"]["name"]=="native-router"];actual=Path(rows[0]["executable"])
    res=subprocess.run([actual],capture_output=True,timeout=3);value=int(res.stdout);assert res.returncode==0 and not res.stderr and (want==value if want is not None else value in (83,97)),(name,value,res.stderr)
    nm=subprocess.run(["nm","-n",actual],check=True,capture_output=True).stdout.decode();syms=[l for l in nm.splitlines()if l.endswith((" native_value"," branch0"," branch1"))]
    assert len(syms)==2 and any(l.endswith(" native_value") for l in syms)
    assert any(l.endswith(" branch1" if value==97 else " branch0") for l in syms)
    elfsha=sha(actual.read_bytes())
    if name[0]=="A":
        lines=log.read_text().splitlines()
        wild=[(i,l) for i,l in enumerate(lines)if 'execve('in l and 'wild-ld/ld.bfd"'in l and l.endswith("= 0")]
        assert len(wild)==2
        chosenarg=wild[-1][1];assert str(router)in chosenarg and str(library)in chosenarg
        assert chosenarg.index(str(router))<chosenarg.index(str(library))
        new_out=next(l.split('"')[1]for l in lines if "O_CREAT|O_TRUNC"in l and '/out/native_router"'in l)
        if true_out:assert new_out==true_out
        true_out=new_out
        nr=[(i,sha(l.encode()),l) for i,l in enumerate(lines)if i>wild[-1][0] and "openat("in l and any('"'+str(v)+'"'in l for v in(router,library))and "= "in l]
        assert nr and any(str(router)in l for _,_,l in nr) and any(str(library)in l for _,_,l in nr)
        states[name]={"runtime":value,"sha256":elfsha,"wild":prior["wild"],"rustc_driver":prior["rustc_driver"],"cargo":cmd,"native_open_lines":nr}
        if name=="A0B0":shutil.copyfile(actual,case/"gold");(case/"gold").chmod(0o775)
    else:
        assert elfsha in {v["sha256"] for v in states.values()},(name,elfsha,value)
    facts[name]={"value":value,"status":status,"elf_sha256":elfsha,"symbols":syms,"events":events,"trace_sha256":sha(log.read_bytes()),"actual_program":res.stdout.decode()}
    doc(r/"receipt.json",facts[name]);print(name,value,syms,flush=True)
    for d in ("target","shared"):(case/d).rename(r/d)
doc(root/"native-states.json",states)
# Run the *unchanged receiving binary* and use the previous kernel pread barrier. The experiment driver supplies the two new ELF inputs.
shutil.copyfile(original/"libguard2.so",root/"libguard2.so")
script=(original/"opposite-order.py").read_text()
pre=script[:script.index("for dest,value in zip(payload,(41,83,97)):")].replace('work.mkdir()','work.mkdir(exist_ok=True)').replace('native.mkdir()','native.mkdir(exist_ok=True)')
mappings='''
router=native/"z-dispatch.o";old_body=native/"a-branches.a";image=work/"gold"
a0,a1,b0,b1=[(root/(n+".input")).read_bytes()for n in ("A0","A1","B0","B1")]
ia=next(i for i in range(len(a0)) if a0[i]!=a1[i]);ib=next(i for i in range(len(b0))if b0[i]!=b1[i])
refs=json.loads((root/"native-states.json").read_bytes())
'''
suffix=script[script.index("router.write_bytes(a0);old_body.write_bytes(b0)\n# The unchanging inputs"):]
suffix=suffix.replace('paths=sorted([router,old_body,*payload,alternate,image])','paths=sorted([router,old_body,image])')
suffix=suffix.replace('[a0.decode(),a1.decode(),b0.decode(),b1.decode()]','[hashlib.sha256(x).hexdigest() for x in (a0,a1,b0,b1)]')
(root/"checker-barrier.py").write_text(pre+mappings+suffix)
cp=subprocess.run(["python3",str(root/"checker-barrier.py")],capture_output=True,timeout=15)
(root/"checker.stdout").write_bytes(cp.stdout);(root/"checker.stderr").write_bytes(cp.stderr);assert cp.returncode==0,cp.stderr
imp=json.loads((root/"impossible-hit.json").read_bytes());assert imp["batch_claim"]["files"]==3 and imp["batch_claim"]["status"]==0 and imp["stable_end_recheck"]["status"]==11
doc(root/"complete.json",{"native":facts,"receiver_body":sha((root/"libguard2.so").read_bytes()),"checker_claim":imp["batch_claim"],"next_status":imp["stable_end_recheck"]["status"],"A_raw_changed_offset":ia,"B_raw_changed_offset":ib,"A_sizes":[len(a0),len(a1)],"B_sizes":[len(b0),len(b1)],"ordinary_native_inputs":[{"name":p.name,"file":subprocess.run(["file","-b",p],check=True,capture_output=True).stdout.decode().strip()} for p in (router,library)],"actual_flags":cmd,"true_stock":prior["wild"]});print("runtime values",[facts[n]["value"]for n in facts],"; native validator reported",imp["batch_claim"],flush=True)
