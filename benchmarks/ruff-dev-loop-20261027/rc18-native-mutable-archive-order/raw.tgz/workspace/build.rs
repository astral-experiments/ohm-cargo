fn main() {
println!("cargo:rustc-link-arg=/mnt/devbox-scratch/dev-user/ohm-rust-native-fresh-handoff-r2-20261028/opposed-direct-archive-v2/case/native/z-dispatch.o");
println!("cargo:rustc-link-arg=/mnt/devbox-scratch/dev-user/ohm-rust-native-fresh-handoff-r2-20261028/opposed-direct-archive-v2/case/native/a-branches.a");
}
