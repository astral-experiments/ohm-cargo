"""Bounded native reader-order counterexample, using the exact generic batch validator and stock Wild."""
import ctypes as C
import errno
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys

root=Path(__file__).resolve().parent
work=root/"case";work.mkdir(exist_ok=True);os.umask(0o002)
native=work/"native";native.mkdir(exist_ok=True)
router=native/"z-router.so"; old_body=native/"a0.so";alternate=native/"a1.so"
payload=[native/f"value-{i}.o" for i in range(3)]
lib=C.CDLL(str(root/"libguard2.so"),use_errno=True)
K=C.CDLL(None,use_errno=True);K.ptrace.restype=C.c_long
class Item(C.Structure):
    _fields_=[("name",C.c_char_p),("resolved",C.c_char_p),("digest",C.c_char_p),("size",C.c_uint64),("flags",C.c_uint)]
class Stats(C.Structure):_fields_=[(s,C.c_uint64) for s in ("bytes","files","names","missing")]
class Regs(C.Structure):
    _fields_=[(s,C.c_ulonglong) for s in "r15 r14 r13 r12 rbp rbx r11 r10 r9 r8 rax rcx rdx rsi rdi orig_rax rip cs eflags rsp ss fs_base gs_base ds es fs gs".split()]
lib.link_check_fd.argtypes=[C.c_int,C.c_void_p,C.POINTER(C.c_uint64)]
lib.check_named.argtypes=[C.c_int,C.POINTER(Item),C.c_uint,C.c_uint,C.POINTER(Stats),C.POINTER(C.c_uint)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,doc):p.write_text(json.dumps(doc,sort_keys=True,indent=2)+"\n")
def b3(p):
    fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC);val=C.create_string_buffer(32);n=C.c_uint64()
    try:assert lib.link_check_fd(fd,val,C.byref(n))==0 and n.value==p.stat().st_size
    finally:os.close(fd)
    return val.raw
def stamp(p):
    s=p.stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]

router=native/"z-dispatch.o";old_body=native/"a-branches.a";image=work/"gold"
a0,a1,b0,b1=[(root/(n+".input")).read_bytes()for n in ("A0","A1","B0","B1")]
ia=next(i for i in range(len(a0)) if a0[i]!=a1[i]);ib=next(i for i in range(len(b0))if b0[i]!=b1[i])
refs=json.loads((root/"native-states.json").read_bytes())
router.write_bytes(a0);old_body.write_bytes(b0)
# The unchanging inputs can be added anywhere. The recipe rows use exactly the name order of emit2.py.
paths=sorted([router,old_body,image])
wire=[(os.fsencode(p),os.fsencode(p),b3(p),p.stat().st_size,4 if p==image else 0) for p in paths]
table=(Item*len(wire))(*(Item(*q) for q in wire))
def verify():
    rootfd=os.open("/",os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    output=Stats();bad=C.c_uint()
    try:status=lib.check_named(rootfd,table,len(table),1,C.byref(output),C.byref(bad))
    finally:os.close(rootfd)
    return {"status":status,"bad":bad.value if status else None,"files":output.files,"bytes":output.bytes}
assert verify()["status"]==0
fd=[os.open(p,os.O_RDWR)for p in (router,old_body)]
am,bm=(mmap.mmap(f,0,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE)for f in fd)
def pstat():return {"A":stamp(router),"B":stamp(old_body)}
def state():return [am[ia],bm[ib]]
am[ia],bm[ib]=a1[ia],b0[ib]
primed=pstat()
assert verify()["status"]!=0
def ptrace(req,pid,data=None):
    ret=K.ptrace(C.c_ulong(req),C.c_ulong(pid),None,data)
    if ret==-1:raise OSError(C.get_errno(),os.strerror(C.get_errno()))
left,right=os.pipe();pid=os.fork()
if pid==0:
    os.close(left);ptrace(0,0);os.kill(os.getpid(),signal.SIGSTOP)
    ans=verify();os.write(right,json.dumps(ans).encode());os._exit(0)
os.close(right);st=os.waitpid(pid,0)[1];assert os.WIFSTOPPED(st)
ptrace(0x4200,pid,C.c_void_p(1));enter=True;changed=False;events=[];order=[]
while True:
    ptrace(24,pid);st=os.waitpid(pid,0)[1]
    if os.WIFEXITED(st):assert os.WEXITSTATUS(st)==0;break
    assert os.WIFSTOPPED(st) and os.WSTOPSIG(st)==(signal.SIGTRAP|128),st
    regs=Regs();ptrace(12,pid,C.byref(regs))
    if enter and regs.orig_rax==17: # Linux x86_64 pread64 entry.
        try:where=os.readlink(f"/proc/{pid}/fd/{regs.rdi}")
        except OSError:where=None
        if where in (str(old_body),str(router)):
            order.append((Path(where).name,regs.r10))
        if not changed and where==str(router):
            assert any(path==old_body.name and off>0 for path,off in order)
            events.append(("A1B0",state(),pstat()));bm[ib]=b1[ib];events.append(("A1B1",state(),pstat()))
            am[ia]=a0[ia];events.append(("A0B1",state(),pstat()));changed=True
    enter=not enter
claim=json.loads(os.read(left,4096));os.close(left)
assert changed and claim["status"]==0,(order,claim,events)
assert all(e[2]==primed for e in events) and pstat()==primed,(primed,events,pstat())
assert [q[1] for q in events]==[[a1[ia],b0[ib]],[a1[ia],b1[ib]],[a0[ia],b1[ib]]]
late=verify();assert late["status"]!=0
save(root/"impossible-hit.json",{"original":refs["A0B0"],"reachable_states":[{"name":e[0],"visible_value":refs[e[0]]["runtime"]}for e in events],
     "fd_reads":order,"observer_edges":events,"held_before":primed,"held_after":pstat(),"batch_claim":claim,"stable_end_recheck":late,
     "checked_image_sha256":sha(image),"actual_lib":sha(root/"libguard2.so"),"rows":[{"name":p[0].decode(),"blake3":p[2].hex(),"bytes":p[3],"flags":p[4]}for p in wire],
     "input_paths":{"router":str(router),"body":str(old_body)},"script_toggles":[hashlib.sha256(x).hexdigest() for x in (a0,a1,b0,b1)]})
for x in (am,bm):x.close()
for n in fd:os.close(n)
print("actual Cargo values", [r["runtime"] for r in refs.values()],"accepted",claim,"next stable",late)
