set -euo pipefail
smoke_crate="$smoke_root/crate"
mkdir -p "$smoke_crate/src" "$smoke_crate/macros/src"
cat > "$smoke_crate/Cargo.toml" <<'EOF'
[package]
name = "ohm-smoke"
version = "0.0.0"
edition = "2024"

[dependencies]
ohm-smoke-macros = { path = "macros" }
EOF
cat > "$smoke_crate/macros/Cargo.toml" <<'EOF'
[package]
name = "ohm-smoke-macros"
version = "0.0.0"
edition = "2024"

[lib]
proc-macro = true
EOF
cat > "$smoke_crate/macros/src/lib.rs" <<'EOF'
use proc_macro::TokenStream;

#[proc_macro]
pub fn make_answer(_: TokenStream) -> TokenStream {
    "fn answer() -> u32 { 42 }".parse().unwrap()
}
EOF
cat > "$smoke_crate/src/main.rs" <<'EOF'
ohm_smoke_macros::make_answer!();

fn main() {
    assert!(invert(false));
    assert_eq!(answer(), 42);
}

fn invert(value: bool) -> bool {
    !value
}
EOF

    raw_tmpdir="$smoke_root/"$'tmp-\xff'
    mkdir "$raw_tmpdir"
    TMPDIR="$raw_tmpdir" CARGO_TARGET_DIR="$smoke_root/byte-path-target" \
      CARGO_BUILD_BUILD_DIR="$smoke_root/byte-path-build" \
      cargo +"$OHM_TOOLCHAIN" run --offline --manifest-path "$smoke_crate/Cargo.toml"
    readelf --string-dump=.comment "$smoke_root/byte-path-target/debug/ohm-smoke" \
      | grep -i 'Wild' >/dev/null
