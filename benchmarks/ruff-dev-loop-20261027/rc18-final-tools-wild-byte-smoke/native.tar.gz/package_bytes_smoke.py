"""Execute the actual package-script stanza and distinguish two native library generations."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out, package = map(Path, sys.argv[1:])
sdk = Path('/home/dev-user/.cache/ohm-rc18-r2-whole-ruff-20261028/sdk')
physical = Path('/home/dev-user/.cache/ohm-rc18-final-tools-ruff-20261028/sdk')
assert sdk.samefile(physical)
wild = sdk/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
sha = lambda p: hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert sha(wild) == '9de3bdd6675f02e08d687045383c097ab0ef6027c779f153a7823153ecf8445e'
assert sha(sdk/'bin/cargo') == 'cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8'
assert sha(sdk/'lib/librustc_driver-774a793a844d5500.so') == '22abce6921b46f93f387c7d3d99cefa4df9c0a866619447077699ef81a73827f'
assert not list(out.iterdir())
smoke = out/'smoke'
smoke.mkdir()
for n in ('home','cargo'):
    (out/n).mkdir()
env = dict(HOME=str(out/'home'),PATH='/home/dev-user/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
    USER=os.environ['USER'],CARGO_HOME=str(out/'cargo'),RUSTUP_HOME=str(sdk.parent/'rustup'),
    RUSTUP_AUTO_INSTALL='0',CARGO_NET_OFFLINE='true', LC_ALL='C.UTF-8',LANG='C.UTF-8',
    OHM_TOOLCHAIN='ohm',smoke_root=str(smoke))
source = package.read_bytes()
fixture = source[source.index(b'smoke_crate="$smoke_root/crate"'):source.index(b'rustc_wrapper="$smoke_root/rustc-wrapper"')]
begin = source.index(b'    raw_tmpdir="$smoke_root/"')
end = source.index(b"| grep -i 'Wild' >/dev/null", begin) + len(b"| grep -i 'Wild' >/dev/null")
stanza = source[begin:end]+b'\n'
assert b"$'tmp-\\xff'" in stanza and b'cargo +"$OHM_TOOLCHAIN" run --offline' in stanza
(out/'original-stanza.sh').write_bytes(stanza)
(out/'original-fixture.sh').write_bytes(fixture)
runner = out/'run-package-stanza.sh'
runner.write_bytes(b'set -euo pipefail\n'+fixture+stanza)


def run(name, args, case_env, binary):
    d = out/name
    d.mkdir()
    trace = d/'exec.trace'
    q = subprocess.run(['strace','-f','-qq','-s','131072','-e','trace=execve','-o',trace, *args], env=case_env,capture_output=True)
    (d/'stdout').write_bytes(q.stdout)
    (d/'stderr').write_bytes(q.stderr)
    (d/'exit').write_text(str(q.returncode)+'\n')
    assert q.returncode == 0, (name,q.returncode,q.stderr[-1800:])
    comment = subprocess.check_output(['readelf','--string-dump=.comment',binary])
    (d/'elf-comment').write_bytes(comment)
    assert b'Wild' in comment
    native = [l for l in trace.read_bytes().splitlines() if b'execve("'+os.fsencode(wild)+b'",' in l and l.rstrip().endswith(b'= 0')]
    assert native
    assert all(os.fsencode(wild) in l for l in native)
    (d/'wild-execs').write_bytes(b'\n'.join(native)+b'\n')
    return {'exit':q.returncode,'stdout_hex':q.stdout.hex(),'elf':sha(binary),'comment':sha(d/'elf-comment'),
        'trace':sha(trace),'wild_executions':len(native),'wild_sha256':sha(wild)}


cases = {'package-raw-tmpdir':run('package-raw-tmpdir',['bash',runner],env,smoke/'byte-path-target/debug/ohm-smoke')}
assert b'tmp-\xff' in os.listdir(os.fsencode(smoke)) and b'tmp-\xef\xbf\xbd' not in os.listdir(os.fsencode(smoke))
crate = out/'library'
(crate/'src').mkdir(parents=True)
(crate/'Cargo.toml').write_text('[package]\nname="ohm-byte-library"\nversion="0.0.0"\nedition="2024"\n')
(crate/'src/main.rs').write_text('#[link(name="ohm_byte_choice", kind="static")]\nunsafe extern "C" { fn ohm_byte_choice()->i32; }\nfn main(){ println!("{}", unsafe {ohm_byte_choice()}); }\n')
for component, value, label in [(b'lib-\xff',41,'raw'),(b'lib-\xef\xbf\xbd',99,'unicode-decoy')]:
    destination = os.fsencode(out)+b'/'+component
    os.mkdir(destination)
    obj = destination+b'/choice.o'
    subprocess.run([b'/usr/bin/gcc',b'-x',b'c',b'-c',b'-',b'-o',obj],input=f'int ohm_byte_choice(void){{return {value};}}'.encode(),check=True)
    subprocess.run([b'/usr/bin/ar',b'rcs',destination+b'/libohm_byte_choice.a',obj],check=True)
for component, value, label in [(b'lib-\xff',41,'raw'),(b'lib-\xef\xbf\xbd',99,'unicode-decoy')]:
    target = out/('lib-target-'+label)
    build = out/('lib-build-'+label)
    assert not target.exists() and not build.exists()
    case_env = dict(env,CARGO_TARGET_DIR=str(target),CARGO_BUILD_BUILD_DIR=str(build))
    case_env['LIBRARY_PATH'] = os.fsdecode(os.fsencode(out)+b'/'+component)
    path = target/'debug/ohm-byte-library'
    evidence = run('library-'+label,['cargo','+ohm','run','--offline','--manifest-path',str(crate/'Cargo.toml')],case_env,path)
    assert bytes.fromhex(evidence['stdout_hex']) == f'{value}\n'.encode()
    cases['library-'+label] = evidence | {'library_path_bytes':os.fsencode(case_env['LIBRARY_PATH']).hex()}
receipt = {'source_script_sha256':sha(package),'exact_fixture_sha256':sha(out/'original-fixture.sh'),
    'exact_stanza_sha256':sha(out/'original-stanza.sh'),'tmpdir_bytes':(os.fsencode(smoke)+b'/tmp-\xff').hex(),
    'cargo':sha(sdk/'bin/cargo'),'rust_driver':sha(sdk/'lib/librustc_driver-774a793a844d5500.so'),
    'wild':sha(wild),'gcc':sha(Path('/usr/bin/gcc')),'cases':cases,'compiler_flags':[]}
(out/'complete.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,sort_keys=True))
