    raw_tmpdir="$smoke_root/"$'tmp-\xff'
    mkdir "$raw_tmpdir"
    TMPDIR="$raw_tmpdir" CARGO_TARGET_DIR="$smoke_root/byte-path-target" \
      CARGO_BUILD_BUILD_DIR="$smoke_root/byte-path-build" \
      cargo +"$OHM_TOOLCHAIN" run --offline --manifest-path "$smoke_crate/Cargo.toml"
    readelf --string-dump=.comment "$smoke_root/byte-path-target/debug/ohm-smoke" \
      | grep -i 'Wild' >/dev/null
