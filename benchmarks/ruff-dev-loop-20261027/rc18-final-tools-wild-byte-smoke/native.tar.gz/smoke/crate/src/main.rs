ohm_smoke_macros::make_answer!();

fn main() {
    assert!(invert(false));
    assert_eq!(answer(), 42);
}

fn invert(value: bool) -> bool {
    !value
}
