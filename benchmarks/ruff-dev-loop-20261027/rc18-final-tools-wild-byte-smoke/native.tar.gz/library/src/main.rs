#[link(name="ohm_byte_choice", kind="static")]
unsafe extern "C" { fn ohm_byte_choice()->i32; }
fn main(){ println!("{}", unsafe {ohm_byte_choice()}); }
