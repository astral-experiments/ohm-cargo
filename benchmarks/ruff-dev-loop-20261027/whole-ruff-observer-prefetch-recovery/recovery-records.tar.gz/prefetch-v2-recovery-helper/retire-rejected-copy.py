"""Release the private recovery duplicate after retaining every changed byte and confirming the original inodes."""
import ctypes,fcntl,hashlib,json,mmap,os,shutil,subprocess,sys
from pathlib import Path
X=Path.home()/'.cache/ohm-233-position-qualified-20261027';h=X/'prefetch-fifo-qualified-v2';sys.path.insert(0,str(h));from common import P,PIN,RUFF,TARGET,git,sha,load,dump,need
primary=X/'whole-ruff-observer-prefetch-fifo-v2';sup=X/'prefetch-v2-missing-proof-supplement';clone=primary/'recovery-private-V';source=X/'cargo-observer-ruff-fifo-fixed/state/test/candidate';dst=sup/'clone-rejection.json';libc=ctypes.CDLL(None);libc.memcmp.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]
with (P/'native-measure.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);need(sha(dst)=='a1486a1f189f5cee993ce92b033da6ec65254381c76beaecdf83ff00ac84a230','unsealed rejection');data=load(dst);need(data['V_initial_elf_gold'] and data['C_not_run'] and data['elf_matching']==107 and len(data['diff'])==3,'wrong recovery');need(git('rev-parse','HEAD')==PIN and not git('status','--porcelain') and sha(Path(git('rev-parse','--path-format=absolute','--git-path','index')))==data['source_index'],'workspace changed');need(sha(primary/'public/statistics.json')==data['original_primary_statistics_sha256'],'stats changed');need((X/'corrected-native-rerun-v2/queue.rc').read_text().strip()=='0' and (h/'queue.rc').read_text().strip()=='0' and (X/'prefetch-v2-recovery-helper/supplement.rc').read_text().strip()=='1','queue differs'); before=shutil.disk_usage(X).free;record={'bytes_free_before':before,'source_pin':PIN,'stats_sha256':data['original_primary_statistics_sha256'],'deltas':{},'retired':{}}
 for q,got in data['diff'].items():
  rel=Path(q).relative_to(TARGET); orig=source/'target'/rel;private=clone/'target'/rel;need(not orig.samefile(private) and got['masked_fields_match'] and sha(orig)==got['reference'] and sha(private)==got['copy'],'unmatched files'); dif=[]
  with orig.open('rb') as f,private.open('rb') as g,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_COPY) as a,mmap.mmap(g.fileno(),0,access=mmap.ACCESS_COPY) as b:
   need(len(a)==len(b),'unequal length');aa=ctypes.addressof(ctypes.c_char.from_buffer(a));bb=ctypes.addressof(ctypes.c_char.from_buffer(b));i=0
   while i<len(a):
    s=min(8192,len(a)-i)
    if libc.memcmp(aa+i,bb+i,s):
     for j in range(i,i+s):
      if a[j]!=b[j]:dif.append([j,a[j],b[j]])
    i+=s
   need(0<len(dif)<256,'unexpected changes');
   for off,old,new in dif:need(a[off]==old and b[off]==new,off);a[off]=new
   need(hashlib.sha256(a).hexdigest()==got['copy'],'delta does not reconstruct')
  record['deltas'][q]={'sha256_before':got['reference'],'sha256_private':got['copy'],'bytes':dif}
 for n,ci,oi in [('target',26486991,24985756),('shared',26521222,24985778)]:
  q=clone/n;orig=source/n;v=q.stat();w=orig.stat();need(clone.parent==primary and clone.name=='recovery-private-V' and not clone.is_symlink() and q.parent==clone and not q.is_symlink() and q.is_dir() and not q.samefile(orig) and v.st_dev==w.st_dev==64769 and v.st_ino==ci and w.st_ino==oi,'refuse wrong data');record['retired'][n]={'private_device':v.st_dev,'private_inode':v.st_ino,'original_device':w.st_dev,'original_inode':w.st_ino,'bytes':int(subprocess.check_output(['du','-s','-B1',q]).split()[0])}
 need(not (sup/'copy-retired.json').exists() and not (sup/'copy-exact-deltas.json').exists(),'already ran');dump(sup/'copy-exact-deltas.json',record)
 for n in record['retired']:shutil.rmtree(clone/n);need((source/n).stat().st_ino==record['retired'][n]['original_inode'] and not (clone/n).exists(),n)
 record['bytes_free_after']=shutil.disk_usage(X).free;record['C_never_created']=not (sup/'recovery-private-C').exists();need(record['C_never_created'],'wrong C');dump(sup/'copy-retired.json',record);print('Free GiB',before/2**30,record['bytes_free_after']/2**30,'Exact changed byte counts',[len(t['bytes']) for t in record['deltas'].values()]);print('preserved delta digest',sha(sup/'copy-exact-deltas.json'))
