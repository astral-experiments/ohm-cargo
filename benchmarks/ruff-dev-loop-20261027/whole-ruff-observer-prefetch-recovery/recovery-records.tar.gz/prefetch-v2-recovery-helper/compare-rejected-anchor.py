"""Explain a rejected private clone anchor without executing Cargo or changing its witnesses."""
import fcntl, hashlib, json, os, shutil, stat, subprocess, sys
from pathlib import Path
X=Path.home()/'.cache/ohm-233-position-qualified-20261027';h=X/'prefetch-fifo-qualified-v2';sys.path.insert(0,str(h));from common import P,PIN,RUFF,TARGET,git,sha,load,dump,need,elf
primary=X/'whole-ruff-observer-prefetch-fifo-v2';sup=X/'prefetch-v2-missing-proof-supplement';clone=primary/'recovery-private-V';source=X/'cargo-observer-ruff-fifo-fixed/state/test/candidate'
with (P/'native-measure.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX); need((X/'prefetch-v2-recovery-helper/supplement.rc').read_text().strip()=='1' and (X/'corrected-native-rerun-v2/queue.rc').read_text().strip()=='0','unfinished');need([q.name for q in sup.glob('removed-complete-*.bin')]==['removed-complete-V.bin'],'unexpected removal');need(not (sup/'recovery-private-C').exists(),'candidate cloned');need('private clone differs' in (sup/'failure.txt').read_text(),'different rejection');need(git('rev-parse','HEAD')==PIN and not git('status','--porcelain'),'Ruff changed');gold=load(h/'rejected-v1-and-starting-state.json');need(gold['source_index_sha256']==sha(Path(git('rev-parse','--path-format=absolute','--git-path','index'))),'index changed')
 initial=list(sup.glob('recovery-V-initial-anchor-attempt-*/anchor.json'));need(len(initial)==1,initial);ini=load(initial[0]);matches=list(sup.glob('recovery-V-final-anchor-attempt-*/anchor.json'));need(len(matches)==1,matches);a=load(matches[0]);b=load(primary/'final-test-V/anchor.json');r=load(matches[0].parent/'receipt.json');p=load(sup/'recovery-V-initial-prepare/receipt.json');rep={'original_primary_statistics_sha256':sha(primary/'public/statistics.json'),'original_helper':sha(X/'prefetch-v2-recovery-helper/postscore-recovery.py'),'source':git('rev-parse','HEAD'),'source_index':gold['source_index_sha256'],'dirty_anchor':r['dirty'],'prepare_dirty':p['dirty'],'prepare_rustc':p['processes']['rustc'],'prepare_links':p['processes']['linkers'],'diff':{},'fields':{},'proofs':{},'V_removed_complete':sha(sup/'removed-complete-V.bin'),'V_initial_elf_gold':ini['raw_sha256']==b['raw_sha256'],'V_steps':[],'C_not_run':True,'no_new_timed_command':True,'no_candidate_clone':True,'private_anchor_sha':sha(matches[0]),'reference_anchor_sha':sha(primary/'final-test-V/anchor.json')};need(rep['original_primary_statistics_sha256']=='f49971aeba6754e25c3a0e06ef1c966bfda99ce5bd7ac28c6f1e347ba3b1afa9','previous stats changed')
 for k in ['units','executables','roster_sha256','message_sha256','diagnostics','elf','raw_sha256','scanned_compiler_dep_info']:
  rep['fields'][k]=a[k]==b[k]
 for step in range(1,4):
  q=load(sup/f'recovery-V-learn-{step}/receipt.json');rep['V_steps'].append({k:q[k] for k in ['step','dirty','training_proof_state','passive_training_proof'] if k in q}|{'processes':q['processes']})
 for k in ['proofs','passive_proofs']:
  rep['proofs'][k]={'main':b[k],'initial':ini[k],'final':a[k]}
  for y in a[k]:
   for path_key,digest_key in [('encoded','sha256'),('raw','raw_sha256')]:
    if path_key not in y: continue
    q=Path(y[path_key]).relative_to(TARGET);l=clone/'target'/q;s=source/'target'/q;need(l.is_file() and s.is_file() and not l.samefile(s),q);need(sha(l)==y[digest_key] and sha(s)==b[k][0][digest_key],q)
 for q in sorted(set(a['raw_sha256'])|set(b['raw_sha256'])):
  act=a['raw_sha256'].get(q);ex=b['raw_sha256'].get(q)
  if act!=ex:
   rel=Path(q).relative_to(TARGET);c=elf(clone/'target'/rel);o=elf(source/'target'/rel);rep['diff'][q]={'reference':ex,'copy':act,'clone_now':c,'physical_original_now':o,'canonical_actual_digests':c['raw']==act and o['raw']==ex,'masked_fields_match':c['content_with_two_wild_fields_masked']==o['content_with_two_wild_fields_masked']}

 rep['elf_matching']=sum(v==b['raw_sha256'].get(k) for k,v in a['raw_sha256'].items());rep['elf_count']=len(a['raw_sha256']);rep['archived']=False
 print(json.dumps({k:rep[k] for k in ['fields','elf_matching','elf_count','dirty_anchor','V_initial_elf_gold','C_not_run']},default=str),flush=True)
 cap=sup/'clone-rejection.json';need(not cap.exists(),cap);dump(cap,rep)
 for n in ('target','shared'):
  q=clone/n;orig=source/n;need(q.parent.resolve()==clone and q.is_dir() and not q.is_symlink() and not q.samefile(orig),'wrong paths');print(n,q.stat().st_dev,q.stat().st_ino,orig.stat().st_ino,subprocess.check_output(['du','-s','-B1',q],text=True).strip(),flush=True)
 print('outcome sealed, no removals',sha(cap),flush=True)
