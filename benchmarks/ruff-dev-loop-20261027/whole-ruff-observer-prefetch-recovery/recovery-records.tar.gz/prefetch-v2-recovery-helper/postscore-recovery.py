"""Run only the optional missing-Ron recovery supplement, preserving the failed calibration and every native measurement."""
import fcntl,hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
x=Path.home()/'.cache/ohm-233-position-qualified-20261027';h=x/'prefetch-fifo-qualified-v2';out=x/'whole-ruff-observer-prefetch-fifo-v2';sup=x/'prefetch-v2-missing-proof-supplement';impl=Path(__file__).resolve().parent
sys.path.insert(0,str(h))
from common import P,TARGET,SHARED,CARGO_HOME,PIN,RUFF,sha,git,need,dump,load
from namespace import spawn_args
source=x/'cargo-observer-ruff-fifo-fixed/state/test/candidate';home=out/'cargo-home-test';mount=load(out/'namespace.json');subj=x/'prefetch-fifo-qualified/subjects'
driver=x/'drivers/driver-dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f'
extras=[(p.resolve(),CARGO_HOME/p.name) for p in (source/'registry-home').iterdir() if p.name in ('registry','git') and p.resolve().is_dir()]
final=load(out/'final-test-V/anchor.json');gold=load(h/'rejected-v1-and-starting-state.json'); origs=sha(out/'public/statistics.json')
rawlog=(h/'score.log').read_text();need('missing native exec-open calibration' in rawlog and (out/'training-limit.json').is_file(),'original failure')
assert (h/'queue.rc').read_text().strip()=='0' and (out/'complete.json').is_file()
while not (x/'corrected-native-rerun-v2/queue.rc').is_file():time.sleep(20)
need((x/'corrected-native-rerun-v2/queue.rc').read_text().strip()=='0','portable correction failed')
def invoke(st,arm,phase,label):
    d=sup/('recovery-'+arm+'-'+label);need(not d.exists(),d)
    cmd=spawn_args(mount,out,st,home,extras,subj/arm,driver);i=cmd.index('--');cmd[i:i]=['--bind',str(sup),str(sup)]
    cmd.extend([sys.executable,'-B',str(h/'worker.py'),arm,'test',phase,str(d),str(subj/'verify-obs1')])
    with (sup/(d.name+'.stdout')).open('x') as so,(sup/(d.name+'.stderr')).open('x') as se:
        run=subprocess.run(cmd,stdout=so,stderr=se,start_new_session=True)
    if run.returncode:
        err=(sup/(d.name+'.stderr')).read_text()
        raise ValueError((phase,label,run.returncode,'missing native exec-open calibration' in err,err.splitlines()[-1][:1300]))
    return d,load(d/'receipt.json')
def anchor(st,arm,num):
    last=None
    for attempt in (1,2):
        try:
            d,r=invoke(st,arm,'anchor',f'{num}-anchor-attempt-{attempt}')
        except ValueError as exc:
            if len(exc.args)!=1 or not isinstance(exc.args[0],tuple) or exc.args[0][3] is not True or attempt==2:raise
            qualifications['initial_calibration_attempts'].append(repr(exc));continue
        a=load(d/'anchor.json');need(not r['dirty'] and a['raw_sha256']==final['raw_sha256'] and a['roster_sha256']==final['roster_sha256'] and a['diagnostics']==final['diagnostics'] and len(a['proofs'])==len(a['passive_proofs'])==1,'private clone differs from sealed native workspace')
        need(a['passive_proofs'][0]['sha256']==final['passive_proofs'][0]['sha256'] and a['passive_proofs'][0]['raw_sha256']==final['passive_proofs'][0]['raw_sha256'] and len(a['exec_open_calibration'])==1,'dormant record/dedicated calibration')
        return a
    raise RuntimeError(('missing anchor',last))
def attest_source():
    need(git('rev-parse','HEAD')==PIN and not git('status','--porcelain'),'Ruff is not restored')
    need(sha(Path(git('rev-parse','--path-format=absolute','--git-path','index')))==gold['source_index_sha256'] and sha(out/'public/statistics.json')==origs,'original data changed')
def remove_owned(st,arm):
    expected=out/'recovery-private-V' if arm=='V' else sup/'recovery-private-C'
    need(st==expected and not st.is_symlink(),'refuse private path')
    for n in ('target','shared'):
        p=st/n;need(p.parent==expected and p.is_dir() and not p.is_symlink() and not p.samefile(source/n),'refusing to touch original')
        shutil.rmtree(p)
with (P/'native-measure.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);attest_source();need(not sup.exists(),sup);sup.mkdir(mode=0o700)
 qualifications={'original_failure_preserved':sha(out/'training-limit.json'),'original_statistics':origs,'zero_new_timed_commands':True,'initial_calibration_attempts':[],'arms':{}}
 try:
    for arm in 'VC':
        st=out/'recovery-private-V' if arm=='V' else sup/'recovery-private-C'
        if arm=='V':need((st/'target').is_dir() and (st/'shared').is_dir(),'existing private clone not found')
        else:
            st.mkdir();sz=int(subprocess.check_output(['du','-s','-B1',source/'target']).split()[0]);need(shutil.disk_usage(st).free>25*2**30+int(1.1*sz),'missing private copy space')
            for n in ('target','shared'):subprocess.run(['cp','-a','--reflink=auto','--',source/n,st/n],check=True)
        _,prev=invoke(st,arm,'prepare','initial-prepare');before=anchor(st,arm,'initial')
        logical=Path(before['proofs'][0]['encoded']);rel=logical.relative_to(TARGET);physical=st/'target'/rel
        need(physical.is_file() and not physical.is_symlink() and physical.name=='dep-lib-ron' and sha(physical)==before['proofs'][0]['sha256'] and not physical.samefile(source/'target'/rel),'unsafe removal or wrong certificate')
        packed=sup/('removed-complete-'+arm+'.bin');packed.write_bytes(physical.read_bytes());physical.unlink()
        steps=[]
        for i in range(1,5):
            _,row=invoke(st,arm,'train',f'learn-{i}')
            steps.append({'step':i,'dirty':row['dirty'],'physical_rustc':row['processes']['rustc'],'native_links':len(row['processes']['linkers']),'proofs':row['training_proof_state'],'passive':row['passive_training_proof']})
            if not row['dirty'] and not row['processes']['rustc'] and any(q['complete'] for q in row['training_proof_state']):break
        end=anchor(st,arm,'final');need(any(s['dirty'] for s in steps) and not steps[-1]['dirty'] and any(q['complete'] for q in steps[-1]['proofs']),'missing recovery')
        qualifications['arms'][arm]={'starting_prepared_dirty':prev['dirty'],'steps':steps,'all_110_native_outputs_identical':before['raw_sha256']==end['raw_sha256']==final['raw_sha256'],'active_before':before['proofs'][0]['sha256'],'active_after':end['proofs'][0]['sha256'],'passive_before_after':before['passive_proofs'][0]['sha256'],'external_fresh':end['units']}
        dump(sup/'progress.json',qualifications)
        remove_owned(st,arm);attest_source()
    dump(sup/'complete.json',qualifications);print('Both independent private recoveries qualified. All primary receipts unchanged.',flush=True)
 except BaseException:
    (sup/'failure.txt').write_text(traceback.format_exc());raise
