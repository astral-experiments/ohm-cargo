/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/cli-switch-native609e-v1/target/debug/build/workspaces/871a6aa7a146b5f3/v2-5891bdba5dbefcd0/ruff/26be721d388d5f0e/out/ruff-26be721d388d5f0e.d: crates/ruff/src/lib.rs crates/ruff/src/args.rs crates/ruff/src/cache.rs crates/ruff/src/commands/mod.rs crates/ruff/src/commands/completions/mod.rs crates/ruff/src/commands/completions/config.rs crates/ruff/src/commands/add_noqa.rs crates/ruff/src/commands/analyze_graph.rs crates/ruff/src/commands/check.rs crates/ruff/src/commands/check_stdin.rs crates/ruff/src/commands/clean.rs crates/ruff/src/commands/config.rs crates/ruff/src/commands/format.rs crates/ruff/src/commands/format_stdin.rs crates/ruff/src/commands/linter.rs crates/ruff/src/commands/rule.rs crates/ruff/src/commands/server.rs crates/ruff/src/commands/show_files.rs crates/ruff/src/commands/show_settings.rs crates/ruff/src/commands/version.rs crates/ruff/src/diagnostics.rs crates/ruff/src/printer.rs crates/ruff/src/resolve.rs crates/ruff/src/stdin.rs crates/ruff/src/version.rs

/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/cli-switch-native609e-v1/target/debug/build/workspaces/871a6aa7a146b5f3/v2-5891bdba5dbefcd0/ruff/26be721d388d5f0e/out/libruff-26be721d388d5f0e.rlib: crates/ruff/src/lib.rs crates/ruff/src/args.rs crates/ruff/src/cache.rs crates/ruff/src/commands/mod.rs crates/ruff/src/commands/completions/mod.rs crates/ruff/src/commands/completions/config.rs crates/ruff/src/commands/add_noqa.rs crates/ruff/src/commands/analyze_graph.rs crates/ruff/src/commands/check.rs crates/ruff/src/commands/check_stdin.rs crates/ruff/src/commands/clean.rs crates/ruff/src/commands/config.rs crates/ruff/src/commands/format.rs crates/ruff/src/commands/format_stdin.rs crates/ruff/src/commands/linter.rs crates/ruff/src/commands/rule.rs crates/ruff/src/commands/server.rs crates/ruff/src/commands/show_files.rs crates/ruff/src/commands/show_settings.rs crates/ruff/src/commands/version.rs crates/ruff/src/diagnostics.rs crates/ruff/src/printer.rs crates/ruff/src/resolve.rs crates/ruff/src/stdin.rs crates/ruff/src/version.rs

/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/cli-switch-native609e-v1/target/debug/build/workspaces/871a6aa7a146b5f3/v2-5891bdba5dbefcd0/ruff/26be721d388d5f0e/out/libruff-26be721d388d5f0e.rmeta: crates/ruff/src/lib.rs crates/ruff/src/args.rs crates/ruff/src/cache.rs crates/ruff/src/commands/mod.rs crates/ruff/src/commands/completions/mod.rs crates/ruff/src/commands/completions/config.rs crates/ruff/src/commands/add_noqa.rs crates/ruff/src/commands/analyze_graph.rs crates/ruff/src/commands/check.rs crates/ruff/src/commands/check_stdin.rs crates/ruff/src/commands/clean.rs crates/ruff/src/commands/config.rs crates/ruff/src/commands/format.rs crates/ruff/src/commands/format_stdin.rs crates/ruff/src/commands/linter.rs crates/ruff/src/commands/rule.rs crates/ruff/src/commands/server.rs crates/ruff/src/commands/show_files.rs crates/ruff/src/commands/show_settings.rs crates/ruff/src/commands/version.rs crates/ruff/src/diagnostics.rs crates/ruff/src/printer.rs crates/ruff/src/resolve.rs crates/ruff/src/stdin.rs crates/ruff/src/version.rs

crates/ruff/src/lib.rs:
crates/ruff/src/args.rs:
crates/ruff/src/cache.rs:
crates/ruff/src/commands/mod.rs:
crates/ruff/src/commands/completions/mod.rs:
crates/ruff/src/commands/completions/config.rs:
crates/ruff/src/commands/add_noqa.rs:
crates/ruff/src/commands/analyze_graph.rs:
crates/ruff/src/commands/check.rs:
crates/ruff/src/commands/check_stdin.rs:
crates/ruff/src/commands/clean.rs:
crates/ruff/src/commands/config.rs:
crates/ruff/src/commands/format.rs:
crates/ruff/src/commands/format_stdin.rs:
crates/ruff/src/commands/linter.rs:
crates/ruff/src/commands/rule.rs:
crates/ruff/src/commands/server.rs:
crates/ruff/src/commands/show_files.rs:
crates/ruff/src/commands/show_settings.rs:
crates/ruff/src/commands/version.rs:
crates/ruff/src/diagnostics.rs:
crates/ruff/src/printer.rs:
crates/ruff/src/resolve.rs:
crates/ruff/src/stdin.rs:
crates/ruff/src/version.rs:

# env-dep:CARGO_PKG_AUTHORS=Charlie Marsh <charlie.r.marsh@gmail.com>
# env-dep:CARGO_PKG_NAME=ruff
# env-dep:CARGO_PKG_VERSION=0.17.0
# env-dep:RUFF_COMMIT_DATE=2026-10-15
# env-dep:RUFF_COMMIT_HASH=829455624d78f2e89669e4b4b14af2b96abdb1ae
# env-dep:RUFF_COMMIT_SHORT_HASH=829455624
# env-dep:RUFF_LAST_TAG
# env-dep:RUFF_LAST_TAG_DISTANCE
# checksum:blake3=03630ea39355e95743cf5127b8f5f9ac0e7e45cd124dd91f55c417602b48c469 file_len:23476 crates/ruff/src/lib.rs
# checksum:blake3=34b0b32f021c25612d3cb6b30f2f7a1d9033e4c60354e61da5c080c6100ddd1c file_len:57335 crates/ruff/src/args.rs
# checksum:blake3=43214df6e9b064704bea1f54ed893a7dc29325d1c082e3c6ea56e6d86f2873d7 file_len:36975 crates/ruff/src/cache.rs
# checksum:blake3=a45bd442fd67fb789eccb16b16b9deba1e9a77b39aed700ac745fe23ac2c6165 file_len:379 crates/ruff/src/commands/mod.rs
# checksum:blake3=07c3c1059d9fed32f22e42894a2825aabf72b966a1a775e3547de537fddedb08 file_len:23 crates/ruff/src/commands/completions/mod.rs
# checksum:blake3=48549f1d1dc93150268638aa28f64bbe02b35a3edfb5c9ec035ede7355f3d9df file_len:4329 crates/ruff/src/commands/completions/config.rs
# checksum:blake3=58c4c032a465511c639f28d3912554d9879b9fb348e79c813ac4631bd57acbe9 file_len:3648 crates/ruff/src/commands/add_noqa.rs
# checksum:blake3=53b2340a6df26b5791649525f9f176a47c92afdba9e299fe3a41922bcb2079dc file_len:10936 crates/ruff/src/commands/analyze_graph.rs
# checksum:blake3=a692e69543144c47def2e55e969b631aab778cec9956542a6a79b9245a2c8e2e file_len:10040 crates/ruff/src/commands/check.rs
# checksum:blake3=519a777037a8a9fbc9666643743776bb6ea2b87ff0ff30452304b9cdef42d961 file_len:1927 crates/ruff/src/commands/check_stdin.rs
# checksum:blake3=f453eef1f682199ea15ee7605e8459dedef2e2b3cc2ceceec85f24072837feee file_len:979 crates/ruff/src/commands/clean.rs
# checksum:blake3=ffcce69f9a37962239e75107b76ce5d5f3d02af8d2e4b5dc3916a98c8c1cb3b7 file_len:1091 crates/ruff/src/commands/config.rs
# checksum:blake3=e5e964b41bac0c834899d456ab32e4d20fe824bd8ea86196df85e2f2bc31e1f0 file_len:56701 crates/ruff/src/commands/format.rs
# checksum:blake3=e54b3f73cb0f3bd09f7b7f0c7c9dffc66fcbfe1bdc1404d3ca19fd862ef3d9d0 file_len:4650 crates/ruff/src/commands/format_stdin.rs
# checksum:blake3=2f569a9d9efa9b4703216cae4b4694c127302a18ae1b400bc9e5a9090571d9b0 file_len:2212 crates/ruff/src/commands/linter.rs
# checksum:blake3=af6410004a6d201c5f7dad84e753ab94197276db35ba38ad1ed52adc3d0c6c36 file_len:4433 crates/ruff/src/commands/rule.rs
# checksum:blake3=5b85954af094ca82d57d20a580705e04e11e39ca1c2c658e8b43627250ff59d3 file_len:272 crates/ruff/src/commands/server.rs
# checksum:blake3=b79610401d0c8e92a84620f4ffe714feea37122afb83553ecb27d409477cedfd file_len:1487 crates/ruff/src/commands/show_files.rs
# checksum:blake3=d45478f047e02efc1cf92e9b91ae21b107aaba681c4c1ed3229a559ebbddf96a file_len:1164 crates/ruff/src/commands/show_settings.rs
# checksum:blake3=914f9ba7619d65a7df7d447d93711035affee09e78c2fef7f48747d71ead60be file_len:542 crates/ruff/src/commands/version.rs
# checksum:blake3=18939eea9453a8fcdd90077f87825be8d4502cd45973077e866df52c7dd5a6ec file_len:20156 crates/ruff/src/diagnostics.rs
# checksum:blake3=8cf06ad6e8c4ddb33c380962e3c16b818a434a8e16ac56c5c79ee6f8649c1823 file_len:20345 crates/ruff/src/printer.rs
# checksum:blake3=9bca47eb31932c704dec54928308bd3c86831fcae778cc45ae76ad7604e287ac file_len:5830 crates/ruff/src/resolve.rs
# checksum:blake3=ef1c4783f0834b0ab0a0bc9a3922cb34c80d23f4495d9f5bfc768a7537d2a1bd file_len:506 crates/ruff/src/stdin.rs
# checksum:blake3=e296c7e6f56ce43b7c6e0950805e5fd97da61e5b73892de8c94cebc7c1a934f3 file_len:4167 crates/ruff/src/version.rs
