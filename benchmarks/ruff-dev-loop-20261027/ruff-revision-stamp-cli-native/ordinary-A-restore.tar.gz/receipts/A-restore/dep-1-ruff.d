/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/cli-switch-native609e-v1/target/debug/build/workspaces/871a6aa7a146b5f3/v2-5891bdba5dbefcd0/ruff/9302c70365f20393/out/ruff.d: crates/ruff/src/main.rs

/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/cli-switch-native609e-v1/target/debug/build/workspaces/871a6aa7a146b5f3/v2-5891bdba5dbefcd0/ruff/9302c70365f20393/out/ruff: crates/ruff/src/main.rs

crates/ruff/src/main.rs:
# checksum:blake3=d42d876e9488fa815b0c8eb637e5116cb29d3e336dded2d1a7ad94b184a49e42 file_len:2473 crates/ruff/src/main.rs
