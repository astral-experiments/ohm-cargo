use std::{env, fs, io, path::Path, process::Command};
fn archive(dir: &Path, value: u32) {
    fs::write(dir.join("choice.c"), format!("int choice(void) {{ return {value}; }}")).unwrap();
    assert!(Command::new("cc").current_dir(dir).args(["-c", "choice.c", "-o", "choice.o"]).status().unwrap().success());
    assert!(Command::new("ar").current_dir(dir).args(["crs", "libchoice.a", "choice.o"]).status().unwrap().success());
}
fn main() {
    println!("cargo:rerun-if-changed=state");
    let out = std::path::PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let early = out.join("early");
    let fallback = out.join("fallback");
    fs::create_dir_all(&early).unwrap();
    fs::create_dir_all(&fallback).unwrap();
    archive(&fallback, 17);
    let name = early.join("libchoice.a");
    if let Err(err) = fs::remove_file(&name) { assert_eq!(err.kind(), io::ErrorKind::NotFound); }
    match fs::read_to_string("state").unwrap().trim() {
        "valid" => archive(&early, 29),
        "malformed" => fs::write(&name, b"not a valid ar archive").unwrap(),
        "absent" => (),
        other => panic!("unexpected state {other}"),
    }
    println!("cargo:rustc-link-search=native={}", early.display());
    println!("cargo:rustc-link-search=native={}", fallback.display());
}
