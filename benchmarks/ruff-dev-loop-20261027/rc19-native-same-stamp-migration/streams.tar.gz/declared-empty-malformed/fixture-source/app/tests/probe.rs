#[link(name = "choice", kind = "static")]
extern "C" { fn choice() -> i32; }
#[test]
fn prints_choice() { println!("native-choice={}", unsafe { choice() }); }
