pub fn value() -> i32 { middle::base() + 2 }
