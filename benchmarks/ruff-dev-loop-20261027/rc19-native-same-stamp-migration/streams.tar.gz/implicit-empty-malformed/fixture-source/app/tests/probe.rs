#[test]
fn prints_choice() { println!("native-choice=17"); }
