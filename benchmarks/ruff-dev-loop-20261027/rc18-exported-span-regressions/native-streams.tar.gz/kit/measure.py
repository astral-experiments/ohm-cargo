"""Replay real consumer outputs with independent empty caches and actual native executables."""
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

lab=Path(os.environ['QA_LAB'])
kit=Path(os.environ['QA_KIT'])
sdk=Path(os.environ['QA_SDK'])
arm=os.environ['QA_ARM']
def sha(f):
    with f.open('rb') as fd:return hashlib.file_digest(fd,'sha256').hexdigest()
def save(path,data):
    path.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
phys={k:sha(f) for k,f in {'front':sdk/'bin/rustc','driver':next((sdk/'lib').glob('librustc_driver-*.so'))}.items()}
assert phys==json.loads(os.environ['QA_BINDING'])
save(lab/'physical.json',phys)
proxy=Path(shutil.which('rustup')).parent
home=lab/'rustup'
(home/'toolchains').mkdir(parents=True)
(home/'toolchains/ohm').symlink_to(sdk)
shim=lab/'rustc-ohm'
shim.write_text('#!/bin/sh\nexec '+str(proxy/'rustc')+' +ohm --sysroot '+str(sdk)+' "$@"\n')
shim.chmod(0o555)
env=dict(os.environ, RUSTUP_HOME=str(home),RUSTUP_AUTO_INSTALL='0',RUSTC=str(shim),RUSTC_BOOTSTRAP='1',
         HOST_RUSTC_DYLIB_PATH=str(sdk/'lib'),TARGET_EXE_DYLIB_PATH=str(sdk/'lib/rustlib/x86_64-unknown-linux-gnu/lib'),LD_LIBRARY_PATH=str(sdk/'lib'),LD_LIB_PATH_ENVVAR='LD_LIBRARY_PATH',TARGET='x86_64-unknown-linux-gnu',HOST='x86_64-unknown-linux-gnu',LC_ALL='C.UTF-8')
rows=[]
def call(cwd,tag,argv):
    proc=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=150)
    idx=len(rows)
    out=lab/'raw'/f'{idx:03d}-{tag}'
    out.with_suffix('.stdout').write_bytes(proc.stdout)
    out.with_suffix('.stderr').write_bytes(proc.stderr)
    row=dict(tag=tag,scope=cwd.name,argv=[str(a) for a in argv],rc=proc.returncode,stdout=hashlib.sha256(proc.stdout).hexdigest(),stderr=hashlib.sha256(proc.stderr).hexdigest(),ice=b'incremental compilation error with module_children' in proc.stderr or b'compiler unexpectedly panicked' in proc.stderr)
    rows.append(row)
    return proc
def rust(cwd,tag,*args):
    return call(cwd,tag,['rustc','+ohm','--sysroot',str(sdk),*args])
(lab/'raw').mkdir()
case=lab/'runmake'
shutil.copytree(kit/'sources',case)
env['TMPDIR']=str(case)
rmake=call(case,'regression',[kit/'module-child'])
print('compiled run-make test',rmake.returncode,flush=True)
env['TMPDIR']='/tmp'
hetero={}
for prod_public in ('yes','no'):
    for cons_public in ('yes','no'):
        d=lab/f'ignore-{prod_public}-{cons_public}'
        d.mkdir()
        (d/'reader.rs').write_text('extern crate input; fn main(){let _=input::answer();}\n')
        (d/'error.rs').write_text('extern crate input; fn main(){input::answer(5);}\n')
        cells=[]
        for step,indent,cache in [('original',0,'warm'),('moved',11,'warm'),('repeat',11,'warm'),('empty',11,'empty')]:
            (d/'input.rs').write_text(' '*indent+'pub fn answer()->u8 {17}\n')
            producer=rust(d,step+'-producer','--crate-type=rlib','--emit=metadata','-Cmetadata=f1','-Cincremental=p-'+cache,'-Zincremental-ignore-spans','-Zpublic-api-hash='+prod_public,'input.rs')
            assert producer.returncode==0,producer.stderr[-900:]
            read=rust(d,step+'-reader','--emit=metadata','-Cincremental=r-'+cache,'-Zpublic-api-hash='+cons_public,'--extern','input=libinput.rmeta','reader.rs')
            diagnostic=rust(d,step+'-diagnostic','--emit=metadata','--error-format=json','--extern','input=libinput.rmeta','error.rs')
            assert diagnostic.returncode==1
            diags=[v for line in diagnostic.stderr.splitlines() if (v:=json.loads(line)).get('code') and v['code']['code']=='E0061']
            assert len(diags)==1
            cols=[sp['column_start'] for ch in diags[0]['children'] for sp in ch['spans'] if sp['file_name'].endswith('input.rs')]
            assert cols
            cells.append(dict(step=step,reader=read.returncode,ice=b'incremental compilation error with module_children' in read.stderr,col=cols,metadata=sha(d/'libinput.rmeta')))
        hetero[d.name]=cells
        print(d.name,[(x['reader'],x['col']) for x in cells],flush=True)
track={}
for public in ('yes','no'):
    for typ in ('rlib','rlib,cdylib'):
        d=lab/('columns-'+public+'-'+typ.replace(',','-'));d.mkdir()
        (d/'reader.rs').write_text('extern crate input; fn main(){let f:fn()->&\'static std::panic::Location<\'static>=input::caller_location;println!("{}",f().column());}\n')
        dec='pub fn caller_location() -> &\'static std::panic::Location<\'static> { std::panic::Location::caller() }'
        cells=[]
        for label,indent,p_cache,r_cache in [('original',0,'warm','warm'),('moved',256,'warm','warm'),('reader-only',256,None,'empty-reader'),('empty',256,'empty','empty'),('move-512',512,'warm','warm'),('move-255',255,'warm','warm'),('move-511',511,'warm','warm'),('empty-511',511,'empty-511','empty-511')]:
            (d/'input.rs').write_text('#[track_caller]\n'+' '*indent+dec+' '*(512-indent)+'\n')
            if p_cache:
                x=rust(d,label+'-producer','--crate-type='+typ,'--emit=metadata,link','-Cmetadata=f0','-Cincremental=p-'+p_cache,'-Zpublic-api-hash='+public,'input.rs')
                assert not x.returncode,x.stderr[-900:]
            rlib=sha(d/'libinput.rlib')
            if label=='reader-only':assert rlib==cells[-1]['rlib']
            x=rust(d,label+'-reader','--extern','input=libinput.rlib','-Cincremental=r-'+r_cache,'-Zpublic-api-hash='+public,'reader.rs','-o','reader')
            val=None
            if x.returncode==0:
                y=call(d,label+'-execute',[d/'reader'])
                assert y.returncode==0
                val=int(y.stdout)
            cells.append(dict(step=label,shift=indent,column=val,reader=x.returncode,rlib=rlib,rmeta=sha(d/'libinput.rmeta')))
        track[d.name]=cells
        print(d.name,[(x['step'],x['column']) for x in cells],flush=True)
issues=[]
for case,cells in hetero.items():
    for x in cells:
        if x['reader']!=0 or x['col']!=[8 if x['step']=='original' else 19]:issues.append((case,x['step'],x['reader'],x['col']))
for case,cells in track.items():
    for x in cells:
        if x['reader']!=0 or x['column']!=cells[0]['column']+x['shift']:issues.append((case,x['step'],x['reader'],x['column']))
result=dict(arm=arm,physical=phys,harness=rmake.returncode,heterogeneous=hetero,columns=track,deviations=issues,raw_commands=len(rows))
save(lab/'commands.json',rows)
save(lab/'results.json',result)
print('done',arm,len(issues),len(rows),flush=True)

