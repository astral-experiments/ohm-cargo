import hashlib,json,os,shutil,socket,subprocess,sys
from pathlib import Path
assert socket.gethostname()=='charlie-ohm-relink-b-1024'
q=Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/mixed-module-children-17-v1-20261028')
kit=Path(__file__).resolve().parent
arm=sys.argv[1]
assert arm in ('shipped','243','rc18-export-r1','rc18-export-r2','rc18-export-r3')
case=kit.parent/('case-'+arm);case.mkdir(mode=0o700)
sdk=q/'canonical-sdk'; lab=q/'canonical-lab'
phys=Path('/dev/shm/ohm-published-member-h2-20261028/installed17') if arm=='shipped' else q.parent/'frozen-toolchain'
soname,=(phys/'lib').glob('librustc_driver-*.so')
if arm=='shipped':
    driver=soname
elif arm=='243':
    driver=q/'tool-fixed2/candidate-driver.so'
else:
    driver=q/('tool-'+arm)/'candidate-driver.so'
def sha(f):
    with f.open('rb') as fd:return hashlib.file_digest(fd,'sha256').hexdigest()
binding=dict(front=sha(phys/'bin/rustc'),driver=sha(driver))
if arm=='243':assert binding['driver']=='748e5862ece9b0e3098cdae472e1b0d94c50da724b8438f2e267c9007aee8737'
elif arm=='shipped': assert binding['driver'].startswith('618ebac1')
else:
    receipt=json.loads((driver.parent/'receipt.json').read_text())
    assert binding['driver']==receipt['candidate_postbolt'] and binding['front']==receipt['frontend']
proc=['taskset','-c','20-23','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--tmpfs','/tmp','--ro-bind',str(phys),str(sdk),'--ro-bind',str(driver),str(sdk/'lib'/soname.name),'--bind',str(case),str(lab),'--',sys.executable,'-IB',str(kit/'measure.py')]
env=dict(os.environ,QA_ARM=arm,QA_LAB=str(lab),QA_SDK=str(sdk),QA_KIT=str(kit),QA_BINDING=json.dumps(binding))
with (case/'worker.log').open('xb') as log:
    result=subprocess.run(proc,cwd=case,env=env,stdout=log,stderr=log,timeout=1200)
(case/'terminal.json').write_text(json.dumps(dict(status=result.returncode,physical=binding,argv=proc))+'\n')
sys.exit(result.returncode)

