"""Execute both unchanged commands in a clone of a proven-wrong official Cargo state."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root,rec,arm=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3];ref=json.loads((rec/'original.json').read_bytes())
h=lambda p: hashlib.file_digest(p.open('rb'),'sha256').hexdigest();store=lambda p,v:p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
env=dict(HOME=str(root),PATH=os.environ['PATH'],RUSTUP_HOME=str(root/'rustup'),RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(root/'cargo'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='4',OHM_SYNC_DIR=str(root),OHM_SYNC_CONSTANT='fixed',LC_ALL='C.UTF-8',LANG='C.UTF-8',CARGO_TARGET_DIR=str(root/'warm/target'),CARGO_BUILD_BUILD_DIR=str(root/'warm/shared'))
def command(args,**kwargs):return subprocess.run(args,cwd=root/'src',env=env,timeout=120,**kwargs)
def proof():
 f,=[p for tree in ('warm/target','warm/shared') for p in (root/tree).rglob('dep-bin-hold_direct') if p.is_file()]
 return f,f.read_bytes()
def value(elf):
 r=command([elf],capture_output=True,check=True);assert not r.stderr
 q,=re.findall(rb'^sample=(\d+)$',r.stdout,re.M);assert b'revision=2' in r.stdout.splitlines();return int(q),r.stdout
bin0=Path(ref['executable']);prior=ref['old'];before,encoded=proof();assert h(before)==prior['fingerprint'] and encoded[-41:-37]==b'OBS1' and encoded[-33]==1;assert h(bin0)==prior['exe']
old,stdout=value(bin0);assert old==17;store(rec/'before.json',dict(fingerprint=h(before),fingerprint_file=str(before),exe=h(bin0),elf=str(bin0),stdout=stdout.decode(),input=h(root/'private-input.txt'),source=h(root/'src/hold_direct/src/main.rs')))
(rec/'before.fingerprint').write_bytes(encoded)
for phase in ('repeat','again'):
 d=rec/phase;d.mkdir();trace=d/'exec';cmd=['strace','-f','-qq','-s','65535','-e','trace=execve','-o',trace,'cargo','+ohm','build','--offline','-p','hold_direct','--message-format=json']
 with (d/'cargo.jsonl').open('xb') as so,(d/'stderr').open('xb') as se:r=command(cmd,stdout=so,stderr=se);assert not r.returncode,(arm,phase,(d/'stderr').read_text()[-600:])
 events=[json.loads(s) for s in (d/'cargo.jsonl').read_bytes().splitlines()];assert events[-1]=={'reason':'build-finished','success':True}
 artifacts=[e for e in events if e['reason']=='compiler-artifact'];c,=[e for e in artifacts if e['target']['name']=='hold_direct'];assert c['executable']==str(bin0)
 v,out=value(bin0);(d/'program').write_bytes(out);fd,b=proof();assert fd==before and b[-41:-37]==b'OBS1';(d/'fingerprint').write_bytes(b)
 df,=[p for base in ('warm/target','warm/shared') for p in (root/base).rglob('hold_direct*.d') if p.parent.name=='out' and b'ohm-foreign-span-bytes' in p.read_bytes()];(d/'rustc.d').write_bytes(df.read_bytes())
 rows=dict(value=v,fresh=c['fresh'],complete=bool(b[-33]),elf=h(bin0),fingerprint=h(fd),trace=h(trace),program=h(d/'program'),dep=h(df),all_units=len(artifacts),rebuilt_units=[e['target']['name'] for e in artifacts if not e['fresh']],source=h(root/'src/hold_direct/src/main.rs'),input=h(root/'private-input.txt'));store(d/'row.json',rows)
 assert rows['source']==ref['source'] and rows['input']==ref['input']
store(rec/'done.json',{phase:json.loads((rec/phase/'row.json').read_bytes()) for phase in ('repeat','again')})
