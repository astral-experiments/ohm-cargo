# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=c0210aa58e8476d33d2ffef8cef5c879cb7255b004b3a5451d1debaff73ff0e0 file_len:486 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt
