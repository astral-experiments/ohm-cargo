from pathlib import Path
import fcntl,hashlib,json,os,shutil,socket,subprocess,sys,traceback
me=Path(__file__).resolve().parent;base=me;data=Path('/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17')
sdk=Path('/dev/shm/ohm-published-member-h2-20261028/installed17');tools=Path('/mnt/devbox-scratch/dev-user/ohm-observer-consumption-tools-20261028')
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();J=lambda p:json.loads(p.read_bytes());store=lambda p,v:p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def main():
 assert socket.gethostname()=='charlie-ohm-relink-b-1024' and (data/'complete.json').is_file();bindings=J(tools/'receipt.json')
 assert h(sdk/'bin/cargo')=='4e4065390403afbf4fb77b2f41fbc21c59afe3dda2337a5bbe29fda29a47dbb3' and h(tools/'fixed-cargo')==bindings['cargo']=='0aa04df8023984b83ef676d1494d43e482472e1b2bccdb82a4d0bd390578a322'
 assert h(tools/'matched-cargo')==bindings['matched_baseline']=='50ca47744e09d3ab9cfa320794c1a656935137abc3aaf22b7f74841f7c1be466'
 driver,=sdk.glob('lib/librustc_driver-*.so');assert h(driver)=='618ebac16b7d4ec01a2af89661d25b8f26ff347edbb69c6dcaa78f10115914a7'
 store(base/'bindings.json',{'product':bindings,'official':h(sdk/'bin/cargo'),'rustc':h(sdk/'bin/rustc'),'driver':h(driver)})
 table={}
 for case in sorted(data.glob('trained-*')):
  info=J(case/'report.json');old=info['rows']['again'];refs=[json.loads(s) for s in (case/'again/cargo.jsonl').read_bytes().splitlines()];c,=[e for e in refs if e['reason']=='compiler-artifact' and e['target']['name']=='hold_direct']
  assert old['fresh'] and old['value']==17 and old['initially_complete'] and info['rows']['clean']['value']==29
  for arm in ('official','matched','fixed'):
   path=base/arm/case.name;path.mkdir(parents=True);clone=path/'state';clone.mkdir();rec=path/'receipts';rec.mkdir()
   assert shutil.disk_usage(base).free>5*2**30
   for nm in ('src','rustup','cargo','warm','private-input.txt','observed','release'):
    subprocess.run(['cp','-a','--reflink=auto',str(case/nm),str(clone/nm)],check=True)
   store(rec/'original.json',dict(old=old,executable=c['executable'],source=old['caller_sha'],input=info['after']['sha256'],path=case.name))
   cmd=['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--tmpfs','/tmp','--bind',str(base),str(base),'--bind',str(clone),str(case)]
   if arm!='official':cmd+=['--ro-bind',str(tools/(arm+'-cargo')),str(sdk/'bin/cargo')]
   cmd+=['--','taskset','-c','8-11',sys.executable,'-B',str(base/'measure.py'),str(case),str(rec),arm]
   with (rec/'stdout').open('xb') as so,(rec/'worker.stderr').open('xb') as se:r=subprocess.run(cmd,stdout=so,stderr=se)
   assert r.returncode==0,(arm,case.name,(rec/'worker.stderr').read_text()[-1300:]);table[arm+'/'+case.name]=J(rec/'done.json');store(base/'progress.json',{k:[[v[p]['value'],v[p]['fresh'],v[p]['complete']]for p in ('repeat','again')]for k,v in table.items()})
 assert len(table)==18
 store(base/'complete.json',table)
except_to=None
try:main()
except BaseException:
 (base/'failure.txt').write_text(traceback.format_exc());raise
