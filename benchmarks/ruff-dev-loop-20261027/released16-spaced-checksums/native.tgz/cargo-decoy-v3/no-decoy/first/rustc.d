/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/no-decoy/target/debug/build/workspaces/7ca9c540e691f74a/v2-38030f2b3f6cffb6/hold_direct/d24d62169f556d01/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/no-decoy/target/debug/build/workspaces/7ca9c540e691f74a/v2-38030f2b3f6cffb6/hold_direct/d24d62169f556d01/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/no-decoy/target/debug/build/workspaces/7ca9c540e691f74a/v2-38030f2b3f6cffb6/hold_direct/d24d62169f556d01/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/no-decoy/target/debug/build/workspaces/7ca9c540e691f74a/v2-38030f2b3f6cffb6/hold_direct/d24d62169f556d01/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/no-decoy/target/debug/build/workspaces/7ca9c540e691f74a/v2-38030f2b3f6cffb6/hold_direct/d24d62169f556d01/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=7a071de79df8192ebeb887d8349031e3c5eb7c5aaa64ca4b61999a7b5d3b1962 file_len:270 hold_direct/src/main.rs
