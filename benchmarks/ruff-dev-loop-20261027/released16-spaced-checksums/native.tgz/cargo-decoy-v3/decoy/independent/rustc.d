/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/decoy/independent-target/debug/build/workspaces/b8e5407f48c29cba/v2-ac797d2852066fac/hold_direct/ad765f277e8d370d/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/decoy/independent-target/debug/build/workspaces/b8e5407f48c29cba/v2-ac797d2852066fac/hold_direct/ad765f277e8d370d/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/decoy/independent-target/debug/build/workspaces/b8e5407f48c29cba/v2-ac797d2852066fac/hold_direct/ad765f277e8d370d/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/decoy/independent-target/debug/build/workspaces/b8e5407f48c29cba/v2-ac797d2852066fac/hold_direct/ad765f277e8d370d/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/cargo-decoy-v3/decoy/independent-target/debug/build/workspaces/b8e5407f48c29cba/v2-ac797d2852066fac/hold_direct/ad765f277e8d370d/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=7a071de79df8192ebeb887d8349031e3c5eb7c5aaa64ca4b61999a7b5d3b1962 file_len:270 hold_direct/src/main.rs
