from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
p=Path(sys.argv[1]).resolve();p.mkdir()
template=Path(__file__).resolve().parent/'heldout-fixture'
H=lambda b:hashlib.sha256(b).hexdigest()
def outsh(v):return {str(f):H(f.read_bytes()) for f in v}
def run(args,root,env): 
 r=subprocess.run(args,cwd=root,env=env,capture_output=True); assert r.returncode==0,(args,r.stderr.decode()[-1800:],r.stdout.decode()[-1200:]); return r
def compile_extra(st,extra,output,tag,e):
 (st/'extra.rs').write_text('pub fn value()->u32 {'+str(tag)+'}\n')
 run(['rustc','+ohm','--crate-name','escape_fixture','--crate-type=rlib','-Copt-level=1','-Cmetadata=keep-identical-tag','-Cdebuginfo=0',str(st/'extra.rs'),'-o',str(output)],st,e)
def cargo(st,e,label,external,decoy):
 d=st/label;d.mkdir(); cmd=['cargo','+ohm','build','--offline','-p','hold_direct','--message-format=json'];x=run(cmd,st/'code',e);(d/'stdout.jsonl').write_bytes(x.stdout);(d/'stderr').write_bytes(x.stderr)
 art=[j for l in x.stdout.splitlines() if (j:=json.loads(l)).get('reason')=='compiler-artifact']
 a,=[j for j in art if j['target']['name']=='hold_direct'];exe=Path(a['executable']);native=run([str(exe)],st,e).stdout.decode()
 dep,=[f for root in [Path(e['CARGO_TARGET_DIR']),Path(e['CARGO_BUILD_BUILD_DIR'])] for f in root.rglob('hold_direct*.d') if f.parent.name=='out' and b'ohm-foreign-span-bytes' in f.read_bytes()]
 encoded,=[f for root in [Path(e['CARGO_TARGET_DIR']),Path(e['CARGO_BUILD_BUILD_DIR'])] for f in root.rglob('dep-bin-hold_direct') if f.is_file() and b'OBS1' in f.read_bytes()]
 ep=encoded.read_bytes(); assert ep[-41:-37]==b'OBS1';(d/'encoded').write_bytes(ep);(d/'rustc.d').write_bytes(dep.read_bytes());sha=H(external.read_bytes());shadow=H(decoy.read_bytes()) if decoy.exists() else None
 escaped=str(external).replace(' ','\\ ');checks=[l for l in dep.read_text().splitlines() if l.startswith('# checksum:') and l.endswith(escaped)]
 v={'cargo_argv':cmd,'raw_stdout_sha':H(x.stdout),'exit':0,'native':native,'value':int(native.strip().split('escape-value=')[-1]),'elf':H(exe.read_bytes()),'status':ep[-33],'fresh':a['fresh'],'all_fresh':all(j['fresh'] for j in art),'units':len(art),'checksum_line':checks,'external_sha256':sha,'shadow_sha256':shadow,'depinfo':str(dep),'depinfo_sha':H(dep.read_bytes()),'source_sha':H((st/'code/hold_direct/src/main.rs').read_bytes())};(d/'row.json').write_text(json.dumps(v,indent=2)+'\n')
 print(st.name,label,v['value'],v['fresh'],v['status'],len(checks),flush=True);return v
results={}
for mode in ('decoy','no-decoy','ordinary'):
 st=p/mode;st.mkdir();src=st/'code';shutil.copytree(template,src);p0=src/'hold_direct/src/main.rs';p0.write_text(p0.read_text().replace('fn main(){','fn main(){print!("{}\\n",hold_shapes::count());').replace(');}',');println!("escape-value={}",escape_fixture::value());}'))
 extname='external space' if mode!='ordinary' else 'external';extdir=st/extname;extdir.mkdir();shadow=st/extname.replace(' ','\\ ');decoy=shadow/'libescape_fixture.rlib' if mode!='ordinary' else st/'unused-decoy';external=extdir/'libescape_fixture.rlib'
 env=dict(os.environ,CARGO_HOME=str(st/'home'),CARGO_TARGET_DIR=str(st/'target'),CARGO_BUILD_BUILD_DIR=str(st/'build'),CARGO_BUILD_JOBS='4',CARGO_ENCODED_RUSTFLAGS='--extern\x1fescape_fixture='+str(external))
 for key in ('CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'):env.pop(key,None)
 compile_extra(st,extdir,external,17,env); a=external.read_bytes();compile_extra(st,extdir,st/'future.rlib',29,env);b=(st/'future.rlib').read_bytes()
 if mode=='decoy':shadow.mkdir();decoy.write_bytes(b)
 assert a!=b
 v={};v['first']=cargo(st,env,'first',external,decoy);v['train']=cargo(st,env,'train',external,decoy);v['unchanged']=cargo(st,env,'unchanged',external,decoy)
 m=external.stat();external.write_bytes(b);os.utime(external,ns=(m.st_atime_ns,m.st_mtime_ns))
 v['swapped']=cargo(st,env,'swapped',external,decoy)
 env2=dict(env,CARGO_TARGET_DIR=str(st/'independent-target'),CARGO_BUILD_BUILD_DIR=str(st/'independent-build'))
 v['independent']=cargo(st,env2,'independent',external,decoy)
 assert v['first']['value']==v['train']['value']==v['unchanged']['value']==17 and v['independent']['value']==29
 results[mode]=v
(p/'result.json').write_text(json.dumps(results,indent=2)+'\n')
