# ohm-raw-checksum-paths-v1
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-from-prototype/ab/target/debug/build/workspaces/7e55789d6c19695a/v2-56507b0597059447/hold_direct/53ef06a559ea2f07/out/hold_direct-53ef06a559ea2f07.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-from-prototype/ab/target/debug/build/workspaces/7e55789d6c19695a/v2-56507b0597059447/hold_direct/53ef06a559ea2f07/out/hold_direct-53ef06a559ea2f07.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-from-prototype/ab/target/debug/build/workspaces/7e55789d6c19695a/v2-56507b0597059447/hold_direct/53ef06a559ea2f07/out/libhold_direct-53ef06a559ea2f07.rmeta: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-from-prototype/ab/target/debug/build/workspaces/7e55789d6c19695a/v2-56507b0597059447/hold_direct/53ef06a559ea2f07/out/hold_direct-53ef06a559ea2f07.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-from-prototype/ab/target/debug/build/workspaces/7e55789d6c19695a/v2-56507b0597059447/hold_direct/53ef06a559ea2f07/out/hold_direct-53ef06a559ea2f07.d/ohm-foreign-span-bytes:
# checksum:blake3=096afc73108ff9e47dcf22918572bd8a6312e4de49e8f4f6338f02381e088edc file_len:354 hold_direct/src/main.rs
