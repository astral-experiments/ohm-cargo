/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/decoy/clean-target/debug/build/workspaces/e716d4919c607f37/v2-6dd5c96a93afae4f/hold_direct/ae86b75af76986fd/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/decoy/clean-target/debug/build/workspaces/e716d4919c607f37/v2-6dd5c96a93afae4f/hold_direct/ae86b75af76986fd/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/decoy/clean-target/debug/build/workspaces/e716d4919c607f37/v2-6dd5c96a93afae4f/hold_direct/ae86b75af76986fd/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/decoy/clean-target/debug/build/workspaces/e716d4919c607f37/v2-6dd5c96a93afae4f/hold_direct/ae86b75af76986fd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/decoy/clean-target/debug/build/workspaces/e716d4919c607f37/v2-6dd5c96a93afae4f/hold_direct/ae86b75af76986fd/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
