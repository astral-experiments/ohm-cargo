/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/no-decoy/target/debug/build/workspaces/b427158fbf299594/v2-25f19ee8ee1ab602/hold_direct/a2deb656d7b0eb0f/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/no-decoy/target/debug/build/workspaces/b427158fbf299594/v2-25f19ee8ee1ab602/hold_direct/a2deb656d7b0eb0f/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/no-decoy/target/debug/build/workspaces/b427158fbf299594/v2-25f19ee8ee1ab602/hold_direct/a2deb656d7b0eb0f/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/no-decoy/target/debug/build/workspaces/b427158fbf299594/v2-25f19ee8ee1ab602/hold_direct/a2deb656d7b0eb0f/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/no-decoy/target/debug/build/workspaces/b427158fbf299594/v2-25f19ee8ee1ab602/hold_direct/a2deb656d7b0eb0f/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
