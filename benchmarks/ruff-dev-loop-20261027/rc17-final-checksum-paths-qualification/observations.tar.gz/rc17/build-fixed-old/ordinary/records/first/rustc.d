/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/ordinary/target/debug/build/workspaces/5d572117513acf26/v2-1bc83d3ed1ac06ab/hold_direct/061cbb58f5baf747/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/ordinary/target/debug/build/workspaces/5d572117513acf26/v2-1bc83d3ed1ac06ab/hold_direct/061cbb58f5baf747/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/ordinary/target/debug/build/workspaces/5d572117513acf26/v2-1bc83d3ed1ac06ab/hold_direct/061cbb58f5baf747/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/ordinary/target/debug/build/workspaces/5d572117513acf26/v2-1bc83d3ed1ac06ab/hold_direct/061cbb58f5baf747/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-old/ordinary/target/debug/build/workspaces/5d572117513acf26/v2-1bc83d3ed1ac06ab/hold_direct/061cbb58f5baf747/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
