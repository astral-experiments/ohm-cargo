/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-old/no-decoy/clean-target/debug/build/workspaces/7a80045b491c6c21/v2-29e82a8f6745400f/hold_direct/0fb137cf157893a9/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-old/no-decoy/clean-target/debug/build/workspaces/7a80045b491c6c21/v2-29e82a8f6745400f/hold_direct/0fb137cf157893a9/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-old/no-decoy/clean-target/debug/build/workspaces/7a80045b491c6c21/v2-29e82a8f6745400f/hold_direct/0fb137cf157893a9/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-old/no-decoy/clean-target/debug/build/workspaces/7a80045b491c6c21/v2-29e82a8f6745400f/hold_direct/0fb137cf157893a9/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-old/no-decoy/clean-target/debug/build/workspaces/7a80045b491c6c21/v2-29e82a8f6745400f/hold_direct/0fb137cf157893a9/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
