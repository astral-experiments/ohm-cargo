/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/decoy-removed/clean-target/debug/build/workspaces/885b0057aa6d2f45/v2-d0c834503776741f/hold_direct/c69667c4dff9bc12/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/decoy-removed/clean-target/debug/build/workspaces/885b0057aa6d2f45/v2-d0c834503776741f/hold_direct/c69667c4dff9bc12/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/decoy-removed/clean-target/debug/build/workspaces/885b0057aa6d2f45/v2-d0c834503776741f/hold_direct/c69667c4dff9bc12/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/decoy-removed/clean-target/debug/build/workspaces/885b0057aa6d2f45/v2-d0c834503776741f/hold_direct/c69667c4dff9bc12/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/decoy-removed/clean-target/debug/build/workspaces/885b0057aa6d2f45/v2-d0c834503776741f/hold_direct/c69667c4dff9bc12/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
