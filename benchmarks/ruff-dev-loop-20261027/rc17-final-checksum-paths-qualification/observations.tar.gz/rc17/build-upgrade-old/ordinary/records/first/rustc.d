/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/ordinary/target/debug/build/workspaces/c0b44346e5aea8d7/v2-ac141e23aeba2095/hold_direct/4cd8f8439bd2a545/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/ordinary/target/debug/build/workspaces/c0b44346e5aea8d7/v2-ac141e23aeba2095/hold_direct/4cd8f8439bd2a545/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/ordinary/target/debug/build/workspaces/c0b44346e5aea8d7/v2-ac141e23aeba2095/hold_direct/4cd8f8439bd2a545/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/ordinary/target/debug/build/workspaces/c0b44346e5aea8d7/v2-ac141e23aeba2095/hold_direct/4cd8f8439bd2a545/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-upgrade-old/ordinary/target/debug/build/workspaces/c0b44346e5aea8d7/v2-ac141e23aeba2095/hold_direct/4cd8f8439bd2a545/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
