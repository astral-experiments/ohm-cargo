# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/decoy/target/debug/build/workspaces/8e54eab1def56aa0/v2-b4e57510867c5b27/hold_direct/a8c910a2d0a513c0/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/decoy/target/debug/build/workspaces/8e54eab1def56aa0/v2-b4e57510867c5b27/hold_direct/a8c910a2d0a513c0/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/decoy/target/debug/build/workspaces/8e54eab1def56aa0/v2-b4e57510867c5b27/hold_direct/a8c910a2d0a513c0/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/decoy/target/debug/build/workspaces/8e54eab1def56aa0/v2-b4e57510867c5b27/hold_direct/a8c910a2d0a513c0/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/decoy/target/debug/build/workspaces/8e54eab1def56aa0/v2-b4e57510867c5b27/hold_direct/a8c910a2d0a513c0/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
