# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/no-decoy/target/debug/build/workspaces/3e5defdeb0dcba2c/v2-316b50a168666893/hold_direct/75089221485b0b0c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/no-decoy/target/debug/build/workspaces/3e5defdeb0dcba2c/v2-316b50a168666893/hold_direct/75089221485b0b0c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/no-decoy/target/debug/build/workspaces/3e5defdeb0dcba2c/v2-316b50a168666893/hold_direct/75089221485b0b0c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/no-decoy/target/debug/build/workspaces/3e5defdeb0dcba2c/v2-316b50a168666893/hold_direct/75089221485b0b0c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-old-fixed/no-decoy/target/debug/build/workspaces/3e5defdeb0dcba2c/v2-316b50a168666893/hold_direct/75089221485b0b0c/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
