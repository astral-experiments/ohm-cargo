fn main(){println!("{}",include_bytes!("../alias space/value.bin")[0]);}
