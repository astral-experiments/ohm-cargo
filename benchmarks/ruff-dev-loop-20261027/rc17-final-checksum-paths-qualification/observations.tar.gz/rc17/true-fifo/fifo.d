# ohm-raw-checksum-paths-v2
fifo.d: app.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/true-fifo/fifo

libapp.rmeta: app.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/true-fifo/fifo

app.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/true-fifo/fifo:
# checksum:sha256=eb5a7a9dc50043ddfcda16107785da59695b558fe517e7c752ae349f8c6cd5f6 file_len:59 app.rs
