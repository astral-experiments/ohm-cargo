#![feature(proc_macro_tracked_path)]
extern crate proc_macro;
#[proc_macro] pub fn mark(_:proc_macro::TokenStream)->proc_macro::TokenStream { proc_macro::tracked::path(std::env::var("TRACK_NAME").unwrap()); proc_macro::TokenStream::new() }