fn main(){println!("{}",d::value());}
