# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-downgrade-fixed/no-decoy/clean-target/debug/build/workspaces/aeb8cd9ce3b94383/v2-7d674c2a7d448001/hold_direct/bae08c937cca93b8/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-downgrade-fixed/no-decoy/clean-target/debug/build/workspaces/aeb8cd9ce3b94383/v2-7d674c2a7d448001/hold_direct/bae08c937cca93b8/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-downgrade-fixed/no-decoy/clean-target/debug/build/workspaces/aeb8cd9ce3b94383/v2-7d674c2a7d448001/hold_direct/bae08c937cca93b8/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-downgrade-fixed/no-decoy/clean-target/debug/build/workspaces/aeb8cd9ce3b94383/v2-7d674c2a7d448001/hold_direct/bae08c937cca93b8/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-downgrade-fixed/no-decoy/clean-target/debug/build/workspaces/aeb8cd9ce3b94383/v2-7d674c2a7d448001/hold_direct/bae08c937cca93b8/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
