# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/decoy/clean-target/debug/build/workspaces/959e4a8d7c995f79/v2-5e3dfde99d0ce768/hold_direct/dd53bc5f8ac11ccc/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/decoy/clean-target/debug/build/workspaces/959e4a8d7c995f79/v2-5e3dfde99d0ce768/hold_direct/dd53bc5f8ac11ccc/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/decoy/clean-target/debug/build/workspaces/959e4a8d7c995f79/v2-5e3dfde99d0ce768/hold_direct/dd53bc5f8ac11ccc/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/decoy/clean-target/debug/build/workspaces/959e4a8d7c995f79/v2-5e3dfde99d0ce768/hold_direct/dd53bc5f8ac11ccc/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/decoy/clean-target/debug/build/workspaces/959e4a8d7c995f79/v2-5e3dfde99d0ce768/hold_direct/dd53bc5f8ac11ccc/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
