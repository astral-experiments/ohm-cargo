# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/no-decoy/clean-target/debug/build/workspaces/b12e3d4443faacd3/v2-26e618c066fcdd27/hold_direct/254e313a6bc71cb7/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/no-decoy/clean-target/debug/build/workspaces/b12e3d4443faacd3/v2-26e618c066fcdd27/hold_direct/254e313a6bc71cb7/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/no-decoy/clean-target/debug/build/workspaces/b12e3d4443faacd3/v2-26e618c066fcdd27/hold_direct/254e313a6bc71cb7/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/no-decoy/clean-target/debug/build/workspaces/b12e3d4443faacd3/v2-26e618c066fcdd27/hold_direct/254e313a6bc71cb7/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/build-fixed-fixed/no-decoy/clean-target/debug/build/workspaces/b12e3d4443faacd3/v2-26e618c066fcdd27/hold_direct/254e313a6bc71cb7/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
