# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/ab/empty-target/debug/build/workspaces/944cea62bd34d4eb/v2-d7b508f1feda941c/hold_direct/afe725596bfa885b/out/hold_direct-afe725596bfa885b.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/ab/empty-target/debug/build/workspaces/944cea62bd34d4eb/v2-d7b508f1feda941c/hold_direct/afe725596bfa885b/out/hold_direct-afe725596bfa885b.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/ab/empty-target/debug/build/workspaces/944cea62bd34d4eb/v2-d7b508f1feda941c/hold_direct/afe725596bfa885b/out/libhold_direct-afe725596bfa885b.rmeta: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/ab/empty-target/debug/build/workspaces/944cea62bd34d4eb/v2-d7b508f1feda941c/hold_direct/afe725596bfa885b/out/hold_direct-afe725596bfa885b.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/ab/empty-target/debug/build/workspaces/944cea62bd34d4eb/v2-d7b508f1feda941c/hold_direct/afe725596bfa885b/out/hold_direct-afe725596bfa885b.d/ohm-foreign-span-bytes:
# checksum:blake3=096afc73108ff9e47dcf22918572bd8a6312e4de49e8f4f6338f02381e088edc file_len:354 hold_direct/src/main.rs
