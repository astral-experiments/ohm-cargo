# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/only-valid/empty-target/debug/build/workspaces/74dec078c62474cf/v2-dc4947f034c8a550/hold_direct/72ffd64776eb3b76/out/hold_direct-72ffd64776eb3b76.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/only-valid/empty-target/debug/build/workspaces/74dec078c62474cf/v2-dc4947f034c8a550/hold_direct/72ffd64776eb3b76/out/hold_direct-72ffd64776eb3b76.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/only-valid/empty-target/debug/build/workspaces/74dec078c62474cf/v2-dc4947f034c8a550/hold_direct/72ffd64776eb3b76/out/libhold_direct-72ffd64776eb3b76.rmeta: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/only-valid/empty-target/debug/build/workspaces/74dec078c62474cf/v2-dc4947f034c8a550/hold_direct/72ffd64776eb3b76/out/hold_direct-72ffd64776eb3b76.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/gates-v4/rc17/unicode-check-fixed-fixed/only-valid/empty-target/debug/build/workspaces/74dec078c62474cf/v2-dc4947f034c8a550/hold_direct/72ffd64776eb3b76/out/hold_direct-72ffd64776eb3b76.d/ohm-foreign-span-bytes:
# checksum:blake3=d3d7702eed817a5c2c6d6db7cc3982ca855859ecd14ed2e60fcd2058f6f64471 file_len:329 hold_direct/src/main.rs
