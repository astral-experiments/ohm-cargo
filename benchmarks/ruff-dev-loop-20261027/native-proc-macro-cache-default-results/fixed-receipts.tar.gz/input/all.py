from pathlib import Path
import subprocess,sys
src=Path(__file__).resolve().parent
after=Path('/dev/shm/ohm-ron-consumed-v1-20261028/target-derive-guard/debug/cargo')
for args in [[],[str(after),'583b85bda8785951173a00ab3d0f8abb7cb3b7c8fe8f15518f057f46e6c50956']]:subprocess.run(['/usr/bin/python3','-IB',str(src/'run.py'),*args],check=True)
(src.parent/'terminal.ok').write_text('all seven two-timestamp routes complete\n')
