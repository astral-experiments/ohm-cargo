from pathlib import Path
import subprocess
src=Path(__file__).resolve().parent
subprocess.run(['/usr/bin/python3','-IB',str(src/'run.py'),'/dev/shm/ohm-ron-consumed-v1-20261028/target-default-guard/debug/cargo','5e37d20fa6f79cfcc5a273fb7a95eb19f7239ba750c8a3d1aeaedb90171cdd36'],check=True)
(src.parent/'terminal.ok').write_text('all four two-timestamp V2 routes complete\n')
