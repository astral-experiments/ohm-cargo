import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
src=Path(__file__).resolve().parent;base=src.parent
official=Path('/dev/shm/ohm-published-member-h2-20261028/installed17')
prior=Path('/mnt/devbox-scratch/dev-user/ohm-observer-consumption-tools-20261028/fixed-cargo')
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert h(prior)=='0aa04df8023984b83ef676d1494d43e482472e1b2bccdb82a4d0bd390578a322'
assert h(official/'bin/rustc')=='7ec5263869aed2fc9272ea7212aabbe7b272a4685f1b79af75c123daff09c02c'
assert h(next((official/'lib').glob('librustc_driver-*.so')))=='618ebac16b7d4ec01a2af89661d25b8f26ff347edbb69c6dcaa78f10115914a7'
def stage(a):
    sdk=base/a/'active-sdk';(sdk/'bin').mkdir(parents=True)
    for item in official.iterdir():
        if item.name!='bin':(sdk/item.name).symlink_to(item,target_is_directory=item.is_dir())
    for item in (official/'bin').iterdir():
        dest=sdk/'bin'/item.name
        if item.name=='rustc':shutil.copy2(item,dest)
        elif item.name=='cargo':dest.symlink_to(prior)
        else:dest.symlink_to(item)
    return sdk
def run(mode,first,cache,phases,old,after):
    assert shutil.disk_usage(base).free>5*2**30
    arm=base/mode;arm.mkdir()
    sdk=stage(mode)
    argv=['taskset','-c','24-25','bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/dev/shm','/dev/shm','--proc','/proc','--tmpfs','/tmp','--bind',str(base),str(base),'--','/usr/bin/python3','-IB',str(src/'exercise.py'),'--root',str(arm/'cases'),'--sdk',str(sdk)]
    env=os.environ|dict(CARGO_BEFORE=str(prior),CARGO_AFTER=str(after),NO_PM_CACHE=str(int(cache)),FIRST_OBSERVER=str(int(first)),RUN_PHASES=phases,OLD_PHASES=old)
    with (arm/'log').open('xb') as out:
        p=subprocess.run(argv,env=env,stdout=out,stderr=subprocess.STDOUT)
    assert p.returncode==0,(mode,p.returncode,(arm/'log').read_text()[-5500:]);print(mode,(arm/'cases/complete.json').read_text(),flush=True)
if len(sys.argv)==1:
    phases='initial,repeat,again,clean'
    for name,first,cache in [('known-default',0,0),('new-default',1,0),('new-explicit-no-cache',1,1)]:
        run(name,first,cache,phases,phases,prior)
else:
    after=Path(sys.argv[1]);assert h(after)==sys.argv[2]
    phases='initial,repeat,again,clean'
    for name,first,old,route in [
        ('candidate-known',0,'',phases),('candidate-first',1,'',phases),
        ('upgrade-known-already-stale',0,'initial,repeat,again','initial,repeat,again,upgrade,up-again,clean'),
        ('upgrade-first',1,'initial','initial,repeat,again,clean')]:
        run(name,first,0,route,old,after)
