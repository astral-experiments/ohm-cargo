# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-first/cases/dso-preserved/warm/target/debug/build/workspaces/b6efa825727b1e7d/v2-c5793669db7e6531/hold_direct/3ff2738579ce49cc/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-first/cases/dso-preserved/warm/target/debug/build/workspaces/b6efa825727b1e7d/v2-c5793669db7e6531/hold_direct/3ff2738579ce49cc/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-first/cases/dso-preserved/warm/target/debug/build/workspaces/b6efa825727b1e7d/v2-c5793669db7e6531/hold_direct/3ff2738579ce49cc/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-first/cases/dso-preserved/warm/target/debug/build/workspaces/b6efa825727b1e7d/v2-c5793669db7e6531/hold_direct/3ff2738579ce49cc/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-first/cases/dso-preserved/warm/target/debug/build/workspaces/b6efa825727b1e7d/v2-c5793669db7e6531/hold_direct/3ff2738579ce49cc/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
