# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/78f8e50d0b4839d8/v2-c0373c1aa9c23afd/hold_direct/de188ed41dedca77/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/78f8e50d0b4839d8/v2-c0373c1aa9c23afd/hold_direct/de188ed41dedca77/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-default-guard-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/78f8e50d0b4839d8/v2-c0373c1aa9c23afd/hold_direct/de188ed41dedca77/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/78f8e50d0b4839d8/v2-c0373c1aa9c23afd/hold_direct/de188ed41dedca77/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/78f8e50d0b4839d8/v2-c0373c1aa9c23afd/hold_direct/de188ed41dedca77/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
