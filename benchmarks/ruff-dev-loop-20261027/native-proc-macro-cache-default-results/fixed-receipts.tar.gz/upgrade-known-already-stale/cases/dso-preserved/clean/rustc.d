# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-known-already-stale/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/e52039326e791a40/v2-9fe7cb69a2487610/hold_direct/9721e579775b7661/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-known-already-stale/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/e52039326e791a40/v2-9fe7cb69a2487610/hold_direct/9721e579775b7661/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-known-already-stale/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/e52039326e791a40/v2-9fe7cb69a2487610/hold_direct/9721e579775b7661/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-known-already-stale/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/e52039326e791a40/v2-9fe7cb69a2487610/hold_direct/9721e579775b7661/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-default-guard-20261028/upgrade-known-already-stale/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/e52039326e791a40/v2-9fe7cb69a2487610/hold_direct/9721e579775b7661/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
