# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/new-explicit-no-cache/cases/dso-preserved/warm/target/debug/build/workspaces/77cde80e1852bedf/v2-4a482658b32081ce/hold_direct/e4f9383812c6a535/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/new-explicit-no-cache/cases/dso-preserved/warm/target/debug/build/workspaces/77cde80e1852bedf/v2-4a482658b32081ce/hold_direct/e4f9383812c6a535/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/new-explicit-no-cache/cases/dso-preserved/warm/target/debug/build/workspaces/77cde80e1852bedf/v2-4a482658b32081ce/hold_direct/e4f9383812c6a535/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/new-explicit-no-cache/cases/dso-preserved/warm/target/debug/build/workspaces/77cde80e1852bedf/v2-4a482658b32081ce/hold_direct/e4f9383812c6a535/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/new-explicit-no-cache/cases/dso-preserved/warm/target/debug/build/workspaces/77cde80e1852bedf/v2-4a482658b32081ce/hold_direct/e4f9383812c6a535/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
