# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-known/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/46260131a3afa9b4/v2-b39e9f13c781fdfb/hold_direct/19faf11f4192a000/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-known/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/46260131a3afa9b4/v2-b39e9f13c781fdfb/hold_direct/19faf11f4192a000/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-known/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/46260131a3afa9b4/v2-b39e9f13c781fdfb/hold_direct/19faf11f4192a000/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-known/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/46260131a3afa9b4/v2-b39e9f13c781fdfb/hold_direct/19faf11f4192a000/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-known/cases/dso-preserved/fresh-independent/target/debug/build/workspaces/46260131a3afa9b4/v2-b39e9f13c781fdfb/hold_direct/19faf11f4192a000/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
