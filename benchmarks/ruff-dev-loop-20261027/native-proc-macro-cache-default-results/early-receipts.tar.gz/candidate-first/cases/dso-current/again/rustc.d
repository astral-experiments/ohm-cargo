# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/a9506e6670d59c5a/v2-3b5c80b6ecf29ad0/hold_direct/cc507aafbe1aa299/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/a9506e6670d59c5a/v2-3b5c80b6ecf29ad0/hold_direct/cc507aafbe1aa299/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/a9506e6670d59c5a/v2-3b5c80b6ecf29ad0/hold_direct/cc507aafbe1aa299/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/a9506e6670d59c5a/v2-3b5c80b6ecf29ad0/hold_direct/cc507aafbe1aa299/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-ron-derive-migration-rustc-scout-v2-20261028/candidate-first/cases/dso-current/warm/target/debug/build/workspaces/a9506e6670d59c5a/v2-3b5c80b6ecf29ad0/hold_direct/cc507aafbe1aa299/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
