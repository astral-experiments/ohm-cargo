"""Exercise the matched dev controls and the explicit unstable cache on the same native fixture."""
import sys
from pathlib import Path
source = Path(__file__).with_name('run.py').read_text()
source = source[:source.index('if len(sys.argv)==1:')]
needle = "    c=work/'driver/native.c'"
assert source.count(needle) == 1
source = source.replace(needle, "    if name.endswith('explicit-cache'):\n        env['RUSTFLAGS']='-Zcache-proc-macros'\n" + needle)
exec(compile(source, __file__, 'exec'))
shared = Path('/dev/shm/ohm-ron-consumed-v1-20261028')
exercise('matched-parent', shared/'target-default-control/debug/cargo', '45207a4096dad4461f68445741488a273111a1811ae56e2a75a2bb7a2bf98786')
exercise('candidate-explicit-cache', shared/'target-default-guard/debug/cargo', '5e37d20fa6f79cfcc5a273fb7a95eb19f7239ba750c8a3d1aeaedb90171cdd36')
