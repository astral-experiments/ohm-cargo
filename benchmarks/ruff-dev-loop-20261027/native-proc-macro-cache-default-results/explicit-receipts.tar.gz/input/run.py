from pathlib import Path
import ast,hashlib,json,os,re,shutil,struct,subprocess,sys
src=Path(__file__).resolve().parent;base=src.parent
actual=Path('/dev/shm/ohm-published-member-h2-20261028/installed17')
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def sh(buf):return hashlib.sha256(buf).hexdigest()
def save(p,o):p.write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
def sections(p):
    b=p.read_bytes();hdr=struct.unpack_from('<16sHHIQQQIHHHHHH',b,0);taboff=hdr[6];size,count,names=hdr[11:14]
    ss=[struct.unpack_from('<IIQQQQIIQQ',b,taboff+size*i) for i in range(count)]
    noff,nlen=ss[names][4:6];ns=b[noff:noff+nlen]
    return {n:sh(b[a[4]:a[4]+a[5]]) for a in ss if (n:=ns[a[0]:].split(b'\0',1)[0].decode()) in ('.text','.rustc','.dynsym')}
def exercise(name,cargo,expected):
    assert h(cargo)==expected
    arm=base/name;arm.mkdir();work=arm/'source';shutil.copytree(src/'fixture',work);sdk=arm/'sdk';(sdk/'bin').mkdir(parents=True)
    for item in actual.iterdir():
        if item.name!='bin':(sdk/item.name).symlink_to(item,target_is_directory=item.is_dir())
    for item in (actual/'bin').iterdir():
        if item.name=='rustc':shutil.copy2(item,sdk/'bin/rustc')
        elif item.name=='cargo':(sdk/'bin/cargo').symlink_to(cargo)
        else:(sdk/'bin'/item.name).symlink_to(item)
    assert h(sdk/'bin/rustc')=='7ec5263869aed2fc9272ea7212aabbe7b272a4685f1b79af75c123daff09c02c' and h(next((sdk/'lib').glob('librustc_driver-*.so')))=='618ebac16b7d4ec01a2af89661d25b8f26ff347edbb69c6dcaa78f10115914a7'
    rustup=arm/'rustup';(rustup/'toolchains').mkdir(parents=True);(rustup/'toolchains/ohm').symlink_to(sdk)
    env=dict(PATH=os.environ['PATH'],HOME=str(arm),RUSTUP_HOME=str(rustup),RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(arm/'cargo-home'),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',LANG='C.UTF-8')
    c=work/'driver/native.c';rs=work/'reader/src/main.rs';original_c=c.read_bytes();original_rs=rs.read_bytes();out={}
    for phase in ['prime','prime-again','c-edit','c-edit-again','reader-edit','reader-edit-again','empty-edited','restore','restore-again','empty-restored']:
        if phase=='c-edit':c.write_bytes(original_c.replace(b'17',b'29'))
        if phase=='reader-edit':rs.write_bytes(original_rs+b'const _EDIT: () = ();\n')
        if phase=='restore':c.write_bytes(original_c);rs.write_bytes(original_rs)
        place=arm/('history' if not phase.startswith('empty') else phase)
        env.update(CARGO_TARGET_DIR=str(place/'target'),CARGO_BUILD_BUILD_DIR=str(place/'shared'))
        rec=arm/phase;rec.mkdir(exist_ok=True)
        av=['taskset','-c','24-25','strace','-ff','-qq','-s','65535','-e','trace=execve','-o',str(rec/'exec'),'cargo','+ohm','build','--offline','-p','plain_reader','--message-format=json']
        with (rec/'stdout').open('wb') as so,(rec/'stderr').open('wb') as se:p=subprocess.run(av,cwd=work,env=env,stdout=so,stderr=se,timeout=100)
        assert p.returncode==0,(phase,(rec/'stderr').read_text()[-1700:])
        events=[json.loads(line) for line in (rec/'stdout').read_bytes().splitlines()];assert events[-1]==dict(reason='build-finished',success=True)
        arts=[e for e in events if e['reason']=='compiler-artifact'];a,=[e for e in arts if e['target']['name']=='plain_reader'];m,=[e for e in arts if e['target']['name']=='native_derive'];f=Path(m['filenames'][0]);elf=Path(a['executable'])
        rows=[];others=[] 
        for trace in rec.glob('exec.*'):
            for l in trace.read_text().splitlines():
                z=re.match(r'execve\(("(?:\\.|[^"])*"), (\[.*?\]), [^)]*\)\s+= 0$',l)
                if not z:continue
                path=Path(ast.literal_eval(z[1]));arg=ast.literal_eval(z[2])
                if path.name=='rustc' and '--crate-name' in arg and arg[arg.index('--crate-name')+1]!='___':
                    rows.append({'crate':arg[arg.index('--crate-name')+1],'full':'link-only' not in arg and '-Zlink-only' not in arg,'argv':arg})
                elif path.name in ('wild','wild-ld','ld.bfd','cc','ar','build-script-build'):others.append({'tool':path.name,'argv_sha256':sh(l.encode())})
        native=[f for f in [*(place/'target').rglob('native.o'),*(place/'shared').rglob('native.o')] if f.is_file()]
        deps=[v for v in [*(place/'target').rglob('plain_reader*.d'),*(place/'shared').rglob('plain_reader*.d')] if v.is_file()]
        res={'value':int(subprocess.check_output([elf],cwd=work,env=env)),'cargo':expected,'rustc':h(sdk/'bin/rustc'),'src_c':h(c),'src_reader':h(rs),'native_macro':h(f),'native_sections':sections(f),'executable':h(elf),'fresh':{e['target']['name']:e['fresh'] for e in arts},'rustcs':rows,'others':others,'object':{str(v):h(v) for v in native},'raw_deps':{str(v):[h(v),b'ohm-foreign-span' in v.read_bytes()] for v in deps}}
        assert all(not mark for _,mark in res['raw_deps'].values()),phase
        out[phase]=res;save(rec/'result.json',res)
    assert out['prime']['value']==out['empty-restored']['value']==17 and out['empty-edited']['value']==29
    assert out['prime']['native_sections']['.rustc']==out['c-edit']['native_sections']['.rustc'] and out['prime']['native_sections']['.text']!=out['c-edit']['native_sections']['.text']
    save(arm/'complete.json',out);print(name,{k:(v['value'],[t['crate'] for t in v['rustcs']]) for k,v in out.items()},flush=True)
if len(sys.argv)==1:
    exercise('shipping',actual/'bin/cargo','4e4065390403afbf4fb77b2f41fbc21c59afe3dda2337a5bbe29fda29a47dbb3')
    exercise('pr261',Path('/mnt/devbox-scratch/dev-user/ohm-observer-consumption-tools-20261028/fixed-cargo'),'0aa04df8023984b83ef676d1494d43e482472e1b2bccdb82a4d0bd390578a322')
else:exercise(sys.argv[1],Path(sys.argv[2]),sys.argv[3])
