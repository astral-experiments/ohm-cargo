from pathlib import Path
import hashlib,json,os,subprocess
f=Path("/dev/shm/ohm-ron-derive-checked-suite-20261028");s=Path("/dev/shm/ohm-ron-consumed-v1-20261028")
h=lambda p:hashlib.file_digest(p.open("rb"),"sha256").hexdigest()
events=[json.loads(l) for l in (f/"build.stdout").read_bytes().splitlines()]
exe,=[Path(e["executable"]) for e in events if e.get("executable") and e["target"]["name"]=="testsuite"]
cargobin=f/"target/debug/cargo";assert cargobin.is_file();result=[]
arms=[("parent",s/"target-default-control/debug/cargo"),("v2",s/"target-default-guard/debug/cargo")]
for arm,image in arms:
    name="rustflags::ohm_defaults_reexpand_derive_after_native_input_changes"
    sub=["--exact",name,"--nocapture","--test-threads=1"]
    groups=[("native",sub)]
    if arm=="v2":groups.append(("rustflags",["rustflags::","--test-threads=1"]))
    for label,flags in groups:
        log=f/(arm+"-"+label+".log")
        cmd=["taskset","-c","24-25","bwrap","--die-with-parent","--ro-bind","/","/","--dev","/dev","--ro-bind","/dev/shm","/dev/shm","--proc","/proc","--tmpfs","/tmp","--bind",str(f),str(f),"--ro-bind",str(image),str(cargobin),"--","strace","-qq","-ff","-s","16384","-e","trace=execve","-o",str(f/(arm+"-"+label+"-exec")),str(exe),*flags] if label=="native" else ["taskset","-c","24-25","bwrap","--die-with-parent","--ro-bind","/","/","--dev","/dev","--ro-bind","/dev/shm","/dev/shm","--proc","/proc","--tmpfs","/tmp","--bind",str(f),str(f),"--ro-bind",str(image),str(cargobin),"--",str(exe),*flags]
        with log.open("wb") as o:p=subprocess.run(cmd,stdout=o,stderr=subprocess.STDOUT,timeout=1100)
        result.append(dict(arm=arm,group=label,actual_cargo=h(image),suite=h(exe),rc=p.returncode,log_sha256=h(log)))
        (f/"checked.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
        assert (p.returncode==0)==(arm=="v2"),(arm,label,p.returncode,log.read_text()[-2500:])
print(json.dumps(result),flush=True)
