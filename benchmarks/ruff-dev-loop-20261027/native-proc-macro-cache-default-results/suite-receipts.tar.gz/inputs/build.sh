set -euo pipefail
F=/dev/shm/ohm-ron-derive-checked-suite-20261028
D=/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028
S=/dev/shm/ohm-ron-consumed-v1-20261028
R=$F/inputs
A=$S/target-default-control/debug/cargo
B=$S/target-default-guard/debug/cargo
test "$(df -B1 --output=avail /dev/shm | tail -1)" -gt 10000000000
test "$(sha256sum "$D/source.tgz" | cut -d' ' -f1)" = ba4b5ad6b694e42296ece1a6b52d6c29a283c0fba67c96c8a92f47d871078931
test "$(sha256sum "$A" | cut -d' ' -f1)" = 45207a4096dad4461f68445741488a273111a1811ae56e2a75a2bb7a2bf98786
test "$(sha256sum "$B" | cut -d' ' -f1)" = 5e37d20fa6f79cfcc5a273fb7a95eb19f7239ba750c8a3d1aeaedb90171cdd36
mkdir "$F/src" "$F/target" "$F/shared" "$F/home"
tar -xzf "$D/source.tgz" -C "$F/src"
cd "$F/src"
git apply "$R/with-test.patch"
test "$(sha256sum src/compiler/mod.rs | cut -d' ' -f1)" = 8b9b506316854f5e974ae0bf27e2420a3860c4d28ef0bde5df8a1b67f15987a2
cp -a "$S/cargo-builder/." "$F/home/"
export CARGO_TARGET_DIR="$F/target" CARGO_BUILD_BUILD_DIR="$F/shared" CARGO_HOME="$F/home" CARGO_NET_OFFLINE=true
export RUSTUP_HOME="$S/joins/rustup" RUSTUP_TOOLCHAIN=ohm RUSTUP_AUTO_INSTALL=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0 CFG_RELEASE_CHANNEL=dev
unset CARGO_ENCODED_RUSTFLAGS RUSTFLAGS RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST
export PATH="/home/dev-user/.cargo/bin:$PATH"
set +e
taskset -c 24-25 cargo +ohm test --offline --locked -p cargo --test testsuite --features ohm-defaults --no-run --message-format=json -j2 > "$F/build.stdout" 2> "$F/build.stderr"
RC=$?
set -e
echo "$RC" > "$F/build.exit"
test "$RC" = 0
python3 -IB "$R/test.py"
