import hashlib,json,os,subprocess
from pathlib import Path
p=Path('/mnt/devbox-scratch/dev-user/ohm-derive-cache-ci-toolchain-20261028');f=Path('/dev/shm/ohm-ron-derive-checked-suite-20261028');s=Path('/dev/shm/ohm-ron-consumed-v1-20261028');
h=lambda f:hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
events=map(json.loads,(f/'build.stdout').read_bytes().splitlines());exe,=[v['executable'] for v in events if v.get('executable') and v['target']['name']=='testsuite'];out={}
for arm,cargo in [('parent',s/'target-default-control/debug/cargo'),('fixed',s/'target-default-guard/debug/cargo')]:
 argv=['taskset','-c','24-25','bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/dev/shm','/dev/shm','--proc','/proc','--tmpfs','/tmp','--bind',str(p),str(p),'--bind',str(f/'target/tmp'),str(f/'target/tmp'),'--ro-bind',str(cargo),str(f/'target/debug/cargo'),'--chdir',str(f/'src'),'--','strace','-ff','-qq','-s','16384','-e','trace=execve','-o',str(p/(arm+'-exec')),exe,'--exact','rustflags::ohm_defaults_reexpand_derive_after_native_input_changes','--nocapture','--test-threads=1']
 with (p/(arm+'.log')).open('wb') as fd: q=subprocess.run(argv,stdout=fd,stderr=subprocess.STDOUT,timeout=180)
 out[arm]={'cargo':h(cargo),'suite':h(Path(exe)),'exit':q.returncode,'log_sha256':h(p/(arm+'.log'))};(p/'complete.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
