"""Resume the completed native cold compilation after verifying each original file and the actual serialized format."""
import collections,fcntl,hashlib,inspect,json,os,subprocess,sys,traceback
from pathlib import Path
directory=Path(__file__).resolve().parent; root=directory.parent
sys.path.insert(0,str(root/'bin'))
import validate as q

def verify_original():
    assert (root/'run.rc').read_text().strip()=='1' and 'encoded[5]==4' in (root/'failure.txt').read_text()
    for l in (directory/'previous.sha256').read_text().splitlines():
        dig,sep,rel=l.partition('  ');assert sep and q.sha(directory/rel)==dig,(rel,dig)
    assert q.sha(q.O/'phase-0'/'ron.d')=='bfa6917ac4f41b97232a22ec7996d040e52e16c64f305420564e8faac091eb4e'
    assert q.sha(q.O/'phase-0'/'ron-encoded')=='79eb0cd174c15b3f27d29cf8d76792e4af6d8905de4ea7c1065316e6e7e95743'
    b=(q.O/'phase-0'/'ron-encoded').read_bytes(); assert len(b)==3685 and b[5]==2 and b.rfind(b'OBS1')==len(b)-41 and b[-33]==0
    assert sum(l.startswith(b'# checksum:') for l in (q.O/'phase-0'/'ron.d').read_bytes().splitlines())==0
    assert not (q.O/'phase-1').exists()

def adapt():
    source=inspect.getsource(q.run_phase)
    def change(old,new):
        nonlocal source
        assert source.count(old)==1,old;source=source.replace(old,new)
    change("d=O/('phase-'+str(n));d.mkdir();(d/'trace').mkdir();env=environment();", """d=O/('phase-'+str(n))
    if n: d.mkdir();(d/'trace').mkdir()
    else: assert (d/'trace').is_dir()
    env=environment();""")
    change("    watch(argv,WT,env,d)","    if n: watch(argv,WT,env,d)")
    change("    r=products(d,T,lambda unused,s:Path(s),command,command);execs=set(r['executables']);audit=processes(d,SDK,execs)", """    if n:
        r=products(d,T,lambda unused,s:Path(s),command,command);execs=set(r['executables']);audit=processes(d,SDK,execs)
    else:
        r=json.loads((d/'product.json').read_bytes());execs=set(r['executables']);audit=json.loads((d/'native-processes.json').read_bytes())
        # Rehash each output before issuing another Cargo command, plus every immutable process trace.
        assert all(sha(Path(key))==h for key,h in r['native'].items())
        assert all(sha(d/'trace'/key)==h for key,h in json.loads((d/'trace-files.json').read_bytes()).items())""")
    change("    (d/'ron.d').write_bytes(text);(d/'ron-encoded').write_bytes(encoded);index=encoded.rfind(b'OBS1')","""    for name,raw in [('ron.d',text),('ron-encoded',encoded)]:
        f=d/name
        if n:f.write_bytes(raw)
        else:assert f.read_bytes()==raw
    index=encoded.rfind(b'OBS1')""")
    change("encoded[5]==4","encoded[5]==(4 if any(s.startswith(b'# checksum:') for s in text.splitlines()) else 2)")
    env=dict(q.__dict__);exec(compile(source,'verified-patched-phase','exec'),env)
    return env['run_phase']

def main():
    assert all(q.sha(root/k)==v for k,v in json.loads((root/'runner-files.json').read_bytes()).items())
    assert q.sha(q.HERE/'validate.py')==json.loads((root/'runner-files.json').read_bytes())['bin/validate.py']
    verify_original();q.capacity();os.sched_setaffinity(0,set(range(16)))
    earlier=json.loads((q.O/'preflight.json').read_bytes());alias=q.version_and_alias();head=q.validate_source()
    assert head==earlier['source'] and alias==earlier['global_alias'];bind,prov=q.artifacts();assert bind==earlier['package']
    phase=adapt();rows=[];prev=last=None;settled=0
    for i in range(6):
        r,detail,s=phase(i)
        if prev is not None:
            assert s['listed']==rows[0]['listed'] and s['roster']==rows[0]['roster'] and s['diagnostics']==rows[0]['diagnostics'] and r['native'].keys()==prev.keys()
            diff=[k for k,v in r['native'].items() if prev[k]!=v]
            s['raw_native_matches']=110-len(diff);s['prior_native_differences']=[dict(name=Path(k).name,previous=last[k]['raw'],current=detail[k]['raw'],only_known_wild_fields=q.permitted_linker_width(last[k],detail[k])) for k in diff]
            if s['fresh']==619:
                assert not diff and s['real_jobs']['rustc']=={} and s['real_jobs']['wild']==s['real_jobs']['system']==0 and s['ron_complete'];settled+=1
            else:settled=0
        else:assert s['fresh']==0 and s['real_jobs']['rustc'].get('full',0)>600 and s['real_jobs']['wild']>0
        rows.append(s);prev=r['native'];last=detail;q.put(q.O/('phase-'+str(i))/'summary.json',s)
        if settled==2:break
    assert settled==2 and q.validate_source()==head and q.version_and_alias()==alias
    original={rel.lstrip('./'):digest for l in (directory/'previous.sha256').read_text().splitlines() for digest,rel in [l.split('  ')]}
    recovery={'old_assertion':'Expected v4 even with zero stored checksums. Cargo 1.99.0-17 intentionally serializes empty-checksum file lists as v2.','old_exit':1,
      'source':'a0c7d08c898d3fdff992f2f431dec57d2486add2','source_excerpt':q.sha(directory/'cargo-format-contract.txt'),'old_runner':q.sha(root/'runner-files.json'),
      'resumed_runner':q.sha(Path(__file__)),'original_commitments':original,'cold_reexecutions':0,'unchanged_commands':len(rows)-1,
      'all_110_original_cold_elf_bytes_rechecked':True,'all_original_process_traces_rechecked':True}
    q.put(q.O/'postprocess-recovery.json',recovery)
    q.put(q.O/'complete.json',{'release':bind,'installed':json.loads((q.O/'installed.json').read_bytes()),'source':head,'registry':q.digest(json.loads((q.O/'registry-inputs.json').read_bytes())),
              'small':json.loads((q.O/'small-results.json').read_bytes()),'phases':rows,'end_capacity':q.capacity(),'installed_global_alias_before_after_equal':True,'scored_commands':0,'postprocess_recovery':recovery})

if __name__=='__main__':
    try:
        with (q.P/'native-measure.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);main()
    except BaseException:
        (directory/'failure.txt').write_text(traceback.format_exc());raise
