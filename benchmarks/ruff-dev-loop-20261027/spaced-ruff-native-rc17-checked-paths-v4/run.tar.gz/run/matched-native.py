"""Qualify the corrected release-sourced compiler and Cargo on two real Ruff path layouts."""
from pathlib import Path
import collections
import fcntl
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import traceback

p=Path('/mnt/devbox-scratch/dev-user/ohm-spaced-ruff-20261027')
k=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stock_reader',p/'release-discovery-run-v1/capture.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
assets=p.parent/'ohm-observer-shipping-20261027'
arm=json.loads((k/'binding.json').read_bytes())
o=p/('matched-native-'+arm['name'])
git=lambda *xs:subprocess.check_output(['git','--no-optional-locks','-C',a.src,*xs])
def sdk_view():
    native=Path(arm['sdk']);cargo=Path(arm['cargo'])
    new=o/'view';(new/'bin').mkdir(parents=True);(new/'lib').mkdir()
    need=subprocess.check_output(['readelf','-d',str(native/'bin/rustc')],text=True)
    drv,=re.findall(r'Shared library: \[(librustc_driver-[a-f0-9]+\.so)\]',need)
    assert a.sha(native/'bin/rustc')==arm['frontend'] and a.sha(native/'lib'/drv)==arm['driver'] and a.sha(cargo)==arm['cargo_sha']
    for f in native.iterdir():
        if f.name not in ('bin','lib'):(new/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
    for f in (native/'bin').iterdir():
        dst=new/'bin'/f.name
        if f.name in ('cargo','rustc'):shutil.copy2(cargo if f.name=='cargo' else f,dst,follow_symlinks=True)
        else:dst.symlink_to(f.resolve(),target_is_directory=f.is_dir())
    for f in (native/'lib').iterdir():
        dst=new/'lib'/f.name
        if f.name=='rustlib':dst.mkdir()
        elif f.name==drv:shutil.copy2(f,dst,follow_symlinks=True)
        elif not f.name.startswith('librustc_driver-'):dst.symlink_to(f.resolve(),target_is_directory=f.is_dir())
    deps=(native/'lib/rustlib').resolve()
    wild=deps/'x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
    assert a.sha(wild)==arm['wild']
    a.dump(o/'sdk.json',dict(arm=arm,driver=drv,view=str(new),deps=str(deps),wild_sha=a.sha(wild)))
    return new,deps,drv
def snapshot(arts,state,tn):
    reported=sorted({v['executable'] for v in arts if v['executable']})
    native={}
    for row in arts:
        if not row['package_id'].startswith('path+'):continue
        for name in row['filenames']:
            f=Path(name)
            if f.suffix not in ('','.so') or not f.is_relative_to(tn):continue
            rel=f.relative_to(tn);physical=state/'target'/rel
            with physical.open('rb') as file:magic=file.read(4)
            if magic==b'\x7fELF':native[str(rel)]=a.sha(physical)
    assert all(str(Path(x).relative_to(tn)) in native for x in reported)
    return reported,native
def workflow(which,new,deps,drv):
    t=o/which;t.mkdir()
    tn=a.c/('ruff target' if which=='package' else 'ruff-target')
    sdk=a.c/('Ohm-SDK' if which=='package' else 'Ohm SDK');sdk.mkdir(exist_ok=True)
    ru=t/'rustup/toolchains';ru.mkdir(parents=True);(ru/'ohm').symlink_to(sdk,target_is_directory=True)
    state=t/'state';state.mkdir()
    for name in ('home','target','shared'):(state/name).mkdir()
    reg=state/'cargo/registry';reg.mkdir(parents=True)
    for n in ('index','cache'):subprocess.run(['cp','-a','--reflink=auto','--',assets/'assets/registry'/n,reg/n],check=True)
    env=dict(HOME=str(a.c/'home'),USER='dev-user',PATH=str(Path.home()/'.cargo/bin')+':/usr/local/bin:/usr/bin:/bin',
             CARGO_HOME=str(a.c/'cargo'),CARGO_TARGET_DIR=str(tn),CARGO_BUILD_BUILD_DIR=str(a.c/'shared'),CARGO_BUILD_JOBS='4',
             CARGO_NET_OFFLINE='true',RUSTUP_HOME=str(ru.parent),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',
             CARGO_TERM_COLOR='never',GIT_OPTIONAL_LOCKS='0',LANG='C.UTF-8',LC_ALL='C.UTF-8')
    br=['bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp',
        '--ro-bind',str(new),str(sdk),'--ro-bind',str(deps),str(sdk/'lib/rustlib')]
    for n in ('target','shared','home','cargo'):br+=['--bind',str(state/n),str(tn if n=='target' else a.c/n)]
    no_trace=[*br,'--chdir',str(a.src),'--']
    probe=subprocess.run([*no_trace,'rustc','+ohm','--print=sysroot'],env=env,capture_output=True)
    assert probe.returncode==0 and probe.stdout.decode().strip()==str(sdk),(probe.returncode,probe.stdout,probe.stderr)
    logical={str(sdk/'bin/cargo'):arm['cargo_sha'],str(sdk/'bin/rustc'):arm['frontend'],str(sdk/'lib'/drv):arm['driver'],
             str(sdk/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'):arm['wild']}
    sums=subprocess.check_output([*no_trace,'sha256sum',*logical],env=env).decode().splitlines()
    assert {line.split('  ',1)[1]:line.split('  ',1)[0] for line in sums}==logical
    a.dump(t/'sysroot.json',dict(probe=probe.stdout.decode().strip(),hashes=logical))
    cmd=['cargo','+ohm','test','--no-run',*(['-p','ty_project'] if which=='package' else ['--workspace']),
         '--locked','--offline','-j4','--message-format=json']
    history=[]
    for i in range(4):
        assert shutil.disk_usage(p).free>60*2**30
        print(arm['name'],which,i,flush=True)
        dot=t/('call-'+str(i));(dot/'trace').mkdir(parents=True)
        trace=['strace','-ff','-qq','-s','1048576','-e','trace=execve,execveat','-o',str(dot/'trace/exec')]
        with (dot/'stdout').open('xb') as so,(dot/'stderr').open('xb') as se:
            ret=subprocess.run([*br,'--bind',str(dot),str(dot),'--chdir',str(a.src),'--',*trace,*cmd],
                               env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL).returncode
        a.dump(dot/'command.json',dict(code=ret,command=cmd,arm=arm,stdout=a.sha(dot/'stdout'),stderr=a.sha(dot/'stderr')))
        assert ret==0,(which,i,'ordinary Cargo',ret)
        rows=[json.loads(v) for v in (dot/'stdout').read_bytes().splitlines()]
        assert rows[-1]=={'reason':'build-finished','success':True}
        arts=[v for v in rows if v['reason']=='compiler-artifact'];assert len(arts)==(303 if which=='package' else 619)
        exes,native=snapshot(arts,state,tn);assert len(exes)==(1 if which=='package' else 102)
        if which=='workspace':assert len(native)==110
        tools_=a.cmds(dot/'trace');a.dump(dot/'physical.json',tools_)
        assert not set(exes).intersection(tools_['images'])
        proof=a.proof(state);a.dump(dot/'proof.json',proof)
        if which=='package':candidates=exes
        else:
            candidates=[x['executable'] for x in arts if x['executable'] and x['profile']['test'] and x['target']['name']=='e2e' and Path(x['manifest_path']).parent.name=='ty_server']
        exe,=candidates
        oracle=subprocess.run([*no_trace,exe,'--list','--format','terse'],env=env,capture_output=True)
        (dot/'list.stdout').write_bytes(oracle.stdout);(dot/'list.stderr').write_bytes(oracle.stderr)
        assert oracle.returncode==0 and oracle.stdout and b': test' in oracle.stdout
        if which=='workspace':assert b'inlay_hints::default_inlay_hints: test' in oracle.stdout
        item=dict(call=i,units=len(arts),dirty=[v['target']['name'] for v in arts if not v['fresh']],tests_executed=0,
                  rustc=dict(collections.Counter(x['kind'] for x in tools_['jobs'])),wild=len(tools_['wild']),
                  native=native,executables=exes,oracle=a.sha(dot/'list.stdout'),
                  obs=[[(v['has_obs1'],v['status']) for v in x['fingerprints']] for x in proof],
                  trace=a.sha(dot/'physical.json'),proof=a.sha(dot/'proof.json'))
        a.dump(dot/'product.json',item);history.append(item)
        assert git('rev-parse','HEAD').decode().strip()==a.pin and not git('status','--porcelain','-z')
        a.dump(t/'progress.json',history)
    return history
def main():
    assert socket.gethostname()=='charlie-ohm-cargo5-build-1025' and not o.exists()
    assert shutil.disk_usage(p).free>140*2**30
    os.sched_setaffinity(0,set(range(8)))
    with (p/'matched-qualify.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert git('rev-parse','HEAD').decode().strip()==a.pin
        o.mkdir(mode=0o700);new,deps,drv=sdk_view();d={}
        for w in ('package','workspace'):
            d[w]=workflow(w,new,deps,drv)
        a.dump(o/'complete.json',d)
if __name__=='__main__':
    try:main()
    except BaseException:
        if o.is_dir():(o/'failure.txt').write_text(traceback.format_exc())
        raise
