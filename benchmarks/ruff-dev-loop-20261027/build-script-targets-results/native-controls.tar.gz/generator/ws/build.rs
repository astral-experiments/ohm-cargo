fn main(){println!("cargo::rerun-if-changed=trigger.txt");let source=std::fs::read_to_string("trigger.txt").unwrap();let v=source.trim();
std::fs::write(std::path::Path::new(&std::env::var_os("OUT_DIR").unwrap()).join("number.txt"),v).unwrap();
}
