fn main(){println!("{}",env!("SEEN"));}
