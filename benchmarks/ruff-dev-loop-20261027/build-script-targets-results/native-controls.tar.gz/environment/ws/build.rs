fn main(){println!("cargo::rerun-if-changed=trigger.txt");let source=std::fs::read_to_string("trigger.txt").unwrap();let v=source.trim();
println!("cargo::rustc-env=SEEN={}",v);
}
