fn main(){print!("{}",include_str!("../outside.txt"));}
