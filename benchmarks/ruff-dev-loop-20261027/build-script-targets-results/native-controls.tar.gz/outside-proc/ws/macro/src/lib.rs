#![feature(proc_macro_tracked_path)]
extern crate proc_macro;
#[proc_macro]
pub fn outside_value(_:proc_macro::TokenStream)->proc_macro::TokenStream {
 let path=std::env::var("CARGO_MANIFEST_DIR").unwrap()+"/outside.txt";
 proc_macro::tracked::path(&path);
 std::fs::read_to_string(path).unwrap().trim().parse().unwrap()
}
