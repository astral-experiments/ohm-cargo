fn main(){print!("{}",observation_macro::outside_value!());}
