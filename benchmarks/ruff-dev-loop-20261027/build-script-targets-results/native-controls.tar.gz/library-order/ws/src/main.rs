unsafe extern "C"{fn observed_number()->i32;}fn main(){println!("{}",unsafe{observed_number()});}
