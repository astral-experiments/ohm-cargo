int observed_number(void){return 83;}
