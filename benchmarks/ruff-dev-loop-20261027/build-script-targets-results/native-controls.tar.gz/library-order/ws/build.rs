fn main(){println!("cargo::rerun-if-changed=trigger.txt");let source=std::fs::read_to_string("trigger.txt").unwrap();let v=source.trim();

 let path=std::env::current_dir().unwrap().join("native");
 println!("cargo::rustc-link-search=native={}",path.display());
 let names = if v=="41" { ["first","second"] } else { ["second","first"] };
 for n in names { println!("cargo::rustc-link-lib=static={n}"); }

}
