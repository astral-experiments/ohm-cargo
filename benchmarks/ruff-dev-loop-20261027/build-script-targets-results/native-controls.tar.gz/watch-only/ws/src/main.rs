fn main(){println!("41");}
