fn main(){println!("cargo::rerun-if-changed=trigger.txt");let source=std::fs::read_to_string("trigger.txt").unwrap();let v=source.trim();

 use std::process::Command;
 let path=std::env::current_dir().unwrap().join("native");
 let source=path.join("value.c");let object=path.join("value.o");let archive=path.join("libmutable.a");
 std::fs::write(&source,format!("int observed_number(void){{return {v};}}")).unwrap();
 assert!(Command::new("cc").arg("-c").arg(source).arg("-o").arg(&object).status().unwrap().success());
 assert!(Command::new("ar").arg("rcs").arg(archive).arg(object).status().unwrap().success());
 println!("cargo::rustc-link-search=native={}",path.display());println!("cargo::rustc-link-lib=static=mutable");

}
