from pathlib import Path
import os,sys
src=Path(__file__).resolve().with_name('product-tiny.py');text=src.read_text();i=text.index('rows=[]\nphases=')
exec(compile(text[:i],str(src),'exec'))
counts=[]
for stage,n in enumerate([1,2,3,4]):
 if stage:
  for p in (r/'target').rglob('metadata.rmeta'):
   if any(i.startswith('bundle-') for i in p.parts):p.unlink()
 leaf.write_text(base_leaf.replace('V',str(n)));out=run(str(stage),'candidate','bundle');ref=run(str(stage),'reference','bundle');assert [out[k] for k in ['so','meta','embedded','behavior']]==[ref[k] for k in ['so','meta','embedded','behavior']]
 obj=next((r/'target').rglob('libbundle.rlink-objects'));files=list(obj.rglob('*.o'));counts.append({'stage':stage,'phase':out['procs'],'count':len(files),'bytes':sum(f.stat().st_size for f in files)});print(counts[-1],flush=True)
jwrite(r/'growth.json',counts)
