from pathlib import Path
import hashlib,json,re,struct,sys
root=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def extract(path):
 b=path.read_bytes();assert b[:6]==b'\x7fELF\x02\x01';po,so=struct.unpack_from('<QQ',b,32);pz,pn,sz,sn,st=struct.unpack_from('<HHHHH',b,54)
 ph=[struct.unpack_from('<IIQQQQQQ',b,po+i*pz) for i in range(pn)];r=[struct.unpack_from('<IIQQQQIIQQ',b,so+i*sz) for i in range(sn)];t=r[st];stb=b[t[4]:t[4]+t[5]];nam=lambda i:stb[i:stb.index(0,i)].decode();sec={nam(s[0]):s for s in r};anchors={s:(v[1],v[2],v[3],v[5],sha(b[v[4]:v[4]+v[5]]) if v[1]!=8 else None) for s,v in sec.items()}
 sym=sec['.symtab'];strings=r[sym[6]];sb=b[strings[4]:strings[4]+strings[5]];symbols=[]
 for row in range(sym[4],sym[4]+sym[5],sym[9]):
  n,info,other,idx,val,ss=struct.unpack_from('<IBBHQQ',b,row);name=sb[n:sb.index(0,n)].decode(errors='surrogateescape');symbols.append((info,other,idx,val,ss,name))
 return b,ph,sec,anchors,symbols
control=Path('/home/dev-user/.cache/ohm-ruff-cargo-link-skip-20261027/native-span-observer/ruff-sdk-prefetch-corrected-subjects/guardv3');m=Path('/dev/shm/ohm-mixed-certificate-20261027/cargo-v4-compiler')
a=extract(control);ans={}
for name in ['fifo-repeat','fifo-sealed']:
 b=extract(m/name);ad=a[3];bd=b[3];diff=[k for k in sorted(ad.keys()|bd.keys()) if ad.get(k)!=bd.get(k)]
 assert set(diff)<={'.note.gnu.build-id','.strtab','.symtab'} and ad.keys()==bd.keys()
 assert [s[1:] for s in a[1]]==[s[1:] for s in b[1]] and len(a[4])==len(b[4])
 normal=lambda v:re.sub(r'\.llvm\.\d+','.llvm.',v)
 sym=[(r,t) for r,t in zip(a[4],b[4]) if r!=t]
 assert all(r[:5]==t[:5] and normal(r[5])==normal(t[5]) for r,t in sym)
 slices={}
 for k,(typ,flags,addr,size,digest) in ad.items():
  if flags & 2:
   slices[k]={'address':addr,'length':size,'base_sha256':digest,'rebuilt_sha256':bd[k][-1]}
 phdiff=[]
 for i, (typ,flags,off,addr,phys,fsz,msz,align) in enumerate(a[1]):
  if typ!=1:continue
  old=a[0][off:off+fsz];new=b[0][off:off+fsz];deltas=[off+j for j in range(len(old)) if old[j]!=new[j]];note=a[2]['.note.gnu.build-id'];allow_hdr=set(range(40,48));allow_note=set(range(note[4],note[4]+note[5]));assert set(deltas)<=allow_hdr|allow_note,(name,i,deltas[:30])
  phdiff.append({'segment':i,'flags':flags,'offset':off,'filesz':fsz,'memsz':msz,'unexpected_differences':0,'different_section_table_offset_header_bytes':len(set(deltas)&allow_hdr),'different_build_id_note_bytes':len(set(deltas)&allow_note)})
 ans[name]={'base':sha(a[0]),'binary':sha(b[0]),'differing_sections':diff,'symbol_count':len(a[4]),'llvm_private_symbol_names_different':len(sym),'symbol_addresses_sizes_types_identical':True,'alloc_sections':slices,'load_segments':phdiff}
out=root/'final-sources/control-elf-proof.json';out.write_text(json.dumps(ans,indent=2)+'\n')
print([(n,a['binary'],a['llvm_private_symbol_names_different'],a['differing_sections']) for n,a in ans.items()]);print(sha(out.read_bytes()))
