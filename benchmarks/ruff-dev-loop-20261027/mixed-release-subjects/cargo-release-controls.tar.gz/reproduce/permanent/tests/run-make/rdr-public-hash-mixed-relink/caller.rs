fn main() {
    println!("{}", bundle::value());
}
