"""Cancel after manifest invalidation, recover normally, challenge an inactive symlink, and race two legal callers."""
from pathlib import Path
import concurrent.futures as cf,ctypes,os,select,signal,struct,sys,time
source=Path(__file__).resolve().with_name('product-tiny.py')
program=source.read_text().split('rows=[]\nphases=')[0]
needle="p=sp.run(v,env=env,capture_output=True);"
assert program.count(needle)==1
program=program.replace(needle,"p=launch(tag,q,v,env);")
def launch(tag,q,v,en):
 if tag!='interrupted':return sp.run(v,env=en,capture_output=True)
 obj=next((r/'target').rglob('libbundle.rlink-objects'));man=obj.with_suffix('.rlink-cache.json');assert man.is_file()
 libc=ctypes.CDLL(None,use_errno=True);fd=libc.inotify_init1(os.O_CLOEXEC|os.O_NONBLOCK);assert fd>=0
 mask=0x200 # IN_DELETE
 assert libc.inotify_add_watch(fd,os.fsencode(man.parent),mask)>=0
 po=sp.Popen(v,env=en,stdout=sp.PIPE,stderr=sp.PIPE,start_new_session=True);deadline=time.monotonic()+20;events=[];match=False
 while time.monotonic()<deadline and po.poll() is None and not match:
  ready,_,_=select.select([fd],[],[],min(.5,max(0,deadline-time.monotonic())))
  if not ready:continue
  block=os.read(fd,65536);a=0
  while a<len(block):
   wd,flags,cookie,n=struct.unpack_from('iIII',block,a);a+=16;name=os.fsdecode(block[a:a+n].rstrip(b'\0'));a+=n;events.append([name,flags]);match=match or (name==man.name and bool(flags&mask))
 os.close(fd)
 assert match and po.poll() is None,events
 os.killpg(po.pid,signal.SIGKILL);o,e=po.communicate(timeout=20);assert not man.exists() and po.returncode!=0
 (q/'stdout-cancelled').write_bytes(o);(q/'stderr-cancelled').write_bytes(e);jwrite(q/'inotify.json',events);raise InterruptedError()
exec(compile(program,str(source),'exec'))
def vals(n):leaf.write_text(base_leaf.replace('V',str(n)))
def same(x,y):return all(x[k]==y[k] for k in ['meta','embedded','so','symbols','behavior'])
def files():
 obj=next((r/'target').rglob('libbundle.rlink-objects'));return obj,[p for p in obj.iterdir() if p.is_dir() and not p.is_symlink()]
def stable(row):
 obj,slots=files();assert len(slots)==1,(row.name,list(obj.iterdir()))
 paths=sorted(p.relative_to(obj).as_posix() for p in obj.rglob('*.o'));assert paths and all(p.split('/')[0]==slots[0].name for p in paths)
 return [slots[0].name,len(paths)]
rows=[]
for n in [1,2]:
 vals(n);a=run('train'+str(n),'candidate','bundle');b=run('train'+str(n),'reference','bundle');assert same(a,b)
 rows.append(['train'+str(n),a['procs'],stable(r)])
assert ['bundle','checked-link'] in a['procs']
obj,slots=files();outside=r/'outside';outside.mkdir();sentinel=outside/'not-a-cargo-file.o';sentinel.write_bytes(b'untouched')
alternate=obj/('1' if slots[0].name=='0' else '0');assert not alternate.exists();alternate.symlink_to(outside,target_is_directory=True)
# The green metadata work product is selectively evicted, while the recipe stays valid.
for f in (r/'target').rglob('metadata.rmeta'):
 if any(n.startswith('bundle-') for n in f.parts):f.unlink()
vals(3)
try:run('interrupted','candidate','bundle')
except InterruptedError:pass
else:raise AssertionError('cancellation did not occur')
assert sentinel.read_bytes()==b'untouched'
a=run('recovery','candidate','bundle');b=run('recovery','reference','bundle');assert same(a,b) and ['bundle','full'] in a['procs'],(a,b)
rows.append(['recovery',a['procs'],stable(r)]);assert sentinel.read_bytes()==b'untouched'
for n in [4,5]:
 vals(n);a=run('retrain'+str(n),'candidate','bundle');b=run('retrain'+str(n),'reference','bundle');assert same(a,b)
 rows.append(['retrain'+str(n),a['procs'],stable(r)])
assert ['bundle','checked-link'] in a['procs']
# Preserve the outside directory when the next genuine retained-code attempt encounters an inactive symlink.
obj,slots=files();alternate=obj/('1' if slots[0].name=='0' else '0');assert not alternate.exists();alternate.symlink_to(outside,target_is_directory=True)
vals(6)
with cf.ThreadPoolExecutor(2) as pool:
 futures=[pool.submit(run,'concurrent'+str(n),'candidate','bundle') for n in range(2)]
 result=[f.result() for f in futures]
b=run('concurrent-reference','reference','bundle');assert all(same(a,b) for a in result)
xx=sorted(p for a in result for p in a['procs']);assert xx==[['bundle','checked-link'],['leaf','full']],xx
assert sentinel.read_bytes()==b'untouched' and not alternate.exists()
rows.append(['concurrent',xx,stable(r)])
fresh=run('finished-fresh','candidate','bundle');assert not fresh['procs'] and same(fresh,b)
jwrite(r/'verified.json',{'stages':rows,'last':fresh,'sentinel':sentinel.read_text()});print(rows)
