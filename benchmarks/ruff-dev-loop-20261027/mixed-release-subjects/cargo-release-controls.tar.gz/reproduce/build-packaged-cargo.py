from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys
d=Path(__file__).resolve().parent;r=Path('/dev/shm/ohm-mixed-certificate-20261027/cargo-v4-compiler');q=Path('/home/dev-user/code/oss/ohm-mixed-interface-cargo-20261027');label,rev=sys.argv[1:]
assert label in ['fifo-repeat','fifo-sealed','bounded-c1','bounded-repeat']
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def git(*args):return sp.check_output(['git','-C',str(q),*args])
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
out=d/('packaged-'+label);out.mkdir(exist_ok=False);src=r/('tarball-'+label);src.mkdir(exist_ok=False)
assert shutil.disk_usage(r).free>650*2**20
arc=sp.Popen(['git','-C',str(q),'archive','--format=tar',rev],stdout=sp.PIPE)
sp.run(['tar','-xf','-','-C',src],stdin=arc.stdout,check=True);arc.stdout.close();assert arc.wait()==0
stamp='b0a4df740b57589ecec3c83e30d5d326ab52a56d';sf=src/'git-commit-info';sf.write_bytes(git('log','-1','--date=short','--format=%H%n%h%n%cd','--abbrev=9',stamp))
assert sha(sf)=='ad833a45f433b767ab37fe141193fdbe6e33d4bafb7c26cad6779f2ca47150af'
expected=set()
for row in git('ls-tree','-rz',rev).split(b'\0'):
 if not row:continue
 item,raw=row.split(b'\t',1);mode,typ,oid=item.split();p=src/os.fsdecode(raw);expected.add(raw);assert typ==b'blob'
 data=os.fsencode(os.readlink(p)) if mode==b'120000' else p.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==oid
 if mode!=b'120000':assert bool(p.stat().st_mode&0o111)==(mode==b'100755')
actual={os.fsencode(str(p.relative_to(src))) for p in src.rglob('*') if p.is_symlink() or p.is_file()};assert actual==expected|{b'git-commit-info'}
for name in ('build.rs','src/compiler/fingerprint/mod.rs','src/compiler/fingerprint/dep_info.rs','src/compiler/job_queue/job_state.rs','src/compiler/mod.rs','src/ops/cargo_worktree/mod.rs'):os.utime(src/name,None)
rt=Path('/home/dev-user/.cache/ohm-lint-cli-scout-20261026/release14-comparisons/private-rustup/toolchains/ohm')
profile=Path('/home/dev-user/.cache/ohm-ruff-empty-lint-scope-20261026/release/receipts/rustc-pgo.profdata')
assert sha(profile)=='481ada8a40c70dad11b3c7e8871e9a52207d78447ca5e8ace06fc4aec2d2b5a7'
parts=[rt/'bin/rustc',rt/'bin/cargo',*rt.glob('lib/librustc_driver*.so'),profile]
rec={'commit':rev,'root_tree':git('rev-parse',rev+'^{tree}').decode().strip(),'blobs_and_modes':len(expected),'stamp_sha256':sha(sf),'stamp':sf.read_text().splitlines(),'build_inputs':{str(f):sha(f) for f in parts},'source_sha256':{f:sha(src/f) for f in ['Cargo.lock','src/compiler/job_queue/job_state.rs','src/compiler/mod.rs','src/compiler/fingerprint/mod.rs']},'canonical_source':'/home/dev-user/code/oss/ohm-ruff-pgo-study-20261026'}
write(out/'source.json',rec)
bash=(d/'build-product-cargo.sh').read_text();i=bash.index('[[ "$label" ==');j=bash.index('mkdir -p',i);bash=bash[:i]+'''[[ ! -e "$r/$label" && -e "$w/git-commit-info" && ! -e "$w/.git" ]]
'''+bash[j:];bash=bash.replace('w=/home/dev-user/code/oss/ohm-mixed-interface-cargo-20261027','w='+str(src))
if label!='fifo-repeat':
 peer=Path('/dev/shm/ohm-cargo-scout-sdk-pgo-build-20261027')
 for sub,old in [('target','"$target"'),('shared','"$shared"'),('cargo-home','"$cache/registry-home"')]:
  original=(peer/sub).resolve();assert original.is_dir()
  bash=bash.replace('mount_overlay '+sub+' '+old, 'mount_overlay '+sub+' '+str(original))
 bash=bash.replace('views=()', 'exec 8< '+str(peer/'corrected-pgo.lock')+'; flock -s 8\nviews=()')
 bash=bash.replace('--bind "$r/cargo-home/view" "$CARGO_HOME"', '--ro-bind "$cache/registry-home/registry" '+str(peer/'registry-ro')+' --bind "$r/cargo-home/view" "$CARGO_HOME"')
script=out/'build.sh';script.write_text(bash)
with (out/'build.log').open('wb') as f:p=sp.run(['bash',script,label,'8-11'],stdout=f,stderr=sp.STDOUT)
if p.returncode:raise SystemExit((out/'build.log').read_text()[-2000:])
binary=r/label;rec['binary_sha256']=sha(binary);rec['version']=sp.check_output([binary,'-Vv'],text=True).splitlines();assert 'commit-hash: '+stamp in rec['version'] and 'commit-date: 2026-10-27' in rec['version']
write(out/'complete.json',rec);print(label,rec['binary_sha256'],flush=True)
if label in ['fifo-repeat','fifo-sealed']:assert sha(binary)=='dd5cab154b8dcd09ccc2753160d314cade80979b2d055ee66aa9e2217e05e7e1'
