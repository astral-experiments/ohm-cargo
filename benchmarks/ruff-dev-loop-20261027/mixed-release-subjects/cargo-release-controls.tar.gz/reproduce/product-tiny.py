"""Exercise the real negotiated protocol, read actual successful execs, and compare an independent full arm."""
from pathlib import Path
import ast, ctypes, hashlib, json, os, re, shutil, subprocess as sp, sys
r=Path(sys.argv[1]);r.mkdir(exist_ok=False,parents=True)
cargo=Path(sys.argv[2]);driver=Path(sys.argv[3]); mode=sys.argv[4]
base=Path('/home/dev-user/.cache/ohm-ruff-cargo-link-skip-20261027/native-span-observer/ruff-sdk-prefetch-corrected-subjects/guardv3')
ss=Path(os.environ.get('MIXED_SYSROOT_ROOT','/mnt/devbox-scratch/dev-user/ohm-nonleaf-perflint-20261026/stage-score')); rt=ss/'sysroot'
for n in ['ws','target','shared','cargo-home','reference','reference-shared','reference-home']:(r/n).mkdir()
w=r/'ws';(w/'Cargo.toml').write_text('[workspace]\nmembers=["leaf","bundle","app"]\nresolver="3"\n')
for n in ['leaf','bundle','app']:
 d=w/n;(d/'src').mkdir(parents=True);extra=''
 if n=='bundle':extra='\n[lib]\ncrate-type=["cdylib","rlib"]\n[dependencies]\nleaf={path="../leaf"}\n'
 if n=='app':extra='\n[dependencies]\nbundle={path="../bundle"}\n'
 (d/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n'+extra)
leaf=w/'leaf/src/lib.rs';bundle=w/'bundle/src/lib.rs';app=w/'app/src/main.rs';files=w/'leaf/src'
base_leaf='pub fn value()->i32 { V }\n'
bundle.write_text('#[unsafe(no_mangle)] pub extern "C" fn observed()->i32 {leaf::value()}\npub fn via_rust()->i32{observed()}\n')
app.write_text('fn main(){println!("{}",bundle::via_rust());}\n')
if mode.startswith('foreign'):
 (files/'macros.rs').write_text('#[macro_export] macro_rules! gen_fn {()=>{#[inline(never)] pub fn ratio<T>(_: T, x: i32)->i32 {21 / x}};}\n')
 for i in range(9): (files/f'p{i}.rs').write_text('const _: () = ();\n')
 bundle.write_text('leaf::gen_fn!();\n'+bundle.read_text())
 app.write_text('fn main(){std::panic::set_hook(Box::new(|x|{let l=x.location().unwrap();println!("{}:{}:{}",l.file(),l.line(),l.column());}));let _=std::panic::catch_unwind(||bundle::ratio((),std::hint::black_box(0)));}\n')
def sha(f):return hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
def rece(physical):
 return {p.name:(sha(p),p.stat().st_mtime_ns) for p in physical.rglob('bundle.rlink') if p.is_file()}
def jwrite(f,obj):f.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
env=dict(os.environ,RUSTUP_HOME=str(ss/'rustup'),RUSTUP_AUTO_INSTALL='0',RUSTUP_TOOLCHAIN='ohm',CARGO_HOME=str(r/'cargo-home'),CARGO_TARGET_DIR=str(r/'target'),CARGO_BUILD_BUILD_DIR=str(r/'shared'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0' if mode.endswith('-off') else '1',RUSTC=str(rt/'bin/rustc'),LD_LIBRARY_PATH=str(rt/'lib'),CARGO_LOG='cargo::compiler=info',CARGO_TERM_COLOR='never')
for key in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
def run(tag,arm,package):
 q=r/tag/arm/package;q.mkdir(parents=True,exist_ok=False);t=r/('reference' if arm=='reference' else 'target')
 binary=base if arm=='reference' else cargo
 v=['taskset','-c','4-7','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(r),str(r),'--ro-bind',str(driver),str(rt/'lib'/driver.name),'--ro-bind',str(binary),str(rt/'bin/cargo')]
 if os.getenv('MIXED_PROVISIONAL_FRONT'):
  t0=v.index(str(driver))
  del v[t0-1:t0+2]
  under=r/'under-lib';under.mkdir(exist_ok=True)
  v+=['--ro-bind',str(rt/'lib'),str(under),'--tmpfs',str(rt/'lib')]
  for ent in (rt/'lib').iterdir():
   v+=['--ro-bind',str(ent),str(rt/'lib'/ent.name)]
  v+=['--ro-bind',str(driver),str(rt/'lib'/driver.name),'--ro-bind',os.environ['MIXED_PROVISIONAL_FRONT'],str(rt/'bin/rustc')]
 if arm=='reference':
  for a,b in [('reference','target'),('reference-shared','shared'),('reference-home','cargo-home')]:v+=['--bind',str(r/a),str(r/b)]
 v+=['--chdir',str(w),'--','strace','-ff','-qq','-s','65536','-e','trace=execve','-o',str(q/'exec'),'/home/dev-user/.cargo/bin/cargo','+ohm','build','--offline','-p',package,'--message-format=json']
 prior=rece(t);p=sp.run(v,env=env,capture_output=True);(q/'stdout').write_bytes(p.stdout);(q/'stderr').write_bytes(p.stderr)
 if p.returncode: raise AssertionError((tag,arm,package,p.stdout[-1600:],p.stderr[-2000:]))
 after=rece(t);procs=[]
 for f in sorted(q.glob('exec.*')):
  for line in f.read_text(errors='replace').splitlines():
   match=re.match(r'execve\("(.*?)", (\[.*?\]), .*\) += 0$',line)
   if not match:continue
   path,arr=match.groups();a=ast.literal_eval(arr)
   if '--crate-name' not in a or '--print=file-names' in a:continue
   name=a[a.index('--crate-name')+1]; assert name!='___'
   checked=any(x.startswith('ohm-checked-mixed-rlink=') for x in a)
   phase='checked-link' if checked and prior==after and prior else 'checked-full-fallback' if checked else 'ordinary-link-only' if any(x in ('link-only','-Zlink-only') for x in a) else 'full'
   procs.append([name,phase]);jwrite(q/('rustc.'+f.suffix.lstrip('.')+'.json'),a)
 artifacts={x['target']['name']:x for line in p.stdout.splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact'}
 out={'procs':procs,'before':prior,'after':after,'dirty':[n for n,art in artifacts.items() if not art['fresh']]}
 if package=='bundle':
  paths={Path(n).suffix:t/Path(n).relative_to(r/'target') for n in artifacts['bundle']['filenames']}
  so=paths['.so'];lib=paths['.rlib']
  out.update(so=sha(so),meta=sha(paths['.rmeta']),embedded=hashlib.sha256(sp.check_output(['ar','p',lib,'lib.rmeta'])).hexdigest(),symbols=sorted(i.split()[-1] for i in sp.check_output(['nm','-D','--defined-only',so],text=True).splitlines()),behavior=sp.check_output([sys.executable,'-c','import ctypes,sys; print(ctypes.CDLL(sys.argv[1]).observed())',so],text=True).strip())
 else:
  f=t/Path(artifacts['app']['executable']).relative_to(r/'target');out.update(program=sha(f),behavior=sp.check_output([f],text=True).strip())
 jwrite(q/'result.json',out);return out
rows=[]
phases=[('cold',1,''),('body2',2,''),('body3',3,''),('restore2',2,''),('body4',4,''),('new-export',4,'#[unsafe(no_mangle)] pub extern "C" fn marker() {}\n'),('renamed-export',4,'#[unsafe(no_mangle)] pub extern "C" fn renamed() {}\n'),('removed-export',4,''),('rust-api',4,'pub const MARKER: i32 = 12;\n')]
if mode.startswith('foreign'):
 phases=[('before-long',1,'long'),('remove-nine',1,'short'),('restore-nine',1,'long'),('remove-repeat',1,'short')]
for label,val,extra in phases:
 if mode.startswith('foreign'):
  leaf.write_text(''.join(f'#[cfg({"all" if extra=="long" else "any"}())] mod p{i};\n' for i in range(9))+'mod macros;\n'+base_leaf.replace('V',str(val)))
 else:leaf.write_text(base_leaf.replace('V',str(val))+extra)
 o={}; c={}
 for arm in ['candidate','reference']:
  o[arm]=run(label,arm,'bundle')
  t=r/('reference' if arm=='reference' else 'target')
  # Force a newly compiled Rust importer in either arm to observe the normal .rlib.
  for f in t.rglob('out/app-*'):
   if f.is_file() and os.access(f,os.X_OK):f.rename(r/label/arm/(f.name+'.previous'))
  c[arm]=run(label,arm,'app')
  fresh=run(label+'-fresh',arm,'bundle');assert fresh['procs']==[] and not fresh['dirty'],(label,arm,fresh['procs'])
 for k in ['so','meta','embedded','symbols','behavior']:assert o['candidate'][k]==o['reference'][k],(label,k,o['candidate'][k],o['reference'][k])
 for k in ['program','behavior']:assert c['candidate'][k]==c['reference'][k],(label,k,c['candidate'][k],c['reference'][k])
 assert len([i for i in o['candidate']['procs'] if i[0]=='bundle'])==1,(label,o)
 row={'stage':label,'candidate':o['candidate']['procs'],'reference':o['reference']['procs'],'artifacts':{k:o['candidate'][k] for k in ['so','meta','embedded','symbols','behavior']},'caller':{k:c['candidate'][k] for k in ['program','behavior']}}
 rows.append(row);jwrite(r/'summary.json',rows);print(label,row['candidate'],row['caller']['behavior'],flush=True)
if mode=='body':
 assert any(['bundle','checked-link'] in row['candidate'] for row in rows),rows
 assert all(['bundle','checked-link'] not in row['candidate'] for row in rows if row['stage'] in ['new-export','renamed-export','removed-export','rust-api']),rows
if mode.endswith('-off') or mode=='downgrade':
 assert all(all(p[1] not in ('checked-link','checked-full-fallback') for p in row['candidate']) for row in rows),rows
