from pathlib import Path
import hashlib, json, os, shutil, subprocess as sp, sys
d=Path(__file__).resolve().parent;root=Path(sys.argv[1]);cargo=Path(sys.argv[2]);driver=Path(sys.argv[3]); root.mkdir(exist_ok=False)
s=Path(os.environ.get('MIXED_SYSROOT_ROOT','/mnt/devbox-scratch/dev-user/ohm-nonleaf-perflint-20261026/stage-score'));rt=s/'sysroot'; en=dict(os.environ,RUSTUP_HOME=str(s/'rustup'),RUSTUP_TOOLCHAIN='ohm',LD_LIBRARY_PATH=str(rt/'lib'))
q=d/'permanent/tests/run-make/rdr-public-hash-mixed-relink'
for f in ['bundle.rs','caller.rs']:shutil.copy2(q/f,root/f)
exe=['taskset','-c','4-7','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(root),str(root)]
if os.getenv('MIXED_PROVISIONAL_FRONT'):
 exe+=['--tmpfs',str(rt/'lib')]
 for ent in (rt/'lib').iterdir():exe+=['--ro-bind',str(ent),str(rt/'lib'/ent.name)]
 exe+=['--ro-bind',os.environ['MIXED_PROVISIONAL_FRONT'],str(rt/'bin/rustc')]
exe+=['--ro-bind',str(driver),str(rt/'lib'/driver.name),'--chdir',str(root),'--','/home/dev-user/.cargo/bin/rustc','+ohm']
rows=[]
def invoke(tag,args):
 p=sp.run([*exe,*args],env=en,capture_output=True);(root/(tag+'.stderr')).write_bytes(p.stderr); assert p.returncode==0,(tag,p.stderr.decode()[-1500:]);rows.append([tag,args]);return p
def compile(tag,checked,emit):
 a=['bundle.rs','--crate-type','cdylib,rlib','--emit='+emit,'--out-dir',str(root),'-Cincremental=incremental','-Zpublic-api-hash','-Zemit-rlink','-Ztemps-dir=objects']
 if checked:a+=['-Zohm-checked-mixed-rlink='+str(root/'bundle.rlink')]
 return invoke(tag,a)
def caller(tag,val):
 invoke(tag,['caller.rs','--extern','bundle=libbundle.rlib']); v=sp.check_output([root/'caller'],text=True).strip();assert v==val,(tag,v)
std='dep-info,metadata,link'
for n in range(2):compile('begin'+str(n),False,std)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
meta=root/'libbundle.rmeta';recipe=root/'bundle.rlink';before={'meta':sha(meta),'recipe':sha(recipe),'time_ns':recipe.stat().st_mtime_ns}
compile('hit',True,std); after={'meta':sha(meta),'recipe':sha(recipe),'time_ns':recipe.stat().st_mtime_ns};assert before==after,(before,after);caller('caller-one','1')
compile('mir',True,std+',mir=bundle-extra.mir');assert 'fn value()' in (root/'bundle-extra.mir').read_text()
(root/'bundle.rs').write_text('pub fn value() -> u8 { 2 }\n');compile('source',True,std); assert sha(meta)!=before['meta'];caller('caller-two','2')
(root/'summary.json').write_text(json.dumps({'commands':rows,'before':before,'accepted':after,'source_edit':sha(meta),'explicit_mir':sha(root/'bundle-extra.mir')},indent=2)+'\n');print('PASS',before['meta'],sha(meta),'saved recipe',before['recipe'],'MIR',sha(root/'bundle-extra.mir'))
