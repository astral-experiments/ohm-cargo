from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent
def j(path):return json.loads((base/path).read_bytes())
def expect(condition,subject):
 if not condition:raise RuntimeError(subject)
p=j('subjects.json')
assert p['cargo']['head']=='190d261a8546f121e3aa1adf237d85e02164eb18' and p['rustc']['head']=='b5fb832c70e8d0f353e9663a6e4f6e1409ae5eba'
for row in (base/'SHA256SUMS').read_text().splitlines():
 dig,name=row.split('  ',1);assert hashlib.file_digest((base/name).open('rb'),'sha256').hexdigest()==dig,name
counts=j('observations/evict/growth.json')
assert [r['count'] for r in counts]==[2]*4 and [r['bytes'] for r in counts]==[6536]*4
assert all(['bundle','checked-full-fallback'] in r['phase'] for r in counts[1:])
ints=j('observations/interrupt/verified.json')
assert ints['sentinel']=='untouched' and not ints['last']['procs']
m={k:(phase,state) for k,phase,state in ints['stages']};assert m['recovery'][0]==[['bundle','full']] and sorted(m['concurrent'][0])==[['bundle','checked-link'],['leaf','full']]
ev=j('observations/interrupt/interrupted/candidate/bundle/inotify.json')
assert any(n=='libbundle.rlink-cache.json' and flag&512 for n,flag in ev)
fifo=j('observations/fifo/summary.json');assert fifo['cargo_sha256']==p['cargo']['image'] and fifo['driver_sha256']==p['rustc']['parent_image'] and fifo['no_writer_ever'] and not fifo['timed_out_in_open'] and fifo['programs_equal'] and fifo['open_flags']==[0x80900] and fifo['command_returncode']==101 and fifo['downgrade']
for mode in ('body','body-off','foreign','foreign-off','downgrade'):
 rows=j('observations/'+mode+'/summary.json')
 for row in rows:
  name=row['stage'];root='observations/'+mode+'/'+name
  a=j(root+'/candidate/bundle/result.json'); b=j(root+'/reference/bundle/result.json')
  for k in ('so','embedded','meta','symbols','behavior'):expect(a[k]==b[k],(mode,name,k))
  ac=j(root+'/candidate/app/result.json');bc=j(root+'/reference/app/result.json');assert ac['program']==bc['program'] and ac['behavior']==bc['behavior']
  assert all(not j('observations/'+mode+'/'+name+'-fresh/'+arm+'/bundle/result.json')['procs'] for arm in ('candidate','reference'))
  if mode!='body':assert ['bundle','checked-link'] not in a['procs'],(mode,name)
  if mode=='body' and name in ('body2','body3','restore2','body4'):assert ['bundle','checked-link'] in a['procs']
  elif mode=='body':assert ['bundle','full'] in a['procs']
off=j('observations/direct/summary.json');assert off['before']==off['accepted'] and off['source_edit']!=off['before']['meta'] and off['explicit_mir']
pe=j('package/tested-product-elf-proof.json')['bounded-repeat']
assert pe['base']=='7d8a2d6715e0275308194508c70a4d49cb4c281d462c6d14b222ff4f5ecc1572' and pe['binary']==p['cargo']['image']
assert pe['symbol_count']==69473 and pe['llvm_private_symbol_names_different']==1716 and pe['symbol_addresses_sizes_types_identical'] and all(v['unexpected_differences']==0 for v in pe['load_segments'])
print('Passed sealed release native negotiation, ordinary Rust and native output checks, storage bound, cancellation, concurrency, explicit MIR and FIFO.')
