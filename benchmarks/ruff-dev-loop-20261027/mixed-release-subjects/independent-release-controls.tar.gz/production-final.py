from pathlib import Path
import subprocess,sys,hashlib
D=Path(__file__).resolve().parent;W=Path('/dev/shm/ohm-mixed-certificate-20261027');q=Path.home()/'.cache/ohm-ruff-whole-skips-20261027';Rt=Path.home()/'.cache/ohm-ruff-packed-edges-20261026/nonleaf/trait-pgo-state';son='librustc_driver-774a793a844d5500.so';C=W/'cargo-v4-compiler/bounded-repeat';R=W/'release-b1'/son;PC=Path.home()/'.cache/ohm-ruff-cargo-link-skip-20261027/native-span-observer/ruff-sdk-prefetch-corrected-subjects/guardv3';PR=D.parent/'stage2-wire-posobs4fmt'/son
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert sha(C)=='0f237cc3b506aa90c1224e6ed80f646566b424b78c8d74f288f6523d17fc8aa1' and sha(R)=='7c31057e86f800e313b7d32080c7a5abaa7b92fef92254ac21b2e43febf16384'
assert sha(PC)=='dd5cab154b8dcd09ccc2753160d314cade80979b2d055ee66aa9e2217e05e7e1' and sha(PR)=='dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f'
for case,kind,cargo,driver,out in [('plain','product',C,R,'ffi'),('mir','product',C,R,'mir'),('warnings','product',C,R,'warnings'),('plain','incompatible',C,PR,'old-rustc'),('plain','incompatible',PC,R,'old-cargo')]:
 root='release-final-c1-'+out
 if list(sys.argv[1:]) and out not in sys.argv[1:]:continue
 with (D/(root+'.log')).open('wb')as f:r=subprocess.run([sys.executable,'-B',D/'hard-ffi-release.py','--case',case,'--kind',kind,'--cargo',cargo,'--driver',driver,'--runtime',Rt,'--out',root],stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(root,r.returncode,flush=True)
 if r.returncode:print((D/(root+'.log')).read_text()[-1900:]);break
