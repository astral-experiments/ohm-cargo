fn hidden() -> u32 { let n=env!("OHM_AUDIT_VALUE").as_bytes()[0] as u32; n + include_bytes!("payload.bin")[0] as u32 + pm::secret!() }
#[unsafe(no_mangle)] pub extern "C" fn one_symbol() -> u32 { hidden() + leaf::value() }
