pub fn value() -> u32 { inner() }
fn inner() -> u32 { 11 }
