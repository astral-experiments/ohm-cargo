extern crate proc_macro; use proc_macro::TokenStream; #[proc_macro] pub fn secret(input: TokenStream) -> TokenStream { let _=input; "5u32".parse().unwrap() }
