#include <stdio.h>
#include <dlfcn.h>
int main(int n,char **a){void *dl=dlopen(a[1],RTLD_NOW); if(!dl)return 74; unsigned (*f)(void)=dlsym(dl,"one_symbol"); if(!f)return 75; printf("%u\n",f());return 0;}
