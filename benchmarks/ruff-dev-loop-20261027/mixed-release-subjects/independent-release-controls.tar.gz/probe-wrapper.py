#!/usr/bin/python3
import json,os,pathlib,subprocess,sys
c=sys.argv[1:]; env=dict(os.environ); phase=pathlib.Path(env['OHM_INDEPENDENT_PHASE']); root=pathlib.Path(env['OHM_INDEPENDENT_ROOT']); name=c[c.index('--crate-name')+1] if '--crate-name' in c else None
if name is None:os.execv(c[0],c)
state={'crate':name,'given_link_only': 'link-only' in c,'given_product_option':next((v for v in c if v.startswith('ohm-checked-mixed-rlink=')),None),'effective_env_value':env['OHM_AUDIT_VALUE'] if name=='bundle' else None,'args_went_to_real_rustc':None}; c+=['--sysroot',env['SYS']]
if name=='bundle':
 if env['OHM_INDEPENDENT_CASE']=='emit':
  flag=next(v for v in c if v.startswith('--emit='));c[c.index(flag)]=flag+',mir='+str(root/'bundle-tool.mir')
 if env['OHM_INDEPENDENT_DRIVER_KIND']=='probe' and state['given_link_only']:
  idx=c.index('link-only');assert c[idx-1]=='-Z'; del c[idx-1:idx+1];archive=next(v for v in c if v.endswith('.rlink'));c[c.index(archive)]='bundle/src/lib.rs';env['OHM_RESEARCH_CHECKED_NATIVE_RLINK']=archive
 elif env.get('OHM_INDEPENDENT_FORCE_SOURCE')=='1' and state['given_product_option']:
  idx=c.index(state['given_product_option']);assert c[idx-1]=='-Z'; del c[idx-1:idx+1]
state['args_went_to_real_rustc']=c
z=subprocess.run(c,stderr=subprocess.PIPE,env=env,close_fds=False);lines=z.stderr.splitlines(keepends=True);state['witness']=[x.decode().strip() for x in lines if x.startswith(b'OHM_CHECKED_')];sys.stderr.buffer.writelines([x for x in lines if not x.startswith(b'OHM_CHECKED_')]);state['returncode']=z.returncode;(phase/f'child.{os.getpid()}.json').write_text(json.dumps(state));sys.exit(z.returncode)
