set -eu
B=/home/dev-user/.cache/ohm-mixed-cargo-release-20261027
cd "$B"
case "$1" in fixture|full) ;; *) exit 2;; esac
exec > "$B/qualified-$1.log" 2>&1
trap 'echo $? > "$B/qualified-$1.rc"' EXIT
sha256sum -c "$B/final-subjects.sha256"
if test "$1" = fixture; then
    python3 verify-final-cargo.py fixture pairs qualified-final
else
    python3 verify-final-cargo.py full candidate qualified-final
    python3 verify-final-cargo.py full-clean candidate qualified-final
    python3 verify-final-cargo.py full parent qualified-final
fi
