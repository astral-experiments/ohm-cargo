"""Replay Ruff and a typed diamond using matched Cargo binaries, private caches and the #233 driver."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

P = Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027')
B = Path.home()/'.cache/ohm-mixed-cargo-release-20261027'
F = P/'frozen-toolchain'
driver_hash = '3e4b168966e111b52ad1a942d364ec1335cf1cfa994f4208b0909ca215b589d2'
driver = P/'subjects'/('driver-'+driver_hash)
ruff = Path('/home/dev-user/code/oss/ruff-ohm-whole-native-20261027')
cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('scope',choices=['full','full-clean','fixture'])
cli.add_argument('arm',choices=['parent','candidate','pairs'])
cli.add_argument('series',type=str)
a=cli.parse_args()
assert a.series.replace('-','').isalnum()
frozen = {'parent': B/'cargo-parent', 'candidate': B/'cargo-final'}
out = B/(a.series+'-'+a.scope)
out.mkdir(exist_ok=True)
for u in [B/'canonical-target', B/'canonical-build']:
    u.mkdir(exist_ok=True)
def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def write(p, v):
    p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def fixture():
    ws = B/'typed-diamond'
    if ws.is_dir():
        assert (ws/'consumer/src/main.rs').read_text().startswith('fn main()')
        return ws
    ws.mkdir()
    (ws/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=["model","bridge","unrelated","consumer"]\ndefault-members=["consumer"]\n[profile.dev]\ndebug="line-tables-only"\nopt-level=1\nlto="off"\n')
    src={'model':'pub struct Model(pub u32); pub fn make()->Model{ Model(7) }',
         'bridge':'pub fn model()->model::Model { model::make() }',
         'unrelated':'pub fn answer()->u32 { 7 }',
         'consumer':'fn main(){ let a: model::Model = bridge::model(); assert_eq!(a.0, unrelated::answer()); }'}
    deps={'model':'[lib]\ncrate-type=["rlib","cdylib"]','bridge':'[dependencies]\nmodel={path="../model"}','unrelated':'',
          'consumer':'[dependencies]\nmodel={path="../model"}\nbridge={path="../bridge"}\nunrelated={path="../unrelated"}'}
    for k,source in src.items():
        sub=ws/k
        (sub/'src').mkdir(parents=True)
        (sub/'Cargo.toml').write_text(f'[package]\nname="{k}"\nversion="0.1.0"\nedition="2024"\n'+deps[k]+'\n')
        (sub/'src'/('main.rs' if k=='consumer' else 'lib.rs')).write_text(source+'\n')
    return ws

def trial(arm, trial_id):
    cargo=frozen[arm]
    cargo_digest=sha(cargo)
    assert sha(driver)==driver_hash
    place=out/trial_id
    place.mkdir()
    target,shared=place/'target',place/'trusted-build'
    target.mkdir(); shared.mkdir()
    ws=fixture() if a.scope=='fixture' else ruff
    immutable_source=P/'source'
    assert a.scope=='fixture' or subprocess.check_output(['git','--no-optional-locks','-C',immutable_source,'status','--porcelain'])==b''
    assert a.scope=='fixture' or subprocess.check_output(['git','-C',immutable_source,'rev-parse','HEAD'],text=True).strip()=='93526150df078af7dd8fc4226cdcc469539d2001'
    env=dict(os.environ,RUSTUP_HOME=str(P/'rustup'),RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(P/'registry-home'),CARGO_BUILD_JOBS='8',CARGO_TARGET_DIR=str(B/'canonical-target'),CARGO_BUILD_BUILD_DIR=str(B/'canonical-build'),CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST='all',CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST='all',CARGO_TERM_COLOR='never',LC_ALL='C.UTF-8',SSL_CERT_DIR='/etc/ssl/certs',SSL_CERT_FILE='/etc/ssl/certs/ca-certificates.crt')
    assert not any(k.startswith('WILD_') or k in ('RUSTC_WRAPPER','RUSTC_LOG','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS') for k in env)
    wrap=['bwrap','--ro-bind','/','/','--proc','/proc','--dev-bind','/dev','/dev','--bind','/tmp','/tmp','--bind',str(place),str(place),'--bind',str(P/'registry-home'),str(P/'registry-home'),'--bind',str(P/'rustup'),str(P/'rustup'),'--bind',str(target),str(B/'canonical-target'),'--bind',str(shared),str(B/'canonical-build'),'--ro-bind',str(cargo),str(F/'bin/cargo'),'--ro-bind',str(driver),str(F/'lib/librustc_driver-774a793a844d5500.so'),'--chdir',str(ws),'--','taskset','-c','24-31']
    if a.scope!='fixture':
        wrap[4:4]=['--ro-bind',str(immutable_source),str(ruff)]
    if a.scope=='fixture' and not (ws/'Cargo.lock').is_file():
        # The base root ro-bind precedes the writable source mount.
        new=wrap[:4]+['--bind',str(ws),str(ws)]+wrap[4:]
        subprocess.run([*new,'cargo','+ohm','generate-lockfile','--offline'],env=env,check=True)
    def run(step,argv):
        r=place/step
        r.mkdir()
        with (r/'stdout').open('wb') as o,(r/'stderr').open('wb') as e:
            cmd=['cargo','+ohm',*argv,'--locked','--offline','--message-format=json']
            if a.scope=='fixture' and step=='check':
                cmd=['strace','-f','-qq','-s','3000','-e','trace=execve','-o',str(r/'exec'),*cmd]
            v=subprocess.run([*wrap,*cmd],env=env,stdout=o,stderr=e)
        rows = [json.loads(l) for l in (r/'stdout').read_bytes().splitlines() if l.startswith(b'{')]
        if not rows or rows[-1].get('reason')!='build-finished':
            raise RuntimeError((r,(r/'stderr').read_text()[-1000:]))
        arts=[x for x in rows if x['reason']=='compiler-artifact']
        errors=[(x['target']['name'],x['message']['message']) for x in rows if x['reason']=='compiler-message' and x['message']['level']=='error']
        files=[(x['target']['name'],x['fresh'],x['filenames']) for x in arts if x['target']['name'] in {'model','pep440_rs','unrelated','bridge','consumer','pyproject_toml','libcst_native'}]
        diagnostics=[x['message']['rendered'] for x in rows if x['reason']=='compiler-message']
        d=dict(rc=v.returncode,success=rows[-1]['success'],units=len(arts),fresh=sum(x['fresh'] for x in arts),errors=errors,selected=files,diagnostics=diagnostics)
        assert d['success']==(v.returncode==0)
        write(r/'receipt.json',d)
        return d
    report={}
    if a.scope!='full-clean':
        report['native']=run('native',['build'])
        assert report['native']['success']
        if a.scope=='fixture':
            def native_metadata(record):
                rows=[(fresh,f) for name,fresh,files in record['selected'] if name=='unrelated' for f in files if f.endswith('.rmeta')]
                ((fresh,f),)=rows
                path=target / Path(f).relative_to(B/'canonical-target')
                st=path.stat()
                return {'fresh':fresh,'path':f,'sha256':sha(path),'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
            initial=native_metadata(report['native'])
    report['check']=run('check',['check'])
    if report['check']['success']:
        report['fresh']=run('fresh',['check'])
        assert report['fresh']['success'] and report['fresh']['units']==report['fresh']['fresh']
        if a.scope!='fixture':
            report['fresh-again']=run('fresh-again',['check'])
            assert report['fresh-again']['success'] and report['fresh-again']['units']==report['fresh-again']['fresh']
            if a.scope=='full':
                report['native-repeat']=run('native-repeat',['build'])
                assert report['native-repeat']['success'] and report['native-repeat']['units']==report['native-repeat']['fresh']
        if a.scope=='fixture':
            reused=native_metadata(report['check'])
            assert reused==dict(initial,fresh=True), (initial,reused)
            trace=(place/'check/exec').read_text(errors='replace')
            assert '"--crate-name", "consumer"' in trace and '"--crate-name", "unrelated"' not in trace
            report['independent_native_metadata']={'before':initial,'after':reused,'independent_rustcs':0}
    else:
        assert report['check']['rc']==101 and any('colliding StableCrateId' in t for _,t in report['check']['errors'])
    write(place/'result.json',dict(arm=arm,cargo=cargo_digest,driver=driver_hash,report=report))
    print(trial_id,arm,report.get('native',{}).get('units'),report['check']['rc'],report['check']['errors'],flush=True)
    return report['check']['success']

with (B/'functional-checks.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    if a.arm=='pairs':
        assert a.scope=='fixture'
        orders=json.loads((B/'success-plan.json').read_bytes())['orders']
        assert len(orders)==12 and len(set(orders))==2
        runs=[]
        for i,order in enumerate(orders,1):
            result={}
            for arm in order.split('/'):
                result[arm]=trial(arm,f'{i:02}-{arm}')
            runs.append(result)
        wins=sum(not v['parent'] and v['candidate'] for v in runs)
        losses=sum(v['parent'] and not v['candidate'] for v in runs)
        from math import comb
        m=wins+losses
        p=min(1.0, 2*sum(comb(m,k) for k in range(min(wins,losses)+1))/2**m) if m else 1.0
        write(out/'summary.json',dict(wins=wins,losses=losses,p_one_primary_two_sided=p,runs=runs))
    else:
        trial(a.arm,a.arm)
