pub fn observed() -> String { match ruff_python_parser::parse_module("t'first' b'second'\n") { Err(e) => e.to_string(), Ok(_) => panic!("expected invalid syntax") } }
