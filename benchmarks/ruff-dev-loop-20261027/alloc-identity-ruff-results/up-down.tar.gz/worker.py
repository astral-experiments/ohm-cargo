"""Read authentic old/new incremental headers at one literal path across a driver replacement."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys

P=Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027'); F=P/'frozen-toolchain'
X=Path.home()/'.cache/ohm-233-position-qualified-20261027'
spec=P/'alloc-upgrade-protocol-v1/fixture'
base=P/'parse-source-replay-v3/candidate-driver.so'
image=P/'parse-source-alloc-replay-v1/candidate-driver.so';out=P/'alloc-cache-transition-v1'
out.mkdir(mode=0o700); src=out/'src';shutil.copytree(spec,src)
cfg=dict(os.environ,RUSTUP_HOME=str(P/'rustup'),RUSTUP_AUTO_INSTALL='0',RUSTC_BOOTSTRAP='1')
def sha(f):
    with f.open('rb') as v:return hashlib.file_digest(v,'sha256').hexdigest()
def dump(f,x):f.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def run(label,arm,argv):
    d=out/label;d.mkdir()
    ns=['bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(out),str(out),'--ro-bind',str(arm),str(F/'lib/librustc_driver-774a793a844d5500.so'),'--chdir',str(src),'--']
    p=subprocess.run([*ns,*map(str,argv)],env=cfg,capture_output=True)
    (d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);dump(d/'status.json',dict(returncode=p.returncode,argv=list(map(str,argv))))
    assert not p.returncode,(label,p.stderr.decode()[-800:]);return p
cpp=['rustc','+ohm','--sysroot',str(F),'--edition=2024']
assert sha(base)=='36d1fd142355c3ad9e0ce006c1e92b7e511cba70c431b09eb1e335f572d27d05'
assert sha(image)=='4a993e1f78e3ec0122771380eadbf58ed5d467c058d314381e523f1bbe78d955'
os.sched_setaffinity(0,{28,29});os.nice(11)
status={};original=(src/'producer.rs').read_text()
run('plugin',base,[*cpp,'maker.rs','-o',src/'libmaker.so'])
for label,driver,num,asset,inc,epoch,executed in [
    ('old-prime',base,7,'91','same',3,True),('upgrade',image,8,'379','same',4,True),
    ('upgrade-empty',image,8,'379','empty1',4,True),('future-warm',image,9,'379','same',4,False),
    ('future-empty',image,9,'379','empty2',4,True),('downgrade',base,8,'379','same',3,True),
    ('downgrade-empty',base,8,'379','empty3',3,True)]:
    (src/'producer.rs').write_text(original.replace('    7',f'    {num}'))
    (src/'parse-input.txt').write_text(asset)
    p=run(label,driver,[*cpp,'producer.rs','--extern','maker=libmaker.so','-Cincremental='+str(out/inc),'-Zcache-proc-macros','-Zpublic-api-hash','--emit=link,metadata'])
    observed=b'executed attribute' in p.stderr and b'\nexecuted derive\n' in b'\n'+p.stderr
    assert observed==executed and b'executed tracked derive' in p.stderr,(label,p.stderr)
    # Rustc may retain a (non-current) previous session on disk. Read the newest successful one.
    q=max((out/inc).glob('producer-*/s-*/query-cache.bin'),key=lambda f:f.stat().st_mtime_ns)
    with q.open('rb') as f:head=f.read(6)
    assert head==b'RSIC'+epoch.to_bytes(2,'little'),(label,q,head)
    d=out/label;shutil.copyfile(src/'libproducer.rmeta',d/'raw.rmeta')
    entry=dict(query_cache=str(q.relative_to(out)),header_hex=head.hex(),attribute_and_plain_derive_executed=observed,raw_rmeta_sha256=sha(d/'raw.rmeta'),observed=None)
    if label!='old-prime':
        (src/'external.rs').write_text('fn main() { println!("{}:{:?}:{}", producer::value(), producer::position(), producer::TRACKED); }\n')
        run(label+'-caller',driver,[*cpp,'external.rs','--extern','producer=libproducer.rlib','-L','dependency=.', '-o',src/'external'])
        entry['observed']=run(label+'-native',driver,[src/'external']).stdout.decode().strip()
        assert entry['observed'].startswith(str(num)+':') and entry['observed'].endswith(':379')
    status[label]=entry;dump(out/'results.json',status)
for warm,cold in [('upgrade','upgrade-empty'),('future-warm','future-empty'),('downgrade','downgrade-empty')]:
    for k in ['observed','raw_rmeta_sha256']:assert status[warm][k]==status[cold][k],(warm,k)
dump(out/'complete.json',dict(parent_sha256=sha(base),candidate_sha256=sha(image),results_sha256=sha(out/'results.json')))

cross={}
for built in ('parent','candidate'):
    for history in ('warm','empty'):
        lib=P/'alloc-retained-literal-v1'/built/'literal/plain/evidence'/history/'libprobe.rlib'
        for reader,driver in (('parent',base),('candidate',image)):
            n='wire-'+built+'-'+history+'-'+reader
            (src/'wire.rs').write_text('fn main() { println!("{}", probe::observed()); }')
            run(n,driver,[*cpp,'wire.rs','--extern','probe='+str(lib),'-o',src/'wire'])
            v=run(n+'-native',driver,[src/'wire'])
            assert v.stdout==b'8\n' and not v.stderr
            cross[n]=dict(rlib=sha(lib),driver=sha(driver),native=v.stdout.decode().strip(),executable=sha(src/'wire'))
dump(out/'cross-wire.json',cross)
print(json.dumps(dict(transition=status,wire=cross)))
