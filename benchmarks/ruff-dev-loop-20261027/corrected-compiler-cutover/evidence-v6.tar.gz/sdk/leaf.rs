#![feature(no_core,lang_items)]
#![allow(internal_features)]
#![no_core]
extern crate middle; pub use middle::Token;
