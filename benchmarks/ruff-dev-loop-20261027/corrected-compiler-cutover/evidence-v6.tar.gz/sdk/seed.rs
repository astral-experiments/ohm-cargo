#![feature(no_core,lang_items)]
#![allow(internal_features)]
#![no_core]
#[lang="pointee_sized"] pub trait PointeeSized {}
#[lang="meta_sized"] pub trait MetaSized:PointeeSized {}
#[lang="sized"] pub trait Sized:MetaSized {}
#[lang="copy"] pub trait Copy {}
pub struct Token;
