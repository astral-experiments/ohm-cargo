#![feature(no_core,lang_items)]
#![allow(internal_features)]
#![no_core]
extern crate seed; pub use seed::Token;
