#![feature /* 859#0 */(prelude_import /* 1511#0 */)]
#![allow /* 309#0
*/(dead_code /* 683#0 */,unused_macros /* 2452#0 */,unused_imports /* 2185#0
*/)]
extern crate std /* 1948#1 */;
#[prelude_import /* 1511#1 */]
use std /* 1948#1 */::prelude /* 1510#1 */::rust_2024 /* 1649#1 */::*;
use review_macros /* 2453#0 */::{noise /* 2454#0 */, make /* 2455#0 */};
pub struct Public /* 2520#9 */ {
    pub value
    /*
    2214#9
    */: u32 /* 2108#9 */,
}

/*
Expansions:
crate0::{{expn0}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Root
crate0::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)
crate0::{{expn2}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Macro(Bang, "noise")
crate0::{{expn3}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Macro(Bang, "make")
crate1::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)

SyntaxContexts:
#0: parent: #0, outer_mark: (crate0::{{expn0}}, Opaque)
#1: parent: #0, outer_mark: (crate0::{{expn1}}, Opaque)
#2: parent: #0, outer_mark: (crate0::{{expn1}}, Transparent)
#3: parent: #0, outer_mark: (crate1::{{expn1}}, Opaque)
#4: parent: #0, outer_mark: (crate0::{{expn2}}, Opaque)
#5: parent: #0, outer_mark: (crate0::{{expn2}}, Transparent)
#6: parent: #0, outer_mark: (crate0::{{expn2}}, SemiOpaque)
#7: parent: #0, outer_mark: (crate0::{{expn3}}, Opaque)
#8: parent: #0, outer_mark: (crate0::{{expn3}}, Transparent)
#9: parent: #0, outer_mark: (crate0::{{expn3}}, SemiOpaque)
*/
