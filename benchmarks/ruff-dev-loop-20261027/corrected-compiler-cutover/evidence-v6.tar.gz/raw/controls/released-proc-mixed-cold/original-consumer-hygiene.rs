#![feature /* 859#0 */(prelude_import /* 1511#0 */)]
extern crate std /* 1948#1 */;
#[prelude_import /* 1511#1 */]
use std /* 1948#1 */::prelude /* 1510#1 */::rust_2024 /* 1649#1 */::*;
extern crate review_bridge /* 2452 */ as b /* 2351#0 */;
fn main /* 1165#0 */() {
    {
        ::std /* 0#4 */::io /* 2479#4 */::_print /* 2535#4
                */(format_args!("{0}\n",
                b /* 2351#0 */::read /* 2454#0
                        */(b /* 2351#0 */::Public /* 2455#0
                        */ { value /* 2214#0 */: 7 })));
    };
}

/*
Expansions:
crate0::{{expn0}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Root
crate0::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)
crate0::{{expn2}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Macro(Bang, "println")
crate0::{{expn3}}: parent: crate0::{{expn2}}, call_site_ctxt: #4, def_site_ctxt: #0, kind: Macro(Bang, "$crate::format_args_nl")
crate1::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)
crate21::{{expn2}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Macro(Bang, "make")

SyntaxContexts:
#0: parent: #0, outer_mark: (crate0::{{expn0}}, Opaque)
#1: parent: #0, outer_mark: (crate0::{{expn1}}, Opaque)
#2: parent: #0, outer_mark: (crate0::{{expn1}}, Transparent)
#3: parent: #0, outer_mark: (crate1::{{expn1}}, Opaque)
#4: parent: #0, outer_mark: (crate0::{{expn2}}, SemiOpaque)
#5: parent: #0, outer_mark: (crate0::{{expn3}}, Opaque)
#6: parent: #0, outer_mark: (crate21::{{expn2}}, SemiOpaque)
*/
