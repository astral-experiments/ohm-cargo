#![feature /* 859#0 */(prelude_import /* 1511#0 */)]
#![allow /* 309#0
*/(dead_code /* 683#0 */,unused_macros /* 2452#0 */,unused_imports /* 2185#0
*/)]
extern crate std /* 1948#1 */;
#[prelude_import /* 1511#1 */]
use std /* 1948#1 */::prelude /* 1510#1 */::rust_2024 /* 1649#1 */::*;
macro_rules! noise
    /*
    2453#0
    */ {
    () => { struct /* 29#0 */ Noise /* 2454#0 */; }
}
macro_rules! make
    /*
    2455#0
    */ {
    () =>
    {
        pub /* 23#0 */ struct /* 29#0 */ Public /* 2456#0 */
        { pub /* 23#0 */ value /* 2214#0 */: u32 /* 2108#0 */ }
    }
}
pub struct Public /* 2456#4 */ {
    pub value
    /*
    2214#4
    */: u32 /* 2108#4 */,
}

/*
Expansions:
crate0::{{expn0}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Root
crate0::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)
crate0::{{expn2}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: Macro(Bang, "make")
crate1::{{expn1}}: parent: crate0::{{expn0}}, call_site_ctxt: #0, def_site_ctxt: #0, kind: AstPass(StdImports)

SyntaxContexts:
#0: parent: #0, outer_mark: (crate0::{{expn0}}, Opaque)
#1: parent: #0, outer_mark: (crate0::{{expn1}}, Opaque)
#2: parent: #0, outer_mark: (crate0::{{expn1}}, Transparent)
#3: parent: #0, outer_mark: (crate1::{{expn1}}, Opaque)
#4: parent: #0, outer_mark: (crate0::{{expn2}}, SemiOpaque)
*/
