"""Exercise raw DefIndex/ExpnId binding with an independently retained middle library."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument("work",type=Path)
parser.add_argument("--rustup-home",type=Path,required=True)
parser.add_argument("--candidate-rustup-home",type=Path)
parser.add_argument("--bridge",choices=["public","ordinary"],default="ordinary")
parser.add_argument("--producer",choices=["public","ordinary"],default="public")
parser.add_argument("--writer-before",choices=["old","new"],default="old")
parser.add_argument("--writer-after",choices=["old","new"],default="old")
parser.add_argument("--reader",choices=["old","new"],default="old")
parser.add_argument("--proc-macro",action="store_true")
parser.add_argument("--mixed-site",action="store_true")
parser.add_argument("--remove",action="store_true")
parser.add_argument("--empty-noise",action="store_true")
parser.add_argument("--cold-producer",action="store_true")
parser.add_argument("--private-impl",action="store_true")
parser.add_argument("--unchanged",action="store_true")
args=parser.parse_args()
root=args.work.resolve()
root.mkdir(exist_ok=False)
assert not any(os.environ.get(x) for x in ["RUSTFLAGS","RUSTC_WRAPPER","RUSTC"])
homes=dict(old=args.rustup_home.resolve(),new=(args.candidate_rustup_home or args.rustup_home).resolve())
step=0;log=[];out={}


def sha(p):
    with p.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()


def crate(name, content, kind="lib"):
    folder=root/name
    (folder/"src").mkdir(parents=True)
    (folder/"Cargo.toml").write_text('[package]\nname = "'+name+'"\nversion = "0.0.0"\nedition = "2024"\n'
                                     +(('[lib]\nproc-macro = true\n') if kind=="proc" else "")+'[workspace]\n')
    (folder/"src"/("main.rs" if kind=="bin" else "lib.rs")).write_text(content)
    return folder


def run(cwd, cmd, compiler, check=True):
    global step
    step+=1
    env=dict(os.environ,RUSTUP_HOME=str(homes[compiler]),CARGO_TARGET_DIR=str(cwd/"target"),
             CARGO_BUILD_BUILD_DIR=str(root/"shared"),CARGO_BUILD_JOBS="2",RUSTUP_AUTO_INSTALL="0",CARGO_TERM_COLOR="never")
    proc=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True)
    (root/f"{step}-stderr").write_bytes(proc.stderr)
    (root/f"{step}-stdout").write_bytes(proc.stdout)
    log.append(dict(step=step,cwd=str(cwd),cmd=[str(x) for x in cmd],compiler=compiler,status=proc.returncode))
    summary()
    if check and proc.returncode:
        raise RuntimeError((step,cmd,proc.stderr[-600:]))
    return proc


def summary():
    (root/"commands.json").write_text(json.dumps(log,indent=2)+"\n")
    (root/"result.json").write_text(json.dumps(out,indent=2)+"\n")


def compile(cwd,mode,compiler,extra=(),check=True):
    launcher=["cargo","+ohm"]+([] if mode=="public" else ["-Zohm-defaults=no"])
    p=run(cwd,[*launcher,"rustc","--offline","--message-format=json","--",*extra],compiler,check=check)
    if p.returncode:
        return None
    rows=[j for j in map(json.loads,p.stdout.splitlines()) if j["reason"]=="compiler-artifact" and j["target"]["name"]==cwd.name]
    j,=rows
    assert not j["fresh"], (cwd, step)
    return Path(j["executable"] or next(f for f in j["filenames"] if str(f).endswith((".rlib",".so"))))


def extern(name,p):
    return ["--extern",name+"="+str(p),"-L","dependency="+str(p.parent)]


def public_hash(cwd,p,compiler):
    return run(cwd,["rustc","+ohm",p,"-Zls=public_hash"],compiler).stdout.decode().strip()


def save_name(p, file):
    dst=root/file/p.name
    dst.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(p,dst)
    return dst


aux_options=[]
if args.proc_macro:
    macros_source='extern crate proc_macro; use proc_macro::TokenStream; #[proc_macro] pub fn make(_input:TokenStream)->TokenStream { "pub struct Public { pub value: u32 }".parse().unwrap() } #[proc_macro] pub fn noise(_input:TokenStream)->TokenStream { "struct Noise;".parse().unwrap() }'
    if args.mixed_site:
        helper='fn mark(mut token:proc_macro::TokenTree)->proc_macro::TokenTree { if let proc_macro::TokenTree::Group(g)=token { token=proc_macro::TokenTree::Group(proc_macro::Group::new(g.delimiter(),g.stream().into_iter().map(mark).collect())); } token.set_span(proc_macro::Span::mixed_site()); token }'
        macros_source=macros_source.replace('u32 }".parse().unwrap()','u32 }".parse::<TokenStream>().unwrap().into_iter().map(mark).collect()')+helper
    macros=crate("review_macros", macros_source.replace("struct Noise;", "") if args.empty_noise else macros_source, "proc")
    dylib=compile(macros,"ordinary",args.writer_before)
    aux_options=extern("review_macros",save_name(dylib,"macros"))
    imports="use review_macros::{noise,make};"
else:
    imports="macro_rules! noise { () => { struct Noise; } }\nmacro_rules! make { () => { pub struct Public { pub value: u32 } } }"
if args.empty_noise:
    imports=imports.replace("struct Noise;", "")
body="#![allow(dead_code,unused_macros,unused_imports)]\n"+imports+"\n#[cfg(any())] noise!();\nmake!();\n"
if args.private_impl:
    assert not args.proc_macro and not args.remove and not args.empty_noise
    body='#![allow(dead_code)]\n#[cfg(any())] struct Noise;\npub struct Public { pub value: u32 }\nstruct Private;\nimpl Iterator for Private { type Item = u8; fn next(&mut self) -> Option<Self::Item> { None } }\n'
producer=crate("review_producer",body)
bridge_source='extern crate review_producer; pub use review_producer::*; #[inline] pub fn read(x:review_producer::Public)->u32{x.value}'
bridge=crate("review_bridge",bridge_source)
consumer=crate("review_consumer",'extern crate review_bridge as b; fn main(){println!("{}",b::read(b::Public{value:7}));}',"bin")
for key in set([args.writer_before,args.writer_after,args.reader]):
    out[key+"_rustc"]=run(producer,["rustc","+ohm","-Vv"],key).stdout.decode()
    if (homes[key]/"receipt.json").is_file():
        selection=json.loads((homes[key]/"receipt.json").read_bytes())
        out[key+"_selection"]={k:selection[k] for k in ["driver","sha256","sysroot","cargo"]}


def producer_metadata(label,c):
    artifact=compile(producer,args.producer,c,aux_options)
    public=public_hash(producer,artifact,c)
    expanded=run(producer,["rustc","+ohm","src/lib.rs","--crate-name","review_producer","--crate-type","rlib","--edition","2024","-Zunpretty=expanded,hygiene",*aux_options],c)
    (root/(label+"-hygiene.rs")).write_bytes(expanded.stdout)
    info=[line.strip() for line in expanded.stdout.decode().splitlines() if "expn" in line and ("make" in line or "noise" in line)]
    return artifact,dict(public=public,sha256=sha(artifact),hygiene=info)


p, out["producer_original"]=producer_metadata("original",args.writer_before)
oldp=save_name(p,"active-producer")
b=compile(bridge,args.bridge,args.writer_before,extern("review_producer",oldp)+aux_options)
kept=save_name(b,"retained-bridge")
save_name(b,"original-bridge")
out["bridge_sha256"]=sha(kept)


def caller(label,b,compiler):
    fresh=consumer
    if (fresh/"target").exists():
        (fresh/"target").rename(root/("prior-consumer-target-"+label))
    if (root/"shared").exists():
        (root/"shared").rename(root/("prior-consumer-build-"+label))
    foreign=extern("review_bridge",b)+["-L","dependency="+str(oldp.parent)]+aux_options
    contexts=run(fresh,["rustc","+ohm","src/main.rs","--crate-name","review_consumer","--edition","2024","-Zunpretty=expanded,hygiene",*foreign],compiler,check=False)
    (root/(label+"-consumer-hygiene.rs")).write_bytes(contexts.stdout)
    p=compile(fresh,"ordinary",compiler,foreign,check=False)
    out[label]={"compiler_exit":log[-1]["status"],"step":step}
    if p is not None:
        proc=run(fresh,[p],compiler,check=False)
        out[label].update(exit=proc.returncode,stdout=proc.stdout.decode())
    summary()


caller("original",kept,args.writer_before)
assert out["original"]["exit"]==0 and out["original"]["stdout"]=="7\n"
if args.cold_producer and not args.unchanged:
    for folder in [producer/"target",root/"shared"]:
        if folder.exists():
            folder.rename(root/("prior-"+folder.name))
edited=body.replace("cfg(any())","cfg(all())") if not args.remove else body.replace("make!();","pub struct Public { pub value: u32 }")
if args.private_impl:
    edited=edited.replace("type Item = u8", "type Item = i8")
if args.unchanged:
    assert args.writer_after == args.writer_before
    out["producer_edited"]=out["producer_original"].copy()
    assert sha(oldp)==out["producer_edited"]["sha256"]
else:
    (producer/"src/lib.rs").write_text(edited)
    p,out["producer_edited"]=producer_metadata("edited",args.writer_after)
    assert p.name==oldp.name,(p,oldp)
    shutil.copyfile(p,oldp)
caller("stale",kept,args.reader)
assert out["bridge_sha256"]==sha(kept)
if (bridge/"target").exists():
    (bridge/"target").rename(root/"prior-bridge-target")
if (root/"shared").exists():
    (root/"shared").rename(root/"prior-bridge-build")
bnew=compile(bridge,args.bridge,args.writer_after,extern("review_producer",oldp)+aux_options)
assert bnew.name==kept.name
out["regenerated_bridge_sha256"]=sha(bnew)
shutil.copyfile(bnew,kept)
caller("regenerated",kept,args.reader)
summary()
print(json.dumps(out,indent=2))
