"""Create a private rustup descriptor for a read-only compiler sysroot and one explicit driver."""
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

home, sysroot, driver_dir, cargo = map(lambda a: Path(a).resolve(), sys.argv[1:])
assert not home.exists()
binary = sysroot/"bin/rustc"
driver, = driver_dir.glob("librustc_driver-*.so")
libpath = str(driver_dir) + ":" + str(sysroot/"lib")
loaded = subprocess.check_output(["ldd",binary],env=dict(os.environ,LD_LIBRARY_PATH=libpath),text=True)
actual, = re.findall(r"librustc_driver-\S+ => (\S+)",loaded)
assert Path(actual).samefile(driver)
bin_dir = home/"toolchains/ohm/bin"
bin_dir.mkdir(parents=True)
(home/"settings.toml").write_text('version = "12"\nprofile = "minimal"\n')
(bin_dir/"cargo").symlink_to(cargo)
(bin_dir.parent/"lib").symlink_to(sysroot/"lib",target_is_directory=True)
script = "#!/bin/sh\nexport LD_LIBRARY_PATH="+shlex.quote(libpath)+"\nexec "+shlex.quote(str(binary))+" --sysroot "+shlex.quote(str(sysroot))+' "$@"\n'
(bin_dir/"rustc").write_text(script)
(bin_dir/"rustc").chmod(0o755)
with driver.open("rb") as fd:
    digest=hashlib.file_digest(fd,"sha256").hexdigest()
out={"driver":str(driver),"sha256":digest,"sysroot":str(sysroot),"cargo":str(cargo),"ldd":loaded,
     "version":subprocess.check_output(["rustc","+ohm","-Vv"],env=dict(os.environ,RUSTUP_HOME=str(home)),text=True)}
(home/"receipt.json").write_text(json.dumps(out,indent=2)+"\n")
print(driver.name,digest,out["version"].splitlines()[0])
