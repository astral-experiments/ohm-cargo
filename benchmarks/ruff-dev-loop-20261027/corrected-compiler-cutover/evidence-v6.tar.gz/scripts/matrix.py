"""Run the preregistered mixed-mode cases on two bounded CPU lanes, each in a fresh target."""
import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
from pathlib import Path

cli=argparse.ArgumentParser()
cli.add_argument("label")
cli.add_argument("old_home",type=Path)
cli.add_argument("new_home",type=Path)
args=cli.parse_args()
root=Path(__file__).resolve().parent
out=root/args.label
out.mkdir(exist_ok=False)
cases={
    "expansion-public": ["--cold-producer","--empty-noise","--bridge","public"],
    "expansion-ordinary": ["--cold-producer","--empty-noise"],
    "private-defid-ordinary": ["--cold-producer","--private-impl"],
    "private-defid-public": ["--cold-producer","--private-impl","--bridge","public"],
    "expansion-removed": ["--cold-producer","--empty-noise","--bridge","public","--remove"],
    "proc-mixed-site": ["--cold-producer","--empty-noise","--bridge","public","--proc-macro","--mixed-site"],
    "old-reader-new-writer": ["--cold-producer","--empty-noise","--bridge","public","--reader","old"],
    "new-reader-old-bridge-new-producer": ["--cold-producer","--empty-noise","--bridge","public","--writer-before","old"],
    "new-reader-old-exact-public": ["--bridge","public","--writer-before","old","--writer-after","old","--unchanged"],
    "new-reader-old-exact-ordinary": ["--producer","ordinary","--writer-before","old","--writer-after","old","--unchanged"],
    "new-reader-old-stale-public": ["--empty-noise","--cold-producer","--bridge","public","--writer-before","old","--writer-after","old"],
    "new-reader-old-stale-ordinary": ["--empty-noise","--cold-producer","--writer-before","old","--writer-after","old"],
    "new-reader-old-all-ordinary-empty": ["--empty-noise","--cold-producer","--producer","ordinary","--writer-before","old","--writer-after","old"],
    "new-reader-old-all-ordinary-private": ["--private-impl","--cold-producer","--producer","ordinary","--writer-before","old","--writer-after","old"],
    "old-reader-old-all-ordinary-empty": ["--empty-noise","--cold-producer","--producer","ordinary","--writer-before","old","--writer-after","old","--reader","old"],
    "old-reader-old-all-ordinary-private": ["--private-impl","--cold-producer","--producer","ordinary","--writer-before","old","--writer-after","old","--reader","old"],
    "new-reader-old-occupied-slot": ["--cold-producer","--bridge","public","--writer-before","old","--writer-after","old"],
    "new-reader-new-occupied-slot": ["--cold-producer","--bridge","public"],
}
schedule={n:["--writer-before","new","--writer-after","new","--reader","new",*case] for n,case in cases.items()}
(out/"plan.json").write_text(json.dumps(schedule,indent=2)+"\n")


def lane(cpu, which):
    for name, flags in which:
        cmd=["taskset","-c",cpu,sys.executable,"-B",str(root/"mixed.py"),str(out/name),"--rustup-home",str(args.old_home),
             "--candidate-rustup-home",str(args.new_home),*flags]
        with (out/(name+".log")).open("wb") as log:
            result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
        print(name,result.returncode,flush=True)


jobs=list(schedule.items())
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    completed=[pool.submit(lane,cpu,jobs[i::2]) for i,cpu in enumerate(["4-5","6-7"])]
    for f in completed:
        f.result()
