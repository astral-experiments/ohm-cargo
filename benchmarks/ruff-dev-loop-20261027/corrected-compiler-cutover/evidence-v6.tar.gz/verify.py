"""Independently check native return codes, parser diagnostics, visible macro owners and stored crate headers."""
import hashlib
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parent
summary=json.loads((root/"summary.json").read_bytes())
with (root/"SHA256SUMS").open() as manifest:
    for line in manifest:
        expected,name=line.rstrip("\n").split("  ",1)
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name

def inspect(key):
    row=summary[key]
    raw=root/"raw"/key
    src=json.loads((raw/"result.json").read_bytes())
    commands=json.loads((raw/"commands.json").read_bytes())
    for phase in ["producer_original","producer_edited"]:
        header=raw/(phase+".root.txt")
        if header.exists():
            p,q=re.search(r"private hash ([0-9a-f]+).*\npublic_hash ([0-9a-f]+)",header.read_text()).groups()
            assert (p,q)==(row[phase]["private_hash"],row[phase]["public"].split()[-1])
    for phase in ["original","stale","regenerated"]:
        cell=row["cells"][phase]
        assert cell["compiler_exit"]==src[phase]["compiler_exit"]==commands[cell["step"]-1]["status"]
        logs=list(map(json.loads,(raw/(phase+".stdout.jsonl")).read_bytes().splitlines()))
        stderr=(raw/(phase+".stderr")).read_bytes()
        assert cell["ice"]==(b"panicked at" in stderr or b"compiler unexpectedly panicked" in stderr)
        errors=[{"code": (j["message"]["code"] or {}).get("code"),"message":j["message"]["message"]}
                for j in logs if j.get("reason")=="compiler-message" and j["message"]["level"]=="error"]
        assert cell["errors"]==errors
        if cell["compiler_exit"]==0:
            assert cell["stdout"]=="7\n" and cell["exit"]==0 and not errors
            assert all(not j["fresh"] for j in logs if j.get("reason")=="compiler-artifact")
    return row


for k in summary:
    inspect(k)
def x(name):
    found=[k for k in summary if k.split("/")[-1]==name]
    assert len(found)==1,(name,found)
    return inspect(found[0])
def result(name):
    c=x(name)["cells"]["stale"]
    return "ICE" if c["ice"] else "OK" if c["compiler_exit"]==0 else "/".join(str(e["code"]) for e in c["errors"])

assert result("paired-232-source-equivalent")=="E0460"
reg=x("paired-233-source-equivalent")
assert reg["producer_original"]["public"]==reg["producer_edited"]["public"]
assert reg["cells"]["stale"]["compiler_exit"]!=0 and any(e["code"]=="E0391" for e in reg["cells"]["stale"]["errors"])
assert reg["cells"]["regenerated"]["stdout"]=="7\n"
assert all(result(n)=="ICE" for n in ["released-empty-cold-public","released-empty-cold-ordinary","released-proc-mixed-cold"])
for name,expect in {
    "expansion-ordinary":"OK","expansion-public":"OK","expansion-removed":"E0460",
    "private-defid-ordinary":"E0460","private-defid-public":"OK","proc-mixed-site":"OK",
    "old-reader-new-writer":"E0514","new-reader-new-occupied-slot":"OK",
    "new-reader-old-exact-public":"E0514","new-reader-old-stale-public":"E0514",
    "new-reader-old-stale-ordinary":"E0514","new-reader-old-occupied-slot":"E0514",
    "old-reader-old-all-ordinary-empty":"ICE", "old-reader-old-all-ordinary-private":"E0460",
}.items():
    assert result(name)==expect,(name,result(name),expect)
key=next(k for k in summary if k.endswith("/v5-legacy-wrong-valid-slot"))
base=root/"raw"/key
stale=(base/"stale-consumer-hygiene.rs").read_text()
regenerated=(base/"regenerated-consumer-hygiene.rs").read_text()
assert re.search(r'crate\d+::\{\{expn2\}\}.*kind: Macro\(Bang, "noise"\)',stale)
assert re.search(r'crate\d+::\{\{expn3\}\}.*kind: Macro\(Bang, "make"\)',regenerated)
print(f"{len(summary)} complete cases. Raw diagnostics, return codes, runtime results and metadata headers verified.")
for key in sorted(k for k in summary if not k.startswith("controls/")):
    print(key.rsplit("/",1)[-1],result(key.rsplit("/",1)[-1]))
