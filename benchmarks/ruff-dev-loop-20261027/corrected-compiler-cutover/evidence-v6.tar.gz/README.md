# Foreign crate metadata on a retained bridge

These are compiler correctness controls for Ohm Rust #233 on x86-64 Linux. Every stale-bridge case uses a physical copy of the prior bridge rlib. New and retained callers are compiled from identical Rust source. The final confirmation uses the same crate name, paths and compiler arguments in both directions, retires its private Cargo build state, and requires Cargo to report every successful caller compilation as dirty. A native return of zero must print `7`.

The exact source and compiler selection are in `scripts` and `drivers`. `source` in each summary row identifies its original fixture directory. The `raw` directory contains Cargo JSON, compiler stderr, independent rustc hygiene dumps, producer metadata headers and the actual invocation list. Compiler diagnostics and failed cases are retained. No test binary or external dependency is distributed here.

## Independent controls

- On matched stage-2 compilers, adding a private struct and changing an unreachable private iterator item from `u8` to `i8` makes #232 reject the ordinary bridge with E0460. The original #233 accepts the same stale indices and reports a spurious sizedness cycle. Rebuilding the bridge succeeds for both.
- Enabling a private macro that expands to zero tokens can move `make!` from expansion 2 to 3 without changing the public hash. A clean reconstruction of the producer exposes the released rustc ICE. Building the producer in its existing incremental directory can retain the old self-consistent metadata and mask the issue.
- A nonempty private macro can occupy the old index. The original and regenerated programs both print `7`, yet a stale v5 legacy bridge identifies the public expansion as `noise!`. The raw expansion dump records the distinction.
- The procedure tests a real procedural macro that stamps each generated token with `Span::mixed_site`. Original, stale and regenerated function output have to match independently.

## Reproduce

Run `python3 -B verify.py` from any directory with Python 3.11 or later to verify the per-file hashes and recompute the stored assertions. To repeat the compiler invocations, use a release-compatible Cargo and two matching compiler installations. `make-arm.py` can select stage drivers without copying or hardlinking a toolchain. It records actual dynamic-loader resolution and the driver SHA-256.

```sh
python3 -B scripts/make-arm.py /tmp/old-home OLD_SYSROOT OLD_DRIVER_DIR OHM_CARGO
python3 -B scripts/make-arm.py /tmp/new-home NEW_SYSROOT NEW_DRIVER_DIR OHM_CARGO
python3 -B scripts/matrix.py new-run /tmp/old-home /tmp/new-home
python3 -B scripts/path-probes.py /tmp/new-sdk-run /tmp/old-home /tmp/new-home
```

The matrix allocates CPU lanes 4–5 and 6–7. Set those lists to reserved cores when reproducing elsewhere. The runner creates a new directory beside its script, needs an empty writable cache, and uses the selected rustup homes through ordinary `cargo +ohm` or `cargo +ohm -Zohm-defaults=no`. Absolute paths, timestamps and rlib bytes can change across clean recreations. The oracle checks within-run public hashes, explicit stale-binding diagnostics, runtime output and macro identity.

## v6 outcome

Newly written metadata restores the correct foreign expansion. The new reader accepts exact legacy ordinary metadata and rejects legacy public-hashed inputs with E0514. One all-ordinary legacy graph still reaches an ICE. Its producer changes expansion allocation without changing even the ordinary full crate hash. The old reader reproduces that failure as well. A generated ordinary legacy definition change that actually changes the full hash is rejected with E0460.
