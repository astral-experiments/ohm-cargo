pub fn ordinary_library() {}
