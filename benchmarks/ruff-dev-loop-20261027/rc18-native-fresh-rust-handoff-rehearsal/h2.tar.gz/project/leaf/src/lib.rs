const _: () = tokens::observed!();
#[inline(never)] pub fn answer()->i32{0}
