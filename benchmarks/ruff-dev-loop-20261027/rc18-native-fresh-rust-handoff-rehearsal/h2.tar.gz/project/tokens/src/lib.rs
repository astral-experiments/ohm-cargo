#[macro_export] macro_rules! observed { () => { ::observer::observe!(foreign_token) }; }
