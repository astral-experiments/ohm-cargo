unsafe extern "C" {fn atoi(p:*const i8)->i32;} #[inline(never)] pub fn number()->i32{unsafe{atoi(std::hint::black_box(c"41").as_ptr())}}
