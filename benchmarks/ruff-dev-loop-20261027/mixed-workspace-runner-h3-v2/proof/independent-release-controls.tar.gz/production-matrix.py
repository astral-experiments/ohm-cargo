from pathlib import Path
import subprocess,sys,hashlib
D=Path(__file__).resolve().parent;W=Path('/dev/shm/ohm-mixed-certificate-20261027');q=Path.home()/'.cache/ohm-ruff-whole-skips-20261027';Rt=Path.home()/'.cache/ohm-ruff-packed-edges-20261026/nonleaf/trait-pgo-state';son='librustc_driver-774a793a844d5500.so';C=W/'cargo-v4-compiler/bounded-c1';R=W/'release-b1'/son;PC=q/'position-cargo-v3/cargo-observer';PR=D.parent/'stage2-wire-posobs4fmt'/son
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert sha(C)=='7d8a2d6715e0275308194508c70a4d49cb4c281d462c6d14b222ff4f5ecc1572' and sha(R)=='7c31057e86f800e313b7d32080c7a5abaa7b92fef92254ac21b2e43febf16384'
assert sha(PC)=='a99a694c680f474bef2ae17de20533890dc536606021db93aaf531e3ef40919a' and sha(PR)=='dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f'
for case,kind,cargo,driver,out in [('plain','product',C,R,'ffi'),('mir','product',C,R,'mir'),('warnings','product',C,R,'warnings'),('plain','incompatible',C,PR,'old-rustc'),('plain','incompatible',PC,R,'old-cargo')]:
 root=('release-bounded3-' if out=='old-cargo' else 'release-bounded2-')+out
 if list(sys.argv[1:]) and out not in sys.argv[1:]:continue
 with (D/(root+'.log')).open('wb')as f:r=subprocess.run([sys.executable,'-B',D/'hard-ffi-release.py','--case',case,'--kind',kind,'--cargo',cargo,'--driver',driver,'--runtime',Rt,'--out',root],stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(root,r.returncode,flush=True)
 if r.returncode:print((D/(root+'.log')).read_text()[-1900:]);break
