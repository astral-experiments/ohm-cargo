from pathlib import Path
import hashlib,json,tarfile,shutil
d=Path(__file__).resolve().parent;p=d/'product-b1-independent-release';p.mkdir()
s=lambda q:hashlib.file_digest(q.open('rb'),'sha256').hexdigest()
for f in ('hard-ffi-release.py','production-matrix.py','probe-wrapper.py','seal-release.py'):shutil.copy2(d/f,p/f)
shutil.copytree(d/'fixture-master',p/'fixture-master')
inputs={}
for case in ('ffi','warnings','mir','old-rustc','old-cargo'):
 q=d/(('release-bounded3-' if case=='old-cargo' else 'release-bounded2-')+case)
 rr=json.loads((q/'results.json').read_bytes());inputs[case]=json.loads((q/'identity.json').read_bytes())
 assert len(rr)==(12 if case=='ffi' else 6)
 for name in ('identity.json','results.json','physical-negative.json','direct-compiler-output.json'):
  if not(q/name).is_file():continue
  (p/case).mkdir(exist_ok=True);shutil.copy2(q/name,p/case/name)
 if case=='warnings':
  for row in rr:assert [(m['code'],m['message']) for m in row['diagnostics']]==[('dead_code','function `my_deliberately_unused_native_item` is never used')],row
 if case=='mir':
  clean=rr[-1]['MIR'];assert clean and all(r['MIR']==clean for r in(rr[2],rr[3],rr[4]))
 if case=='ffi':
  assert rr[8]['ELF']==rr[9]['ELF'] and rr[8]['rmeta']==rr[9]['rmeta']
 if case.startswith('old-'):assert rr[-1]['ELF']==rr[-2]['ELF']
(p/'README.md').write_text("""# Independent optimized mixed linkage controls

The positive pair uses Cargo 39ff2224 and compiler b5fb832. Each executable, driver and frontend digest is recorded in its own identity file. The same prior compiler and Cargo from #233 serve as separate downgrade arms. A C program calls the exported function through dlopen. Query handling is observed from a real Cargo-invoked compiler, its accepted command flag and exact cached recipe file identity. The ordinary positive uses no compiler wrapper.

There are 36 complete Cargo checks across five fixtures and two direct output-mode checks. Four dependency-only changes replay the good recipe while the C program returns 100, 94, 100 and 121. A changed environment value, included byte, proc macro output and same-size/backdated atomically replaced object from the active recipe all recompile to fresh native values. The edited empty-target reference produces identical ELF and embedded Rmeta for the physical-negative case. The local Cargo test harness separately denies cache eligibility for stored diagnostics and custom output requests. Each emitted warning and MIR file agrees with the clean reference. Previous Cargo without mixed-link support emits ordinary native artifacts and never creates a recipe. The current Cargo with the previous driver uses a full compilation. Both downgrades have the same final ELF as their own clean comparison.

Raw syscall logs remain private. The first development attempts at selecting the alternate-generation object used a pre-v4 filename and then assumed a manifest must exist after a full compile. The final runner identifies a physical object via its absolute name inside the actual .rlink and checks its numbered parent slot. A full legacy Cargo invocation does not write a recipe. The final older-Cargo test checks that distinction explicitly.
""")
(p/'sha256.json').write_text(json.dumps({str(x.relative_to(p)):s(x) for x in sorted(p.rglob('*')) if x.is_file()},indent=2)+'\n')
out=d/(p.name+'.tar.gz')
with tarfile.open(out,'w:gz') as t:
 for x in sorted(p.rglob('*')):
  if x.is_file():t.add(x,arcname=x.relative_to(p),recursive=False)
with tarfile.open(out,'r:gz') as t:
 for n,h in json.loads(t.extractfile('sha256.json').read()).items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
print(out,s(out),out.stat().st_size)
