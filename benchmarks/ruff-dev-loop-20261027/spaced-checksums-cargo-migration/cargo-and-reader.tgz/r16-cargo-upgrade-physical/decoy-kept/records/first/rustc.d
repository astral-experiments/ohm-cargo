/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-upgrade-physical/decoy-kept/target/debug/build/workspaces/38cb0e270142a154/v2-0275439935110c49/hold_direct/52103b051b8baa2b/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-upgrade-physical/decoy-kept/target/debug/build/workspaces/38cb0e270142a154/v2-0275439935110c49/hold_direct/52103b051b8baa2b/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-upgrade-physical/decoy-kept/target/debug/build/workspaces/38cb0e270142a154/v2-0275439935110c49/hold_direct/52103b051b8baa2b/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-upgrade-physical/decoy-kept/target/debug/build/workspaces/38cb0e270142a154/v2-0275439935110c49/hold_direct/52103b051b8baa2b/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-upgrade-physical/decoy-kept/target/debug/build/workspaces/38cb0e270142a154/v2-0275439935110c49/hold_direct/52103b051b8baa2b/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
