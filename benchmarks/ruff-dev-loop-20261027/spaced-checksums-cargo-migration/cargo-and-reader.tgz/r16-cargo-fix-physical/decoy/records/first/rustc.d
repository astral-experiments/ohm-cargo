/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/decoy/target/debug/build/workspaces/33db2cda7b7e75c1/v2-1caa52c3f7886ecb/hold_direct/504aab49b296082e/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/decoy/target/debug/build/workspaces/33db2cda7b7e75c1/v2-1caa52c3f7886ecb/hold_direct/504aab49b296082e/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/decoy/target/debug/build/workspaces/33db2cda7b7e75c1/v2-1caa52c3f7886ecb/hold_direct/504aab49b296082e/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/decoy/target/debug/build/workspaces/33db2cda7b7e75c1/v2-1caa52c3f7886ecb/hold_direct/504aab49b296082e/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/decoy/target/debug/build/workspaces/33db2cda7b7e75c1/v2-1caa52c3f7886ecb/hold_direct/504aab49b296082e/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
