/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/ordinary/clean-target/debug/build/workspaces/f201294c0aceb7e9/v2-58bbcbc4c80b838d/hold_direct/d0c754c45f3a57b1/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/ordinary/clean-target/debug/build/workspaces/f201294c0aceb7e9/v2-58bbcbc4c80b838d/hold_direct/d0c754c45f3a57b1/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/ordinary/clean-target/debug/build/workspaces/f201294c0aceb7e9/v2-58bbcbc4c80b838d/hold_direct/d0c754c45f3a57b1/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/ordinary/clean-target/debug/build/workspaces/f201294c0aceb7e9/v2-58bbcbc4c80b838d/hold_direct/d0c754c45f3a57b1/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/r16-cargo-fix-physical/ordinary/clean-target/debug/build/workspaces/f201294c0aceb7e9/v2-58bbcbc4c80b838d/hold_direct/d0c754c45f3a57b1/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
