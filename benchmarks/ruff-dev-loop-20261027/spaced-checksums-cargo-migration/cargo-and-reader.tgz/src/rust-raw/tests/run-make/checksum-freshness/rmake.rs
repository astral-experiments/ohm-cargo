//@ needs-target-std
use run_make_support::{rfs, rustc};

fn main() {
    rustc().input("lib.rs").arg("-Zchecksum-hash-algorithm=blake3").emit("dep-info").run();
    let make_file_contents = rfs::read_to_string("lib.d");
    let expected_contents = rfs::read_to_string("expected.d");
    assert_eq!(make_file_contents, expected_contents);
    assert!(!expected_contents.is_empty());

    if cfg!(unix) {
        checksum_uses_the_literal_filename();
    }
}

fn checksum_uses_the_literal_filename() {
    use std::path::Path;

    use run_make_support::rust_lib_name;

    let name = rust_lib_name("helper");
    rfs::write("helper.rs", "pub fn value() -> u32 { 17 }");
    rfs::write("user.rs", "pub fn value() -> u32 { helper::value() }");
    rustc().input("helper.rs").crate_type("rlib").run();
    rfs::create_dir("actual dir");
    rfs::create_dir(r"actual\ dir");
    let actual = Path::new("actual dir").join(&name);
    rfs::copy(&name, &actual);
    rfs::write(Path::new(r"actual\ dir").join(&name), b"different file behind the Make escape");

    let checksum = |path: &Path| {
        let path = std::path::absolute(path).unwrap();
        rustc()
            .input("user.rs")
            .edition("2021")
            .crate_type("rlib")
            .extern_("helper", &path)
            .arg("-Zbinary-dep-depinfo")
            .arg("-Zchecksum-hash-algorithm=sha256")
            .emit("dep-info=user.d,metadata")
            .run();
        let depfile = rfs::read_to_string("user.d");
        let spelling = path.display().to_string().replace(' ', "\\ ");
        depfile
            .lines()
            .find_map(|line| {
                line.strip_prefix("# checksum:")?
                    .strip_suffix(&format!(" {spelling}"))
                    .map(str::to_owned)
            })
            .unwrap()
    };
    assert_eq!(checksum(Path::new(&name)), checksum(&actual));
}
