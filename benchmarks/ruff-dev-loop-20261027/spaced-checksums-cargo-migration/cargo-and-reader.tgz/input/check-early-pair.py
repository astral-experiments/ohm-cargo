from pathlib import Path
import json,sys,hashlib
h=Path(sys.argv[1]);u=json.loads((h/'r16-cargo-upgrade-physical/result.json').read_text());m=json.loads((h/'r16-cargo-fix-physical/result.json').read_text())
for name,rows in u.items():
 print('upgrade',name,[(k,v['value'],v['fresh'],v['wire'],v['complete']) for k,v in rows.items()])
 assert rows['first']['value']==rows['train']['value']==rows['unchanged']['value']==17 and rows['empty']['value']==rows['upgrade']['value']==rows['upgrade-noop']['value']==29
 if name.startswith('decoy-'):
  assert rows['changed']['value']==17 and rows['changed']['all_fresh'] and rows['changed']['wire']=='OBS1' and rows['changed']['complete']==1
  assert not rows['upgrade']['fresh'] and not rows['upgrade-noop']['fresh'] and rows['upgrade']['complete']==0 and rows['upgrade']['fp']==rows['changed']['fp']
 else:assert rows['unchanged']['fresh'] and rows['changed']['value']==29 and rows['upgrade']['fresh']
for name,rows in m.items():
 print('fixed/old',name,[(k,v['value'],v['fresh'],v['wire'],v['complete']) for k,v in rows.items()])
 assert rows['changed']['value']==rows['empty']['value']==29
 if name=='ordinary':assert rows['unchanged']['all_fresh'] and rows['unchanged']['complete']==1
 else:assert not rows['unchanged']['fresh'] and rows['unchanged']['complete']==0
