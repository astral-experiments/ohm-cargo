#!/usr/bin/env bash
set -euo pipefail
p=/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027; a=$p/assets; s=$p/states/raw-path; src=$p/src-stock16
if [[ ! -d "$s" ]]; then
 mkdir -p "$s"/{rustup/toolchains,cargo-home/registry/cache,cargo-home/registry/index,target,shared}
 ln -s "$a/stock16-sdk" "$s/rustup/toolchains/ohm"
 for dir in index cache; do orig=("$a/registry/$dir"/*); [[ ${#orig[@]} == 1 ]]; cp -a --reflink=auto "${orig[0]}" "$s/cargo-home/registry/$dir/index.crates.io-1949cf8c6b5b557f"; done
 cp "$a/git-commit-info" "$src/git-commit-info"
fi
export PATH=/home/dev-user/.cargo/bin:$PATH RUSTUP_HOME="$s/rustup" CARGO_HOME="$s/cargo-home" CARGO_TARGET_DIR="$s/target" CARGO_BUILD_BUILD_DIR="$s/shared" CARGO_NET_OFFLINE=true CARGO_PROFILE_RELEASE_INCREMENTAL=false CFG_RELEASE_CHANNEL=dev
export RUSTFLAGS="-Cprofile-use=$a/rustc-pgo.profdata -Cllvm-args=-pgo-warn-missing-function=false"
cd "$src"; sha256sum -c "$a/profile.sha256" --ignore-missing >/dev/null 2>&1 || (cd "$a" && sha256sum -c profile.sha256)
test -f "$src/src/compiler/fingerprint/dep_info.rs"
for role in "$@"; do
 if [[ "$role" == fixed ]]; then git apply --check "$a/cargo-raw-paths.patch"; git apply "$a/cargo-raw-paths.patch"; fi
 if [[ "$role" == unit ]]; then taskset -c 8-23 cargo +ohm test --locked --offline --lib -p cargo --features ohm-defaults -j12 legacy_observers_retrain_only_when_an_input_contains_spaces -- --nocapture >"$p/logs/$role.log" 2>&1; continue; fi
 taskset -c 8-23 cargo +ohm build --release --locked --offline -p cargo --bin cargo --features ohm-defaults -j12 >"$p/logs/$role.log" 2>&1
 cp "$s/target/release/cargo" "$p/subjects/raw-$role"; sha256sum "$p/subjects/raw-$role" >"$p/subjects/raw-$role.sha256"; "$p/subjects/raw-$role" -Vv > "$p/subjects/raw-$role.version"
done
