#![forbid(unsafe_code)]
fn main() { println!("{}:{}", revision::value(), engine::payload::<u32>()); }
