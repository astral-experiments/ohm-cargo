#[inline(never)]
pub fn value() -> u32 { 5 }
