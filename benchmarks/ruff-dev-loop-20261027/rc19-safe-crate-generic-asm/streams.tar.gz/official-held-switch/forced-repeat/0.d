# ohm-raw-checksum-paths-v2
/study/official-held-switch/state/target/debug/build/workspaces/ccc1444096c082e3/v2-57b0eeb27b5cdd45/app/2fcd8e8703188796/out/app.d: app/src/main.rs

/study/official-held-switch/state/target/debug/build/workspaces/ccc1444096c082e3/v2-57b0eeb27b5cdd45/app/2fcd8e8703188796/out/app: app/src/main.rs

app/src/main.rs:
# checksum:blake3=190603863eac0e4ef863aea403fb33622786743f549bcd964868d6311207c749 file_len:134 app/src/main.rs
