# ohm-raw-checksum-paths-v2
/study/official-held-switch/state/target/debug/build/workspaces/ccc1444096c082e3/v2-57b0eeb27b5cdd45/app/2fcd8e8703188796/out/app.d: app/src/main.rs

/study/official-held-switch/state/target/debug/build/workspaces/ccc1444096c082e3/v2-57b0eeb27b5cdd45/app/2fcd8e8703188796/out/app: app/src/main.rs

app/src/main.rs:
# checksum:blake3=7d710f07630857e49e5ced4e3299cc2ed483c12bdc2f4b700b0327f01c4777ce file_len:102 app/src/main.rs
