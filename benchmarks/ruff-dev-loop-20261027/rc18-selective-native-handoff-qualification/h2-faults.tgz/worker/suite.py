from pathlib import Path
import ast,hashlib,json,os,platform,re,shutil,subprocess,sys
r=Path(__file__).resolve().parent
label=sys.argv[1]; assert label.isalnum()
os.umask(0o002)
w=r/label;w.mkdir(mode=0o700);src=w/'source';shutil.copytree(r.parent/'trial1/source',src)
case='generate_inline_tests'
manifest=src/'reader/Cargo.toml';manifest.write_text(manifest.read_text().replace('reader_case',case))
reports=w/'reports';reports.mkdir();audit=w/'audit';audit.mkdir();caps=w/'capsule';caps.mkdir()
for n in ('enroll','check','data.py'):shutil.copyfile(r/n,caps/n)
for n in ('check','enroll'):(caps/n).chmod(0o755)
shutil.copyfile(r/'libfdhash.so',caps/'fdhash.so')
for n in ('ld.stock','training.json','policy.json','control'):(caps/n).touch()
(caps/'control').write_text('normal');(caps/'audit').mkdir()
base=Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027');install=base/'frozen-toolchain';cargo=Path('/mnt/devbox-scratch/dev-user/ohm-rc18-pgo-qualification-20261028/cargo')
driver=base/'mixed-module-children-17-v1-20261028/tool-rc18-export-r2/candidate-driver.so'
sdk=w/'sdk';sdk.mkdir();ru=w/'rustup';(ru/'toolchains').mkdir(parents=True);(ru/'toolchains/ohm').symlink_to(sdk)
stem=Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd');stock=(install/stem).resolve();so=next((install/'lib').glob('librustc_driver-*.so')).name
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(stock)=='0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'
assert sha(cargo)=='cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8' and sha(driver)=='22abce6921b46f93f387c7d3d99cefa4df9c0a866619447077699ef81a73827f'
assert shutil.disk_usage(w).free>=8*1024**3 and os.geteuid()==1000 and platform.machine()=='x86_64'
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','OHM_QA','WILD_')) and k not in ('RUSTFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD','LD_AUDIT','RUST_BACKTRACE')}
env.update(RUSTUP_HOME=str(ru),RUSTUP_AUTO_INSTALL='0',PATH=str(Path.home()/'.cargo/bin')+':'+os.environ['PATH'],CARGO_HOME=str(w/'cargo-home'),CARGO_TARGET_DIR=str(w/'target'),CARGO_BUILD_BUILD_DIR=str(w/'shared'),CARGO_NET_OFFLINE='true')
c=Path('/run/ohm-native-handoff-v1');cmd=[str(Path.home()/'.cargo/bin/cargo'),'+ohm','test','--no-run','-p','reader','--test',case,'--locked','--offline','-j1','--message-format=json']
ext=w/'external';ext.mkdir();rows={};outdir=None
def dump(f,j):f.write_text(json.dumps(j,sort_keys=True,indent=2)+'\n')
def phase(name,expected,gate=True):
 global outdir
 dest=reports/name;dest.mkdir();before=set(audit.glob('*.json'));native=r/'gate' if gate else (caps/'enroll')
 ns=['taskset','-c','24,25','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--bind',str(w),str(w),'--tmpfs','/tmp','--tmpfs','/run','--ro-bind',str(caps),str(c),'--bind',str(audit),str(c/'audit'),'--ro-bind',str(stock),str(c/'ld.stock'),'--ro-bind',str(install),str(sdk),'--ro-bind',str(driver),str(sdk/'lib'/so),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--ro-bind',str(native),str(sdk/stem),'--chdir',str(src),'--']
 trace=dest/'trace';cp=subprocess.run(ns+['strace','-f','-qq','-s','131072','-e','trace=execve','-o',str(trace),'--',*cmd],env=env,capture_output=True,timeout=120)
 (dest/'stdout').write_bytes(cp.stdout);(dest/'stderr').write_bytes(cp.stderr)
 procs=[]
 for raw in trace.read_text(errors='replace').splitlines():
  m=re.match(r'^(\d+)\s+execve\(("(?:[^"\\]|\\.)*"), (\[.*\]), (?:0x[^ ]+ )?/\* [0-9]+ vars \*/\)\s+= 0$',raw)
  if not m:continue
  path=ast.literal_eval(m[2]);args=ast.literal_eval(m[3]);role=Path(path).name
  unit=None
  if role=='rustc':
   if '--crate-name' not in args:continue
   unit=args[args.index('--crate-name')+1]
   if unit=='___':continue
   zs={a[2:] for a in args if a.startswith('-Z') and len(a)>2}|{b for a,b in zip(args,args[1:]) if a=='-Z'}
   role='link-only' if 'link-only' in zs else 'full'
  elif role not in ('cc','collect2','ld.bfd','ld.stock','check'):continue
  procs.append({'pid':int(m[1]),'role':role,'unit':unit,'executable':path,'argv':args,'sha256':hashlib.sha256(raw.encode()).hexdigest()})
 after=[json.loads(f.read_bytes()) for f in set(audit.glob('*.json'))-before if f.name!='training.json']
 msg=[json.loads(l) for l in cp.stdout.splitlines() if l.strip()]
 for j in msg:
  if j.get('reason')=='build-script-executed' and '/search#' in j['package_id']:outdir=Path(j['out_dir'])
 exe=next((Path(j['executable']) for j in msg if j.get('reason')=='compiler-artifact' and j['target']['name']==case and j.get('executable')),None)
 val=None
 if expected is not None:
  assert cp.returncode==0 and exe is not None,(name,cp.stderr[-1300:])
  run=subprocess.run([exe],capture_output=True,timeout=5);assert run.returncode==0;val=run.stdout.decode().strip()
  assert val=='native-value='+str(expected),(name,val)
 else:assert cp.returncode==101,(name,cp.returncode)
 row={'phase':name,'architecture':platform.machine(),'euid':os.geteuid(),'status':cp.returncode,'value':val,'exe_sha256':sha(exe)if exe else None,'commands':procs,'decisions':after,'argv':cmd,'normal_flags':True}
 rows[name]=row;dump(dest/'result.json',row);dump(reports/'all.json',rows)
 print(name,cp.returncode,val,[(p['role'],p['unit']) for p in procs if p['unit']],sum(p['role']=='ld.stock' for p in procs),[(q['reason'],q.get('workers'))for q in after],flush=True)
 if gate:assert len(after)==1,(name,len(after),cp.stderr[-1200:])
 return row
phase('cold',41,False);phase('training',41,False)
training=audit/'training.json';shutil.copyfile(training,caps/'training.json');j=json.loads(training.read_bytes())
policy={'schema':1,'wild_sha256':sha(stock),'checker_sha256':sha(caps/'check'),'target':j['target'],'gcc_sha256':sha(Path('/usr/bin/cc')),'collect2_sha256':sha(Path(subprocess.check_output(['/usr/bin/cc','-print-prog-name=collect2'],text=True).strip())),'required_mode':0o775,'workers':{'1':{'training_sha256':sha(training),'output_blake3':j['output_blake3']}}}
dump(caps/'policy.json',policy)
pos=phase('same',41)
assert pos['decisions'][0]['reason']=='fixture-native-fresh' and not any(p['role']=='ld.stock'for p in pos['commands'])
for k in ['refuse','wrong-nonce','diagnostic']:
 (caps/'control').write_text(k);v=phase(k,41);assert any(p['role']=='ld.stock'for p in v['commands'])
for label, reason in [('wrong-nonce', 'invalid-response'), ('diagnostic', 'checker-refusal')]:
    decision = rows[label]['decisions'][0]
    assert decision['checker_code'] == 0 and decision['reason'] == reason, (label, decision)
    assert rows[label]['value'] == 'native-value=41'
dump(reports/'qualified.json', {'pass':True, 'injected_branches': ['wrong-nonce','diagnostic'], 'gate':sha(r/'gate')})
