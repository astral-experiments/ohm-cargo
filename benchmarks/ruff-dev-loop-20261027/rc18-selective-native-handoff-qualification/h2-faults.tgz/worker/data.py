"""Fixed H2 transport-only lower checker. Production input evidence is independently supplied on H8."""
import ctypes,hashlib,json,os,sys
from pathlib import Path
from ctypes import c_int,c_void_p,c_uint64,POINTER
CAP=Path('/run/ohm-native-handoff-v1')
lib=ctypes.CDLL(str(CAP/'fdhash.so'),use_errno=True);lib.link_check_fd.argtypes=[c_int,c_void_p,POINTER(c_uint64)]
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 fd=os.open(p,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC)
 try:
  import stat
  if not stat.S_ISREG(os.fstat(fd).st_mode):raise OSError("nonregular")
  b=ctypes.create_string_buffer(32);n=c_uint64();assert lib.link_check_fd(fd,b,ctypes.byref(n))==0;return b.raw.hex()
 finally:os.close(fd)
def key(args):
 norm=[];vals={};dirs=[];libs=[];roles=0
 for i,a in enumerate(args):
  p=Path(a);clear=a
  if p.name=='symbols.o':clear='<rustc-symbols>/symbols.o';roles+=1
  elif a.startswith('-L') and Path(a[2:]).name=='raw-dylibs':
   assert not list(Path(a[2:]).iterdir());clear='-L<rustc-raw-dylibs>';roles+=1
  elif a.startswith('-plugin-opt=-fresolution='):
   assert Path(a.split('=',2)[-1]).stat().st_size==0;clear='<known-non-LTO-GCC-res>';roles+=1
  norm.append(clear)
  if a.startswith('-L'):dirs.append((clear,Path(a[2:])))
  if a.startswith('-l'):libs.append(a[2:])
  if i and args[i-1]=='-o':continue
  if not a.startswith('-') and p.suffix in ('.o','.rlib','.a','.so'):vals[clear]=digest(p)
 assert roles==3
 for d,p in dirs:
  for lib in set(libs):
   for ex in ('.a','.so'):
    n='lib'+lib+ex
    try:v=digest(p/n)
    except FileNotFoundError:v='ENOENT'
    vals[d+'/'+n]=v
 return sha(json.dumps([norm,vals],sort_keys=True,separators=(',',':')).encode())
