import hashlib,json,os,shutil,socket,subprocess,traceback
from pathlib import Path
assert socket.gethostname()=='charlie-ohm-relink-b-1024'
d=Path(__file__).resolve().parent
released=Path('/dev/shm/ohm-published-member-h2-20261028/installed17')
cargo=d.parent/'cargo'
def sha(f):
    with f.open('rb') as fd:return hashlib.file_digest(fd,'sha256').hexdigest()
def main():
    assert sha(cargo)=='cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8'
    assert sha(released/'bin/cargo')=='4e4065390403afbf4fb77b2f41fbc21c59afe3dda2337a5bbe29fda29a47dbb3'
    sdk=d/'sdk';sdk.mkdir()
    jobs=[('parent','released',17,True),('parent','candidate',18,False),('candidate','released',17,True),('candidate','candidate',18,True),('candidate','released',18,False)]
    rows=[]
    for script,image,revision,ok in jobs:
        case=d/(script+'-'+image+'-'+str(revision));case.mkdir(mode=0o700)
        home=case/'rustup';(home/'toolchains').mkdir(parents=True)
        name='ohm-1.99.0-'+str(revision)
        (home/'toolchains'/name).symlink_to(sdk)
        env=dict(os.environ,RUSTUP_HOME=str(home),RUSTUP_AUTO_INSTALL='0',RUSTC_BOOTSTRAP='1',
                 CARGO_HOME=str(case/'cargo-home'),CARGO_BUILD_BUILD_DIR=str(case/'shared-build'),
                 CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',LC_ALL='C.UTF-8',
                 OHM_TOOLCHAIN=name,smoke_root=str(case),RELEASE_DIRECTORY=str(d))
        for n in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):
            env.pop(n,None)
        use=cargo if image=='candidate' else released/'bin/cargo'
        cmd=['bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--ro-bind',str(released),str(sdk),'--ro-bind',str(use),str(sdk/'bin/cargo'),'--bind',str(case),str(case),'--','bash',str(d/(script+'.sh'))]
        with (case/'stdout').open('wb') as out,(case/'stderr').open('wb') as err:
            r=subprocess.run(cmd,cwd=case,env=env,stdout=out,stderr=err,timeout=160)
        stderr=(case/'stderr').read_text()
        row={'script':script,'cargo':image,'cargo_sha256':sha(use),'revision':revision,'status':r.returncode,'stderr':sha(case/'stderr'),'rustc':sha(released/'bin/rustc'),'driver':sha(next((released/'lib').glob('librustc_driver-*.so')))}
        for n in ('defaults-rustc-args','disabled-rustc-args'):
            row[n]=(case/n).read_text().splitlines() if (case/n).exists() else []
        rows.append(row)
        print(script,image,revision,r.returncode,flush=True)
        assert (r.returncode==0)==ok,stderr[-1200:]
        if ok:
            assert row['defaults-rustc-args'] and set(row['defaults-rustc-args'])=={'enabled'}
            assert row['disabled-rustc-args'] and set(row['disabled-rustc-args'])=={'disabled'}
        elif script=='parent':
            assert 'Ohm defaults missing from ohm_smoke rustc invocation' in stderr,stderr[-1000:]
        else:
            assert 'unexpected proc-macro cache setting in ohm_smoke rustc invocation' in stderr,stderr[-1000:]
    (d/'results.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
try:main()
except BaseException:
    (d/'failure.txt').write_text(traceback.format_exc())
    raise

