#!/usr/bin/env bash
set -euo pipefail
smoke_crate="$smoke_root/crate"
mkdir -p "$smoke_crate/src" "$smoke_crate/macros/src"
cat > "$smoke_crate/Cargo.toml" <<'EOF'
[package]
name = "ohm-smoke"
version = "0.0.0"
edition = "2024"

[dependencies]
ohm-smoke-macros = { path = "macros" }
EOF
cat > "$smoke_crate/macros/Cargo.toml" <<'EOF'
[package]
name = "ohm-smoke-macros"
version = "0.0.0"
edition = "2024"

[lib]
proc-macro = true
EOF
cat > "$smoke_crate/macros/src/lib.rs" <<'EOF'
use proc_macro::TokenStream;

#[proc_macro]
pub fn make_answer(_: TokenStream) -> TokenStream {
    "fn answer() -> u32 { 42 }".parse().unwrap()
}
EOF
cat > "$smoke_crate/src/main.rs" <<'EOF'
ohm_smoke_macros::make_answer!();

fn main() {
    assert!(invert(false));
    assert_eq!(answer(), 42);
}

fn invert(value: bool) -> bool {
    !value
}
EOF

rustc_wrapper="$smoke_root/rustc-wrapper"
cat > "$rustc_wrapper" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

crate_name=
has_public_api_hash=false
has_proc_macro_cache=false
previous_argument=
for argument in "$@"; do
  if [[ "$previous_argument" == "--crate-name" ]]; then
    crate_name="$argument"
  fi
  case "$argument" in
    -Zpublic-api-hash) has_public_api_hash=true ;;
    -Zcache-proc-macros) has_proc_macro_cache=true ;;
  esac
  previous_argument="$argument"
done

if [[ "$crate_name" == "ohm_smoke" ]]; then
  case "${OHM_EXPECT_DEFAULTS:?}" in
    enabled)
      if [[ "$has_public_api_hash" != true || "$has_proc_macro_cache" != true ]]; then
        echo "Ohm defaults missing from ohm_smoke rustc invocation" >&2
        exit 1
      fi
      ;;
    disabled)
      if [[ "$has_public_api_hash" == true || "$has_proc_macro_cache" == true ]]; then
        echo "Ohm defaults present on disabled ohm_smoke rustc invocation" >&2
        exit 1
      fi
      ;;
    *)
      echo "invalid OHM_EXPECT_DEFAULTS value" >&2
      exit 1
      ;;
  esac
  printf '%s\n' "$OHM_EXPECT_DEFAULTS" >> "${OHM_RUSTC_LOG:?}"
fi

exec "$@"
EOF
chmod +x "$rustc_wrapper"

unset CARGO_BUILD_RUSTFLAGS CARGO_ENCODED_RUSTFLAGS RUSTFLAGS RUSTC_WORKSPACE_WRAPPER
defaults_log="$smoke_root/defaults-rustc-args"
OHM_EXPECT_DEFAULTS=enabled \
  OHM_RUSTC_LOG="$defaults_log" \
  RUSTC_WRAPPER="$rustc_wrapper" \
  CARGO_TARGET_DIR="$smoke_root/defaults-target" \
  cargo +"$OHM_TOOLCHAIN" build --manifest-path "$smoke_crate/Cargo.toml"
grep -Fx enabled "$defaults_log" >/dev/null

disabled_log="$smoke_root/disabled-rustc-args"
OHM_EXPECT_DEFAULTS=disabled \
  OHM_RUSTC_LOG="$disabled_log" \
  RUSTC_WRAPPER="$rustc_wrapper" \
  CARGO_TARGET_DIR="$smoke_root/disabled-target" \
  cargo +"$OHM_TOOLCHAIN" -Zohm-defaults=no build \
    --manifest-path "$smoke_crate/Cargo.toml"
grep -Fx disabled "$disabled_log" >/dev/null

