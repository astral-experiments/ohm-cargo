
#[macro_use] extern crate native;
#[derive(Observe)] pub struct Marker;
#[marked] pub struct Unexpanded;
