
#![crate_type="proc-macro"]
extern crate proc_macro;
use proc_macro::TokenStream;
extern "C" { fn value() -> u32; }
#[proc_macro_derive(Observe)] pub fn observe(_:TokenStream)->TokenStream{
 let n=unsafe{value()};eprintln!("derive {n}");format!("pub const DERIVED_{n}: u32 = {n};").parse().unwrap()
}
#[proc_macro_attribute] pub fn marked(_:TokenStream,_:TokenStream)->TokenStream{
 let n=unsafe{value()};eprintln!("attribute {n}");format!("pub const MARKED_{n}: u32 = {n};").parse().unwrap()
}
