# ohm-raw-checksum-paths-v2
/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-preserved/warm/target/debug/build/workspaces/76049610abf86511/v2-0a288cc0360046cc/hold_direct/fd517c790c98c06a/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-preserved/warm/target/debug/build/workspaces/76049610abf86511/v2-0a288cc0360046cc/hold_direct/fd517c790c98c06a/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-preserved/warm/target/debug/build/workspaces/76049610abf86511/v2-0a288cc0360046cc/hold_direct/fd517c790c98c06a/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-preserved/warm/target/debug/build/workspaces/76049610abf86511/v2-0a288cc0360046cc/hold_direct/fd517c790c98c06a/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-preserved/warm/target/debug/build/workspaces/76049610abf86511/v2-0a288cc0360046cc/hold_direct/fd517c790c98c06a/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
