# ohm-raw-checksum-paths-v2
/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-current/fresh-independent/target/debug/build/workspaces/fec4d6d772c8724b/v2-85e04bb12efec7f8/hold_direct/488ee5d79a75cddf/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-current/fresh-independent/target/debug/build/workspaces/fec4d6d772c8724b/v2-85e04bb12efec7f8/hold_direct/488ee5d79a75cddf/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-current/fresh-independent/target/debug/build/workspaces/fec4d6d772c8724b/v2-85e04bb12efec7f8/hold_direct/488ee5d79a75cddf/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-current/fresh-independent/target/debug/build/workspaces/fec4d6d772c8724b/v2-85e04bb12efec7f8/hold_direct/488ee5d79a75cddf/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-native-macro-session-direct-20261028/phase-after/synced/dso-current/fresh-independent/target/debug/build/workspaces/fec4d6d772c8724b/v2-85e04bb12efec7f8/hold_direct/488ee5d79a75cddf/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=4b458726174f33ce55f2e18909859f10d240441b14eed053c75b0fb1cb6bd851 file_len:236 hold_direct/src/main.rs
