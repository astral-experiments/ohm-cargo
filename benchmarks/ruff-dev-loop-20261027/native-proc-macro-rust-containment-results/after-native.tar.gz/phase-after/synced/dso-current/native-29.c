unsigned selected_literal(void) { return 29; }
