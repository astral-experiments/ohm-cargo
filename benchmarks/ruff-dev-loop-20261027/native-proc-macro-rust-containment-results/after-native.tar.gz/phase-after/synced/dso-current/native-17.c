unsigned selected_literal(void) { return 17; }
