# ohm-raw-checksum-paths-v2
/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-released/dso-preserved/fresh-independent/target/debug/build/workspaces/e52d97cbe0c256d8/v2-7bd9b82d952b7af8/hold_direct/b4673115226e4677/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-released/dso-preserved/fresh-independent/target/debug/build/workspaces/e52d97cbe0c256d8/v2-7bd9b82d952b7af8/hold_direct/b4673115226e4677/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-released/dso-preserved/fresh-independent/target/debug/build/workspaces/e52d97cbe0c256d8/v2-7bd9b82d952b7af8/hold_direct/b4673115226e4677/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-released/dso-preserved/fresh-independent/target/debug/build/workspaces/e52d97cbe0c256d8/v2-7bd9b82d952b7af8/hold_direct/b4673115226e4677/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-released/dso-preserved/fresh-independent/target/debug/build/workspaces/e52d97cbe0c256d8/v2-7bd9b82d952b7af8/hold_direct/b4673115226e4677/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=f3538d4d57b736e5338a3acc5eef910cc3fd90adb6570d67990fcf2dff470f7c file_len:237 hold_direct/src/main.rs
