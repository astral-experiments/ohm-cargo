
#[macro_use] extern crate native;
#[derive(Witness)] struct Caller;
#[mark] struct Other;
fn main() { let _=Caller; println!("{DERIVED},{ATTRIBUTE}"); }
