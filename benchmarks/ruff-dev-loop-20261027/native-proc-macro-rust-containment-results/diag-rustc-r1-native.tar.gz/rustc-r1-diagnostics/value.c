int value(void) { return 17; }
