
#![crate_type="proc-macro"]
extern crate proc_macro;
use proc_macro::TokenStream;
extern "C" {fn value()->i32;}
fn item(name:&str)->TokenStream {
 let n=unsafe{value()}; eprintln!("native {name} {n}");
 let ty=if n==17 {"u8"} else {"i16"};
 format!("const {name}: u8 = {n}{ty};").parse().unwrap()
}
#[proc_macro_derive(Witness)] pub fn derive(_:TokenStream)->TokenStream{item("DERIVED")}
#[proc_macro_attribute] pub fn mark(_:TokenStream,_:TokenStream)->TokenStream{item("ATTRIBUTE")}
