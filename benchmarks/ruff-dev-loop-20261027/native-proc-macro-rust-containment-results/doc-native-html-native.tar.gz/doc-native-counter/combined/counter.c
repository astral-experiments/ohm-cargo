static unsigned seq; unsigned next(void){return ++seq;}
