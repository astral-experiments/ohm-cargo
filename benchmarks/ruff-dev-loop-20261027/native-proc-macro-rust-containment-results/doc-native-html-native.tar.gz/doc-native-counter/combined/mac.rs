#![crate_type="proc-macro"]
extern crate proc_macro;
use proc_macro::TokenStream;
extern "C" {fn next()->u32;}
fn number(name:&str)->TokenStream {
    let n=unsafe{next()}; eprintln!("counter {} {name} {n}",std::process::id());
    format!("pub const {name}_{n}: u32 = {n};").parse().unwrap()
}
#[proc_macro_derive(Count)] pub fn count(_:TokenStream)->TokenStream{number("DERIVE")}
#[proc_macro_attribute] pub fn number_attr(_:TokenStream,_:TokenStream)->TokenStream{number("ATTR")}
