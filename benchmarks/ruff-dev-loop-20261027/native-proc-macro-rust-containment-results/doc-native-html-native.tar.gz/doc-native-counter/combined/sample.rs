#[macro_use] extern crate mac;
#[derive(Count)] pub struct T;
#[number_attr] pub struct Replaced;
