# ohm-raw-checksum-paths-v2
/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-common-r2/dso-preserved/warm/target/debug/build/workspaces/d5d8fdfc792c1b2d/v2-8c827fce7d0dd50a/hold_direct/3f590336c6114ce9/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-common-r2/dso-preserved/warm/target/debug/build/workspaces/d5d8fdfc792c1b2d/v2-8c827fce7d0dd50a/hold_direct/3f590336c6114ce9/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-common-r2/dso-preserved/warm/target/debug/build/workspaces/d5d8fdfc792c1b2d/v2-8c827fce7d0dd50a/hold_direct/3f590336c6114ce9/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-common-r2/dso-preserved/warm/target/debug/build/workspaces/d5d8fdfc792c1b2d/v2-8c827fce7d0dd50a/hold_direct/3f590336c6114ce9/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-native-macro-session-direct-20261028/attr-sync-common-r2/dso-preserved/warm/target/debug/build/workspaces/d5d8fdfc792c1b2d/v2-8c827fce7d0dd50a/hold_direct/3f590336c6114ce9/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=f3538d4d57b736e5338a3acc5eef910cc3fd90adb6570d67990fcf2dff470f7c file_len:237 hold_direct/src/main.rs
