fn main() { println!("{}",leaf::value(std::hint::black_box(30))); }
