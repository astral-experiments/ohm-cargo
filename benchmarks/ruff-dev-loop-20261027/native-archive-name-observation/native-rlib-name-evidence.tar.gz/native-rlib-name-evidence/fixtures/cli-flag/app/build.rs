fn main() { println!("cargo::rerun-if-changed=build.rs"); println!("cargo::rustc-link-arg-bin=app=-Wl,--write-layout"); }
