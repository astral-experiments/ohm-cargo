#![no_std]
#![no_main]
use core::arch::global_asm;
global_asm!(r#"
.global _start
.type _start,@function
_start:
  movzbl {value}(%rip), %edi
  leaq picked_end(%rip), %rax
  leaq picked_start(%rip), %rdx
  subq %rdx, %rax
  addl %eax, %edi
  movl $60, %eax
  syscall
  ud2
"#,value=sym leaf::AUDIT_BYTES,options(att_syntax));
#[panic_handler] fn panic(_: &core::panic::PanicInfo)->! { loop {} }
