fn main() {
 let path = std::path::PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).join("layout.ld");
 println!("cargo::rerun-if-changed=build.rs");
 println!("cargo::rerun-if-changed=layout.ld");
 for flag in ["-nostartfiles", "-static", "-no-pie"] { println!("cargo::rustc-link-arg={flag}"); }
 println!("cargo::rustc-link-arg=-Wl,-T,{}",path.display());
}
