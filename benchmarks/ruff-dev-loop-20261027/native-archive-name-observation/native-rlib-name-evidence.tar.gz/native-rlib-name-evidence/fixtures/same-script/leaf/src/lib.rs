#![no_std]
#[used]
#[unsafe(no_mangle)]
#[unsafe(link_section = ".audit_marker")]
pub static AUDIT_BYTES: [u8; 42] = [41; 42];
/// Hidden example B.
fn _private_note() {}
