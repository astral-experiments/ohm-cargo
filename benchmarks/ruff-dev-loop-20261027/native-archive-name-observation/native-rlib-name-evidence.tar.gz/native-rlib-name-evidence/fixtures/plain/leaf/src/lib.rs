#[inline(never)] pub fn value(x:u32)->u32 { hidden(x) }
/// Hidden example B.
#[inline(never)] fn hidden(x:u32)->u32 { x + 12 }
