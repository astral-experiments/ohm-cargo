"""Observe the archive member name in a real ordinary Cargo link with a fixed native flag."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys,struct
D=Path(os.environ['OHM_WITNESS_RESULTS']);P=Path(os.environ['OHM_WITNESS_ROOT']);P.mkdir(exist_ok=False,mode=0o700)
sdk=Path(os.environ['OHM_WITNESS_SDK']);cargo=Path(os.environ['OHM_WITNESS_CARGO']);driver=Path(os.environ['OHM_WITNESS_DRIVER']);rustup=Path(os.environ['OHM_WITNESS_RUSTUP']);hw=sdk/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
ids={k:sha(v)for k,v in {'frontend':sdk/'bin/rustc','driver':driver,'cargo':cargo,'wild':hw}.items()};assert ids['driver']=='dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f' and ids['cargo'].startswith('dd5cab15');W=P/'src';W.mkdir();S=P/'state';S.mkdir();(S/'home').mkdir()
(W/'Cargo.toml').write_text('[workspace]\nmembers=["leaf","app"]\nresolver="2"\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\n')
for n in ('leaf','app'):
 (W/n/'src').mkdir(parents=True);(W/n/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n'+('[dependencies]\nleaf={path="../leaf"}\n'if n=='app'else''))
leaf=W/'leaf/src/lib.rs';leaf.write_text('#[inline(never)] pub fn value(x:u32)->u32 { hidden(x) }\n/// Hidden example A.\n#[inline(never)] fn hidden(x:u32)->u32 { x + 11 }\n')
app=W/'app/src/main.rs';app.write_text('fn main() { println!("{}",leaf::value(std::hint::black_box(30))); }\n')
build=W/'app/build.rs';build.write_text('fn main() { println!("cargo::rerun-if-changed=build.rs"); println!("cargo::rustc-link-arg-bin=app=-Wl,--write-layout"); }\n')
n=['taskset','-c',os.environ['OHM_WITNESS_CPUS'],'bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(P),str(P),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--ro-bind',str(driver),str(sdk/'lib'/driver.name),'--chdir',str(W),'--']
env=dict(os.environ,RUSTUP_HOME=str(rustup),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(S/'home'),CARGO_TARGET_DIR=str(S/'target'),CARGO_BUILD_BUILD_DIR=str(S/'build'),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='1',LC_ALL='C.UTF-8',LD_LIBRARY_PATH=str(sdk/'lib'))
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):env.pop(k,None)
def cgus(p):
 with p.open('rb')as f:
  assert f.read(8)==b'!<arch>\n';names=b'';m={};slot={};sym=0;old={}
  while h:=f.read(60):
   off=f.tell()-60;l=int(h[48:58]);nm=h[:16].strip();val=f.read(l)
   if l&1:f.read(1)
   if nm==b'/':index=val;continue
   if nm==b'//':names=val;continue
   if nm.startswith(b'/'):i=int(nm[1:]);nm=names[i:names.index(b'/\n',i)]
   nm=nm.rstrip(b'/').decode();slot[off]=len(m);m[nm]=hashlib.sha256(val).hexdigest()
  sym=int.from_bytes(index[:4],'big');o=struct.unpack_from('>'+str(sym)+'I',index,4);symbols=index[4+4*sym:].split(b'\0')[:sym];pairs=[(slot[k],v.decode())for k,v in zip(o,symbols)]
  return m,hashlib.sha256(json.dumps(pairs,separators=(',',':')).encode()).hexdigest()

(W/'Cargo.toml').write_text((W/'Cargo.toml').read_text()+'panic="abort"\n')
leaf.write_text('''#![no_std]
#[used]
#[unsafe(no_mangle)]
#[unsafe(link_section = ".audit_marker")]
pub static AUDIT_BYTES: [u8; 42] = [41; 42];
/// Hidden example A.
fn _private_note() {}
''')
app.write_text('''#![no_std]
#![no_main]
use core::arch::global_asm;
global_asm!(r#"
.global _start
.type _start,@function
_start:
  movzbl {value}(%rip), %edi
  leaq picked_end(%rip), %rax
  leaq picked_start(%rip), %rdx
  subq %rdx, %rax
  addl %eax, %edi
  movl $60, %eax
  syscall
  ud2
"#,value=sym leaf::AUDIT_BYTES,options(att_syntax));
#[panic_handler] fn panic(_: &core::panic::PanicInfo)->! { loop {} }
''')
build.write_text('''fn main() {
 let path = std::path::PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).join("layout.ld");
 println!("cargo::rerun-if-changed=build.rs");
 println!("cargo::rerun-if-changed=layout.ld");
 for flag in ["-nostartfiles", "-static", "-no-pie"] { println!("cargo::rustc-link-arg={flag}"); }
 println!("cargo::rustc-link-arg=-Wl,-T,{}",path.display());
}
''')
script=W/'app/layout.ld';script.write_text('ENTRY(_start)')
def cargo_run(phase,pkg,store='state'):
 rec=S/phase;rec.mkdir();target=P/store/'target';shared=P/store/'build';e=dict(env,CARGO_TARGET_DIR=str(target),CARGO_BUILD_BUILD_DIR=str(shared));q=[os.environ['OHM_WITNESS_RUSTUP_CARGO'],'+ohm','build','--offline','--message-format=json','-p',pkg];cmd=['strace','-f','-qq','-s','100000','-e','trace=execve','-o',str(rec/'exec'),*q];proc=sp.run(n+cmd,env=e,capture_output=True,timeout=60);(rec/'stdout').write_bytes(proc.stdout);(rec/'stderr').write_bytes(proc.stderr);assert proc.returncode==0,proc.stderr.decode(errors='replace')[-2200:];msgs=[json.loads(z)for z in proc.stdout.splitlines()];a={x['target']['name']:x for x in msgs if x.get('reason')=='compiler-artifact'};rlib=next(Path(x)for x in a['leaf']['filenames']if x.endswith('.rlib'));m,idx=cgus(rlib);shutil.copy(rlib,rec/'leaf.rlib');proj={k:v for k,v in m.items()if k.endswith('.rcgu.o')};l=[x for x in (rec/'exec').read_text().splitlines()if ' = 0' in x];picked=[v for v in l if '"link-only"' in v or '"-Zlink-only' in v];r={'sources':{f.name:sha(f)for f in [leaf,app,build,script]},'leaf_public_api':next(target.rglob('lib-leaf.public-api-hash')).read_text().strip(),'archive':sha(rlib),'raw_rmeta':sha(next(target.rglob('libleaf-*.rmeta'))),'ordered_member_objects':proj,'gnu_symbol_to_member_ordinal':idx,'cargo_fresh':{k:v['fresh']for k,v in a.items()},'calls':{'leaf':sum('"--crate-name", "leaf"'in x for x in l),'app_full':sum('"--crate-name", "app"'in x and x not in picked for x in l),'link_only':len(picked),'wild':sum('wild-ld/ld' in x.split('", [')[0]for x in l)}}
 if 'app' in a:
  elf=Path(a['app']['executable']);r['elf_sha256']=sha(elf);sub=sp.run([elf],capture_output=True,timeout=5);r['exit']=sub.returncode;assert sub.returncode>=0;nm=sp.check_output(['nm','-n',elf],text=True);r['marker_bounds']={l.split()[-1]:l.split()[0]for l in nm.splitlines() if l.endswith(' picked_start')or l.endswith(' picked_end')};r['marker_width']=int(r['marker_bounds']['picked_end'],16)-int(r['marker_bounds']['picked_start'],16)
 return r
prim=cargo_run('producer','leaf');rlib=S/'producer/leaf.rlib';ofile=next(k for k in prim['ordered_member_objects'] if b'.audit_marker' in sp.check_output(['ar','p',rlib,k]));script.write_text('''ENTRY(_start)
SECTIONS {
 . = 0x600000;
 .text : { *(.text*) }
 .selected : { picked_start = .; KEEP('''+ofile+'''(.audit_marker)) picked_end = .; }
 .rest : { KEEP(*(.audit_marker)) *(.rodata*) }
 . = ALIGN(4096);
 .data : { *(.data*) }
 .bss : { *(.bss*) }
}
''');initial=cargo_run('original','app');noop=cargo_run('original-repeat','app');leaf.write_text(leaf.read_text().replace('example A.','example B.'));edited=cargo_run('edited','app');rep=cargo_run('edited-repeat','app');clean=cargo_run('clean-physical-reference','app','fresh');report={'subjects':ids,'same_fixed_wild_selector':script.read_text(),'selected_original_member':ofile,'producer':prim,'original':initial,'original_noop':noop,'edited':edited,'edited_noop':rep,'clean_edited':clean,'complete':True};(D/'selector.json').write_text(json.dumps(report,indent=2)+'\n');print([(n,x.get('exit'),x.get('marker_width'),x['calls'])for n,x in report.items() if isinstance(x,dict)and 'calls'in x],flush=True);print('public, object bytes, GNU symbol mapping equal',initial['leaf_public_api']==edited['leaf_public_api'],list(initial['ordered_member_objects'].values())==list(edited['ordered_member_objects'].values()),initial['gnu_symbol_to_member_ordinal']==edited['gnu_symbol_to_member_ordinal']);print('matched original, absent edited',ofile in initial['ordered_member_objects'],ofile not in edited['ordered_member_objects'])
