from pathlib import Path
import json,hashlib
d=Path(__file__).resolve().parent
def read(p):return json.loads((d/p).read_text())
def h(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
for k,v in read('SHA256.json').items():assert h(d/k)==v,k
r=read('selector.json');a=r['original'];b=r['edited'];c=r['clean_edited']
assert a['exit']==83 and b['exit']==c['exit']==41 and a['marker_width']==42 and b['marker_width']==c['marker_width']==0
assert b['calls']==dict(leaf=1,app_full=0,link_only=1,wild=1)
assert a['sources']['layout.ld']==b['sources']['layout.ld']==c['sources']['layout.ld']
assert a['leaf_public_api']==b['leaf_public_api']==c['leaf_public_api'] and a['gnu_symbol_to_member_ordinal']==b['gnu_symbol_to_member_ordinal']
assert list(a['ordered_member_objects'].values())==list(b['ordered_member_objects'].values()) and set(a['ordered_member_objects']).isdisjoint(b['ordered_member_objects'])
for label,key in [('original','original'),('edited','edited'),('clean-physical-reference','clean_edited')]:assert h(d/'fixtures/same-script'/('leaf-'+label+'.rlib'))==r[key]['archive']
for n in ('name-observation-cli-validated.json','name-observation-env.json'):
 o=read(n);a,b=o['prime'],o['edited'];assert all(o[k]for k in ('old_member_name_absent_after_edit','same_native_object_sequence','same_symbol_to_member_ordinals'))
 assert a['output_elf']==b['output_elf'] and a['layout_sha256']!=b['layout_sha256'] and set(a['selected_upstream_member_names']).isdisjoint(b['selected_upstream_member_names']) and b['native_command_counts']==dict(leaf=1,app_full=0,link_only=1,wild=1)
p=read('plain.json')['phases'];assert p['initial']['elf_sha256']==p['doc']['elf_sha256']!=p['body']['elf_sha256']==p['clean-body']['elf_sha256']
for x in read('previous-ruff-archive-projections.json').values():
 z=x['archive_summary'];assert z['same_slot_payloads']==z['same_slot_cgu_prefixes']==z['object_count']==256 and z['identical_member_names']==0 and z['identical_ordered_symbol_to_member_index']and z['index_entries']==26199 and x['bytes'][0]-x['bytes'][1]==1760
print('21 Cargo commands, four scoped witnesses, unchanged Rust API vs observable linker names and two historical 256-object Ruff projections verified.')
