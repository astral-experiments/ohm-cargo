"""Observe the archive member name in a real ordinary Cargo link with a fixed native flag."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys,struct
D=Path(os.environ['OHM_WITNESS_RESULTS']);P=Path(os.environ['OHM_WITNESS_ROOT']);P.mkdir(exist_ok=False,mode=0o700)
sdk=Path(os.environ['OHM_WITNESS_SDK']);cargo=Path(os.environ['OHM_WITNESS_CARGO']);driver=Path(os.environ['OHM_WITNESS_DRIVER']);rustup=Path(os.environ['OHM_WITNESS_RUSTUP']);hw=sdk/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
ids={k:sha(v)for k,v in {'frontend':sdk/'bin/rustc','driver':driver,'cargo':cargo,'wild':hw}.items()};assert ids['driver']=='dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f' and ids['cargo'].startswith('dd5cab15');W=P/'src';W.mkdir();S=P/'state';S.mkdir();(S/'home').mkdir()
(W/'Cargo.toml').write_text('[workspace]\nmembers=["leaf","app"]\nresolver="2"\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\n')
for n in ('leaf','app'):
 (W/n/'src').mkdir(parents=True);(W/n/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n'+('[dependencies]\nleaf={path="../leaf"}\n'if n=='app'else''))
leaf=W/'leaf/src/lib.rs';leaf.write_text('#[inline(never)] pub fn value(x:u32)->u32 { hidden(x) }\n/// Hidden example A.\n#[inline(never)] fn hidden(x:u32)->u32 { x + 11 }\n')
app=W/'app/src/main.rs';app.write_text('fn main() { println!("{}",leaf::value(std::hint::black_box(30))); }\n')
build=W/'app/build.rs';build.write_text('fn main() { println!("cargo::rerun-if-changed=build.rs"); println!("cargo::rustc-link-arg-bin=app=-Wl,--write-layout"); }\n')
n=['taskset','-c',os.environ['OHM_WITNESS_CPUS'],'bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(P),str(P),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--ro-bind',str(driver),str(sdk/'lib'/driver.name),'--chdir',str(W),'--']
env=dict(os.environ,RUSTUP_HOME=str(rustup),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(S/'home'),CARGO_TARGET_DIR=str(S/'target'),CARGO_BUILD_BUILD_DIR=str(S/'build'),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='1',LC_ALL='C.UTF-8',LD_LIBRARY_PATH=str(sdk/'lib'))
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):env.pop(k,None)
def cgus(p):
 with p.open('rb')as f:
  assert f.read(8)==b'!<arch>\n';names=b'';m={};slot={};sym=0;old={}
  while h:=f.read(60):
   off=f.tell()-60;l=int(h[48:58]);nm=h[:16].strip();val=f.read(l)
   if l&1:f.read(1)
   if nm==b'/':index=val;continue
   if nm==b'//':names=val;continue
   if nm.startswith(b'/'):i=int(nm[1:]);nm=names[i:names.index(b'/\n',i)]
   nm=nm.rstrip(b'/').decode();slot[off]=len(m);m[nm]=hashlib.sha256(val).hexdigest()
  sym=int.from_bytes(index[:4],'big');o=struct.unpack_from('>'+str(sym)+'I',index,4);symbols=index[4+4*sym:].split(b'\0')[:sym];pairs=[(slot[k],v.decode())for k,v in zip(o,symbols)]
  return m,hashlib.sha256(json.dumps(pairs,separators=(',',':')).encode()).hexdigest()
def run(phase):
 N=S/phase;N.mkdir();trace=N/'trace';a=['strace','-f','-qq','-s','100000','-e','trace=execve','-o',str(trace),os.environ['OHM_WITNESS_RUSTUP_CARGO'],'+ohm','build','--offline','--message-format=json','-p','app'];p=sp.run(n+a,env=env,capture_output=True,timeout=60);(N/'err').write_bytes(p.stderr);(N/'out').write_bytes(p.stdout);assert p.returncode==0,p.stderr.decode(errors='replace')[-2000:]; rows=[json.loads(l) for l in p.stdout.splitlines()]; arts={m['target']['name']:m for m in rows if m.get('reason')=='compiler-artifact'};exe=Path(arts['app']['executable']);rlib=next(Path(x)for x in arts['leaf']['filenames']if x.endswith('.rlib'));meta=rlib.with_suffix('.rmeta');files=sorted((S/'target').rglob('*.layout'));assert len(files)==1,files;layout=files[0];members,index=cgus(rlib);data=layout.read_bytes();obj={x:y for x,y in members.items()if x.endswith('.rcgu.o')};selected=[x for x in obj if x.encode()in data];rlab=trace.read_text();commands=[l for l in rlab.splitlines()if ' = 0' in l];r={'phase':phase,'leaf_source':sha(leaf),'app_source':sha(app),'build_script':sha(build),'cargo_status':p.returncode,'cargo_fresh':{k:v['fresh']for k,v in arts.items()},'native_command_counts':{'leaf':sum('"--crate-name", "leaf"' in l for l in commands),'app_full':sum('"--crate-name", "app"' in l and not any(y in l for y in ('"-Zlink-only','"link-only"'))for l in commands),'link_only':sum(any(y in l for y in ('"-Zlink-only','"link-only"'))for l in commands),'wild':sum('wild-ld/ld' in l.split('", [')[0]for l in commands)},'program':sp.check_output([exe],text=True).strip(),'output_elf':sha(exe),'archive':sha(rlib),'rmeta':sha(meta),'all_members':members,'ordered_symbol_to_ordinal':index,'layout_sha256':sha(layout),'layout_bytes':len(data),'selected_upstream_member_names':selected,'rust_api':None}
 for f in (S/'target').rglob('lib-leaf.public-api-hash'):
  r['rust_api']=f.read_text().strip()
 assert r['program']=='41';(N/'result.json').write_text(json.dumps(r,indent=2));shutil.copyfile(layout,N/'layout');return r,layout
r,l=run('prime');assert r['selected_upstream_member_names'],r;noop,_=run('noop');assert not noop['native_command_counts']['wild'];old=r['selected_upstream_member_names'];leaf.write_text(leaf.read_text().replace('example A.','example B.'));u,l=run('edited');assert u['app_source']==r['app_source'] and u['build_script']==r['build_script'];rrestore,l=run('repeat');assert not rrestore['native_command_counts']['wild'];Srows=[r,noop,u,rrestore];summary={'toolchains':ids,'prime':r,'unchanged':noop,'edited':u,'repeat':rrestore,'old_member_name_absent_after_edit':all(x.encode()not in l.read_bytes()for x in old),'same_native_object_sequence':[v for k,v in r['all_members'].items()if k.endswith('.rcgu.o')]==[v for k,v in u['all_members'].items()if k.endswith('.rcgu.o')],'same_symbol_to_member_ordinals':r['ordered_symbol_to_ordinal']==u['ordered_symbol_to_ordinal']};(D/'name-observation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:{'physical':x['native_command_counts'],'leaf_hash':x['rust_api'],'selected':x['selected_upstream_member_names'],'elf':x['output_elf'],'layout':x['layout_sha256']}for k,x in zip(['prime','noop','edit','repeat'],Srows)},indent=2));print('same native objects, same GNU index, old name absent:',summary['same_native_object_sequence'],summary['same_symbol_to_member_ordinals'],summary['old_member_name_absent_after_edit'])
