"""Run every bounded Cargo witness under a fresh physical target, registry and state."""
import argparse,os,subprocess,shutil,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for k in ('workdir','sysroot','cargo','driver'):p.add_argument('--'+k,required=True,type=Path)
p.add_argument('--cpus',default=','.join(map(str,sorted(os.sched_getaffinity(0))[:2])));a=p.parse_args();D=Path(__file__).resolve().parent;w=a.workdir.resolve();w.mkdir(mode=0o700);(w/'results').mkdir();(w/'rustup/toolchains').mkdir(parents=True);(w/'rustup/toolchains/ohm').symlink_to(a.sysroot.resolve())
for n in ('plain','same-script','cli-flag','env-flag'):
 env=dict(os.environ,OHM_WITNESS_ROOT=str(w/n),OHM_WITNESS_RESULTS=str(w/'results'),OHM_WITNESS_SDK=str(a.sysroot.resolve()),OHM_WITNESS_CARGO=str(a.cargo.resolve()),OHM_WITNESS_DRIVER=str(a.driver.resolve()),OHM_WITNESS_RUSTUP=str(w/'rustup'),OHM_WITNESS_CPUS=a.cpus,OHM_WITNESS_RUSTUP_CARGO=shutil.which('cargo')or'cargo')
 subprocess.run([sys.executable,'-B',D/(n+'.py')],env=env,check=True)
print('Raw rerun JSON under',w/'results')
