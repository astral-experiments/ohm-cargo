"""Observe the archive member name in a real ordinary Cargo link with a fixed native flag."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys,struct
D=Path(os.environ['OHM_WITNESS_RESULTS']);P=Path(os.environ['OHM_WITNESS_ROOT']);P.mkdir(exist_ok=False,mode=0o700)
sdk=Path(os.environ['OHM_WITNESS_SDK']);cargo=Path(os.environ['OHM_WITNESS_CARGO']);driver=Path(os.environ['OHM_WITNESS_DRIVER']);rustup=Path(os.environ['OHM_WITNESS_RUSTUP']);hw=sdk/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
ids={k:sha(v)for k,v in {'frontend':sdk/'bin/rustc','driver':driver,'cargo':cargo,'wild':hw}.items()};assert ids['driver']=='dec72d1e68fdb0f8ff91fc98e8a826bf837878eca30b1ec5ea2f3258b6b2f99f' and ids['cargo'].startswith('dd5cab15');W=P/'src';W.mkdir();S=P/'state';S.mkdir();(S/'home').mkdir()
(W/'Cargo.toml').write_text('[workspace]\nmembers=["leaf","app"]\nresolver="2"\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\n')
for n in ('leaf','app'):
 (W/n/'src').mkdir(parents=True);(W/n/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n'+('[dependencies]\nleaf={path="../leaf"}\n'if n=='app'else''))
leaf=W/'leaf/src/lib.rs';leaf.write_text('#[inline(never)] pub fn value(x:u32)->u32 { hidden(x) }\n/// Hidden example A.\n#[inline(never)] fn hidden(x:u32)->u32 { x + 11 }\n')
app=W/'app/src/main.rs';app.write_text('fn main() { println!("{}",leaf::value(std::hint::black_box(30))); }\n')
build=W/'app/frozen-irrelevant-file';build.write_text('fn main() { println!("cargo::rerun-if-changed=build.rs"); println!("cargo::rustc-link-arg-bin=app=-Wl,--write-layout"); }\n')
n=['taskset','-c',os.environ['OHM_WITNESS_CPUS'],'bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(P),str(P),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--ro-bind',str(driver),str(sdk/'lib'/driver.name),'--chdir',str(W),'--']
env=dict(os.environ,RUSTUP_HOME=str(rustup),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(S/'home'),CARGO_TARGET_DIR=str(S/'target'),CARGO_BUILD_BUILD_DIR=str(S/'build'),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',CARGO_INCREMENTAL='1',LC_ALL='C.UTF-8',LD_LIBRARY_PATH=str(sdk/'lib'))
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):env.pop(k,None)
def cgus(p):
 with p.open('rb')as f:
  assert f.read(8)==b'!<arch>\n';names=b'';m={};slot={};sym=0;old={}
  while h:=f.read(60):
   off=f.tell()-60;l=int(h[48:58]);nm=h[:16].strip();val=f.read(l)
   if l&1:f.read(1)
   if nm==b'/':index=val;continue
   if nm==b'//':names=val;continue
   if nm.startswith(b'/'):i=int(nm[1:]);nm=names[i:names.index(b'/\n',i)]
   nm=nm.rstrip(b'/').decode();slot[off]=len(m);m[nm]=hashlib.sha256(val).hexdigest()
  sym=int.from_bytes(index[:4],'big');o=struct.unpack_from('>'+str(sym)+'I',index,4);symbols=index[4+4*sym:].split(b'\0')[:sym];pairs=[(slot[k],v.decode())for k,v in zip(o,symbols)]
  return m,hashlib.sha256(json.dumps(pairs,separators=(',',':')).encode()).hexdigest()

script=W/'app/fixed-config';script.write_text('default packaged native flags')
def cargo_run(phase,pkg,store='state'):
 rec=S/phase;rec.mkdir();target=P/store/'target';shared=P/store/'build';e=dict(env,CARGO_TARGET_DIR=str(target),CARGO_BUILD_BUILD_DIR=str(shared));q=[os.environ['OHM_WITNESS_RUSTUP_CARGO'],'+ohm','build','--offline','--message-format=json','-p',pkg];cmd=['strace','-f','-qq','-s','100000','-e','trace=execve','-o',str(rec/'exec'),*q];proc=sp.run(n+cmd,env=e,capture_output=True,timeout=60);(rec/'stdout').write_bytes(proc.stdout);(rec/'stderr').write_bytes(proc.stderr);assert proc.returncode==0,proc.stderr.decode(errors='replace')[-2200:];msgs=[json.loads(z)for z in proc.stdout.splitlines()];a={x['target']['name']:x for x in msgs if x.get('reason')=='compiler-artifact'};rlib=next(Path(x)for x in a['leaf']['filenames']if x.endswith('.rlib'));m,idx=cgus(rlib);shutil.copy(rlib,rec/'leaf.rlib');proj={k:v for k,v in m.items()if k.endswith('.rcgu.o')};l=[x for x in (rec/'exec').read_text().splitlines()if ' = 0' in x];picked=[v for v in l if '"link-only"' in v or '"-Zlink-only' in v];r={'sources':{f.name:sha(f)for f in [leaf,app,build,script]},'leaf_public_api':next(target.rglob('lib-leaf.public-api-hash')).read_text().strip(),'archive':sha(rlib),'raw_rmeta':sha(next(target.rglob('libleaf-*.rmeta'))),'ordered_member_objects':proj,'gnu_symbol_to_member_ordinal':idx,'cargo_fresh':{k:v['fresh']for k,v in a.items()},'calls':{'leaf':sum('"--crate-name", "leaf"'in x for x in l),'app_full':sum('"--crate-name", "app"'in x and x not in picked for x in l),'link_only':len(picked),'wild':sum('wild-ld/ld' in x.split('", [')[0]for x in l)}}
 if 'app' in a:
  elf=Path(a['app']['executable']);r['elf_sha256']=sha(elf);p=sp.run([elf],capture_output=True,timeout=5);assert p.returncode==0;r['printed']=p.stdout.decode().strip()
 return r

a=cargo_run('original','app');b=cargo_run('original-noop','app');leaf.write_text(leaf.read_text().replace('example A.','example B.'));c=cargo_run('same-native','app');d=cargo_run('same-native-repeat','app');leaf.write_text(leaf.read_text().replace('x + 11','x + 12'));e=cargo_run('new-native','app');f=cargo_run('new-native-quiet','app');g=cargo_run('new-native-cold','app','fresh')
report={'subjects':ids,'phases':{'initial':a,'initial-repeat':b,'doc':c,'doc-repeat':d,'body':e,'body-repeat':f,'clean-body':g}};(D/'plain.json').write_text(json.dumps(report,indent=2)+'\n')
for n,q in report['phases'].items():print(n,q['printed'],q['calls'],q['elf_sha256'])
assert all(a['leaf_public_api']==x['leaf_public_api']for x in (b,c,d,e,f,g)) and list(a['ordered_member_objects'].values())==list(c['ordered_member_objects'].values())!=list(e['ordered_member_objects'].values())
assert a['elf_sha256']==c['elf_sha256'] and a['printed']==c['printed']=='41'and e['printed']==f['printed']==g['printed']=='42'
