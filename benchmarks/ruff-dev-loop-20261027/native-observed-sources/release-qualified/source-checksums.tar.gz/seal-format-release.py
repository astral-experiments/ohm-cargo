"""Seal the exact source/black-box outputs and verify them again after packaging."""
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import tarfile

q = Path(__file__).resolve().parent
out = q / 'release-obs4fmt'
cfg = json.loads((out/'release-inputs.json').read_bytes())
cutover = json.loads((out/'cutover/result.json').read_bytes())
assert len(cutover)==7 and all(r['compiler_sha256']==cfg['new_driver'] for r in cutover[2:6])
assert len({r['root_hashes'] for r in cutover})==1
assert [r['source_md5']==r['metadata_md5'] for r in cutover] == [True,False,True,True,True,True,True]
crlf = json.loads((out/'crlf/receipts.json').read_bytes())
assert len(crlf)==8
for row in crlf.values():
    assert row['compiler']==cfg['new_driver'] and row['cargo_sha256']==cfg['cargo']
    assert list(map(int,row['runtime_result']))==([1,2,1] if row['source_changed'] else [1,1,1])
    if 'fresh' in row['stage']:
        assert not row['dirty']
for warm,clean in [('warm-edit','clean-edit'),('warm-restore','clean-restored')]:
    a,b=(crlf['candidate/'+r] for r in (warm,clean))
    assert a['consumer_elf']==b['consumer_elf'] and a['diagnostics']==b['diagnostics']
archives={}
for warm,clean in [('warm-edit','clean-edit'),('warm-restore','clean-restored')]:
    a,b=(out/'crlf'/('source-file-'+r+'.rlib') for r in (warm,clean))
    inputs=[p.read_bytes() for p in (a,b)]
    names=[subprocess.check_output(['ar','t',p],text=True).splitlines() for p in (a,b)]
    assert len(names[0])==len(names[1])
    normalized=inputs[0]
    pairs=[]
    for s,t in zip(*names):
        if s!=t and s.endswith('.rcgu.o') and t.endswith('.rcgu.o'):
            pairs.append([s,t,normalized.count(s.encode())])
            normalized=normalized.replace(s.encode(),t.encode())
    archives[warm]={'warm_bytes':len(inputs[0]),'clean_bytes':len(inputs[1]),
                    'warm_sha256':hashlib.sha256(inputs[0]).hexdigest(),
                    'clean_sha256':hashlib.sha256(inputs[1]).hexdigest(),
                    'archive_equal_after_cgu_member_name_replacement':normalized==inputs[1],
                    'changed_cgu_member_names':pairs}
(out/'crlf/rlib-member-names.json').write_text(json.dumps(archives,indent=2)+'\n')
parsers = {d:json.loads((out/'parser'/d/'result.json').read_bytes())
           for d in ('original','fresh','modified','checksum-restore','checksum-fresh')}
assert all(p['units']==90 and p['driver']==cfg['new_driver'] for p in parsers.values())
assert not parsers['fresh']['dirty'] and not parsers['checksum-fresh']['dirty']
assert parsers['modified']['dirty']==parsers['checksum-restore']['dirty']==['ruff_python_parser']
assert len({p['hashes'][0][1]['value'] for p in parsers.values()})==1
physical=json.loads((out/'parser-source-checksums.json').read_bytes())
assert physical['warm-restore']==physical['fresh-restored']
assert physical['warm-edit']['source_md5']!=physical['warm-restore']['source_md5']
graphroot=Path('/dev/shm/ohm-private-derive-ruff-parser-release-obs4fmt-20261027')
actual_graph,=[p for p in graphroot.rglob('dep-graph.bin') if any(x.startswith('ruff_python_parser-') for x in p.parts)]
audit=runpy.run_path(q/'source-graph-count.py')['inspect'](actual_graph,q/'obs4fmt-inputs/compiler/rustc_middle/src/queries.rs')
assert audit['checksum_edges']==physical['warm-restore']['encoded_files']
(out/'ruff-parser-source-graph.json').write_text(json.dumps(audit,indent=2)+'\n')
summary={'scope':'Untimed exact final optimized toolchain black-box smoke, independent private target/build directories',
         'inputs':cfg,'cutover_steps':len(cutover),'cutover_public_private':cutover[0]['root_hashes'],
         'ruff_parser':{d:{'units':v['units'],'dirty_units':len(v['dirty']),'public':v['hashes'][0][1]['value']} for d,v in parsers.items()},
         'ruff_parser_physical':physical, 'incremental_graph':audit,
         'ruff_crlf':{r['stage']:{k:r[k] for k in ('units','dirty','consumer_elf','runtime_result','producer_public','diagnostics')} for r in crlf.values()}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
members=[out/f for f in ('release-inputs.json','summary.json','cutover.py','cutover/result.json','parser.py','parser-physical.py','parser-source-checksums.json','ruff-parser-source-graph.json','crlf/replay.py','crlf/receipts.json','crlf/rlib-member-names.json')]
members += sorted((out/'cutover').glob('*.rmeta'))+sorted((out/'parser').glob('*/result.json'))
members += [q/p for p in ('replay-source-checksum.py','source-graph-count.py','producer-source-checksum-plan.md','obs4fmt-inputs/input-hashes.json','obs4fmt-inputs/single-format.patch','obs4fmt-inputs/format-provenance.json','physical-upgrade-obs4fmt-early/result.json','format-release-smoke.py','seal-format-release.py')]
sums={str(p.relative_to(q)):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in members}
(out/'SHA256SUMS.json').write_text(json.dumps(sums,indent=2)+'\n')
archive=out/'release-source-checksums.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
    for p in [*members,out/'SHA256SUMS.json']:
        t.add(p,arcname=str(p.relative_to(q)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for name,digest in sums.items():
        assert hashlib.file_digest(t.extractfile(name),'sha256').hexdigest()==digest
print(archive,len(sums)+1,archive.stat().st_size,hashlib.file_digest(archive.open('rb'),'sha256').hexdigest())
