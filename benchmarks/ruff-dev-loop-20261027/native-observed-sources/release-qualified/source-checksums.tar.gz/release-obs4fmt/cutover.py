"""Compare metadata provenance while two matching compilers share one real incremental directory."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys


here = Path(__file__).resolve().parents[1]
arm = 'pgo'
out = here / 'release-obs4fmt' / 'cutover'
out.mkdir(exist_ok=True)
driver = 'librustc_driver-774a793a844d5500.so'
score = Path('/home/dev-user/.cache/ohm-ruff-packed-edges-20261026/nonleaf/trait-pgo-state')
rust = score / 'sysroot'
old = here.parent / 'stage2-wire-posobs3' / driver
new = here.parent / 'stage2-wire-posobs4fmt' / driver
orig = b'#[macro_export] macro_rules! deliver { ($cb:ident) => { $cb!(foreign_marker) } }\n// Unrelated note.\n'
edit = orig.replace(b'note.', b'edit.')
assert len(orig) == len(edit)
Reader = runpy.run_path('/home/dev-user/.cache/ohm-ruff-cargo-link-skip-20261027/link-export-inventory.py')['Reader']
steps = [
    ('old-prime', old, 1, orig, orig),
    ('old-warm-edit', old, 1, edit, orig),
    ('new-cutover', new, 2, edit, edit),
    ('new-repeat', new, 2, edit, edit),
    ('new-warm-restore', new, 2, orig, orig),
    ('new-warm-reedit', new, 2, edit, edit),
    ('old-return', old, 1, edit, edit),
]
evidence = out / 'result.json'
rows = json.loads(evidence.read_bytes()) if evidence.exists() else []
stop_after = sys.argv[2] if len(sys.argv) > 2 else steps[-1][0]
for i, (label, compiler, epoch, source, expected_stored) in enumerate(steps):
    if i < len(rows):
        if label == stop_after:
            break
        continue
    (out / 'subject.rs').write_bytes(source)
    cmd = ['taskset', '-c', '20-23', 'bwrap', '--ro-bind', '/', '/', '--dev', '/dev', '--proc', '/proc',
           '--tmpfs', '/tmp', '--bind', out, out, '--ro-bind', compiler, rust / 'lib' / driver,
           '--chdir', out, '--', Path.home() / '.cargo/bin/rustc', '+ohm',
           '--crate-type=rlib', '--crate-name=subject', '--edition=2024', '--emit=metadata=libsubject.rmeta',
           '-C', 'incremental=incremental', 'subject.rs']
    proc = subprocess.run(list(map(str, cmd)), env=dict(os.environ, RUSTUP_HOME=str(score/'rustup'),
                         RUSTUP_TOOLCHAIN='ohm', RUSTUP_AUTO_INSTALL='0'), capture_output=True)
    (out / (label + '.stderr')).write_bytes(proc.stderr)
    assert proc.returncode == 0, (label, proc.stderr)
    m = (out / 'libsubject.rmeta').read_bytes()
    (out / (label + '.rmeta')).write_bytes(m)
    a, b = hashlib.md5(orig).digest(), hashlib.md5(edit).digest()
    actual_md5 = [v for v in (a, b) if v in m]
    assert actual_md5 == [hashlib.md5(expected_stored).digest()], (label, actual_md5)
    r = Reader(m)
    assert r.u() == 0
    r.text()
    hashes = r.raw(32).hex()
    entries = [s for s in (out/'incremental').glob('*/*') if s.is_dir() and not s.name.endswith('working')]
    current = max(entries, key=lambda e: e.stat().st_mtime_ns)
    headers = {p.name:p.read_bytes()[:6].hex() for p in current.glob('*.bin')}
    assert {'dep-graph.bin','query-cache.bin','work-products.bin'} <= headers.keys()
    assert set(headers.values()) == {('RSIC'.encode() + epoch.to_bytes(2, 'little')).hex()}, headers
    rows.append(dict(label=label, compiler=str(compiler), args=list(map(str,cmd)),
                     compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),
                     source_md5=hashlib.md5(source).hexdigest(), metadata_md5=actual_md5[0].hex(),
                     metadata_sha256=hashlib.sha256(m).hexdigest(), root_hashes=hashes, incr_headers=headers))
    evidence.write_text(json.dumps(rows, indent=2)+'\n')
    print(label, 'epoch', epoch, 'checksum matches disk', source == expected_stored, hashes, flush=True)
    if label == stop_after:
        break
if len(rows) == len(steps):
    assert len({r['root_hashes'] for r in rows}) == 1
    assert rows[0]['metadata_sha256'] == rows[1]['metadata_sha256']
    assert rows[2]['metadata_sha256'] == rows[3]['metadata_sha256'] == rows[5]['metadata_sha256'] == rows[6]['metadata_sha256']
    assert rows[4]['metadata_sha256'] == rows[0]['metadata_sha256']
