"""Repeat the proven 4b release commands in independent stores for the exact rustfmt revision."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
tag, expected = sys.argv[1:]
old = here / 'release-obs4b'
out = here / 'release-obs4fmt'
assert not out.exists()
out.mkdir()
lib = 'librustc_driver-774a793a844d5500.so'
compiler = here.parent / ('stage2-wire-' + tag) / lib
with compiler.open('rb') as f:
    assert hashlib.file_digest(f, 'sha256').hexdigest() == expected
inputs = json.loads((old / 'release-inputs.json').read_bytes())
inputs.update(new_driver=expected, rust_commit='27029b4bce40f3b5497add5019c02a11c16c4c18',
              source_manifest_sha256=hashlib.sha256((here / 'obs4fmt-inputs/input-hashes.json').read_bytes()).hexdigest())
work = Path('/home/dev-user/code/oss/ohm-rust-private-native-20261027')
inputs['rust_compiler_tree'] = subprocess.check_output(['git','-C',work,'rev-parse',inputs['rust_commit']+':compiler'],text=True).strip()
for path,digest in json.loads((here/'obs4fmt-inputs/input-hashes.json').read_bytes()).items():
    raw = subprocess.check_output(['git', '-C', work, 'show', inputs['rust_commit']+':'+path])
    assert hashlib.sha256(raw).hexdigest() == digest, path
(out / 'release-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
for name in ['cutover.py','parser.py','parser-physical.py','crlf/replay.py']:
    dest=out/name
    dest.parent.mkdir(exist_ok=True, parents=True)
    script=(old/name).read_text().replace('release-obs4b','release-obs4fmt').replace('stage2-wire-posobs4b','stage2-wire-'+tag)
    if name == 'crlf/replay.py':
        needle=";actions=[]\n"
        assert script.count(needle)==1
        script=script.replace(needle, needle+"""        if stage in ('warm-edit','warm-restore','clean-edit','clean-restored'):
            rlib,=[Path(x) for x in src_art['filenames'] if x.endswith('.rlib')]
            shutil.copy2(store/rlib.relative_to(active), base/('source-file-'+stage+'.rlib'))
""")
    dest.write_text(script)
for name in ['cutover.py','parser.py','parser-physical.py','crlf/replay.py']:
    with (out / (name.replace('/', '-') + '.log')).open('wb') as log:
        subprocess.run([sys.executable,'-B',out/name],stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name, 'passed', flush=True)
