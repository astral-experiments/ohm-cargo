extern crate proc_macro;
use proc_macro::TokenStream;
#[proc_macro] pub fn read_span(input: TokenStream) -> TokenStream {
    let span = input.into_iter().next().unwrap().span();
    format!("{:?}",format!("{span:?}")).parse().unwrap()
}
#[proc_macro] pub fn swallow(_: TokenStream) -> TokenStream { "0u8".parse().unwrap() }
