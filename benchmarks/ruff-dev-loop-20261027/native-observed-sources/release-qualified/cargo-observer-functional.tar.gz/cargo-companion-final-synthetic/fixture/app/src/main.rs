use probe::{swallow, read_span};
const _: u8=leaf::prime_file!(swallow);
fn main(){println!("{} {}",leaf::value(),leaf::deliver!(read_span));}
