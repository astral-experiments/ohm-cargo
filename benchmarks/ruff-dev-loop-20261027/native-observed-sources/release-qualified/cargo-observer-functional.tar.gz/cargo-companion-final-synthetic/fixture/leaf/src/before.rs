pub struct Public;
pub fn value() -> u32 { 7 }
#[macro_export] macro_rules! prime_file { ($callback:ident) => { $callback!(first_marker) }; }
/// private change
fn hidden() {}
#[derive(Debug, Copy, Clone, PartialEq, Eq)] pub(super) enum AttrsAutoAttribs { True, False, Inferred }
#[derive(Debug, Copy, Clone, PartialEq, Eq)] pub(super) enum DataclassKind { Standard, Attrs(AttrsAutoAttribs) }
