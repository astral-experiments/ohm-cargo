# Ruff no-op builds with observed foreign spans

This companion to `cargo_companion_support` in `plan.json` keeps the corrected compiler fixed and compares two matched release-built Cargos. It times the complete process from the rustup Cargo proxy through successful exit. It uses the registered twelve balanced pairs for each of `cargo +ohm build` and `cargo +ohm test --no-run`. Both commands include `--locked --offline`. No test binary runs.

## Run on H2

Use the prepared `charlie-ohm-relink-b-1024` checkout and its frozen toolchain. Start this after the main integrated study. The runner holds the same `/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/native-measure.lock` for initialization, all observations and the functional controls. The selected files are mounted onto the published toolchain paths inside a private namespace. The runner aborts if a subject changes, Ruff differs from the clean pin, or the home filesystem has less than 25 GiB free before a command. The destination must be new. Preserve a failed attempt under its original path.

```sh
sha256sum -c SHA256SUMS
/usr/bin/python3 -B run.py \
  --parent-cargo "$HOME/.cache/ohm-mixed-cargo-release-20261027/cargo-final" \
  --candidate-cargo "$HOME/.cache/ohm-mixed-cargo-release-20261027/cargo-observer3" \
  --compiler-commit "$COMPILER_COMMIT" --driver-sha "$DRIVER_SHA" \
  --driver "$HOME/.cache/ohm-233-position-qualified-20261027/drivers/driver-$DRIVER_SHA" \
  --run "$HOME/.cache/ohm-233-position-qualified-20261027/cargo-observer-ruff-final"
```

`COMPILER_COMMIT` and `DRIVER_SHA` must be the full digest pair from the reviewed release PGO+BOLT build. The runner records both before creating the benchmark state. It fixes the parent Cargo SHA to `fd9bfe1178f30d12d412f4736eea9e0a7d68e8f687ab2653681d0181049f3025` and the candidate Cargo SHA to `a99a694c680f474bef2ae17de20533890dc536606021db93aaf531e3ef40919a`. The frozen plan and package source patch identify the matching source configuration. Run from a shell without compiler, linker, profile or wrapper overrides.

## Workload and integrity gates

Each endpoint and arm begins with a distinct empty target and shared-build directory. Each gets a private copy of the offline registry and Git source inputs. Cache databases, locks and built outputs belong to that arm. Both arms see identical absolute source, target, shared-build, Cargo home and toolchain paths. The CPU affinity is 0–23 and Cargo uses eight jobs. Four independent native stores are retained, plus two small observer captures. Two large cold test builds need disk headroom beyond the reserve.

A cold command and two identical unchanged-source commands precede each cohort. Each retains Cargo JSON and a per-process `strace` trace. The last setup command and a final separate replay must prove that all 501 build units or 619 test-build units are fresh under candidate Cargo, with zero compiled crates, final linkers or target processes. The control can rebuild. It must reproduce its initial dirty-unit, compiler and linker rosters in the final trace. Every measured command is untraced with ordinary Cargo output. The runner writes stdout, stderr, the exact command and elapsed nanoseconds before checking diagnostics. It rejects candidate compile status or any inode, size or mtime/ctime change to a candidate ELF during a timed no-op. Neither this check nor the two CLI probes is inside the timer.

The two CLI cases cover Ruff's mixed Python literal diagnostic and the two dataclass RUF008 diagnostics. The raw Cargo unit, executable, message and ELF rosters compare across arms. There are 6 executable paths and 15 workspace ELF products for build, or 102 and 110 for test compilation. Every workspace ELF receives both a raw digest and a digest masking only the GNU build-ID descriptor and `.rodata` section header's `sh_entsize`. All bytes outside these two documented Wild variations must agree. Differences in either field retain both original digests and concrete field values. A code, data, DWARF, symbol, other header, padding or trailing-byte discrepancy rejects the cohort.

After all scores, a fresh bind-mounted copy of the Ruff helper changes the matcher from `dataclasses.field` to `dataclasses.other`. Each arm's ordinary compile must actually update the Ruff binary and produce one RUF008 diagnostic. Restoring the original file must restore both diagnostics and the native ELF references. The real checkout and index retain their original bytes. An independent three-package fixture changes a private doc comment by one byte. Stable `proc_macro::Span` Debug from a separate source file must change the linked program's byte range, agree with a cold edited build, and return to its original value after restoration. Both arms execute that probe. Its source, cold and warm receipts remain available. This independent program and the Ruff CLI probes run outside the timed commands.

## Analysis and raw records

```sh
/usr/bin/python3 -B analyze.py "$HOME/.cache/ohm-233-position-qualified-20261027/cargo-observer-ruff-final"
/usr/bin/python3 -B selftest.py --trace
```

`subjects.json` binds the source and binary hashes. Each endpoint's `observations.csv` preserves its chronological pair, slot, arm and nanoseconds. `receipt.json`, `invocation.json`, raw `stdout`, `stderr`, `exec.*`, `trace.json` and `elf.json` under each arm retain the evidence. `statistics.json` includes both endpoints, the paired geometric elapsed reduction, marginal medians, dirty and physical process counts and which binaries varied in the two disclosed ELF fields. The exact two-sided test enumerates all 924 assignments of six parent-first pairs. The percentile interval resamples whole log-ratio pairs 20,000 times with seed 831361. Significance requires adjusted Holm p < 0.05 across both registered endpoints and a positive lower 95% bound. Separate scores involving different compilers belong to the primary integrated study.

The local dry run traced an actual rustup Cargo proxy and replayed public Ruff build/test process records; it verified known positive and flat randomization examples and rejected an executable-code perturbation. `observer-smoke-parent.json` and `observer-smoke-candidate.json` are the independent local functional controls using prior matched shipping driver `4e967d262ea9dae4c1e673ec2e1d07a7dc492d8bca2ea42bb90cbcd509da9c7c`. They are controls for the harness, separate from scored H2 observations.
