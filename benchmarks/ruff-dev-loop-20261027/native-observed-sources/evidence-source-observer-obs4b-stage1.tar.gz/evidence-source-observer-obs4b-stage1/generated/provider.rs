#[macro_export]
macro_rules! make {
    () => {
        #[proc_macro]
        pub fn read_def(_: proc_macro::TokenStream) -> proc_macro::TokenStream {
            let s = proc_macro::Span::def_site();
            let value = format!("{}|{}|{:?}", s.file(),s.line(),s.source_text());
            proc_macro::TokenTree::Literal(proc_macro::Literal::string(&value)).into()
        }
    }
}
// private comment
