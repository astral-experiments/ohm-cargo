fn main(){println!("{}",made::read_def!());}
