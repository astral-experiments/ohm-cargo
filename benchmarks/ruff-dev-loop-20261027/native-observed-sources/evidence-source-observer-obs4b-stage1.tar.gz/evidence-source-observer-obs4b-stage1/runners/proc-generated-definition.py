"""Trace a re-exported source file serialized in a generated proc-macro definition."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


arm,out=map(lambda a:Path(a).resolve(),sys.argv[1:]);out.mkdir()
with tempfile.TemporaryDirectory(prefix='ohm-proc-def-source-',dir='/tmp') as tmp:
    ws=Path(tmp)/'source';ws.mkdir();data={}
    (ws/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=["provider","made","app"]\n')
    producer='''#[macro_export]
macro_rules! make {
    () => {
        #[proc_macro]
        pub fn read_def(_: proc_macro::TokenStream) -> proc_macro::TokenStream {
            let s = proc_macro::Span::def_site();
            let value = format!("{}|{}|{:?}", s.file(),s.line(),s.source_text());
            proc_macro::TokenTree::Literal(proc_macro::Literal::string(&value)).into()
        }
    }
}
// private comment
'''
    samples=[('provider','',producer,'lib.rs'),('made','[lib]\nproc-macro=true\n[dependencies]\nprovider={path="../provider"}',
              '#![feature(proc_macro_def_site)]\nextern crate proc_macro;\nprovider::make!();\n','lib.rs'),
             ('app','[dependencies]\nmade={path="../made"}','fn main(){println!("{}",made::read_def!());}\n','main.rs')]
    for nm,manifest,src,path in samples:
        d=ws/nm/'src';d.mkdir(parents=True);(d/path).write_text(src);(d.parent/'Cargo.toml').write_text(f'[package]\nname="{nm}"\nversion="0.0.0"\nedition="2021"\n{manifest}\n')
        (out/f'{nm}.rs').write_text(src)
    env=dict(os.environ,RUSTUP_HOME=str(arm),RUSTC=str(arm/'toolchains/ohm/bin/rustc'),RUSTC_BOOTSTRAP='made',
             CARGO_HOME=str(Path(tmp)/'cargo-home'),CARGO_TARGET_DIR=str(Path(tmp)/'target'),CARGO_BUILD_BUILD_DIR=str(Path(tmp)/'shared'),CARGO_BUILD_JOBS='2')
    fp=ws/'provider/src/lib.rs'
    for n in ('prime','after','force-app','cold'):
        if n=='after':fp.write_text(producer.replace('private comment','private remarks'))
        if n=='force-app':
            app=ws/'app/src/main.rs';app.write_text('const _: () = ();\n'+app.read_text())
        if n=='cold':env.update(CARGO_TARGET_DIR=str(Path(tmp)/'cold-target'),CARGO_BUILD_BUILD_DIR=str(Path(tmp)/'cold-shared'))
        z=subprocess.run(['cargo','+ohm','build','-vv','-p','app','--offline','--message-format=json'],env=env,cwd=ws,capture_output=True,text=True)
        (out/(n+'.stderr')).write_text(z.stderr);(out/(n+'.stdout')).write_text(z.stdout)
        rows=[json.loads(l) for l in z.stdout.splitlines() if l.startswith('{')]
        artifacts=[a for a in rows if a['reason']=='compiler-artifact'];rec={'code':z.returncode,'artifacts':{a['target']['name']:a['fresh'] for a in artifacts}};data[n]=rec
        rec['rustc_command_lines']=[line for line in z.stderr.splitlines() if 'Running `' in line and '--crate-name' in line]
        if z.returncode:break
        executable,=[a['executable'] for a in artifacts if a.get('executable')];rec['value']=subprocess.check_output([executable],cwd=ws,text=True).strip()
        for a in artifacts:
            files={}
            for fname in a['filenames']:
                f=Path(fname)
                if f.suffix in ('.rmeta','.so'):
                    raw=f.read_bytes();files[f.name]={'sha256':hashlib.sha256(raw).hexdigest(),'contains_source_md5':raw.count(hashlib.md5(fp.read_bytes()).digest())}
                    if f.suffix=='.rmeta':shutil.copyfile(f,out/f'{n}-{a["target"]["name"]}.rmeta')
            if files:rec[a['target']['name']]=files
        print(n,rec['value'],rec['artifacts'],flush=True)
    (out/'results.json').write_text(json.dumps(data,indent=2)+'\n')
