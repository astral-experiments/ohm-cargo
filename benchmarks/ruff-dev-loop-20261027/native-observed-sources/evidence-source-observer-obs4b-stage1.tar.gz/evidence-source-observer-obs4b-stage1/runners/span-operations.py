"""Compile a real proc macro and independently isolate each span observation in rustc depinfo."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


arm, out = map(lambda arg: Path(arg).resolve(), sys.argv[1:]);out.mkdir()
env=dict(os.environ,RUSTUP_HOME=str(arm),RUSTC_BOOTSTRAP='probe')
leaf='''pub fn value() -> u8 { 3 }
#[macro_export] macro_rules! send { ($cb:ident) => { $cb!(foreign_tag "xyz") } }
#[macro_export] macro_rules! mixed { ($cb:ident, $token:tt) => { $cb!(foreign_tag $token) } }
// unrelated private file contents
'''
probe='''#![feature(proc_macro_span)]
extern crate proc_macro;
use proc_macro::{Literal, TokenStream, TokenTree};
fn string(value:String) -> TokenStream {TokenTree::Literal(Literal::string(&value)).into()}
#[proc_macro] pub fn text(input:TokenStream)->TokenStream {let t=input.into_iter().next().unwrap();string(format!("{:?}",t.span().source_text()))}
#[proc_macro] pub fn range(input:TokenStream)->TokenStream {let t=input.into_iter().next().unwrap();string(t.span().byte_range().len().to_string())}
#[proc_macro] pub fn join(input:TokenStream)->TokenStream {let mut ts=input.into_iter();let a=ts.next().unwrap().span();let b=ts.next().unwrap().span();string(a.join(b).is_some().to_string())}
#[proc_macro] pub fn subrange(input:TokenStream)->TokenStream {let TokenTree::Literal(lit)=input.into_iter().nth(1).unwrap() else {panic!()};string(lit.subspan(0..1).is_some().to_string())}
#[proc_macro] pub fn subrange_outside(input:TokenStream)->TokenStream {let TokenTree::Literal(lit)=input.into_iter().nth(1).unwrap() else {panic!()};string(lit.subspan(400..401).is_some().to_string())}
'''
observations={}
with tempfile.TemporaryDirectory(prefix='ohm-observer-apis-',dir='/tmp') as tmp:
    work=Path(tmp)
    def command(name,*args):
        cmd=['rustc','+ohm',*map(str,args)];z=subprocess.run(cmd,cwd=work,env=env,capture_output=True,text=True)
        (out/(name+'.compile.json')).write_text(json.dumps({'argv':cmd,'status':z.returncode,'stdout':z.stdout,'stderr':z.stderr},indent=2)+'\n')
        z.check_returncode()
    for name,src in [('leaf.rs',leaf),('probe.rs',probe)]:
        (work/name).write_text(src);(out/name).write_text(src)
    command('producer','leaf.rs','--crate-type=rlib','-Cincremental=leaf-incr','-Zpublic-api-hash')
    command('proc','probe.rs','--crate-type=proc-macro')
    def client(name,reader,spelling):
        source='use probe::'+reader+'; fn main() { assert_eq!(leaf::value(),3); println!("{}",'+spelling+');}\n'
        (work/'client.rs').write_text(source);(out/(name+'.rs')).write_text(source)
        command(name,'client.rs','--edition=2021','--extern','probe=libprobe.so','--extern','leaf=libleaf.rlib','--emit=link,dep-info=actual.d','-Zpublic-api-hash')
        actual=(work/'actual.d').read_text(); (out/(name+'.d')).write_text(actual)
        stdout=subprocess.check_output([work/'client'],cwd=work,text=True,env=env).strip()
        inputs=next(l.removeprefix('actual.d: ').split() for l in actual.splitlines() if l.startswith('actual.d: '))
        observations[name]={'value':stdout,'prerequisites':inputs,'marker':'actual.d/ohm-foreign-span-bytes' in inputs,
            'source_tracked':any(Path(p).name=='leaf.rs' for p in inputs)}
    for reader in ['text','range','join','subrange','subrange_outside']:
        client('external-'+reader,reader,'leaf::send!('+reader+')')
        client('local-'+reader,reader,reader+'!(local_tag "xyz")')
    client('different-files-join','join','leaf::mixed!(join, local_tag)')
    # Keep the rlib and token offsets unchanged, but make its original source file fail rustc's content check.
    (work/'leaf.rs').write_text(leaf.replace('private file','changed file'))
    client('external-stale-source','text','leaf::send!(text)')

(out/'arm.json').write_bytes((arm/'receipt.json').read_bytes())
(out/'results.json').write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps(observations,indent=2))
