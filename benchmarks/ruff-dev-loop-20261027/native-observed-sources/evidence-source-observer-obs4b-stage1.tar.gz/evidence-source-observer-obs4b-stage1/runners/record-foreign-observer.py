"""A direct run-make rustc shim that also audits the emitted depinfo and clock-free client output."""
import json
from pathlib import Path
import subprocess
import sys


trace = Path('__PRIVATE_RECORDS__')
args = ['__REAL_FRONT__', '--sysroot', '__SYSROOT__', *sys.argv[1:]]
result = subprocess.run(args, capture_output=True)
row = {'argv': args, 'returncode': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
       'stderr': result.stderr.decode(errors='replace')}
if 'client.rs' in args and result.returncode == 0:
    row['depinfo'] = Path('actual.d').read_text()
if 'client.rs' in args and result.returncode == 0 and '--crate-type=rlib' not in args and 'rlib' not in args:
    executed = subprocess.run([Path.cwd() / 'client'], capture_output=True, check=True)
    row['client_returncode'] = executed.returncode
    row['client_stdout'] = executed.stdout.decode()
    row['client_stderr'] = executed.stderr.decode()
if 'leaf.rs' in args and result.returncode == 0:
    row['before_rs'] = Path('before.rs').read_text()
index = len(list(trace.glob('*.json')))
(trace / f'{index:03}.json').write_text(json.dumps(row, indent=2) + '\n')
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)
