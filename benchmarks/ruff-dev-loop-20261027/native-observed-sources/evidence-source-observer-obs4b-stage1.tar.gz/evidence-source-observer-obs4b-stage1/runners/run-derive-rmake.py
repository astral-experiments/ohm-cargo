"""Compile and run the checked-in run-make test using an existing host support library."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parent
home,where=map(lambda p:Path(p).resolve(),sys.argv[1:3]);where.mkdir()
fixtures=(Path(os.environ.get('OHM_RUN_MAKE_FIXTURES','/home/dev-user/code/oss/ohm-rust-private-native-20261027/tests/run-make'))/
          (sys.argv[3] if len(sys.argv)>3 else 'rdr-public-hash-private-native-derive'))
inputs=Path(os.environ.get('OHM_RUN_MAKE_SUPPORT_RECEIPT','/home/dev-user/.cache/ohm-build-cutoff-20261027/rmake/wire-trace-before-sealed-cargo-stdout'))
rows=[j for line in inputs.open() if (j:=json.loads(line)).get('reason')=='compiler-artifact']
dirs=sorted({str(Path(p).parent) for r in rows for p in r['filenames'] if Path(p).suffix in ('.rlib','.so','.rmeta')})
rlib,=[p for r in rows if r['target']['name']=='run_make_support' for p in r['filenames'] if p.endswith('.rlib')]
receipt=json.loads((home/'receipt.json').read_bytes());stage=Path(receipt['sysroot']);driver=Path(receipt['driver']).parent
with tempfile.TemporaryDirectory(dir='/tmp',prefix='ohm-derive-rmake-') as ts:
    t=Path(ts);repo=t/'fixture';shutil.copytree(fixtures,repo);runner=t/'rmake'
    hostcmd=['rustc','+ohm','--edition=2024',str(repo/'rmake.rs'),'--extern','run_make_support='+rlib,
             *[arg for d in dirs for arg in ['-L','dependency='+d]],'-o',str(runner)]
    build=subprocess.run(hostcmd,capture_output=True,cwd=repo);(where/'host-rustc.stderr').write_bytes(build.stderr);build.check_returncode()
    env=dict(os.environ,RUSTC=str(home/'toolchains/ohm/bin/rustc'),RUSTC_BOOTSTRAP='1',HOST_RUSTC_DYLIB_PATH=str(driver),
             TARGET_EXE_DYLIB_PATH=str(stage/'lib/rustlib/x86_64-unknown-linux-gnu/lib'),LD_LIBRARY_PATH=str(driver)+':'+str(stage/'lib'),
             LD_LIB_PATH_ENVVAR='LD_LIBRARY_PATH',TARGET='x86_64-unknown-linux-gnu',HOST='x86_64-unknown-linux-gnu',TMPDIR=str(repo))
    if template:=os.environ.get('OHM_RUN_MAKE_RECORD_TEMPLATE'):
        trace=where/'trace';trace.mkdir();shim=t/'record-rustc'
        content=Path(template).read_text().replace('__REAL_FRONT__',str(stage/'bin/rustc')).replace('__SYSROOT__',str(stage)).replace('__PRIVATE_RECORDS__',str(trace))
        shim.write_text('#!/usr/bin/python3\n'+content);shim.chmod(0o755);env['RUSTC']=str(shim)
    p=subprocess.run([runner],cwd=repo,env=env,capture_output=True);(where/'stderr').write_bytes(p.stderr);(where/'stdout').write_bytes(p.stdout)
    (where/'result.json').write_text(json.dumps({'status':p.returncode,'driver':receipt['sha256'],'fixtures':str(fixtures)},indent=2)+'\n')
    print('checked-in run-make status',p.returncode,p.stderr[-1300:].decode(),flush=True);sys.exit(p.returncode)
