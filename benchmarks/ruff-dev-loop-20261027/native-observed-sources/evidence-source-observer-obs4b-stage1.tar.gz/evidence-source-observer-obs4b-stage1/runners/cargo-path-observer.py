"""Run ordinary Cargo and its default Ohm mode under a representable path containing whitespace."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat as statmod
import subprocess
import sys
import tempfile


arm, out=map(lambda x:Path(x).resolve(),sys.argv[1:3]);out.mkdir()
char={'newline':'\n','tab':'\t','space':' ','plain':'-'}[sys.argv[3]]
ordinary='ordinary' in sys.argv[4:]
causal='causal' in sys.argv[4:]
assert_kind=next((a.removesuffix('-assert') for a in sys.argv[4:] if a.endswith('-assert')),None)
assert assert_kind in (None,'build','test','check')
with tempfile.TemporaryDirectory(dir='/tmp',prefix='ohm-makepath-observer-') as td:
    t=Path(td);ws=t/('tree'+char+'extra');ws.mkdir()
    (ws/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=["leaf","probe","app"]\n')
    leaf='pub fn value()->u8 {7}\n#[macro_export] macro_rules! send {($cb:ident)=>{$cb!(foreign_tag)};}\n// private comment\n'
    probe='extern crate proc_macro; use proc_macro::{Literal,TokenStream,TokenTree}; #[proc_macro] pub fn text(i:TokenStream)->TokenStream {let v=i.into_iter().next().unwrap().span().source_text();TokenTree::Literal(Literal::string(&format!("{v:?}"))).into()}\n'
    client='use probe::text;fn main(){println!("{}:{}",leaf::value(),leaf::send!(text));}\n'
    if assert_kind:client='use probe::text; const READING:&str=leaf::send!(text); const _:()=assert!(READING.len()>4); fn main(){println!("{}:{}",leaf::value(),READING);}\n'
    for n,extra,src,fn in [('leaf','',leaf,'lib.rs'),('probe','[lib]\nproc-macro=true',probe,'lib.rs'),('app','[dependencies]\nleaf={path="../leaf"}\nprobe={path="../probe"}',client,'main.rs')]:
        directory=ws/n/'src';directory.mkdir(parents=True);(directory/fn).write_text(src)
        (directory.parent/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.0.0"\nedition="2021"\n{extra}\n')
    env=dict(os.environ,RUSTUP_HOME=str(arm),RUSTC=str(arm/'toolchains/ohm/bin/rustc'),CARGO_BUILD_JOBS='2',
             CARGO_TARGET_DIR=str(t/'target'),CARGO_BUILD_BUILD_DIR=str(t/'shared'))
    src=ws/'leaf/src/lib.rs';results={}
    edited_leaf=leaf.replace('private comment','private remarks' if 'same-length' in sys.argv[4:] else 'private comments')
    if causal:env['CARGO_HOME']=str(t/'cargo-home')
    edited_time=None;snapshot=t/'pre-edit.tar';physical=str(Path(json.loads((arm/'receipt.json').read_bytes())['sysroot'])/'bin/rustc')
    def checkpoint():
        records={};links={}
        for d in [t/'target',t/'shared']:
            for f in sorted(d.rglob('*')):
                rel=str(f.relative_to(t));s=f.lstat();kind=statmod.S_IFMT(s.st_mode)
                if statmod.S_ISREG(s.st_mode):
                    with f.open('rb') as fd:h=hashlib.file_digest(fd,'sha256').hexdigest()
                    link=links.setdefault((s.st_dev,s.st_ino),rel);extra=(s.st_size,h,link)
                elif f.is_symlink():extra=(os.readlink(f),)
                else:extra=()
                records[rel]=(s.st_mode,s.st_mtime_ns,*extra)
        return records
    phases=('prime','edit','leaf-cleared','app-cleared','both-cleared','edited-cold') if causal else ('prime','repeat','edit','repeat-edit','edited-cold')
    for n in phases:
        cleared=[]
        if n in ('leaf-cleared','app-cleared','both-cleared'):
            assert snapshot.is_file() and edited_time is not None
            for directory in (t/'target',t/'shared'):
                if directory.exists():shutil.rmtree(directory)
            subprocess.run(['tar','-xf',snapshot,'-C',t],check=True)
            restored=checkpoint()
            assert restored==manifest,[(k,v,restored.get(k)) for k,v in manifest.items() if restored.get(k)!=v][:4]
            for unit in (['leaf','app'] if n=='both-cleared' else [n.split('-')[0]]):
                lines=(out/'prime.exec').read_text().splitlines()
                roots={Path(re.search(r'"incremental=([^\"]+)"',line)[1]) for line in lines if 'execve("'+physical+'"' in line and '"--crate-name", "'+unit+'"' in line}
                assert len(roots)==1
                real={p.resolve() for d in roots for p in d.glob(unit+'-*') if p.is_dir()}
                assert len(real)==1,(unit, sorted(str(x.relative_to(t)) for x in (t/'target').rglob('incremental')))
                folder,=real;assert folder.is_relative_to(t);cleared.append(str(folder.relative_to(t)));shutil.rmtree(folder)
            src.write_text(edited_leaf);os.utime(src,ns=edited_time)
        if n=='edit':src.write_text(edited_leaf)
        if n=='edit':stat=src.stat();edited_time=(stat.st_atime_ns,stat.st_mtime_ns)
        if n=='edited-cold':env.update(CARGO_TARGET_DIR=str(t/'cold-target'),CARGO_BUILD_BUILD_DIR=str(t/'cold-shared'))
        args=['cargo','+ohm',*(['-Zohm-defaults=no'] if ordinary else []),assert_kind or 'build','-p','app','--offline','--message-format=json']
        if assert_kind=='test':args.append('--no-run')
        if causal:args=['strace','-f','-qq','-s','65535','-e','trace=execve','-o',str(out/(n+'.exec')), *args, '-vv']
        z=subprocess.run(args,cwd=ws,env=env,capture_output=True,text=True);(out/(n+'.stdout')).write_text(z.stdout);(out/(n+'.stderr')).write_text(z.stderr)
        rows=[json.loads(l) for l in z.stdout.splitlines() if l.startswith('{')]
        r={'code':z.returncode,'artifacts':{x['target']['name']:x['fresh'] for x in rows if x['reason']=='compiler-artifact'},'depinfo':{}}
        r['errors']=[x['message']['code']['code'] for x in rows if x['reason']=='compiler-message' and x['message'].get('code') and x['message']['level']=='error']
        if causal:
            r['cleared_incremental']=cleared;r['physical_rustc']=[]
            for line in (out/(n+'.exec')).read_text(errors='replace').splitlines():
                if 'execve("'+physical+'"' not in line:continue
                crate=re.search(r'"--crate-name", "([^"]+)"',line)
                if crate and crate[1] in ('leaf','probe','app'):r['physical_rustc'].append([crate[1],'link-only' if 'link-only' in line else 'full'])
                elif 'link-only' in line:r['physical_rustc'].append(['unqualified','link-only'])
        if z.returncode==0:
            saved=out/n;saved.mkdir();(saved/'leaf.rs').write_bytes(src.read_bytes())
            project,=[x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']=='leaf']
            for raw in project['filenames']:
                p=Path(raw);shutil.copyfile(p,saved/('libleaf'+p.suffix))
            if assert_kind:r['value']='passed source-text compile-time assertion'
            else:
                exe,=[x['executable'] for x in rows if x.get('executable')];r['value']=subprocess.check_output([exe],cwd=ws,env=env,text=True).strip()
                with open(exe,'rb') as f:r['exe_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
        for d in map(Path,(env['CARGO_TARGET_DIR'],env['CARGO_BUILD_BUILD_DIR'])):
            for f in sorted(d.rglob('*.d')):
                if f.stat().st_size<10000:r['depinfo'][str(f.relative_to(t))]=f.read_text(errors='replace')
        results[n]=r
        if z.returncode and (not assert_kind or n in ('prime','repeat')):break
        if causal and n=='prime':
            paths=[str(d.relative_to(t)) for d in (t/'target',t/'shared') if d.exists()]
            manifest=checkpoint();(out/'prime-checkpoint.json').write_text(json.dumps(manifest,sort_keys=True)+'\n')
            subprocess.run(['tar','--format=pax','--pax-option=delete=atime,delete=ctime','-cf',snapshot,'-C',t,*paths],check=True)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print([(k,v['code'],v['artifacts'],v.get('value')) for k,v in results.items()])
