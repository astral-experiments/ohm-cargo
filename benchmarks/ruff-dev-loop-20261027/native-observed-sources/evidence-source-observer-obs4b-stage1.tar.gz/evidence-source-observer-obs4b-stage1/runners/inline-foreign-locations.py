"""Exercise a foreign call-site and line table through a retained inline-only middle crate."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',required=True,type=Path)
parser.add_argument('arms',type=Path,nargs='+')
args=parser.parse_args()
out=args.out.resolve();out.mkdir();work=Path(tempfile.mkdtemp(dir='/tmp',prefix='ohm-foreign-inline-'))
repo=work/'workspace';(repo/'defs/src').mkdir(parents=True);(repo/'bridge/src').mkdir(parents=True)
(repo/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=["defs","bridge"]\n[profile.dev]\ndebug="line-tables-only"\nopt-level=2\ncodegen-units=1\npanic="abort"\n')
for crate,extra in [('defs',''),('bridge','[dependencies]\ndefs={path="../defs"}\n')]:
    (repo/crate/'Cargo.toml').write_text(f'[package]\nname="{crate}"\nversion="0.0.0"\nedition="2024"\n'+extra)
p=repo/'defs/src/lib.rs';mid=repo/'bridge/src/lib.rs';client=repo/'client.rs'
original='''#![no_std]
#![allow(dead_code)]
/// Example private method: dataclass.field.
fn private_helper() {}
#[inline(always)] #[track_caller]
fn observe() -> u32 { core::panic::Location::caller().column() }
unsafe extern "C" { fn observable_sink(value: u32); }
#[inline(always)]
pub fn captured(value: u32) -> u32 {
    unsafe { observable_sink(value); }
    observe()
}
'''
sources={'original':original,'edited':original.replace('dataclass.field','dataclasses.field'),
         'moved':original.replace('    observe()','      observe()')}
assert len(sources['edited'])-len(original)==2
mid.write_text('#![no_std]\n#[inline(always)] pub fn through(value: u32) -> u32 { defs::captured(value) }\n')
client.write_text('#![no_std]\n#[unsafe(no_mangle)] pub extern "C" fn observed_column(value:u32) -> u32 { bridge::through(value) }\n')
for key,v in sources.items():(out/(key+'.rs')).write_text(v)
(out/'bridge.rs').write_bytes(mid.read_bytes());(out/'client.rs').write_bytes(client.read_bytes())
assembly=work/'start.s';obj=work/'start.o'
assembly.write_text('.global _start\n.global observable_sink\n.section .text._start,"ax",@progbits\n_start:\n mov $15,%edi\n call observed_column\n mov %eax,%edi\n mov $60,%eax\n syscall\nobservable_sink:\n ret\n.section .note.GNU-stack,"",@progbits\n')
subprocess.run(['/usr/bin/as','-o',obj,assembly],check=True)
wild=Path('/home/dev-user/.cache/ohm-wild-regular-reloc-20261026/combined-build/ld.bfd')
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(wild)=='0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5'
def run(cmd,env,required=True):
    proc=subprocess.run(list(map(str,cmd)),cwd=repo,env=env,text=True,capture_output=True)
    if required and proc.returncode: raise RuntimeError((cmd,proc.returncode,proc.stderr[-1400:]))
    return proc
all_results={}
for arm,home in enumerate(args.arms):
    side=home.name;where=out/side;where.mkdir();results={};all_results[side]=results
    env=dict(os.environ,RUSTUP_HOME=str(home.resolve()),RUSTC=str(home.resolve()/'toolchains/ohm/bin/rustc'),CARGO_BUILD_JOBS='2')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):
        env.pop(key,None)
    caps={}
    for stage,source in sources.items():
        p.write_text(source);env.update(CARGO_TARGET_DIR=str(work/f'{arm}t{stage}'),CARGO_BUILD_BUILD_DIR=str(work/f'{arm}s{stage}'))
        run(['cargo','+ohm','generate-lockfile','--offline'],env)
        cargo=run(['cargo','+ohm','build','--offline','--locked','--workspace','--message-format=json'],env)
        (where/(stage+'-cargo.jsonl')).write_text(cargo.stdout);caps[stage]={}
        for row in map(json.loads,cargo.stdout.splitlines()):
            if row.get('reason')!='compiler-artifact': continue
            crate=row['target']['name'];assert not row['fresh'];caps[stage][crate]={}
            dest=work/f'{arm}cap{stage}';dest.mkdir(exist_ok=True)
            for file in map(Path,row['filenames']):
                if file.suffix in ('.rlib','.rmeta'):
                    path=dest/('lib'+crate+file.suffix);shutil.copyfile(file,path);caps[stage][crate][file.suffix]=path
            (where/(stage+'-'+crate+'-root.txt')).write_text(run(['rustc','+ohm','-Zls=root',caps[stage][crate]['.rlib']],env).stdout)
    for label,rev,bridge in [('original','original','original'),('stale','edited','original'),('rebuilt','edited','edited'),('stale-moved','moved','original'),('rebuilt-moved','moved','moved')]:
        p.write_text(sources[rev]);active=work/f'{arm}-active';active.mkdir(exist_ok=True)
        for crate,select in [('defs',rev),('bridge',bridge)]:
            for ext,path in caps[select][crate].items():shutil.copyfile(path,active/('lib'+crate+ext))
        clientobj=active/'client.o'
        cc=run(['rustc','+ohm',client,'--crate-type=lib','--edition=2024','--emit=obj','-C','opt-level=2','-C','panic=abort','-C','debuginfo=line-tables-only',
                '-C','codegen-units=1','--error-format=json','--extern',f'bridge={active}/libbridge.rlib','--extern',f'defs={active}/libdefs.rlib',
                '-L',f'dependency={active}','-o',clientobj],env,False)
        (where/(label+'-rustc.stderr')).write_text(cc.stderr)
        if cc.returncode:
            codes=[r['code']['code'] for r in map(json.loads,cc.stderr.splitlines()) if r.get('code')]
            results[label]={'rejected':codes};continue
        exe=active/'linked';ld=run([wild,'--no-fork','--threads=1','--build-id=sha1','--gc-sections','-m','elf_x86_64','-o',exe,obj,clientobj],{'LC_ALL':'C'})
        assert not ld.stderr and not ld.stdout
        result=run([exe],{},False);dump=run(['/usr/bin/readelf','-wL',clientobj],{})
        raw=run(['/usr/bin/readelf','-wl',clientobj],{})
        (where/(label+'-dwarf.txt')).write_text(dump.stdout+'\n'+raw.stdout)
        section=active/'line';run(['/usr/bin/objcopy','--dump-section','.debug_line='+str(section),clientobj,active/'objcopy-out'],{})
        asm=run(['/usr/bin/objdump','-dr',clientobj],{}).stdout
        (where/(label+'-disassembly.txt')).write_text(asm)
        results[label]={'returns_column':result.returncode,'client_sha':sha(clientobj),'elf_sha':sha(exe),'line_table_sha':sha(section),
                        'raw_dwarf_producer_rows':sum('defs/src/' in l or 'defs/src:' in l for l in dump.stdout.splitlines())}
    print(side,results,flush=True)
(out/'result.json').write_text(json.dumps({'root':str(work),'arms':all_results},indent=2)+'\n')
