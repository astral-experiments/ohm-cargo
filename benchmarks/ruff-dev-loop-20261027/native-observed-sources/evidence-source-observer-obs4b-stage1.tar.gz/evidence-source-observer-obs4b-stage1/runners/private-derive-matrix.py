"""Run paired user sources with a real Ohm Cargo producer and a separate downstream rustc."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


def fixture(name, root='', inside='', body='7', *, public=False, front='', consumer=True):
    return dict(name=name, root=root, inside=inside, body=body, public=public, front=front, consumer=consumer)


cases=[
    fixture('unrelated-rules-rpit',
            '#[macro_export] macro_rules! unrelated { () => { 7usize }; }\npub fn opaque() -> impl Copy { 8u8 }',
            body='dep::unrelated!() + core::mem::size_of_val(&dep::opaque())'),
    fixture('unrelated-decl-macro',
            'mod separate { pub macro unrelated() { 7usize } }\npub use separate::unrelated;',
            body='dep::unrelated!()'),
    fixture('local-opaque-direct','pub use scope::exposed;',
            'pub fn exposed() -> impl Copy + PartialEq { private::Hidden(7) }',
            'let x=dep::exposed(); core::mem::size_of_val(&x) + usize::from(x==x)'),
    fixture('local-opaque-nested','pub use scope::exposed;',
            'pub fn exposed() -> impl Copy + PartialEq { Some((private::Hidden(7),)) }',
            'let x=dep::exposed(); core::mem::size_of_val(&x) + usize::from(x==x)'),
    fixture('closure-capture','pub use scope::exposed;',
            '#[inline(never)] fn consume(value: private::Hidden) -> usize { usize::from(value.0) }\n'
            'pub fn exposed() -> impl Fn() -> usize { let v=private::Hidden(7); move || consume(v) }',
            'let f=dep::exposed(); core::mem::size_of_val(&f) + f()'),
    fixture('rpiti-trait','pub use scope::{Public,Api};',
            'pub trait Api { fn value() -> impl Copy + PartialEq; }\npub struct Public;\n'
            'impl Api for Public { fn value() -> impl Copy + PartialEq { private::Hidden(7) } }',
            'let v=<dep::Public as dep::Api>::value(); core::mem::size_of_val(&v) + usize::from(v==v)'),
    fixture('tait-hidden','pub use scope::{Public,exposed};',
            'pub type Public=impl Copy + PartialEq;\n#[define_opaque(Public)] pub fn exposed()->Public { private::Hidden(7) }',
            'let v:dep::Public=dep::exposed(); core::mem::size_of_val(&v) + usize::from(v==v)'),
    fixture('effective-associated-type','pub use scope::{Public,Api};',
            'pub trait Api { type Item: Copy + PartialEq; fn value() -> Self::Item; }\npub struct Public;\n'
            'impl Api for Public { type Item=private::Hidden; fn value()->Self::Item { private::Hidden(7) } }',
            'let v:<dep::Public as dep::Api>::Item=dep::Public::value();core::mem::size_of_val(&v)+usize::from(v==v)',public=True),
    fixture('effective-reexport','pub use scope::Reexported;',
            'pub use private::Hidden as Reexported;','core::mem::size_of::<dep::Reexported>()',public=True),
    fixture('generic-mir','pub use scope::generic;',
            'pub fn generic<T>(_: T)->usize { core::mem::size_of::<private::Hidden>() }','dep::generic(())'),
    fixture('source-rules-private-path',
            '#[macro_export] macro_rules! reveal { () => { $crate::scope::private::Hidden(7) }; }',
            body='let v=dep::reveal!();core::mem::size_of_val(&v)',consumer=False),
    fixture('dollar-crate-inferred',
            '#[doc(hidden)] pub use scope::provide as __provide;\n#[macro_export] macro_rules! reveal { () => { $crate::__provide() }; }',
            'pub fn provide()->impl Copy + PartialEq { private::Hidden(7) }',
            'let v=dep::reveal!();core::mem::size_of_val(&v) + usize::from(v==v)'),
    fixture('decl-macro-inferred','pub use scope::provide as __provide;\npub macro reveal() { $crate::__provide() }',
            'pub fn provide()->impl Copy + PartialEq { private::Hidden(7) }',
            'let v=dep::reveal!();core::mem::size_of_val(&v) + usize::from(v==v)'),
    fixture('decl-macro-private-path','pub use scope::reveal;',
            'pub macro reveal() { { let v=private::Hidden(7); core::mem::size_of_val(&v) + usize::from(v==v) } }',
            'dep::reveal!()'),
    fixture('opaque-rules-private-path','pub use scope::reveal as exposed;',
            '#[rustc_macro_transparency="opaque"] #[macro_export] macro_rules! reveal { () => {{ '
            'let v=private::Hidden(7); core::mem::size_of_val(&v) + usize::from(v==v) }}; }\npub use reveal;',
            'dep::exposed!()'),
    fixture('generated-rules', 'macro_rules! provider { ($n:ident) => { #[macro_export] macro_rules! $n { () => { 7usize }; } }; }\nprovider!(generated);',body='dep::generated!()'),
    fixture('custom-opaque-neutral','#[rustc_macro_transparency="opaque"] #[macro_export] macro_rules! neutral { () => {7usize}; }',body='dep::neutral!()'),
    fixture('forged-automatically-derived',
            '#[macro_export] macro_rules! unrelated { () => { 7usize }; }\npub fn opaque() -> impl Copy { 8u8 }',
            body='dep::unrelated!()'),
    fixture('custom-proc-derive',
            '#[macro_export] macro_rules! unrelated { () => { 7usize }; }\npub fn opaque() -> impl Copy { 8u8 }',
            body='dep::unrelated!()'),
]


def parse_args():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('arm',type=Path);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--only',action='append',default=[])
    return ap.parse_args()


def run_case(case,home,work,output):
    name=case['name'];out=output/name;out.mkdir();workspace=work/name
    package=workspace/'dep';(package/'src/scope').mkdir(parents=True)
    (package/'Cargo.toml').write_text('[package]\nname="dep"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\ncodegen-units=1\n')
    lib='#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]\n#![allow(dead_code,internal_features,unused_imports,unused_macros)]\nmod scope;\n'+case['root']+'\n'
    scope='mod private;\n'+case['inside']+'\n'
    lib=lib.replace('private::Hidden(7)','private::Hidden::Value(7)')
    scope=scope.replace('private::Hidden(7)','private::Hidden::Value(7)').replace('usize::from(value.0)','match value { private::Hidden::Value(n) => usize::from(n) }')
    if name.endswith('private-path'):
        lib=lib.replace('\nmod scope;','\npub mod scope;')
        scope=scope.replace('mod private;','pub mod private;')
        if name!='source-rules-private-path':scope=scope.replace('v=private::Hidden','v=$crate::scope::private::Hidden')
    visibility='pub' if case['public'] else 'pub(super)'
    hidden=f'/// Example dataclasses.field.\n#[derive(Clone, Copy, Debug, PartialEq, Eq)]\n{visibility} enum Hidden {{ Value(u8) }}\n'
    if name=='forged-automatically-derived':
        hidden=hidden.replace('#[derive(Clone, Copy, Debug, PartialEq, Eq)]','')+'#[automatically_derived] impl Clone for Hidden {fn clone(&self)->Self {match self { Self::Value(x)=> Self::Value(*x) }}}\n'
    if name=='custom-proc-derive':
        proc=workspace/'derive_aux';(proc/'src').mkdir(parents=True)
        manifest='[package]\nname="derive_aux"\nversion="0.0.0"\nedition="2024"\n[lib]\nproc-macro=true\n'
        (proc/'Cargo.toml').write_text(manifest);(out/'derive-aux.toml').write_text(manifest)
        impl='#[automatically_derived] impl Clone for Hidden {fn clone(&self)->Self {match self {Self::Value(x)=>Self::Value(*x)}}}'
        src='use proc_macro::TokenStream;\n#[proc_macro_derive(ForeignClone)]\npub fn derive(_:TokenStream)->TokenStream {'+json.dumps(impl)+'.parse().unwrap()}\n'
        (proc/'src/lib.rs').write_text(src);(out/'derive-aux.rs').write_text(src)
        with (package/'Cargo.toml').open('a') as f:f.write('\n[dependencies]\nderive_aux={path="../derive_aux"}\n')
        hidden=hidden.replace('#[derive(Clone, Copy, Debug, PartialEq, Eq)]','#[derive(derive_aux::ForeignClone)]')
    consumer='extern crate dep;\nuse dep::*;\nfn main() {let value:usize={'+case['body']+'};println!("{value}");}\n'
    sources={'lib.rs':lib,'scope.rs':scope,'private.rs':hidden,'consumer.rs':consumer}
    for f,content in sources.items():(out/f).write_text(content)
    (package/'src/lib.rs').write_text(lib);(package/'src/scope.rs').write_text(scope);consumer_path=workspace/'consumer.rs';consumer_path.write_text(consumer)
    private=package/'src/scope/private.rs'
    env=dict(os.environ,RUSTUP_HOME=str(home),RUSTC=str(home/'toolchains/ohm/bin/rustc'),CARGO_BUILD_JOBS='2',
             CARGO_TARGET_DIR=str(workspace/'target'),CARGO_BUILD_BUILD_DIR=str(workspace/'shared'))
    for key in ('CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','RUSTC_WRAPPER','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):
        env.pop(key,None)
    def run(args):return subprocess.run(list(map(str,args)),env=env,cwd=package,capture_output=True,text=True)
    run(['cargo','+ohm','generate-lockfile','--offline']).check_returncode()
    result={}
    moved=hidden.replace('dataclasses.field','dataclass.field')
    for tag,source in [('original',hidden),('moved',moved),('layout',moved.replace('u8)','u16)'))]:
        private.write_text(source)
        proc=run(['cargo','+ohm','build','--offline','--locked','--message-format=json'])
        rows=list(map(json.loads,proc.stdout.splitlines()));(out/(tag+'-cargo.stderr')).write_text(proc.stderr)
        if proc.returncode:
            msgs=[r['message']['rendered'] for r in rows if r.get('reason')=='compiler-message'];(out/(tag+'-failure.txt')).write_text(''.join(msgs));result[tag]={'producer_error':msgs};break
        row,=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='dep'];assert not row['fresh']
        rlib,=[p for p in row['filenames'] if p.endswith('.rlib')]
        dep_dirs=sorted({str(Path(p).parent) for r in rows if r.get('reason')=='compiler-artifact'
                         for p in r['filenames'] if p.endswith(('.rlib','.so'))})
        meta=run(['rustc','+ohm','-Zls=root',rlib]);meta.check_returncode();(out/(tag+'-header.txt')).write_text(meta.stdout)
        key=re.search('^public_hash ([0-9a-f]+)$',meta.stdout,re.M)[1]
        exe=workspace/'consumer';p=run(['rustc','+ohm',consumer_path,'--edition=2024','-C','opt-level=2',
                                      '--extern',f'dep={rlib}',*['-Ldependency='+d for d in dep_dirs],
                                      '--error-format=json','-o',exe]);(out/(tag+'-client.stderr')).write_text(p.stderr)
        if p.returncode:
            codes=[m['code']['code'] for m in map(json.loads,p.stderr.splitlines()) if m.get('code')]; observed={'client_codes':codes}
        else:
            executed=run([exe]);executed.check_returncode();observed={'value':int(executed.stdout)}
        result[tag]={'public_hash':key,**observed}
    for dir in [workspace/'target',workspace/'shared']:
        if dir.exists():shutil.rmtree(dir)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(name,result,flush=True)
    return result


if __name__=='__main__':
    opt=parse_args();home=opt.arm.resolve();output=opt.out.resolve();output.mkdir()
    with tempfile.TemporaryDirectory(dir='/tmp',prefix='ohm-native-derive-matrix-') as tmp:
        result={c['name']:run_case(c,home,Path(tmp),output) for c in cases if not opt.only or c['name'] in opt.only}
    (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
