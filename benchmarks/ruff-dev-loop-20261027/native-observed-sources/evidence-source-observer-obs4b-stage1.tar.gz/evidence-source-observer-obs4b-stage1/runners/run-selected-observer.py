"""Run the already frozen safe-derive and foreign-observer fixtures against one exact compiler."""
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys


here = Path(__file__).resolve().parent
arm, output = map(lambda p: Path(p).resolve(), sys.argv[1:])
output.mkdir()
bundle = Path(os.environ.get('OHM_EXISTING_API_FIXTURES', '/home/dev-user/.cache/ohm-build-cutoff-20261027'))
receipt = json.loads((arm / 'receipt.json').read_bytes())
(output / 'arm.json').write_text(json.dumps(receipt, indent=2)+'\n')

def run(cpus, name, argv, **extra):
    args = ['taskset','-c',cpus,sys.executable,'-B',*map(str,argv)]
    (output/(name+'.argv.json')).write_text(json.dumps(args,indent=2)+'\n')
    with (output/(name+'.log')).open('wb') as log:
        proc = subprocess.run(args, env=dict(os.environ, **extra), stdout=log, stderr=subprocess.STDOUT)
    print(name, proc.returncode, flush=True)
    return name, proc.returncode

def checked_in():
    results = {}
    first=['rdr-public-hash-proc-macro-foreign-bytes','rdr-public-hash-private-native-derive',
           'rdr-public-hash-private-trait-impl','rdr-public-hash-private-native-impls','release-api']
    extras=['rdr-public-hash-'+name for name in ('body-changes','extra-filename','mono-library-runtime','private-end-of-file-change','shared-generics','staticlib','track-caller-location')]
    for name in first+extras:
        template = here/'record-foreign-observer.py' if 'proc-macro' in name else bundle/'record-release-api-rustc.py'
        fixtures = name if name!='release-api' else bundle/'release-api-fixtures/after-sealed'
        out, status = run('4-5',name,[here/'run-derive-rmake.py',arm,output/name,fixtures],OHM_RUN_MAKE_RECORD_TEMPLATE=str(template),CC='/usr/bin/cc',CC_DEFAULT_FLAGS='-fPIC')
        results[out] = status
    return results

def independent_clients():
    results = {}
    for name, prog in [('diagnostics','diagnostic-byte-ranges.py'),('inline','inline-foreign-locations.py'),('matrix','private-derive-matrix.py')]:
        out, status = run('6-7',name,[here/prog,arm,'--out',output/name])
        results[out] = status
    return results

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs = [pool.submit(f) for f in (checked_in, independent_clients)]
    statuses = {k:v for job in jobs for k,v in job.result().items()}
(output/'statuses.json').write_text(json.dumps(statuses,indent=2)+'\n')
sys.exit(any(statuses.values()))
