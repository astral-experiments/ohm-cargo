"""Repeat three ordinary edited commands and the source-text reproducer in private projects."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys


here=Path(__file__).resolve().parent
arm,output=map(lambda p:Path(p).resolve(),sys.argv[1:]);output.mkdir()
def one(label,case,cpu,extra=()):
    args=['taskset','-c',cpu,sys.executable,'-B',here/'cargo-path-observer.py',arm,output/label,'plain',*extra]
    with (output/(label+'.log')).open('wb') as f:
        q=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    if q.returncode:return label,{'runner_error':q.returncode}
    rows=json.loads((output/label/'results.json').read_bytes())
    valid=list(rows)==['prime','repeat','edit','repeat-edit','edited-cold'] and all(x['code']==0 for x in rows.values())
    value='passed source-text compile-time assertion' if case=='assert' else '7:Some("foreign_tag")'
    valid=valid and all(x.get('value')==value for x in rows.values())
    print(label,'pass' if valid else 'FAIL',flush=True);return label,valid
def first():return [one('build','assert','4-5',['same-length','build-assert']),one('test-no-run','assert','4-5',['same-length','test-assert']),one('check','assert','4-5',['same-length','check-assert'])]
def second():return [one('different-width','run','6-7'),one('same-width','run','6-7',['same-length']),one('ordinary-different-width','run','6-7',['ordinary'])]
with ThreadPoolExecutor(max_workers=2) as e:
    downstream=[e.submit(job) for job in (first,second)]
    values=dict(row for job in downstream for row in job.result())
(output/'summary.json').write_text(json.dumps(values,indent=2)+'\n')
sys.exit(not all(x is True for x in values.values()))
