"""Check a foreign expansion's diagnostic byte offsets after the private documentation typo edit."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


parser=argparse.ArgumentParser()
parser.add_argument('toolchain_home',nargs='+',type=Path)
parser.add_argument('--out',type=Path,required=True)
opt=parser.parse_args()
out=opt.out.resolve();out.mkdir()
root=Path(tempfile.mkdtemp(prefix='ohm-diag-byte-range-',dir='/tmp'))
proj=root/'workspace';(proj/'defs/src').mkdir(parents=True);(proj/'bridge/src').mkdir(parents=True)
(proj/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=["defs","bridge"]\n[profile.dev]\ndebug="line-tables-only"\n')
for name,extra in [('defs',''),('bridge','[dependencies]\ndefs={path="../defs"}\n')]:
    (proj/name/'Cargo.toml').write_text(f'[package]\nname="{name}"\nversion="0.0.0"\nedition="2024"\n'+extra)
producer=proj/'defs/src/lib.rs';bridge=proj/'bridge/src/lib.rs'
source='''#![allow(dead_code)]
/// Only used in the dataclass.field example.
fn private_helper() {}
#[macro_export]
macro_rules! declare_method { () => { pub fn generated_name(_value: u32) {} }; }
'''
bridge.write_text('defs::declare_method!();\n')
consumer=proj/'consumer.rs';consumer.write_text('pub fn consume() { bridge::generated_name(); }\n')
edited=source.replace('dataclass.field','dataclasses.field');assert len(edited)==len(source)+2
(out/'original.rs').write_text(source);(out/'edited.rs').write_text(edited)
(out/'bridge.rs').write_bytes(bridge.read_bytes());(out/'consumer.rs').write_bytes(consumer.read_bytes())
reports={}
for arm,home in enumerate(opt.toolchain_home):
    home=home.resolve();label=home.name;report={};reports[label]=report
    env=dict(os.environ,RUSTUP_HOME=str(home),CARGO_BUILD_JOBS='2',
             RUSTC=str(home/'toolchains/ohm/bin/rustc'),CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST='all',
             CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST='all')
    for key in ('RUSTC_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):
        env.pop(key,None)
    caps={}
    for stage,src in [('original',source),('edited',edited)]:
        producer.write_text(src)
        target=root/f't{arm}{stage}';shared=root/f's{arm}{stage}';env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_BUILD_DIR=str(shared))
        subprocess.run(['cargo','+ohm','generate-lockfile','--offline'],cwd=proj,env=env,check=True,capture_output=True)
        cmd=['cargo','+ohm','build','--locked','--offline','--workspace','--message-format=json']
        proc=subprocess.run(cmd,cwd=proj,env=env,capture_output=True,text=True,check=True)
        d=out/label/stage;d.mkdir(parents=True);(d/'cargo.jsonl').write_text(proc.stdout);(d/'cargo.stderr').write_text(proc.stderr)
        rows=[json.loads(l) for l in proc.stdout.splitlines()]; caps[stage]={}
        for name in ('defs','bridge'):
            row,=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name]
            assert not row['fresh'];paths={}
            for p in map(Path,row['filenames']):
                if p.suffix not in ('.rmeta','.rlib'):continue
                dest=root/(f'cap{arm}{stage}');dest.mkdir(exist_ok=True)
                path=dest/(f'lib{name}'+p.suffix);shutil.copy2(p,path);paths[p.suffix]=path
            assert '.rlib' in paths
            header=subprocess.run(['rustc','+ohm','-Zls=root',str(paths['.rlib'])],env=env,capture_output=True,text=True,check=True).stdout
            (d/(name+'-root.txt')).write_text(header);caps[stage][name]=paths
            report[stage+'_'+name]={'private':re.search(r'^private hash ([0-9a-f]+)',header,re.M)[1],
                                    'public':re.search(r'^public_hash ([0-9a-f]+)',header,re.M)[1]}
    for name,producer_state,bridge_state in [('original','original','original'),('stale','edited','original'),('rebuilt','edited','edited')]:
        producer.write_text(source if producer_state=='original' else edited)
        active=root/f'links{arm}';active.mkdir(exist_ok=True)
        for crate,stage in [('defs',producer_state),('bridge',bridge_state)]:
            for ext,p in caps[stage][crate].items():shutil.copyfile(p,active/(f'lib{crate}'+ext))
        command=['rustc','+ohm',str(consumer),'--edition=2024','--crate-name','consumer','--crate-type=lib','--emit=metadata','--error-format=json',
                 '-Zmacro-backtrace','--extern',f'bridge={active}/libbridge.rlib','--extern',f'defs={active}/libdefs.rlib','-L',f'dependency={active}',
                 '-o',str(root/f'discard{arm}.rmeta')]
        p=subprocess.run(command,cwd=proj,env=env,text=True,capture_output=True)
        assert p.returncode==1,(label,name,p.stderr[-1200:]);(out/label/(name+'-diagnostic.jsonl')).write_text(p.stderr)
        errors=[];spans=[]
        def add(sp,context):
            file=Path(sp['file_name']);file=file if file.is_absolute() else proj/file
            if file.is_file():
                raw=file.read_bytes();a,b=sp['byte_start'],sp['byte_end']
                spans.append(dict(context=context,file=str(file),bytes=[a,b],line=sp['line_start'],col=sp['column_start'],
                                  snippet=raw[a:b].decode(errors='replace'),label=sp['label'],primary=sp['is_primary']))
            if (ex:=sp.get('expansion')):
                for key in ('span','def_site_span'):
                    if ex.get(key): add(ex[key],context+'/'+key)
        def diagnostic(msg):
            if msg.get('code'): errors.append(msg['code']['code'])
            for s in msg.get('spans',[]):add(s,msg['message'])
            for child in msg.get('children',[]):diagnostic(child)
        for line in p.stderr.splitlines():diagnostic(json.loads(line))
        report[name]={'errors':errors,'producer_spans':[s for s in spans if s['file']==str(producer)],'all_spans':spans}
    print(label,report['original_defs'],report['edited_defs'],[(k,report[k]['errors'],[(s['bytes'],s['line'],s['col'],s['snippet']) for s in report[k]['producer_spans'][:4]]) for k in ('original','stale','rebuilt')],flush=True)
(out/'result.json').write_text(json.dumps({'root':str(root),'arms':reports},indent=2)+'\n')
