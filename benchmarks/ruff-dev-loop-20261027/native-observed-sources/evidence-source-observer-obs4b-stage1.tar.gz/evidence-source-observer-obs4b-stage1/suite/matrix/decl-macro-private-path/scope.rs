pub mod private;
pub macro reveal() { { let v=$crate::scope::private::Hidden::Value(7); core::mem::size_of_val(&v) + usize::from(v==v) } }
