#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]
#![allow(dead_code,internal_features,unused_imports,unused_macros)]
mod scope;
#[doc(hidden)] pub use scope::provide as __provide;
#[macro_export] macro_rules! reveal { () => { $crate::__provide() }; }
