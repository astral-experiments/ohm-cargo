extern crate dep;
use dep::*;
fn main() {let value:usize={dep::unrelated!() + core::mem::size_of_val(&dep::opaque())};println!("{value}");}
