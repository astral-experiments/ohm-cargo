mod private;
pub trait Api { fn value() -> impl Copy + PartialEq; }
pub struct Public;
impl Api for Public { fn value() -> impl Copy + PartialEq { private::Hidden::Value(7) } }
