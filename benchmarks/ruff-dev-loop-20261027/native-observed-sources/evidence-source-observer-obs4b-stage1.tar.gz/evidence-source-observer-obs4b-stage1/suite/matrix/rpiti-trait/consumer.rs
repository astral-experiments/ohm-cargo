extern crate dep;
use dep::*;
fn main() {let value:usize={let v=<dep::Public as dep::Api>::value(); core::mem::size_of_val(&v) + usize::from(v==v)};println!("{value}");}
