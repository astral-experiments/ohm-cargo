extern crate dep;
use dep::*;
fn main() {let value:usize={let v:dep::Public=dep::exposed(); core::mem::size_of_val(&v) + usize::from(v==v)};println!("{value}");}
