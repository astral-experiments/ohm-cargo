mod private;
pub type Public=impl Copy + PartialEq;
#[define_opaque(Public)] pub fn exposed()->Public { private::Hidden::Value(7) }
