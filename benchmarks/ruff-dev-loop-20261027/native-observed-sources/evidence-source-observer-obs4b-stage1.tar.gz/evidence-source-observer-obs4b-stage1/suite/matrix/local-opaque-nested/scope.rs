mod private;
pub fn exposed() -> impl Copy + PartialEq { Some((private::Hidden::Value(7),)) }
