extern crate dep;
use dep::*;
fn main() {let value:usize={dep::generic(())};println!("{value}");}
