mod private;
pub fn generic<T>(_: T)->usize { core::mem::size_of::<private::Hidden>() }
