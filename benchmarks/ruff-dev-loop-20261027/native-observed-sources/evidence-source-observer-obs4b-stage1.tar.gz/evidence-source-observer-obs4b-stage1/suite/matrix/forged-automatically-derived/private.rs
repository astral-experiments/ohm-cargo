/// Example dataclasses.field.

pub(super) enum Hidden { Value(u8) }
#[automatically_derived] impl Clone for Hidden {fn clone(&self)->Self {match self { Self::Value(x)=> Self::Value(*x) }}}
