extern crate dep;
use dep::*;
fn main() {let value:usize={let v=dep::reveal!();core::mem::size_of_val(&v)};println!("{value}");}
