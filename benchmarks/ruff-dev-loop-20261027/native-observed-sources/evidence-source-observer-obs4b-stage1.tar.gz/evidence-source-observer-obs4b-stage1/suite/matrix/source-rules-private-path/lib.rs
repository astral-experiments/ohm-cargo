#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]
#![allow(dead_code,internal_features,unused_imports,unused_macros)]
pub mod scope;
#[macro_export] macro_rules! reveal { () => { $crate::scope::private::Hidden::Value(7) }; }
