extern crate dep;
use dep::*;
fn main() {let value:usize={let x=dep::exposed(); core::mem::size_of_val(&x) + usize::from(x==x)};println!("{value}");}
