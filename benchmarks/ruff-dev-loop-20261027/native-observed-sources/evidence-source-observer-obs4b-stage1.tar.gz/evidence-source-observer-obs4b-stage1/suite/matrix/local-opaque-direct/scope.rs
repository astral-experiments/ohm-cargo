mod private;
pub fn exposed() -> impl Copy + PartialEq { private::Hidden::Value(7) }
