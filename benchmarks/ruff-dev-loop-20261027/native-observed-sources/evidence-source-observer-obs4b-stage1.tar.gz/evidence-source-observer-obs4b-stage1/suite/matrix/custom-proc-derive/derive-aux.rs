use proc_macro::TokenStream;
#[proc_macro_derive(ForeignClone)]
pub fn derive(_:TokenStream)->TokenStream {"#[automatically_derived] impl Clone for Hidden {fn clone(&self)->Self {match self {Self::Value(x)=>Self::Value(*x)}}}".parse().unwrap()}
