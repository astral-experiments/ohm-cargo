extern crate dep;
use dep::*;
fn main() {let value:usize={dep::unrelated!()};println!("{value}");}
