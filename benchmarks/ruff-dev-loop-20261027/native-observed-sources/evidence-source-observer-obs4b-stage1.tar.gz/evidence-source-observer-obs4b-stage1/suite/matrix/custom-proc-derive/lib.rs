#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]
#![allow(dead_code,internal_features,unused_imports,unused_macros)]
mod scope;
#[macro_export] macro_rules! unrelated { () => { 7usize }; }
pub fn opaque() -> impl Copy { 8u8 }
