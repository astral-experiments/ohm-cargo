/// Example dataclasses.field.
#[derive(derive_aux::ForeignClone)]
pub(super) enum Hidden { Value(u8) }
