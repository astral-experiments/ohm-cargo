extern crate dep;
use dep::*;
fn main() {let value:usize={core::mem::size_of::<dep::Reexported>()};println!("{value}");}
