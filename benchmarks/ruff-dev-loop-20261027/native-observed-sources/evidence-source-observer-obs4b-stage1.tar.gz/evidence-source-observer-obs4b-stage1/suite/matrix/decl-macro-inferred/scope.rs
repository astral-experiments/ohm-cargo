mod private;
pub fn provide()->impl Copy + PartialEq { private::Hidden::Value(7) }
