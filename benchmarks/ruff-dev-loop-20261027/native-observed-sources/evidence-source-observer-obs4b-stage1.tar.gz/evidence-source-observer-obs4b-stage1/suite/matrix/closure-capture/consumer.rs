extern crate dep;
use dep::*;
fn main() {let value:usize={let f=dep::exposed(); core::mem::size_of_val(&f) + f()};println!("{value}");}
