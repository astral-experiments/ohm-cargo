mod private;
#[inline(never)] fn consume(value: private::Hidden) -> usize { match value { private::Hidden::Value(n) => usize::from(n) } }
pub fn exposed() -> impl Fn() -> usize { let v=private::Hidden::Value(7); move || consume(v) }
