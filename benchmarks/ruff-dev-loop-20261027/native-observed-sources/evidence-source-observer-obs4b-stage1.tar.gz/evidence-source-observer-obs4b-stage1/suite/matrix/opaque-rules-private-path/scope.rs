pub mod private;
#[rustc_macro_transparency="opaque"] #[macro_export] macro_rules! reveal { () => {{ let v=$crate::scope::private::Hidden::Value(7); core::mem::size_of_val(&v) + usize::from(v==v) }}; }
pub use reveal;
