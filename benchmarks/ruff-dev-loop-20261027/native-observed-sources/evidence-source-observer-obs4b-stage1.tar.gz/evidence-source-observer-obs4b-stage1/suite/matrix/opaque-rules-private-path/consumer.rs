extern crate dep;
use dep::*;
fn main() {let value:usize={dep::exposed!()};println!("{value}");}
