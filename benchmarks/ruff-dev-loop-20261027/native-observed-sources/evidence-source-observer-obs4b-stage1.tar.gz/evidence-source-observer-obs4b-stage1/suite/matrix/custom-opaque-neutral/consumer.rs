extern crate dep;
use dep::*;
fn main() {let value:usize={dep::neutral!()};println!("{value}");}
