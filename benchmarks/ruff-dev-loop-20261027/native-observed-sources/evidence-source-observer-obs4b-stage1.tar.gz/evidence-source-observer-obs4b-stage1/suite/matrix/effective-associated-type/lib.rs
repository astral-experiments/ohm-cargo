#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]
#![allow(dead_code,internal_features,unused_imports,unused_macros)]
mod scope;
pub use scope::{Public,Api};
