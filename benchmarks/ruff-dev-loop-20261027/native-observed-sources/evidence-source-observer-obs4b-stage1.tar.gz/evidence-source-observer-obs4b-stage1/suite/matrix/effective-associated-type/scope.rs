mod private;
pub trait Api { type Item: Copy + PartialEq; fn value() -> Self::Item; }
pub struct Public;
impl Api for Public { type Item=private::Hidden; fn value()->Self::Item { private::Hidden::Value(7) } }
