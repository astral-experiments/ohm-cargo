/// Example dataclasses.field.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Hidden { Value(u8) }
