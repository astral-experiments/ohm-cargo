#![feature(decl_macro,type_alias_impl_trait,rustc_attrs)]
#![allow(dead_code,internal_features,unused_imports,unused_macros)]
mod scope;
macro_rules! provider { ($n:ident) => { #[macro_export] macro_rules! $n { () => { 7usize }; } }; }
provider!(generated);
