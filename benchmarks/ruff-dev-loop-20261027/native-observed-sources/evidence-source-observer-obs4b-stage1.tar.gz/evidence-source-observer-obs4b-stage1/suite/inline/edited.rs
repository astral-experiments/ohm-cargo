#![no_std]
#![allow(dead_code)]
/// Example private method: dataclasses.field.
fn private_helper() {}
#[inline(always)] #[track_caller]
fn observe() -> u32 { core::panic::Location::caller().column() }
unsafe extern "C" { fn observable_sink(value: u32); }
#[inline(always)]
pub fn captured(value: u32) -> u32 {
    unsafe { observable_sink(value); }
    observe()
}
