#![no_std]
#[inline(always)] pub fn through(value: u32) -> u32 { defs::captured(value) }
