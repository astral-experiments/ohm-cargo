#![no_std]
#[unsafe(no_mangle)] pub extern "C" fn observed_column(value:u32) -> u32 { bridge::through(value) }
