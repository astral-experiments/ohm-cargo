#![allow(dead_code)]
/// Only used in the dataclasses.field example.
fn private_helper() {}
#[macro_export]
macro_rules! declare_method { () => { pub fn generated_name(_value: u32) {} }; }
