pub fn consume() { bridge::generated_name(); }
