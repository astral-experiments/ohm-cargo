"""Check the selected compiler's actual native caller observations and source metadata."""
import hashlib
import json
import re
import sys
from pathlib import Path


base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
read=lambda p:json.loads((base/p).read_bytes())
driver=read('arm.json')['sha256']
suite=base/'suite'
status=read('suite/statuses.json')
assert len(status)==15 and all(v==0 for v in status.values()),status
for name in status:
    if name in ('inline','matrix','diagnostics'):continue
    record=read(f'suite/{name}/result.json')
    assert record['driver']==driver and record['status']==0

rmake=suite/'rdr-public-hash-proc-macro-foreign-bytes'
trace=[json.loads(f.read_bytes()) for f in sorted((rmake/'trace').glob('*.json'))]
clients=[r for r in trace if 'client.rs' in r['argv']]
forms=[]
for r in clients:
    args=r['argv'];mode=next(a.partition('=')[2] for a in args if a.startswith('--cfg='))
    crate=args[args.index('--crate-type')+1]
    prereqs=r['depinfo'].splitlines()[0].split()[1:]
    terms=[mode,crate,'actual.d/ohm-foreign-span-bytes' in prereqs]
    forms.append(terms)
    if mode=='text':assert 'output.rs' in prereqs and r['client_stdout'].strip()=='Some("foreign_marker")'
    assert r['returncode']==0
expected=[['clone_only','bin',False],['local','bin',False],['observer','bin',True],
          ['observer','rlib',True],['observer','bin',True],['text','bin',True],['text','bin',True],['observer','rlib',False]]
assert forms==expected,forms
lo=[int(re.search(r'bytes\((\d+)\.\.',r['client_stdout'])[1]) for r in clients if '--cfg=observer' in r['argv'] and r.get('client_stdout')]
assert len(lo)==2 and lo[1]==lo[0]+1
wa=[json.loads(f.read_bytes()) for f in sorted((suite/'release-api/trace').glob('*.json'))];assert len(wa)==76
assert wa[1]['links']['original-metadata.rmeta']==wa[1]['links']['liblib.rmeta']
for idx in ([19,21,22,24],[26,28,29,31],[50,53,55,57]):
    a,b,c,d=[wa[i]['metadata_hash'][0] for i in idx];assert a==b and c==d and b!=c
    assert [wa[i]['reused_prefix'] for i in idx]==[False,True,False,True]

matrix=read('suite/matrix/result.json');reference=read('encoder-matrix-reference.json');assert len(matrix)==19 and matrix.keys()==reference.keys()
for name,rows in matrix.items():
    for phase,expected in reference[name].items():
        assert {k:v for k,v in rows[phase].items() if k!='public_hash'}=={k:v for k,v in expected.items() if k!='public_hash'}
    for a,b in [('original','moved'),('moved','layout')]:
        assert (rows[a]['public_hash']==rows[b]['public_hash'])==(reference[name][a]['public_hash']==reference[name][b]['public_hash'])
diag,=read('suite/diagnostics/result.json')['arms'].values();assert diag['stale']['errors']==['E0460']
for tag,offset in [('original',151),('rebuilt',153)]:
    item,=[x for x in diag[tag]['producer_spans'] if x['primary']];assert (item['bytes'],item['snippet'],item['col'])==([offset,offset+14],'generated_name',46)
inline,=read('suite/inline/result.json')['arms'].values()
assert inline['stale']['rejected']==inline['stale-moved']['rejected']==['E0460']
assert inline['original']['elf_sha']==inline['rebuilt']['elf_sha']!=inline['rebuilt-moved']['elf_sha']
assert [inline[t]['returns_column'] for t in ('original','rebuilt','rebuilt-moved')]==[5,5,7]

gates=read('cargo/summary.json');assert len(gates)==6 and all(v is True for v in gates.values()),gates
for name in ('build','check','test-no-run','different-width','same-width','ordinary-different-width'):
    rows=read(f'cargo/{name}/results.json');assert list(rows)==['prime','repeat','edit','repeat-edit','edited-cold']
    for phase,r in rows.items():
        assert r['code']==0 and r['errors']==[]
        producer=base/'cargo'/name/phase
        m=(producer/'libleaf.rmeta').read_bytes();source=(producer/'leaf.rs').read_bytes()
        assert m.count(hashlib.md5(source).digest())==1,(name,phase)
        if name in ('different-width','same-width','ordinary-different-width'):
            assert r['value']=='7:Some("foreign_tag")'
        else:assert r['value']=='passed source-text compile-time assertion'

api=read('api/results.json')
for tag,r in api.items():
    assert r['marker']==tag.startswith('external-')
    assert r['source_tracked']==(tag in ('external-text','external-stale-source'))
    if tag in ('external-text','external-stale-source','different-files-join'):
        assert r['value']=={'external-text':'Some("foreign_tag")','external-stale-source':'None','different-files-join':'false'}[tag]
assert len(api)==12
generated=read('generated/results.json')
for phase,r in generated.items():
    assert r['code']==0 and r['value']==generated['cold']['value'] and '|Some("pub fn read_def' in r['value']
    assert all(v['contains_source_md5']==1 for n in ('provider','made') for v in r[n].values()),phase

mf=base/'SHA256SUMS'
if mf.exists():
    for line in mf.read_text().splitlines():
        h,path=line.split('  ',1)
        with (base/path).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h,path
print('Verified all eleven RDR tests, 76 artifact compiles, 19 type cases, 12 span API controls, three normal Cargo commands and the generated proc-macro source map.')
