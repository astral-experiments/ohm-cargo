pub fn value()->u8 {7}
#[macro_export] macro_rules! send {($cb:ident)=>{$cb!(foreign_tag)};}
// private comments
