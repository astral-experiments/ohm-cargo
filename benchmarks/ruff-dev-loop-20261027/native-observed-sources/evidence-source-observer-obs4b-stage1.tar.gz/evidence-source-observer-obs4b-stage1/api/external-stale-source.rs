use probe::text; fn main() { assert_eq!(leaf::value(),3); println!("{}",leaf::send!(text));}
