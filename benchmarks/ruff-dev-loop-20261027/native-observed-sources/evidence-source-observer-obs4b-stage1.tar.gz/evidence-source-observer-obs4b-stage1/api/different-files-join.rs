use probe::join; fn main() { assert_eq!(leaf::value(),3); println!("{}",leaf::mixed!(join, local_tag));}
