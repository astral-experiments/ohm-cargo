use probe::subrange; fn main() { assert_eq!(leaf::value(),3); println!("{}",leaf::send!(subrange));}
