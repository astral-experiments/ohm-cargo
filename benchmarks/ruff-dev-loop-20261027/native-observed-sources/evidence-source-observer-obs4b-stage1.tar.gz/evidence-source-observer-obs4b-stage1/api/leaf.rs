pub fn value() -> u8 { 3 }
#[macro_export] macro_rules! send { ($cb:ident) => { $cb!(foreign_tag "xyz") } }
#[macro_export] macro_rules! mixed { ($cb:ident, $token:tt) => { $cb!(foreign_tag $token) } }
// unrelated private file contents
