use probe::subrange_outside; fn main() { assert_eq!(leaf::value(),3); println!("{}",leaf::send!(subrange_outside));}
