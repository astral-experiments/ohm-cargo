#![feature(proc_macro_span)]
extern crate proc_macro;
use proc_macro::{Literal, TokenStream, TokenTree};
fn string(value:String) -> TokenStream {TokenTree::Literal(Literal::string(&value)).into()}
#[proc_macro] pub fn text(input:TokenStream)->TokenStream {let t=input.into_iter().next().unwrap();string(format!("{:?}",t.span().source_text()))}
#[proc_macro] pub fn range(input:TokenStream)->TokenStream {let t=input.into_iter().next().unwrap();string(t.span().byte_range().len().to_string())}
#[proc_macro] pub fn join(input:TokenStream)->TokenStream {let mut ts=input.into_iter();let a=ts.next().unwrap().span();let b=ts.next().unwrap().span();string(a.join(b).is_some().to_string())}
#[proc_macro] pub fn subrange(input:TokenStream)->TokenStream {let TokenTree::Literal(lit)=input.into_iter().nth(1).unwrap() else {panic!()};string(lit.subspan(0..1).is_some().to_string())}
#[proc_macro] pub fn subrange_outside(input:TokenStream)->TokenStream {let TokenTree::Literal(lit)=input.into_iter().nth(1).unwrap() else {panic!()};string(lit.subspan(400..401).is_some().to_string())}
