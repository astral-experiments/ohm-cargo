actual.d: client.rs

client: client.rs

client.rs:
