use probe::range; fn main() { assert_eq!(leaf::value(),3); println!("{}",leaf::send!(range));}
