use probe::join; fn main() { assert_eq!(leaf::value(),3); println!("{}",join!(local_tag "xyz"));}
