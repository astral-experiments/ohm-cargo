use probe::range; fn main() { assert_eq!(leaf::value(),3); println!("{}",range!(local_tag "xyz"));}
