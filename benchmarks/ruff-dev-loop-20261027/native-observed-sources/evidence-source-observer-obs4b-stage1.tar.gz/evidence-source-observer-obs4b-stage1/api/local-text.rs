use probe::text; fn main() { assert_eq!(leaf::value(),3); println!("{}",text!(local_tag "xyz"));}
