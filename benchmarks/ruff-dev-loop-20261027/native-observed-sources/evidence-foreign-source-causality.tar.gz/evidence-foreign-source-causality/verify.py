"""Verify the native source_text result and the producer's serialized source digest in each arm."""
import hashlib
import json
import sys
from pathlib import Path


root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
digest=lambda b:hashlib.sha256(b).hexdigest()
both={'parent': '265a5d34e49d0e3fd86f05341d9597625cfddd939950f2909b78b26602303fc6',
      'obs3': '6a35f2144ec130945312822792a2e3f622f343369b7018946d1987d80fbf4b12'}
results={}
for arm,driver in both.items():
    assert json.loads((root/'arms'/f'{arm}.json').read_bytes())['sha256']==driver
    d=root/arm;rows=json.loads((d/'results.json').read_bytes());table={};results[arm]=table
    assert len(rows)==6
    old=(d/'prime/leaf.rs').read_bytes();new=(d/'edit/leaf.rs').read_bytes()
    assert len(old)==112 and len(new)==113 and new==old.replace(b'private comment',b'private comments')
    assert [hashlib.md5(t).hexdigest() for t in (old,new)]==['5f544b1d23ac00b7aabcf4c5f2cd5ac5','bf878eacf23540f983e69e948391c768']
    for phase,row in rows.items():
        meta=(d/phase/'libleaf.rmeta').read_bytes();files=(d/phase/'leaf.rs').read_bytes()
        fresh_table=phase in ('leaf-cleared','both-cleared','edited-cold')
        current=new if fresh_table else old
        assert len(meta)==2566 and meta[1930:1946]==hashlib.md5(current).digest()
        assert digest(meta)==('501c21e619c6ff83aa595b865b34256b72456b9bc1a4a7a31b8e941411d8bd44' if fresh_table else
                              'bb343cc4f866259511abbc09f31d72e8b08a6cb3a5b264438b09aa41df49285e')
        assert files==(old if phase=='prime' else new)
        mismatch=arm=='obs3' and phase in ('edit','app-cleared')
        assert row['value']==('7:None' if mismatch else '7:Some("foreign_tag")')
        assert row['code']==0
        if phase in ('prime','edited-cold'):
            assert sorted(row['physical_rustc'])==[['app','full'],['leaf','full'],['probe','full']]
        else:
            assert sorted(row['physical_rustc'])==[['app','full' if arm=='obs3' else 'link-only'],['leaf','full']]
            assert row['artifacts']=={'probe':True,'leaf':False,'app':False}
        removed=[Path(p).name.split('-')[0] for p in row['cleared_incremental']]
        assert sorted(removed)=={'leaf-cleared':['leaf'],'app-cleared':['app'],'both-cleared':['app','leaf']}.get(phase,[])
        table[phase]={'runtime':row['value'],'physical_rustc':row['physical_rustc'],'archived_source_md5':hashlib.md5(current).hexdigest()}
    assert (d/'prime-checkpoint.json').is_file()
for t in ('parent','obs3'):
    j=json.loads((root/f'ordinary-{t}/results.json').read_bytes());assert j['edit']['value']=='7:None' and j['edited-cold']['value']=='7:Some("foreign_tag")'

direct=root/'permanent-obs3';assert json.loads((direct/'result.json').read_bytes())['status']==101
readers=[json.loads(f.read_bytes()) for f in sorted((direct/'trace').glob('*.json'))]
text=[r for r in readers if '--cfg=text' in r['argv']]
assert [r['client_stdout'].strip() for r in text]==['Some("foreign_marker")','None']
assert all(r['depinfo'].splitlines()[0]=='actual.d: client.rs output.rs actual.d/ohm-foreign-span-bytes' for r in text)
manifest=root/'SHA256SUMS'
if manifest.exists():
    for line in manifest.read_text().splitlines():
        h,path=line.split('  ',1);assert digest((root/path).read_bytes())==h,path
print('Verified both native compiler controls, all twelve process rosters, cached source MD5s and the permanent reproducer.')
