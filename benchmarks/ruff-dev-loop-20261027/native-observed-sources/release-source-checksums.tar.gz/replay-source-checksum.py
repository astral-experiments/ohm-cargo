"""Usage: python3 replay-source-checksum.py OLD_RUSTC FIXED_RUSTC NEW_DIRECTORY."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys


old, fixed, out = [Path(p).resolve() for p in sys.argv[1:]]
out.mkdir()
before = b'#[macro_export] macro_rules! deliver { ($cb:ident) => { $cb!(foreign_marker) } }\n// Unrelated note.\n'
after = before.replace(b'note.', b'edit.')
assert len(before) == len(after)

def root_hashes(data):
    root = int.from_bytes(data[8:16], 'little')
    assert data[root] == 0
    pos = root + 1
    length = 0
    shift = 0
    while True:
        n = data[pos]
        pos += 1
        length |= (n & 127) << shift
        if n < 128:
            break
        shift += 7
    pos += length
    assert data[pos] == 0xc1
    return data[pos + 1 : pos + 33].hex()

rows = []
for name, compiler, epoch, src, expected in [
    ('old-original', old, 1, before, before),
    ('old-warm-edit', old, 1, after, before),
    ('fixed-upgrade', fixed, 2, after, after),
    ('fixed-repeat', fixed, 2, after, after),
    ('fixed-warm-restore', fixed, 2, before, before),
    ('fixed-warm-edit', fixed, 2, after, after),
    ('old-return', old, 1, after, after),
]:
    (out / 'subject.rs').write_bytes(src)
    cmd = [str(compiler), '--crate-type=rlib', '--crate-name=subject', '--edition=2024',
           '--emit=metadata=libsubject.rmeta', '-C', 'incremental=incremental', 'subject.rs']
    subprocess.run(cmd, cwd=out, check=True)
    data = (out / 'libsubject.rmeta').read_bytes()
    given = [hashlib.md5(s).digest() for s in (before, after)]
    observed = [h for h in given if h in data]
    assert observed == [hashlib.md5(expected).digest()], (name, observed)
    sessions = [p for p in (out/'incremental').glob('*/*') if p.is_dir() and not p.name.endswith('working')]
    current = max(sessions, key=lambda p:p.stat().st_mtime_ns)
    headers = {p.name:p.read_bytes()[:6].hex() for p in current.glob('*.bin')}
    assert {'dep-graph.bin','query-cache.bin','work-products.bin'} <= headers.keys(), headers
    assert set(headers.values()) == {(b'RSIC'+epoch.to_bytes(2,'little')).hex()}, headers
    rows.append(dict(case=name, api_and_private=root_hashes(data), input_md5=hashlib.md5(src).hexdigest(),
                     stored_md5=observed[0].hex(), metadata_sha256=hashlib.sha256(data).hexdigest(),
                     incremental_headers=headers, command=cmd))
assert len({r['api_and_private'] for r in rows}) == 1
assert len({rows[i]['metadata_sha256'] for i in (0, 1, 4)}) == 1
assert len({rows[i]['metadata_sha256'] for i in (2, 3, 5, 6)}) == 1
print(json.dumps(rows, indent=2))
