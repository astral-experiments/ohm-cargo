"""Read the actual emitted physical source table after both directions of the real Ruff edit."""
from pathlib import Path
import hashlib, json, sys
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent))
from decode import decode
data=(here/'parser.py').read_text().split("a=run('original'",1)[0].replace("root.mkdir();","root.mkdir(exist_ok=True);").replace("home.mkdir();","home.mkdir(exist_ok=True);").replace("out.mkdir();","out.mkdir(exist_ok=True);").replace("(home/'registry').symlink_to(reg)","assert (home/'registry').resolve()==reg")
namespace={'__file__':str(here/'parser.py')}
exec(compile(data,str(here/'parser.py'),'exec'),namespace)
root,src,fixture,out,rerun=(namespace[k] for k in ('root','src','fixture','out','run'))
path=Path('crates/ruff_python_parser/src/parser/expression.rs')
assert sorted(f.relative_to(fixture) for f in fixture.rglob('*') if f.is_file())==[path]
inputs={'original':(src/path).read_bytes(),'modified':(fixture/path).read_bytes()}
stored={}
def capture(label,kind):
    f,=root.rglob('libruff_python_parser*.rmeta')
    raw=f.read_bytes()
    decoded=decode(f,'parser/expression.rs')
    file, = decoded['files']
    md5=hashlib.md5(inputs[kind]).hexdigest()
    assert file[-1]==md5+'0'*32,(file,md5)
    stored[label]={'source_input':kind,'source_sha256':hashlib.sha256(inputs[kind]).hexdigest(),'source_table_ordinal':file[0],'encoded_source':file[1],'encoded_len':file[2],'source_md5':md5,'encoded_src_hash':file[-1],'rmeta_sha256':hashlib.sha256(raw).hexdigest(),'producer_public_private':decoded['private_public_raw'],'encoded_files':len(decoded['source_table'])}
    assert len(inputs[kind])==file[2]
    (here/'parser-source-checksums.json').write_text(json.dumps(stored,indent=2)+'\n')
capture('warm-edit','modified')
restored=rerun('checksum-restore',False)
assert restored['dirty']==['ruff_python_parser'] and restored['units']==90
capture('warm-restore','original')
repeat=rerun('checksum-fresh',False)
assert not repeat['dirty'] and repeat['units']==90
capture('fresh-restored','original')
assert stored['warm-edit']['source_md5']!=stored['warm-restore']['source_md5']
assert stored['warm-restore']==stored['fresh-restored']
assert len({v['producer_public_private'][32:] for v in stored.values()})==1
print([(k,v['source_md5']) for k,v in stored.items()],flush=True)
