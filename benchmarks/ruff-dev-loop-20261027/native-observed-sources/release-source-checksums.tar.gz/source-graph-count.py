"""Inspect checksum edges and their order in an RSIC v2 graph without recompiling anything."""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re
import struct


def leb(data, pos):
    value = shift = 0
    while True:
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, pos
        shift += 7


def inspect(graph, queries):
    raw = graph.read_bytes()
    assert raw.startswith(b'RSIC\2\0') and raw.endswith(b'rust-end-file')
    data = memoryview(raw)[:-len(b'rust-end-file')]
    node_max, nodes, edges = struct.unpack_from('<QQQ', data, len(data) - 24)
    source = queries.read_text()
    kinds = re.findall(r'^    non_query (\w+)\s*$', source, re.M)
    kinds += re.findall(r'^    query (\w+)\s*\(', source, re.M)
    assert len(kinds) == len(set(kinds))
    kind_bits = (len(kinds) - 1).bit_length()
    low = (1 << kind_bits) - 1
    query_kind = kinds.index('metadata_source_file_hash')
    meta_kind = kinds.index('Metadata')
    expected = collections.Counter()
    stored = []
    found = set()
    keys = set()
    prefix = 7 + int(data[6]) + 8
    pos = prefix
    edge_total = 0
    for _ in range(nodes):
        head, index = struct.unpack_from('<HI', data, pos)
        kind = head & low
        assert 0 < kind < len(kinds) and index < node_max, (index, kind)
        width = 1+((head >> kind_bits) & 3)
        length = (head >> (kind_bits + 2)) - 1
        key = bytes(data[pos+6:pos+22]) if kind == query_kind else None
        pos += 38
        if length < 0:
            length, pos = leb(data, pos)
        end = pos + width*length
        expected[kind] += 1
        if kind == query_kind:
            assert length == 0 and len(key) == 16 and key not in keys and index not in found
            keys.add(key)
            found.add(index)
        elif kind == meta_kind:
            assert not stored
            stored = [int.from_bytes(data[p:p+width], 'little') for p in range(pos, end, width)]
        edge_total += length
        pos = end
    assert edge_total == edges
    for kind in range(len(kinds)):
        count, pos = leb(data, pos)
        assert count == expected[kind], (kinds[kind], count, expected[kind])
    _, pos = leb(data, pos)
    assert pos <= len(data)-24 and stored and found and set(stored[-len(found):]) == found
    assert sum(e in found for e in stored) == len(found)
    # The suffix query nodes have no reads of their own and are referenced once each.
    return dict(file=str(graph), query_source_sha256=hashlib.sha256(queries.read_bytes()).hexdigest(),
                graph_sha256=hashlib.sha256(raw).hexdigest(), graph_bytes=len(raw),
                nodes=nodes, edges=edges, metadata_edges=len(stored),
                checksum_edges=len(found), first_checksum_edge_offset=len(stored) - len(found),
                checksums_are_unique_trailing_edges=True, checksum_query_children=0)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('queries', type=Path)
    parser.add_argument('graph', type=Path)
    args = parser.parse_args()
    print(json.dumps(inspect(args.graph, args.queries), indent=2))
