# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/warm/target/debug/build/workspaces/7d0bbb3086052012/v2-c682099261d66931/hold_direct/4deaa1cc93619429/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/warm/target/debug/build/workspaces/7d0bbb3086052012/v2-c682099261d66931/hold_direct/4deaa1cc93619429/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/warm/target/debug/build/workspaces/7d0bbb3086052012/v2-c682099261d66931/hold_direct/4deaa1cc93619429/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/warm/target/debug/build/workspaces/7d0bbb3086052012/v2-c682099261d66931/hold_direct/4deaa1cc93619429/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/foreign.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/warm/target/debug/build/workspaces/7d0bbb3086052012/v2-c682099261d66931/hold_direct/4deaa1cc93619429/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=c1625fb872b71d50c4e3262d52030d3961ca6519d5d51a57821ce88a78cbc817 file_len:273 hold_direct/src/main.rs
# checksum:blake3=8006d69bcb8296e7afb07ed9f8e046acb92da5b9e5d8547822c1979cc4f676db file_len:105 /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/first-preserved/foreign.rs
