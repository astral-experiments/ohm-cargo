# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/empty/target/debug/build/workspaces/d82af77e9cc4788b/v2-0907cbfd0a842c6f/hold_direct/12ef6477623546a2/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/empty/target/debug/build/workspaces/d82af77e9cc4788b/v2-0907cbfd0a842c6f/hold_direct/12ef6477623546a2/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/empty/target/debug/build/workspaces/d82af77e9cc4788b/v2-0907cbfd0a842c6f/hold_direct/12ef6477623546a2/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/empty/target/debug/build/workspaces/d82af77e9cc4788b/v2-0907cbfd0a842c6f/hold_direct/12ef6477623546a2/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/foreign.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/empty/target/debug/build/workspaces/d82af77e9cc4788b/v2-0907cbfd0a842c6f/hold_direct/12ef6477623546a2/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=d11efcb4f30bae2b1485241be6853d06492aa6cf1ccc6fba21e1e4d8dabf3486 file_len:320 hold_direct/src/main.rs
# checksum:blake3=8006d69bcb8296e7afb07ed9f8e046acb92da5b9e5d8547822c1979cc4f676db file_len:105 /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-preserved/foreign.rs
