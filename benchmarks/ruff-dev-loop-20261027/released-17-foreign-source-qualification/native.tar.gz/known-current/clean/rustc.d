# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/empty/target/debug/build/workspaces/8da2e31ae5b27b29/v2-23fbd78aa3f06997/hold_direct/e26a80b729c1acc8/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/empty/target/debug/build/workspaces/8da2e31ae5b27b29/v2-23fbd78aa3f06997/hold_direct/e26a80b729c1acc8/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/empty/target/debug/build/workspaces/8da2e31ae5b27b29/v2-23fbd78aa3f06997/hold_direct/e26a80b729c1acc8/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/foreign.rs /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/empty/target/debug/build/workspaces/8da2e31ae5b27b29/v2-23fbd78aa3f06997/hold_direct/e26a80b729c1acc8/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/foreign.rs:
/mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/empty/target/debug/build/workspaces/8da2e31ae5b27b29/v2-23fbd78aa3f06997/hold_direct/e26a80b729c1acc8/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=d11efcb4f30bae2b1485241be6853d06492aa6cf1ccc6fba21e1e4d8dabf3486 file_len:320 hold_direct/src/main.rs
# checksum:blake3=8006d69bcb8296e7afb07ed9f8e046acb92da5b9e5d8547822c1979cc4f676db file_len:105 /mnt/devbox-scratch/dev-user/ohm-official-17-foreign-source-audit-20261028/known-current/foreign.rs
