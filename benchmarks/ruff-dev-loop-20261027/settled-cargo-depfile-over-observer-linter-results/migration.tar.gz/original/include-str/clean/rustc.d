# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/empty/target/debug/build/workspaces/991e0ea8b5507205/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/empty/target/debug/build/workspaces/991e0ea8b5507205/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/empty/target/debug/build/workspaces/991e0ea8b5507205/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/empty/target/debug/build/workspaces/991e0ea8b5507205/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/empty/target/debug/build/workspaces/991e0ea8b5507205/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=abf5f2f168512f837bb8e5078757640bd72cba4bb246c63f3dd6259d5fac7c3f file_len:459 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt
