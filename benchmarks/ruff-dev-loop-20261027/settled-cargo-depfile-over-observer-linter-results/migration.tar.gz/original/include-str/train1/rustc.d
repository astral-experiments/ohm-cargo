# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/warm/target/debug/build/workspaces/e21fc5c2a34a5ec2/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/warm/target/debug/build/workspaces/e21fc5c2a34a5ec2/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/warm/target/debug/build/workspaces/e21fc5c2a34a5ec2/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/warm/target/debug/build/workspaces/e21fc5c2a34a5ec2/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/warm/target/debug/build/workspaces/e21fc5c2a34a5ec2/v2-3bb160d46e7d04a1/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=dc1dc09e0fe0098d7bdbd590f0d694283df8a1fd6a20e3185c5d284a4c8e543b file_len:436 hold_direct/src/main.rs
# checksum:blake3=2bc7ef5f44f1bad1562c1d40d45195f5102d690a302cadab32ff8fd8ebf420df file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-str-active/private-input.txt
