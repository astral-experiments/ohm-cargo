# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/empty/target/debug/build/workspaces/f6fa1a0959030c51/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/empty/target/debug/build/workspaces/f6fa1a0959030c51/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/empty/target/debug/build/workspaces/f6fa1a0959030c51/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/empty/target/debug/build/workspaces/f6fa1a0959030c51/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/empty/target/debug/build/workspaces/f6fa1a0959030c51/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=371067b4213e635e1a3afbe962975a5b0a6960423f675793025c745a6d81efce file_len:467 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt
