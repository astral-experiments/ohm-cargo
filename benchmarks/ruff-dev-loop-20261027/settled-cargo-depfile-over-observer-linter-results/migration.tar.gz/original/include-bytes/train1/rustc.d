# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/warm/target/debug/build/workspaces/89536b2538351854/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/warm/target/debug/build/workspaces/89536b2538351854/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/warm/target/debug/build/workspaces/89536b2538351854/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/warm/target/debug/build/workspaces/89536b2538351854/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/warm/target/debug/build/workspaces/89536b2538351854/v2-d8cf73f60d39a284/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=33744e40d59743097b2996bf054dd7b138526ebb54e1af88e4faa316937d7f54 file_len:444 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/include-bytes-active/private-input.txt
