# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/warm/target/debug/build/workspaces/e439b8de3e726b94/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/warm/target/debug/build/workspaces/e439b8de3e726b94/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/warm/target/debug/build/workspaces/e439b8de3e726b94/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/warm/target/debug/build/workspaces/e439b8de3e726b94/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/warm/target/debug/build/workspaces/e439b8de3e726b94/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=e23a3eb45880a6f83eb9e9a6690dca086b052d5ae0ae6e34307f30d2168cfed2 file_len:250 hold_direct/src/main.rs
# checksum:blake3=2bc7ef5f44f1bad1562c1d40d45195f5102d690a302cadab32ff8fd8ebf420df file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt
