# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/empty/target/debug/build/workspaces/4ada82b6be100821/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/empty/target/debug/build/workspaces/4ada82b6be100821/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/empty/target/debug/build/workspaces/4ada82b6be100821/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/empty/target/debug/build/workspaces/4ada82b6be100821/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt:
/home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/empty/target/debug/build/workspaces/4ada82b6be100821/v2-5aa8e94b37f4ac15/hold_direct/774e5025bf6a65dd/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=2850b30486f9b9604edb81dfc9b9df017f6f9fe84cdc87eba2fc4298dc6ddf83 file_len:273 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /home/dev-user/.cache/ohm-output-paths-over261-20261028/adversarial/tracked-file-active/private-input.txt
