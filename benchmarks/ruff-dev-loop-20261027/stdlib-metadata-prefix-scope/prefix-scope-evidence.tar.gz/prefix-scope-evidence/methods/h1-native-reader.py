from pathlib import Path
import runpy,sys,shutil,json,subprocess as sp
P=Path('/dev/shm/ohm-rustc-prefix-real-20261027');v=runpy.run_path(str(P/'replay.py'),run_name='replay');globals().update({k:y for k,y in v.items()if not k.startswith('__')});src=S/'bin-client.rs';src.write_text('fn main() {use ruff_python_stdlib::typing::is_mutable_return_type as mutable; println!("{:?} {} {}",std::hint::black_box(ty_ide::CompletionKind::Function),mutable(std::hint::black_box(&["collections", "ChainMap"])),mutable(std::hint::black_box(&["weakref", "WeakSet"])));}\n');exts={}
for n in ['ty_ide','ruff_python_stdlib']:
 oldout=Path(data[n]['arg'][data[n]['arg'].index('--out-dir')+1]);exts[n]=oldout/next(out(n).glob('*.rlib')).name
args0=data['ty_ide']['arg'];ld=[]
for j,x in enumerate(args0):
 if x=='-L':ld+=['-L',args0[j+1]]
prog=S/'bin-client';report={}
for a in ['retained','forced']:
 log=S/'log'/('reader-'+a);log.mkdir();cmd=['taskset','-c','26-27','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(S),str(S)];
 for t in ['target','shared','registry-home']:cmd+=['--ro-bind',str(H/'pair'/t),str(R/t)]
 for n in allnames:cmd+=['--ro-bind',str(out(n)),data[n]['arg'][data[n]['arg'].index('--out-dir')+1]]
 if a=='retained':cmd+=['--ro-bind',str(S/'ide-retained.rlib'),str(exts['ty_ide'])]
 cmd+=['--ro-bind',str(D),str(R/'sysroot/lib'/son),'--chdir',str(W),'--',str(Path.home()/'.cargo/bin/rustc'),'+ohm','--edition=2024','--crate-name=actual_ide_reader','--crate-type=bin',str(src),'--emit=link','-Copt-level=1','-Cdebuginfo=line-tables-only','-o',str(prog),*sum((['--extern',n+'='+str(f)]for n,f in exts.items()),[]),*ld];env=dict(os.environ,RUSTUP_HOME=str(R/'rustup'),RUSTUP_TOOLCHAIN='ohm',LD_LIBRARY_PATH=str(R/'sysroot/lib'));r=sp.run(cmd,env=env,capture_output=True,timeout=90);(log/'stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace')[-2200:];val=sp.check_output([prog],text=True).strip();report[a]={'runtime':val,'sha256':sha(prog),'size':prog.stat().st_size};assert val=='Function false false',val
assert report['retained']==report['forced'];(S/'reader-matched.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
