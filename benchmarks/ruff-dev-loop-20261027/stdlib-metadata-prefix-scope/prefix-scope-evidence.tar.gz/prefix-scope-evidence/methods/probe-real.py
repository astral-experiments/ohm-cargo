from pathlib import Path
import json,subprocess as sp,hashlib,sys,collections,re,struct
D=Path(__file__).resolve().parent;program=D/'probe-graph';sp.run(['gcc','-O2','-Wall','-Werror',D/'probe-graph.c','-o',program],check=True)
R=Path('/home/dev-user/code/oss/ohm-rust-private-native-20261027')
root=Path('/mnt/devbox-scratch/dev-user/ohm-highest-whole-20261026/test/target/debug/incremental')
def run(root,src,cases):
 defmeta=next(root.glob('*/ruff_python_stdlib-*/*/metadata.rmeta'))
 ns={'__file__':str(D/'read-mir.py'),'__name__':'__parser__'}
 s=(D/'read-mir.py').read_text().replace('return {"name":name,"private_public_raw"', 'return {"all":{f"{v:016x}":defname(i)for i,v in enumerate(ids) if v},"stable":int.from_bytes(crate,"little"),"name":name,"private_public_raw"')
 exec(compile(s,'<checked-reader>','exec'),ns)
 packet=ns['decode'](defmeta,'typing.rs');values=packet['all'];cs=packet['stable']
 names=re.findall(r'^    non_query (\w+)',src,re.M)+re.findall(r'^    query (\w+)',src,re.M)
 results={}
 for case in cases:
  m=next(root.glob('*/'+case+'-*/*/metadata.rmeta'));g=m.with_name('dep-graph.bin');cmd=sp.run([program,g,f'{cs:x}'],capture_output=True,text=True,check=True)
  data=m.read_bytes();found={}
  for k,name in values.items():
   raw=int(k,16).to_bytes(8,'little')
   if raw in data:found[name]=data.count(raw)
  observed=collections.defaultdict(list);encoded=collections.defaultdict(list);extras=[];t=None
  for row in map(str.split,cmd.stdout.splitlines()):
   if row[0]=='totals':t=list(map(int,row[1:]));continue
   how,kind,k=row;n=names[int(kind)];item=values.get(k)
   if item is None:
    if k!=f'{cs:016x}':extras.append([n,k])
    item='<crate>'
   coll=observed if how=='seen'else encoded;coll[item].append(n)
  assert t;results[case]={'metadata_size':len(data),'metadata':hashlib.sha256(data).hexdigest(),'depgraph_size':g.stat().st_size,'depgraph_count_directmetadeps_totedges':t,'metadata_direct_for_stdlib':dict(encoded),'all_queries_for_stdlib':dict(observed),'unresolved':extras,'raw_exact_encoded_defpathhash_in_rmeta':found}
  print(case,'direct defs',[(key,[q for q in v if q=='extern_def_public_hash'])for key,v in encoded.items()if key!='<crate>'],'global fields',encoded['<crate>'],'all distinct items',len(observed),'wire',found,flush=True)
 return {'stdlib_stablecrateid':f'{cs:016x}','stdlib_sha':hashlib.sha256(defmeta.read_bytes()).hexdigest(),'explicit_source_paths':len(values),'consumers':results}
x=run(D/'incremental-graph-bridges/target/debug/incremental',(R/'compiler/rustc_middle/src/queries.rs').read_text(),['sibling','uses_moved','forwards'])
(D/'probe-calibration.json').write_text(json.dumps(x,indent=2)+'\n')
assert any(k.endswith('simple_magic_return_type')and 'extern_def_public_hash'in qs for k,qs in x['consumers']['forwards']['metadata_direct_for_stdlib'].items())
src=sp.check_output(['git','-C',R,'show','f1a7cf9d2:compiler/rustc_middle/src/queries.rs'],text=True)
x=run(root,src,sys.argv[1:] or 'ruff_workspace ty_ide ty_module_resolver ruff_python_semantic ruff_linter ty_python_semantic'.split())
(D/'archived-real-query-observers.json').write_text(json.dumps(x,indent=2)+'\n')
