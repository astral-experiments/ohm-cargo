from pathlib import Path
import itertools,math,statistics,random,sys,runpy
P=Path('/dev/shm/ohm-rustc-prefix-real-20261027')
sys.path.insert(0,str(P))
from link_record import check_ar,compact
v=runpy.run_path(str(P/'replay.py'),run_name='stage');globals().update({k:y for k,y in v.items()if not k.startswith('__')})
k=P/'seed-ty_ide'; cfg=json.loads((P/'ide-cohort-plan.json').read_bytes());assert sha(P/'ide-cohort-plan.json')=='cb2459450f5a7e3cf941bfff7de1955cd8d91e0a47aa1611a6d185d30bcc1ca8';u='ty_ide'; ordered=[]
for i,order in enumerate(cfg['orders']):
 bb={};members={};saved=[]
 for arm in order:
  reset(u,k,arm=='F');row=compile(u,f'cohort-{i:02}-{arm}','edited');ar=check_ar(next(out(u).glob('*.rlib')));assert row['rebind']==int(arm=='R');bb[arm]=row;members[arm]=ar;saved.append(dict(row,archive=compact(ar)))
 assert bb['R']['rmeta_sha256']==bb['F']['rmeta_sha256']
 x,y=members['R'],members['F'];assert x['members']==y['members'] and set(x['normalized_order'])==set(y['normalized_order']) and x['native_libraries']==y['native_libraries'];ordered.append({'order':order,'matched_raw_metadata':True,'matched_native_member_contents':True,'native_names_order_equal':x['normalized_order']==y['normalized_order'],'rows':saved});(S/'scope-cohort.partial.json').write_text(json.dumps(ordered,indent=2))
def logs(z):return [math.log(y['elapsed_ns'])for y in z['rows']]
d=[(logs(z)[0]-logs(z)[1])*(1 if z['order']=='FR' else -1)for z in ordered];delta=[logs(z)[0]-logs(z)[1]for z in ordered];stat=statistics.mean(d);perms=[sum(x*(1 if j in pos else -1)for j,x in enumerate(delta))/len(delta)for pos in itertools.combinations(range(len(delta)),len(delta)//2)];p=sum(abs(y)>=abs(stat)-1.e-12 for y in perms)/len(perms);R=random.Random(cfg['bootstrap_seed']);boot=sorted(1-math.exp(-statistics.mean(R.choices(d,k=len(d))))for _ in range(cfg['bootstrap_reps']));measure={'reduction_percent':100*(1-math.exp(-stat)),'paired_percentile_ci95_percent':[100*boot[int(len(boot)*k)]for k in (.025,.975)],'order_randomization_p':p,'assignments':len(perms),'retained_faster_pairs':sum(x>0 for x in d),'median_seconds':{arm:statistics.median([next(y['elapsed_ns']/1e9 for y in z['rows']if y['tag'].endswith(arm)) for z in ordered])for arm in 'RF'},'all_metadata_equal':True,'all_objects_equal':True,'all_normalized_name_order_equal':all(z['native_names_order_equal']for z in ordered)};report={'plan_sha256':sha(P/'ide-cohort-plan.json'),'observations':ordered,'analysis':measure};(S/'scope-cohort.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(measure,indent=2),flush=True)
