from pathlib import Path
import hashlib,struct,json
P=Path('/dev/shm/ohm-rustc-prefix-real-20261027')
def section(b,name):
 off=struct.unpack_from('<Q',b,40)[0];size,n,start=struct.unpack_from('<3H',b,58);sections=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)for i in range(n)];s=sections[start];names=b[s[4]:s[4]+s[5]]
 for s in sections:
  if names[s[0]:names.index(0,s[0])]==name:return b[s[4]:s[4]+s[5]]
 raise KeyError(name)
def check_ar(path):
 names={};st=b''
 with path.open('rb')as f:
  assert f.read(8)==b'!<arch>\n'
  while h:=f.read(60):
   n=int(h[48:58]);b=f.read(n);lab=h[:16].decode().strip()
   if n&1:f.read(1)
   if lab=='//':st=b;continue
   if lab in ('/','/SYM64/'):continue
   if lab[0]=='/':off=int(lab[1:]);lab=st[off:st.index(b'/\n',off)].decode()
   lab=lab.rstrip('/');assert lab not in names;names[lab]=hashlib.sha256(b).hexdigest()
   if lab=='lib.rmeta-link':record=section(b,b'.rmeta-link')
 idx=0
 def leb():
  nonlocal idx
  v=0
  for k in range(11):
   z=record[idx];idx+=1;v|=(z&127)<<(k*7)
   if not z&128:return v
  raise ValueError('bad length')
 def string():
  nonlocal idx
  n=leb();d=record[idx:idx+n].decode();idx+=n;assert record[idx]==0xc1;idx+=1;return d
 objs=[string()for _ in range(leb())];libs=[]
 for _ in range(leb()):
  tag=leb();assert tag in (0,1);libs.append(string()if tag else None)
 assert record[idx:]==b'rust-end-file',record[idx:][:30]
 assert len(objs)==len(set(objs)) and all(x in names for x in objs)
 def canon(x):
  parts=x.split('.')
  if x.endswith('.rcgu.o'):
   assert 5<=len(parts[-3])<=9 and parts[-3].isalnum(),x
   return '.'.join(parts[:-3]+parts[-2:])
  return x
 assert len({canon(n)for n in names})==len(names)
 return {'archive_sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'archive_members':len(names),'objects':len(objs),'native_libraries':libs,'raw_order':objs,'normalized_order':[canon(x)for x in objs],'members':{canon(x):v for x,v in names.items()if x!='lib.rmeta-link'}}
def compact(z):
 return {'archive_sha256':z['archive_sha256'],'members':z['archive_members'],'object_count':z['objects'],'native_libraries':z['native_libraries'],'normalized_objects_sha256':hashlib.sha256(json.dumps(z['members'],sort_keys=True).encode()).hexdigest(),'ordered_normalized_filenames_sha256':hashlib.sha256('\n'.join(z['normalized_order']).encode()).hexdigest(),'ordered_raw_filenames_sha256':hashlib.sha256('\n'.join(z['raw_order']).encode()).hexdigest()}
if __name__=='__main__':
 import shutil
 t=P/'state';a=t/'ide-retained.rlib';b=t/'ide-forced.rlib';live=next((t/'out/ty_ide').glob('*.rlib'))
 if not b.exists():shutil.copyfile(live,b)
 a,b=map(check_ar,(a,b));x={'arms':list(map(compact,(a,b))),'same_173_member_set':a['members'].keys()==b['members'].keys(),'all_ordinary_contents_match':a['members']==b['members'],'ordered_filenames_after_normalizing_session_suffix':a['normalized_order']==b['normalized_order'],'raw_object_names_changed':len(set(a['raw_order'])-set(b['raw_order'])),'native_filenames_equal':a['native_libraries']==b['native_libraries']};print(json.dumps(x,indent=2))
