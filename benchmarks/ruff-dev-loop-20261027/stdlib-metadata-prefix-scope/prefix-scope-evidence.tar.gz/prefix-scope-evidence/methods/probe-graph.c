#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
static uint64_t u64(const unsigned char*p){uint64_t x;memcpy(&x,p,8);return x;}
static uint32_t u32(const unsigned char*p){uint32_t x;memcpy(&x,p,4);return x;}
static uint16_t u16(const unsigned char*p){uint16_t x;memcpy(&x,p,2);return x;}
static unsigned leb(const unsigned char **p){unsigned v=0,b;for(unsigned i=0;i<=28;i+=7){b=*(*p)++;v|=(b&127)<<i;if(b<128)return v;}abort();}
int main(int argc,char**argv){
 assert(argc==3);int fd=open(argv[1],O_RDONLY);assert(fd>=0);uint64_t id;assert(sscanf(argv[2],"%lx",&id)==1);
 struct stat st;assert(fstat(fd,&st)==0);unsigned char *b=mmap(0,st.st_size,PROT_READ,MAP_PRIVATE,fd,0);assert(b!=MAP_FAILED);
 const unsigned char *e=b+st.st_size,*f=e-61;assert(!memcmp(e-13,"rust-end-file",13));
 uint64_t count=u64(f+32),max=u64(f+24),total=u64(f+40),acc=0;assert(count<=max&&max<20000000);
 const unsigned char **nodes=calloc(max,sizeof(*nodes)),*md=0,*p=b+7+b[6]+8;
 for(size_t i=0;i<count;i++){
  assert(p+38<e);unsigned h=u16(p),key=h&511,width=1+((h>>9)&3),idx=u32(p+2);assert(idx<max&&nodes[idx]==0);nodes[idx]=p;
  if(key==7){assert(!md&&!u64(p+6)&&!u64(p+14));md=p;}
  if(u64(p+6)==id){printf("seen %u %016lx\n",key,u64(p+14));}
  p+=38;unsigned n=h>>11;n=n?n-1:leb(&p);acc+=n;p+=n*width;
 }
 assert(acc==total&&md);
 unsigned h=u16(md),width=1+((h>>9)&3),n=h>>11;p=md+38;n=n?n-1:leb(&p);
 printf("totals %lu %u %lu\n",count,n,total);
 for(unsigned i=0;i<n;i++,p+=width){
  unsigned ix=0;memcpy(&ix,p,width);assert(ix<max&&nodes[ix]);
  const unsigned char *q=nodes[ix];if(u64(q+6)==id)printf("metadata %u %016lx\n",u16(q)&511,u64(q+14));
 }
 free(nodes);munmap(b,st.st_size);close(fd);
}
