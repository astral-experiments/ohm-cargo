"""Run the ordinary Cargo frontend, then force a full encoder from an identical private checkpoint."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys,time
D=Path(__file__).resolve().parent;name=sys.argv[1];driver=Path(sys.argv[2]);P=(D/name);P.mkdir(exist_ok=False);W=P/'ws';W.mkdir();stage=Path('/mnt/devbox-scratch/dev-user/ohm-nonleaf-perflint-20261026/stage-score');sdk=stage/'sysroot';son='librustc_driver-15d35e5526bb94f8.so';cargo=Path.home()/'.cache/ohm-ruff-whole-skips-20261027/position-cargo-v3/cargo-observer';sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();z=P/'phase-inputs';z.mkdir(); home=P/'home';home.mkdir(); (P/'target').mkdir();(P/'build').mkdir();c=Path.home()/'.cargo/bin/cargo';
state='pub fn tool(x:u8)->u8{x+1}\n'; end='pub fn shifted(x: u8)->u8{x + 1}\n';variants={'original':'// original doc\n'+state+'\n\n'+end,'moved':'// original doc\n'+state+'\n'+end,'deprecated':'// original doc\n#[deprecated(note="new external warning")]\n'+state+'\n\n'+end}
for n,s in variants.items():(z/n).write_text(s)
variants['body-shift-layout']=variants['moved'].replace('x+1','x+2')+'pub struct Shape(pub u16);\n';variants={k:(v if 'pub struct Shape' in v else v+'pub struct Shape(pub u8);\n') for k,v in variants.items()};
api='pub const EXPORTED: u8 = 1; pub static GLOBAL: u8=1; #[inline(always)] pub fn inlined(x:u8)->u8{x+1}\n'; variants={k:v+(api.replace('= 1','= 2').replace('=1','=3').replace('x+1','x+4') if k=='body-shift-layout' else api)for k,v in variants.items()};
sources={'upstream':variants['original'],'exported_body':'pub static PTR: &u8 = &upstream::GLOBAL; pub const VALUE:u8 = upstream::EXPORTED; #[inline(always)] pub fn observe(x:u8)->u8 { upstream::inlined(x)+*PTR+VALUE }\n','layout':'pub fn width() -> usize {std::mem::size_of::<upstream::Shape>()} pub struct Contains(pub upstream::Shape);\n','isolated':'pub fn value(x:u8)->u8 {upstream::tool(x)}\n','forward':'pub use upstream::shifted; pub fn value(x:u8)->u8 {shifted(x)}\n','denied':'#![deny(deprecated)]\npub fn value(x:u8)->u8{upstream::tool(x)}\n'};members=list(sources);(W/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers='+json.dumps(members)+'\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\nlto="off"\n');
for n,s in sources.items():
 d=W/n;(d/'src').mkdir(parents=True);(d/'src/lib.rs').write_text(s);(d/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n'+('[dependencies]\nupstream={path="../upstream"}\n' if n!='upstream' else ''))
env=dict(os.environ,RUSTUP_HOME=str(stage/'rustup'),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(home),CARGO_TARGET_DIR=str(P/'target'),CARGO_BUILD_BUILD_DIR=str(P/'build'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='1',RUSTC_LOG='ohm_metadata_reuse=info');[env.pop(k,None)for k in ('RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')]; output={};
P.joinpath('client.rs').write_text('extern crate isolated; extern crate forward; extern crate layout; extern crate exported_body; fn main(){println!("{} {} {} {}",isolated::value(7),forward::value(7),layout::width(),exported_body::observe(7))}');
(P/'subjects.json').write_text(json.dumps({'cargo':sha(cargo),'rustc':sha(sdk/'bin/rustc'),'driver':sha(driver)},indent=2));
def run(label,units,success=True):
 out=P/label;out.mkdir();args=['taskset','-c','26-27','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(P),str(P),'--ro-bind',str(driver),str(sdk/'lib'/son),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--chdir',str(W),'--',str(c),'+ohm','build','--offline','--message-format=json',*sum((['-p',u]for u in units),[])];r=sp.run(args,env=env,capture_output=True,timeout=60);(out/'stderr').write_bytes(r.stderr);(out/'cargo.jsonl').write_bytes(r.stdout);assert (r.returncode==0)==success,(label,r.returncode,r.stderr[-1000:],r.stdout[-1300:]);rv={'status':r.returncode,'reuse':r.stderr.count(b'rebound unused dependencies'), 'prefix':r.stderr.count(b'with a freshly encoded source map'),'warnings':[],'artifacts':{},'dirty':[]};
 for line in r.stdout.splitlines():
  try:m=json.loads(line)
  except ValueError:continue
  n=m.get('target',{}).get('name');
  if m.get('reason')=='compiler-message' and m['message'].get('code'):rv['warnings'].append([n,m['message']['level'],m['message']['message']]);
  if m.get('reason')!='compiler-artifact' or n not in members:continue
  if not m['fresh']:rv['dirty'].append(n)
  rv['artifacts'][n]={}
  for f in map(Path,m['filenames']):
   if f.suffix=='.rmeta':shutil.copy2(f,out/(n+'.rmeta'));rv['artifacts'][n]['rmeta']=sha(f)
   if f.suffix=='.rlib':
    rv['artifacts'][n]['rlib']=sha(f);mem=sp.check_output(['ar','t',f],text=True).splitlines();rv['artifacts'][n]['objs']={m:hashlib.sha256(sp.check_output(['ar','p',f,m])).hexdigest() for m in mem if m.endswith('.o')};
 output[label]=rv;(P/'results.json').write_text(json.dumps(output,indent=2));print(label,rv['status'],rv['reuse'],rv['prefix'],rv['dirty'],rv['warnings'],flush=True);return rv

def save():
 for n in ('target','build'):shutil.copytree(P/n,P/('seed-'+n),symlinks=True)
def reset(phase):
 for n in ('target','build'):
  shutil.rmtree(P/n); shutil.copytree(P/('seed-'+n),P/n,symlinks=True)
 (W/'upstream/src/lib.rs').write_text(variants[phase])
def strip(n):
 cand=list((P/'target').glob('debug/incremental/*/'+n+'-*/*/metadata-prefix-v3.*'));assert cand,(n,list((P/'target').rglob('metadata-prefix*')));[k.unlink() for k in cand]
def app(phase,arm):
 out=P/(phase+'-'+arm+'-app');out.mkdir();files={};search=set()
 for n in ('isolated','forward','layout','exported_body','upstream'):
  for m in map(json.loads,(P/(phase+'-'+arm+'-'+n)/'cargo.jsonl').read_text().splitlines()):
   if m.get('reason')!='compiler-artifact':continue
   for f in map(Path,m['filenames']):
    if f.suffix=='.rlib':files[m['target']['name']]=f;search.add(f.parent)
 dest=P/'client';argv=['taskset','-c','26-27','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(P),str(P),'--ro-bind',str(driver),str(sdk/'lib'/son),'--chdir',str(P),'--',str(Path.home()/'.cargo/bin/rustc'),'+ohm','--edition=2024','--crate-name=observer',str(P/'client.rs'),'-o',str(dest)];argv+=sum((['--extern',n+'='+str(f)]for n,f in sorted(files.items())),[])+sum((['-L','dependency='+str(d)]for d in sorted(search)),[]);r=sp.run(argv,env=env,capture_output=True,timeout=35);(out/'diagnostic').write_bytes(r.stderr);assert r.returncode==0,r.stderr[-1200:];text=sp.check_output([dest],text=True).strip();assert text==('9 8 2 16' if phase=='body-shift-layout' else '8 8 1 10'),text;output[phase+'-'+arm+'-app']={'elf':sha(dest),'runtime':text};(P/'results.json').write_text(json.dumps(output,indent=2))
run('prime',members);run('no-op',members);save()
for phase in ('moved','deprecated','body-shift-layout'):
 for arm in ('retained','forced'):
  reset(phase)
  if arm=='forced':
   for n in ('isolated','forward','layout','exported_body','denied'):strip(n)
  for n in ('upstream','isolated','forward','layout','exported_body','denied'):run(phase+'-'+arm+'-'+n,[n],not(phase=='deprecated' and n=='denied'))
  app(phase,arm)
for phase in ('moved','deprecated','body-shift-layout'):
 for n in members:
  a,b=[output[phase+'-'+t+'-'+n]for t in ('retained','forced')]; assert a['warnings']==b['warnings'] and a['status']==b['status'],(phase,n,a,b)
  for unit in a['artifacts']:
   v,y=[w['artifacts'][unit]for w in (a,b)];assert v['rmeta']==y['rmeta'] and sorted(v['objs'].values())==sorted(y['objs'].values()),(phase,n,unit,v,y)
 assert output[phase+'-retained-app']==output[phase+'-forced-app'],phase
 assert output[phase+'-retained-isolated']['reuse']==1 and output[phase+'-retained-forward']['reuse']==0 and output[phase+'-retained-layout']['reuse']==0 and output[phase+'-retained-exported_body']['reuse']==0,phase
print('Final ELF and runtime, exact emitted metadata, content of every native object and diagnostics matched across each case.',flush=True)
