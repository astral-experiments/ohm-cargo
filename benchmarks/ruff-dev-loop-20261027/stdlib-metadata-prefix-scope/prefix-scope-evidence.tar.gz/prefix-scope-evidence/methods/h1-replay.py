"""Scoped production-like native rustc commands from a read-only matching stage-one workspace."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys,time,resource
P=Path('/dev/shm/ohm-rustc-prefix-real-20261027');R=Path('/mnt/devbox-scratch/dev-user/ohm-mixed-interface-20261027');H=Path.home()/'.cache/ohm-mixed-pilot-targets-20261027';W=Path.home()/'code/oss/ruff-ohm-mixed-interface-20261027';T=H/'pair/target';S=P/'state';I=S/'incremental';O=S/'out';son='librustc_driver-15d35e5526bb94f8.so';D=P/'encoder-stage1.so';data=json.loads((P/'stage-roster.json').read_bytes());data=data['units'];allnames=['ruff_python_stdlib','ty_module_resolver','ty_python_core','ty_python_semantic','ty_project','ty_ide'];ty=Path('crates/ruff_python_stdlib/src/typing.rs');orig=P/'original.rs';edit=P/'historical.rs';b='ty_python_semantic'; cache=lambda n:list(I.glob(n+'-*'));sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();out=lambda n:O/n
assert sha(D)=='7d5062b08021e29073bc06eee54a775ef02f299418e57d0a9565175134fde6fb';assert sha(W/ty)==sha(orig); assert sp.check_output(['git','-C',W,'rev-parse','HEAD'],text=True).strip()=='93526150df078af7dd8fc4226cdcc469539d2001'

def init():
 assert shutil.disk_usage(P).free>25*2**30;S.mkdir(exist_ok=False);I.mkdir();O.mkdir();(S/'other-cache').mkdir()
 for n in allnames:
  d=data[n];folder=Path(d['inc'])/d['sessions'][0]['folder'].split('/')[0];shutil.copytree(folder,I/folder.name,symlinks=True);shutil.copytree(d['out'],out(n),symlinks=True)
 (S/'log').mkdir();print('Initialized six scoped private output/incremental copies',sum(x['bytes'] for v in data.values()for x in v['sessions'])//2**20,'MiB',flush=True)

def compile(n,tag,phase='original',extra=False):
 log=S/'log'/tag;log.mkdir();a=data[n]['arg'];inc=R/'target'/Path(data[n]['inc']).relative_to(T);c=['taskset','-c','26-27','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(S/'other-cache'),str(S/'other-cache')];
 for t in ['target','shared','registry-home']:c+=['--ro-bind',str(H/'pair'/t),str(R/t)]
 for u in allnames:c+=['--bind',str(out(u)),data[u]['arg'][data[u]['arg'].index('--out-dir')+1]]
 c+=['--bind',str(I),str(inc),'--ro-bind',str(D),str(R/'sysroot/lib'/son),'--ro-bind',str(edit if phase=='edited' else orig),str(W/ty)];
 if extra:
  p=S/(n+'-initial.rs');p.write_bytes((W/data[n]['source']).read_bytes()+b'\nconst _: () = ();\n');c+=['--ro-bind',str(p),str(W/data[n]['source'])]
 c+=['--chdir',str(W),'--',*a];env=dict(os.environ,LD_LIBRARY_PATH=str(R/'sysroot/lib'),CARGO_MANIFEST_DIR=str(W/'crates'/n),CARGO_MANIFEST_PATH=str(W/'crates'/n/'Cargo.toml'),CARGO_CRATE_NAME=n,RUSTUP_HOME=str(R/'rustup'),RUSTUP_TOOLCHAIN='ohm',CARGO_HOME=str(R/'registry-home'),XDG_CACHE_HOME=str(S/'other-cache'),RUSTC_LOG='ohm_metadata_reuse=info',CARGO_PKG_VERSION='0.0.0');t=time.monotonic();r=sp.run(c,cwd=W,env=env,capture_output=True,timeout=220);elapsed=time.monotonic()-t;(log/'stderr').write_bytes(r.stderr);(log/'stdout').write_bytes(r.stdout);row={'tag':tag,'crate':n,'phase':phase,'status':r.returncode,'elapsed_ns':round(elapsed*1e9),'rebind':r.stderr.count(b'rebound unused dependencies'),'prefix':r.stderr.count(b'with a freshly encoded source map'),'args_sha256':hashlib.sha256(json.dumps(a,separators=(',',':')).encode()).hexdigest()};(log/'result.json').write_text(json.dumps(row,indent=2));print(row,flush=True)
 if r.returncode:
  for l in r.stderr.splitlines():
   try:q=json.loads(l);print(str(q.get('rendered',q.get('message','')))[:1100],flush=True)
   except ValueError:print(l[:280],flush=True)
  raise RuntimeError(tag)
 f=next(out(n).glob('*.rmeta'));ll=next(out(n).glob('*.rlib'));row['rmeta_sha256']=sha(f);row['rmeta_bytes']=f.stat().st_size;row['rlib_sha256']=sha(ll);row['rlib_bytes']=ll.stat().st_size
 if n==b and tag in ['real-retained','real-forced','original-exact']:
  objects={};
  with ll.open('rb')as archive:
   assert archive.read(8)==b'!<arch>\n';i=0
   while hdr:=archive.read(60):
    assert len(hdr)==60;sz=int(hdr[48:58]);v=archive.read(sz);assert len(v)==sz
    if len(v)>4 and v[:4]==b'\x7fELF':objects[str(i)]=hashlib.sha256(v).hexdigest()
    if sz&1:archive.read(1)
    i+=1
  row['elf_member_values']=list(objects.values());
 (log/'result.json').write_text(json.dumps(row,indent=2));
 return row

def seed(n):
 k=P/('seed-'+n);k.mkdir();assert len(cache(n))==1;shutil.copytree(cache(n)[0],k/'incremental');shutil.copytree(out(n),k/'out');return k

def reset(n,k,strip):
 assert len(cache(n))==1;t=cache(n)[0];shutil.rmtree(t);shutil.copytree(k/'incremental',t);shutil.rmtree(out(n));shutil.copytree(k/'out',out(n));m=list(t.glob('s-*/metadata-prefix-v3.ohm-prefix-v3'));assert len(m)==1 and m[0].open('rb').read(23).startswith(b'ohm-metadata-prefix-v4\x00'),[(x.name,x.open('rb').read(24))for x in m]
 if strip:m[0].unlink()

if sys.argv[1]=='init':init()
elif sys.argv[1]=='run':
 assert S.is_dir(); normal=compile(b,'original-smoke');compile(b,'prime-with-local-input','original',True); exact=compile(b,'original-exact'); assert normal['rmeta_sha256']==exact['rmeta_sha256'],(normal['rmeta_sha256'],exact['rmeta_sha256']);k=seed(b)
 for n in allnames[:3]:compile(n,'edited-'+n,'edited')
 reset(b,k,False);a=compile(b,'real-retained','edited');reset(b,k,True);z=compile(b,'real-forced','edited');assert a['rmeta_sha256']==z['rmeta_sha256'] and a['elf_member_values']==z['elf_member_values'],(a,z);print('end',a['rebind'],a['elapsed_ns'],z['elapsed_ns'],a['rmeta_sha256'],len(a['elf_member_values']),flush=True)
