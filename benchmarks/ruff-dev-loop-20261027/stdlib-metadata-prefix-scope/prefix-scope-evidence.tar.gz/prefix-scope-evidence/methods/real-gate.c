#include <assert.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
typedef const unsigned char *Node;
static uint16_t u16(Node p){uint16_t v;memcpy(&v,p,2);return v;}
static uint32_t u32(Node p){uint32_t v;memcpy(&v,p,4);return v;}
static uint64_t u64(Node p){uint64_t v;memcpy(&v,p,8);return v;}
static unsigned leb(Node *p){unsigned v=0;for(unsigned i=0;i<=28;i+=7){unsigned b=*(*p)++;v|=(b&127)<<i;if(b<128)return v;}abort();}
struct Data {Node p,metadata;Node *index; uint64_t size,count;};
static struct Data load(const char *f){int fd=open(f,O_RDONLY);assert(fd>=0);struct stat st;assert(fstat(fd,&st)==0);Node b=mmap(NULL,st.st_size,PROT_READ,MAP_PRIVATE,fd,0);assert(b!=MAP_FAILED);close(fd);Node end=b+st.st_size,ft=end-61;assert(!memcmp(end-13,"rust-end-file",13));struct Data v={b,NULL,NULL,u64(ft+24),u64(ft+32)};assert(v.count<=v.size&&v.size<20000000);v.index=calloc(v.size,sizeof(*v.index));Node p=b+7+b[6]+8;size_t total=0;for(size_t i=0;i<v.count;i++){assert(p+38<ft);unsigned h=u16(p),k=h&511,index=u32(p+2);assert(index<v.size&&!v.index[index]);v.index[index]=p;if(k==7){assert(!v.metadata&&!u64(p+6)&&!u64(p+14));v.metadata=p;}p+=38;unsigned n=h>>11;n=n?n-1:leb(&p);total+=n;p+=n*(1+((h>>9)&3));}assert(total==u64(ft+40)&&v.metadata);return v;}
static size_t bucket(Node p,size_t mask){uint64_t a=u64(p+6),b=u64(p+14);uint64_t v=(a^(b*0x9e3779b185ebca87ULL))+(u16(p)&511);v=(v^(v>>33))*0xff51afd7ed558ccdULL;return (v^(v>>33))&mask;}
static int same(Node a,Node b){return (u16(a)&511)==(u16(b)&511)&&!memcmp(a+6,b+6,16);}
int main(int argc,char **argv){assert(argc==3);struct Data a=load(argv[1]),b=load(argv[2]);unsigned h=u16(a.metadata),n=h>>11,w=1+((h>>9)&3);Node p=a.metadata+38;n=n?n-1:leb(&p);size_t len=1;while(len<n*2ul)len*=2;Node *keys=calloc(len,sizeof(*keys));unsigned char *colors=calloc(len,1);size_t totals[512][3]={0};size_t mask=len-1;for(unsigned j=0;j<n;j++,p+=w){unsigned idx=0;memcpy(&idx,p,w);assert(idx<a.size&&a.index[idx]);Node v=a.index[idx];size_t k=bucket(v,mask);while(keys[k]&&!same(keys[k],v))k=(k+1)&mask;keys[k]=v;}
for(size_t j=0;j<b.size;j++){Node v=b.index[j];if(!v)continue;size_t k=bucket(v,mask);while(keys[k]&&!same(keys[k],v))k=(k+1)&mask;if(keys[k])colors[k]=memcmp(keys[k]+22,v+22,16)?2:1;}
for(size_t k=0;k<len;k++){Node v=keys[k];if(!v)continue;unsigned kind=u16(v)&511,which=colors[k];if(which!=1&&totals[kind][which]<4)printf("first %u %u %016lx %016lx\n",kind,which,u64(v+6),u64(v+14));totals[kind][which]++;}printf("total %lu %lu %u\n",a.count,b.count,n);for(unsigned k=0;k<512;k++)if(totals[k][0]||totals[k][1]||totals[k][2])printf("kind %u %lu %lu %lu\n",k,totals[k][0],totals[k][1],totals[k][2]);}
