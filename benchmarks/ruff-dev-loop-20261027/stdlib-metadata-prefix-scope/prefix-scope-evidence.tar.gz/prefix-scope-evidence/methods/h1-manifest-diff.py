import sys,hashlib,json
from pathlib import Path
r=Path('/dev/shm/ohm-rustc-prefix-real-20261027');result={}
def parse(m):
 i=23+16;assert m[:23]==b'ohm-metadata-prefix-v4\0';
 def u():
  nonlocal i;v=0;s=0
  while True:
   b=m[i];i+=1;v|=(b&127)<<s
   if b&128:s+=7;continue
   return v
 def raw(n):
  nonlocal i; b=m[i:i+n];i+=n;return b
 sid=u();prefix=u();nbytes=u();h=raw(16);files={raw(16).hex():raw(16).hex() for _ in range(u())}; protected={}
 for j in range(u()):
  fid=raw(16).hex();a=u();b=u();dis=raw(1)[0];assert dis in (0,1);hv=raw(16).hex()if dis else None;protected[(fid,a,b)]=hv
 crateids=raw(16).hex();bits=raw(u());definitions=u();fp=raw(16).hex();return {'id':sid,'prefix':prefix,'nbytes':nbytes,'files':files,'protected':protected,'crateids':crateids,'bits':bits.hex(),'count':definitions,'def_fp':fp}
for n in ['ty_python_semantic','ty_ide']:
 a=parse(next((r/('seed-'+n)/'incremental').glob('s-*/metadata-prefix-v3.ohm-prefix-v3')).read_bytes());b=parse(next((r/'state/incremental').glob(n+'-*/s-*/metadata-prefix-v3.ohm-prefix-v3')).read_bytes());out={}
 for k in a:
  if k in ('files','protected'):
   keys=a[k].keys()|b[k].keys();out[k]={'before':len(a[k]),'after':len(b[k]),'missing':sum(x not in b[k] for x in a[k]),'added':sum(x not in a[k] for x in b[k]),'changed':sum(a[k][x]!=b[k][x] for x in a[k].keys()&b[k].keys())}
  else:out[k]=[a[k],b[k]] if a[k]!=b[k] else True
 result[n]=out
print(json.dumps(result,indent=2))
