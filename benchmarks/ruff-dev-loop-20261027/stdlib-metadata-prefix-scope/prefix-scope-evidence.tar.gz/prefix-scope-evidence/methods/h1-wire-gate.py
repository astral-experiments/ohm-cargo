from pathlib import Path
import json,sys,hashlib
p=Path('/dev/shm/ohm-rustc-prefix-real-20261027');s=p/'state';chosen='ty_python_semantic';seed=p/('seed-'+chosen);old=next((seed/'out').glob('*.rmeta'));new=s/'real-forced.rmeta';rd=Path(p/'rd.py');
READER='''class R:
 def __init__(s,b):s.v=b;s.root=int.from_bytes(b[8:16],'little');s.i=s.root;s.prev=None
 def raw(s,n):r=s.v[s.i:s.i+n];s.i+=n;return r
 def u(s):
  ret=0;j=0
  while 1:
   b=s.raw(1)[0];ret|=(b&127)<<j
   if not b&128:return ret
   j+=7
 def text(s):v=s.raw(s.u()).decode();assert s.raw(1)==b'\\xc1';return v
 def sym(s):
  k=s.u()
  if k==0:return s.text()
  n=s.u()
  if k==2:return n
  assert k==1;i=s.i;s.i=n;t=s.text();s.i=i;return t
 def arr(s):
  n=s.u()
  if not n:return (0,0)
  d=s.u();s.prev=s.root-d if s.prev is None else s.prev+d;return n,s.prev
 def deps(s):
  assert s.u()==0;s.text();s.raw(32);s.sym();s.raw(2);s.text();s.raw(8)
  if s.u():s.u()
  s.u();s.u();s.raw(4);s.arr();n,pos=s.arr();s.i=pos;z=[]
  for c in range(1,n+1):
   name=s.sym();hash=s.raw(16).hex();host=s.raw(16).hex()if s.u()else None;k=s.u();extra=s.text();pr=s.u();z.append([name,c,hash,extra,host,k,pr])
  return z
''';exec(READER);a=R(old.read_bytes()).deps();b=R(new.read_bytes()).deps();m=next((seed/'incremental').glob('s-*/metadata-prefix-v3.ohm-prefix-v3')).read_bytes();r=R(m);r.i=23+16;sid=r.u();pref=r.u();length=r.u();r.raw(16);n=r.u();r.raw(32*n);protect=r.u()
for _ in range(protect):
 r.raw(16);r.u();r.u();tag=r.raw(1)[0]
 if tag:r.raw(16)
assert tag in (0,1) if protect else True
ids=r.raw(16).hex();nn=r.u();bits=r.raw(nn);assert all(v in (0,1)for v in bits);assert len(a)==len(b);out={'manifest_prefix_bytes':pref,'protected':protect,'source_files':n,'dependency_slots':len(a),'touched_crates':sum(bits),'changed':[],'bit_for_direct_stdlib':[],'size_and_sort_check':{}};
for aa,bb in zip(a,b):
 assert aa[:2]+aa[3:]==bb[:2]+bb[3:];used=aa[1]<len(bits)and bits[aa[1]]==1
 if aa[0]=='ruff_python_stdlib':out['bit_for_direct_stdlib'].append(used)
 if aa[2]!=bb[2]:out['changed'].append({'name':aa[0],'cnum':aa[1],'referenced':used,'old':aa[2],'new':bb[2]})
rr=[json.loads((s/'log'/t/'result.json').read_bytes()) for t in ('real-retained','real-forced')];v,w=(z['elf_member_values'] for z in rr);out['object_order']={'ordered':v==w,'sorted':sorted(v)==sorted(w),'count':[len(v),len(w)],'unique_missing':[len(set(v)-set(w)),len(set(w)-set(v))]};print(json.dumps(out,indent=2))
