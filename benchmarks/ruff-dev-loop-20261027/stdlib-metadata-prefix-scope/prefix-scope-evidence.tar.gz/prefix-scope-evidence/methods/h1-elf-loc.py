from pathlib import Path
import hashlib,json,subprocess as sp,struct
p=Path('/dev/shm/ohm-rustc-prefix-real-20261027/state');n='ty_ide';sha=lambda b:hashlib.sha256(b).hexdigest()
def archive(x):
 ans={};st=b''
 with x.open('rb')as f:
  assert f.read(8)==b'!<arch>\n'
  while h:=f.read(60):
   sz=int(h[48:58]);b=f.read(sz);lab=h[:16].decode().strip();
   if sz&1:f.read(1)
   if lab=='//':st=b;continue
   if lab in ('/','/SYM64/'):continue
   if lab[0]=='/':i=int(lab[1:]);lab=st[i:st.index(b'/\n',i)].decode()
   lab=lab.rstrip('/'); parts=lab.split('.')
   if lab.endswith('.rcgu.o'):lab='.'.join(parts[:-3]+parts[-2:]);
   assert lab not in ans,lab;ans[lab]=b
 return ans

def secs(b):
 assert b[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',b,40)[0];size,n,st=struct.unpack_from('<3H',b,58);table=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)for i in range(n)];ss=table[st];sb=b[ss[4]:ss[4]+ss[5]];out={}
 for h in table:
  name=sb[h[0]:sb.index(0,h[0])].decode();out[name]={'n':h[5],'hash':sha(b[h[4]:h[4]+h[5]]) if h[1]!=8 else None}
 return out
ar0=archive(p/'ide-retained.rlib');ar1=archive(next((p/'out'/n).glob('*.rlib')));assert ar0.keys()==ar1.keys();d=[]
for k in ar0:
 if ar0[k]==ar1[k]:continue
 a=secs(ar0[k]);b=secs(ar1[k]);ns=a.keys()|b.keys();st={z:[a.get(z),b.get(z)]for z in sorted(ns) if a.get(z)!=b.get(z)};d.append({'member':k,'differing_sections':st,'hashes':[sha(ar0[k]),sha(ar1[k])]});
print(json.dumps({'members':len(ar0),'differences':d},indent=2))
