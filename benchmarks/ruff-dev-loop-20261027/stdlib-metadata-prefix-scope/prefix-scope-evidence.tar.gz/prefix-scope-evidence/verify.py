from pathlib import Path
import hashlib,itertools,json,math
D=Path(__file__).resolve().parent;R=D/'results'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def read(p):return json.loads(p.read_bytes())
for name,digest in read(D/'SHA256.json').items():assert sha(D/name)==digest,name
plan=read(R/'ide-scope-plan.json'); all_=read(R/'h1-validated-scoped-results.json');q=all_['scope-cohort'];assert q['plan_sha256']==sha(R/'ide-scope-plan.json')
obs=q['observations'];assert len(obs)==12 and [n['order']for n in obs]==plan['orders'] and plan['orders'].count('FR')==6
xs=[];sign=[]
for b in obs:
 order=b['order'];x,y=b['rows'];assert [r['tag'][-1] for r in (x,y)]==list(order)
 assert x['status']==y['status']==0 and x['args_sha256']==y['args_sha256']
 assert [r['rebind']for r in (x,y)]==[int(s=='R')for s in order]
 assert x['rmeta_sha256']==y['rmeta_sha256'] and x['archive']['normalized_objects_sha256']==y['archive']['normalized_objects_sha256']
 assert x['archive']['ordered_normalized_filenames_sha256']==y['archive']['ordered_normalized_filenames_sha256'] and all(r['archive']['object_count']==171 and r['archive']['native_libraries']==[]for r in (x,y))
 xs.append(math.log(x['elapsed_ns'])-math.log(y['elapsed_ns']));sign.append(1 if order=='FR'else -1)
t=sum(s*x for s,x in zip(sign,xs))/12;vs=[sum(x*(1 if i in s else -1)for i,x in enumerate(xs))/len(xs)for s in itertools.combinations(range(12),6)];p=sum(abs(n)>=abs(t)-1e-12 for n in vs)/len(vs);assert abs(p-q['analysis']['order_randomization_p'])<1e-12 and abs(100*(1-math.exp(-t))-q['analysis']['reduction_percent'])<1e-10
s=read(R/'h1-real-physical-declarations.json');assert s['ty_python_semantic']['changed_raw_DefIndex_slots']==133 and s['ty_python_semantic']['total']==[89246,89246] and s['ty_ide']['changed_raw_DefIndex_slots']==0 and s['ty_ide']['total']==[7494,7494]
v=read(R/'h1-real-query-classes.json');assert(sum(x['same']+x['missing']+x['changed']for x in v.values()),sum(x['changed']for x in v.values()),sum(x['missing']for x in v.values()))==(953893,1,0)
assert all_['ide-differential']['hit']==1 and all_['real-differential']['hit']==0 and all_['real-differential']['raw_metadata_equal']
a=all_['reader-matched'];assert a['retained']==a['forced'] and a['forced']['size']==170598376 and a['forced']['runtime']=='Function false false'
z=read(R/'tiny-native-and-diagnostic-guards.json');assert z['deprecated-retained-denied']['status']==z['deprecated-forced-denied']['status']==101
for case in ('moved','deprecated','body-shift-layout'):
 assert z[case+'-retained-app']==z[case+'-forced-app']
 assert z[case+'-retained-isolated']['reuse']==1 and z[case+'-forced-isolated']['reuse']==0
 assert all(z[case+'-retained-'+n]['reuse']==0 for n in ('forward','layout','exported_body'))
print(f'12 scoped pairs, {len(vs)} order assignments, p={p:.8f}; metadata, all native objects, external ELF, observations and digests agree.')
