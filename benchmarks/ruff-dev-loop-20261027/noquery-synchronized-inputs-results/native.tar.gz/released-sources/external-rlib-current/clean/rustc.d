# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028/released-sources/external-rlib-current/independent/target/debug/build/workspaces/2dbc038fde31c274/v2-a9b82e083e0eba69/hold_direct/25790fd6646d2af3/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028/released-sources/external-rlib-current/independent/target/debug/build/workspaces/2dbc038fde31c274/v2-a9b82e083e0eba69/hold_direct/25790fd6646d2af3/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028/released-sources/external-rlib-current/independent/target/debug/build/workspaces/2dbc038fde31c274/v2-a9b82e083e0eba69/hold_direct/25790fd6646d2af3/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028/released-sources/external-rlib-current/independent/target/debug/build/workspaces/2dbc038fde31c274/v2-a9b82e083e0eba69/hold_direct/25790fd6646d2af3/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028/released-sources/external-rlib-current/independent/target/debug/build/workspaces/2dbc038fde31c274/v2-a9b82e083e0eba69/hold_direct/25790fd6646d2af3/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=8a0ca1cf0408d434221f9953b3db132fc660c226b6049dfd9b905d0e3bbacdbe file_len:269 hold_direct/src/main.rs
