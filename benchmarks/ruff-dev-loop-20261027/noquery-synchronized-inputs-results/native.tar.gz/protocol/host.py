"""Bind the candidate Cargo and Rust executables inside the original verified SDK layout."""
from pathlib import Path
import fcntl,hashlib,json,os,shlex,shutil,subprocess,sys,traceback
here=Path(__file__).resolve().parent
ops=here.parent; bank=Path('/dev/shm/ohm-observer-protocol-h1-20261027');pilot=bank/'optional-native-pilot1-20261028';store=Path('/mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028');store.mkdir(mode=0o700)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();J=lambda p:json.loads(p.read_bytes())
ref=J(pilot/'pinned-subjects/shared-generation.json')['matched'];nsbase=['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--bind',str(store),str(store),'--tmpfs','/tmp']
assert shutil.disk_usage(store).free>8*2**30
try:
  for case,cargo,cc in [('released-sources','A','N-old-raw'),('candidate','N','N-common'),('explicit-probe','Q','Q-common')]:
    sdk=pilot/cc/'active-sdk';prog=pilot/'pinned-subjects'/cargo/'cargo';release=bank/'release-unicode/rc17-fixed' if case=='released-sources' else pilot/'common-release';rd=J(release/'receipt.json');drv=sdk/'lib'/rd['driver_name'];assert sha(prog)==ref[cargo]['binary'] and sha(sdk/'bin/rustc')==rd['frontend'] and sha(drv)==rd['candidate_postbolt'];assert sha(drv)==('52d5c046f570d3d61ff8bbaeff0d44798df916306110b4a2cac7fe459bc11955' if case=='released-sources' else 'ee9448c27a69a06a50abe707797637638dc6b2a226011339b35adc2b9a065b99');out=store/case
    (store/(case+'.identity.json')).write_text(json.dumps(dict(cargo=sha(prog),frontend=rd['frontend'],driver=sha(drv),sdk=str(sdk),base=rd),indent=2,sort_keys=True)+'\n')
    cmd=[*nsbase,'--ro-bind',str(prog),str(sdk/'bin/cargo'),'--','taskset','-c','0-3','/usr/bin/python3','-B',str(here/'exercise.py'),'--sdk',str(sdk),'--root',str(out)]
    with (store/(case+'.stdout')).open('xb') as so,(store/(case+'.stderr')).open('xb') as se:a=subprocess.run(cmd,stdout=so,stderr=se)
    (store/(case+'.exit')).write_text(str(a.returncode));assert a.returncode==0,(case,(store/(case+'.stderr')).read_text()[-1600:]);assert (out/'complete.json').exists()
  (store/'complete.json').write_text(json.dumps({d:J(store/d/'complete.json') for d in ('released-sources','candidate','explicit-probe')},indent=2)+'\n')
except BaseException:
  (store/'failure.txt').write_text(traceback.format_exc());raise
