fn main(){println!("native-value={}",leaf::answer());}
