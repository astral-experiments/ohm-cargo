use std::path::PathBuf;
fn main() {
    let external = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).parent().unwrap().parent().unwrap().join("external");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-search=native={}", external.join("first").display());
    println!("cargo:rustc-link-search=native={}", external.join("second").display());
}
