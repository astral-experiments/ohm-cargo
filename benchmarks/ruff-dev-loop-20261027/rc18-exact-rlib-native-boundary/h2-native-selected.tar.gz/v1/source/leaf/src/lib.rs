const _: () = tokens::observed!();
#[link(name="nativeguard",kind="static",modifiers="-bundle")] unsafe extern "C" {fn nativeguard_number()->i32;}
#[inline(never)] pub fn answer()->i32 {(unsafe { nativeguard_number() }) + 1}
