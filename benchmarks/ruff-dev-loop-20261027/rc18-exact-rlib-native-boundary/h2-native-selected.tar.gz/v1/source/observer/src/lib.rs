extern crate proc_macro;
use proc_macro::TokenStream;
#[proc_macro] pub fn observe(t:TokenStream)->TokenStream { let s=t.into_iter().next().unwrap().span(); ::std::hint::black_box(format!("{s:?}")); "()".parse().unwrap() }
