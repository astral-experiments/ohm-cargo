int atoi(const char *p) { return 83; }
