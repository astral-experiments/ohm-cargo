int atoi(const char *p) { return 41; }
