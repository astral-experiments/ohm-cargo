use std::path::PathBuf;
fn main() {
    let donor = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).parent().unwrap().parent().unwrap().join("external/libutil.a");
    let out = PathBuf::from(std::env::var_os("OUT_DIR").unwrap());
    if donor.is_file() { std::fs::copy(donor, out.join("libutil.a")).unwrap(); }
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-search=native={}", out.display());
}
