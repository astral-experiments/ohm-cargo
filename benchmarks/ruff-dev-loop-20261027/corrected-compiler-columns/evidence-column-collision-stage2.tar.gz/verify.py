"""Verify source provenance, raw compile notifications and reader diagnostics without running Rust."""
import hashlib
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for line in (root/"SHA256SUMS").read_text().splitlines():
    want,rel=line.split("  ",1)
    assert sha(root/rel)==want,rel
prov=json.loads((root/"source.json").read_bytes())
assert set(prov["trees"][rev] for rev in [prov["fix"],prov["initial_head"],prov["final_head"]])=={"9e52c043880793c40fedf3eb137a231479d9adba"}
assert prov["changed"]==["tests/run-make/public-api-hash-artifact/rmake.rs"]
assert prov["fixture_rmake_sha256"]==sha(root/"fixture/rmake.rs")
assert prov["final_rmake_sha256"]==sha(root/"final-rmake.rs")
drivers={side:json.loads((root/"drivers"/(side+".json")).read_bytes())["sha256"] for side in ["parent","fixed"]}
assert drivers=={"parent":"55e123a9e87f16a449d260ab65449eab743cd30ba356a7f10ffdd1fa6f8a2484","fixed":"3e4b168966e111b52ad1a942d364ec1335cf1cfa994f4208b0909ca215b589d2"}
assert json.loads((root/"drivers/release-build.json").read_bytes())["candidate_postbolt"]==drivers["fixed"]
count=0
for side in drivers:
    for kind in ["tracked","private-method","exported-macro"]:
        for emit in ("metadata","metadata,link"):
            d=root/"raw"/(side+"-"+kind+"-"+emit.replace(",","-"))
            j=json.loads((d/"result.json").read_bytes())
            assert (j["driver"],j["kind"],j["emit"])==(drivers[side],kind,emit)
            assert j["args"].count("--emit="+emit)==1
            assert j["args"].count("-Zincremental-verify-ich")==1 and j["args"].count("-Zpublic-api-hash")==1
            hashes=[]
            for row,phase,reused in zip(j["rows"],["base","steady","moved","repeat"],[False,True,False,True],strict=True):
                stderr=(d/(phase+".stderr")).read_bytes()
                artifact,=[x for l in stderr.splitlines() if l.startswith(b"{") and (x:=json.loads(l)).get("emit")=="metadata"]
                assert artifact["public_api_hash"]["version"]==1
                assert row["phase"]==phase and row["public_hash"]==artifact["public_api_hash"]["value"]
                assert (b"reused metadata item prefix" in stderr)==row["prefix_reused_message"]==reused
                assert sha(d/(phase+".stdout"))==hashlib.sha256(b"").hexdigest()
                hashes.append(row["public_hash"])
                if phase=="steady":continue
                expected={"tracked":1,"private-method":19,"exported-macro":76}[kind]+(0 if phase=="base" else 256)
                if emit=="metadata,link" or kind=="private-method":assert row["column"]==expected
                if kind=="private-method":
                    errors=list(map(json.loads,(d/(phase+"-reader.stderr")).read_bytes().splitlines()))
                    e=next(x for x in errors if (x.get("code") or {}).get("code")=="E0624")
                    spans=e["spans"]+[s for child in e["children"] for s in child["spans"]]
                    assert any(s.get("label")=="private method defined here" and s["column_start"]==expected for s in spans)
                elif emit=="metadata,link":
                    assert not (d/(phase+"-reader.stderr")).read_bytes()
            assert hashes[0]==hashes[1] and hashes[2]==hashes[3]
            assert (hashes[0]!=hashes[2])==(side=="fixed" and emit=="metadata,link"),(side,kind,emit,hashes)
            count+=len(hashes)
assert count==48
print("Verified 48 artifact notifications, 48 metadata-prefix observations, 12 native/readback cohorts and the #233 compiler tree.")
