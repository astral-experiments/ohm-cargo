"""Replay the existing run-make fixture's source/flags on metadata-only and native rlibs."""
import concurrent.futures
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

root,fixtures,*arms=(Path(a).resolve() for a in sys.argv[1:])
root.mkdir()
recipe=(fixtures/"rmake.rs").read_text()
writer=recipe[recipe.index("    let mut compiler = rustc();"):recipe.index("    for flag in flags")]
extra=re.findall(r'\.arg\("([^"]+)"\)', writer)
assert len(extra)==2
base=(fixtures/"lib.rs").read_text().replace("-> u32","-> u64")
padding=" "*256
track="pub fn caller_location() -> &'static std::panic::Location<'static> { std::panic::Location::caller() }"
method="impl Diagnostic { fn hidden(&self) {} }"
export="#[macro_export] macro_rules! forward { ($observer:ident) => { $observer!(123) }; }"
gap=" "*(256-len(export)-4)
tracked=base+"\n#[track_caller]\n"+track+padding+"\n"
moved_track=tracked.replace(track+padding,padding+track)
diagnostic=moved_track+"\npub struct Diagnostic;\n"+method+padding+"\n"
moved_diagnostic=diagnostic.replace(method+padding,padding+method)
original_export="  "+export+"  "+gap+"/*"+export+"*/"
moved_export="/*"+export+"*/"+gap+"  "+export+"  "
sources={"tracked":(tracked,moved_track),"private-method":(diagnostic,moved_diagnostic),
         "exported-macro":(moved_diagnostic+"\n"+original_export+"\n",moved_diagnostic+"\n"+moved_export+"\n")}
for old,new in sources.values(): assert len(old)==len(new) and old!=new
def lane(i,home):
    side=("parent","fixed")[i]
    env=dict(os.environ,RUSTUP_HOME=str(home),RUSTC_BOOTSTRAP="1",RUSTC_LOG="ohm_metadata_reuse=debug,rustc_metadata::rmeta::encoder=debug")
    for kind in ("tracked","private-method","exported-macro"):
        for emit in ("metadata","metadata,link"):
            dir=root/(side+"-"+kind+"-"+emit.replace(",","-"))
            dir.mkdir()
            first,second=sources[kind]
            for src in fixtures.glob("*.rs"):
                if src.name!="rmake.rs": shutil.copyfile(src,dir/src.name)
            def rustc(label,args,env=env):
                cpu=os.environ.get(("OHM_REVIEW_PARENT_CPUS","OHM_REVIEW_FIXED_CPUS")[i],("4-5","6-7")[i])
                proc=subprocess.run(["taskset","-c",cpu,"rustc","+ohm",*args],cwd=dir,env=env,capture_output=True)
                (dir/(label+".stdout")).write_bytes(proc.stdout);(dir/(label+".stderr")).write_bytes(proc.stderr)
                return proc
            no_log={k:v for k,v in env.items() if k!="RUSTC_LOG"}
            if kind=="exported-macro":
                proc=rustc("inspector",["macro_inspector.rs","--crate-type","proc-macro"],no_log)
                assert proc.returncode==0,proc.stderr
            history=[]
            for idx,(name,src,val) in enumerate([("base",first,5),("steady",first,6),("moved",second,7),("repeat",second,8)]):
                (dir/"lib.rs").write_text(src)
                (dir/"private.rs").write_text((fixtures/"private.rs").read_text().replace("    1","    "+str(val)))
                args=["lib.rs","--crate-type","rlib","--emit="+emit,*extra,"--json=artifacts","--error-format=json","-Cincremental=incremental","-L","."]
                proc=rustc(name,args)
                assert proc.returncode==0,(kind,emit,name,proc.stderr[-500:])
                rows=[json.loads(l) for l in proc.stderr.splitlines() if l.startswith(b'{"')]
                artifact,=[j for j in rows if j.get("emit")=="metadata"]
                h=artifact["public_api_hash"]["value"]
                r=dict(phase=name,public_hash=h,metadata_bytes=hashlib.sha256((dir/"liblib.rmeta").read_bytes()).hexdigest(),
                       prefix_reused_message=b"reused metadata item prefix" in proc.stderr,debug_disabled=b"disabled statically" in proc.stderr)
                if idx in (0,2,3):
                    suffix="rlib" if emit=="metadata,link" else "rmeta"
                    extern=["--extern","lib=liblib."+suffix]
                    reader_args=[*extern,*extra[:1]]
                    if kind=="private-method":
                        p=rustc(name+"-reader",["diagnostic.rs",*reader_args,"--error-format=json","--emit=metadata"],no_log)
                        assert p.returncode==1
                        diag=next(j for j in map(json.loads,p.stderr.splitlines()) if (j.get("code") or {}).get("code")=="E0624")
                        spans=diag["spans"]+[s for child in diag["children"] for s in child["spans"]]
                        r["column"]=next(s["column_start"] for s in spans if s.get("label")=="private method defined here")
                    elif emit=="metadata,link":
                        input="caller.rs" if kind=="tracked" else "macro_user.rs"
                        if kind=="exported-macro": reader_args+=["--extern","macro_inspector=libmacro_inspector.so"]
                        p=rustc(name+"-reader",[input,*reader_args,"-o","runner"],no_log)
                        assert p.returncode==0,p.stderr
                        r["column"]=int(subprocess.check_output([dir/"runner"],cwd=dir,env=no_log))
                history.append(r)
            out=dict(driver=json.loads((home/"receipt.json").read_bytes())["sha256"],kind=kind,emit=emit,args=args,rows=history)
            (dir/"result.json").write_text(json.dumps(out,indent=2)+"\n")
            print(side,kind,emit,[x["public_hash"] for x in history],[x.get("column") for x in history],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs=[pool.submit(lane,i,arm) for i,arm in enumerate(arms)]
    for job in jobs:job.result()
