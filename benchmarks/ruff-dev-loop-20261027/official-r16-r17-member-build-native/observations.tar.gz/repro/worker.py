"""Trace two published native packages on the same unmodified Ruff member and a spaced target."""
import ast
import fcntl
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import traceback
import zipfile

R=Path(__file__).resolve().parent
X=R.parent
original=X/'published-r17-space-h2-v2'
sys.path[:0]=[str(R),str(original/'bin')]
import validate as q
from member_reader import validate as real_caller
from stub_bytes import read_stub

T=Path('/dev/shm/ohm-published-member-h2-20261028')
C=T/'canon'
SDK=C/'sdk'
TARGET=C/'ruff target'
MEMBER=q.WT/'crates/ty_wasm'
STUB='stdlib/functools.pyi'
COLD='721696b22e172c4f9dbe15ec5e04a04a9939188eca12d8110ab62f9de81d96a1'
ARCH={'17':'163267d26889b1bd2c467d7db97efee42cd2ac9dc9af2abc3a56ade8da9a9572','16':'957ca8144205008ddaee75ef35f9775b2e428271c6b044e38bbdd8196c6bbf3e'}
OLD=X/'build-script-current-stock-sdk-v1'
ELFS=['cargo','rustc','driver','wild']
WILD='lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
BASIC=['--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp']
def put(k,v):q.put(k,v)
def filebyte(b):return hashlib.sha256(b).hexdigest()

def search_args(dot,process):
    job,=[v for v in process['jobs'] if v[1:3]==['ty_wasm','full']]
    for raw in (dot/'trace'/('exec.'+str(job[0]))).read_bytes().splitlines():
        if filebyte(raw)!=job[4]:continue
        _,_,call=raw.partition(b' ')
        match=re.match(rb'^execve\(("(?:[^"\\]|\\.)*"),\s*(\[.*\]),\s*(?:0x[\da-f]+|NULL).*?\)\s+= 0$',call)
        assert match is not None and Path(ast.literal_eval(match[1].decode())).samefile(SDK/'bin/rustc')
        args=ast.literal_eval(match[2].decode())
        assert args[args.index('--crate-name')+1]=='ty_wasm'
        return [item for i,v in enumerate(args) if v=='-L' for item in ('-L',args[i+1])]
    raise AssertionError('missing true ty_wasm rustc argv')

def products(rows):
    paths={}
    for v in rows:
        if v['target']['name'] not in ('ty_wasm','ty_vendored') or v['target']['kind']==['custom-build']:continue
        for n in v['filenames']:
            f=Path(n);rel=str(f.relative_to(TARGET));paths[rel]=q.sha(f)
    assert 'debug/libty_wasm.so' in paths
    libs=[n for n in paths if Path(n).name.startswith('libty_vendored-') and Path(n).suffix in ('.rlib','.rmeta')]
    assert len(libs)==2;return paths,libs

def inside(ver):
    q.T=C;q.O=R/('observations-'+ver);q.O.mkdir();q.capacity()
    histories=[];env=q.environment();env['CARGO_TARGET_DIR']=str(TARGET)
    assert ' ' in env['CARGO_TARGET_DIR'] and ' ' not in str(SDK)
    assert not list(TARGET.iterdir()) and not list((C/'shared').iterdir())
    reg=q.registry()
    def invoke(argv,out):
        return subprocess.run(argv,cwd=MEMBER,env=env,capture_output=True,stdin=subprocess.DEVNULL)
    actual=invoke(['rustc','+ohm','--print','sysroot'],q.O);assert actual.returncode==0 and actual.stdout.decode().strip()==str(SDK)
    if ver=='17':assert (SDK/'.ohm-version').read_text().strip()=='ohm-1.99.0-17'
    driver,=(SDK/'lib').glob('librustc_driver-*.so')
    hashes={k:q.sha(f) for k,f in zip(ELFS,[SDK/'bin/cargo',SDK/'bin/rustc',driver,SDK/WILD])}
    if ver=='17':
        identity=json.loads((original/'receipts/installed.json').read_bytes())
        assert hashes=={k:identity['elf'][k]['sha256'] for k in ELFS}
    else:
        a=json.loads((OLD/'official.json').read_bytes())['hashes'];assert hashes=={k:a['frontend' if k=='rustc' else k] for k in ELFS}
    versions={k:invoke([k,'+ohm',flag],q.O).stdout.decode().strip() for k,flag in [('rustc','-vV'),('cargo','-Vv')]};assert all('ohm-1.99.0-'+ver in y for y in versions.values())
    stub=(q.WT/'crates/ty_vendored/vendor/typeshed'/STUB).read_bytes();assert filebyte(stub)==COLD and len(stub)==18553
    cold=None;search=None
    for n in range(4):
        dot=q.O/('phase-'+str(n));dot.mkdir();(dot/'trace').mkdir()
        cmd=['cargo','+ohm','build','--locked','--offline','-j4','--message-format=json']
        trace=['strace','-q','-ff','-ttt','-s','1048576','-e','trace=execve,execveat','-e','signal=SIGCHLD','-o',str(dot/'trace/exec')]
        q.watch([*trace,*cmd],MEMBER,env|{'CARGO_LOG':'cargo::compiler::fingerprint=info'},dot)
        allrows=list(map(json.loads,(dot/'stdout').read_bytes().splitlines()));assert allrows[-1]=={'reason':'build-finished','success':True}
        arts=[v for v in allrows if v['reason']=='compiler-artifact'];assert len(arts)==304 and not any(v['profile']['test'] for v in arts)
        roster=sorted(json.dumps({k:v[k] for k in ('package_id','manifest_path','target','profile','features','filenames','executable')},sort_keys=True) for v in arts)
        if cold is None:cold=roster
        assert roster==cold
        procs=q.processes(dot,SDK,set());search=search_args(dot,procs) if n==0 else search
        assert search and len(search)%2==0 and all(Path(v.split('=',1)[-1]).is_dir() for v in search[1::2]),search
        paths,vendored=products(arts);archive,=[f for root in (TARGET,C/'shared') for f in root.rglob('zipped_typeshed.zip')]
        zipped=archive.read_bytes();embed={}
        with zipfile.ZipFile(archive) as z:
            assert read_stub(z,STUB)==stub;info=z.getinfo(STUB);assert info.compress_type==8
        for rel in vendored:
            with (TARGET/rel).open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
                pos=m.find(zipped);assert pos>=0;embed[rel]=pos
        callerout=C/('reader-'+str(n));callerout.mkdir()
        witness=real_caller('ty_wasm',callerout,invoke,TARGET,paths,search,(R/'reader.rs').read_bytes(),stub)
        for suf in ['stdout','stderr','compile.stdout','compile.stderr']:shutil.copyfile(callerout/('reader.'+suf),dot/('reader.'+suf))
        receipts=dict(phase=n,argv=cmd,units=len(arts),fresh=sum(v['fresh'] for v in arts),roster=q.digest(roster),dirty=sorted([v['target']['name'],v['target']['kind']] for v in arts if not v['fresh']),
                      counts=procs['counts'],jobs=[[v[1],v[2]] for v in procs['jobs']],link_dests=[v[2] for v in procs['linkers']],cargo_raw=q.sha(dot/'stdout'),stderr=q.sha(dot/'stderr'),
                      native=q.sha(dot/'native-processes.json'),traces=q.sha(dot/'trace-files.json'),products=paths,compressed_zip={'sha256':filebyte(zipped),'bytes':len(zipped),'offsets':embed},
                      caller=witness,functools_source_sha256=COLD,search_digest=q.digest(search),diagnostics=q.digest([v for v in allrows if v['reason']=='compiler-message']))
        put(dot/'result.json',receipts);histories.append(receipts)
        assert histories[0]['diagnostics']==receipts['diagnostics'] and histories[0]['compressed_zip']==receipts['compressed_zip']
        if n==3:
            final=q.O/'final-products';final.mkdir()
            for src,name in [(TARGET/'debug/libty_wasm.so','libty_wasm.so'),(archive,'zipped_typeshed.zip'),(dot/'reader.stdout','functools.pyi')]:
                dest=final/name;shutil.copyfile(src,dest);assert q.sha(src)==q.sha(dest)
            assert q.sha(final/'zipped_typeshed.zip')==filebyte(zipped) and q.sha(final/'functools.pyi')==COLD
        print(ver,n,receipts['units'],receipts['fresh'],receipts['counts'],[v[0] for v in procs['jobs'] if v[1]=='ty_wasm'],flush=True)
    result=dict(version=ver,archive=ARCH[ver],tool=hashes,versions=versions,registry=reg,effective_sdk=str(SDK),effective_target=str(TARGET),member='crates/ty_wasm',cold_and_three_unchanged=histories)
    put(q.O/'complete.json',result)

def outside():
    assert socket.gethostname()=='charlie-ohm-relink-b-1024' and (original/'run.rc').read_text().strip()=='1' and (original/'recovery-typed-v1/run.rc').read_text().strip()=='0' and (original/'receipts/complete.json').is_file()
    assert q.validate_source()['commit']==q.PIN
    assert not T.exists() and not (R/'complete.json').exists()
    assert all(q.sha(R/k)==v for k,v in json.loads((R/'source-files.json').read_bytes()).items())
    global_alias=q.version_and_alias();start=q.capacity();os.sched_setaffinity(0,set(range(16)))
    T.mkdir(mode=0o700);C.mkdir();setup=T/'setup';setup.mkdir()
    for dir in ('home','rustup','cargo','tmp'):(setup/dir).mkdir()
    q.T=setup;inst=R/'installer';inst.mkdir()
    archive=original/'release'/(q.STEM+'.tar.gz');assert q.sha(archive)==ARCH['17']
    sdk17=T/'installed17';env=q.environment()|{'OHM_DOWNLOAD_URL':'file://'+str(original/'release'),'OHM_INSTALL_DIR':str(sdk17)}
    q.watch(['bwrap',*BASIC,'--bind',str(T),str(T),'--','/bin/sh',str(original/'release/ohm-installer.sh')],T,env,inst)
    assert (setup/'rustup/toolchains/ohm').resolve(strict=True)==sdk17
    old=json.loads((OLD/'official.json').read_bytes());sdk16=Path(old['sdk_root']);assert q.sha(OLD/'ohm-1.99.0-16-x86_64-unknown-linux-gnu.tar.gz')==old['archive_sha256']==ARCH['16']
    for ver,sdk in [('17',sdk17),('16',sdk16)]:
        q.capacity();state=T/('state-'+ver);state.mkdir()
        for rel in ('home','tmp','cargo','shared','ruff target','rustup/toolchains','sdk'):(state/rel).mkdir(parents=True)
        (state/'rustup/toolchains/ohm').symlink_to(SDK)
        argv=['bwrap',*BASIC,'--bind',str(state),str(C),'--ro-bind',str(sdk),str(SDK),'--bind',str(R),str(R),'--','/usr/bin/python3','-IB',str(R/'worker.py'),'inside',ver]
        subprocess.run(argv,check=True)
        witness=json.loads((R/('observations-'+ver)/'complete.json').read_bytes())['cold_and_three_unchanged'][-1]
        backed=R/('observations-'+ver)/'final-products'
        assert q.sha(backed/'libty_wasm.so')==witness['products']['debug/libty_wasm.so'] and q.sha(backed/'zipped_typeshed.zip')==witness['compressed_zip']['sha256'] and q.sha(backed/'functools.pyi')==COLD
        if ver=='17':
            assert state.resolve()==T/'state-17' and q.sha(R/'worker.py')==json.loads((R/'source-files.json').read_bytes())['worker.py']
            shutil.rmtree(state)  # Only this study's completed private scratch. Its final native products and all four ledgers are durable.
    assert q.version_and_alias()==global_alias and q.validate_source()['commit']==q.PIN
    put(R/'complete.json',dict(campaign='Official Linux ty_wasm with spaced target and unspaced installed SDK',archives=ARCH,global_alias_unchanged=True,source=q.validate_source(),capacity_before=start,capacity_after=q.capacity(),observations={ver:q.sha(R/('observations-'+ver)/'complete.json') for ver in ('16','17')},scored_commands=0))
if __name__=='__main__':
    if len(sys.argv)>1:inside(sys.argv[2])
    else:
        try:
            with (q.P/'native-measure.lock').open('a') as lk:
                fcntl.flock(lk,fcntl.LOCK_EX|fcntl.LOCK_NB);outside()
        except BaseException:
            (R/'failure.txt').write_text(traceback.format_exc());raise
