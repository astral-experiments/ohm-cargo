extern crate right; const _: u8 = right::VALUE;
