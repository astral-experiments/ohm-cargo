# ohm-raw-checksum-paths-v2
/dev/shm/ohm-observer-protocol-h1-20261027/equal-length-release-v4-20261028/r16-build-fixed-fixed/decoy/target/debug/build/workspaces/e0e32573f46884a9/v2-a87db7293a7577c2/hold_direct/e8697830aad8c038/out/hold_direct.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/equal-length-release-v4-20261028/r16-build-fixed-fixed/decoy/target/debug/build/workspaces/e0e32573f46884a9/v2-a87db7293a7577c2/hold_direct/e8697830aad8c038/out/hold_direct.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/equal-length-release-v4-20261028/r16-build-fixed-fixed/decoy/target/debug/build/workspaces/e0e32573f46884a9/v2-a87db7293a7577c2/hold_direct/e8697830aad8c038/out/hold_direct: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/equal-length-release-v4-20261028/r16-build-fixed-fixed/decoy/target/debug/build/workspaces/e0e32573f46884a9/v2-a87db7293a7577c2/hold_direct/e8697830aad8c038/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/equal-length-release-v4-20261028/r16-build-fixed-fixed/decoy/target/debug/build/workspaces/e0e32573f46884a9/v2-a87db7293a7577c2/hold_direct/e8697830aad8c038/out/hold_direct.d/ohm-foreign-span-bytes:
# checksum:blake3=391153fad8dfe8e06a268f6d9896da8dcc50b0c3342fb1958348aebc17259454 file_len:234 hold_direct/src/main.rs
