extern crate external_a;
extern crate external_b;
use hold_shapes::Number;
use hold_probe::native_offset;
const _: Option<Number> = None;
fn main(){println!("{} {}",hold_shapes::count(),hold_tokens::inspect_value!(native_offset));let _ = external_b::value(); println!("escape-value={}",external_a::value());}
