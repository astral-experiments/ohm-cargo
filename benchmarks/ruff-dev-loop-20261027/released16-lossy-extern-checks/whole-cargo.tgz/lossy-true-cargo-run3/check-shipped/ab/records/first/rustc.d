/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ab/target/debug/build/workspaces/caf0c8bf6ecadd79/v2-db693acd5fa77827/hold_direct/9e27a2fb45d3e66d/out/hold_direct-9e27a2fb45d3e66d.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ab/target/debug/build/workspaces/caf0c8bf6ecadd79/v2-db693acd5fa77827/hold_direct/9e27a2fb45d3e66d/out/hold_direct-9e27a2fb45d3e66d.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ab/target/debug/build/workspaces/caf0c8bf6ecadd79/v2-db693acd5fa77827/hold_direct/9e27a2fb45d3e66d/out/libhold_direct-9e27a2fb45d3e66d.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ab/target/debug/build/workspaces/caf0c8bf6ecadd79/v2-db693acd5fa77827/hold_direct/9e27a2fb45d3e66d/out/hold_direct-9e27a2fb45d3e66d.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ab/target/debug/build/workspaces/caf0c8bf6ecadd79/v2-db693acd5fa77827/hold_direct/9e27a2fb45d3e66d/out/hold_direct-9e27a2fb45d3e66d.d/ohm-foreign-span-bytes:
# checksum:blake3=096afc73108ff9e47dcf22918572bd8a6312e4de49e8f4f6338f02381e088edc file_len:354 hold_direct/src/main.rs
