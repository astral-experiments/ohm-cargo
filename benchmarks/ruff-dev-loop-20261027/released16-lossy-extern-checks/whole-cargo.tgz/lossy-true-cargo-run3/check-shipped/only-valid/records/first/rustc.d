/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/only-valid/target/debug/build/workspaces/fbe1dbc9db583206/v2-1396e6dfc54e570e/hold_direct/2afaeb7d766f4ff8/out/hold_direct-2afaeb7d766f4ff8.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/only-valid/target/debug/build/workspaces/fbe1dbc9db583206/v2-1396e6dfc54e570e/hold_direct/2afaeb7d766f4ff8/out/hold_direct-2afaeb7d766f4ff8.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/only-valid/target/debug/build/workspaces/fbe1dbc9db583206/v2-1396e6dfc54e570e/hold_direct/2afaeb7d766f4ff8/out/libhold_direct-2afaeb7d766f4ff8.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/only-valid/target/debug/build/workspaces/fbe1dbc9db583206/v2-1396e6dfc54e570e/hold_direct/2afaeb7d766f4ff8/out/hold_direct-2afaeb7d766f4ff8.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/only-valid/target/debug/build/workspaces/fbe1dbc9db583206/v2-1396e6dfc54e570e/hold_direct/2afaeb7d766f4ff8/out/hold_direct-2afaeb7d766f4ff8.d/ohm-foreign-span-bytes:
# checksum:blake3=d3d7702eed817a5c2c6d6db7cc3982ca855859ecd14ed2e60fcd2058f6f64471 file_len:329 hold_direct/src/main.rs
