/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ba/target/debug/build/workspaces/bd7c0f542c3cb595/v2-b79fc774acca8c02/hold_direct/12bea6977c3d70b8/out/hold_direct-12bea6977c3d70b8.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ba/target/debug/build/workspaces/bd7c0f542c3cb595/v2-b79fc774acca8c02/hold_direct/12bea6977c3d70b8/out/hold_direct-12bea6977c3d70b8.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ba/target/debug/build/workspaces/bd7c0f542c3cb595/v2-b79fc774acca8c02/hold_direct/12bea6977c3d70b8/out/libhold_direct-12bea6977c3d70b8.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ba/target/debug/build/workspaces/bd7c0f542c3cb595/v2-b79fc774acca8c02/hold_direct/12bea6977c3d70b8/out/hold_direct-12bea6977c3d70b8.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-shipped/ba/target/debug/build/workspaces/bd7c0f542c3cb595/v2-b79fc774acca8c02/hold_direct/12bea6977c3d70b8/out/hold_direct-12bea6977c3d70b8.d/ohm-foreign-span-bytes:
# checksum:blake3=77d8e1c5411401e1e6ddc26eb8cdc5c51153da6266de8f0f411763848705747b file_len:354 hold_direct/src/main.rs
