# ohm-raw-checksum-paths-v1
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ab/empty-target/debug/build/workspaces/29d88655b65ac433/v2-67051b557932a4b6/hold_direct/63d985d3664f2255/out/hold_direct-63d985d3664f2255.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ab/empty-target/debug/build/workspaces/29d88655b65ac433/v2-67051b557932a4b6/hold_direct/63d985d3664f2255/out/hold_direct-63d985d3664f2255.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ab/empty-target/debug/build/workspaces/29d88655b65ac433/v2-67051b557932a4b6/hold_direct/63d985d3664f2255/out/libhold_direct-63d985d3664f2255.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ab/empty-target/debug/build/workspaces/29d88655b65ac433/v2-67051b557932a4b6/hold_direct/63d985d3664f2255/out/hold_direct-63d985d3664f2255.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ab/empty-target/debug/build/workspaces/29d88655b65ac433/v2-67051b557932a4b6/hold_direct/63d985d3664f2255/out/hold_direct-63d985d3664f2255.d/ohm-foreign-span-bytes:
# checksum:blake3=096afc73108ff9e47dcf22918572bd8a6312e4de49e8f4f6338f02381e088edc file_len:354 hold_direct/src/main.rs
