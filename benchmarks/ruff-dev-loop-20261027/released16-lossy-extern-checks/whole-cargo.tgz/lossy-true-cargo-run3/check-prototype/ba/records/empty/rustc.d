# ohm-raw-checksum-paths-v1
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ba/empty-target/debug/build/workspaces/83f1f00bf48396d2/v2-b829c19589e80cbc/hold_direct/a9de36288d292ddc/out/hold_direct-a9de36288d292ddc.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ba/empty-target/debug/build/workspaces/83f1f00bf48396d2/v2-b829c19589e80cbc/hold_direct/a9de36288d292ddc/out/hold_direct-a9de36288d292ddc.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ba/empty-target/debug/build/workspaces/83f1f00bf48396d2/v2-b829c19589e80cbc/hold_direct/a9de36288d292ddc/out/libhold_direct-a9de36288d292ddc.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ba/empty-target/debug/build/workspaces/83f1f00bf48396d2/v2-b829c19589e80cbc/hold_direct/a9de36288d292ddc/out/hold_direct-a9de36288d292ddc.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/ba/empty-target/debug/build/workspaces/83f1f00bf48396d2/v2-b829c19589e80cbc/hold_direct/a9de36288d292ddc/out/hold_direct-a9de36288d292ddc.d/ohm-foreign-span-bytes:
# checksum:blake3=77d8e1c5411401e1e6ddc26eb8cdc5c51153da6266de8f0f411763848705747b file_len:354 hold_direct/src/main.rs
