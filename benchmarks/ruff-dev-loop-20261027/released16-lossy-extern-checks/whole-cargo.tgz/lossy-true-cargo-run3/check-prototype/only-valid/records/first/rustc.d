# ohm-raw-checksum-paths-v1
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/only-valid/target/debug/build/workspaces/acf0a5f75b4a0ba5/v2-5d6f7fe3f46afe23/hold_direct/dbca0de167c7df9e/out/hold_direct-dbca0de167c7df9e.d: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/only-valid/target/debug/build/workspaces/acf0a5f75b4a0ba5/v2-5d6f7fe3f46afe23/hold_direct/dbca0de167c7df9e/out/hold_direct-dbca0de167c7df9e.d/ohm-foreign-span-bytes

/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/only-valid/target/debug/build/workspaces/acf0a5f75b4a0ba5/v2-5d6f7fe3f46afe23/hold_direct/dbca0de167c7df9e/out/libhold_direct-dbca0de167c7df9e.rmeta: hold_direct/src/main.rs /dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/only-valid/target/debug/build/workspaces/acf0a5f75b4a0ba5/v2-5d6f7fe3f46afe23/hold_direct/dbca0de167c7df9e/out/hold_direct-dbca0de167c7df9e.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/dev/shm/ohm-observer-protocol-h1-20261027/lossy-true-cargo-run3/check-prototype/only-valid/target/debug/build/workspaces/acf0a5f75b4a0ba5/v2-5d6f7fe3f46afe23/hold_direct/dbca0de167c7df9e/out/hold_direct-dbca0de167c7df9e.d/ohm-foreign-span-bytes:
# checksum:blake3=d3d7702eed817a5c2c6d6db7cc3982ca855859ecd14ed2e60fcd2058f6f64471 file_len:329 hold_direct/src/main.rs
