# ohm-raw-checksum-paths-v1
/mnt/devbox-scratch/dev-user/ohm-observer-shipping-20261027/lossy-external-raw-rc17-final-fixed/relative.d: test.rs

libunicode_experiment.rmeta: test.rs

test.rs:
# checksum:sha256=16d62749b9bcd71ae2d2dfddb53fbafb6d02d76b631ba23ee1e22e6286171baf file_len:24 test.rs
