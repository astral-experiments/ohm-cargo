extern crate external_b;
extern crate external_a;
fn main(){println!("{} {}", external_a::value(),external_b::value());}