"""Compare the external E0061 definition note against three real H2 Ruff parser metadata snapshots."""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,sys,traceback
base=Path.home()/'.cache/ohm-233-position-qualified-20261027'
suite=base/'first-occurrence-mixed-parser-20261027';worker=base/'first-occurrence-worker-v2'
snap=base/'first-occurrence-parser-b-diagnostic-20261027';out=base/'first-occurrence-lexer-definition-probe-v1'
P=Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027');ruff=Path('/home/dev-user/code/oss/ruff-ohm-whole-native-20261027')
F=P/'frozen-toolchain';soname='librustc_driver-774a793a844d5500.so';srel=Path('crates/ruff_python_parser/src/lexer.rs')
def j(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def dump(path,x):path.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='--inside':
    tag=sys.argv[2];rec=j(snap/tag/'receipt.json');md=Path(rec['compiler_reported_path'])
    assert sha(md)==rec['rmeta_sha256'] and sha(ruff/srel)==rec['lexer_rs_sha256']
    driver=sha(F/'lib'/soname);frontend=sha(F/'bin/rustc');assert driver==rec['release_driver']['driver_sha256'] and frontend==rec['frontend']['sha256']
    cmd=['rustc','+ohm','--sysroot',str(F),'--crate-name','ordinary_new_lexer_caller','--crate-type','lib','--edition=2024','--emit=metadata','--error-format=json','--extern','ruff_python_parser='+str(md),*rec['trace_inputs']['ruff_linter']['L_search_arguments'],str(out/'caller.rs'),'-o',str(out/'current/ordinary.rmeta')]
    env=dict(os.environ,RUSTUP_HOME=str(P/'rustup'),RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(P/'registry-home'),LC_ALL='C.UTF-8',RUST_BACKTRACE='0')
    q=subprocess.run(cmd,env=env,cwd=ruff,capture_output=True);d=out/'current'
    (d/'stdout').write_bytes(q.stdout);(d/'stderr.jsonl').write_bytes(q.stderr)
    dump(d/'input.json',{'compiler':driver,'frontend':frontend,'active_root_rmeta_sha256':sha(md),'active_source_sha256':sha(ruff/srel),'caller_source_sha256':sha(out/'caller.rs'),'extern_command':cmd,'installed_runtime_path':str(F),'returncode':q.returncode,'cwd':str(ruff),'hash_opt_in':False,'incremental_opt_in':False})
    assert q.returncode==1 and not q.stdout,(tag,q.returncode,q.stderr[-1000:])
    rows=[json.loads(line) for line in q.stderr.splitlines() if line.strip()]
    errors=[r for r in rows if (r.get('code') or {}).get('code')];assert len(errors)==1 and errors[0]['code']['code']=='E0061',(tag,[r.get('message') for r in rows])
    err=errors[0];notes=[c for c in err['children'] if c['level']=='note' and 'defined here' in c['message']];assert len(notes)==1,(tag,err['children'])
    ext=[s for s in notes[0]['spans'] if s['file_name'].endswith(str(srel))];assert len(ext)==1,(tag,notes[0])
    prim=[s for s in err['spans'] if s['is_primary']];assert len(prim)==1
    sec=ext[0];actual_number,=[i for i,line in enumerate((ruff/srel).read_text().splitlines(),1) if line.startswith('pub fn lex(')]
    # The file text is an independent source-side oracle. The compiler position comes from the retained rmeta.
    assert sec['line_start']==actual_number and sec['line_start']==sec['line_end'] and sec['text'],(tag,sec,actual_number)
    dump(d/'observation.json',{'tag':tag,'diagnostic_code':'E0061','message':err['message'],'primary':prim[0],'secondary_note':notes[0]['message'],'secondary':sec,'source_text_function_line':actual_number,'total_json_diagnostics':len(rows),'raw_stderr_sha256':sha(d/'stderr.jsonl')})
    sys.exit(0)
assert (worker/'rc').read_text().strip()=='0' and (suite/'complete.json').is_file() and (snap/'complete.json').is_file(),'run only after experimental terminal state and completed sidecar'
with (P/'native-measure.lock').open('rb') as lock:
    fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
# Release immediately; this tiny external caller does not occupy the native benchmark lane.
assert sorted(os.sched_getaffinity(0))==[30] and not out.exists();out.mkdir(mode=0o700)
try:
    (out/'caller.rs').write_text('pub fn check_exported_function() {\n    let _ = ruff_python_parser::lexer::lex();\n}\n')
    (out/'current').mkdir();state=suite/'state/test/B';shutil.copytree(state/'rustup',out/'rustup',symlinks=True)
    for tag in ('initial','edited','restored'):
        r=j(snap/tag/'receipt.json');md=Path(r['compiler_reported_path']);rec=out/tag;rec.mkdir()
        args=['bwrap','--ro-bind','/','/','--dev-bind','/dev','/dev','--proc','/proc','--bind',str(rec),str(out/'current'),'--bind',str(out/'rustup'),str(P/'rustup')]
        for physical,logical in [('target','native-target'),('shared','shared'),('registry-home','registry-home')]:args+=['--ro-bind',str(state/physical),str(P/logical)]
        for src,dst in [(snap/tag/md.name,md),(snap/tag/'lexer.rs',ruff/srel),(Path(r['release_driver']['driver']),F/'lib'/soname)]:args+=['--ro-bind',str(src),str(dst)]
        args+=['--','/usr/bin/python3','-B',str(Path(__file__).resolve()),'--inside',tag]
        subprocess.run(args,check=True)
    z={tag:j(out/tag/'observation.json') for tag in ('initial','edited','restored')};primary=[r['primary'] for r in z.values()];assert primary[0]==primary[1]==primary[2]
    lines=[r['secondary']['line_start'] for r in z.values()];assert lines[0]==lines[2]==lines[1]+3,lines
    dump(out/'complete.json',{'secondary_definition_lines':lines,'source_positions':{tag:[r['secondary']['line_start'],r['secondary']['column_start'],r['secondary']['line_end'],r['secondary']['column_end']] for tag,r in z.items()},'matched_primary_source':z['initial']['primary'],'status':'external observation only; no claim about which previous workspace processes consumed this definition'})
    print(json.dumps(j(out/'complete.json')),flush=True)
except BaseException:
    (out/'failure.txt').write_text(traceback.format_exc());raise
