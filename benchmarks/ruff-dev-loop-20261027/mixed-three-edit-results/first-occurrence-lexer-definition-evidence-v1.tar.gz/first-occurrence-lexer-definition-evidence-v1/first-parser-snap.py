"""Capture three bounded real parser objects after the frozen H2 test-B freshness audits."""
from pathlib import Path
import ast,gzip,hashlib,json,os,re,shutil,time,traceback
base=Path.home()/'.cache/ohm-233-position-qualified-20261027';q=base/'first-occurrence-mixed-parser-20261027';state=q/'state/test/B'
p=Path('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027');W=base/'first-occurrence-worker-v2'
out=base/'first-occurrence-parser-b-diagnostic-20261027';out.mkdir(mode=0o700)
def j(p):return json.loads(p.read_bytes())
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def facts(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def physical(logical):
 for a,k in ((p/'native-target','target'),(p/'shared','shared')):
  if logical.is_relative_to(a):return state/k/logical.relative_to(a)
 raise ValueError(logical)
def select_trace(d,crate,lib_only):
 jobrows=j(d/'receipt.json')['processes']['jobs'];pids=[t['pid'] for t in jobrows if t['crate']==crate and t['kind']=='full']
 choices=[]
 for pid in pids:
  f=d/pid;successful=[s for s in f.read_text(errors='replace').splitlines() if s.startswith('execve(') and s.endswith('= 0')]
  for line in successful:
   m=re.match(r'execve\(("(?:[^"\\]|\\.)*"),\s*(\[.*\]),\s*(?:0x[\da-f]+|NULL)',line)
   if not m:continue
   argv=[ast.literal_eval(s) for s in re.findall(r'"(?:[^"\\]|\\.)*"',m[2])]
   if '--crate-name' not in argv or argv[argv.index('--crate-name')+1]!=crate:continue
   if lib_only and '--test' in argv:continue
   choices.append((pid,f,argv,m[1],line))
 assert len(choices)==1,(crate,len(choices))
 pid,f,argv,img,line=choices[0];dirs=[];externs=[]
 for i,a in enumerate(argv):
  if a=='-L':dirs+=['-L',argv[i+1]]
  elif a.startswith('-L') and a!='-L':dirs.append(a)
  if a=='--extern':externs+=['--extern',argv[i+1]]
 return {'crate':crate,'argv_as_executed':argv,'exe':ast.literal_eval(img),'L_search_arguments':dirs,'extern_flags':externs,'trace_file':pid,'trace_sha256':sha(f),'matched_execve_line_sha256':hashlib.sha256(line.encode()).hexdigest()}
cases=[('initial','original-baseline','original','cold'),('edited','lexer-pending-indentation-edit','lexer-pending-indentation','lexer-pending-indentation-edit'),('restored','lexer-pending-indentation-restore','original','lexer-pending-indentation-restore')]
try:
 for tag,sample,view,source_trace in cases:
  fresh=q/'receipts/test/B'/(sample+'-fresh');stop=time.monotonic()+3000
  while not (fresh/'receipt.json').is_file():
   assert time.monotonic()<stop and not (q/'failure.txt').exists(),(sample,'missing fresh')
   time.sleep(.5)
  before_label=(state/'source-state').read_text();assert before_label==view,(tag,before_label)
  r=j(fresh/'receipt.json');assert r['fresh_units']==r['unit_count']==619 and not r['processes']['jobs'] and not any(r['processes']['native'].values()) and r['source_view']==view
  candidates=[]
  for l in (fresh/'stdout').read_bytes().splitlines():
   row=json.loads(l)
   if row.get('reason')=='compiler-artifact' and row['target']['name']=='ruff_python_parser' and row['target']['kind']==['lib'] and not row['profile']['test']:candidates.extend(Path(v) for v in row['filenames'] if v.endswith('.rmeta'))
  logical,=candidates;real=physical(logical);dest=out/tag;dest.mkdir()
  src=state/'inputs/crates/ruff_python_parser/src/lexer.rs';expected=j(q/'fixture/manifest.json')[view]['crates/ruff_python_parser/src/lexer.rs'];assert sha(src)==expected
  with real.open('rb') as inp:
   f0=facts(os.fstat(inp.fileno()));payload=inp.read();f1=facts(os.fstat(inp.fileno()))
  assert f0==f1==facts(real.stat()) and len(payload)==f0[2]
  (dest/logical.name).write_bytes(payload);shutil.copyfile(src,dest/'lexer.rs')
  assert (state/'source-state').read_text()==view and sha(dest/'lexer.rs')==expected and sha(real)==sha(dest/logical.name)
  trace=q/'receipts/test/B'/source_trace
  providers={cr:select_trace(trace,cr,True) for cr in ('ruff_python_parser','ruff_linter')}
  assert all(v['L_search_arguments'] for v in providers.values())
  binding=j(W/'binding.json')
  dump(dest/'receipt.json',{'arm':'B','input_label':view,'sample':sample,'active_raw_state':str(state),'observed_successful_fresh':str(fresh),'fresh_receipt_sha256':sha(fresh/'receipt.json'),'real_target_path':str(real),'compiler_reported_path':str(logical),'file_stamp':f0,'rmeta_bytes':len(payload),'rmeta_sha256':sha(dest/logical.name),'lexer_rs_sha256':expected,'source_index':j(q/'preflight.json')['source_index'],'release_driver':binding['arms']['B'],'frontend':binding['host']['host_tools']['rustc_frontend'],'trace_inputs':providers})
  print(tag,sha(dest/logical.name),len(payload),flush=True)
 dump(out/'complete.json',{t:sha(out/t/'receipt.json') for t,*_ in cases})
except BaseException:
 (out/'failure.txt').write_text(traceback.format_exc());raise
