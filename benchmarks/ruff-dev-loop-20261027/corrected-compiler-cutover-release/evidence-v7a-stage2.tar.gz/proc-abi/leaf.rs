extern crate foreign_macro; fn main(){println!("{}",foreign_macro::val!());}
