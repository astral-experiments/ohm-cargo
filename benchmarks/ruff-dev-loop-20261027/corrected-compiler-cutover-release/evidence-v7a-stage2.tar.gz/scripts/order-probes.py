"""Check raw DefId dependencies against declaration-order changes at fixed Rust source paths."""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

root,home=(Path(a).resolve() for a in sys.argv[1:])
root.mkdir()
env=dict(os.environ,RUSTUP_HOME=str(home))
cases={
    "declarations":("pub struct Public {pub value:u32;} struct Decoy {decoy:u64;}","struct Decoy {decoy:u64;} pub struct Public {pub value:u32;}"),
    "modules":("mod aa; mod bb; pub use aa::Public;","mod bb; mod aa; pub use aa::Public;"),
    "include":('include!("aa.rs"); include!("bb.rs");','include!("bb.rs"); include!("aa.rs");'),
    "expansion":('macro_rules! aa {()=>{include!("aa.rs");}} macro_rules! bb {()=>{include!("bb.rs");}} aa!(); bb!();',
                 'macro_rules! aa {()=>{include!("aa.rs");}} macro_rules! bb {()=>{include!("bb.rs");}} bb!(); aa!();'),
}
summary={}
for name,(original,edited) in cases.items():
    cwd=root/name
    cwd.mkdir()
    # The exported declaration has the same source file and byte positions in the separate-file cases.
    (cwd/"aa.rs").write_text("pub struct Public { pub value: u32 }\n")
    (cwd/"bb.rs").write_text("#[allow(dead_code)] struct Decoy { decoy: u64 }\n")
    (cwd/"bridge.rs").write_text('extern crate seed; pub use seed::Public; #[inline] pub fn read(x:seed::Public)->u32 {x.value}\n')
    (cwd/"leaf.rs").write_text('extern crate bridge; pub fn f()->u32{bridge::read(bridge::Public{value:7})}\n')
    paths={}
    def run(label,*args,check=True):
        cmd=["rustc","+ohm",*map(str,args)]
        proc=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True)
        for key,data in [("stdout",proc.stdout),("stderr",proc.stderr)]:
            (cwd/(label+"."+key)).write_bytes(data)
        paths[label]=dict(cmd=cmd,exit=proc.returncode)
        if check: assert proc.returncode==0,(name,label,proc.stderr[:700])
        return proc
    def build(label,crate,*args,check=True):
        return run(label,crate+".rs","--edition=2024","--crate-name",crate,"--crate-type=rlib","--emit=metadata","--error-format=json",*args,check=check)
    def capture(stage,body):
        (cwd/"seed.rs").write_text("#![allow(dead_code)]\n"+body.replace("u32;}","u32}").replace("u64;}","u64}")+"\n")
        build(stage+"-producer","seed")
        diag=run(stage+"-meta","libseed.rmeta","-Zls=root").stdout
        private,public=re.search(rb"private hash ([0-9a-f]+).*\npublic_hash ([0-9a-f]+)",diag).groups()
        hir=run(stage+"-hir","seed.rs","--crate-name","seed","--crate-type=rlib","-Zunpretty=hir-tree").stdout
        defs=sorted(set(re.findall(rb"DefId\(0:(\d+) ~ seed\[[0-9a-f]+\]::(?:aa::)?Public\)",hir)))
        assert len(defs)==1,(name,defs)
        return dict(private=private.decode(),public=public.decode(),defindex=int(defs[0]),digest=hashlib.sha256((cwd/"libseed.rmeta").read_bytes()).hexdigest())
    def leaf(phase):
        c=build(phase,"leaf","--extern","bridge=libbridge.rmeta","-Ldependency=.",check=False)
        msg=[(j.get("code") or {}).get("code") for j in map(json.loads,c.stderr.splitlines()) if j.get("level")=="error"]
        return dict(exit=c.returncode,ice=b"panicked at" in c.stderr,codes=msg)
    before=capture("old",original)
    build("old-bridge","bridge","--extern","seed=libseed.rmeta")
    base=leaf("original")
    assert base["exit"]==0
    after=capture("new",edited)
    stale=leaf("stale")
    build("rebuilt-bridge","bridge","--extern","seed=libseed.rmeta")
    fresh=leaf("fresh")
    assert fresh["exit"]==0
    summary[name]=dict(before=before,after=after,stale=stale,base=base,fresh=fresh)
    (cwd/"commands.json").write_text(json.dumps(paths,indent=2)+"\n")
    print(name,before["private"]==after["private"],before["defindex"],after["defindex"],stale,flush=True)
(root/"result.json").write_text(json.dumps(summary,indent=2)+"\n")
