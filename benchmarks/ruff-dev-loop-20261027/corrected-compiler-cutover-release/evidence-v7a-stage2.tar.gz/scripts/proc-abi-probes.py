"""Load real procedural-macro libraries across the metadata epoch in fresh native callers."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root,old_home,new_home=(Path(x).resolve() for x in sys.argv[1:])
root.mkdir()
homes={"legacy":old_home,"current":new_home}
macro_src=root/"procedural.rs"
macro_src.write_text('extern crate proc_macro; use proc_macro::{Literal,Span,TokenStream,TokenTree}; #[proc_macro] pub fn val(_:TokenStream)->TokenStream {let mut t=Literal::u32_suffixed(7);t.set_span(Span::mixed_site());TokenTree::Literal(t).into()}\n')
leaf=root/"leaf.rs"
leaf.write_text('extern crate foreign_macro; fn main(){println!("{}",foreign_macro::val!());}\n')
out=dict(selectors={},libraries={},cases={})
def run(label,epoch,*cmd):
    proc=subprocess.run(list(map(str,cmd)),cwd=root,capture_output=True,env=dict(os.environ,RUSTUP_HOME=str(homes[epoch])))
    (root/(label+".stdout")).write_bytes(proc.stdout)
    (root/(label+".stderr")).write_bytes(proc.stderr)
    return proc
for epoch,home in homes.items():
    out["selectors"][epoch]=json.loads((home/"receipt.json").read_bytes())["sha256"]
    arm=root/epoch
    arm.mkdir()
    dst=arm/"libforeign_macro.so"
    compile=run(epoch,epoch,"rustc","+ohm",macro_src,"--edition=2024","--crate-type=proc-macro","--crate-name","foreign_macro","-o",dst)
    assert compile.returncode==0,compile.stderr
    out["libraries"][epoch]=hashlib.sha256(dst.read_bytes()).hexdigest()
for reader in homes:
    for library in homes:
        label=reader+"-reads-"+library
        dst=root/(label+".bin")
        proc=run(label,reader,"rustc","+ohm",leaf,"--edition=2024","--error-format=json","--extern","foreign_macro="+str(root/library/"libforeign_macro.so"),"-o",dst)
        errors=[(j.get("code") or {}).get("code") for j in map(json.loads,proc.stderr.splitlines()) if j.get("level")=="error"]
        data=dict(exit=proc.returncode,ice=b"panicked at" in proc.stderr,errors=errors)
        if proc.returncode==0:
            result=run(label+".runtime",reader,dst)
            data.update(runtime_exit=result.returncode,stdout=result.stdout.decode())
            assert result.returncode==0 and result.stdout==b"7\n"
        assert not data["ice"]
        assert (data["exit"]==0 if reader==library else data["exit"]!=0 and errors[0]=="E0514"),(label,data)
        out["cases"][label]=data
        print(label,data,flush=True)
(root/"result.json").write_text(json.dumps(out,indent=2)+"\n")
