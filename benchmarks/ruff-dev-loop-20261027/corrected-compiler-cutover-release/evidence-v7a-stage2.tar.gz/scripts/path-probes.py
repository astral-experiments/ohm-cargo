"""Exercise legacy metadata eligibility in isolated synthetic host/target rustlib directories."""
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

root, old_home, new_home = (Path(a).resolve() for a in sys.argv[1:])
root.mkdir(exist_ok=False)
rec=json.loads((new_home/"receipt.json").read_bytes())
runtime=Path(rec["sysroot"])
driver=Path(rec["driver"])
assert hashlib.sha256(driver.read_bytes()).hexdigest()==rec["sha256"]
old=dict(os.environ,RUSTUP_HOME=str(old_home))
triple="x86_64-unknown-linux-gnu"
prefix='#![feature(no_core,lang_items)]\n#![allow(internal_features)]\n#![no_core]\n'
lang='#[lang="pointee_sized"] pub trait PointeeSized {}\n#[lang="meta_sized"] pub trait MetaSized:PointeeSized {}\n#[lang="sized"] pub trait Sized:MetaSized {}\n#[lang="copy"] pub trait Copy {}\n'
source=root/"src"
source.mkdir()
(source/"seed.rs").write_text(prefix+lang+"pub struct Token;\n")
(source/"bridge.rs").write_text(prefix+"extern crate seed; pub use seed::Token;\n")
(source/"leaf.rs").write_text(prefix+"extern crate middle; pub use middle::Token;\n")
def invoke(env,src,name,dst,extra,log):
    cmd=["rustc","+ohm",src,"--crate-name",name,"--edition","2024","--crate-type=rlib","--emit=metadata","--error-format=json","-o",dst,*extra]
    proc=subprocess.run(cmd,cwd=root,env=env,capture_output=True)
    (log.parent/(log.name+".stdout")).write_bytes(proc.stdout)
    (log.parent/(log.name+".stderr")).write_bytes(proc.stderr)
    errors=[j for j in map(json.loads,proc.stderr.splitlines()) if isinstance(j,dict) and j.get("level")=="error"]
    return dict(cmd=[str(x) for x in cmd],exit=proc.returncode,ice=b"panicked at" in proc.stderr,
                errors=[dict(code=(j.get("code") or {}).get("code"),message=j.get("message")) for j in errors])
legacy=root/"legacy"
legacy.mkdir()
seed=legacy/"libseed.rmeta"
middle=legacy/"libmiddle.rmeta"
first=invoke(old,source/"seed.rs","seed",seed,[],root/"legacy-seed")
assert first["exit"]==0,first
second=invoke(old,source/"bridge.rs","middle",middle,["--extern","seed="+str(seed)],root/"legacy-bridge")
assert second["exit"]==0,second
current_dir=root/"current"
current_dir.mkdir()
current_seed=current_dir/seed.name
current_env=dict(os.environ,RUSTUP_HOME=str(new_home))
third=invoke(current_env,source/"seed.rs","seed",current_seed,[],root/"current-seed")
assert third["exit"]==0,third
seed_owners={}
for epoch,env,artifact in [("legacy",old,seed),("current",current_env,current_seed)]:
    query=subprocess.run(["rustc","+ohm",str(artifact),"-Zls=root"],env=env,capture_output=True,check=True)
    (root/(epoch+"-seed-header.txt")).write_bytes(query.stdout)
    private,public=re.search(rb"private hash ([0-9a-f]+).*\npublic_hash ([0-9a-f]+)",query.stdout).groups()
    seed_owners[epoch]=dict(private=private.decode(),public=public.decode(),sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
assert seed_owners["legacy"]["private"]==seed_owners["current"]["private"],seed_owners
cases=["physical","sibling-prefix","symlink-inside-to-outside","symlink-outside-to-inside","current-external",
       "legacy-transitive-physical","legacy-transitive-external","legacy-transitive-current-inside","legacy-transitive-current-external"]
rows={}
for case in cases:
    cwd=root/case
    cwd.mkdir()
    sdk=cwd/"sdk"
    lib=sdk/"lib/rustlib"/triple/"lib"
    lib.mkdir(parents=True)
    lookalike=lib.parent/"lib-sibling"
    lookalike.mkdir()
    tool=cwd/"rustup"
    bin_dir=tool/"toolchains/ohm/bin"
    bin_dir.mkdir(parents=True)
    (tool/"settings.toml").write_text('version = "12"\nprofile = "minimal"\n')
    wrapper=bin_dir/"rustc"
    wrapper.write_text('#!/bin/sh\nexport LD_LIBRARY_PATH='+shlex.quote(str(driver.parent)+":"+str(runtime/"lib"))+
                       '\nexec '+shlex.quote(str(runtime/"bin/rustc"))+' --sysroot '+shlex.quote(str(sdk))+' "$@"\n')
    wrapper.chmod(0o755)
    new=dict(os.environ,RUSTUP_HOME=str(tool))
    if not case.startswith("legacy-transitive"):
        if case=="physical":
            supplied=lib/seed.name
            shutil.copyfile(seed,supplied)
        elif case in ("sibling-prefix","current-external"):
            supplied=lookalike/seed.name
            shutil.copyfile(current_seed if case=="current-external" else seed,supplied)
        elif case=="symlink-inside-to-outside":
            target=lookalike/seed.name
            shutil.copyfile(seed,target)
            supplied=lib/seed.name
            supplied.symlink_to(target)
        else:
            target=lib/seed.name
            shutil.copyfile(seed,target)
            supplied=lookalike/seed.name
            supplied.symlink_to(target)
        src=source/"bridge.rs"
        extra=["--extern","seed="+str(supplied)]
    else:
        supplied=lib/middle.name
        shutil.copyfile(middle,supplied)
        dep_dir=lib if case in ("legacy-transitive-physical","legacy-transitive-current-inside") else lookalike
        dependency=dep_dir/seed.name
        shutil.copyfile(current_seed if "-current-" in case else seed,dependency)
        src=source/"leaf.rs"
        extra=["--extern","middle="+str(supplied),"-L","dependency="+str(dep_dir)]
    data=invoke(new,src,"review_leaf",cwd/"libleaf.rmeta",extra,cwd/"out")
    data.update(supplied=str(supplied),canonical=str(supplied.resolve()),expected_library_dir=str(lib.resolve()),
                input_sha256=hashlib.sha256(supplied.read_bytes()).hexdigest())
    if case.startswith("legacy-transitive"):
        data.update(dependency=str(dependency),dependency_sha256=hashlib.sha256(dependency.read_bytes()).hexdigest())
    rows[case]=data
    print(case,data["exit"],data["errors"],flush=True)
(root/"result.json").write_text(json.dumps(dict(driver=rec["sha256"],legacy_compiler=json.loads((old_home/"receipt.json").read_bytes())["sha256"],
                                                seed=first,middle=second,current_seed=third,owners=seed_owners,cases=rows),indent=2)+"\n")
