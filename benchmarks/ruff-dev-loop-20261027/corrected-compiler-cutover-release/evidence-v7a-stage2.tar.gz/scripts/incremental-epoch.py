"""Compile unchanged source in one incremental cache across both directions of the metadata cutover."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root,old_home,new_home=(Path(x).resolve() for x in sys.argv[1:])
root.mkdir()
source=root/"subject.rs"
source.write_text('macro_rules! value {()=>{7_u32}} #[inline] pub fn value()->u32{value!()}\n')
sessions=root/"sessions"
rows=[]
for sequence,(compiler,home,version) in enumerate([("old",old_home,0),("new",new_home,1),("new",new_home,1),("old",old_home,0)]):
    env=dict(os.environ,RUSTUP_HOME=str(home))
    cmd=["rustc","+ohm","subject.rs","--crate-name","subject","--crate-type=rlib","--edition=2024","-C","incremental="+str(sessions),"-o","libsubject.rlib"]
    proc=subprocess.run(cmd,cwd=root,env=env,capture_output=True)
    (root/f"{sequence}.stderr").write_bytes(proc.stderr)
    assert proc.returncode==0 and not proc.stderr,(sequence,proc.stderr)
    current=sorted(d for crate in sessions.iterdir() for d in crate.iterdir() if d.is_dir() and not d.name.endswith("working"))
    # Rustc records the running session as the newest directory in the crate-specific cache.
    work=max(current,key=lambda p:p.stat().st_mtime_ns)
    files={}
    for artifact in work.glob("*.bin"):
        raw=artifact.read_bytes()
        assert raw[:4]==b"RSIC" and int.from_bytes(raw[4:6],"little")==version,(work,artifact,raw[:6],version)
        files[artifact.name]=dict(header=raw[:6].hex(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    assert {"dep-graph.bin","query-cache.bin","work-products.bin"}<=files.keys(),files
    cmd_ar=["ar","p","libsubject.rlib","lib.rmeta"]
    member=subprocess.run(cmd_ar,cwd=root,check=True,capture_output=True).stdout
    assert member.startswith(b"\x7fELF")
    (root/f"{sequence}-lib.rmeta").write_bytes(member)
    rows.append(dict(step=sequence,compiler=compiler,driver=json.loads((home/"receipt.json").read_bytes())["sha256"],cmd=cmd,status=proc.returncode,session=str(work),
                     file_headers=files,rmeta_sha256=hashlib.sha256(member).hexdigest(),rlib_sha256=hashlib.sha256((root/"libsubject.rlib").read_bytes()).hexdigest()))
assert rows[1]["rmeta_sha256"]==rows[2]["rmeta_sha256"] and rows[1]["rmeta_sha256"]!=rows[0]["rmeta_sha256"] and rows[3]["rmeta_sha256"]==rows[0]["rmeta_sha256"],rows
print("Unchanged-source incremental reuse and clean cutover:",[next(iter(r["file_headers"].values()))["header"] for r in rows],flush=True)
(root/"result.json").write_text(json.dumps(rows,indent=2)+"\n")
