"""Independently check native return codes, parser diagnostics, visible macro owners and stored crate headers."""
import hashlib
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parent
summary=json.loads((root/"summary.json").read_bytes())
with (root/"SHA256SUMS").open() as manifest:
    for line in manifest:
        expected,name=line.rstrip("\n").split("  ",1)
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name

def inspect(key):
    row=summary[key]
    raw=root/"raw"/key
    src=json.loads((raw/"result.json").read_bytes())
    commands=json.loads((raw/"commands.json").read_bytes())
    for phase in ["producer_original","producer_edited"]:
        header=raw/(phase+".root.txt")
        if header.exists():
            p,q=re.search(r"private hash ([0-9a-f]+).*\npublic_hash ([0-9a-f]+)",header.read_text()).groups()
            assert (p,q)==(row[phase]["private_hash"],row[phase]["public"].split()[-1])
    for phase in ["original","stale","regenerated"]:
        cell=row["cells"][phase]
        assert cell["compiler_exit"]==src[phase]["compiler_exit"]==commands[cell["step"]-1]["status"]
        logs=list(map(json.loads,(raw/(phase+".stdout.jsonl")).read_bytes().splitlines()))
        stderr=(raw/(phase+".stderr")).read_bytes()
        assert cell["ice"]==(b"panicked at" in stderr or b"compiler unexpectedly panicked" in stderr)
        errors=[{"code": (j["message"]["code"] or {}).get("code"),"message":j["message"]["message"]}
                for j in logs if j.get("reason")=="compiler-message" and j["message"]["level"]=="error"]
        assert cell["errors"]==errors
        if cell["compiler_exit"]==0:
            assert cell["stdout"]=="7\n" and cell["exit"]==0 and not errors
            assert all(not j["fresh"] for j in logs if j.get("reason")=="compiler-artifact")
    return row


for k in summary:
    inspect(k)
def x(name):
    found=[k for k in summary if k.split("/")[-1]==name]
    assert len(found)==1,(name,found)
    return inspect(found[0])
def result(name,phase="stale"):
    c=x(name)["cells"][phase]
    return "ICE" if c["ice"] else "OK" if c["compiler_exit"]==0 else "/".join(str(e["code"]) for e in c["errors"])

assert result("paired-232-source-equivalent")=="E0460"
reg=x("paired-233-source-equivalent")
assert reg["producer_original"]["public"]==reg["producer_edited"]["public"]
assert reg["cells"]["stale"]["compiler_exit"]!=0 and any(e["code"]=="E0391" for e in reg["cells"]["stale"]["errors"])
assert reg["cells"]["regenerated"]["stdout"]=="7\n"
assert all(result(n)=="ICE" for n in ["released-empty-cold-public","released-empty-cold-ordinary","released-proc-mixed-cold"])
for name,expect in {
    "expansion-ordinary":"OK","expansion-public":"OK","expansion-removed":"E0460",
    "private-defid-ordinary":"E0460","private-defid-public":"OK","proc-mixed-site":"OK",
    "old-reader-new-writer":"E0514","new-reader-new-occupied-slot":"OK",
    "new-reader-old-exact-public":"E0514","new-reader-old-stale-public":"E0514",
    "new-reader-old-stale-ordinary":"E0514","new-reader-old-occupied-slot":"E0514",
    "old-reader-old-all-ordinary-empty":"ICE", "old-reader-old-all-ordinary-private":"E0460",
}.items():
    assert result(name)==expect,(name,result(name),expect)
matrix={k.split("/")[0] for k in summary if not k.startswith("controls/")}
assert len(matrix)==1,matrix
label=next(iter(matrix))
if "v7a" in label:
    for name in ["new-reader-old-all-ordinary-empty","new-reader-old-all-ordinary-private","new-reader-old-exact-ordinary",
                 "new-reader-old-bridge-new-producer"]:
        assert result(name)=="E0514",name
    for name in ("new-reader-old-exact-ordinary","new-reader-old-exact-public","new-reader-old-stale-public",
                 "new-reader-old-stale-ordinary","new-reader-old-all-ordinary-empty","new-reader-old-all-ordinary-private",
                 "new-reader-old-occupied-slot","old-reader-new-writer"):
        assert result(name,"regenerated")=="E0514",name
    for name in ("expansion-public","expansion-ordinary","private-defid-public","private-defid-ordinary",
                 "expansion-removed","proc-mixed-site","new-reader-old-bridge-new-producer","new-reader-new-occupied-slot"):
        assert result(name,"regenerated")=="OK",name
    for name in ["expansion-public","expansion-ordinary","proc-mixed-site","new-reader-new-occupied-slot"]:
        before=(root/"raw"/label/name/"original-consumer-hygiene.rs").read_text()
        stale=(root/"raw"/label/name/"stale-consumer-hygiene.rs").read_text()
        after=(root/"raw"/label/name/"regenerated-consumer-hygiene.rs").read_text()
        assert re.search(r'crate\d+::\{\{expn2\}\}.*kind: Macro\(Bang, "make"\)',before),name
        assert re.search(r'crate\d+::\{\{expn3\}\}.*kind: Macro\(Bang, "make"\)',after),name
        assert re.search(r'crate\d+::\{\{expn3\}\}.*kind: Macro\(Bang, "make"\)',stale),name
    ordinary=x("new-reader-old-all-ordinary-empty")
    assert ordinary["producer_original"]["private_hash"]==ordinary["producer_edited"]["private_hash"]
    sdk=json.loads((root/"sdk/result.json").read_bytes())
    current=json.loads(next((root/"drivers").glob("v7a-stage"+("2" if "stage2" in label else "1")+".json")).read_bytes())
    assert sdk["driver"]==current["sha256"]
    owners=sdk["owners"]
    assert owners["current"]["private"]==owners["legacy"]["private"]==owners["legacy"]["public"]==owners["current"]["public"]
    assert owners["current"]["sha256"]!=owners["legacy"]["sha256"]
    for role in ("current","legacy"):
        header=(root/"sdk"/(role+"-seed-header.txt")).read_text()
        assert re.search(r"private hash ([a-f0-9]+)",header)[1]==owners[role]["private"]
        assert re.search(r"public_hash ([a-f0-9]+)",header)[1]==owners[role]["public"]
    sdk_expect={"physical":"OK","sibling-prefix":"E0514","symlink-inside-to-outside":"E0514","symlink-outside-to-inside":"OK",
                "current-external":"OK","legacy-transitive-physical":"OK","legacy-transitive-external":"E0514",
                "legacy-transitive-current-inside":"E0463","legacy-transitive-current-external":"E0463"}
    assert set(sdk_expect)==set(sdk["cases"])
    for name,expect in sdk_expect.items():
        c=sdk["cases"][name]
        raw=(root/"sdk"/(name+".stderr")).read_bytes()
        diagnostics=[j for j in map(json.loads,raw.splitlines()) if j.get("level")=="error"]
        codes=[(j.get("code") or {}).get("code") for j in diagnostics]
        assert c["errors"]==[{"code":(j.get("code") or {}).get("code"),"message":j["message"]} for j in diagnostics]
        assert not c["ice"] and b"panicked at" not in raw,name
        assert ("OK" if c["exit"]==0 and not codes else "/".join(p for p in codes if p))==expect,(name,codes)
        if name.startswith("legacy-transitive"):
            dep_epoch="current" if "-current-" in name else "legacy"
            assert c["dependency_sha256"]==owners[dep_epoch]["sha256"]
        else:
            assert c["input_sha256"]==owners["current" if name=="current-external" else "legacy"]["sha256"]
        if name=="symlink-inside-to-outside":
            assert Path(c["supplied"]).parent==Path(c["expected_library_dir"])!=Path(c["canonical"]).parent
        if name=="symlink-outside-to-inside":
            assert Path(c["supplied"]).parent!=Path(c["expected_library_dir"])==Path(c["canonical"]).parent
else:
    assert result("new-reader-old-exact-ordinary")=="OK"
    assert result("new-reader-old-all-ordinary-empty")=="ICE"
    assert result("new-reader-old-all-ordinary-private")=="E0460"
    assert result("new-reader-old-bridge-new-producer")=="E0514"
key=next(k for k in summary if k.endswith("/v5-legacy-wrong-valid-slot"))
base=root/"raw"/key
stale=(base/"stale-consumer-hygiene.rs").read_text()
regenerated=(base/"regenerated-consumer-hygiene.rs").read_text()
assert re.search(r'crate\d+::\{\{expn2\}\}.*kind: Macro\(Bang, "noise"\)',stale)
assert re.search(r'crate\d+::\{\{expn3\}\}.*kind: Macro\(Bang, "make"\)',regenerated)
if (root/"proc-abi").is_dir():
    abi=json.loads((root/"proc-abi/result.json").read_bytes())
    assert abi["selectors"]["legacy"]!=abi["selectors"]["current"]
    assert abi["libraries"]["legacy"]!=abi["libraries"]["current"]
    for name,d in abi["cases"].items():
        reader,writer=name.split("-reads-")
        codes=[(j.get("code") or {}).get("code") for j in map(json.loads,(root/"proc-abi"/(name+".stderr")).read_bytes().splitlines()) if j.get("level")=="error"]
        assert codes==d["errors"] and not d["ice"]
        if reader==writer:
            assert (d["exit"],d["runtime_exit"],d["stdout"])==(0,0,"7\n")
            assert (root/"proc-abi"/(name+".runtime.stdout")).read_text()=="7\n"
        else:
            assert d["exit"]==1 and codes[0]=="E0514"
    order=json.loads((root/"order/result.json").read_bytes())
    for name,d in order.items():
        dir=root/"order"/name
        assert d["before"]["defindex"]!=d["after"]["defindex"] and d["before"]["private"]!=d["after"]["private"]
        assert d["fresh"]["exit"]==0 and d["base"]["exit"]==0 and d["stale"]["codes"][0]=="E0460" and not d["stale"]["ice"]
        for phase,stage in [("before","old"),("after","new")]:
            header=(dir/(stage+"-meta.stdout")).read_text()
            assert re.search(r"private hash ([a-f0-9]+)",header)[1]==d[phase]["private"]
            pat=r"DefId\(0:"+str(d[phase]["defindex"])+r" ~ seed\[[0-9a-f]+\]::(?:aa::)?Public\)"
            assert re.search(pat,(dir/(stage+"-hir.stdout")).read_text())
        assert b"E0460" in (dir/"stale.stderr").read_bytes()
if (root/"incremental").is_dir():
    inc=json.loads((root/"incremental/result.json").read_bytes())
    subject=json.loads((root/"drivers/v7a-stage2.json").read_bytes())["sha256"]
    parent=json.loads((root/"drivers/r233-stage2.json").read_bytes())["sha256"]
    build=json.loads((root/"drivers/release-build.json").read_bytes())
    assert build["candidate_postbolt"]==subject
    assert [cell["driver"] for cell in inc]==[parent,subject,subject,parent]
    hashes=[]
    for i,cell in enumerate(inc):
        version=1 if i in (1,2) else 0
        assert set(cell["file_headers"])=={"dep-graph.bin","query-cache.bin","work-products.bin"}
        assert all(bytes.fromhex(x["header"])==b"RSIC"+version.to_bytes(2,"little") for x in cell["file_headers"].values())
        data=(root/"incremental"/f"{i}-lib.rmeta").read_bytes()
        hashes.append(hashlib.sha256(data).hexdigest())
        assert hashes[-1]==cell["rmeta_sha256"] and cell["status"]==0
        assert not (root/"incremental"/f"{i}.stderr").read_bytes()
    assert hashes[1]==hashes[2] and hashes[0]==hashes[3] and hashes[0]!=hashes[1]
print(f"{len(summary)} complete cases. Raw diagnostics, return codes, runtime results and metadata headers verified.")
for key in sorted(k for k in summary if not k.startswith("controls/")):
    print(key.rsplit("/",1)[-1],result(key.rsplit("/",1)[-1]))
