macro_rules! value {()=>{7_u32}} #[inline] pub fn value()->u32{value!()}
