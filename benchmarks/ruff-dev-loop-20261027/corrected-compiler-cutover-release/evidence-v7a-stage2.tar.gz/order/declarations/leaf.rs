extern crate bridge; pub fn f()->u32{bridge::read(bridge::Public{value:7})}
