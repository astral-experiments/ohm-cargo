pub struct Public { pub value: u32 }
