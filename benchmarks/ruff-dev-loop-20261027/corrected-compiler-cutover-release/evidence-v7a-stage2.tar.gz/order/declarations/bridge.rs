extern crate seed; pub use seed::Public; #[inline] pub fn read(x:seed::Public)->u32 {x.value}
