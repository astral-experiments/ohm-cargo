#[allow(dead_code)] struct Decoy { decoy: u64 }
