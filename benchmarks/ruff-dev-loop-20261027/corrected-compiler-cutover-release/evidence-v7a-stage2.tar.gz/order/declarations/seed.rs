#![allow(dead_code)]
struct Decoy {decoy:u64} pub struct Public {pub value:u32}
