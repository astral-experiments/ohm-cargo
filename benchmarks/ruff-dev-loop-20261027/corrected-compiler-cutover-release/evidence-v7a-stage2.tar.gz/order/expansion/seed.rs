#![allow(dead_code)]
macro_rules! aa {()=>{include!("aa.rs");}} macro_rules! bb {()=>{include!("bb.rs");}} bb!(); aa!();
