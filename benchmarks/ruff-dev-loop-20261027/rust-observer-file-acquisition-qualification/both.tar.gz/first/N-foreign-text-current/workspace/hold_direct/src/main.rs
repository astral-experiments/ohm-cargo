use hold_probe::foreign_text;
use hold_shapes::Number;
use hold_probe::native_offset;
const _: Option<Number> = None;
fn main(){println!("sample={}",escape_fixture::sampled!(foreign_text));println!("{} {}",hold_shapes::count(),hold_tokens::inspect_value!(native_offset));}
