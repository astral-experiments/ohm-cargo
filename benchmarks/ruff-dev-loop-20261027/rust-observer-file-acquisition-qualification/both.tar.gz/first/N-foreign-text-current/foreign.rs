#[macro_export]
macro_rules! sampled { ($gate:ident) => { $gate!(foreign_marker) }; }
// private note 29
