actual.d: client.rs

libclient.rlib: client.rs

client.rs:
