#![feature(proc_macro_tracked_path)]

extern crate proc_macro;

use proc_macro::{Literal, TokenStream, TokenTree};

#[proc_macro]
pub fn read_span(input: TokenStream) -> TokenStream {
    let span = input.into_iter().next().unwrap().span();
    TokenTree::Literal(Literal::string(&format!("{span:?}"))).into()
}

#[proc_macro]
pub fn read_text(input: TokenStream) -> TokenStream {
    let text = input.into_iter().next().unwrap().span().source_text();
    TokenTree::Literal(Literal::string(&format!("{text:?}"))).into()
}

#[proc_macro]
pub fn read_text_then_edit(input: TokenStream) -> TokenStream {
    let result = read_text(input);
    let source = std::fs::read_to_string("output.rs").unwrap();
    std::fs::write("output.rs", source.replace("Unrelated note", "Unrelated edit")).unwrap();
    result
}

#[proc_macro]
pub fn tracked_read(_: TokenStream) -> TokenStream {
    proc_macro::tracked::path("tracked.txt");
    let observed = std::fs::read_to_string("tracked.txt").unwrap();
    std::fs::write("tracked.txt", "29").unwrap();
    TokenTree::Literal(Literal::string(&observed)).into()
}

#[proc_macro]
pub fn discard(input: TokenStream) -> TokenStream {
    drop(input.clone());
    TokenTree::Literal(Literal::u8_suffixed(0)).into()
}
