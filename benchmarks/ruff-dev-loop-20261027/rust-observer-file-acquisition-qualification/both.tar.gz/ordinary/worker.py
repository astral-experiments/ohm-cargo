from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess,sys
R=Path('/mnt/devbox-scratch/dev-user/ohm-rust-observer-foreign-guard-audit-20261028');O=R/'ordinary-native';active=O/'active';sdk=Path('/dev/shm/ohm-observer-protocol-h1-20261027/optional-native-pilot1-20261028/N-common/active-sdk');driver=sdk/'lib/librustc_driver-774a793a844d5500.so'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
put=lambda p,x:p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='inside':
    arm=sys.argv[2];assert sha(driver)==json.loads((O/'binding.json').read_bytes())['arms'][arm]
    rustup=active/'rustup';(rustup/'toolchains').mkdir(parents=True);(rustup/'toolchains/ohm').symlink_to(sdk);env=dict(os.environ,RUSTUP_HOME=str(rustup),RUSTUP_AUTO_INSTALL='0',RUSTC_BOOTSTRAP='1')
    rows={}
    for mode in ['tracked','clone_only','local']:
        for label,flags in [('default',['-Zcache-proc-macros']),('explicit-request',['-Zohm-observer-dep-info']),('binary-checksums',['-Zbinary-dep-depinfo','-Zchecksum-hash-algorithm=blake3'])]:
            d=active/(mode+'-'+label);d.mkdir();(active/'tracked.txt').write_text('17')
            cmd=['rustc','+ohm','--edition=2021','--crate-type=bin','--crate-name','client','--cfg='+mode,'-Zpublic-api-hash',*flags,'--extern','probe='+str(active/'libprobe.so'),'--extern','leaf='+str(active/'libleaf.rlib'),'--emit','dep-info=actual.d,link=client','client.rs']
            p=subprocess.run(cmd,cwd=active,env=env,capture_output=True,check=True);(d/'stderr').write_bytes(p.stderr);(d/'stdout').write_bytes(p.stdout)
            q=subprocess.run([active/'client'],cwd=active,env=env,capture_output=True,check=True);assert not q.stderr
            (d/'native').write_bytes(q.stdout);shutil.copyfile(active/'actual.d',d/'actual.d')
            dep=(d/'actual.d').read_bytes();assert b'ohm-observer-inputs' not in dep and b'ohm-foreign-span-bytes' not in dep and b'ohm-untrackable-foreign-span' not in dep
            if mode=='tracked':assert q.stdout==b'17\n' and (active/'tracked.txt').read_bytes()==b'29' and b'tracked.txt' in dep
            if mode=='clone_only':assert q.stdout==b'\n'
            if mode=='local':assert b'bytes(' in q.stdout
            rows[mode+'-'+label]=dict(command=cmd,elf=sha(active/'client'),bytes=(active/'client').stat().st_size,dep=sha(d/'actual.d'),stderr=sha(d/'stderr'),stdout=sha(d/'stdout'),native_sha256=sha(d/'native'),runtime=q.stdout.decode(),status=p.returncode)
    put(active/'result.json',rows);sys.exit()
assert not O.exists();O.mkdir();active.mkdir();headers=R/'parent-runmake/case';arms={'parent':sha(driver),'fixed':sha(R/'release/candidate-driver.so')}
put(O/'binding.json',dict(arms=arms,sdk=str(sdk),frontend=sha(sdk/'bin/rustc'),frozen_prerequisites={f:sha(headers/f) for f in ['libprobe.so','libleaf.rlib','client.rs']}))
for arm in ('parent','fixed'):
    d=O/arm;d.mkdir()
    for f in ['libprobe.so','libleaf.rlib','client.rs']:shutil.copyfile(headers/f,d/f)
    cmd=['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--tmpfs','/tmp','--bind',str(d),str(active)]
    if arm=='fixed':cmd+=['--ro-bind',str(R/'release/candidate-driver.so'),str(driver)]
    cmd+=['--','taskset','-c','24-25',sys.executable,'-B',__file__,'inside',arm]
    p=subprocess.run(cmd,capture_output=True,timeout=120);(d/'log.stderr').write_bytes(p.stderr);assert p.returncode==0,(arm,p.stderr[-1200:])
before=json.loads((O/'parent/result.json').read_bytes());after=json.loads((O/'fixed/result.json').read_bytes());put(O/'complete.json',dict(rows=len(before),equal=before==after,details={k:[f for f in before[k] if before[k][f]!=after[k][f]] for k in before}));assert before==after
