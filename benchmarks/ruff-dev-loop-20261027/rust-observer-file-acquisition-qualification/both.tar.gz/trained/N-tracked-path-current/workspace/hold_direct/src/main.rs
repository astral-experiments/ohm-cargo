use hold_probe::wait_value;
use hold_shapes::Number;
use hold_probe::native_offset;
const _: Option<Number> = None;
fn main(){println!("sample={}",wait_value!(file));println!("{} {}",hold_shapes::count(),hold_tokens::inspect_value!(native_offset));}

const _: usize = core::mem::size_of::<u32>();
