from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess as sp,sys
base=Path('/mnt/devbox-scratch/dev-user/ohm-rust-observer-source-audit-20261028')
pilot=Path('/dev/shm/ohm-observer-protocol-h1-20261027/optional-native-pilot1-20261028')
inp=base/'inputs';kind=sys.argv[1];arm=sys.argv[2];assert kind in ('runmake','race','ron') and arm in ('parent','fixed')
sdkname='N-common';sdk=pilot/sdkname/'active-sdk'
driver=sdk/'lib/librustc_driver-774a793a844d5500.so';front=sdk/'bin/rustc'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
put=lambda p,v:p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
assert sha(front)=='4fa9a18b77430bcc416e88561b6fe5797d98b996a7698b9f3bd11d4e7817a19f'
assert sha(driver)=='ee9448c27a69a06a50abe707797637638dc6b2a226011339b35adc2b9a065b99'
def selected_cargo(code):
    p=pilot/'pinned-subjects'/code/'cargo'
    expected=json.loads((pilot/'pinned-subjects/shared-generation.json').read_bytes())['matched'][code]['binary']
    assert sha(p)==expected;return p
subject=driver
if arm=='fixed':
    subject=base/'release/candidate-driver.so';receipt=json.loads((base/'release/receipt.json').read_bytes())
    assert sha(subject)==receipt['candidate_postbolt'] and receipt['frontend']==sha(front)
out=base/(arm+'-'+kind);out.mkdir();assert shutil.disk_usage(base).free>8*2**30
def ns(code):
    return ['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--tmpfs','/tmp','--bind',str(out),str(out),'--ro-bind',str(subject),str(driver),'--ro-bind',str(selected_cargo(code)),str(sdk/'bin/cargo')]
put(out/'identity.json',dict(driver=sha(subject),frontend=sha(front),cargo={i:sha(selected_cargo(i)) for i in ('A','N','Q')},sdk=str(sdk),exercise=sha(inp/'exercise.py'),rmake=sha(inp/'rmake')))
def execute(args,where,expected=None,env=None):
    with (where/'command.stdout').open('xb') as so,(where/'command.stderr').open('xb') as se:
        result=sp.run(args,env=env,cwd=where,stdout=so,stderr=se,timeout=320)
    put(where/'command.json',dict(argv=args,status=result.returncode))
    if expected is not None:assert result.returncode==expected,(result.returncode,(where/'command.stderr').read_text()[-1450:])
    return result.returncode
if kind=='runmake':
    case=out/'case';shutil.copytree(inp/'run-make',case);home=out/'rustup';(home/'toolchains').mkdir(parents=True);(home/'toolchains/ohm').symlink_to(sdk)
    shim=out/'rustc-ohm';shim.write_text('#!/bin/sh\nexec /home/dev-user/.cargo/bin/rustc +ohm --sysroot '+shlex.quote(str(sdk))+' "$@"\n');shim.chmod(0o755)
    env=dict(os.environ,RUSTUP_HOME=str(home),RUSTUP_AUTO_INSTALL='0',RUSTC=str(shim),RUSTC_BOOTSTRAP='1',HOST_RUSTC_DYLIB_PATH=str(sdk/'lib'),TARGET_EXE_DYLIB_PATH=str(sdk/'lib/rustlib/x86_64-unknown-linux-gnu/lib'),LD_LIBRARY_PATH=str(sdk/'lib'),LD_LIB_PATH_ENVVAR='LD_LIBRARY_PATH',TARGET='x86_64-unknown-linux-gnu',HOST='x86_64-unknown-linux-gnu',TMPDIR=str(out))
    rc=execute([*ns('N'),'--','taskset','-c','24-25','strace','-f','-qq','-s','32000','-e','trace=execve','-o',str(out/'exec'),str(inp/'rmake')],case,env=env)
    if arm=='parent':assert rc!=0 and 'assertion' in (case/'command.stderr').read_text() and 'rmake.rs:104' in (case/'command.stderr').read_text(),(case/'command.stderr').read_text()[-1300:]
    else: assert rc==0,(case/'command.stderr').read_text()[-1500:]
    put(out/'complete.json',dict(status=rc,stderr=(case/'command.stderr').read_text(),trace=sha(out/'exec')))
elif kind=='race':
    allrows={}
    for code,why,stamp in [('N','foreign-text','current'),('N','foreign-text','preserved'),('N','tracked-path','current'),('N','tracked-path','preserved'),('Q','tracked-path','preserved'),('Q','foreign-text','preserved')]:
        name=f'{code}-{why}-{stamp}'; wrapper=out/(name+'-wrapper');wrapper.mkdir()
        execute([*ns(code),'--','taskset','-c','24-25','python3','-B',str(inp/'exercise.py'),str(sdk),str(out/name),why,stamp],wrapper,0)
        allrows[name]=json.loads((out/name/'complete.json').read_bytes())
        print(name,[(s,r['value'],r['caller_fresh'],r['claim_complete'],r['untrackable']) for s,r in allrows[name]['rows'].items()],flush=True)
    put(out/'complete.json',allrows)
else:
    source=inp/'ron-v3.py';temp=out/'ron.py'
    body=source.read_text()
    orig="N=Path(__file__).resolve().parent;D=N.parent; R=N/'ron-native-probe-v3';";assert body.count(orig)==1;body=body.replace(orig,"N=Path("+repr(str(pilot))+");D=N.parent; R=Path("+repr(str(out/'ron-state'))+");")
    assert body.count("for arm in ('A','N'):")==1;body=body.replace("for arm in ('A','N'):","for arm in ('N',):").replace("'0-3'","'24-25'")
    # The old worker uses its tmpfs location to implement a 3 GiB floor. The independent
    # new receipt lives on scratch, so measure the filesystem where its outputs land.
    body=body.replace('shutil.disk_usage(N)', 'shutil.disk_usage(R)')
    temp.write_text(body)
    # The inner worker spawns a read-only bwrap which needs a destination on the outer
    # namespace's writable scratch. Both levels retain the same read-only SDK bind.
    execute([*ns('N'),'--','taskset','-c','24-25','python3','-B',str(temp)],out,0)
    x=out/'ron-state/N';result=json.loads((x/'result.json').read_bytes())
    for phase in ('first','second','third'):
        raw=(x/phase/'compiler.d').read_bytes()
        hdr,= [l for l in raw.splitlines() if l.startswith(b'# ohm-observer-inputs-v1 ')]
        nested=bytes.fromhex(hdr.split()[3].decode())
        paths=[v for v in nested.splitlines() if v.startswith(b'# checksum:')]
        assert len(paths)==45,(phase,[v[-100:] for v in paths])
        assert result[phase]['complete']==1 and result[phase]['driver']==sha(subject) and result[phase]['cargo']==sha(selected_cargo('N'))
        result[phase]['checksum_inputs']=len(paths)
    put(out/'complete.json',result)
