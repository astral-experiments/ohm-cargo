pub use ruff_python_stdlib::typing::*; pub fn result(s:&str)->bool { !s.is_empty() }
