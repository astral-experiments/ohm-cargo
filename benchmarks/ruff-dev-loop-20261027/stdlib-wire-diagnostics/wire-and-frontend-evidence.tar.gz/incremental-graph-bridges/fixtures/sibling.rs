pub fn result(s:&str)->bool { ruff_python_stdlib::identifiers::is_identifier(s) }
