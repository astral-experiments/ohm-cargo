pub fn result(s:&str)->bool { ruff_python_stdlib::typing::simple_magic_return_type(s).is_some() }
