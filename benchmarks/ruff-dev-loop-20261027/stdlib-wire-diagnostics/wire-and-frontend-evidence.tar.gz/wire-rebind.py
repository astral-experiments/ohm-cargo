"""Offline upper bound. Accept only if the entire resulting file equals a genuine new rustc output."""
from pathlib import Path
import hashlib,json,runpy
D=Path(__file__).resolve().parent
Reader=runpy.run_path(str(Path.home()/'.cache/ohm-ruff-cargo-link-skip-20261027/link-export-inventory.py'))['Reader']
def info(data):
 r=Reader(data);assert r.u()==0;r.text();private=r.i;r.raw(32);name=r.symbol();assert r.raw(2)==bytes(2);r.text();r.raw(8)
 if r.u():r.u()
 r.u();r.u();r.raw(4);r.array();n,pos=r.array();r.i=pos; deps=[]
 for i in range(n):
  sym=r.symbol();idx=r.i;svh=r.raw(16).hex();tag=r.u();assert tag in (0,1);host=r.raw(16).hex()if tag else None;kind=r.u();ext=r.text();priv=r.u();deps.append((sym,idx,svh,host,kind,ext,priv))
 return {'name':name,'own_private':private,'deps':deps}
f=lambda b:hashlib.sha256(b).hexdigest()
summary={}
for suite in ('incremental-graph-bridges','private-refs-byteexact','private-deprecation'):
 p=D/suite;summary[suite]={}
 for name in sorted(x.name for x in(p/'updated').glob('lib*.rmeta') if 'ruff_python_stdlib'not in x.name):
  a=(p/'initial'/name).read_bytes();b=(p/'updated'/name).read_bytes();ia,ib=info(a),info(b)
  assert len(ia['deps'])==len(ib['deps']);diffs=[];bind=bytearray(a)
  for v,w in zip(ia['deps'],ib['deps']):
   assert (v[0],v[3:])==(w[0],w[3:]) and v[1]==w[1]
   if w[2]!=v[2]:
    assert v[0]=='ruff_python_stdlib';diffs.append(v[0]);off=v[1];bind[off:off+16]=bytes.fromhex(w[2])
  assert ia['own_private']==ib['own_private'] and diffs==['ruff_python_stdlib'];off=ia['own_private'];bind[off:off+16]=b[off:off+16]
  same=len(bind)==len(b);summary[suite][name]={'copied_size':len(a),'current_size':len(b),'previous_sha':f(a),'current_sha':f(b),'rebound_sha':f(bind),'matches':bytes(bind)==b,'residual_different_bytes':sum(x!=y for x,y in zip(bind,b)) if same else None,'dep_binding_offset':next(x[1]for x in ia['deps']if x[0]=='ruff_python_stdlib'),'own_private_hash_offset':off}
(D/'wire-rebind-facts.json').write_text(json.dumps(summary,indent=2)+'\n')
for k,v in summary.items():print(k,{n:(d['matches'],d['residual_different_bytes'])for n,d in v.items()})
