"""Measure three actual RDR consumers as the real stdlib producer changes source geometry."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess as sp,sys
D=Path(__file__).resolve().parent;Q=D/sys.argv[1];Q.mkdir(exist_ok=False);W=Q/'ws';W.mkdir();A=Path('/home/dev-user/code/oss/ruff');src=Path('crates/ruff_python_stdlib/src/typing.rs');V=D/'focused-233/variants';rt=Path.home()/'.cache/ohm-ruff-packed-edges-20261026/nonleaf/trait-pgo-state';sdk=rt/'sysroot';son='librustc_driver-774a793a844d5500.so';drv=D.parent/'stage2-wire-posobs4fmt'/son;cargo=Path.home()/'.cache/ohm-ruff-whole-skips-20261027/position-cargo-v3/cargo-observer';reg=Path.home()/'.cache/ohm-ruff-loop-20261026/registry-home/registry';sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest(); (Q/'subjects.json').write_text(json.dumps({'driver':sha(drv),'cargo':sha(cargo),'rustc':sha(sdk/'bin/rustc')}));
for s in ('home','build','target'):(Q/s).mkdir()
(Q/'home/registry').symlink_to(reg);names={'sibling':'pub fn result(s:&str)->bool { ruff_python_stdlib::identifiers::is_identifier(s) }\n','uses_moved':'pub fn result(s:&str)->bool { ruff_python_stdlib::typing::simple_magic_return_type(s).is_some() }\n','forwards':'pub use ruff_python_stdlib::typing::*; pub fn result(s:&str)->bool { !s.is_empty() }\n'};(W/'Cargo.toml').write_text('[workspace]\nresolver="3"\nmembers=['+','.join('"'+x+'"' for x in names)+']\n[profile.dev]\nopt-level=1\ndebug="line-tables-only"\nlto="off"\n')
for n,s in names.items():
 p=W/n;(p/'src').mkdir(parents=True);(p/'Cargo.toml').write_text(f'[package]\nname="{n}"\nversion="0.1.0"\nedition="2024"\n[dependencies]\nruff_python_stdlib={{path="'+str(A/'crates/ruff_python_stdlib')+'"}\n');(p/'src/lib.rs').write_text(s)
(Q/'caller.rs').write_text('pub fn x(s:&str)->bool { observed::result(s) }\n');environment={k:v for k,v in os.environ.items() if k not in ('RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')};environment.update(RUSTUP_HOME=str(rt/'rustup'),RUSTUP_TOOLCHAIN='ohm',RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(Q/'home'),CARGO_TARGET_DIR=str(Q/'target'),CARGO_BUILD_BUILD_DIR=str(Q/'build'),CARGO_INCREMENTAL='1',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1');TC=Path.home()/'.cargo/bin';entries={};results=[]

def cmd(phase,args):
 return sp.run(['taskset','-c','26,27','bwrap','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(Q),str(Q),'--ro-bind',str(V/phase),str(A/src),'--ro-bind',str(drv),str(sdk/'lib'/son),'--ro-bind',str(cargo),str(sdk/'bin/cargo'),'--chdir',str(W),'--',*map(str,args)],env=environment,capture_output=True,timeout=40)
def run(tag,phase,args):
 p=Q/tag;p.mkdir();r=cmd(phase,[TC/'cargo','+ohm','build','--offline','--message-format=json',*args]);(p/'cargo.jsonl').write_bytes(r.stdout);(p/'stderr').write_bytes(r.stderr);assert r.returncode==0,(r.stderr[-1800:],r.stdout[-200:]);out=[]
 for row in map(json.loads,r.stdout.splitlines()):
  if row.get('reason')!='compiler-artifact':continue
  name=row['target']['name'];outs=list(map(Path,row['filenames']));met=next((f for f in outs if f.suffix=='.rmeta'),None);ar=next((f for f in outs if f.suffix=='.rlib'),None)
  if name not in {*names,'ruff_python_stdlib'}:continue
  assert met and ar;entries[name]=met;shutil.copy2(met,p/('lib'+name+'.rmeta'));h=next((Q/'target').rglob('lib-'+name+'.public-api-hash'));members=sp.check_output(['ar','t',ar],text=True).splitlines();native=[hashlib.sha256(sp.check_output(['ar','p',ar,m])).hexdigest() for m in members if m.endswith('.rcgu.o')];out.append({'name':name,'fresh':row['fresh'],'rmeta':sha(met),'rlib':sha(ar),'native_objects':sorted(native),'public':json.loads(h.read_bytes())['value']})
 for item in names:
  if any(report['name']==item for report in out):
   files=list((Q/'target/debug/incremental').glob('*/'+item+'-*/*/dep-graph.bin'));assert len(files)==1,(tag,item,files);shutil.copy2(files[0],p/(item+'-dep-graph.bin'))
 (p/'record.json').write_text(json.dumps(out,indent=2));print(tag,[(o['name'],o['fresh'],o['public'][:8])for o in out],flush=True)
def call(tag,phase,bridge_mode,ok):
 p=Q/tag;p.mkdir();deps={s.parent for s in (Q/'target').rglob('*.rmeta') if 'incremental' not in s.parts};deps.update(s.parent for s in (Q/'build').rglob('*.rmeta') if 'incremental' not in s.parts);base_dir=Q/bridge_mode;assert 'ruff_python_stdlib' in entries
 for n in names:
  args=[TC/'rustc','+ohm',Q/'caller.rs','--crate-name','client','--crate-type=lib','--edition=2024','--emit=metadata','--error-format=json','--sysroot',sdk];args+=['--extern','observed='+str(base_dir/('lib'+n+'.rmeta')),'--extern','ruff_python_stdlib='+str(entries['ruff_python_stdlib'])];args+=[f for dr in sorted(deps) for f in ('-L','dependency='+str(dr))]+['-o',p/('client-'+n+'.rmeta')];r=cmd(phase,args);(p/(n+'.stderr')).write_bytes(r.stderr);err=[m for l in r.stderr.splitlines() if l.startswith(b'{') and (m:=json.loads(l)).get('code')];res={'tag':tag,'bridge':n,'ok':r.returncode==0,'errors':[m['code']['code'] for m in err]};results.append(res);print(res,flush=True);assert (r.returncode==0)==ok,(p,n,r.stderr[-900:]);
 (Q/'callers.json').write_text(json.dumps(results,indent=2))
run('initial','original',['--workspace']);call('old-producer','original','initial',True);run('new-provider','historical',['-p','ruff_python_stdlib']);call('old-bridge-new-producer','historical','initial',False);run('updated','historical',['--workspace']);call('new-all','historical','updated',True)
