from pathlib import Path
import hashlib,json,os,re,subprocess as sp,sys
D=Path(__file__).resolve().parent;CFG=sys.argv[1];assert CFG in('warn','deny');P=Path('/dev/shm/ohm-mixed-certificate-20261027');runtime=Path.home()/'.cache/ohm-ruff-packed-edges-20261026/nonleaf/trait-pgo-state'
sys.argv=[sys.argv[0],'--cargo',str(P/'cargo-v4-compiler/bounded-c1'),'--driver',str(P/'release-b1/librustc_driver-774a793a844d5500.so'),'--runtime',str(runtime),'--case','plain','--kind','product','--out','release-upstream-deprecation-'+CFG]
exec(compile((D/'hard-ffi-release.py').read_text().split('\nprime=run(',1)[0],str(D/'hard-ffi-release.py'),'exec'),globals())
assert root_case['cargo'].startswith('7d8a2d67')and root_case['driver'].startswith('7c31057e')
if CFG=='deny':
 rs=ws/'bundle/src/lib.rs';rs.write_text('#![deny(deprecated)]\n'+rs.read_text())
def key(path):
 f=next(path.rglob('lib-leaf.public-api-hash'));return json.loads(f.read_bytes())['value']
prime=run('prime',94);before=key(target);set_leaf(17);pos=run('private',100);assert key(target)==before and pos['checked_option'] and not pos['rlink_writes']
leaf.write_text('#[deprecated(note="upstream feedback control")]\n'+leaf.read_text())
def denyattempt(phase,cold):
 p=root/phase;p.mkdir();env['OHM_INDEPENDENT_PHASE']=str(p)
 binds=['--bind',str(gold/'target'),str(target),'--bind',str(gold/'shared'),str(shared)] if cold else []
 cmd=seed+binds+['--chdir',str(ws),'--','/usr/bin/strace','-f','-qq','-s','6000','-e','trace=execve','-o',str(p/'syscall.private'),str(Path.home()/'.cargo/bin/cargo'),'+ohm','build','-p','bundle','--offline','--locked','--message-format=json']
 ret=sp.run(cmd,env=env,stdout=sp.PIPE,stderr=sp.PIPE,timeout=40);(p/'cargo.out').write_bytes(ret.stdout);(p/'cargo.err').write_bytes(ret.stderr);msgs=[m['message']for x in ret.stdout.splitlines()if x.startswith(b'{')and(m:=json.loads(x)).get('reason')=='compiler-message'];assert ret.returncode==101 and any((m.get('code')or{}).get('code')=='deprecated' and m['level']=='error' and 'upstream feedback control' in m['message']for m in msgs)
 cs=[s for s in(p/'syscall.private').read_text().splitlines() if 'execve("'+str(rt/'bin/rustc')+'",' in s and '"--crate-name", "bundle"'in s and '= -1'not in s]
 assert len(cs)==1 and 'ohm-checked-mixed-rlink='not in cs[0]and '"link-only"'not in cs[0]
 return {'phase':phase,'returncode':ret.returncode,'bundle_rustc':1,'checked_option':False,'old_link_option':False,'diagnostics':[(m['level'],(m.get('code')or{}).get('code'),m['message'],[(s['file_name'],s['byte_start'],s['byte_end'])for s in m['spans']])for m in msgs]}
if CFG=='warn':
 warm=run('deprecated',100);cold=run('clean',100,True);assert warm['ELF']==cold['ELF'] and warm['rmeta']==cold['rmeta']and not warm['checked_option']and warm['rlink_writes'];assert any(d['code']=='deprecated'and d['level']=='warning'for d in warm['diagnostics'])and warm['diagnostics']==cold['diagnostics']
else:
 warm=denyattempt('deprecated',False);cold=denyattempt('clean',True);assert warm['diagnostics']==cold['diagnostics']
assert key(target)==key(gold/'target')and key(target)!=before
(root/'upstream-deprecation.json').write_text(json.dumps({'kind':CFG,'original_leaf':before,'changed_leaf':key(target),'warm':warm,'clean':cold},indent=2)+'\n');print(CFG,'passed',flush=True)
