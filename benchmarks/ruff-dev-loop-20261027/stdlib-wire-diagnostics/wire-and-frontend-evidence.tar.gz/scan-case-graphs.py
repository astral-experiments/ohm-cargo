from pathlib import Path
import hashlib, json, re, struct, collections,sys
D=Path(__file__).resolve().parent;R=Path('/home/dev-user/code/oss/ohm-rust-private-native-20261027');src=(R/'compiler/rustc_middle/src/queries.rs').read_text();names=re.findall(r'^    non_query (\w+)',src,re.M)+re.findall(r'^    query (\w+)',src,re.M);bits=(len(names)-1).bit_length();mask=(1<<bits)-1;print(len(names),names[:12]);
def read(p):
 d=p.read_bytes();assert d[-13:]==b'rust-end-file';start,nroots,magic,size,n,edges=struct.unpack_from('<6Q',d,len(d)-61);indexed=(magic==int.from_bytes(b'OHMIDX01','little'));byid={};raw={};off=7+d[6]+8
 for seq in range(size if indexed else n):
  o=struct.unpack_from('<Q',d,start+8*seq)[0] if indexed else off
  if o==0:continue
  hd,id=struct.unpack_from('<HI',d,o);i=seq if indexed else id;assert i==id;kind=hd&mask;width=((hd>>bits)&3)+1;length=(hd>>(bits+2))-1;pos=o+38
  if length<0:
   length=0;shift=0
   while True:
    c=d[pos];pos+=1;length|=(c&127)<<shift
    if c<128:break
    shift+=7
  key=(names[kind],d[o+6:o+22].hex());value=d[o+22:o+38].hex(); deps=[int.from_bytes(d[k:k+width],'little') for k in range(pos,pos+length*width,width)];assert key not in raw;raw[key]=(value,deps);byid[i]=key;off=pos+length*width
 assert len(byid)==n and sum(len(ns) for _,ns in raw.values())==edges;return {key:(v,[byid[j] for j in ds]) for key,(v,ds) in raw.items()}
target=D/sys.argv[1];summary={}
for case in [p.name[:-14] for p in sorted((target/'updated').glob('*-dep-graph.bin'))]:
 a=read(target/'initial'/(case+'-dep-graph.bin')); b=read(target/'updated'/(case+'-dep-graph.bin')); changed={k for k in a if k not in b or a[k][0]!=b[k][0]};mds=[k for k in a if 'metadata' in k[0].lower() or 'codegen' in k[0].lower() or k[0] in ('analysis','CompileCodegenUnit')];quality={}
 for k in mds:
  if k[0] not in ('CrateMetadata','CompileCodegenUnit','Analysis','analysis','codegen_unit','Metadata') or not a[k][1]:continue
  deps=a[k][1];reds=[z for z in deps if z in changed];quality[k[0]+':'+k[1][:9]]={'output_changed_or_missing':k in changed,'total_children':len(deps),'red_or_missing_children':[[z[0],z[1],a[z][0],b[z][0] if z in b else None]for z in reds]};
 print(case,len(a),len(b),'kind',collections.Counter(k[0]for k in mds).most_common(18),'all-red',collections.Counter(k[0]for k in changed).most_common(22));print('keyed',[(k,v['total_children'],[n[0]for n in v['red_or_missing_children']][:25])for k,v in quality.items()]);summary[case]={'nodes':[len(a),len(b)],'changed_by_kind':dict(collections.Counter(k[0]for k in changed)),'direct_children':quality}
(target/'graph-facts.json').write_text(json.dumps(summary,indent=2))
