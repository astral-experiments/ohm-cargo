"""Observe ordinary full Ruff workspaces seeded by the verified package experiment."""
from pathlib import Path
import collections
import hashlib
import json
import os
import shutil
import socket
import subprocess
import traceback

import capture as base

p = base.p
out = p / 'sdk-workspace-stock-controls-v2'
git = lambda *args: subprocess.check_output(['git', '--no-optional-locks', '-C', base.src, *args])
index = 'fc84f15ac7401cd9bdc362e4574c6d395529766c16be2e6b032ac47fa63d21cd'

def task(arm, workflow, seed_digest):
    slot = out / (arm + '-' + workflow)
    slot.mkdir(mode=0o700)
    state = slot / 'state'
    state.mkdir(mode=0o700)
    for name in ('target','shared','home'):
        (state/name).mkdir()
    reg=state/'cargo/registry';reg.mkdir(parents=True)
    for name in ('index','cache'):
        subprocess.run(['cp','-a','--reflink=auto','--',base.assets/'registry'/name,reg/name],check=True)
    logical_target=base.c/'ruff-target'
    sdk_path=base.c/('Ohm SDK' if arm=='spaced' else 'Ohm-SDK')
    sdk_path.mkdir(exist_ok=True)
    rustup=slot/'rustup'
    (rustup/'toolchains').mkdir(parents=True)
    (rustup/'toolchains/ohm').symlink_to(sdk_path,target_is_directory=True)
    preflight=json.loads((p/'sdk-layout-preflight-v2/result.json').read_bytes())
    assert preflight['code']==0 and preflight['path']==preflight['sysroot']==str(base.c/'Ohm SDK')
    env = dict(HOME=str(base.c / 'home'), USER='dev-user',
               PATH=str(Path.home()/'.cargo/bin') + ':/usr/local/bin:/usr/bin:/bin',
               CARGO_HOME=str(base.c / 'cargo'), CARGO_TARGET_DIR=str(logical_target),
               CARGO_BUILD_BUILD_DIR=str(base.c / 'shared'), CARGO_BUILD_JOBS='4',
               CARGO_NET_OFFLINE='true', RUSTUP_HOME=str(rustup), RUSTUP_TOOLCHAIN='ohm',
               RUSTUP_AUTO_INSTALL='0', CARGO_TERM_COLOR='never', GIT_OPTIONAL_LOCKS='0',
               LANG='C.UTF-8', LC_ALL='C.UTF-8')
    br = ['bwrap', '--ro-bind', '/', '/', '--dev', '/dev', '--proc', '/proc', '--tmpfs', '/tmp']
    br+=['--ro-bind',str(base.sdk),str(sdk_path)]
    for name in ('cargo', 'home', 'shared', 'target'):
        logical = logical_target if name == 'target' else base.c/name
        br += ['--bind', str(state/name), str(logical)]
    cmd = ['cargo', '+ohm', 'test', '--no-run'] if workflow == 'test' else ['cargo', '+ohm', 'build']
    cmd += ['--workspace', '--locked', '--offline', '-j4', '--message-format=json']
    probe=subprocess.run([*br,'--chdir',str(base.src),'--','rustc','+ohm','--print=sysroot'],env=env,capture_output=True)
    assert probe.returncode==0 and probe.stdout.decode().strip()==str(sdk_path),(probe.returncode,probe.stdout,probe.stderr)
    drivers,=[*base.sdk.joinpath('lib').glob('librustc_driver-*.so')]
    base.dump(slot/'sysroot.json',dict(spelling=str(sdk_path),sysroot=probe.stdout.decode().strip(),
        cargo=base.sha(base.sdk/'bin/cargo'),driver=base.sha(drivers),frontend=base.sha(base.sdk/'bin/rustc'),
        logical_target=str(logical_target),source=base.pin,previous_target_failure=seed_digest))
    rows = []
    for i in range(4):
        assert shutil.disk_usage(p).free > 55*2**30
        print(arm, workflow, i, flush=True)
        dot = slot/('call-' + str(i))
        dot.mkdir()
        (dot/'trace').mkdir()
        trace = ['strace', '-qq', '-ff', '-s', '1048576', '-e', 'trace=execve,execveat', '-o', str(dot/'trace/exec')]
        with (dot/'stdout').open('xb') as so, (dot/'stderr').open('xb') as se:
            rc = subprocess.run([*br, '--bind', str(dot), str(dot), '--chdir', str(base.src), '--',
                                 *trace, *cmd], env=env, stdout=so, stderr=se, stdin=subprocess.DEVNULL).returncode
        base.dump(dot/'command.json', dict(cmd=cmd, status=rc, parent=seed_digest, arm=arm, workflow=workflow,
                  stdout=base.sha(dot/'stdout'), stderr=base.sha(dot/'stderr'), cargo=base.sha(base.sdk/'bin/cargo')))
        assert rc == 0, (arm, workflow, i, rc)
        lines = [json.loads(b) for b in (dot/'stdout').read_bytes().splitlines()]
        assert lines[-1] == {'reason':'build-finished','success':True}
        arts = [v for v in lines if v['reason'] == 'compiler-artifact']
        assert len(arts) > 400
        native = {v['executable'] for v in arts if v['executable']}
        assert len(native) >= (80 if workflow == 'test' else 5)
        phys = base.cmds(dot/'trace')
        assert not native.intersection(phys['images'])
        if i==0:
            assert any(a.endswith('/bin/rustc') for a in phys['images'])
            assert any(a.endswith('/bin/cargo') for a in phys['images'])
            # Rustup may exec its symlink spelling. The compiler-printed sysroot is checked above.
        base.dump(dot/'physical.json', phys)
        raw = base.proof(state)
        base.dump(dot/'proof.json', raw)
        hashes = {}
        for exe in native:
            path = Path(exe)
            assert path.is_relative_to(logical_target)
            hashes[str(path.relative_to(logical_target))] = base.sha(state/'target'/path.relative_to(logical_target))
        base.dump(dot/'products.json', hashes)
        rows.append(dict(call=i, units=len(arts), dirty=[v['target']['name'] for v in arts if not v['fresh']],
                         compilers=collections.Counter(v['kind'] for v in phys['jobs']),
                         wild=len(phys['wild']), native=len(hashes), tests_executed=0,
                         observer=[[(f['has_obs1'], f['status']) for f in h['fingerprints']] for h in raw],
                         physical=base.sha(dot/'physical.json'), products=base.sha(dot/'products.json')))
        base.dump(slot/'progress.json', rows)
        assert hashlib.sha256(git('ls-files','-s','-z')).hexdigest() == index
    return rows

def main():
    assert socket.gethostname() == 'charlie-ohm-cargo5-build-1025'
    os.sched_setaffinity(0, set(range(8)))
    assert git('rev-parse','HEAD').decode().strip() == base.pin and not git('status','--porcelain','-z')
    assert base.sha(base.sdk/'bin/cargo') == '42e90992cec21a29956e20fd52ab952472a9dbc1dcc7a3b60c92aad101b5f568'
    assert base.sha(base.sdk/'bin/rustc') == 'b0c412a7a8010a768f00546419a0b1bcfca382d7e70191df3ae72e30ac1ef3e5'
    complete = base.out/'complete.json'
    assert (p/'release-discovery-run-v1/exit').read_text() == '0'
    baseline = json.loads(complete.read_bytes())
    assert all(v['jobs'] == {} for v in baseline['unspaced'][2:])
    assert all(v['jobs'] == {'full': 2, 'link-only': 1} and v['wild'] == 1 for v in baseline['spaced'][1:])
    assert not out.exists() and shutil.disk_usage(p).free > 165*2**30
    failed=p/'workspace-stock-controls-v1/spaced-test/call-0'
    assert base.sha(failed/'stderr')=='bcf81fee51c7421ec090e5403cf2ce6b5c84461ab7e18bb569317a1f4cc6e07e'
    assert b'configure: error: Prefix should not contain spaces' in (failed/'stderr').read_bytes()
    earlier=p/'sdk-workspace-stock-registration-v1'
    assert (earlier/'exit').read_text()=='1' and b"FileNotFoundError" in (earlier/'stderr').read_bytes()
    assert not list((p/'sdk-workspace-stock-controls-v1').glob('*/call-*'))
    out.mkdir(mode=0o700)
    result = {}
    for arm, workflow in [('spaced','test'), ('spaced','build'), ('unspaced','test'), ('unspaced','build')]:
        result[arm + '-' + workflow] = task(arm, workflow, base.sha(complete))
        base.dump(out/'progress.json', result)
    assert not git('status','--porcelain','-z')
    base.dump(out/'complete.json', result)
    print('completed sixteen unscored workspace builds', flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        if out.exists():
            (out/'failure.txt').write_text(traceback.format_exc())
        raise
