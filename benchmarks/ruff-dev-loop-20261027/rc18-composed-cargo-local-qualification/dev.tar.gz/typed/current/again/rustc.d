# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-current/warm/target/debug/build/workspaces/5984199b0c048edd/v2-4730521c1121491f/hold_direct/01516df27db99ded/out/hold_direct-01516df27db99ded.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-current/warm/target/debug/build/workspaces/5984199b0c048edd/v2-4730521c1121491f/hold_direct/01516df27db99ded/out/hold_direct-01516df27db99ded.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-current/warm/target/debug/build/workspaces/5984199b0c048edd/v2-4730521c1121491f/hold_direct/01516df27db99ded/out/libhold_direct-01516df27db99ded.rmeta: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-current/warm/target/debug/build/workspaces/5984199b0c048edd/v2-4730521c1121491f/hold_direct/01516df27db99ded/out/hold_direct-01516df27db99ded.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-current/warm/target/debug/build/workspaces/5984199b0c048edd/v2-4730521c1121491f/hold_direct/01516df27db99ded/out/hold_direct-01516df27db99ded.d/ohm-foreign-span-bytes:
# checksum:blake3=7e470a00b67ade0a3e5a24ba477f795b8ad0a9b7446874f0ab49d964f94c98ae file_len:256 hold_direct/src/main.rs
