# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-preserved/warm/target/debug/build/workspaces/fe747151e0cc8dda/v2-5660d4adee60ede9/hold_direct/b5022b8b235e6001/out/hold_direct-b5022b8b235e6001.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-preserved/warm/target/debug/build/workspaces/fe747151e0cc8dda/v2-5660d4adee60ede9/hold_direct/b5022b8b235e6001/out/hold_direct-b5022b8b235e6001.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-preserved/warm/target/debug/build/workspaces/fe747151e0cc8dda/v2-5660d4adee60ede9/hold_direct/b5022b8b235e6001/out/libhold_direct-b5022b8b235e6001.rmeta: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-preserved/warm/target/debug/build/workspaces/fe747151e0cc8dda/v2-5660d4adee60ede9/hold_direct/b5022b8b235e6001/out/hold_direct-b5022b8b235e6001.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-composed/typed-check/status/rmeta-preserved/warm/target/debug/build/workspaces/fe747151e0cc8dda/v2-5660d4adee60ede9/hold_direct/b5022b8b235e6001/out/hold_direct-b5022b8b235e6001.d/ohm-foreign-span-bytes:
# checksum:blake3=7e470a00b67ade0a3e5a24ba477f795b8ad0a9b7446874f0ab49d964f94c98ae file_len:256 hold_direct/src/main.rs
