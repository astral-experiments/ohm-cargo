# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-from261/warm/target/debug/build/workspaces/7ce8c558634b5d25/v2-f2beb53a1f7a4c1e/cli/6225e01af3137e91/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-from261/warm/target/debug/build/workspaces/7ce8c558634b5d25/v2-f2beb53a1f7a4c1e/cli/6225e01af3137e91/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
