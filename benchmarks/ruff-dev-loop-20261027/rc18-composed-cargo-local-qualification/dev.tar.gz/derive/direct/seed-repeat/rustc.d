# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-rc18/warm/target/debug/build/workspaces/23c9072c076527ef/v2-bff353b1473a328f/cli/8ff7df453fb623ca/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-rc18/warm/target/debug/build/workspaces/23c9072c076527ef/v2-bff353b1473a328f/cli/8ff7df453fb623ca/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
