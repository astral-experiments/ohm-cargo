# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/warm/target/debug/build/workspaces/4e380e9aed1d1ccf/v2-89f2d26915d45ce2/hold_direct/cf26dab7a47bc843/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/warm/target/debug/build/workspaces/4e380e9aed1d1ccf/v2-89f2d26915d45ce2/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/warm/target/debug/build/workspaces/4e380e9aed1d1ccf/v2-89f2d26915d45ce2/hold_direct/cf26dab7a47bc843/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/warm/target/debug/build/workspaces/4e380e9aed1d1ccf/v2-89f2d26915d45ce2/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/private-input.txt:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/warm/target/debug/build/workspaces/4e380e9aed1d1ccf/v2-89f2d26915d45ce2/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=080d7a9d6cce9f2e88a4b384c7074e950168f9950bb2419a2b9217c36d790b80 file_len:462 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-current/private-input.txt
