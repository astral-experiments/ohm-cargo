# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/warm/target/debug/build/workspaces/58ee1077231fff60/v2-d45eb73187e1b376/hold_direct/cf26dab7a47bc843/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/warm/target/debug/build/workspaces/58ee1077231fff60/v2-d45eb73187e1b376/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/warm/target/debug/build/workspaces/58ee1077231fff60/v2-d45eb73187e1b376/hold_direct/cf26dab7a47bc843/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/warm/target/debug/build/workspaces/58ee1077231fff60/v2-d45eb73187e1b376/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/private-input.txt:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/warm/target/debug/build/workspaces/58ee1077231fff60/v2-d45eb73187e1b376/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=8fcc1ce3ffd26503e4f3712ef8266f14849ef8af92244a9e6e62a6a896c624e0 file_len:464 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-bytes-preserved/private-input.txt
