# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/warm/target/debug/build/workspaces/00eb6a144ce9a26c/v2-6d42f3b4d19e8844/hold_direct/cf26dab7a47bc843/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/warm/target/debug/build/workspaces/00eb6a144ce9a26c/v2-6d42f3b4d19e8844/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/warm/target/debug/build/workspaces/00eb6a144ce9a26c/v2-6d42f3b4d19e8844/hold_direct/cf26dab7a47bc843/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/warm/target/debug/build/workspaces/00eb6a144ce9a26c/v2-6d42f3b4d19e8844/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/private-input.txt:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/warm/target/debug/build/workspaces/00eb6a144ce9a26c/v2-6d42f3b4d19e8844/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=a2c0032a81c6403cf10a9e0d5acb1ba05fe9fd32d6cc4eae6108d525c19913d6 file_len:456 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-preserved/private-input.txt
