# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/warm/target/debug/build/workspaces/088b40e0d9d8ab3a/v2-e41e6f23f8a1bea5/hold_direct/cf26dab7a47bc843/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/warm/target/debug/build/workspaces/088b40e0d9d8ab3a/v2-e41e6f23f8a1bea5/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/warm/target/debug/build/workspaces/088b40e0d9d8ab3a/v2-e41e6f23f8a1bea5/hold_direct/cf26dab7a47bc843/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/warm/target/debug/build/workspaces/088b40e0d9d8ab3a/v2-e41e6f23f8a1bea5/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/private-input.txt:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/warm/target/debug/build/workspaces/088b40e0d9d8ab3a/v2-e41e6f23f8a1bea5/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=10bb04f62e05a342e70e85763ea1aae0c24ab414c98297c16e090fa5b6cb7057 file_len:454 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-include-str-current/private-input.txt
