# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/warm/target/debug/build/workspaces/812771cf49ec8261/v2-4856637ee1c3a0ca/hold_direct/cf26dab7a47bc843/out/hold_direct.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/warm/target/debug/build/workspaces/812771cf49ec8261/v2-4856637ee1c3a0ca/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/warm/target/debug/build/workspaces/812771cf49ec8261/v2-4856637ee1c3a0ca/hold_direct/cf26dab7a47bc843/out/hold_direct: hold_direct/src/main.rs /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/private-input.txt /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/warm/target/debug/build/workspaces/812771cf49ec8261/v2-4856637ee1c3a0ca/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/private-input.txt:
/home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/warm/target/debug/build/workspaces/812771cf49ec8261/v2-4856637ee1c3a0ca/hold_direct/cf26dab7a47bc843/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=2850b30486f9b9604edb81dfc9b9df017f6f9fe84cdc87eba2fc4298dc6ddf83 file_len:273 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /home/dev-user/.cache/ohm-rc18-current-epoch-20261028/trained-tracked-file-preserved/private-input.txt
