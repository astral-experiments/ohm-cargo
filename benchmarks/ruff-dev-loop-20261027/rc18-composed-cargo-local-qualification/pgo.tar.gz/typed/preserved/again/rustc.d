# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-preserved/warm/target/debug/build/workspaces/8c741058bf44ae0b/v2-97fb2a6e27c525bb/hold_direct/d0017c820e472dd7/out/hold_direct-d0017c820e472dd7.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-preserved/warm/target/debug/build/workspaces/8c741058bf44ae0b/v2-97fb2a6e27c525bb/hold_direct/d0017c820e472dd7/out/hold_direct-d0017c820e472dd7.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-preserved/warm/target/debug/build/workspaces/8c741058bf44ae0b/v2-97fb2a6e27c525bb/hold_direct/d0017c820e472dd7/out/libhold_direct-d0017c820e472dd7.rmeta: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-preserved/warm/target/debug/build/workspaces/8c741058bf44ae0b/v2-97fb2a6e27c525bb/hold_direct/d0017c820e472dd7/out/hold_direct-d0017c820e472dd7.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-preserved/warm/target/debug/build/workspaces/8c741058bf44ae0b/v2-97fb2a6e27c525bb/hold_direct/d0017c820e472dd7/out/hold_direct-d0017c820e472dd7.d/ohm-foreign-span-bytes:
# checksum:blake3=7e470a00b67ade0a3e5a24ba477f795b8ad0a9b7446874f0ab49d964f94c98ae file_len:256 hold_direct/src/main.rs
