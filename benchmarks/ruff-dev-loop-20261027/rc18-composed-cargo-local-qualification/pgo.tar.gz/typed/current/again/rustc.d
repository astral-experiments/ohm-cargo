# ohm-raw-checksum-paths-v2
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-current/warm/target/debug/build/workspaces/b18da141fed45dc0/v2-c30d06a6976e0c9b/hold_direct/f784778197ed9739/out/hold_direct-f784778197ed9739.d: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-current/warm/target/debug/build/workspaces/b18da141fed45dc0/v2-c30d06a6976e0c9b/hold_direct/f784778197ed9739/out/hold_direct-f784778197ed9739.d/ohm-foreign-span-bytes

/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-current/warm/target/debug/build/workspaces/b18da141fed45dc0/v2-c30d06a6976e0c9b/hold_direct/f784778197ed9739/out/libhold_direct-f784778197ed9739.rmeta: hold_direct/src/main.rs /home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-current/warm/target/debug/build/workspaces/b18da141fed45dc0/v2-c30d06a6976e0c9b/hold_direct/f784778197ed9739/out/hold_direct-f784778197ed9739.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/home/dev-user/.cache/ohm-ron-consumed-cargo-20261028/rc18-pgo/typed/status/rmeta-current/warm/target/debug/build/workspaces/b18da141fed45dc0/v2-c30d06a6976e0c9b/hold_direct/f784778197ed9739/out/hold_direct-f784778197ed9739.d/ohm-foreign-span-bytes:
# checksum:blake3=7e470a00b67ade0a3e5a24ba477f795b8ad0a9b7446874f0ab49d964f94c98ae file_len:256 hold_direct/src/main.rs
