# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-pgo-from17/warm/target/debug/build/workspaces/4a40074c5f198e9b/v2-3822001e13c19aec/cli/9a3e43e1a218ad14/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-pgo-from17/warm/target/debug/build/workspaces/4a40074c5f198e9b/v2-3822001e13c19aec/cli/9a3e43e1a218ad14/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
