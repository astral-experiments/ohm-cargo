# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-pgo-from261/warm/target/debug/build/workspaces/c51787e40229a732/v2-be0a4696841b2665/cli/399119258a21f890/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/migrate-natural-rc18-pgo-from261/warm/target/debug/build/workspaces/c51787e40229a732/v2-be0a4696841b2665/cli/399119258a21f890/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
