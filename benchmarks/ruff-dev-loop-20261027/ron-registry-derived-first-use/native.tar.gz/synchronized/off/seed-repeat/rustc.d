# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-control-v2/old/target/debug/build/workspaces/51648271904af617/v2-595b169f46ddf681/cli/f963eee5b2f43a17/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-control-v2/old/target/debug/build/workspaces/51648271904af617/v2-595b169f46ddf681/cli/f963eee5b2f43a17/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
