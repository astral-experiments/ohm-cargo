# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-known-v2/old/target/debug/build/workspaces/44c7710e43ce47ce/v2-1940245dc2babc66/cli/64d4dbf4b35ee8c4/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-known-v2/old/target/debug/build/workspaces/44c7710e43ce47ce/v2-1940245dc2babc66/cli/64d4dbf4b35ee8c4/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
