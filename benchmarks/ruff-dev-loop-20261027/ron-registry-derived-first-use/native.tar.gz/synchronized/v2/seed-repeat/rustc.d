# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-v2-repeat/old/target/debug/build/workspaces/291b94b5a0d735a1/v2-5a17369b514ab677/cli/57e6666e9ae02200/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/first-managed-v2-repeat/old/target/debug/build/workspaces/291b94b5a0d735a1/v2-5a17369b514ab677/cli/57e6666e9ae02200/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
