# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-control-v1/warm/target/debug/build/workspaces/8ff04d81fb2a7247/v2-09ec169a204d9635/cli/87b1d1fd88704801/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-control-v1/warm/target/debug/build/workspaces/8ff04d81fb2a7247/v2-09ec169a204d9635/cli/87b1d1fd88704801/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
