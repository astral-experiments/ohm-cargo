# ohm-raw-checksum-paths-v2
/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-known-v1/warm/target/debug/build/workspaces/06a8c14e1d805d42/v2-d844d7c7744d79c9/cli/cc93bf8528969bc2/out/cli.d: cli/src/main.rs

/dev/shm/ohm-ron-consumed-v1-20261028/natural-managed-known-v1/warm/target/debug/build/workspaces/06a8c14e1d805d42/v2-d844d7c7744d79c9/cli/cc93bf8528969bc2/out/cli: cli/src/main.rs

cli/src/main.rs:
# checksum:blake3=4b5630242decd74dacb71f209a80feb3bae9eaa81b5c33725d539ff483135b1a file_len:145 cli/src/main.rs
