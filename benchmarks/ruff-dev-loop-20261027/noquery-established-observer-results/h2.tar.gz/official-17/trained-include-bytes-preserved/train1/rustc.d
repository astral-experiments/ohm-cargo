# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/warm/target/debug/build/workspaces/373ee731ed9de46d/v2-22ba72ede8e9de41/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=4eac2a22a35b6a7c38291a3d6c037cdbd65d0ca85b4a5ab23fac34fad7a1e22f file_len:463 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-preserved/private-input.txt
