# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/empty/target/debug/build/workspaces/5655f8b06bedfa94/v2-cb03bc060f479cf0/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/empty/target/debug/build/workspaces/5655f8b06bedfa94/v2-cb03bc060f479cf0/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/empty/target/debug/build/workspaces/5655f8b06bedfa94/v2-cb03bc060f479cf0/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/empty/target/debug/build/workspaces/5655f8b06bedfa94/v2-cb03bc060f479cf0/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/empty/target/debug/build/workspaces/5655f8b06bedfa94/v2-cb03bc060f479cf0/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=2850b30486f9b9604edb81dfc9b9df017f6f9fe84cdc87eba2fc4298dc6ddf83 file_len:273 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-preserved/private-input.txt
