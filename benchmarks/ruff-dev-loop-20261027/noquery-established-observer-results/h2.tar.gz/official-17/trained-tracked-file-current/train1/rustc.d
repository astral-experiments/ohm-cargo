# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/warm/target/debug/build/workspaces/8f50baef35d6444b/v2-760646c72cf3ad39/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/warm/target/debug/build/workspaces/8f50baef35d6444b/v2-760646c72cf3ad39/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/warm/target/debug/build/workspaces/8f50baef35d6444b/v2-760646c72cf3ad39/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/warm/target/debug/build/workspaces/8f50baef35d6444b/v2-760646c72cf3ad39/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/warm/target/debug/build/workspaces/8f50baef35d6444b/v2-760646c72cf3ad39/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=e23a3eb45880a6f83eb9e9a6690dca086b052d5ae0ae6e34307f30d2168cfed2 file_len:250 hold_direct/src/main.rs
# checksum:blake3=2bc7ef5f44f1bad1562c1d40d45195f5102d690a302cadab32ff8fd8ebf420df file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-tracked-file-current/private-input.txt
