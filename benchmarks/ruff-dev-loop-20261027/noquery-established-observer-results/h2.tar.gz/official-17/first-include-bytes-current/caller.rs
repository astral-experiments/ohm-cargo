use hold_probe::wait_value;
const INPUT: &[u8] = include_bytes!(r#"/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-current/private-input.txt"#);
const GATE: u32=wait_value!(17);
use hold_shapes::Number;
use hold_probe::native_offset;
const _: Option<Number> = None;
fn main(){assert_eq!(GATE,17);println!("sample={}",INPUT[1]);println!("{} {}",hold_shapes::count(),hold_tokens::inspect_value!(native_offset));}
