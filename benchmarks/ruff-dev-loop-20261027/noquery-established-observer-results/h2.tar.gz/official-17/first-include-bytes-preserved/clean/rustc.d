# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/empty/target/debug/build/workspaces/9e8334b063b5a0c4/v2-c2179bb1e9df9bae/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/empty/target/debug/build/workspaces/9e8334b063b5a0c4/v2-c2179bb1e9df9bae/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/empty/target/debug/build/workspaces/9e8334b063b5a0c4/v2-c2179bb1e9df9bae/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/empty/target/debug/build/workspaces/9e8334b063b5a0c4/v2-c2179bb1e9df9bae/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/empty/target/debug/build/workspaces/9e8334b063b5a0c4/v2-c2179bb1e9df9bae/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=d3f488fc877e2876a6180aeb92620464cb0fcec6ac44b44c0ed7ec09b5928068 file_len:461 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/first-include-bytes-preserved/private-input.txt
