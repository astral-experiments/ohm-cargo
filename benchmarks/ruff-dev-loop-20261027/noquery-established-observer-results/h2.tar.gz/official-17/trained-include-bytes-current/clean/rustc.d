# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/empty/target/debug/build/workspaces/d976cc1d9d1bb4d9/v2-65e2143e323fbfba/hold_direct/941997fcaf9b0eab/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/empty/target/debug/build/workspaces/d976cc1d9d1bb4d9/v2-65e2143e323fbfba/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/empty/target/debug/build/workspaces/d976cc1d9d1bb4d9/v2-65e2143e323fbfba/hold_direct/941997fcaf9b0eab/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/empty/target/debug/build/workspaces/d976cc1d9d1bb4d9/v2-65e2143e323fbfba/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/empty/target/debug/build/workspaces/d976cc1d9d1bb4d9/v2-65e2143e323fbfba/hold_direct/941997fcaf9b0eab/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=e5c3c87f31cbd0e138ed4292cdabe022ff6a0dc2812f0b8417944c30df568b5d file_len:484 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/official-17/trained-include-bytes-current/private-input.txt
