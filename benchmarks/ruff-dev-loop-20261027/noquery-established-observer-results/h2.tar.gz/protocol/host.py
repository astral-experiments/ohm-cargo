from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,sys,traceback
host,k,b=sys.argv[1:];k=Path(k);b=Path(b);sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest();J=lambda f:json.loads(f.read_bytes());pin=Path('/dev/shm/ohm-observer-protocol-h1-20261027/optional-native-pilot1-20261028');bp=['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--ro-bind','/dev/shm','/dev/shm','--tmpfs','/tmp','--bind',str(b),str(b)];release=Path('/dev/shm/ohm-published-member-h2-20261028/installed17');arms=[('official-17',release,release/'bin/cargo')] if host=='h2' else [('candidate',pin/'N-common/active-sdk',pin/'pinned-subjects/N/cargo'),('released-sources',pin/'N-old-raw/active-sdk',pin/'pinned-subjects/A/cargo')];
try:
 if host=='h2':
  lock=open('/mnt/devbox-scratch/dev-user/ohm-whole-skips-20261027/native-measure.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for arm,sdk,cargo in arms:
  driver,=sdk.glob('lib/librustc_driver-*.so');identity={'cargo':sha(cargo),'driver':sha(driver),'frontend':sha(sdk/'bin/rustc')};
  if arm=='official-17':
   assert identity['driver']=='618ebac16b7d4ec01a2af89661d25b8f26ff347edbb69c6dcaa78f10115914a7' and identity['cargo']=='4e4065390403afbf4fb77b2f41fbc21c59afe3dda2337a5bbe29fda29a47dbb3' and identity['frontend']=='7ec5263869aed2fc9272ea7212aabbe7b272a4685f1b79af75c123daff09c02c' and (sdk/'.ohm-version').read_text().strip()=='ohm-1.99.0-17'
  else:
   binding=J(Path('/mnt/devbox-scratch/dev-user/ohm-noquery-synchronized-inputs-v2-h1-20261028')/(arm+'.identity.json'));assert all(identity[k]==binding[k] for k in identity)
  (b/(arm+'.identity.json')).write_text(json.dumps(identity,sort_keys=True));cmd=[*bp,*([] if arm=='official-17' else ['--ro-bind',str(cargo),str(sdk/'bin/cargo')]),'--','taskset','-c','0-3','/usr/bin/python3','-B',str(k/'exercise.py'),'--sdk',str(sdk),'--out',str(b/arm)];
  with (b/(arm+'.stdout')).open('xb') as so,(b/(arm+'.stderr')).open('xb') as se:res=subprocess.run(cmd,stdout=so,stderr=se)
  (b/(arm+'.exit')).write_text(str(res.returncode));assert res.returncode==0,(arm,(b/(arm+'.stderr')).read_text()[-1300:]);assert (b/arm/'complete.json').is_file()
 (b/'complete.json').write_text(json.dumps({a:J(b/a/'complete.json') for a,s,c in arms},sort_keys=True,indent=2))
except BaseException:
 (b/'failure.txt').write_text(traceback.format_exc());raise
