# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/warm/target/debug/build/workspaces/04cd0e12d60ea0fe/v2-24bbb7f95f31907b/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/warm/target/debug/build/workspaces/04cd0e12d60ea0fe/v2-24bbb7f95f31907b/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/warm/target/debug/build/workspaces/04cd0e12d60ea0fe/v2-24bbb7f95f31907b/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/warm/target/debug/build/workspaces/04cd0e12d60ea0fe/v2-24bbb7f95f31907b/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/warm/target/debug/build/workspaces/04cd0e12d60ea0fe/v2-24bbb7f95f31907b/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=249bee11f69169ac5814b1126aca2e94a3069526a6fc2217f95b2c1c7a9382b6 file_len:458 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-preserved/private-input.txt
