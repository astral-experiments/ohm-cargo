# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/empty/target/debug/build/workspaces/cad25ed1b35eeaa2/v2-1d4ec537de838d88/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/empty/target/debug/build/workspaces/cad25ed1b35eeaa2/v2-1d4ec537de838d88/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/empty/target/debug/build/workspaces/cad25ed1b35eeaa2/v2-1d4ec537de838d88/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/empty/target/debug/build/workspaces/cad25ed1b35eeaa2/v2-1d4ec537de838d88/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/empty/target/debug/build/workspaces/cad25ed1b35eeaa2/v2-1d4ec537de838d88/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=65fa098de6d368cd0de531e1fabd230f4d3427e34c5ca39c9ac29e6cd022dbd4 file_len:466 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-preserved/private-input.txt
