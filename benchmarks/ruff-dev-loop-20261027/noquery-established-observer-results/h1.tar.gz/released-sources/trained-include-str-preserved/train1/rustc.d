# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/warm/target/debug/build/workspaces/0b90b389b657ef14/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/warm/target/debug/build/workspaces/0b90b389b657ef14/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/warm/target/debug/build/workspaces/0b90b389b657ef14/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/warm/target/debug/build/workspaces/0b90b389b657ef14/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/warm/target/debug/build/workspaces/0b90b389b657ef14/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=44b22e6121c42fa778b5f4ceefabc5364452cbaad667450da0559ea5164fda49 file_len:460 hold_direct/src/main.rs
# checksum:blake3=2bc7ef5f44f1bad1562c1d40d45195f5102d690a302cadab32ff8fd8ebf420df file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt
