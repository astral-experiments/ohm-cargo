# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/empty/target/debug/build/workspaces/f93412a3c53b3f80/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/empty/target/debug/build/workspaces/f93412a3c53b3f80/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/empty/target/debug/build/workspaces/f93412a3c53b3f80/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/empty/target/debug/build/workspaces/f93412a3c53b3f80/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/empty/target/debug/build/workspaces/f93412a3c53b3f80/v2-2d16084faa84fcca/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=f456a296f81eabf1848204eed0ee5fd8fe4caa22ce23b09b8853b26ad64af3d8 file_len:483 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-preserved/private-input.txt
