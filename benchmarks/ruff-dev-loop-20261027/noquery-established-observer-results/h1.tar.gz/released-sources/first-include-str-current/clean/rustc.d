# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/empty/target/debug/build/workspaces/2e42ed43d2b30771/v2-b6543a9dc972e55c/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/empty/target/debug/build/workspaces/2e42ed43d2b30771/v2-b6543a9dc972e55c/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/empty/target/debug/build/workspaces/2e42ed43d2b30771/v2-b6543a9dc972e55c/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/empty/target/debug/build/workspaces/2e42ed43d2b30771/v2-b6543a9dc972e55c/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/empty/target/debug/build/workspaces/2e42ed43d2b30771/v2-b6543a9dc972e55c/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=8f45672760555aa719b2de96e7b695acb55e3e4590e343c27a23d0a7d6507f9f file_len:456 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-str-current/private-input.txt
