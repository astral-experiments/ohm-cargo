# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/empty/target/debug/build/workspaces/39f96f40a7f150dc/v2-5ec2f28b5b4ff2ae/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/empty/target/debug/build/workspaces/39f96f40a7f150dc/v2-5ec2f28b5b4ff2ae/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/empty/target/debug/build/workspaces/39f96f40a7f150dc/v2-5ec2f28b5b4ff2ae/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/empty/target/debug/build/workspaces/39f96f40a7f150dc/v2-5ec2f28b5b4ff2ae/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/empty/target/debug/build/workspaces/39f96f40a7f150dc/v2-5ec2f28b5b4ff2ae/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=498535a361ab75a037614c8af5d193f3e919ec8d33adf43d01cc7a22a227a04e file_len:464 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/first-include-bytes-current/private-input.txt
