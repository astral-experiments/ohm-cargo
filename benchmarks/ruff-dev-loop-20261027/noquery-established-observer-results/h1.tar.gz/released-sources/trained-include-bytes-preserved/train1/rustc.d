# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/warm/target/debug/build/workspaces/d1b1719cd1cbc53f/v2-f2b61beeeffaf640/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/warm/target/debug/build/workspaces/d1b1719cd1cbc53f/v2-f2b61beeeffaf640/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/warm/target/debug/build/workspaces/d1b1719cd1cbc53f/v2-f2b61beeeffaf640/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/warm/target/debug/build/workspaces/d1b1719cd1cbc53f/v2-f2b61beeeffaf640/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/warm/target/debug/build/workspaces/d1b1719cd1cbc53f/v2-f2b61beeeffaf640/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=e3fd8e37d6611949d92f5fed8fc941799e5de59f34922f837f91772c092823f8 file_len:468 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-preserved/private-input.txt
