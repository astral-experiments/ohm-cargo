# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/warm/target/debug/build/workspaces/3329e1a679d92d6d/v2-f78773e68064ba17/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/warm/target/debug/build/workspaces/3329e1a679d92d6d/v2-f78773e68064ba17/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/warm/target/debug/build/workspaces/3329e1a679d92d6d/v2-f78773e68064ba17/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/warm/target/debug/build/workspaces/3329e1a679d92d6d/v2-f78773e68064ba17/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/warm/target/debug/build/workspaces/3329e1a679d92d6d/v2-f78773e68064ba17/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=5abc797dc9b797250c2e01468889198fdd5d13a1e7a2fe4cf92b6fb1147fb79a file_len:466 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-bytes-current/private-input.txt
