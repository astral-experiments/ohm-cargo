# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/warm/target/debug/build/workspaces/b6abe0d6505069e5/v2-c1386847e77e7205/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/warm/target/debug/build/workspaces/b6abe0d6505069e5/v2-c1386847e77e7205/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/warm/target/debug/build/workspaces/b6abe0d6505069e5/v2-c1386847e77e7205/hold_direct/46e7a50c1fc29e9c/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/warm/target/debug/build/workspaces/b6abe0d6505069e5/v2-c1386847e77e7205/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/warm/target/debug/build/workspaces/b6abe0d6505069e5/v2-c1386847e77e7205/hold_direct/46e7a50c1fc29e9c/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=569272aca7f3e68334cb75d75e594560993d9d001d92efa7a40540dcc8f9394e file_len:458 hold_direct/src/main.rs
# checksum:blake3=2bc7ef5f44f1bad1562c1d40d45195f5102d690a302cadab32ff8fd8ebf420df file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/released-sources/trained-include-str-current/private-input.txt
