# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/warm/target/debug/build/workspaces/8bd4f40b7dcdb62e/v2-e8aec6ac560267b9/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/warm/target/debug/build/workspaces/8bd4f40b7dcdb62e/v2-e8aec6ac560267b9/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/warm/target/debug/build/workspaces/8bd4f40b7dcdb62e/v2-e8aec6ac560267b9/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/warm/target/debug/build/workspaces/8bd4f40b7dcdb62e/v2-e8aec6ac560267b9/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/warm/target/debug/build/workspaces/8bd4f40b7dcdb62e/v2-e8aec6ac560267b9/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=74d43140d545e5a726bb747f78a8989526d69bb3f37354203622840c6d2c4063 file_len:459 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-preserved/private-input.txt
