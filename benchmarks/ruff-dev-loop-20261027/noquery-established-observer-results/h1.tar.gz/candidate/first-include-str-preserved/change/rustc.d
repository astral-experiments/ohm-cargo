# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/warm/target/debug/build/workspaces/312ef76a7e9c2026/v2-8be96a7c3ed71406/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/warm/target/debug/build/workspaces/312ef76a7e9c2026/v2-8be96a7c3ed71406/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/warm/target/debug/build/workspaces/312ef76a7e9c2026/v2-8be96a7c3ed71406/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/warm/target/debug/build/workspaces/312ef76a7e9c2026/v2-8be96a7c3ed71406/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/warm/target/debug/build/workspaces/312ef76a7e9c2026/v2-8be96a7c3ed71406/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=9d157e3d355bc8b06fe3e46a1186db230ec2707f91ccd0824456393f005c40ae file_len:451 hold_direct/src/main.rs
# checksum:blake3=26ef00fd9555bd7513a82faef1b56c9d1efd61bc84e311e6ed902c79c40602c4 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-str-preserved/private-input.txt
