# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/warm/target/debug/build/workspaces/aa4edb41ba376120/v2-63221caa11c278d4/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/warm/target/debug/build/workspaces/aa4edb41ba376120/v2-63221caa11c278d4/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/warm/target/debug/build/workspaces/aa4edb41ba376120/v2-63221caa11c278d4/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/warm/target/debug/build/workspaces/aa4edb41ba376120/v2-63221caa11c278d4/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/warm/target/debug/build/workspaces/aa4edb41ba376120/v2-63221caa11c278d4/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=deb8de31014a0cb1c4efc092868f973b051ede81b2c290b63441640a45110e7b file_len:457 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/first-include-bytes-current/private-input.txt
