# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/warm/target/debug/build/workspaces/9c95e299cd45bebe/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/warm/target/debug/build/workspaces/9c95e299cd45bebe/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/warm/target/debug/build/workspaces/9c95e299cd45bebe/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/warm/target/debug/build/workspaces/9c95e299cd45bebe/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/warm/target/debug/build/workspaces/9c95e299cd45bebe/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=8fa8bab8ca6c6098f81b00794793bc5991ed3d4b60d650c340ba80bae535f671 file_len:459 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt
