# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/empty/target/debug/build/workspaces/ec9efd6cf0d653c1/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/empty/target/debug/build/workspaces/ec9efd6cf0d653c1/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/empty/target/debug/build/workspaces/ec9efd6cf0d653c1/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/empty/target/debug/build/workspaces/ec9efd6cf0d653c1/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/empty/target/debug/build/workspaces/ec9efd6cf0d653c1/v2-66b43097fc745a16/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=eaa37fc4a6c1873f2282baf91e95d3299d70529692f4948eb048cf940d3474ed file_len:482 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-current/private-input.txt
