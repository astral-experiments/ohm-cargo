# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/warm/target/debug/build/workspaces/dd4ad432610da576/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/warm/target/debug/build/workspaces/dd4ad432610da576/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/warm/target/debug/build/workspaces/dd4ad432610da576/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/warm/target/debug/build/workspaces/dd4ad432610da576/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/warm/target/debug/build/workspaces/dd4ad432610da576/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=28f048d15573bb3157e6000a740ee1545a1d521f90c6826e8c1b8754defae323 file_len:461 hold_direct/src/main.rs
# checksum:blake3=f76b1dfe1ed3b52ca1baa17a72b847e706cb437d2301b37f9b9838c5207ba87b file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt
