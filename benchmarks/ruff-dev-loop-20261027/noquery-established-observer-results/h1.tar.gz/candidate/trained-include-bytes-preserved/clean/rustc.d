# ohm-raw-checksum-paths-v2
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/empty/target/debug/build/workspaces/fb3c72dbe7510ac3/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/empty/target/debug/build/workspaces/fb3c72dbe7510ac3/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/empty/target/debug/build/workspaces/fb3c72dbe7510ac3/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct: hold_direct/src/main.rs /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/empty/target/debug/build/workspaces/fb3c72dbe7510ac3/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes

hold_direct/src/main.rs:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt:
/mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/empty/target/debug/build/workspaces/fb3c72dbe7510ac3/v2-80fd5e84866a9c88/hold_direct/f0611a30f16038ea/out/hold_direct.d/ohm-foreign-span-bytes:

# env-dep:OHM_SYNC_CONSTANT=fixed
# checksum:blake3=0dc8a492dffdf448457e97de1849a5fa5a62a7b080592de07e4d1eb72ab0d1b5 file_len:484 hold_direct/src/main.rs
# checksum:blake3=b5d1e70f1eaa471a592b91e695b13d181156521c31840321052f937a87937658 file_len:2 /mnt/devbox-scratch/dev-user/ohm-observer-read-holdout-20261028/candidate/trained-include-bytes-preserved/private-input.txt
