const INPUT: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/ordinary-input/value.bin"));
const _: [();17] = [();INPUT[0] as usize];
fn main() { println!("{}",INPUT[0]); }
