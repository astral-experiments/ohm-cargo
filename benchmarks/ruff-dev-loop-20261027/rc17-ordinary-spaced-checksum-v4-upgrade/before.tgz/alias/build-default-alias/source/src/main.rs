const INPUT: &[u8] = include_bytes!("../alias space/value.bin");
fn main() { println!("{}",INPUT[0]); }
