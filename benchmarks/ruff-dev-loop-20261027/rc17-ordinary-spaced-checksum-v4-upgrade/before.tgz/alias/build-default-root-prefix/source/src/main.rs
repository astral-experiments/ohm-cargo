const INPUT: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/ordinary-input/value.bin"));
fn main() { println!("{}",INPUT[0]); }
