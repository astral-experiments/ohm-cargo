const INPUT: &[u8] = include_bytes!("../alias space/value.bin");
const _: [();17] = [();INPUT[0] as usize];
fn main() { println!("{}",INPUT[0]); }
