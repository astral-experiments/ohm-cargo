const INPUT: &[u8] = include_bytes!("../input-space/value.bin");
fn main() { println!("{}",INPUT[0]); }
