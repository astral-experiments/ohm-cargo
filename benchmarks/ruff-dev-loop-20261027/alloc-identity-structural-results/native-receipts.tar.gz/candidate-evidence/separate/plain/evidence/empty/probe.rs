#![crate_type="rlib"]
#![feature(core_intrinsics, const_heap)]
#![allow(internal_features)]
const fn heap() -> &'static [u8; 8] {
    unsafe {
        let p = core::intrinsics::const_allocate(8, 1) as *mut [u8; 8];
        *p = *b"abcdefgh";
        &*(core::intrinsics::const_make_global(p.cast()) as *const [u8; 8])
    }
}
pub const ALLOC: &[u8; 8] = heap();
pub const LITERAL: &[u8; 8] = b"abcdefgh";
pub static FIRST: [u8; 8] = *b"abcdefgh";
pub static SECOND: [u8; 8] = *b"abcdefgh";
#[inline] pub fn left() -> &'static [u8; 8] { ALLOC }
#[inline] pub fn right() -> (&'static [u8; 8], u32) { (LITERAL, 8) }
pub fn observed() -> u32 {
    assert_eq!(left(), right().0);
    assert!(!core::ptr::eq(&FIRST, &SECOND));
    right().1
}

