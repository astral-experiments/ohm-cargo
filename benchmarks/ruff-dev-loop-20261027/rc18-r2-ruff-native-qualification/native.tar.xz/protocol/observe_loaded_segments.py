from pathlib import Path
import hashlib,json,os,time
R=Path('/home/dev-user/.cache/ohm-rc18-r2-whole-ruff-20261028');S=R/'sdk';front=S/'bin/rustc';driver=S/'lib/librustc_driver-774a793a844d5500.so';wild=S/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
facts={}
for _ in range(1200):
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            prog=Path(os.readlink(proc/'exe'))
            if prog.name=='rustc' and prog.samefile(front) and 'compiler' not in facts:
                raw=(proc/'cmdline').read_bytes();args=raw.split(b'\0')
                if b'--crate-name' not in args or b'--out-dir' not in args:continue
                crate=args[args.index(b'--crate-name')+1].decode()
                if crate.startswith('__'):continue
                rows=[l for l in (proc/'maps').read_text().splitlines() if str(driver) in l and 'r-xp' in l]
                if not rows:continue
                l=rows[0];f=proc/'root'/driver.relative_to('/');st=os.stat(f)
                assert all(int(ln.split()[4])==st.st_ino for ln in rows) and f.samefile(driver)
                facts['compiler']={'pid':int(proc.name),'frontend_sha256':sha(proc/'exe'),'driver_sha256':sha(f),'mapping':l,'all_executable_mappings':rows,'argv_sha256':hashlib.sha256(raw).hexdigest(),'crate':crate,'driver_inode':st.st_ino}
            if prog==wild and 'linker' not in facts:
                raw=(proc/'cmdline').read_bytes();args=raw.split(b'\0')
                if b'-o' not in args:continue
                facts['linker']={'pid':int(proc.name),'sha256':sha(proc/'exe'),'argv_sha256':hashlib.sha256(raw).hexdigest(),'output':Path(os.fsdecode(args[args.index(b'-o')+1])).name}
        except (OSError,ValueError,IndexError):continue
    if facts:
        t=R/'actual-loaded-all-segments.pending';t.write_text(json.dumps(facts,indent=2,sort_keys=True)+'\n');os.replace(t,R/'actual-loaded-all-segments.json')
    if len(facts)==2:break
    if (R/'worker.exit').exists():break
    time.sleep(.4)
print(json.dumps(facts))
