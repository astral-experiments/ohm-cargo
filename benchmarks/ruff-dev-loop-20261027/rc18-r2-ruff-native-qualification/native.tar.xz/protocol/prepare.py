from pathlib import Path
import hashlib,json,os,shutil,socket,subprocess,sys,tomllib
assert socket.gethostname()=='charlie-ohm-c5-check-1025'
R=Path('/home/dev-user/.cache/ohm-rc18-r2-whole-ruff-20261028')
W=Path('/mnt/devbox-scratch/dev-user/ohm-combined-prs-20261028')
S=R/'sdk';K=R/'protocol';src=Path('/home/dev-user/code/oss/ruff-ohm-combined-prs-20261028'); copy=R/'source'
read=lambda f:json.loads(f.read_bytes())
def sha(f):
    with f.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
def save(n,d): (R/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def git(where,*a):return subprocess.check_output(['git','--no-optional-locks','-C',where,*a])
pin='93526150df078af7dd8fc4226cdcc469539d2001';hist=read(K/'historical.json')
assert shutil.disk_usage(R).free>160*2**30 and not (R/'prepare.done').exists()
assert git(src,'rev-parse','HEAD').decode().strip()==hist['ruff']==pin and not git(src,'status','--porcelain','-z')
index=hashlib.sha256(git(src,'ls-files','--stage','-z')).hexdigest();assert index==read(W/'ruff.json')['index']
assert sha(K/'historical.patch')==hist['patch_sha256']
assert sha(S/'bin/rustc')=='4fa9a18b77430bcc416e88561b6fe5797d98b996a7698b9f3bd11d4e7817a19f'
expected=read(K/'h2-original-sdk.json');actual=json.loads(subprocess.check_output([sys.executable,'-B',K/'sdk-manifest.py',S]))
core='lib/librustc_driver-774a793a844d5500.so';wild='lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd';bank='bin/cargo'
assert set(actual)==set(expected)-{core},set(actual)^set(expected)
for path in sorted(set(actual)-{bank}):assert actual[path]==expected[path],path
assert actual[bank]['sha256']==read(Path('/mnt/devbox-scratch/dev-user/ohm-rc18-pgo-qualification-20261028/complete.json'))['candidate']=='cfc66a7ceee5cad8f8939245d359e4db0d2b6f2abb5760c7cbefa6c9a1d454f8'
assert actual[wild]['sha256']==read(W/'sdk.json')['tools']['wild']==sha(W/'official-installed17'/wild)
save('partial-sdk.json',actual)
assert not copy.exists() and (src/'.git').is_dir() and not (src/'.git').is_symlink()
subprocess.run(['cp','-a','--reflink=auto',src,copy],check=True)
assert git(copy,'rev-parse','HEAD').decode().strip()==pin and not git(copy,'status','--porcelain','-z')
for f,s in hist['source'].items():
    assert sha(src/f)==sha(copy/f)==s['original'] and (src/f).stat().st_ino!=(copy/f).stat().st_ino
subprocess.run(['git','--no-optional-locks','-C',copy,'apply','--reverse','--check',K/'historical.patch'],check=True)
reg=W/'registry-seed-v2';crates=[x for x in tomllib.loads((src/'Cargo.lock').read_text())['package'] if 'source' in x];assert len(crates)==498
cache,=(reg/'registry/cache').iterdir();idx=reg/'registry/index'/cache.name
assert hashlib.sha256(cache.name.encode()).hexdigest()==read(W/'registry-v2.json')['offline_registry_id_sha256'] and sha(idx/'config.json')==read(W/'registry-v2.json')['offline_registry_config_sha256']
for x in crates:
    assert x['source']=='registry+https://github.com/rust-lang/crates.io-index' and sha(cache/(x['name']+'-'+x['version']+'.crate'))==x['checksum']
(R/'rustup/toolchains').mkdir(parents=True);(R/'rustup/toolchains/ohm').symlink_to(S)
for mode in ('check','build','test'):
    st=R/'states'/mode;st.mkdir(parents=True)
    # Copy only registry crates and index. Each Cargo home and workspace products start physically separate.
    subprocess.run(['cp','-a','--reflink=auto',reg,st/'cargo'],check=True)
    assert not (st/'cargo/registry/src').exists()
    for name in ('target','shared','home','tmp'):(st/name).mkdir()
(R/'records').mkdir()
save('prepare.done',{'source_commit':pin,'source_index':index,'tracked_paths':len(git(src,'ls-files','-z').split(b'\0'))-1,'historical_parent_change':hist['historical_commit'],'sdk_immutable_leaves':len(actual),'packages':len(crates),'registry_index_identity_sha256':hashlib.sha256(cache.name.encode()).hexdigest(),'free_root':shutil.disk_usage(R).free,'free_scratch':shutil.disk_usage(W).free,'free_floor_root':60*2**30,'cargo':actual[bank]['sha256'],'frontend':actual['bin/rustc']['sha256'],'wild':actual[wild]['sha256']})
print((R/'prepare.done').read_text())
