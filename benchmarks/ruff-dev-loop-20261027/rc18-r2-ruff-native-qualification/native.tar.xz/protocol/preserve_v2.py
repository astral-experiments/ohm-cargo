"""Run the unchanged qualification and retain physical native output bytes after every terminal Cargo invocation."""
from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,sys,traceback
sys.path.insert(0,str(Path(__file__).resolve().parent))
import whole_v2 as whole
assert whole.sha(Path(whole.__file__))=='f28e01f14dee09b0b94a9ba5c085bb623dfae0630f84d513f8fc3e07d24bc050'
store=whole.R/'native-outputs';assert store.is_dir() and not list(store.iterdir())
original=whole.command
def snapshot(mode,phase,state):
    row=original(mode,phase,state);d=whole.D/mode/phase
    procs=json.loads((d/'actual-processes.json').read_bytes());paths={Path(s) for s in row['native_terminal']};wild=[]
    for job in procs['processes']:
        if job['kind']!='wild':continue
        lines=(d/'trace'/('exec.'+str(job['pid']))).read_bytes().splitlines()
        line,=[l for l in lines if hashlib.sha256(l).hexdigest()==job['argv_sha256']]
        m=re.match(rb'^execve\(("(?:[^"\\]|\\.)*"),\s*(\[.*\]),\s*(?:0x[\da-f]+|NULL)',line)
        a=ast.literal_eval(m[2].decode());f=Path(a[a.index('-o')+1])
        info={'pid':job['pid'],'argv_sha256':job['argv_sha256'],'output':str(f),'retained':False};wild.append(info)
        if f.is_absolute() and f.is_file():paths.add(f)
    files={}
    for f in sorted(paths):
        if not f.is_file():continue
        with f.open('rb') as r:
            if r.read(4)!=b'\x7fELF':continue
        digest=whole.sha(f);dest=store/digest;size=f.stat().st_size
        if not dest.exists():
            assert shutil.disk_usage(store).free>60*2**30+size+2**30
            temp=dest.with_suffix('.pending')
            subprocess.run(['cp','--reflink=auto','--preserve=mode,timestamps',f,temp],check=True)
            assert temp.stat().st_ino!=f.stat().st_ino and whole.sha(temp)==digest and whole.sha(f)==digest
            temp.chmod(0o444);os.rename(temp,dest)
        assert dest.stat().st_size==size
        files[str(f)]={'sha256':digest,'size':size}
    for info in wild:
        if info['output'] in files:
            info['retained']=True;info.update(files[info['output']])
    whole.save(d/'retained-links.json',{'wild':wild,'elf':files,'report_only':True,'original_packaged_wild':whole.sha(whole.WILD)})
    return row
whole.command=snapshot
whole.save(whole.R/'preservation-protocol-v2.json',{'native_worker':whole.sha(Path(whole.__file__)),'sidecar':whole.sha(Path(__file__)),'purpose':'Qualify Rust/Cargo with original package Wild. Preserve terminal ELF bytes and accessible original active linker destinations after each command.'})
try:whole.main()
except Exception:
    if not (whole.R/'failure-v2.txt').exists():(whole.R/'failure-v2.txt').write_text(traceback.format_exc())
    traceback.print_exc();sys.exit(1)
