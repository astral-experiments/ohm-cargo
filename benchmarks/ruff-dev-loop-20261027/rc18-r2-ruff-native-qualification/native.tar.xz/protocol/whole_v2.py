"""Qualify released Cargo with the matched R2 Rust driver in three initially empty native Ruff workspaces."""
from pathlib import Path
import argparse,ast,collections,fcntl,hashlib,json,os,re,shutil,signal,socket,subprocess,sys,traceback
R=Path('/home/dev-user/.cache/ohm-rc18-r2-whole-ruff-20261028')
O=Path('/home/dev-user/code/oss/ruff-ohm-combined-prs-20261028')
P=R/'protocol'; S=R/'sdk'; W=R/'source'; D=R/'records'
RUST=S/'bin/rustc'; CARGO=S/'bin/cargo'; WILD=S/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'; DRIVER=S/'lib/librustc_driver-774a793a844d5500.so'
MODES={'check':['check'],'build':['build'],'test':['test','--workspace','--no-run']}
ORACLES=json.loads((P/'historical.json').read_bytes());PIN=ORACLES['ruff']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(f,o):
    q=f.with_name(f.name+'.partial');q.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n');os.replace(q,f)
def room(floor=60):
    free=shutil.disk_usage(R).free
    if free<floor*2**30:raise RuntimeError(f'QA reserve: {free} < {floor} GiB')
    return free
def source(state):
    assert subprocess.check_output(['git','--no-optional-locks','-C',W,'rev-parse','HEAD']).decode().strip()==PIN
    original=subprocess.check_output(['git','--no-optional-locks','-C',O,'status','--porcelain','-z'])
    assert not original
    for raw,ident in ORACLES['source'].items():
        want=ident['reversed' if state=='reversed' else 'original'];f=W/raw
        assert (sha(f) if f.exists() else None)==want and sha(O/raw)==ident['original'],(raw,want)
    changes=set(subprocess.check_output(['git','--no-optional-locks','-C',W,'diff','--name-only']).decode().splitlines())
    assert changes==(set(ORACLES['source']) if state=='reversed' else set()),changes
def edit(reverse):
    args=['git','-C',str(W),'apply']+(['--reverse'] if reverse else [])
    subprocess.run(args+['--check',str(P/'historical.patch')],check=True);subprocess.run(args+[str(P/'historical.patch')],check=True)
    source('reversed' if reverse else 'original')
def nsenv(mode,d):
    st=R/'states'/mode
    ns=['bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--ro-bind',str(W),str(O),'--ro-bind',str(S),str(S),'--bind',str(d),str(d)]
    for n in ('target','shared','cargo','tmp','home'):ns+=['--bind',str(st/n),str(st/n)]
    ns+=['--chdir',str(O),'--']
    env=dict(HOME=str(st/'home'),PATH='/home/dev-user/.cargo/bin:/usr/local/bin:/usr/bin:/bin',USER=os.environ['USER'],RUSTUP_HOME=str(R/'rustup'),RUSTUP_AUTO_INSTALL='0',CARGO_HOME=str(st/'cargo'),CARGO_BUILD_BUILD_DIR=str(st/'shared'),CARGO_TARGET_DIR=str(st/'target'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='8',CARGO_TERM_COLOR='never',TMPDIR=str(st/'tmp'),LC_ALL='C.UTF-8',LANG='C.UTF-8',GIT_OPTIONAL_LOCKS='0')
    assert not any('TRUST' in k or k in ('RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER') for k in env)
    return ns,env
def capture(ns,env,argv,d,stdin=None,want=0):
    d.mkdir();save(d/'argv.json',list(map(str,argv)))
    q=subprocess.run(ns+list(map(str,argv)),input=stdin,env=env,capture_output=True,timeout=180)
    (d/'stdout').write_bytes(q.stdout);(d/'stderr').write_bytes(q.stderr);save(d/'exit.json',q.returncode)
    assert q.returncode==want,(d,q.returncode,q.stderr[-1600:])
    return q
def jobs(trace):
    counts=collections.Counter(); rec=[]; paths={}; rawindex={}
    pattern=re.compile(rb'^execve\(("(?:[^"\\]|\\.)*"),\s*(\[.*\]),\s*(?:0x[\da-f]+|NULL).*?\)\s+= 0$')
    for f in sorted(trace.glob('exec.*')):
        raw=f.read_bytes();rawindex[f.name]=hashlib.sha256(raw).hexdigest()
        for line in raw.splitlines():
            if not line.startswith(b'execve(') or not line.endswith(b'= 0'):continue
            m=pattern.match(line);assert m,(f,line[:250])
            name=Path(ast.literal_eval(m[1].decode()));argv=ast.literal_eval(m[2].decode())
            if name.name not in ('cargo','rustc','collect2','ld.bfd','ld.lld','ld','rust-lld','wild','mold','rustdoc'):continue
            if name not in paths:
                try:paths[name]=name.resolve(strict=True)
                except FileNotFoundError:paths[name]=name
            exe=paths[name];kind=None;detail=None
            if exe==CARGO:
                if argv[1:]==['--version']:kind='cargo-version'
                else:
                    assert argv[1] in ('check','build','test') and '--locked' in argv and '--message-format=json' in argv,argv
                    kind='cargo'
            elif exe==RUST and '--crate-name' in argv and not any(v.startswith('--print') for v in argv):
                kind='link-only' if any(s in ('-Zlink-only','link-only') or s.startswith('link-only=') for s in argv) else 'full'
                detail=argv[argv.index('--crate-name')+1]
            elif name.name=='collect2':kind='collect2'
            elif '-o' in argv and name.name in ('ld.bfd','ld.lld','ld','rust-lld','wild','mold'):
                out=argv[argv.index('-o')+1];detail=Path(out).name
                if exe==WILD:kind='wild'
                elif str(exe)=='/usr/bin/x86_64-linux-gnu-ld.bfd' and out=='conftest':kind='configure-linker'
                else:kind='other-linker'
            elif name.name=='rustdoc':kind='rustdoc'
            if kind:
                counts[kind]+=1;rec.append({'pid':int(f.suffix[1:]),'kind':kind,'unit_or_output':detail,'executable':str(exe),'argv_sha256':hashlib.sha256(line).hexdigest()})
    assert counts['cargo']==1 and not counts['other-linker'],counts
    return dict(counts=dict(counts),processes=rec,raw_trace_sha256=rawindex)
def consumers(mode,d,ns,env,records,state):
    deps=set();items=set()
    for m in records:
        for s in m['filenames']:
            f=Path(s)
            if f.suffix in ('.rlib','.rmeta','.so'):deps.add(f.parent)
            if m['target']['name']=='ruff_python_trivia' and f.suffix==('.rmeta' if mode=='check' else '.rlib'):items.add(f)
    assert items and len(items)<=3,items
    results=[];key='reversed' if state=='reversed' else 'original'
    for i,lib in enumerate(sorted(items)):
        common=['rustc','+ohm','--edition=2024','--extern','ruff_python_trivia='+str(lib)]
        for directory in sorted(deps):common+=['-L','dependency='+str(directory)]
        orig=d/f'ordinary-{i}';orig.mkdir()
        if mode=='check':
            capture(ns,env,common+[P/'ordinary.rs','--emit=metadata','-o',orig/'probe.rmeta'],orig/'ordinary-good')
            q=capture(ns,env,common+[P/'ill-typed.rs','--crate-name','invalid_consumer','--emit=metadata','--error-format=json','-o',orig/'bad.rmeta'],orig/'ordinary-bad',want=1)
            errors=[j for line in q.stderr.splitlines() if (j:=json.loads(line)).get('code')]
            assert len(errors)==1 and errors[0]['code']['code']=='E0308'
            results.append({'library':str(lib),'sha256':sha(lib),'good':0,'invalid':errors[0]['code']['code']})
        else:
            exe=orig/'ordinary';capture(ns,env,common+[P/'ordinary.rs','-o',exe],orig/'compile')
            q=capture(ns,env,[exe],orig/'run');assert q.stdout.decode()==ORACLES['oracles'][key] and not q.stderr
            results.append({'library':str(lib),'sha256':sha(lib),'output':q.stdout.decode(),'ordinary_exe_sha256':sha(exe)})
    if mode=='build':
        cli,={Path(m['executable']) for m in records if m['target']['name']=='ruff' and m['executable'] and m['target']['kind']==['bin']}
        q=capture(ns,env,[cli,'check','--no-cache','--isolated','--select','RET505','--unsafe-fixes','--fix-only','--exit-zero','--stdin-filename','sample.py','-'],d/'real-ruff-ret505',stdin=(P/'ret505.py').read_bytes())
        assert b'def f(condition)' in q.stdout
        results.append({'ruff_cli':str(cli),'fixed_source_sha256':hashlib.sha256(q.stdout).hexdigest()})
    if mode=='test':
        test,={Path(m['executable']) for m in records if m['target']['name']=='ruff_python_parser' and m.get('executable') and m['profile']['test'] and 'lib' in m['target']['kind']}
        listing=capture(ns,env,[test,'--list'],d/'parser-test-list').stdout
        case,=[v.decode().removesuffix(': test') for v in listing.splitlines() if v.endswith(b'::test_modes: test')]
        q=capture(ns,env,[test,'--exact',case],d/'selected-parser-test');assert b'1 passed; 0 failed' in q.stdout
        results.append({'parser_test':str(test),'list_sha256':hashlib.sha256(listing).hexdigest(),'case':case})
    return results
def command(mode,phase,state):
    room(65);source(state);d=D/mode/phase;ns,env=nsenv(mode,d)
    if mode=='check' and phase=='cold' and (d/'exit.json').exists():
        assert json.loads((d/'exit.json').read_bytes())==0 and not (d/'result.json').exists()
        bound=json.loads((d/'command.json').read_bytes())
        assert bound['driver']==sha(DRIVER) and bound['cargo']==sha(CARGO) and bound['source_state']==state and bound['argv']==['cargo','+ohm','check','--locked','--offline','-j8','--message-format=json']
        assert 'other-linker' in (R/'failure.txt').read_text() and (R/'worker.exit').read_text().strip()=='1'
    else:
        d.mkdir(parents=True)
        assert subprocess.check_output(ns+['rustc','+ohm','--print','sysroot'],env=env).decode().strip()==str(S)
        argv=['cargo','+ohm',*MODES[mode],'--locked','--offline','-j8','--message-format=json'];(d/'trace').mkdir()
        prefix=['strace','-ff','-q','-s','262144','-e','trace=execve','-o',str(d/'trace/exec')]
        save(d/'command.json',{'argv':argv,'source_state':state,'trust_overrides':[],'environment':env,'driver':sha(DRIVER),'cargo':sha(CARGO),'initial_free':room()})
        with (d/'stdout').open('xb') as out,(d/'stderr').open('xb') as err:
            proc=subprocess.Popen(ns+prefix+argv,env=env,stdout=out,stderr=err,start_new_session=True)
            try:
                while proc.poll() is None:
                    room()
                    try:proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:pass
            except BaseException:
                if proc.poll() is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=25)
                raise
        save(d/'exit.json',proc.returncode)
        assert proc.returncode==0,(d,proc.returncode,(d/'stderr').read_bytes()[-3800:])
    events=[json.loads(l) for l in (d/'stdout').read_bytes().splitlines()];assert events[-1]=={'reason':'build-finished','success':True}
    arts=[v for v in events if v['reason']=='compiler-artifact'];assert len(arts)>=400 and any(v['target']['name']=='ruff_python_trivia' for v in arts)
    diag=[v['message'] for v in events if v['reason']=='compiler-message'];assert not any(v['level']=='error' for v in diag)
    p=jobs(d/'trace');save(d/'actual-processes.json',p)
    roster=sorted(json.dumps([v['package_id'],v['target']['name'],v['target']['kind'],v['features'],v['profile']],sort_keys=True) for v in arts)
    native={}
    for row in arts:
        for raw in [*row['filenames'],row.get('executable')]:
            if not raw or raw in native:continue
            path=Path(raw);assert path.is_file(),path
            if raw==row.get('executable') or path.suffix=='.so' or (row['target']['name']=='ruff_python_trivia' and path.suffix in ('.rlib','.rmeta')):
                native[raw]={'sha256':sha(path),'size':path.stat().st_size}
    sig=hashlib.sha256(json.dumps(roster,separators=(',',':')).encode()).hexdigest()
    if phase!='cold':assert sig==json.loads((D/mode/'cold/result.json').read_bytes())['roster_sha256'],(d,'roster')
    else:assert not any(v['fresh'] for v in arts)
    witness=consumers(mode,d,ns,env,arts,state) if phase in ('cold','edited','restored') else []
    out={'phase':phase,'mode':mode,'source_state':state,'artifacts':len(arts),'fresh':sum(v['fresh'] for v in arts),'dirty':[v['target']['name'] for v in arts if not v['fresh']],'roster_sha256':sig,'diagnostics':[{'level':v['level'],'message':v['message']} for v in diag],'native_terminal':native,'actual':p['counts'],'ordinary':witness,'free_after':room(),'cargo_stdout_sha256':sha(d/'stdout'),'cargo_stderr_sha256':sha(d/'stderr')}
    save(d/'result.json',out);print(mode,phase,len(arts),out['fresh'],out['actual'],flush=True);return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--driver',type=Path,required=True);ap.add_argument('--sha',required=True);a=ap.parse_args()
    assert socket.gethostname()=='charlie-ohm-c5-check-1025' and re.fullmatch('[0-9a-f]{64}',a.sha)
    assert (R/'prepare.done').is_file() and sha(a.driver)==sha(DRIVER)==a.sha
    launch=json.loads((R/'launch.json').read_bytes())
    assert launch['tree']==PIN and launch['driver']==a.sha and launch['cargo']==sha(CARGO) and launch['packaged_wild']==sha(WILD)
    assert not (R/'progress.json').exists() and not (R/'complete.json').exists() and not (R/'failure-v2.txt').exists()
    assert sorted(d.name for d in D.iterdir())==['cargo-version','check','rustc-version']
    save(R/'observation-amendment-v2.json',{'first_cargo_command_exit':json.loads((D/'check/cold/exit.json').read_bytes()),
        'raw_stdout_sha256':sha(D/'check/cold/stdout'),'failure_sha256':sha(R/'failure.txt'),'original_worker':launch['worker'],
        'replayed_from_existing_trace':True,'new_worker':sha(Path(__file__)),'accepted_cargo_probe':['--version'],
        'accepted_system_linker':'/usr/bin/x86_64-linux-gnu-ld.bfd','accepted_system_link_output':'conftest'})
    completed=[]
    for phase,state in [('cold','original'),('unchanged','original'),('edited','reversed'),('restored','original'),('final-unchanged','original')]:
        if phase=='edited':edit(True)
        if phase=='restored':edit(False)
        for mode in MODES:
            row=command(mode,phase,state);completed.append([mode,phase,row['artifacts'],row['fresh'],row['actual']]);save(R/'progress.json',completed)
    source('original')
    for mode in ('build','test'):
        values=[json.loads((D/mode/ph/'result.json').read_bytes())['ordinary'] for ph in ('cold','edited','restored')]
        assert values[0][0]['output']==values[2][0]['output']!=values[1][0]['output']
        if mode=='build':assert values[0][-1]['fixed_source_sha256']==values[2][-1]['fixed_source_sha256']
        else:assert len({w[-1]['list_sha256'] for w in values})==1
    save(R/'complete.json',{'records':completed,'restored':True,'release':sha(CARGO),'driver':sha(DRIVER),'root_free':room(),'scratch_free':shutil.disk_usage('/mnt/devbox-scratch').free})
if __name__=='__main__':
    try: main()
    except Exception:
        if not (R/'failure.txt').exists():(R/'failure.txt').write_text(traceback.format_exc())
        traceback.print_exc();sys.exit(1)
