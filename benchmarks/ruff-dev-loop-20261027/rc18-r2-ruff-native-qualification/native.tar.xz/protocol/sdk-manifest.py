from pathlib import Path
import hashlib,json,os,sys
root=Path(sys.argv[1])
out={}
for p in sorted(root.rglob('*')):
    n=str(p.relative_to(root))
    if p.is_symlink():out[n]={'link':os.readlink(p)}
    elif p.is_file():
        with p.open('rb') as f:out[n]={'sha256':hashlib.file_digest(f,'sha256').hexdigest(),'size':p.stat().st_size}
print(json.dumps(out,indent=2,sort_keys=True))
