# Reopen the whole Ruff CLI branch-return confirmation

This independent reader compares one packed rustc with its branch cache disabled and enabled. Both dispatches build Ruff with strict Cargo, stock Wild, four jobs, a locked offline registry, and ordinary Cargo defaults. Only the enabled arm sets CARGO_ENCODED_RUSTFLAGS to "-Zohm-branch-cache=yes". All hardware counts cover Cargo and its descendant processes in user mode. The inherited disabled-at-start hardware instruction event enables on its child's exec. Source, compiler image, observer ABI, positive nested/thread/process calibration and the authentic original archive are checked for each boot. ELF sections, executable load bytes, the typed parser, command outputs and both real error/repair histories are replayed. This reader also checks hardlink-deduplicated allocated blocks in the complete build and target directories against find, du and Python. Allocations represent visit ends.

The aged full-Ruff GNU native-link explanation is a separate, pinned unscored source run. These measured commands emitted typed Cargo rosters and PMU records. The reader does not infer a physical compiler or linker census from those rosters. It verifies the per-arm native provider controls independently, including a backdated in-place 83→47 and malformed replacement.

## One-step offline statistical replay

From this directory on Python 3.11+ run:

    python3 -IB confirm.py score results/c1-raw.json results/c2-raw.json --out /tmp/confirmed-packed-ruff.json

Compare SHA-256 with the final verification manifest. This mode uses only the original-byte-replayed position projections in this packet. It needs no network, system counter, root privilege, Ruff checkout or compilation. It does not rehash the complete ELF bodies in the original hosted ZIP files. The next section does that independently.

## Reopen every original

Clone or point at the three existing source checkouts below. The calibrator's fixed commit and the observer's exact checkout are validated. The Ruff source checkout must contain the exact commits, trees, unmodified Cargo.lock and both parser files. All Git operations are read-only. Use Linux, Python 3.11+, git, zstd, GNU sha256sum, a writable /dev/shm, hardware-counter-free readers and the original artifact access for astral-experiments/ohm via gh-auto.

    export OHM_RUFF_REPO=/path/to/ruff
    export OHM_CALIBRATOR_REPO=/path/to/packaging/git-with-2f413ca94b84af2dbd6d6231bcf8d860c97ebee8
    export OHM_OBSERVER_REPO=/path/to/packaging/clean-8a659140df8ab27fd6a8cc61f5eb38717b3f8bbc
    sha256sum --check READER-SHA256
    (cd original && sha256sum --check SOURCE-SHA256)

The default paths point to the established coordinator checkouts. For each pair below, set its cohort and its official run, then execute the two commands. The separate catalog file preserves the GitHub originals for an offline rerun. Only attempt 1 on the exact dispatch is accepted.

| cohort | run |
|---|---|
| c1 | 41219513694 |
| c2 | 41219530573 |

    head=1d446332e82ca0188f63c3fddc9689f1f131fd42
    branch=charlie/qa-packed-ordinary-confirmation-20261031
    python3 -IB confirm.py catalog --cohort "$cohort" --run "$run" --head "$head" --branch "$branch" --out "results/$cohort-catalog.json"
    python3 -IB confirm.py reopen --catalog "results/$cohort-catalog.json" --out "results/$cohort-raw.json"

If the original ZIPs are already on local read-only storage, add "--archives /path/to/files" to "reopen" and use the authenticated catalogs instead of contacting GitHub. Names are RUN-POSITION-ARTIFACTID.zip as recorded in each catalog. The network mode holds one archive per reader in a bounded anonymous memory file and releases it before the next position. Raw compressed Rust ELF inputs are decoded into a separate anonymous memory file and checked against the original SHA, load segments, all sections and actual defined Ruff main symbol. Calibration is a readback of historical raw bytes, with scratch in RAM. It launches no Rust compiler or native workload.

## Statistical decision

Odd c1 and even c2 positions run Koff then Kon. Each cohort has 12 distinct boots, one per position. Each boot contributes (Koff return-A + return-B)/(Kon return-A + return-B), both sums in raw retired user instructions. The median and third/tenth ordered bounds are exact rational numbers. The two-sided interval covers 1969/2048 (96.142578125%) for a continuous population median. The decision requires both lower bounds to strictly exceed 2. The excluded two-machine screen, earlier refused workers, individual directions, arm-order strata, elapsed time and exploratory costs never enter this gate.

Each position retains all seven phases with raw start/stop, child CPU, counter status/time covered, exit and instruction counts. All five successful commands, the invalid/repair commands, first-switch overhead, observed allocation high-water marks and modeled repeat count to repay the initial cost are separate. A missing terminal, failed calibration, stale program or replicated boot withholds the complete decision. A true lower bound at or below two returns a negative decision even if the other cohort exceeds it. No replacement position is admitted.

## Negative controls

    python3 -IB test_reader.py
    python3 -IB pilot_exercise.py

The first runs 20 synthetic statistical and custody negatives, including a failed diagnostic exit, rank-three at exactly two, a duplicate boot and a ratio-of-sums counterexample. The second reopens two authentic excluded pilot ZIPs once each, independently checks all 28 prior counts plus allocations and program bodies, and exercises seven deliberate mutations (PMU errno and multiplexing, wrong diagnostic, stale typed reader, stale archive, forged ELF section and disk allocation). No pilot result enters the confirmation score. The two runs listed above are the only eligible inputs.
