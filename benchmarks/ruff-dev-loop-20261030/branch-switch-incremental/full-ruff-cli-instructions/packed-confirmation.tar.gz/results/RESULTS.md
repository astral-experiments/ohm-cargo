# Whole-Cargo instructions for branch returns in the GNU Ruff CLI

Koff and Kon used the same packed compiler, strict Cargo, Wild, locked archive set, and canonical paths. Each boot contributes the ratio of the two summed whole-Cargo return counts. The two 12-boot confirmations were independently registered before the first result. Their two screen boots and every prior refused stage are excluded.

| Cohort | Median return ratio | Exact rank 3–10 interval | Individual observed range | Off-first / on-first medians |
|---|---:|---:|---:|---:|
| c1 | 6.57428× | 6.57310–6.57557× | 6.57190–6.57600× | 6.57428× / 6.57407× |
| c2 | 6.57443× | 6.57351–6.57511× | 6.57334–6.57531× | 6.57443× / 6.57446× |

Each interval has 1969/2048 marginal coverage. Both lower bounds must strictly exceed two. The original score records exact fractions, absolute counts for each phase, and the identity of each bound.

| Individually paired median (off/on) | c1 | c2 |
|---|---:|---:|
| Cold A | 0.99996× | 1.00001× |
| First B | 0.93576× | 0.93564× |
| Return A | 7.42523× | 7.42563× |
| Return B | 5.89993× | 5.89956× |
| Immediate unchanged B | 0.99967× | 0.99964× |
| Invalid B, Cargo 101 | 0.72535× | 0.72534× |
| Repair B | 0.66938× | 0.66948× |
| First B plus first return A | 1.66259× | 1.66254× |
| Cold A through second return B | 1.36443× | 1.36450× |
| All five successful visits | 1.36410× | 1.36416× |
| All seven visits including rejection and repair | 1.34911× | 1.34918× |

| Descriptive per-boot costs | c1 median | c2 median |
|---|---:|---:|
| Extra instructions through first B | 58.05 billion | 58.00 billion |
| Instructions saved per return A+B | 1,434.07 billion | 1,434.13 billion |
| Return pairs to repay the initial overhead (model) | 1.0 | 1.0 |
| Maximum sampled allocation with cache off | 2.433 GiB | 2.433 GiB |
| Maximum sampled allocation with cache on | 2.686 GiB | 2.686 GiB |
| Paired peak allocation difference | 0.253 GiB | 0.253 GiB |

The allocation ledger deduplicates hardlinked inodes in both complete roots. Its maximum is sampled at visit ends. Storage modes observed were runner-filesystem. Raw start/stop, CPU, enabled/running, errno, retained byte counts and Cargo exits for all 336 hardware observations are in all-phases.tsv. The disabled-at-start inherited hardware event counts the normal Cargo process tree in user mode. Stock native provider failures and recovery were checked separately. These measured Cargo commands do not carry the distinct historical physical linker census.

