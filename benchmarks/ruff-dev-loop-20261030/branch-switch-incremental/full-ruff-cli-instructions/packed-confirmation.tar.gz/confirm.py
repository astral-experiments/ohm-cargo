"""Independently acquire, physically reopen, and then score the two original 12-boot cohorts."""
import argparse, gzip, json, os, sys, tempfile, time, traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import custody as C
from position import host, original
from scoring import summarize

def pinned(cohort,run,head,branch):
    C.need(head=="1d446332e82ca0188f63c3fddc9689f1f131fd42","not the frozen confirmation source")
    bindings=HERE/"runs.json"
    C.need(bindings.is_file(),"both separately dispatched run IDs must be registered before reading results")
    ids=C.get(bindings)
    C.need(set(ids)==set(C.COHORTS) and all(C.positive_int(v) for v in ids.values())
           and len(set(ids.values()))==2 and ids[cohort]==run,"wrong official enrolled confirmation")
    return C.spec(cohort,run,head,branch,C.REG["plan"])

def ruff_inputs():
    import replay_controls as controls
    # These only select a read-only exact Git checkout. All source identities are authenticated.
    if "OHM_OBSERVER_REPO" in os.environ: controls.OBSERVER=Path(os.environ["OHM_OBSERVER_REPO"])
    if "OHM_CALIBRATOR_REPO" in os.environ: controls.PACKAGING=Path(os.environ["OHM_CALIBRATOR_REPO"])
    return original.corpus.source(Path(os.environ.get("OHM_RUFF_REPO",str(original.corpus.RUFF))))

def rowrefused(z,row):
    failure=z.read("failure.txt") if "failure.txt" in z.NameToInfo else b""
    return {"error":"official job " + row["job_conclusion"],"failure_sha256":C.sha(failure),
            "failure_excerpt":failure.decode(errors="replace")[-1000:],
            "has_complete":"complete.json" in z.NameToInfo,"zip_members":len(z.NameToInfo)}
def reopen(catalog,archives):
    checked=C.check_catalog(catalog); s=checked["spec"]
    C.need(pinned(s["cohort"],s["run"],s["head"],s["branch"])==s,"unregistered cohort source")
    inputs,parser=ruff_inputs()
    rows={}; tempfile.tempdir="/dev/shm"
    for p,row in checked["positions"].items():
        sys.stderr.write(f"Reopening {s['cohort']}/{p} official job {row['job']}\n");sys.stderr.flush()
        detail={"original":row}
        if "id" not in row:
            detail["error"]="missing official worker archive";rows[p]=detail;continue
        # Acquisition failures propagate, preventing a transient transfer from sealing a scientific refusal.
        with C.archive(row,archives) as z:
            if row["job_conclusion"]!="success":
                detail.update(rowrefused(z,row))
            else:
                try:
                    result=host(z,p,inputs,parser,s)
                    C.need(C.valid_boot(result["boot"]) and result["boot"] not in C.REG["excluded_boots"],
                           "previous/invalid enrolled boot")
                    detail["host"]=result
                except (ValueError,AssertionError,KeyError,TypeError) as e:
                    detail["error"]=f"original {type(e).__name__}: {str(e)[:1400]}"
                    detail["traceback"]=traceback.format_exc(limit=4)
        rows[p]=detail
    r={"spec":s,"catalog_sha256":C.sha(C.canonical(catalog)),"run_conclusion":checked["run_conclusion"],
       "positions":rows,"ruff_input_manifest_sha256":C.sha(C.canonical(inputs)),"locked_registry_archives":len(inputs["archives"])}
    return {"receipt":r,"sha256":C.sha(C.canonical(r))}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    subs=p.add_subparsers(dest="cmd",required=True)
    cat=subs.add_parser("catalog")
    cat.add_argument("--cohort",choices=C.COHORTS,required=True);cat.add_argument("--run",type=int,required=True)
    cat.add_argument("--head",required=True);cat.add_argument("--branch",required=True)
    cat.add_argument("--out",type=Path,required=True)
    read=subs.add_parser("reopen");read.add_argument("--catalog",type=Path,required=True)
    read.add_argument("--archives",type=Path);read.add_argument("--out",type=Path,required=True)
    sc=subs.add_parser("score");sc.add_argument("c1",type=Path);sc.add_argument("c2",type=Path)
    sc.add_argument("--out",type=Path,required=True)
    a=p.parse_args()
    if a.cmd=="catalog":
        result=C.fetch_catalog(pinned(a.cohort,a.run,a.head,a.branch))
    elif a.cmd=="reopen":
        result=reopen(C.get(a.catalog),a.archives)
    else:
        values=[C.get(a.c1),C.get(a.c2)]
        for v in values:
            s=v["receipt"]["spec"]
            C.need(s==pinned(s["cohort"],s["run"],s["head"],s["branch"]),"unregistered final source")
        result=summarize(*values)
    C.seal(a.out,result)
    print(f"{C.sha(C.canonical(result))}  {a.out}")
if __name__=="__main__": main()
