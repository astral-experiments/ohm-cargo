"""Reopen positions as their official archive appears; scoring remains terminal-only.
A final catalog binds all original artifact and job IDs again before outputs are assembled.
"""
import argparse, json, sys, tempfile, warnings
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import custody as C
import confirm
from position import host,original

def individual(s,run,j,a,p):
    c,n,h=s["cohort"],s["run"],s["head"]
    C.need((run["id"],run["head_sha"],run["head_branch"],run["run_attempt"],run["event"],run["path"],run["head_repository"]["full_name"],run["repository"]["full_name"],run["display_title"])==
           (n,h,s["branch"],1,"workflow_dispatch",".github/workflows/ci.yml",C.REPO,C.REPO,f"Packed Ruff confirmation {c} {h}"),"wrong dispatch")
    C.need((j["name"],j["status"],j["run_id"],j["head_sha"])==
           (f"Packed Ruff confirmation {c}-{p}","completed",n,h) and C.positive_int(j["id"]),"job identity")
    C.need((a["name"],a["expired"],a["workflow_run"]["id"],a["workflow_run"]["head_sha"])==
           (f"packed-ordinary-confirm-{c}-{p}",False,n,h),"incomplete official archive")
    import re
    C.need(C.positive_int(a["id"]) and type(a["size_in_bytes"]) is int and 0<a["size_in_bytes"]<=C.MAX_ARCHIVE and
           re.fullmatch("sha256:[a-f0-9]{64}",a["digest"]),"ZIP bytes")
    steps={step["name"]:step["conclusion"] for step in j["steps"]}
    identity=dict(job=j["id"],job_name=j["name"],job_conclusion=j["conclusion"],job_started=j["started_at"],
                  job_completed=j["completed_at"],position=p,steps={x:steps.get(x) for x in C.REQUIRED_STEPS},
                  id=a["id"],artifact_name=a["name"],size_in_bytes=a["size_in_bytes"],sha256=a["digest"][7:],
                  filename=f"{n}-{p}-{a['id']}.zip")
    if j["conclusion"]=="success":
        C.need(all(v=="success" for v in identity["steps"].values()),"failed physical steps")
    return identity

def take(s,run,j,a,p,inputs,parser,dst):
    meta=individual(s,run,j,a,p)
    detail={"original":meta}
    with C.archive(meta) as z:
        if meta["job_conclusion"]!="success":
            detail.update(confirm.rowrefused(z,meta))
        else:
            try:
                r=host(z,p,inputs,parser,s)
                C.need(C.valid_boot(r["boot"]) and r["boot"] not in C.REG["excluded_boots"],"previous/invalid enrolled boot")
                detail["host"]=r
            except (ValueError,AssertionError,KeyError,TypeError) as e:
                import traceback
                detail.update(error=f"original {type(e).__name__}: {str(e)[:1400]}",traceback=traceback.format_exc(limit=4))
    position={"spec":s,"position":p,"result":detail,"official_job":j,"official_archive":a,
              "ruff_input_manifest_sha256":C.sha(C.canonical(inputs))}
    C.seal(dst,{"sha256":C.sha(C.canonical(position)),"position":position})
    print(s["cohort"],p,meta["id"],"native refusal: "+detail["error"] if "error" in detail else "original ZIP and native gates verified",flush=True)

def harvest(outdir):
    inputs,parser=confirm.ruff_inputs()
    for c,r in C.get(HERE/"runs.json").items():
        s=confirm.pinned(c,r,"1d446332e82ca0188f63c3fddc9689f1f131fd42",C.REG["branch"])
        run=C.github.api(f"runs/{r}")
        jobs=C.github.api(f"runs/{r}/attempts/1/jobs?per_page=100")
        artifacts=C.github.api(f"runs/{r}/artifacts?per_page=100")
        C.need(jobs["total_count"]==len(jobs["jobs"])==12 and artifacts["total_count"]==len(artifacts["artifacts"]),
               "wrong official count")
        js={j["name"]:j for j in jobs["jobs"]}; aa={a["name"]:a for a in artifacts["artifacts"]}
        todo=0; done=0
        for p in C.POSITIONS:
            j=js[f"Packed Ruff confirmation {c}-{p}"]; a=aa.get(f"packed-ordinary-confirm-{c}-{p}")
            dst=outdir/f"{c}-{p}.json"
            if dst.is_file():
                done+=1;continue
            if not a or j["status"]!="completed":continue
            take(s,run,j,a,p,inputs,parser,dst);todo+=1
        print(f"{c} {run['status']} {done+todo}/12 positions verified",flush=True)
def assemble(catalog,outdir,dst):
    ck=C.check_catalog(catalog);s=ck["spec"]
    C.need(confirm.pinned(s["cohort"],s["run"],s["head"],s["branch"])==s,"unregistered")
    ruff,_=confirm.ruff_inputs();h=C.sha(C.canonical(ruff));posit={}
    for p,m in ck["positions"].items():
        if "id" not in m:
            posit[p]={"original":m,"error":"missing official worker archive"}
            continue
        wrapper=C.get(outdir/f"{s['cohort']}-{p}.json"); raw=wrapper["position"]
        C.need(wrapper["sha256"]==C.sha(C.canonical(raw)) and raw["spec"]==s and raw["position"]==p and
               raw["ruff_input_manifest_sha256"]==h and raw["result"]["original"]==m,"original reopening disagrees with final authenticated catalog")
        rr=catalog["official"]["run"];j=raw["official_job"];a=raw["official_archive"]
        C.need(individual(s,rr,j,a,p)==m,"original official position metadata changed")
        # Raw GitHub job and archive may acquire unrelated access metadata after completion.
        # The complete terminal catalog and per-position snapshots both remain available.
        posit[p]=raw["result"]
    v={"spec":s,"catalog_sha256":C.sha(C.canonical(catalog)),"run_conclusion":ck["run_conclusion"],
       "positions":posit,"ruff_input_manifest_sha256":h,"locked_registry_archives":len(ruff["archives"])}
    C.seal(dst,{"receipt":v,"sha256":C.sha(C.canonical(v))})
if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="cmd",required=True)
    for n in ("harvest","assemble"):
        c=sub.add_parser(n);c.add_argument("--positions",type=Path,required=True)
        if n=="assemble":
            c.add_argument("--catalog",type=Path,required=True);c.add_argument("--out",type=Path,required=True)
    opt=p.parse_args();tempfile.tempdir="/dev/shm"
    if opt.cmd=="harvest":harvest(opt.positions)
    else:assemble(C.get(opt.catalog),opt.positions,opt.out)
