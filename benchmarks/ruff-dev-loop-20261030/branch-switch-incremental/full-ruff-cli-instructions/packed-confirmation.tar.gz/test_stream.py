"""Exercise the optional per-position transport against the immutable terminal catalog rules."""
import copy, json, sys, tempfile, unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import custody as C, confirm, stream_positions as stream
from test_reader import HEAD,core

class StreamTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inputs,_=confirm.ruff_inputs()
    def fixture(self,dir):
        spec=confirm.pinned("c1",41219513694,HEAD,C.REG["branch"])
        run={"id":spec["run"],"head_sha":HEAD,"head_branch":spec["branch"],"run_attempt":1,"event":"workflow_dispatch",
             "path":".github/workflows/ci.yml","repository":{"full_name":C.REPO},"head_repository":{"full_name":C.REPO},
             "display_title":f"Packed Ruff confirmation c1 {HEAD}","status":"completed","conclusion":"success"}
        jobs={"jobs":[],"total_count":12}; arts={"artifacts":[],"total_count":12}
        rows=core("c1")["positions"];h=C.sha(C.canonical(self.inputs))
        for p in C.POSITIONS:
            j={"run_id":spec["run"],"head_sha":HEAD,"name":f"Packed Ruff confirmation c1-{p}","id":int(p)+60000,
               "status":"completed","conclusion":"success","started_at":"first","completed_at":"last",
               "steps":[{"name":n,"conclusion":"success"} for n in C.REQUIRED_STEPS]}
            a={"name":f"packed-ordinary-confirm-c1-{p}","id":int(p)+50000,"expired":False,"size_in_bytes":200,
               "digest":"sha256:"+C.sha(p.encode()),"workflow_run":{"id":spec["run"],"head_sha":HEAD}}
            jobs["jobs"].append(j);arts["artifacts"].append(a)
            ident=stream.individual(spec,run,j,a,p)
            r={"spec":spec,"position":p,"result":{"host":rows[p]["host"],"original":ident},"official_job":j,"official_archive":a,
               "ruff_input_manifest_sha256":h}
            C.seal(dir/f"c1-{p}.json",{"sha256":C.sha(C.canonical(r)),"position":r})
        catalog=C.official(spec,run,jobs,arts)|{"official":{"run":run,"jobs":jobs,"artifacts":arts}}
        return catalog
    def test_byte_schema_matches_registered_reader(self):
        with tempfile.TemporaryDirectory(dir="/dev/shm") as t:
            d=Path(t);catalog=self.fixture(d);stream.assemble(catalog,d,d/"merged.json")
            v=C.get(d/"merged.json");r=v["receipt"]
            self.assertEqual(v["sha256"],C.sha(C.canonical(r)))
            for p in C.POSITIONS:
                self.assertEqual(r["positions"][p]["original"],C.check_catalog(catalog)["positions"][p])
            self.assertEqual(r["catalog_sha256"],C.sha(C.canonical(catalog)))
    def test_wrong_final_digest_even_if_transport_rehashed(self):
        with tempfile.TemporaryDirectory(dir="/dev/shm") as t:
            d=Path(t);catalog=self.fixture(d)
            original=catalog["official"];original["artifacts"]["artifacts"][10]["digest"]="sha256:"+"0"*64
            relabel=C.official(catalog["spec"],original["run"],original["jobs"],original["artifacts"])|{"official":original}
            with self.assertRaisesRegex(ValueError,"disagrees with final"):stream.assemble(relabel,d,d/"merged.json")
    def test_forged_independent_original_acquisition(self):
        with tempfile.TemporaryDirectory(dir="/dev/shm") as t:
            d=Path(t);catalog=self.fixture(d);target=d/"c1-10.json";raw=C.get(target)
            raw["position"]["result"]["host"]["boot"]="bad";target.write_bytes(C.canonical(raw))
            with self.assertRaisesRegex(ValueError,"disagrees with final"):stream.assemble(catalog,d,d/"merged.json")
    def test_wrong_cohort_job_and_partial_official_run(self):
        with tempfile.TemporaryDirectory(dir="/dev/shm") as t:
            d=Path(t);catalog=self.fixture(d);one=copy.deepcopy(catalog);one["official"]["jobs"]["jobs"][0]["name"]="c2"
            with self.assertRaisesRegex(ValueError,"official job"):C.check_catalog(one)
            two=copy.deepcopy(catalog);two["official"]["run"]["status"]="in_progress"
            with self.assertRaisesRegex(ValueError,"still active"):C.check_catalog(two)
if __name__=="__main__":unittest.main(verbosity=2)
