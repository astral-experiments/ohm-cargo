"""Authenticate immutable Actions metadata, then SHA-check a single bounded original ZIP in memory."""
import contextlib, hashlib, json, os, re, shutil, sys, uuid, zipfile
from pathlib import Path, PurePosixPath

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"original"))
import acquire_pilot as github
from replay_metrics import need, sha
REG=json.loads((HERE/"registration.json").read_bytes())
REPO="astral-experiments/ohm"
POSITIONS=tuple(f"{i:02}" for i in range(1,13))
COHORTS=("c1","c2")
REQUIRED_STEPS=("Read the binding to the independently completed native source run",
                "Verify the two original screen archives",
                "Prepare a bounded task-owned target and build filesystem",
                "Open qualified source SDKs and measure both same-SDK switches")
MAX_ARCHIVE=512 << 20

def canonical(d):
    return (json.dumps(d,sort_keys=True,separators=(",",":"),ensure_ascii=True)+"\n").encode()
def get(path):
    return json.loads(Path(path).read_bytes())
def seal(path,value):
    data=canonical(value); path=Path(path)
    if path.exists():
        need(path.read_bytes()==data, f"previous receipt differs: {path}")
        return
    tmp=path.with_name("."+path.name+"."+str(os.getpid())+".part")
    with tmp.open("xb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    try:
        os.link(tmp,path)
    finally:
        tmp.unlink()
def order(cohort,p):
    need(cohort in COHORTS and p in POSITIONS,"unknown cohort/position")
    return list(("Koff","Kon") if (int(p)%2==1)==(cohort=="c1") else ("Kon","Koff"))
def positive_int(x): return type(x) is int and x>0
def valid_boot(b):
    try: return type(b) is str and str(uuid.UUID(b))==b and uuid.UUID(b).version==4
    except (ValueError,TypeError): return False

def spec(cohort,run,head,branch,plan):
    if cohort=="pilot":
        raise ValueError("exploratory pilot is excluded")
    need(cohort in COHORTS and positive_int(run) and run not in REG["excluded_runs"]
         and run!=REG["pilot_run"] and re.fullmatch("[0-9a-f]{40}",head)
         and branch==REG["branch"] and plan==REG["plan"],"unregistered source/run or exploratory pilot")
    return dict(cohort=cohort,run=run,head=head,branch=branch,plan=plan,pilot_run=REG["pilot_run"],
                orders={p:order(cohort,p) for p in POSITIONS})

def official(s,run,jobs,arts):
    c,r,h=s["cohort"],s["run"],s["head"]
    need((run["id"],run["head_sha"],run["head_branch"],run["run_attempt"],run["event"],run["path"],
          run["repository"]["full_name"],run["head_repository"]["full_name"],run["display_title"])==
         (r,h,s["branch"],1,"workflow_dispatch",".github/workflows/ci.yml",REPO,REPO,
          f"Packed Ruff confirmation {c} {h}"),"wrong official run/ref/cohort/attempt")
    need(run["status"]=="completed","run is still active; no confirmation acquisition")
    need(jobs["total_count"]==len(jobs["jobs"]) and arts["total_count"]==len(arts["artifacts"]),"paginated/incomplete API")
    jid={j["name"]:j for j in jobs["jobs"]}; aid={a["name"]:a for a in arts["artifacts"]}
    name=lambda p:f"Packed Ruff confirmation {c}-{p}"
    aname=lambda p:f"packed-ordinary-confirm-{c}-{p}"
    need(len(jid)==len(jobs["jobs"]) and set(jid)=={name(p) for p in POSITIONS},"unexpected, missing or duplicated official job")
    need(len(aid)==len(arts["artifacts"]) and set(aid)<={aname(p) for p in POSITIONS},"unexpected/duplicate official archive")
    result={}
    for p in POSITIONS:
        j=jid[name(p)]; a=aid.get(aname(p))
        need(j["run_id"]==r and j["head_sha"]==h and j["status"]=="completed"
             and positive_int(j["id"]),"unbound job")
        base=dict(job=j["id"],job_name=name(p),job_conclusion=j["conclusion"],
                  job_started=j["started_at"],job_completed=j["completed_at"],position=p)
        steps={v["name"]:v["conclusion"] for v in j["steps"]}
        base["steps"]={n:steps.get(n) for n in REQUIRED_STEPS}
        if a:
            need(not a["expired"] and a["workflow_run"]["id"]==r and a["workflow_run"]["head_sha"]==h
                 and positive_int(a["id"]) and type(a["size_in_bytes"]) is int
                 and 0<a["size_in_bytes"]<=MAX_ARCHIVE and re.fullmatch("sha256:[a-f0-9]{64}",a["digest"]),
                 "unbound or expired/wrong-sized original archive")
            base.update(id=a["id"],artifact_name=aname(p),size_in_bytes=a["size_in_bytes"],
                        sha256=a["digest"][7:],filename=f"{r}-{p}-{a['id']}.zip")
        if j["conclusion"]=="success":
            need(a and all(v=="success" for v in base["steps"].values()),"successful worker lacks native gates or original")
        result[p]=base
    for k in ("job","id","sha256"):
        ids=[v[k] for v in result.values() if k in v]
        need(len(ids)==len(set(ids)),f"duplicate official {k}")
    return {"spec":s,"run_conclusion":run["conclusion"],"positions":result}

def fetch_catalog(s):
    r=s["run"]
    run=github.api(f"runs/{r}")
    need(run["status"]=="completed","run is still active; no confirmation acquisition")
    jobs=github.api(f"runs/{r}/attempts/1/jobs?per_page=100")
    arts=github.api(f"runs/{r}/artifacts?per_page=100")
    return official(s,run,jobs,arts)|{"official":{"run":run,"jobs":jobs,"artifacts":arts}}

def check_catalog(c):
    want=spec(**{k:c["spec"][k] for k in ("cohort","run","head","branch","plan")})
    raw=c["official"]; projected=official(want,raw["run"],raw["jobs"],raw["artifacts"])
    need(projected=={k:c[k] for k in projected},"recomputed original catalog differs")
    return projected

def headroom(n):
    mem=Path("/proc/meminfo").read_text()
    available=int(re.search(r"^MemAvailable:\s+(\d+) kB",mem,re.M)[1])*1024
    need(available>n+(2<<30),"less than 2 GiB remaining after original ZIP")
    need(shutil.disk_usage("/dev/shm").free>512<<20,"RAM temporary filesystem guard")

@contextlib.contextmanager
def archive(w,local=None):
    n=w["size_in_bytes"]; need(0<n<=MAX_ARCHIVE,"original ZIP size limit"); headroom(n)
    if local is None:
        with os.fdopen(os.memfd_create("packed-ordinary-original"),"w+b") as f:
            github.fetch(w,f)
            need(f.tell()==n,"incomplete original ZIP")
            yield from opened(f,w)
    else:
        path=Path(local)/w["filename"]
        need(path.is_file() and not path.is_symlink() and path.stat().st_size==n,"missing or truncated local original ZIP")
        with path.open("rb") as f: yield from opened(f,w)

def opened(f,w):
    f.seek(0); need(hashlib.file_digest(f,"sha256").hexdigest()==w["sha256"],"official ZIP byte digest")
    f.seek(0)
    with zipfile.ZipFile(f) as z:
        info=z.infolist()
        need(len(info)<40000 and sum(i.file_size for i in info) < (2<<30)
             and max(i.file_size for i in info) < (256<<20),"unbounded ZIP logical extent")
        names=[i.filename for i in info]
        need(len(names)==len(set(names)) and all(not PurePosixPath(n).is_absolute() and
             ".." not in PurePosixPath(n).parts for n in names) and z.testzip() is None,"original ZIP member/CRC failure")
        yield z
