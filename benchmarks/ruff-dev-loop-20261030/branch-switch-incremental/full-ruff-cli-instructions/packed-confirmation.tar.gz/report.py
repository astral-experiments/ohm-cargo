"""Write review tables after both registered originals and the frozen inference are terminal."""
import argparse
import csv
from fractions import Fraction
import json
from pathlib import Path
from statistics import median
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import confirm
import custody as C
from statistics_exact import VISITS


def review(inputs, decision, out):
    summaries = []
    for v in inputs:
        s=v['receipt']['spec']
        C.need(s == confirm.pinned(s['cohort'],s['run'],s['head'],s['branch']), 'wrong official run and order')
    C.need(confirm.summarize(*inputs) == decision, 'terminal decision and original observations disagree')
    hdr = ('cohort','position','boot','job','artifact','order','arm','phase','exit','instructions',
           'user_us','system_us','start_ns','stop_ns','enabled_ns','running_ns','event_errno',
           'allocated_bytes','outside_allocated_bytes','dirty_typed_units','storage_backend')
    lines=[]
    for wrapper in inputs:
        r=wrapper['receipt']; c=r['spec']['cohort']
        for p,v in r['positions'].items():
            if 'host' not in v: continue
            h=v['host'];j=v['original']
            for a in h['order']:
                for phase in VISITS:
                    row=h['arms'][a][phase]; cl=row['raw_clock']
                    lines.append((c,p,h['boot'],j['job'],j['id'],'/'.join(h['order']),a,phase,row['cargo_exit'],
                                row['instructions'],cl['user_us'],cl['system_us'],cl['start'],cl['stop'],cl['enabled'],
                                cl['running'],cl['event_errno'],row['allocated'],row['unmetered_allocated'],
                                'n/a' if row['dirty'] is None else row['dirty'],h['storage_mode']))
    with (out/'all-phases.tsv').open('x',newline='') as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(hdr);w.writerows(lines)
    summaries.append('# Whole-Cargo instructions for branch returns in the GNU Ruff CLI\n')
    if decision['withheld']:
        summaries.append('The registered 24-boot confirmation was withheld. The individual raw counts are not a substitute for it.\n')
        for c,v in decision['cohorts'].items():summaries.append(c+' '+str(v['admission_errors'])+'\n')
    else:
        summaries.append('Koff and Kon used the same packed compiler, strict Cargo, Wild, locked archive set, and canonical paths. Each boot contributes the ratio of the two summed whole-Cargo return counts. The two 12-boot confirmations were independently registered before the first result. Their two screen boots and every prior refused stage are excluded.\n')
        summaries.append('| Cohort | Median return ratio | Exact rank 3–10 interval | Individual observed range | Off-first / on-first medians |\n|---|---:|---:|---:|---:|')
        fmt=lambda a:f'{float(Fraction(*a)):.5f}'
        for c,entry in decision['cohorts'].items():
            s=entry['score'];p=s['primary'];order=s['order_strata_descriptive']
            summaries.append(f"| {c} | {fmt(p['median'])}× | {fmt(p['interval'][0])}–{fmt(p['interval'][1])}× | {fmt(p['min'])}–{fmt(p['max'])}× | {fmt(order['Koff']['median'])}× / {fmt(order['Kon']['median'])}× |")
        summaries.append('\nEach interval has 1969/2048 marginal coverage. Both lower bounds must strictly exceed two. The original score records exact fractions, absolute counts for each phase, and the identity of each bound.\n')
        summaries.append('| Individually paired median (off/on) | c1 | c2 |\n|---|---:|---:|')
        keys=[('Cold A','cold-A'),('First B','first-B'),('Return A','return-A'),('Return B','return-B'),
              ('Immediate unchanged B','unchanged-B'),('Invalid B, Cargo 101','invalid'),('Repair B','repair'),
              ('First B plus first return A','first_B_plus_return_A'),('Cold A through second return B','empty_A_through_return_B'),
              ('All five successful visits','five_successful_through_unchanged'),
              ('All seven visits including rejection and repair','all_seven_including_failure_repair')]
        for label,k in keys:
            values=[fmt(decision['cohorts'][c]['score']['metrics'][k]['median'])+'×' for c in ('c1','c2')]
            summaries.append('| '+' | '.join([label,*values])+' |')
        summaries.append('\n| Descriptive per-boot costs | c1 median | c2 median |\n|---|---:|---:|')
        def modes(c):
            s=decision['cohorts'][c]['score'];return list(s['paired_position'].values())
        for label,fn,unit,places in [
                    ('Extra instructions through first B',lambda v:v['model']['extra_through_first_B']/1e9,' billion',2),
                    ('Instructions saved per return A+B',lambda v:v['model']['saved_per_return_pair']/1e9,' billion',2),
                    ('Return pairs to repay the initial overhead (model)',lambda v:v['model']['pairs_to_repay'],'',1),
                    ('Maximum sampled allocation with cache off',lambda v:v['peak_observed_visit_end_bytes']['off']/2**30,' GiB',3),
                    ('Maximum sampled allocation with cache on',lambda v:v['peak_observed_visit_end_bytes']['on']/2**30,' GiB',3),
                    ('Paired peak allocation difference',lambda v:(v['peak_observed_visit_end_bytes']['on']-v['peak_observed_visit_end_bytes']['off'])/2**30,' GiB',3)]:
            v=[list(map(fn,modes(c))) for c in ('c1','c2')]
            summaries.append('| '+ ' | '.join([label,*(f'{median(x):,.{places}f}{unit}' if all(i is not None for i in x) else 'unbounded for some boots' for x in v)])+' |')
        backends=sorted(set(row[-1] for row in lines))
        summaries.append('\nThe allocation ledger deduplicates hardlinked inodes in both complete roots. Its maximum is sampled at visit ends. Storage modes observed were '+', '.join(backends)+'. Raw start/stop, CPU, enabled/running, errno, retained byte counts and Cargo exits for all 336 hardware observations are in all-phases.tsv. The disabled-at-start inherited hardware event counts the normal Cargo process tree in user mode. Stock native provider failures and recovery were checked separately. These measured Cargo commands do not carry the distinct historical physical linker census.\n')
    (out/'RESULTS.md').open('x').write('\n'.join(summaries)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('results',type=Path);p.add_argument('out',type=Path)
    a=p.parse_args();review([C.get(a.results/(c+'-raw.json')) for c in ('c1','c2')],C.get(a.results/'decision.json'),a.out)
