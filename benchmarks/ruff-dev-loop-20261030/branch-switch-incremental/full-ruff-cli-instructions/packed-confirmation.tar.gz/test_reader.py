"""Result-blind adversarial guards. All toy counts are synthetic."""
from copy import deepcopy
from fractions import Fraction
from io import BytesIO
import json, sys, unittest, uuid, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import custody as C
from scoring import VISITS, cohort_stats, summarize
HEAD="1d446332e82ca0188f63c3fddc9689f1f131fd42"

def core(c):
    group=1 if c=="c1" else 2
    ident=lambda p:group*10000+int(p)
    spec=C.spec(c,9000+group,HEAD,C.REG["branch"],C.REG["plan"])
    host={}
    for p in C.POSITIONS:
        seq=0; arms={}
        for arm in spec["orders"][p]:
            phases=arms[arm]={}
            for visit in VISITS:
                seq+=2; n=600 if arm=="Koff" and "return-" in visit else 100
                code=101 if visit=="invalid" else 0
                phases[visit]={"instructions":n,"allocated":4096,"unmetered_allocated":4096,"cargo_exit":code,
                               "raw_clock":{"code":code,"event_errno":0,"instructions":n,"enabled":1000,"running":995,
                                            "user_us":5,"system_us":5,"start":seq,"stop":seq+1}}
        u=str(uuid.UUID(int=ident(p),version=4))
        host[p]={"host":{"arms":arms,"order":spec["orders"][p],"boot":u,"cpu":{"model":"Synthetic"},"pmu":"synthetic"},
                 "original":{"job":ident(p),"id":ident(p)+50000,"sha256":C.sha(str(ident(p)).encode()),
                             "position":p,"job_conclusion":"success","steps":dict.fromkeys(C.REQUIRED_STEPS,"success")}}
    return {"spec":spec,"positions":host,"run_conclusion":"success","catalog_sha256":"a"*64}
def seal(d):return {"receipt":d,"sha256":C.sha(C.canonical(d))}
def calc(a,b):return summarize(seal(a),seal(b))
def nset(h,arm,phase,n):
    row=h["arms"][arm][phase];row["instructions"]=row["raw_clock"]["instructions"]=n
def sample(rows,p,n):
    h=rows["positions"][p]["host"]
    for ph in ("return-A","return-B"): nset(h,"Koff",ph,n)
class ScoreTests(unittest.TestCase):
    def setUp(self):self.a,self.b=core("c1"),core("c2")
    def test_full_independent(self):
        result=calc(self.a,self.b);self.assertTrue(result["replicated_above_2"])
        for x in result["cohorts"].values():
            primary=x["score"]["primary"]
            self.assertEqual(primary["median"],[6,1]);self.assertEqual(primary["marginal_median_coverage"],[1969,2048])
            self.assertEqual(primary["interval"],[[6,1],[6,1]])
    def test_direction_cannot_replace_sum(self):
        # 1000/10 and 400/900; mean of separate directions is >50, genuine sum is 140/91 (<2).
        for row in self.b["positions"].values():
            h=row["host"]
            for a,pa,pb in [("Koff",1000,400),("Kon",10,900)]:
                nset(h,a,"return-A",pa);nset(h,a,"return-B",pb)
        got=calc(self.a,self.b)
        self.assertFalse(got["replicated_above_2"]);self.assertEqual(got["cohorts"]["c2"]["score"]["primary"]["median"],[20,13])
    def test_two_adverse_hosts_dont_fail_rank3_but_three_do(self):
        for p in ("01","02"):sample(self.b,p,199)
        self.assertTrue(calc(self.a,self.b)["replicated_above_2"])
        sample(self.b,"03",200)
        x=calc(self.a,self.b);self.assertFalse(x["replicated_above_2"])
        self.assertEqual(x["cohorts"]["c2"]["score"]["primary"]["interval"][0],[2,1])
        sample(self.b,"03",201);self.assertTrue(calc(self.a,self.b)["replicated_above_2"])
    def test_rank10(self):
        for i,p in enumerate(C.POSITIONS):sample(self.a,p,100*(1+i))
        p=calc(self.a,self.b)["cohorts"]["c1"]["score"]["primary"]
        self.assertEqual(p["interval"],[[3,1],[10,1]]);self.assertEqual(p["median"],[13,2])
    def test_wrong_arm_order(self):
        self.a["positions"]["01"]["host"]["order"].reverse();self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_chronological_reversal(self):
        self.a["positions"]["01"]["host"]["arms"]["Kon"]["cold-A"]["raw_clock"]["start"]=1
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_too_multiplexed(self):
        self.a["positions"]["01"]["host"]["arms"]["Kon"]["cold-A"]["raw_clock"]["running"]=994
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_invalid_cargo_succeeded(self):
        self.a["positions"]["07"]["host"]["arms"]["Kon"]["invalid"]["raw_clock"]["code"]=0
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_missing_last_boot(self):
        del self.b["positions"]["12"];self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_do_not_impute_failed_host(self):
        self.a["positions"]["08"].update(error="PMU refused");self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_refused_official_job(self):
        self.a["positions"]["06"]["original"]["job_conclusion"]="failure"
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_excluded_pilot_boot(self):
        self.b["positions"]["01"]["host"]["boot"]=C.REG["excluded_boots"][0]
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_pilot_artifact_cannot_enter(self):
        self.a["positions"]["03"]["original"]["id"]=C.REG["excluded_artifacts"]["01"]["id"]
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_alias_across_cohorts(self):
        self.b["positions"]["11"]["host"]["boot"]=self.a["positions"]["02"]["host"]["boot"]
        self.assertIsNone(calc(self.a,self.b)["replicated_above_2"])
    def test_duplicate_job_artifact_digest(self):
        for marker in ("job","id","sha256"):
            with self.subTest(marker=marker):
                b=deepcopy(self.b); b["positions"]["11"]["original"][marker]=self.a["positions"]["02"]["original"][marker]
                self.assertIsNone(calc(self.a,b)["replicated_above_2"])
    def test_exclude_pilot_run(self):
        self.b["spec"]["run"]=C.REG["pilot_run"]
        with self.assertRaisesRegex(ValueError,"reused run or pilot"):calc(self.a,self.b)
    def test_cannot_label_c1_as_its_own_replication(self):
        with self.assertRaises(ValueError):calc(self.a,self.a)
    def test_hash(self):
        b=seal(self.b); sample(self.b,"01",9999)
        with self.assertRaisesRegex(ValueError,"modified"):summarize(seal(self.a),b)
    def test_corrupt_archive_digest(self):
        f=BytesIO()
        with zipfile.ZipFile(f,"w") as z:z.writestr("complete.json","{}")
        with self.assertRaisesRegex(ValueError,"ZIP byte digest"):list(C.opened(f,{"sha256":"0"*64}))
    def test_unsafe_archive_member(self):
        f=BytesIO()
        with zipfile.ZipFile(f,"w") as z:z.writestr("../escape","")
        with self.assertRaisesRegex(ValueError,"member/CRC"):list(C.opened(f,{"sha256":C.sha(f.getvalue())}))
if __name__=="__main__":unittest.main(verbosity=2)
