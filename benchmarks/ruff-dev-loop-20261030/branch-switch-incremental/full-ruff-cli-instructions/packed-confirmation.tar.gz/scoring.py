"""Statistical decision from admitted native positions, without floats in any threshold."""
from fractions import Fraction
from math import comb
from statistics import median
from custody import COHORTS, POSITIONS, REG, canonical, need, order, positive_int, sha, valid_boot
from statistics_exact import VISITS, RETURNS, exact, counts, physical_order, position

def distribution(values):
    a=sorted(map(Fraction,values))
    return {"min":exact(a[0]),"median":exact(median(a)),"max":exact(a[-1])}

def cohort_stats(rows):
    need(set(rows)==set(POSITIONS),"only complete cohorts may be scored")
    detailed={}
    for p,host in rows.items():
        arms=host["arms"]
        entry=position(arms,"K")
        for key,phases in {"five_successful_through_unchanged":VISITS[:5],"all_seven_including_failure_repair":VISITS}.items():
            entry["ratios"][key]=exact(Fraction(*(sum(arms[k][v]["instructions"] for v in phases)
                                                  for k in ("Koff","Kon"))))
        detailed[p]=entry
    metrics={k:distribution(Fraction(*e["ratios"][k]) for e in detailed.values())
             for k in next(iter(detailed.values()))["ratios"]}
    ordered=sorted(((Fraction(*e["ratios"]["round_trip"]),p) for p,e in detailed.items()))
    lower,upper=ordered[2][0],ordered[9][0]
    coverage=1-Fraction(2*sum(comb(12,i) for i in range(3)),2**12)
    primary=metrics["round_trip"] | {"interval":[exact(lower),exact(upper)],"ranks":[3,10],
              "lower_position":ordered[2][1],"upper_position":ordered[9][1],
              "pass_lower_strictly_above_2":lower>2,"marginal_median_coverage":exact(coverage)}
    byorder={a:distribution(Fraction(*detailed[p]["ratios"]["round_trip"]) for p in POSITIONS if rows[p]["order"][0]==a)
             for a in ("Koff","Kon")}
    phase={}
    for v in VISITS:
        fields={}
        for field in ("instructions","allocated","unmetered_allocated"):
            fields[field]={mode:distribution(r["arms"][mode][v][field] for r in rows.values()) for mode in ("Koff","Kon")}
            fields[field]["on_minus_off"]=distribution(r["arms"]["Kon"][v][field]-r["arms"]["Koff"][v][field] for r in rows.values())
        phase[v]=fields
    return {"primary":primary,"paired_position":detailed,"metrics":metrics,"order_strata_descriptive":byorder,
            "absolute_counts_and_costs":phase,"sampled_peak_by_arm":{
                a:distribution(detailed[p]["peak_observed_visit_end_bytes"][a] for p in POSITIONS) for a in ("off","on")}}

def identity_errors(raw,shared):
    errors=[]
    s=raw["spec"]
    c=s["cohort"]
    rows=raw["positions"]
    if set(rows)!=set(POSITIONS): errors.append("incomplete position inventory")
    if raw["run_conclusion"]!="success": errors.append("official run "+str(raw["run_conclusion"]))
    for p in POSITIONS:
        if p not in rows: continue
        r=rows[p]
        try:
            j=r["original"]
            need(j["position"]==p and j["job_conclusion"]=="success" and
                 all(x=="success" for x in j["steps"].values()),"failed native job or migration")
            for k in ("job","id","sha256"):
                val=j[k]; need((positive_int(val) if k!="sha256" else isinstance(val,str) and len(val)==64),"invalid artifact/job")
                need(val not in shared[k],f"reused {k} or exploratory pilot"); shared[k].add(val)
            need("error" not in r,r.get("error","missing original worker"))
            h=r["host"]; b=h["boot"]
            need(valid_boot(b) and b not in shared["boots"],"reused/invalid worker boot or pilot")
            shared["boots"].add(b)
            need(h["order"]==s["orders"][p]==order(c,p) and set(h["arms"])=={"Koff","Kon"},"registered role order")
            counts(h["arms"]); physical_order(h["order"],h["arms"])
            cpu=canonical(h["cpu"]); pmu=canonical(h["pmu"])
            shared["cpus"].add(cpu);shared["pmus"].add(pmu)
            for arm,vis in h["arms"].items():
                for phase, obs in vis.items():
                    cl=obs["raw_clock"]
                    need(obs["unmetered_allocated"]>=0 and obs["cargo_exit"]==cl["code"] and
                         all(type(cl[k]) is int for k in ("start","stop","user_us","system_us")) and
                         cl["user_us"]+cl["system_us"]>0,"original clock/accounting")
        except (ValueError,AssertionError, KeyError,TypeError) as e:
            errors.append(p+" "+str(e))
    return errors

def check_raw(supplied):
    raw=supplied["receipt"]
    need(supplied["sha256"]==sha(canonical(raw)),"modified or incomplete reopened-position receipt")
    return raw

def summarize(first,second):
    raw=[check_raw(first),check_raw(second)]
    need(tuple(v["spec"]["cohort"] for v in raw)==COHORTS,"c1 and c2 required in that order")
    pinned=raw[0]["spec"]
    need(all(v["spec"][field]==pinned[field] for v in raw for field in ("head","branch","plan","pilot_run")),
         "different head, branch or registration between cohorts")
    runs=[r["spec"]["run"] for r in raw]; need(len(set(runs))==2 and not set(runs)&set(REG["excluded_runs"]),"reused run or pilot")
    pilot=REG["excluded_artifacts"].values()
    shared={"boots":set(REG["excluded_boots"]),"cpus":set(),"pmus":set(),
            **{k:{a[k] for a in pilot} for k in ("id","job","sha256")}}
    results={}; pre={}
    for r in raw:
        c=r["spec"]["cohort"]; e=identity_errors(r,shared)
        pre[c]=e
        results[c]={"run":r["spec"]["run"],"original_catalog_sha256":r["catalog_sha256"],
                    "reopened_receipt_sha256":sha(canonical(r)),"admission_errors":e}
    need(len(shared["cpus"])<=1 and len(shared["pmus"])<=1,"different CPU/PMU across hardware cohorts")
    # No pooled substitution. A position reused by the second cohort withholds replication.
    for r in raw:
        c=r["spec"]["cohort"]
        if not pre[c]:
            results[c]["score"]=cohort_stats({p:x["host"] for p,x in r["positions"].items()})
    passed=None if any(pre.values()) else all(results[c]["score"]["primary"]["pass_lower_strictly_above_2"] for c in COHORTS)
    return {"kind":"packed binary, off/on, retired user-mode instructions, 2 independently registered cohorts",
            "cohorts":results,"replicated_above_2":passed,"withheld":any(pre.values()),
            "git_head":pinned["head"],"plan":pinned["plan"],"pilot_excluded":REG["pilot_run"],
            "interpretation":"Each boot is one paired return sum. Invalid and repair retained. Disk totals are sampled, hardlink-deduplicated visit ends. CPU/time and secondary endpoints are descriptive."}
