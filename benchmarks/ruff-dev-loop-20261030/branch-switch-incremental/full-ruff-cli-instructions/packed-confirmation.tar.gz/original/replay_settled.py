"""Reopen the precise settled GNU Ruff native link qualified by the unscored control."""
import gzip
import json
from pathlib import PurePosixPath as P
import stat

from replay_fingerprint import MARK, decode, rustc_rules
from replay_metrics import need, sha
from replay_native import read
from replay_ruff_link import chain

DIGEST = '6e9c1d753b9bd2dcb90ad100096447903867e42d961d1ea56fa21a32429986a2'
COMPLETE = 'a5952bbf7b41190543ed0ecbe7195fb5b2bf2bf971ea45f521617c3cba36c109'
SEP = ('cold-A','return-B','unchanged-B')


def binding(z):
    q=json.loads(z.read('native-recheck-qualification.json'))
    expected={'run':41203835321,'attempt':1,'job':124544792579,'head':'d8b51eace7817c784a7bd0a220b745777c1891fd',
              'artifact':{'id':13042799674,'size':81914908,'sha256':DIGEST},'complete_sha256':COMPLETE,
              'independent':'f2860d5156edc217f4011b230d36e9e043fd03147798c53fb10f24d881dfef55'}
    need(q['binding']==expected,'wrong full Ruff native qualification')
    terminal=(json.dumps(q['complete'],sort_keys=True,separators=(',',':'))+'\n').encode()
    need(sha(terminal)==COMPLETE,'wrong calibrated native verdict')
    return expected


def verify(z, slot, root, roster, identified, returned):
    cold=read(z,slot+'/cold-A','native-execs.json.gz')
    settled=read(z,slot+'/unchanged-B','native-execs.json.gz')
    g=chain(cold,settled)
    need(identified['rustcs']==['ruff'] and identified['wild']==1 and not settled['other_linkers'],
         'unexpected settled native work')
    dirty,=roster['dirty']
    need(dirty['name']=='ruff' and dirty['crate_types']==dirty['kind']==['bin'] and not dirty['profile']['test']
         and dirty['id']=='path+file:///__public_ruff_source__/crates/ruff#0.16.7','wrong settled Cargo unit')
    prior=None
    records=[]
    for phase in SEP:
        prefix=slot+'/'+phase
        info=read(z,prefix,'settled-origin.json')
        leaf=info['cold']['zmij']
        need(leaf['rlib']==g['archive'] and leaf['rmeta']==g['zmij'] and
             info['cold']['ruff']['out']==g['ruff'] and
             [info['cold'][k]['pid'] for k in ('ruff','serde_json','zmij')]==g['full_pids'] and
             P(leaf['source']).parts[-3:]==('zmij-1.0.10','src','lib.rs'),'wrong original cold chain')
        data=z.read(prefix+'/dep-lib-zmij')
        need(decode(data)=={'version':2,'files':1,'link_index':0} and
             sha(data)=='ffc9e632155e2eaade4194d1277961ca1ee852e72c481d7b9e11792d634daae8','wrong native record')
        deps=z.read(prefix+'/zmij.d')
        rules=rustc_rules(deps,leaf['depfile'])
        need(MARK+b':' in deps.splitlines() and set(rules)=={g['archive'],g['zmij']} and
             leaf['source'].encode() in deps and
             str(P(leaf['source']).with_name('traits.rs')).encode() in deps,'wrong raw source rules')
        bound=info['emitter']['files']
        for k,path in (('rlib',g['archive']),('rmeta',g['zmij']),('encoded',g['marker']),('depfile',leaf['depfile'])):
            need(bound[k]['path']==path,'foreign producer')
        need(bound['encoded']['sha256']==sha(data) and bound['depfile']['sha256']==sha(deps),'missing authentic original')
        ledger=read(z,prefix,'path-inodes.json.gz')
        def allocated(rec):
            key=str(P(rec['path']).relative_to(root))
            want=rec['identity']
            actual=ledger[key]
            need(stat.S_ISREG(actual[3]) and [actual[0],actual[1],stat.S_IMODE(actual[3]),actual[5]]==want[:4],
                 ('identity differs from observed allocation',key))
        for k in ('rlib','rmeta','encoded','depfile'):
            allocated(bound[k])
        if prior is None:
            prior=info
        else:
            need(prior['cold']==info['cold'] and prior['emitter']==info['emitter'],'settled origin moved')
            allocated(info['recipe'])
            need(info['recipe']['path']==g['recipe'],'foreign recipe')
        records.append(info)
    end=records[-1]
    recipe=gzip.decompress(z.read(slot+'/return-B/settled-ruff.rlink.gz'))
    need(recipe.startswith(b'rustlink\0\0\0\1') and len(recipe)==end['recipe']['identity'][3] and
         sha(recipe)==end['recipe']['sha256'] and end['recipe']==records[1]['recipe'],'saved recipe mismatch')
    need(end['link']=={'rustc':g['settled_rustc'],'wild':g['wild'],'recipe':g['recipe'],'output':g['output'],
                       'linked_zmij':g['archive']},'kernel vs physical output')
    need(P(end['cold']['ruff']['executable'])==root/'target/debug/ruff' and
         end['output_identity']==end['returned_identity'],'different returned binary inode')
    for p in (str(root/'target/debug/ruff'),g['output']):
        allocated({'path':p,'identity':end['output_identity']})
    raw=read(z,slot+'/unchanged-B','native.json.gz')
    need(raw['cli']['whole']==returned and end['output_identity'][3]==raw['cli']['size'],'wrong final binary')
    before=read(z,slot+'/return-B','watched-git-files.json')
    need(before==read(z,slot+'/unchanged-B','watched-git-files.json')==
         read(z,slot+'/unchanged-B','watched-git-files-after.json'),'Ruff refs changed during settled link')
    return {'dirty':'ruff [bin]','rustc':g['settled_rustc'],'wild':g['wild'],'native_marker':sha(data),
            'recipe':sha(recipe),'output':returned,'zmij':g['archive']}
