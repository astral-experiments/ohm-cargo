"""Bind the real Ruff binary to its compiled Rust dependencies and the linker input it uses."""
from pathlib import PurePosixPath as P


def option(argv, name):
    value, = [right for left,right in zip(argv,argv[1:]) if left == name]
    return value


def crate(compilers, name, kind):
    match, = [c for c in compilers if c['crate'] == name and
              option(c['argv'], '--crate-type') == kind and c['mode'] == 'full']
    assert option(match['argv'], '--crate-name') == name
    return match


def extern(argv, key, extension):
    dependency, = [P(a.split('=',1)[1]) for prev,a in zip(argv,argv[1:]) if prev == '--extern' and
                   a.startswith(key+'=') and a.endswith(extension)]
    assert dependency.is_absolute() and '..' not in dependency.parts
    return dependency


def chain(cold, settled):
    root = crate(cold['rustcs'], 'ruff','bin')
    json = crate(cold['rustcs'], 'serde_json','lib')
    zmij = crate(cold['rustcs'], 'zmij','lib')
    exe, = settled['rustcs']
    linker, = settled['wild_processes']
    assert settled['wild'] == 1 and exe['crate'] == 'ruff' and exe['mode'] == 'link-only'
    assert option(exe['argv'],'--crate-type') == 'bin' and ('-Z','link-only') in zip(exe['argv'],exe['argv'][1:])
    out = P(option(root['argv'],'--out-dir'))
    target = out/'ruff'
    recipe = out/'ruff.rlink'
    assert out.is_absolute() and P(option(exe['argv'],'--out-dir')) == out
    assert str(recipe) in exe['argv'] and option(linker['argv'],'-o') == linker['output'] == str(target)
    j = extern(root['argv'],'serde_json','.rlib')
    z = extern(json['argv'],'zmij','.rmeta')
    assert j.parent == P(option(json['argv'],'--out-dir')) and z.parent == P(option(zmij['argv'],'--out-dir'))
    assert source_archive(json, 'serde_json','.rlib') == j and source_archive(zmij, 'zmij','.rmeta') == z
    archive = str(z.with_suffix('.rlib'))
    assert linker['argv'].count(archive) == 1
    return {'ruff':str(out),'serde_json':str(j),'zmij':str(z),'archive':archive,
            'marker':str(z.parent.parent/'fingerprint/dep-lib-zmij'), 'recipe':str(recipe),
            'output':str(target),'full_pids':[r['pid'] for r in (root,json,zmij)],
            'settled_rustc':exe['pid'],'wild':linker['pid']}


def source_archive(rustc, name, ext):
    out = P(option(rustc['argv'],'--out-dir'))
    assert out.name == 'out' and out.parent.parent.name == name
    return out/('lib'+name+'-'+out.parent.name+ext)
