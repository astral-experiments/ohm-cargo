"""Reopen the two original ordinary-command archives and independently score the preregistered screen."""
import contextlib
import hashlib
import json
import os
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import acquire_pilot as github
import independent_reader as original
from replay_metrics import COMMAND, REVS, VISITS, need, ratio, sha
from replay_native import raw, read, native_verdict

RUN = 41217046302
HEAD = "ae9ed53266a0106f19571e692a05fb65d28f06b2"
BRANCH = "charlie/qa-packed-ordinary-efficacy-20261031"
PLAN = "52075870a19ae3b0944c2b7341d6d0c8737127465a21eb85aff305dd55c50aae"
ORDER = {"01": ["Koff", "Kon"], "02": ["Kon", "Koff"]}


def catalog():
    run = github.api(f"runs/{RUN}")
    need((run["id"], run["head_branch"], run["head_sha"], run["run_attempt"], run["event"],
          run["path"], run["repository"]["full_name"]) ==
         (RUN, BRANCH, HEAD, 1, "workflow_dispatch", ".github/workflows/ci.yml", "astral-experiments/ohm"),
         "wrong official run")
    need((run["status"], run["conclusion"]) == ("completed", "success"), "both workers must finish")
    jobs = github.api(f"runs/{RUN}/attempts/1/jobs?per_page=100")
    artifacts = github.api(f"runs/{RUN}/artifacts?per_page=100")
    need(jobs["total_count"] == len(jobs["jobs"]) == artifacts["total_count"] == len(artifacts["artifacts"]) == 2,
         "wrong number of positions or archives")
    result = {}
    for pos in ORDER:
        job, = [j for j in jobs["jobs"] if j["name"] == "Ordinary packed Ruff CLI " + pos]
        art, = [a for a in artifacts["artifacts"] if a["name"] == "packed-ordinary-efficacy-" + pos]
        need(job["run_id"] == RUN and job["head_sha"] == HEAD and job["conclusion"] == "success"
             and any(x["name"] == "Open qualified source SDKs and measure both same-SDK switches"
                     and x["conclusion"] == "success" for x in job["steps"]), "official benchmark job")
        need(not art["expired"] and art["workflow_run"]["id"] == RUN and art["workflow_run"]["head_sha"] == HEAD
             and re.fullmatch(r"sha256:[0-9a-f]{64}", art["digest"]) and 0 < art["size_in_bytes"] <= 2 << 30,
             "official ZIP identity")
        result[pos] = dict(id=art["id"], job=job["id"], size_in_bytes=art["size_in_bytes"], sha256=art["digest"][7:])
    return result


@contextlib.contextmanager
def archive(row):
    with os.fdopen(os.memfd_create("ohm-ordinary-efficacy-original"), "w+b") as f:
        github.fetch(row, f)
        need(f.tell() == row["size_in_bytes"], "truncated original")
        f.seek(0)
        need(hashlib.file_digest(f, "sha256").hexdigest() == row["sha256"], "official ZIP mismatch")
        f.seek(0)
        with zipfile.ZipFile(f) as z:
            names = z.namelist()
            need(len(names) == len(set(names)) and all(not PurePosixPath(n).is_absolute() and
                 ".." not in PurePosixPath(n).parts for n in names) and z.testzip() is None, "archive members")
            yield z


def unmetered(z, phase, arm, branch, env, measured):
    prefix = f"ordinary/{arm}/{phase}"
    twin = f"measured/{arm}/{phase}"
    command = read(z, prefix, "cargo.json.gz")
    need(command["observer_argv"] is None and command["expected"] == command["exit"] ==
         (101 if phase == "invalid" else 0) and command["env"] == env and command["stdin_sha256"] == sha(b"")
         and prefix + "/clock.json" not in z.NameToInfo, "ordinary command has a wrapper or counter")
    need(read(z, prefix, "source.json") == read(z, twin, "source.json"), "ordinary source differs")
    data, diag = (raw(z, prefix, "cargo." + s + ".gz") for s in ("stdout", "stderr"))
    roster = original.cargo_messages(data, diag, command, command["exit"], command["cwd"])
    disk, total = original.storage(z, prefix)
    own = read(z, prefix, "visit.json")
    other = read(z, twin, "visit.json")
    need(own["allocated"] == total and own["instructions"] is None and
         {k:v for k,v in own.items() if k not in ("instructions", "allocated")} ==
         {k:v for k,v in other.items() if k not in ("instructions", "allocated")}, "ordinary receipt")
    if phase == "invalid":
        need(roster is None and sorted(read(z, prefix, "working.json")) == disk["failed_sessions"], "failed history")
    else:
        need(roster == read(z, prefix, "roster.json.gz") == measured["roster"] and
             native_verdict(z, prefix, branch) == measured["native"] and not disk["failed_sessions"],
             "unmetered whole-ELF behavior or typed roster")
    return total


def host(z, pos, inputs, parser_digests):
    en = json.loads(z.read("enrollment.json"))
    order = ORDER[pos]
    need((en["run"], en["head"], en["attempt"], en["position"], en["order"], en["command"]) ==
         (RUN, HEAD, 1, pos, order, COMMAND) and en["plan"] == PLAN == sha(z.read("PLAN.md")), "registration")
    complete = json.loads(z.read("complete.json"))
    need(complete["host_complete"] is True and complete["raw_counts_unscaled"] is True and
         complete["arms"] == order and complete["phases"] == list(VISITS) and
         "failure.txt" not in z.NameToInfo and json.loads(z.read("ruff-inputs.json")) == inputs, "whole acquisition")
    sdk = original.sdk(z, en)
    source = json.loads(z.read("source-kit.json"))
    need(en["source"] == source and source["run"] == 41199659076 and
         source["manifest"] == "c29e2e57626491804d9c24e5fa50a709015a002067a3bf39e884d8b6ef0fea43",
         "source-built SDK binding")
    control = original.replay_settled.binding(z)
    calibration = original.calibration(z, en["boot"])
    terminal = read(z, "sdk", "terminal.json")
    need(terminal["both_complete_byte_and_inode_inventories_unchanged"] is True and
         terminal["registry"] == sha((json.dumps(inputs["archives"], sort_keys=True, separators=(",",":")) + "\n").encode()),
         "terminal SDK/registry identities")
    envs, clean, bodies, checked, rows = {}, {}, {}, {}, {}
    for arm in order:
        env = original.active(z, "clean/" + arm, arm, sdk, source["manifest"])
        envs[arm] = env
        for branch in REVS:
            ref = original.visit(z, f"clean/{arm}/{branch}", arm, branch, "cold-"+branch, env, parser_digests, "clean")
            clean[arm,branch] = ref
            for name in ("cli", "reader"):
                desc = ref["native"][name]
                digest = desc["whole"]
                need(bodies.setdefault(digest, desc) == desc, "inconsistent clean ELF")
                if digest not in checked:
                    checked[digest] = original.replay_elf.verify(z, "native-bodies/"+digest+".zst", desc,
                                                                  "ruff" if name == "cli" else None)
        original.native_provider(z, arm)
    left, right = (envs[a] for a in ORDER["01"])
    need(left == {k:v for k,v in right.items() if k != "CARGO_ENCODED_RUSTFLAGS"}, "unequal arm environments")
    for branch in REVS:
        a, b = (clean[arm,branch] for arm in ORDER["01"])
        need(a["roster"]["members"] == b["roster"]["members"] and
             all(a["native"][k] == b["native"][k] for k in ("typed","cli_cases","fstring_cases")) and
             all(a["native"][k][s] == b["native"][k][s] for k in ("cli","reader") for s in ("executable","loads")),
             "clean equivalence across arms")
    rosters = {}
    previous_stop = 0
    for arm in order:
        env = envs[arm]
        rows[arm] = {}
        for lane in ("measured", "ordinary"):
            slot = lane+"/"+arm
            need(original.active(z, slot, arm, sdk, source["manifest"]) == env, "changed environment")
            watched = read(z, slot+"/return-B", "watched-git-files.json")
            need(watched == read(z, slot+"/unchanged-B","watched-git-files.json") and
                 set(watched) == {"HEAD","refs/heads/historical-feature"}, "truly unchanged Git state")
            grace = read(z, slot+"/repair","failed-session-grace.json")
            need(grace["sessions"] == read(z, slot+"/invalid", "working.json") and
                 all(grace["ready_ns"] >= s["created_ns"] + 11_000_000_000 for s in grace["sessions"].values()),
                 "failed-state ownership and grace")
        for phase in VISITS:
            branch = "A" if phase in ("cold-A", "return-A") else "B"
            measured = original.visit(z, f"measured/{arm}/{phase}", arm, branch, phase, env, parser_digests, "measured")
            if phase != "invalid":
                ref = clean[arm, branch]
                need(measured["native"] == ref["native"] and measured["roster"]["members"] == ref["roster"]["members"]
                     and measured["native_output"] == ref["native_output"], ("full own-empty products",arm,phase))
                need(rosters.setdefault(phase, measured["roster"]) == measured["roster"],
                     ("both arms report the same work",phase))
                if phase == "unchanged-B":
                    dirty = measured["roster"]["dirty"]
                    need(len(dirty)==1 and dirty[0]["name"]=="ruff" and dirty[0]["kind"]==["bin"], "settled roster")
            outside = unmetered(z, phase, arm, branch, env, measured)
            raw_count = measured["raw_clock"]
            need(set(raw_count) == {"start","stop","user_us","system_us","instructions","enabled","running","event_errno","code"}
                 and all(type(v) is int for v in raw_count.values()) and
                 previous_stop <= raw_count["start"] < raw_count["stop"] and raw_count["user_us"] + raw_count["system_us"] > 0,
                 ("ordered native observations", pos, arm, phase))
            previous_stop = raw_count["stop"]
            rows[arm][phase] = dict(instructions=measured["instructions"], allocated=measured["allocated"],
                                    unmetered_allocated=outside, enabled=raw_count["enabled"], running=raw_count["running"])
    storage_mode = z.read("storage-mode.txt").decode().strip()
    need(storage_mode in {"private-ext4", "runner-filesystem"}, "unknown storage backend")
    return dict(boot=en["boot"], runner=en["runner"], order=order, cpu=calibration["cpu"], pmu=calibration["pmu"],
                storage_mode=storage_mode, filesystem=z.read("filesystem.txt").decode().strip(),
                source_manifest=source["manifest"], bodies=checked, native_binding=control, arms=rows)


def score(rows):
    off, on = rows["Koff"], rows["Kon"]
    phases = {p: ratio(off[p]["instructions"], on[p]["instructions"]) |
              {"additional_allocated_bytes":on[p]["allocated"]-off[p]["allocated"]} for p in VISITS}
    returns = ("return-A","return-B")
    whole = ratio(sum(off[p]["instructions"] for p in returns),sum(on[p]["instructions"] for p in returns))
    cold_switch_return = ("cold-A", "first-B", "return-A", "return-B")
    from_empty = ratio(sum(off[p]["instructions"] for p in cold_switch_return),
                       sum(on[p]["instructions"] for p in cold_switch_return))
    return dict(phases=phases, both_returns=whole, from_empty_through_both_returns=from_empty,
                max_visit_end_allocated={arm:max(r["allocated"] for r in values.values()) for arm,values in rows.items()},
                passes_screen=all(phases[p]["numerator"] >= 2*phases[p]["denominator"]
                for p in returns) and whole["numerator"] >= 2*whole["denominator"])


def main():
    meta = catalog()
    inputs, parser = original.corpus.source()
    hosts = {}
    for pos,row in meta.items():
        with archive(row) as z:
            hosts[pos] = host(z, pos, inputs, parser)
    a,b = hosts.values()
    need(a["boot"] != b["boot"] and a["source_manifest"] == b["source_manifest"] and a["cpu"] == b["cpu"] and
         a["pmu"] == b["pmu"], "two separate comparable hosts")
    scores = {pos:score(h["arms"]) for pos,h in hosts.items()}
    print(json.dumps(dict(run=RUN,head=HEAD,plan=PLAN,registry_archives=len(inputs["archives"]),
                         artifacts=meta,hosts=hosts,scores=scores,advance=all(s["passes_screen"] for s in scores.values())),
                     indent=2,sort_keys=True))


if __name__ == "__main__":
    main()
