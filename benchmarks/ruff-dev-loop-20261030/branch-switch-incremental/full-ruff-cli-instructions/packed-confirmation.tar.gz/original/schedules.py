"""Publish the deterministic counterbalanced assignments before any worker is acquired."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DESIGN = "8f4795736921f08b840cbed76ac7f81b93440a720d753e5b8bcc954e05a9955a"
POSITIONS = tuple(f"{i:02}" for i in range(1, 13))
FORWARD = ("Foff", "Fon", "Kon", "Koff")


def generate(cohort):
    if cohort not in (1, 2):
        raise ValueError("unknown cohort")
    seed = f"Ohm/full-Ruff/whole-Cargo/instructions/confirmation/{DESIGN}/cohort-{cohort}"
    ranked = sorted(POSITIONS, key=lambda p: hashlib.sha256(f"{seed}/{p}".encode("ascii")).digest())
    orders = {p: list(FORWARD if p in ranked[:6] else reversed(FORWARD)) for p in POSITIONS}
    return {"cohort": cohort, "design_sha256": DESIGN, "seed": seed, "orders": orders}


def encoded(cohort):
    return (json.dumps(generate(cohort), indent=2, sort_keys=True) + "\n").encode()


def load(cohort):
    data = (HERE / f"cohort-{cohort}.json").read_bytes()
    if data != encoded(cohort):
        raise ValueError("frozen schedule changed")
    return json.loads(data)


if __name__ == "__main__":
    for i in (1, 2):
        data = encoded(i)
        path = HERE / f"cohort-{i}.json"
        if path.exists():
            load(i)
        else:
            with path.open("xb") as f:
                f.write(data)
        print(hashlib.sha256(data).hexdigest(), path.name,
              "F-off-first", ",".join(p for p,v in load(i)["orders"].items() if v[0] == "Foff"))
