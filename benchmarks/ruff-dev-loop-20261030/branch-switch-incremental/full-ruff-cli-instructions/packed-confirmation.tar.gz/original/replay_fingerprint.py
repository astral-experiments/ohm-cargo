"""Reopen real strict Cargo native-link fingerprints and their original rustc dependency rules."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import struct
import subprocess


MARK = b'/dev/null/ohm-recheck-dependent-links'
HERE = Path(__file__).resolve().parent


def digest3(data):
    tool = shutil.which('b3sum') or str(HERE/'distro-tools/b3sum-root/usr/bin/b3sum')
    return bytes.fromhex(subprocess.check_output([tool, '--no-names'], input=data).decode().strip())


def decode(data):
    f = io.BytesIO(data)
    def take(n):
        b = f.read(n)
        if len(b) != n:
            raise ValueError('incomplete Cargo dep-info')
        return b
    def word():
        return struct.unpack('<I',take(4))[0]
    def field():
        return take(word())
    def tagged():
        b = take(1)
        assert b in (b'\x00',b'\x01')
        return b == b'\x01'
    assert take(5) == b'\x01\0\0\0\xff'
    version = take(1)[0]
    assert version in (2,4)
    table = {}
    for i in range(word()):
        kind = int(tagged())
        name = field()
        checksum = (struct.unpack('<Q',take(8))[0],field()) if tagged() else None
        table[i] = (kind,name,checksum)
    for _ in range(word()):
        field()
        if tagged():
            field()
    native = None
    trailer = f.read(4)
    if trailer == b'LNK1':
        native = word()
        assert table[native] == (1,MARK,None)
        expected = digest3(data[:f.tell()])
        assert take(32) == expected
        trailer = f.read(4)
    if trailer:
        assert trailer == b'OBS1'
        i = word()
        tagged()
        assert table[i][1].split(b'/')[-1] == b'ohm-foreign-span-bytes' and table[i][2] is None
        expected = digest3(data[:f.tell()])
        assert take(32) == expected and f.read() == b''
    elif version == 2:
        assert all(row[2] is None for row in table.values())
    return {'version':version,'files':len(table),'link_index':native}


def rustc_rules(data, origin):
    targets = [(lhs, rhs) for line in data.splitlines() if b': ' in line and not line.startswith(b'#')
               for lhs,rhs in [line.split(b': ', 1)]]
    path = str(origin).encode()
    own, = [rhs for lhs,rhs in targets if lhs == path]
    assert own and MARK not in own.split() and b'\r' not in own
    marked = [lhs for lhs,rhs in targets if rhs == own + b' ' + MARK]
    assert marked and not any(MARK in rhs.split() and rhs != own + b' ' + MARK for _,rhs in targets)
    return [lhs.decode() for lhs in marked]


def diagnostic(z):
    prefix = 'blocking-records/'
    census = json.loads(z.read(prefix+'census.json'))
    origins = json.loads(z.read(prefix+'origins.json'))
    def original(h):
        data = gzip.decompress(z.read(prefix+'objects/'+h+'.gz'))
        assert hashlib.sha256(data).hexdigest() == h
        return data
    actual = {}
    seen = {}
    for path,row in census.items():
        h = row['sha256']
        if h not in seen:
            seen[h] = decode(original(h))
        value = seen[h]
        assert {k:row[k] for k in value} == value
        if value['link_index'] is None:
            continue
        o = origins[path]
        outputs = {v['path']:rustc_rules(original(v['sha256']),v['path']) for v in o['raw']}
        assert outputs and o['sha256'] == h and PurePosixPath(path).parent.name == 'fingerprint'
        actual[path] = {'index': value['link_index'], 'bytes':row['identity'][2], 'outputs': outputs,
                        'chain': [c['name'] for c in o['chain']] if o['chain'] else None}
    assert actual.keys() == origins.keys()
    return {'census_size':len(census),'unique_encoded_records':len(seen),'markers':actual}
