"""Independently recompute sharing bounds from physical ledgers, per-inode hashes and cmp evidence."""
from collections import defaultdict
from pathlib import PurePosixPath
import re
import stat

from replay_metrics import need, sha
from replay_native import read

OBSERVER = "ea6526bd3466552797cd0e003ec0c831a78c4fb560d483c72b42e8d55a36685d"
LABEL = re.compile(r"s-[0-9a-z]+-_([0-9a-f]{16})_[0-9a-z]+-[0-9a-z]+")


def tags(names):
    sets = defaultdict(set)
    for n, record in names.items():
        p = PurePosixPath(n)
        m = LABEL.fullmatch(p.name)
        if m and "incremental" in p.parts and stat.S_ISDIR(record[3]):
            sets[p.parent.as_posix()].add(m[1])
    return sets


def reread(z, base, phase):
    p = base + "/" + phase
    status = read(z, p, "object-equality-status.json")
    need(status["source"] == OBSERVER and status["required_for_pmu"] is False and
         status["eligible"] == (status["exit"] == 0), "object comparison eligibility")
    if not status["eligible"]:
        return {"admitted": False, "exit": status["exit"]}
    proof = read(z, p, "object-equality.json.gz")
    cold = base + "/cold-A"
    need(proof["source_ledgers"] == dict(cold=sha(z.read(cold + "/path-inodes.json.gz")),
                                         visit=sha(z.read(p + "/path-inodes.json.gz"))), "object census binding")
    names = read(z, p, "path-inodes.json.gz")
    before = tags(read(z, cold, "path-inodes.json.gz"))
    after = tags(names)
    old_dirs = {unit: next(iter(s)) for unit, s in before.items() if
                len(s) == 1 and len(after.get(unit, {})) == 2 and not (s - after[unit])}
    need(old_dirs == proof["two_checkout_units"], "alternate checkout attribution")
    aliases, raw_aliases = defaultdict(list), defaultdict(list)
    records, display = {}, {}
    for name, row in names.items():
        if not stat.S_ISREG(row[3]):
            continue
        key = tuple(row[:2])
        records[key] = row
        aliases[key].append(name)
        basename = PurePosixPath(name).name
        if basename.endswith(".o") or basename.startswith("ohm-packed-object-"):
            raw_aliases[key].append(name)
    loose_exclusions = set(proof["non_elf_objects_excluded"])
    classify = {}
    older, size_buckets = set(), defaultdict(set)
    for key, candidates in raw_aliases.items():
        name = min(candidates)
        display[key] = name
        if name in loose_exclusions:
            need(name.endswith(".o"), "excluded a packed object as non-ELF")
            continue
        kind = "packed" if PurePosixPath(name).name.startswith("ohm-packed-object-") else "loose-elf"
        classify[key] = kind
        size_buckets[(key[0], kind, records[key][5])].add(key)
        if len(aliases[key]) == records[key][2] and all(
            any((m := LABEL.fullmatch(s.name)) and old_dirs.get(s.parent.as_posix()) == m[1]
                for s in PurePosixPath(n).parents) for n in aliases[key]
        ):
            older.add(key)
    need(loose_exclusions <= set(display.values()), "unknown excluded inode")
    def removable(keys):
        old = keys & older
        return old if old != keys else old - {min(old, key=lambda k: (records[k][4], k))}
    allowance, equal, hashed, measured_pairs = set(), set(), set(), {}
    for group in size_buckets.values():
        possible = removable(group)
        if not possible:
            continue
        allowance |= possible
        same = defaultdict(set)
        for k in group:
            n = display[k]
            h = proof["candidate_sha256"][n]
            need(re.fullmatch("[0-9a-f]{64}", h), "bad complete-object SHA")
            hashed.add(n)
            same[h].add(k)
        for h, keys in same.items():
            old = removable(keys)
            equal |= old
            keep = min(keys - old)
            for k in old:
                measured_pairs[display[k]] = (display[keep], h, records[k][4] * 512, classify[k])
    comparisons = {r["older"]: (r["surviving"], r["sha256"], r["allocated_bytes"], r["kind"])
                   for r in proof["complete_cmp"]}
    need(hashed == proof["candidate_sha256"].keys() and len(comparisons) == len(proof["complete_cmp"]) and
         comparisons == measured_pairs, "mismatched exact-equality comparisons")
    alloc = lambda keys: sum(records[k][4] * 512 for k in keys)
    metrics = {}
    for label in ("loose-elf", "packed"):
        keys = {k for k, kind in classify.items() if kind == label}
        metrics[label] = {"unique_object_inodes": len(keys), "older_only_inodes": len(keys & older),
                          "older_only_bytes": alloc(keys & older), "length_only_ceiling_bytes": alloc(keys & allowance),
                          "byte_equal_older_inodes": len(keys & equal), "byte_equal_older_bytes": alloc(keys & equal)}
    need(metrics == proof["summary"], "object equality denominator")
    return {"admitted": True, "metrics": metrics, "complete_byte_comparisons": len(comparisons),
            "two_checkout_units": len(old_dirs), "excluded_non_elf": len(loose_exclusions)}
