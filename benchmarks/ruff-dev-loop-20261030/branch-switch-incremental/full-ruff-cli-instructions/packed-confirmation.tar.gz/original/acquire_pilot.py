"""Authenticate and retain the exact two hosted original ZIPs for an enrolled whole-Cargo pilot."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


GH = "/home/dev-user/.local/bin/gh-auto"
REPO = "repos/astral-experiments/ohm"
CHECKOUT = Path("/home/dev-user/code/oss/ohm-package-qa-branch-return-pmu-20261031")
BRANCH = "charlie/qa-branch-return-pmu-20261031"
RESERVE = 4 << 30


def need(ok, problem):
    if not ok:
        raise ValueError(problem)


def api(path):
    return json.loads(subprocess.check_output([GH, "api", REPO + "/actions/" + path], cwd=CHECKOUT))


def check(file, size, digest):
    need(file.is_file() and not file.is_symlink() and file.stat().st_size == size, "incorrect ZIP size")
    with file.open("rb") as f:
        need(hashlib.file_digest(f, "sha256").hexdigest() == digest, "wrong GitHub ZIP digest")


def catalog(run, head):
    need(re.fullmatch("[a-f0-9]{40}", head) and run > 0, "exact pilot run and QA head required")
    actual = api(f"runs/{run}")
    need(actual["id"] == run and actual["run_attempt"] == 1 and actual["event"] == "workflow_dispatch" and
         actual["head_branch"] == BRANCH and actual["head_sha"] == head and actual["path"] == ".github/workflows/ci.yml"
         and actual["status"] == "completed" and actual["conclusion"] == "success", "unqualified pilot run")
    raw_jobs = api(f"runs/{run}/attempts/1/jobs?per_page=100")
    jobs = {j["name"]: j for j in raw_jobs["jobs"]}
    need(len(jobs) == raw_jobs["total_count"] == 2 and
         all(j["head_sha"] == head and j["run_id"] == run and j["conclusion"] == "success" for j in jobs.values()),
         "incomplete pilot positions")
    catalog = api(f"runs/{run}/artifacts?per_page=100")
    artifacts = {j["name"]: j for j in catalog["artifacts"]}
    need(len(artifacts) == catalog["total_count"] == 2, "unexpected pilot artifact membership")
    custody = {"run": run, "head": head, "attempt": 1, "jobs": {}, "artifacts": []}
    for pos in ("01", "02"):
        j = jobs["Whole branch-return pilot " + pos]
        a = artifacts["branch-return-pmu-" + pos]
        need(a["workflow_run"]["id"] == run and a["workflow_run"]["head_sha"] == head and not a["expired"]
             and re.fullmatch("sha256:[a-f0-9]{64}", a["digest"]), "artifact identity")
        size, digest = a["size_in_bytes"], a["digest"][7:]
        need(0 < size <= 2 << 30, "unexpected pilot medium size")
        filename = f'{run}-{pos}-{a["id"]}.zip'
        custody["jobs"][pos] = j["id"]
        custody["artifacts"].append({"position": pos, "id": a["id"], "size_in_bytes": size,
                                     "sha256": digest, "filename": filename})
    return custody


def fetch(artifact, destination):
    command = [GH, "api", f'{REPO}/actions/artifacts/{artifact["id"]}/zip']
    remaining = artifact['size_in_bytes']
    with subprocess.Popen(command, cwd=CHECKOUT, stdout=subprocess.PIPE) as proc:
        try:
            while chunk := proc.stdout.read(min(remaining + 1, 2 ** 20)):
                need(len(chunk) <= remaining, 'official ZIP exceeds its reported length')
                destination.write(chunk)
                remaining -= len(chunk)
            need(proc.wait() == 0 and remaining == 0, 'incomplete official ZIP')
        finally:
            if proc.poll() is None:
                proc.kill()
    destination.flush()


def acquire(run, head, directory):
    need(directory.is_absolute() and directory.resolve() == directory and directory.is_dir(),
         "missing canonical receipt directory")
    custody = catalog(run, head)
    for artifact in custody["artifacts"]:
        filename, size, digest = (artifact[k] for k in ("filename", "size_in_bytes", "sha256"))
        dst = directory / filename
        if not dst.exists():
            need(shutil.disk_usage(directory).free > RESERVE + size, "native raw ZIP evidence space reserve")
            with tempfile.NamedTemporaryFile(prefix=filename + ".", suffix=".partial", dir=directory, delete=False) as f:
                temp = Path(f.name)
            try:
                with temp.open("wb") as f:
                    fetch(artifact, f)
                    f.flush()
                    os.fsync(f.fileno())
                check(temp, size, digest)
                os.link(temp, dst)
            finally:
                temp.unlink(missing_ok=True)
        check(dst, size, digest)
    out = directory / f"{run}-custody.json"
    if out.exists():
        need(json.loads(out.read_bytes()) == custody, "original custody changed")
    else:
        with out.open("x") as f:
            f.write(json.dumps(custody, indent=2, sort_keys=True) + "\n")
    print(out)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("run", type=int)
    p.add_argument("head")
    p.add_argument("directory", type=Path)
    a = p.parse_args()
    acquire(a.run, a.head, a.directory)
