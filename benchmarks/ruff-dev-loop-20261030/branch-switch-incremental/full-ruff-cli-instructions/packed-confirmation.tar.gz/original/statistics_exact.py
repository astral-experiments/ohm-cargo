"""Exact, paired estimates. Input rows have already passed the pilot's independent raw reader."""
from fractions import Fraction
from math import comb
from statistics import median

from schedules import POSITIONS, load

VISITS = ("cold-A","first-B","return-A","return-B","unchanged-B","invalid","repair")
RETURNS = ("return-A","return-B")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def exact(value):
    f = Fraction(value)
    return [f.numerator, f.denominator]


def order_for(cohort, position, roles):
    need(list(roles) in (["F"], ["K"], ["F","K"]), "empty or ambiguous eligible roles")
    return [a for a in load(cohort)["orders"][position] if a[0] in roles]


def counts(raw):
    for arm, visits in raw.items():
        need(set(visits) == set(VISITS), f"incomplete raw visits for {arm}")
        for phase, visit in visits.items():
            n, alloc, clock = visit["instructions"], visit["allocated"], visit["raw_clock"]
            need(type(n) is int and n > 0 and type(alloc) is int and alloc >= 0, "invalid counter/allocation")
            expected = 101 if phase == "invalid" else 0
            need(all(type(clock[k]) is int for k in ("code","event_errno","instructions","enabled","running")) and
                 clock["code"] == expected and clock["event_errno"] == 0 and clock["instructions"] == n and
                 0 < clock["running"] <= clock["enabled"] and 1000*clock["running"] >= 995*clock["enabled"],
                 f"failed native PMU observation {arm}/{phase}")


def physical_order(order, raw):
    previous_stop = 0
    for arm in order:
        for v in VISITS:
            clock = raw[arm][v]["raw_clock"]
            start,stop = clock["start"],clock["stop"]
            need(type(start) is int and type(stop) is int and previous_stop <= start < stop,
                 f"monotonic PMU records contradict registered order at {arm}/{v}")
            previous_stop = stop


def pilot_eligibility(pilot):
    need(pilot["pilot_only"] is True and set(pilot["hosts"]) == {"01","02"}, "two admitted pilot hosts required")
    boots = [host["boot"] for host in pilot["hosts"].values()]
    need(all(boots) and len(set(boots)) == 2, "reused pilot boot")
    for p,host in pilot["hosts"].items():
        need(set(host["raw"]) == {"Foff","Fon","Koff","Kon"}, "incomplete pilot roles")
        counts(host["raw"])
        arms = ["Foff","Fon","Kon","Koff"]
        physical_order(arms if p == "01" else list(reversed(arms)),host["raw"])
    eligible = {s: all(host["raw"][s+"off"][r]["instructions"] >= 2*host["raw"][s+"on"][r]["instructions"]
                       for host in pilot["hosts"].values() for r in RETURNS) for s in ("F","K")}
    need(eligible == pilot["qualifies_for_confirmation"], "pilot decision disagrees with the admitted raw counts")
    return [role for role in ("F","K") if eligible[role]]


def position(raw, role):
    off, on = (raw[role+m] for m in ("off","on"))
    def total(visits, phases):
        return sum(visits[p]["instructions"] for p in phases)
    groups = {p:(p,) for p in VISITS}
    groups.update({"round_trip":RETURNS, "first_B_plus_return_A":("first-B","return-A"),
                   "empty_A_through_return_B":("cold-A","first-B",*RETURNS)})
    ratios = {k:Fraction(total(off,phases),total(on,phases)) for k,phases in groups.items()}
    initial = total(on,("cold-A","first-B")) - total(off,("cold-A","first-B"))
    saved = total(off,RETURNS) - total(on,RETURNS)
    cycles = 0 if initial <= 0 else ((initial+saved-1)//saved if saved > 0 else None)
    return {"ratios":{k:exact(v) for k,v in ratios.items()},
            "peak_observed_visit_end_bytes":{m:max(v["allocated"] for v in arm.values())
                                             for m,arm in (("off",off),("on",on))},
            "model":{"extra_through_first_B":initial, "saved_per_return_pair":saved, "pairs_to_repay":cycles}}


def cohort_report(cohort, roles, rows, previous_boots=(), cohort_errors=()):
    inventory, failures, used = {}, list(cohort_errors), set(previous_boots)
    for key in sorted(set(rows) - set(POSITIONS)):
        failures.append(f"unregistered position {key}")
    for p in POSITIONS:
        order = order_for(cohort,p,roles)
        row = rows.get(p,{})
        summary = {k:row[k] for k in ("boot","artifact","job","error") if k in row}
        inventory[p] = summary | {"order":order}
        try:
            need(bool(row) and "error" not in row, row.get("error","missing position"))
            need(row["order"] == order and len(order) == len(set(order)) and set(row["raw"]) == set(order),
                 "unexpected order or role")
            need(isinstance(row["boot"],str) and bool(row["boot"]) and row["boot"] not in used,
                 "boot missing or reused")
            used.add(row["boot"])
            counts(row["raw"])
            physical_order(order,row["raw"])
        except (KeyError,TypeError,ValueError) as e:
            inventory[p]["error"] = str(e)
            failures.append(p + " " + str(e))
    out = {"cohort":cohort, "eligible":list(roles), "positions":inventory, "errors":failures}
    if failures:
        return out | {"status":"withheld"}
    q = 3 if len(roles) == 1 else 2
    marginal = 1 - Fraction(2*sum(comb(12,i) for i in range(q)),2**12)
    out.update(status="complete", ranks=[q,13-q], marginal_coverage=exact(marginal),
               simultaneous_coverage_at_least=exact(1-len(roles)*(1-marginal)), results={})
    for p,row in rows.items():
        inv = inventory[p]
        inv["raw"] = row["raw"]
        inv["paired"] = {role:position(row["raw"],role) for role in roles}
        if len(roles) == 2:
            inv["packed_on_vs_full_on"] = {
                v:{"instructions_K_over_F":exact(Fraction(row["raw"]["Kon"][v]["instructions"],
                                                         row["raw"]["Fon"][v]["instructions"])),
                   "additional_K_bytes":row["raw"]["Kon"][v]["allocated"]-row["raw"]["Fon"][v]["allocated"]}
                for v in VISITS}
    for role in roles:
        metrics = {}
        for n in (*RETURNS,"round_trip"):
            values = sorted(Fraction(*inventory[p]["paired"][role]["ratios"][n]) for p in POSITIONS)
            metrics[n] = {"minimum":exact(values[0]), "median":exact(median(values)), "maximum":exact(values[-1])}
            if n == "round_trip":
                metrics[n]["interval"] = [exact(values[q-1]),exact(values[-q])]
                metrics["passes_2x"] = values[q-1] > 2
        out["results"][role] = metrics
    return out


def replication(first, second):
    need([first["cohort"],second["cohort"]] == [1,2], "need cohorts 1 and 2 in order")
    for key in ("eligible","pilot_sha256","source"):
        need(first[key] == second[key], "confirmation registration changed: "+key)
    need(first["run"] != second["run"], "reused official run")
    if any(r["status"] != "complete" for r in (first,second)):
        return {"status":"withheld","reason":"at least one cohort was withheld"}
    for r in (first,second):
        recomputed = cohort_report(r["cohort"],r["eligible"],r["positions"])
        need(recomputed["status"] == "complete" and recomputed["results"] == r["results"],
             "reopened raw pairs differ from the reported cohort decision")
    boots = [v["boot"] for r in (first,second) for v in r["positions"].values()]
    need(len(set(boots)) == 24, "reused confirmation boot")
    return {"status":"complete","cohorts":[first["run"],second["run"]],
            "repeatable_2x":{s:all(r["results"][s]["passes_2x"] for r in (first,second)) for s in first["eligible"]}}
