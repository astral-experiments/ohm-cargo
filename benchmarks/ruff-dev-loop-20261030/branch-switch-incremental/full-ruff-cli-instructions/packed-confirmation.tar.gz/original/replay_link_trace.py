"""Derive image ownership for original GNU linker opens, unsuccessful searches and Cargo reads."""
import ast
from pathlib import PurePosixPath
import re
import tarfile


def events(lines):
    pending = None
    for line in lines:
        line = line.rstrip(b'\n')
        if line.startswith(b'<... '):
            syscall, middle, rest = line[5:].partition(b' resumed>')
            if pending is None or not middle or not pending.startswith(syscall + b'('):
                pending = None
                yield None
                continue
            line = pending + rest
            pending = None
        if pending is not None:
            yield None
            pending = None
        if line.endswith(b' <unfinished ...>'):
            pending = line[:-len(b' <unfinished ...>')]
        else:
            yield None if line.startswith(b'???(') else line
    if pending is not None:
        yield None


def audit(file, claims, side, catalog, cargo, wild, required_execs=()):
    images, parents, observations = {}, {}, []
    pending_execs = {(x['pid'], x['exe'], tuple(x['argv'])) for x in required_execs}
    with tarfile.open(fileobj=file, mode='r|gz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.size < 256 << 20 and re.fullmatch(r'pid\.\d+',entry.name)
            pid = int(entry.name.split('.')[1])
            assert pid not in images
            images[pid] = []
            for i, line in enumerate(events(archive.extractfile(entry))):
                item = (pid,i)
                if line is None:
                    images[pid].append((i,None))
                    continue
                if line.startswith((b'execve(',b'execveat(')) and re.search(rb'=\s*0$',line):
                    found = re.search(rb'"((?:[^"\\]|\\.)*)"',line)
                    assert found
                    name = ast.literal_eval(found[0].decode())
                    images[pid].append((i,(pid,name)))
                    if any((wanted[0], wanted[1]) == (pid,name) for wanted in pending_execs):
                        args = re.search(rb'", (\[.*\]), (?:0x|/\*)', line)
                        assert args, ('truncated native argv', pid, name)
                        pending_execs.discard((pid,name,tuple(ast.literal_eval(args[1].decode()))))
                birth = re.fullmatch(rb'(?:clone3?|fork|vfork)\(.*\)\s*=\s*([0-9]+)',line)
                if birth:
                    child = int(birth[1])
                    assert child not in parents and child != pid
                    parents[child] = item
                if line.startswith((b'open(',b'openat(',b'openat2(')):
                    fd = re.search(rb'\)\s*=\s*\d+<([^>]+)>$',line)
                    if fd:
                        path = fd[1].decode('utf-8','surrogateescape')
                        if path == side or path in catalog or PurePosixPath(path).name.startswith('libgcc_s.so'):
                            observations.append((item,'fd',path))
                if b'ENOENT' in line and ('"'+side+'"').encode() in line:
                    observations.append((item,'enoent',side))
    assert len(images) == claims['captured_threads'] and not pending_execs, ('missing native exec', pending_execs)
    def image_before(pid, when):
        seen = set()
        while True:
            assert pid not in seen
            seen.add(pid)
            prev = [val for time,val in images[pid] if time < when]
            if prev:
                return prev[-1]
            if pid not in parents:
                return None
            pid,when = parents[pid]
    rows = {k:set() for k in ('cargo_records','wild_opens','wild_missing','wild_libgcc_reads')}
    for (pid, i), kind, path in observations:
        who = image_before(pid,i)
        point = (pid,i,path)
        if who == cargo and kind == 'fd' and path in catalog:
            rows['cargo_records'].add(point)
        if who in wild:
            if kind == 'fd' and PurePosixPath(path).name.startswith('libgcc_s.so'):
                rows['wild_libgcc_reads'].add(point)
            if path == side:
                rows['wild_opens' if kind == 'fd' else 'wild_missing'].add(point)
    for field, actual in rows.items():
        got = {(r['pid'],r['event'],r['path']) for r in claims[field]}
        assert actual == got and len(got) == len(claims[field]), (field,actual-got,got-actual)
    return {k:sorted(v) for k,v in rows.items()}
