"""Cross-check kernel exec receipts for the physical rustc and linker invocations."""
import ast
import gzip
import re
from pathlib import PurePosixPath

from replay_metrics import need
from replay_native import read


def trace(stream):
    events = []
    pending = {}
    for raw in stream:
        line = raw.decode("utf-8").rstrip("\n")
        m = re.match(r"^(\d+)\s+(.*)$", line)
        if not m:
            need("execve" not in line, "missing traced PID")
            continue
        pid = int(m[1])
        body = m[2]
        if body.startswith("<... execve resumed>"):
            need(pid in pending, "unexpected exec resumption")
            body = pending.pop(pid) + body.removeprefix("<... execve resumed>")
        elif not body.startswith("execve("):
            need("execveat(" not in body and "<... execveat resumed>" not in body, "unhandled execution")
            continue
        if body.endswith("<unfinished ...>"):
            need(pid not in pending, "nested incomplete exec in same task")
            pending[pid] = body.removesuffix("<unfinished ...>").rstrip()
            continue
        m = re.fullmatch(r'execve\(("(?:[^"\\]|\\.)*"),\s*(\[.*\]),\s*.*\)\s*=\s*(.*)', body)
        need(m, ("malformed exec record", body[:160]))
        if m[3].startswith("-1 "):
            continue
        need(m[3] == "0", ("unresolved exec", m[3]))
        path, args = tuple(ast.literal_eval(m[i]) for i in (1, 2))
        need(isinstance(path, str) and isinstance(args, list) and
             all(isinstance(w, str) for w in args), "truncated native argv")
        events.append((pid, path, args))
    need(not pending, "incomplete kernel trace")
    return events


def structural(z, prefix, arm, sdk_root, proxies):
    physical = read(z, prefix, "native-execs.json.gz")
    with z.open(prefix + "/exec.raw.gz") as compressed, gzip.GzipFile(fileobj=compressed) as stream:
        events = trace(stream)
    need(len(events) == physical["successful_exec_count"], "physical exec count")
    all_events = set((pid, exe, tuple(args)) for pid, exe, args in events)
    names = ("rustcs", "wild_processes", "wild_queries", "cargos", "cargo_queries")
    selected = {k: {(q["pid"], q["exe"], tuple(q["argv"])) for q in physical[k]} for k in names}
    need(all(len(physical[k]) == len(selected[k]) and selected[k] <= all_events for k in names),
         "physical summary has an unobserved exec")
    rustcs = []
    native_wild = []
    actual_cargo = []
    native_args = set()
    for pid, exe, args in events:
        p = PurePosixPath(exe)
        key = (pid, exe, tuple(args))
        if p.name == "rustc" and "--crate-name" in args and not any(s.startswith("--print") for s in args):
            if exe == sdk_root + "/bin/rustc" or key in selected["rustcs"]:
                need(key in selected["rustcs"], "omitted physical compiler")
                crate = args[args.index("--crate-name") + 1]
                if crate in {"ruff", "ruff_python_ast", "ruff_python_parser"}:
                    flag = any(s in ("ohm-branch-cache=yes", "-Zohm-branch-cache=yes") for s in args)
                    need(flag == arm.endswith("on") and any("ohm-check-relink-inputs" in s for s in args),
                         "physical compiler options")
                rustcs.append(crate)
                native_args.add(key)
            elif exe not in proxies:
                # A rustup launcher can have a different absolute spelling. Require an exactly
                # matching later invocation of the uniquely identified native compiler.
                need(any(q["pid"] == pid and q["argv"][1:] == args[1:] for q in physical["rustcs"]),
                     ("unknown compiler", exe))
        if key in selected["wild_queries"]:
            need("-o" not in args and any(a in ("-v", "--version", "--help", "--print-output-format")
                                          for a in args), "a physical link was classified as a version query")
        elif key in selected["wild_processes"] or exe == sdk_root + "/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd":
            need(key in selected["wild_processes"], "omitted physical Wild link")
            native_wild.append(key)
        if key in selected["cargos"]:
            actual_cargo.append(key)
    need(native_args == selected["rustcs"] and len(actual_cargo) == physical["real_cargo"] == 1 and
         len(native_wild) == physical["wild"], "physical rosters")
    return {"rustcs": sorted(rustcs), "wild": len(native_wild), "successful_execs": len(events)}
