"""Reconstruct each whole-Cargo instruction and disk result from source-bound hosted receipts."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import corpus
import replay_elf
import replay_owners
import replay_settled
from replay_controls import calibration, native_provider
from replay_processes import structural
from replay_object import reread as measured_equality
from replay_metrics import COMMAND, REVS, VISITS, allocation, cargo_messages, measured_count, need, scores, sha
from replay_native import native_verdict, raw, read

PLAN = "b22aac0fd37a6903c62103f721c0579a5c114d5ea64de5564d5065ce26f7867b"
ORDERS = {"01": ["Foff", "Fon", "Kon", "Koff"], "02": ["Koff", "Kon", "Fon", "Foff"]}
RUST = {"F": "c6fe8ecda65452c105f85367a009af80cbb5efbc",
        "K": "0afbeff303d3658bff52582d8f1a996d59e6c8ce"}
COMPILER = {"F": "1df08b3c45a7e6fa3739a8e753132f707f97896a", "K": "b8fa7ed926a6589fb8fd7e913b0eaadc36875611"}
STRICT = "035e681081683f4141e4c544b8cf9492b73784051e4541c12bb3cbdb73a798a4"
WILD = "lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd"
STOCK = "0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5"


def sdk(z, enrollment):
    manifest_raw = z.read("sdk/manifest.json")
    need(sha(manifest_raw) == enrollment["source"]["manifest"], "unbound complete SDK")
    manifest = json.loads(manifest_raw)
    inventory = {}
    for role in RUST:
        physical = read(z, "sdk", role + ".json")
        need(manifest["roles"][role]["commit"] == RUST[role] and
             physical["compiler_tree"] == COMPILER[role] and physical["role"] == role,
             "wrong compiler or source")
        members = manifest["files"][role]
        inv = physical["files"]
        need(set(members) == set(inv) and
             all([rec[0], rec[4], rec[3]] == members[name] for name, rec in inv.items()),
             "sealed SDK and physically installed files differ")
        need(len(members) >= 64 and members["bin/cargo"][0] == STRICT and members[WILD][0] == STOCK
             and "bin/rustc" in members and "bin/rustdoc" in members, "toolchain closure")
        need(re.fullmatch(r"lib/librustc_driver-[a-f0-9]+\.so", physical["driver"]) and
             physical["driver"] in members, "compiler driver")
        inventory[role] = physical
    first, second = (manifest["files"][k] for k in RUST)
    changes = {p for p in first if first[p] != second[p]}
    driver = inventory["F"]["driver"]
    need(set(first) == set(second) and inventory["K"]["driver"] == driver and driver in changes and
         changes <= {driver, "bin/rustdoc"}, "uncontrolled SDK difference")
    return inventory


def active(z, slot, arm, inventory, source):
    rec = read(z, slot, "arm.json")
    p = inventory[arm[0]]
    roles = ["bin/cargo", "bin/rustc", "bin/rustdoc", WILD, p["driver"]]
    need(rec["arm"] == arm and rec["role"] == arm[0] and rec["source_manifest"] == source and
         rec["files"] == {n: p["files"][n] for n in roles}, "reinstalled or mixed role")
    env = rec["env"]
    need(env["CARGO_TARGET_DIR"] != env["CARGO_BUILD_BUILD_DIR"] and
         env["CARGO_NET_OFFLINE"] == "true" and env.get("CARGO_ENCODED_RUSTFLAGS") ==
         ("-Zohm-branch-cache=yes" if arm.endswith("on") else None) and
         not ({"RUSTC", "RUSTFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER"} & env.keys()),
         "changed effective environment")
    return env


def storage(z, prefix):
    disk = read(z, prefix, "storage.json")
    value = allocation(read(z, prefix, "path-inodes.json.gz"), disk, read(z, prefix, "allocation-readers.json"))
    return disk, value


def visit(z, prefix, arm, branch, phase, env, parser_digests, lane):
    failed = phase == "invalid"
    expected = 101 if failed else 0
    rec = read(z, prefix, "cargo.json.gz")
    need(rec["env"] == env and rec["expected"] == expected and rec["stdin_sha256"] == sha(b""),
         "unexpected command environment")
    src = read(z, prefix, "source.json")
    ref = "historical-parent" if branch == "A" else "historical-feature"
    need(src["commit"] == REVS[branch] and src["tree"] == corpus.TREES[branch] and
         src["branch"] == "refs/heads/" + ref and src["registry_lock"] == corpus.LOCK and
         src["status"] == ("M " + corpus.FILE if failed else "") and
         ((src["parser_sha256"] == parser_digests[branch]) == (not failed)),
         ("source transition and parser contents", prefix))
    n = None
    clock = None
    if lane == "measured":
        argv = rec["observer_argv"]
        need(len(argv) == len(COMMAND) + 2 and argv[2:] == COMMAND and argv[0].endswith("/observers/plain")
             and argv[1].endswith("/" + prefix + "/clock.json"), "extra process in metered window")
        clock = read(z, prefix, "clock.json")
        n = measured_count(clock, expected)
    else:
        need(prefix + "/clock.json" not in z.NameToInfo, "unexpected instrumentation")
        if lane == "clean":
            need(rec["observer_argv"] is None, "wrapped clean reference")
        else:
            need(rec["observer_argv"][0] == "strace" and
                 rec["observer_argv"][-len(COMMAND):] == COMMAND, "unknown structural observer")
    data, diag = (raw(z, prefix, "cargo." + k + ".gz") for k in ("stdout", "stderr"))
    roster = cargo_messages(data, diag, rec, expected, rec["cwd"])
    disk, value = storage(z, prefix)
    need(disk["all_inodes"] > 1000 and min(disk["roots"].values()) > 0 and
         (failed or not disk["failed_sessions"]), "unexpected live/failed session")
    v = read(z, prefix, "visit.json")
    need(v["source"] == REVS[branch] and v["allocated"] == value and v["instructions"] == n and
         v["arm"] == arm and v["branch"] == branch and v["phase"] == phase and v["status"] == expected,
         "disagreement with worker visit")
    if failed:
        failed_state = read(z, prefix, "working.json")
        need(sorted(failed_state) == disk["failed_sessions"], "incorrect failed-state ownership")
        return {"instructions": n, "allocated": value, "failed": failed_state, "raw_clock": clock}
    need(roster == read(z, prefix, "roster.json.gz") and v["dirty"] == len(roster["dirty"]),
         "typed work or freshness differs")
    if phase in ("first-B", "return-A", "return-B"):
        changed = (json.dumps(roster["dirty"], sort_keys=True, separators=(",", ":")) + "\n").encode()
        need(len(roster["dirty"]) == 20 and
             sha(changed) == "051ce242f7e322de5461eb39ad55f6a52cd275b665490eb0c95afe678fb14d8c",
             "different set of dirty units in the historical Ruff edit")
    if lane == "clean" or phase == "cold-A":
        need(len(roster["dirty"]) == 375 and disk["packed_files"] == 0, "cold-compile admission")
    if phase in ("first-B", "return-A", "return-B", "unchanged-B"):
        need(bool(disk["packed_files"]) == (arm == "Kon"), "wrong packed-object activation")
    native = native_verdict(z, prefix, branch)
    need(v["cli"] == native["cli"]["whole"] and v["reader"] == native["reader"]["whole"],
         "worker/whole native hash mismatch")
    return {"instructions": n, "allocated": value, "roster": roster, "native": native,
            "native_output": v["native_output"], "raw_clock": clock}


def read_host(z, pos, enrollment, inputs, parser_digests):
    order = ORDERS[pos]
    need("failure.txt" not in z.NameToInfo and enrollment["position"] == pos and
         enrollment["order"] == order and enrollment["command"] == COMMAND and
         sha(z.read("PLAN.md")) == enrollment["plan"] == PLAN, "unqualified host or registration")
    complete = json.loads(z.read("complete.json"))
    need(complete["host_complete"] is True and complete["raw_counts_unscaled"] is True and
         complete["arms"] == order and complete["phases"] == list(VISITS), "missing complete acquisition")
    need(json.loads(z.read("ruff-inputs.json")) == inputs, "corpus disagrees with original Git objects")
    baseline = {}
    originals = {}
    inventories = sdk(z, enrollment)
    control_run = replay_settled.binding(z)
    meters = calibration(z, enrollment["boot"])
    native_controls = {}
    proxies = set(read(z, "sdk", "proxy.json")["paths"])
    common_env = None
    for arm in order:
        env = active(z, "clean/" + arm, arm, inventories, enrollment["source"]["manifest"])
        shared = {k: v for k, v in env.items() if k != "CARGO_ENCODED_RUSTFLAGS"}
        common_env = shared if common_env is None else common_env
        need(common_env == shared, "roles do not see the same Cargo environment")
        for branch in REVS:
            ref = visit(z, f"clean/{arm}/{branch}", arm, branch, "cold-" + branch, env, parser_digests, "clean")
            baseline[arm, branch] = ref
            for kind in ("cli", "reader"):
                desc = ref["native"][kind]
                need(originals.setdefault(desc["whole"], desc) == desc, "one ELF has two records")
    for branch in REVS:
        first = baseline[order[0], branch]
        for arm in order[1:]:
            cmp = baseline[arm, branch]
            need(first["roster"]["members"] == cmp["roster"]["members"] and
                 all(first["native"][k] == cmp["native"][k] for k in ("typed", "cli_cases", "fstring_cases")),
                 "across-arm native and dependency controls")
            for kind in ("cli", "reader"):
                need(all(first["native"][kind][k] == cmp["native"][kind][k] for k in ("executable", "loads")),
                     "changed native executable contents between arms")
    cli_hashes = {r['native']['cli']['whole'] for r in baseline.values()}
    verified = [replay_elf.verify(z, "native-bodies/" + h + ".zst", desc, 'ruff' if h in cli_hashes else None)
                for h, desc in originals.items()]
    symbols = {v['whole']: v['rust_main'] for v in verified if 'rust_main' in v}
    manifest = json.loads(z.read('sdk/manifest.json'))
    arms = {arm: {} for arm in order}
    topology = {}
    deduplication = {}
    for arm in order:
        lanes = {}
        native_controls[arm] = native_provider(z, arm)
        for lane in ("structural", "measured"):
            slot = lane + "/" + arm
            env = active(z, slot, arm, inventories, enrollment["source"]["manifest"])
            need({k: v for k, v in env.items() if k != "CARGO_ENCODED_RUSTFLAGS"} == common_env, "lane environment")
            p = {}
            for phase in VISITS:
                branch = "A" if phase in ("cold-A", "return-A") else "B"
                prefix = slot + "/" + phase
                result = visit(z, prefix, arm, branch, phase, env, parser_digests, lane)
                p[phase] = result
                if phase != "invalid":
                    ref = baseline[arm, branch]
                    need(result["native"] == ref["native"] and result["roster"]["members"] == ref["roster"]["members"]
                         and result["native_output"] == ref["native_output"], ("own independent clean", prefix))
                if lane == "measured":
                    arms[arm][phase] = {k: result[k] for k in ("instructions", "allocated", "raw_clock")}
            watched = read(z, slot + "/return-B", "watched-git-files.json")
            need(watched == read(z, slot + "/unchanged-B", "watched-git-files.json") and
                 set(watched) == {"HEAD", "refs/heads/historical-feature"}, "changed Git input at unchanged invocation")
            grace = read(z, slot + "/repair", "failed-session-grace.json")
            need(grace["sessions"] == p["invalid"]["failed"] and
                 all(grace["ready_ns"] >= v["created_ns"] + 11_000_000_000 for v in grace["sessions"].values()),
                 "unexpected failed-state cleanup")
            lanes[lane] = p
        topology[arm] = {}
        if arm.endswith("on"):
            deduplication[arm] = {phase: measured_equality(z, "structural/" + arm, phase)
                                  for phase in ("first-B", "return-B")}
        for phase in VISITS:
            prefix = "structural/" + arm
            stages = structural(z, prefix + "/" + phase, arm, read(z, prefix, "arm.json")["sdk"], proxies)
            if phase != 'invalid':
                result = lanes['structural'][phase]
                where = PurePosixPath(common_env['CARGO_TARGET_DIR']).parent
                stages['incremental_owners'] = replay_owners.verify(
                    z, prefix + '/' + phase, where, symbols[result['native']['cli']['whole']], arm[0], manifest)
            topology[arm][phase] = stages
            if phase == "unchanged-B":
                where = PurePosixPath(common_env["CARGO_TARGET_DIR"]).parent
                stages["required_settled_link"] = replay_settled.verify(
                    z, prefix, where, lanes["measured"][phase]["roster"], stages,
                    lanes["structural"][phase]["native"]["cli"]["whole"])
            if phase != "invalid":
                a, b = (lanes[l][phase] for l in ("structural", "measured"))
                need(a["roster"] == b["roster"], "structural instrumentation changed Cargo work")
    storage_mode = z.read("storage-mode.txt").decode().strip()
    need(storage_mode in ("private-ext4", "runner-filesystem"), "unrecognized filesystem setup")
    return {"boot": enrollment["boot"], "raw": arms, "originals": verified, "topology": topology,
            "storage_mode": storage_mode, "filesystem": z.read("filesystem.txt").decode().strip(),
            "calibration": meters, "native_providers": native_controls, "settled_control": control_run,
            "object_equality": deduplication,
            "scores": scores(arms), "complete_native_behaviors": len(order) * (2 + 2 * 6)}


@contextmanager
def verified_zip(file, row):
    file.seek(0)
    need(os.fstat(file.fileno()).st_size == row["size_in_bytes"] and
         hashlib.file_digest(file, "sha256").hexdigest() == row["sha256"], "changed hosted archive")
    file.seek(0)
    with zipfile.ZipFile(file) as z:
        yield z


def replay_cohort(meta, open_original):
    need(meta.get('conclusion', 'success') == 'success', 'refused official cohort')
    inputs, digests = corpus.source()
    hosts = {}
    source = None
    for row in meta["artifacts"]:
        pos = row["position"]
        with open_original(row) as file, verified_zip(file, row) as z:
            entries = [PurePosixPath(v) for v in z.namelist()]
            need(len(entries) == len(set(entries)) and all(not v.is_absolute() and ".." not in v.parts for v in entries),
                 "unsafe, duplicate or ambiguous archive members")
            enrollment = json.loads(z.read("enrollment.json"))
            need(enrollment["run"] == meta["run"] and enrollment["head"] == meta["head"] and
                 enrollment["attempt"] == meta["attempt"] == 1 and pos in ORDERS and pos not in hosts,
                 "incorrect cohort")
            source = enrollment["source"] if source is None else source
            need(enrollment["source"] == source, "different source builder")
            hosts[pos] = read_host(z, pos, enrollment, inputs, digests)
    need(set(hosts) == set(ORDERS) and hosts["01"]["boot"] != hosts["02"]["boot"], "independent pilot boots")
    return {"run": meta["run"], "head": meta["head"], "source": source, "registration": PLAN,
            "official_artifacts": meta["artifacts"], "jobs": meta["jobs"],
            "pilot_only": True, "hosts": hosts, "qualifies_for_confirmation": {
                k: all(h["scores"][k]["each_return_at_least_2x"] for h in hosts.values()) for k in RUST}}


@contextmanager
def hosted_original(row):
    import acquire_pilot
    with os.fdopen(os.memfd_create('ohm-official-pilot'), 'w+b') as file:
        acquire_pilot.fetch(row, file)
        file.seek(0)
        yield file


def main():
    p = argparse.ArgumentParser(description=__doc__)
    locations = p.add_mutually_exclusive_group(required=True)
    locations.add_argument('custody', type=Path, nargs='?', help='Authenticated local artifact inventory')
    locations.add_argument('--github', nargs=2, metavar=('RUN', 'HEAD'),
                           help='Read each official ZIP in turn without a second disk copy')
    args = p.parse_args()
    if args.github:
        import acquire_pilot
        run, head = args.github
        result = replay_cohort(acquire_pilot.catalog(int(run), head), hosted_original)
    else:
        meta = json.loads(args.custody.read_bytes())
        result = replay_cohort(meta, lambda row: (args.custody.parent / row['filename']).open('rb'))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
