"""Match final incremental sessions to their physical Rust process, emitted rmeta or defined main."""
from pathlib import PurePosixPath
import re
import stat

from replay_metrics import need
from replay_native import read


def owners(ledger, processes, root, binary):
    paths = {PurePosixPath(k): v for k, v in ledger.items()}
    dirs = {p for p, v in paths.items() if stat.S_ISDIR(v[3])}
    result = {}
    for row in processes['rustcs']:
        crate = row['crate']
        if crate not in ('ruff', 'ruff_python_ast', 'ruff_python_parser') or row['mode'] != 'full':
            continue
        argv = row['argv']
        inc, = [v.split('=', 1)[1] for v in argv if v.startswith(('incremental=', '-Cincremental='))]
        base = PurePosixPath(inc).relative_to(root)
        candidates = {p for p in dirs if p.parent == base and re.fullmatch(re.escape(crate) + r'-[0-9a-z]{13}', p.name)}
        kind = argv[argv.index('--crate-type') + 1]
        out = PurePosixPath(argv[argv.index('--out-dir') + 1]).relative_to(root)
        if kind == 'lib':
            suffix, = [v.split('=', 1)[1] for v in argv if v.startswith('extra-filename=')]
            path = out / ('lib' + crate + suffix + '.rmeta')
            device, inode, _, mode, _, size = paths[path]
            need(stat.S_ISREG(mode) and size > 0, 'emitted library rmeta')
            matching = {p.parent.parent for p, rec in paths.items() if p.name == 'metadata.rmeta' and
                        p.parent.parent in candidates and p.parent in dirs and not p.parent.name.endswith('-working') and
                        (rec[0], rec[1]) == (device, inode)}
            proof = {'method': 'returned rmeta inode', 'device': device, 'inode': inode, 'extra_filename': suffix}
        else:
            need(kind == 'bin' and crate == 'ruff' and binary is not None, 'unexpected binary owner')
            path = out / crate
            need(stat.S_ISREG(paths[path][3]) and paths[path][5] > 0, 'emitted binary')
            matching = {p for p in candidates if int(p.name.rsplit('-', 1)[1], 36) == binary['stable_crate_id']}
            proof = {'method': 'defined v0 Rust main stable crate ID', **binary}
        need(len(matching) == 1, ('no unique owner of compiler output', str(path)))
        owner, = matching
        sessions = {str(p) for p in dirs if p.parent == owner and p.name.startswith('s-') and not p.name.endswith('-working')}
        need(sessions, 'no finalized producing session')
        result[str(row['pid'])] = {'flag': inc, 'crate': crate, 'owner': str(owner), 'producer': {
            'crate_type': kind, 'output': str(path), 'proof': proof}, 'sessions': sessions}
    return result


def verify(z, prefix, root, binary, role, manifest):
    ledger = read(z, prefix, 'path-inodes.json.gz')
    physical = read(z, prefix, 'native-execs.json.gz')
    expected = owners(ledger, physical, root, binary)
    witness = read(z, prefix, 'incremental-owners.json')
    need(witness.keys() == expected.keys(), 'missing compiler owner witness')
    tables = ('dep-graph.bin', 'query-cache.bin')
    counts = {'raw': 0, 'packed': 0}
    version = manifest['compiler_verbose'].splitlines()[0].removeprefix('rustc ')
    for pid, exp in expected.items():
        got = witness[pid]
        need(all(got[k] == exp[k] for k in ('flag', 'crate', 'owner', 'producer')) and
             got['role'] == role and got['source'] == manifest['roles'][role]['commit'] and
             got['driver_sha256'] == manifest['files'][role][manifest['driver']][0], 'wrong physical rustc owner')
        items = got['current_or_prior_complete_sessions']
        need(len(items) == len(exp['sessions']) and {i['session'] for i in items} == exp['sessions'], 'missing session')
        for item in items:
            session = item['session']
            end = session + '/'
            files = {p[len(end):]: v for p, v in ledger.items() if p.startswith(end) and '/' not in p[len(end):]}
            packed = any('ohm-packed-' + name in files for name in tables)
            label = 'packed' if packed else 'raw'
            need(item['representation'] == label and item['compiler'] == version and
                 item['work_products'][0] == files['work-products.bin'][5] > 0 and
                 re.fullmatch('[0-9a-f]{64}', item['work_products'][1]) and stat.S_ISREG(files['work-products.bin'][3]),
                 'wrong work-product index or representation')
            for name, tag in zip(tables, ('G', 'Q')):
                record = item['tables'][name]
                stored = 'ohm-packed-' + name if packed else name
                need(stat.S_ISREG(files[stored][3]) and record['bytes'] > 0 and
                     re.fullmatch('[0-9a-f]{64}', record['sha256']), 'table signature')
                if packed:
                    need(not any(alias + name in files for alias in ('', 'ohm-build-', 'ohm-check-')) and
                         record['stored_bytes'] == files[stored][5] and record['session_prefix'] ==
                         PurePosixPath(session).name.rsplit('-', 1)[0] and record['tag'] == tag and
                         record['aliases'] in (1, 3, 5, 7) and re.fullmatch('[0-9a-f]{64}', record['stored_sha256']),
                         'incomplete encoded table or session label')
                else:
                    need(record['bytes'] == files[stored][5], 'raw table bytes')
            objects = sum(n.endswith('.o') for n in files)
            packed_objects = sum(bool(re.fullmatch(r'ohm-packed-object-[0-9a-z]+\.o-blake3=[0-9a-f]{64}', n)) for n in files)
            need(item['objects'] == objects and item['packed_objects'] == packed_objects and objects + packed_objects > 0,
                 'missing retained objects')
            counts[label] += 1
    return {'actual_rustcs': len(expected), 'sessions': counts}
