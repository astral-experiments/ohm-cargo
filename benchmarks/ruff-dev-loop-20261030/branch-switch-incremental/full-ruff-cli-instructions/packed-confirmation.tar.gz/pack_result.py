"""Package original-byte projections, guards, raw outcomes and the independently reproducible decision."""
from pathlib import Path
import gzip, hashlib, io, os, shutil, subprocess, sys, tarfile, tempfile

HERE = Path(__file__).resolve().parent
def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    target=Path(sys.argv[1]).resolve()
    if target.exists(): raise ValueError('output archive already exists')
    keys=['README.md','READER-SHA256','registration.json','runs.json','report.py','pack_result.py',
          'confirm.py','custody.py','position.py','hardware.py','scoring.py','test_reader.py','pilot_exercise.py',
          'stream_positions.py','test_stream.py']
    keys += [p.relative_to(HERE).as_posix() for p in (HERE/'original').iterdir() if p.is_file()]
    for c in ('c1','c2'):
        keys += ['results/'+c+'-catalog.json','results/'+c+'-raw.json']
    keys += ['results/decision.json','results/pilot-fixtures-hardware.json','results/logic-tests.txt',
             'results/stream-tests.txt','results/all-phases.tsv','results/RESULTS.md']
    source={k:(HERE/k).read_bytes() for k in sorted(keys)}
    source['CONTENTS.sha256']=''.join(digest(v)+'  '+k+'\n' for k,v in source.items()).encode()
    with target.open('xb') as b, gzip.GzipFile(mode='wb',fileobj=b,filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
            for n,data in sorted(source.items()):
                entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o644;entry.mtime=0
                tar.addfile(entry,io.BytesIO(data))
    with tempfile.TemporaryDirectory(prefix='ohm-24-position-review-') as td:
        reopened=Path(td)
        with tarfile.open(target,'r:gz') as tar:
            files=tar.getmembers();assert len(files)==len(source) and all(f.isfile() and f.name in source for f in files)
            for f in files:
                data=tar.extractfile(f).read(); assert data==source[f.name]
                out=reopened/f.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
        for args,where in [(['sha256sum','--check','--status','CONTENTS.sha256'],reopened),
                           (['sha256sum','--check','--status','READER-SHA256'],reopened),
                           (['sha256sum','--check','--status','SOURCE-SHA256'],reopened/'original'),
                           ([sys.executable,'-IB','test_reader.py'],reopened),
                           ([sys.executable,'-IB','test_stream.py'],reopened),
                           ([sys.executable,'-IB','confirm.py','score','results/c1-raw.json','results/c2-raw.json',
                             '--out','scratch-decision.json'],reopened)]:
            subprocess.run(args,cwd=where,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert (reopened/'scratch-decision.json').read_bytes()==source['results/decision.json']
        out=reopened/'rendered';out.mkdir()
        subprocess.run([sys.executable,'-IB','report.py',reopened/'results',out],cwd=reopened,check=True)
        for name in ('all-phases.tsv','RESULTS.md'):
            assert (out/name).read_bytes()==source['results/'+name]
    print(digest(target.read_bytes()),target.stat().st_size,len(source),target)
if __name__=='__main__':main()
