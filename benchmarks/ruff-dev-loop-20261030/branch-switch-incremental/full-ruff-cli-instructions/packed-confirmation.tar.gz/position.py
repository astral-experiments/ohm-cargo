"""Position replay adapted from frozen pilot 41217046302; original is retained byte-for-byte."""
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent / "original"))
import independent_reader as original
from replay_metrics import COMMAND, REVS, VISITS, need, sha
from replay_native import raw, read, native_verdict
from hardware import verify as hardware

def unmetered(z, phase, arm, branch, env, measured):
    prefix = f"ordinary/{arm}/{phase}"
    twin = f"measured/{arm}/{phase}"
    command = read(z, prefix, "cargo.json.gz")
    need(command["observer_argv"] is None and command["expected"] == command["exit"] ==
         (101 if phase == "invalid" else 0) and command["env"] == env and command["stdin_sha256"] == sha(b"")
         and prefix + "/clock.json" not in z.NameToInfo, "ordinary command has a wrapper or counter")
    need(read(z, prefix, "source.json") == read(z, twin, "source.json"), "ordinary source differs")
    data, diag = (raw(z, prefix, "cargo." + s + ".gz") for s in ("stdout", "stderr"))
    roster = original.cargo_messages(data, diag, command, command["exit"], command["cwd"])
    disk, total = original.storage(z, prefix)
    own = read(z, prefix, "visit.json")
    other = read(z, twin, "visit.json")
    need(own["allocated"] == total and own["instructions"] is None and
         {k:v for k,v in own.items() if k not in ("instructions", "allocated")} ==
         {k:v for k,v in other.items() if k not in ("instructions", "allocated")}, "ordinary receipt")
    if phase == "invalid":
        need(roster is None and sorted(read(z, prefix, "working.json")) == disk["failed_sessions"], "failed history")
    else:
        need(roster == read(z, prefix, "roster.json.gz") == measured["roster"] and
             native_verdict(z, prefix, branch) == measured["native"] and not disk["failed_sessions"],
             "unmetered whole-ELF behavior or typed roster")
    return total


def host(z, pos, inputs, parser_digests, spec):
    en = json.loads(z.read("enrollment.json"))
    order = spec["orders"][pos]
    need((en["run"], en["head"], en["attempt"], en["position"], en["order"], en["command"]) ==
         (spec["run"], spec["head"], 1, pos, order, COMMAND) and en["plan"] == spec["plan"] == sha(z.read("PLAN.md")), "registration")
    complete = json.loads(z.read("complete.json"))
    need(complete["host_complete"] is True and complete["raw_counts_unscaled"] is True and
         complete["arms"] == order and complete["phases"] == list(VISITS) and
         "failure.txt" not in z.NameToInfo and json.loads(z.read("ruff-inputs.json")) == inputs, "whole acquisition")
    if spec["cohort"] == "pilot":
        need("cohort" not in en and "cohort" not in complete, "pilot/confirmation mix")
    else:
        need(en["cohort"] == complete["cohort"] == spec["cohort"] and complete["position"] == pos
             and en["pilot_run"] == 41217046302, "wrong cohort or pilot")
    need(complete["requires_independent_cross_host_replay"] is True, "terminal replay flag")
    sdk = original.sdk(z, en)
    source = json.loads(z.read("source-kit.json"))
    need(en["source"] == source and source["run"] == 41199659076 and
         source["manifest"] == "c29e2e57626491804d9c24e5fa50a709015a002067a3bf39e884d8b6ef0fea43",
         "source-built SDK binding")
    control = original.replay_settled.binding(z)
    calibration = original.calibration(z, en["boot"])
    ready = json.loads(z.read("meter-ready.json"))
    need(ready["boot"] == en["boot"] and ready["affinity"] == sorted(calibration["affinity"])
         and ready["plain"].endswith("/observers/plain") and ready["observer"] == calibration["observer"]
         and ready["calibrator"] == calibration["calibrator"], "meter admission does not bind to real calibration")
    scope = hardware(z, calibration, ready)
    terminal = read(z, "sdk", "terminal.json")
    need(terminal["both_complete_byte_and_inode_inventories_unchanged"] is True and
         terminal["registry"] == sha((json.dumps(inputs["archives"], sort_keys=True, separators=(",",":")) + "\n").encode()),
         "terminal SDK/registry identities")
    envs, clean, bodies, checked, rows, providers = {}, {}, {}, {}, {}, {}
    for arm in order:
        env = original.active(z, "clean/" + arm, arm, sdk, source["manifest"])
        envs[arm] = env
        for branch in REVS:
            ref = original.visit(z, f"clean/{arm}/{branch}", arm, branch, "cold-"+branch, env, parser_digests, "clean")
            clean[arm,branch] = ref
            for name in ("cli", "reader"):
                desc = ref["native"][name]
                digest = desc["whole"]
                need(bodies.setdefault(digest, desc) == desc, "inconsistent clean ELF")
                if digest not in checked:
                    checked[digest] = original.replay_elf.verify(z, "native-bodies/"+digest+".zst", desc,
                                                                  "ruff" if name == "cli" else None)
        providers[arm] = original.native_provider(z, arm)
    left, right = (envs[a] for a in ("Koff", "Kon"))
    need(left == {k:v for k,v in right.items() if k != "CARGO_ENCODED_RUSTFLAGS"}, "unequal arm environments")
    for branch in REVS:
        a, b = (clean[arm,branch] for arm in ("Koff", "Kon"))
        need(a["roster"]["members"] == b["roster"]["members"] and
             all(a["native"][k] == b["native"][k] for k in ("typed","cli_cases","fstring_cases")) and
             all(a["native"][k][s] == b["native"][k][s] for k in ("cli","reader") for s in ("executable","loads")),
             "clean equivalence across arms")
    rosters = {}
    previous_stop = 0
    for arm in order:
        env = envs[arm]
        rows[arm] = {}
        for lane in ("measured", "ordinary"):
            slot = lane+"/"+arm
            need(original.active(z, slot, arm, sdk, source["manifest"]) == env, "changed environment")
            watched = read(z, slot+"/return-B", "watched-git-files.json")
            need(watched == read(z, slot+"/unchanged-B","watched-git-files.json") and
                 set(watched) == {"HEAD","refs/heads/historical-feature"}, "truly unchanged Git state")
            grace = read(z, slot+"/repair","failed-session-grace.json")
            need(grace["sessions"] == read(z, slot+"/invalid", "working.json") and
                 all(grace["ready_ns"] >= s["created_ns"] + 11_000_000_000 for s in grace["sessions"].values()),
                 "failed-state ownership and grace")
        for phase in VISITS:
            branch = "A" if phase in ("cold-A", "return-A") else "B"
            measured = original.visit(z, f"measured/{arm}/{phase}", arm, branch, phase, env, parser_digests, "measured")
            if phase != "invalid":
                ref = clean[arm, branch]
                need(measured["native"] == ref["native"] and measured["roster"]["members"] == ref["roster"]["members"]
                     and measured["native_output"] == ref["native_output"], ("full own-empty products",arm,phase))
                need(rosters.setdefault(phase, measured["roster"]) == measured["roster"],
                     ("both arms report the same work",phase))
                if phase == "unchanged-B":
                    dirty = measured["roster"]["dirty"]
                    need(len(dirty)==1 and dirty[0]["name"]=="ruff" and dirty[0]["kind"]==["bin"], "settled roster")
            outside = unmetered(z, phase, arm, branch, env, measured)
            raw_count = measured["raw_clock"]
            need(set(raw_count) == {"start","stop","user_us","system_us","instructions","enabled","running","event_errno","code"}
                 and all(type(v) is int for v in raw_count.values()) and
                 previous_stop <= raw_count["start"] < raw_count["stop"] and raw_count["user_us"] + raw_count["system_us"] > 0,
                 ("ordered native observations", pos, arm, phase))
            previous_stop = raw_count["stop"]
            rows[arm][phase] = dict(instructions=measured["instructions"], allocated=measured["allocated"],
                                    unmetered_allocated=outside, raw_clock=raw_count,
                                    allocation=read(z, f"measured/{arm}/{phase}", "storage.json"),
                                    dirty=None if phase == "invalid" else len(measured["roster"]["dirty"]),
                                    cargo_exit=raw_count["code"])
    storage_mode = z.read("storage-mode.txt").decode().strip()
    need(storage_mode in {"private-ext4", "runner-filesystem"}, "unknown storage backend")
    refs = {arm: {b: {k: clean[arm,b]["native"][k]["whole"] for k in ("cli","reader")}
                      | {"typed":clean[arm,b]["native"]["typed"]} for b in REVS} for arm in order}
    return dict(calibration=calibration, hardware_scope=scope, native_controls=providers, clean=refs,
                sha256_witness={p: sha(z.read(p)) for p in ("enrollment.json","complete.json","meter-ready.json",
                    "host.json","observer.json","calibration/admitted.json","sdk/terminal.json","ruff-inputs.json")},
                boot=en["boot"], runner=en["runner"], order=order, cpu=calibration["cpu"], pmu=calibration["pmu"],
                storage_mode=storage_mode, filesystem=z.read("filesystem.txt").decode().strip(),
                source_manifest=source["manifest"], bodies=checked, native_binding=control, arms=rows)

