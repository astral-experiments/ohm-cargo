"""Positive raw ZIPs and independently injected raw negative controls, never a confirmation sample."""
import gzip, hashlib, io, json, sys, tempfile
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import position
from position import original
import read_packed_ordinary as pilot
from replay_metrics import need, measured_count
from replay_native import raw, read, native_verdict

class Substitute:
    def __init__(self, z, replacements):
        self.z, self.replacements = z, replacements
    def __getattr__(self, name):
        return getattr(self.z, name)
    def read(self, name, *args):
        key = name if isinstance(name,str) else name.filename
        return self.replacements[key] if key in self.replacements else self.z.read(name,*args)
    def open(self, name, *args):
        return io.BytesIO(self.replacements[name]) if name in self.replacements else self.z.open(name,*args)

def must_reject(assertion, fn):
    try:
        fn()
    except (ValueError, AssertionError) as e:
        need(assertion in str(e), ("wrong rejection", assertion, str(e)))
        return str(e)
    raise ValueError("false acceptance: "+assertion)

def test_original(z, result, parser):
    prefix = "measured/Kon/return-A"
    invalid = "measured/Kon/invalid"
    env = read(z,"measured/Kon","arm.json")["env"]
    native = gzip.compress(b"Expr=56 valid=1 rejected\n")
    typed = must_reject("typed parser client", lambda: native_verdict(
        Substitute(z,{prefix+"/reader-run.stdout.gz":native}),prefix,"A"))
    clock = read(z,prefix,"clock.json") | {"event_errno": 13}
    refused = must_reject("PMU failure", lambda: measured_count(clock,0))
    clock = read(z,prefix,"clock.json") | {"running":1}
    multiplexed = must_reject("scheduling coverage", lambda: measured_count(clock,0))
    cmds = read(z,invalid,"cargo.json.gz")
    data = [json.loads(line) for line in raw(z,invalid,"cargo.stdout.gz").splitlines()]
    found = False
    for e in data:
        msg=e.get("message")
        if isinstance(msg,dict) and (msg.get("code") or {}).get("code")=="E0308":
            msg["code"]["code"]="E0999"; found=True
    need(found,"original diagnostic must exist")
    body=b"".join(json.dumps(d).encode()+b"\n" for d in data)
    altered=Substitute(z,{invalid+"/cargo.stdout.gz":gzip.compress(body),
        invalid+"/cargo.json.gz":gzip.compress(json.dumps(cmds|{"stdout_sha256":hashlib.sha256(body).hexdigest()}).encode())})
    wrong_error=must_reject("deliberately wrong parser function",lambda:original.visit(altered,invalid,"Kon","B","invalid",env,parser,"measured"))
    archive="providers/Kon/provider-Kon/returned-A/witness.stdout.gz"
    stale=must_reject("wrong archive",lambda: original.native_provider(Substitute(z,{archive:gzip.compress(b"17 1\n")}),"Kon"))
    desc=read(z,prefix,"native.json.gz")["reader"]
    # Change only the claimed physical executable section. The originally compressed bytes still verify.
    forged=json.loads(json.dumps(desc)); forged["executable"][".text"]["sha256"]="0"*64
    text=must_reject("ELF program loads",lambda:original.replay_elf.verify(z,"native-bodies/"+desc["whole"]+".zst",forged,None))
    c=read(z,prefix,"storage.json"); modified=c|{"allocated":c["allocated"]+512}
    disk=must_reject("allocated against", lambda:original.storage(Substitute(z,{prefix+"/storage.json":json.dumps(modified).encode()}), prefix))
    return dict(stale_typed_reader=typed,PMU_failure=refused,PMU_multiplex=multiplexed,
                forged_but_rehashed_wrong_diagnostic=wrong_error,stale_native_archive=stale,
                changed_executable_section=text,changed_disk=disk)
def main():
    tempfile.tempdir="/dev/shm"
    known=json.loads((HERE/"original/pilot-reference.json").read_bytes())
    controls=pilot.catalog()
    need(controls==known["artifacts"],"signed pilot subjects")
    inputs,parser=original.corpus.source()
    rows={}
    spec={"run":pilot.RUN,"head":pilot.HEAD,"plan":pilot.PLAN,"cohort":"pilot","orders":pilot.ORDER}
    for pos,meta in controls.items():
        print("Reopening excluded pilot "+pos,file=sys.stderr,flush=True)
        with pilot.archive(meta) as z:
            row=position.host(z,pos,inputs,parser,spec); previous=known["hosts"][pos]
            for field in ("boot","bodies","native_binding","order","cpu","pmu","source_manifest"):
                need(row[field]==previous[field],("pilot comparable records",field))
            for arm in row["order"]:
                for phase, detail in row["arms"][arm].items():
                    previous_row=previous["arms"][arm][phase]
                    need(all(detail[k]==previous_row[k] for k in ("allocated","instructions","unmetered_allocated"))
                         and all(detail["raw_clock"][k]==previous_row[k] for k in ("enabled","running")),
                         ("pilot exact original count and allocation",pos,arm,phase))
            rows[pos] = dict(boot=row["boot"],artifact=meta,matched_existing_14_clocks=True,
                             calibration=row["calibration"],negative=test_original(z,row,parser) if pos=="01" else None)
    print(json.dumps(dict(run=pilot.RUN,excluded=True,positions=rows),indent=2,sort_keys=True))
if __name__=="__main__": main()
