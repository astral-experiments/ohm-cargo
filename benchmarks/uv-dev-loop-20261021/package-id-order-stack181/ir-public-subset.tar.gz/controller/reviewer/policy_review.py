"""Independent decision policy; no controller imports or statistical calculations."""
import math
from evidence import need


def decide(phase, completed):
    need(phase in {'ir', 'native'}, 'unplanned policy phase')
    need(len(completed) == 2 and tuple(row['workflow'] for row in completed) == ('check', 'test'), 'policy workflow order differs')
    by_name, regressions = {}, []
    for row in completed:
        need(isinstance(row['passes_gate'], bool), 'gate result is not boolean')
        interval, p = row['interval_99'], row['sign_p']
        need(len(interval) == 2 and all(math.isfinite(value) for value in interval)
             and interval[0] <= interval[1] and math.isfinite(p) and 0 <= p <= 1, 'invalid gate evidence')
        by_name[row['workflow']] = row['passes_gate']
        if interval[-1] < 0 and p <= 0.01:
            regressions.append(row['workflow'])
    qualifies = not regressions if phase == 'native' else by_name['check'] and 'test' not in regressions
    return {'rule': 'no-established-native-regression' if phase == 'native' else 'primary-check-ir',
            'qualifies': qualifies, 'primary_workflow': 'check',
            'primary_gate_passed': by_name['check'], 'secondary_gate_passed': by_name['test'],
            'established_regressions': regressions,
            'improvement_claims': {name: qualifies and by_name[name] for name in ('check', 'test')}}
