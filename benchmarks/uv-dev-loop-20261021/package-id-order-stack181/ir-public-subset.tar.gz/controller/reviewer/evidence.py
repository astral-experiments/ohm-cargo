"""Independent local input/transport checks; never imports experiment controls."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath
import tarfile

ROOT = '/tmp/ohm-hillclimb-20261021/package-id-order-stack181'
HOST = 'charlie-oss'
FREEZE = SEAL = DELIVERY = DRIVER = None
APPROVAL = None
CORE = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'
REPEATED = '50547460e030aa73e1f48121bf477cf8f4a4538bf1bb577851af54176750b6d3'
PROTOCOL = '86eed951e351e0d7a96575c4a27035ec2c28675bce8793e5588202c0496f1b3b'
UV = '3d82a6ad5a7eab8c68236553b7846517767c4b61'
EXPECTED = None
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '12f12327e7c56fb04386b7cfb4d61d5fd434bfc5'}
NAMES = {'baseline': 'package-id-order-stack181-baseline', 'candidate': 'package-id-order-stack181-reduced'}
STAGES = {
    'ir': {'pairs': 12, 'phase': 'confirmation', 'warming_order': ['baseline', 'candidate'],
           'plan': [['check', 20261021141], ['test', 20261021142]]},
    'native': {'pairs': 30, 'phase': 'confirmation', 'warming_order': ['baseline', 'candidate'],
               'plan': [['check', 20261021143], ['test', 20261021144]]},
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def relative(name):
    need(isinstance(name, str), 'path is not a string')
    path = PurePosixPath(name)
    need(name and name != '.' and not path.is_absolute() and '..' not in path.parts
         and '\\' not in name and str(path) == name, 'unsafe path: ' + repr(name))
    return path


def configure(controls, expected_seal):
    """Bind future real identities from root-reviewed inputs, never placeholders."""
    global FREEZE, SEAL, DELIVERY, DRIVER, EXPECTED, APPROVAL
    controls = Path(controls).resolve()
    need(controls == Path(__file__).resolve().parents[1], 'review controls are outside this frozen package')
    need(isinstance(expected_seal, str) and len(expected_seal) == 64
         and set(expected_seal) <= set('0123456789abcdef') and expected_seal != '0' * 64, 'unbound measurement seal')
    FREEZE, SEAL = sha(controls / 'source-freeze.json'), expected_seal
    source = read(controls / 'source-freeze.json')
    for name, digest in source['files'].items():
        need(sha(controls / relative(name)) == digest, 'frozen control source changed')
    reviewed = read(controls / 'source-review.json')
    need(reviewed['status'] == 'passed' and reviewed['source_freeze_sha256'] == FREEZE, 'source review not bound')
    APPROVAL = read(controls / 'input-approval.json')
    need(APPROVAL['status'] == 'passed' and APPROVAL['scope'] == 'package-id-order-production-inputs'
         and APPROVAL['source_freeze_sha256'] == FREEZE and APPROVAL['protocol_sha256'] == PROTOCOL
         and APPROVAL['root'] == ROOT and APPROVAL['host'] == HOST and APPROVAL['source_trees'] == TREES
         and APPROVAL['source_parent_commit'] == 'd81a093becb4321a975522624c2a383970f0d164'
         and APPROVAL['candidate_patch_sha256'] == 'bdaf1930258f5b92f3235e0d3375934c324c156304a39204effceb33cebac575'
         and APPROVAL['root_correctness_review_sha256'] == '8da35b84c488c97fd68eab717d0537c1920ee2e2b4ede0727bd0eab483a8bb6b'
         and APPROVAL['correctness_seal_sha256'] == 'e4c82bea38975ff0a1c4a97ed8157237152ee502d5ed3c15da81e60ac299e238'
         and 'source_commit' not in APPROVAL and 'source_ci_sha256' not in APPROVAL, 'input approval differs')
    need(APPROVAL['controller_path'] == ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin', 'controller PATH differs')
    EXPECTED = APPROVAL['variants']
    need(set(EXPECTED) == {'baseline', 'candidate'} and len(set(EXPECTED.values())) == 2, 'production pair is incomplete')
    for value in EXPECTED.values():
        need(isinstance(value, str) and len(value) == 64 and set(value) <= set('0123456789abcdef')
             and value != '0' * 64, 'unbound production binary')
    delivery = read(controls / 'delivery/delivery.json')
    binding = read(controls / 'delivery/binding.json')
    DELIVERY = sha(controls / 'delivery/delivery.json')
    DRIVER = source['files']['driver.py']
    need(binding['delivery_sha256'] == DELIVERY and delivery['source_freeze_sha256'] == FREEZE
         and delivery['variants'] == EXPECTED and delivery['source_trees'] == TREES, 'delivery identity differs')
    need(delivery['files']['controller/input-approval.json'] == sha(controls / 'input-approval.json')
         and delivery['files']['controller/driver.py'] == DRIVER, 'input approval/driver transport differs')
    return FREEZE, SEAL, EXPECTED


def translated_reference(value):
    if isinstance(value, str):
        return value.replace('/tmp/ohm-hillclimb-20261021-inheritance-measurement', ROOT).replace(
            'inheritance-stack180-baseline', 'package-id-order-stack181-baseline').replace(
            'inheritance-stack180-shared', 'package-id-order-stack181-reduced')
    if isinstance(value, list):
        return [translated_reference(item) for item in value]
    if isinstance(value, dict):
        return {key: translated_reference(item) for key, item in value.items()}
    return value


class Evidence:
    def __init__(self, controls, phase):
        self.controls = Path(controls).resolve()
        self.phase = phase
        self.directory = self.controls / 'collections' / phase
        self.remote = self.directory / 'remote'
        freeze_path = self.controls / 'source-freeze.json'
        need(sha(freeze_path) == FREEZE, 'PackageId-ordering source freeze changed')
        self.freeze = read(freeze_path)
        for name, digest in self.freeze['files'].items():
            need(sha(self.controls / relative(name)) == digest, 'local frozen control changed: ' + name)
        source_review = read(self.controls / 'source-review.json')
        need(source_review['status'] == 'passed' and source_review['source_freeze_sha256'] == FREEZE, 'source review binding differs')
        transport, receipt = read(self.directory / 'transport.json'), read(self.directory / 'receipt.json')
        self.manifest = read(self.directory / 'transfer-manifest.json')
        need(transport['returncode'] == 0 and receipt['status'] == 'passed', 'collection transport is incomplete')
        need(sha(self.directory / 'payload.tar') == transport['archive_sha256']
             and sha(self.directory / 'transfer.stderr') == transport['stderr_sha256'], 'transport bytes differ')
        need(sha(self.directory / 'transfer-manifest.json') == receipt['transfer_manifest_sha256'], 'transfer manifest differs')
        need(self.manifest['phase'] == receipt['phase'] == phase and self.manifest['root'] == ROOT, 'collection phase/root differs')
        need(self.manifest['seal_sha256'] == receipt['measurement_seal_sha256'] == SEAL
             and self.manifest['delivery_sha256'] == DELIVERY and self.manifest['driver_sha256'] == DRIVER, 'collection identities differ')
        self.files = self.manifest['files']
        seen = set()
        with tarfile.open(self.directory / 'payload.tar', 'r:') as archive:
            for member in archive:
                relative(member.name)
                need(member.isfile() and not member.issym() and not member.islnk()
                     and member.name not in seen, 'unsafe/duplicate archive member')
                seen.add(member.name)
                if member.name == 'transfer-manifest.json':
                    need(archive.extractfile(member).read() == (self.directory / member.name).read_bytes(), 'archived manifest differs')
                    continue
                need(member.name.startswith('remote/'), 'unexpected archive prefix')
                name = member.name[len('remote/'):]
                need(name in self.files, 'unexpected remote member')
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as source:
                    while chunk := source.read(1024 * 1024):
                        digest.update(chunk)
                        size += len(chunk)
                path = self.remote / relative(name)
                need(path.is_file() and not path.is_symlink() and path.resolve() == path, 'noncanonical extracted file')
                need(digest.hexdigest() == self.files[name] == sha(path)
                     and size == member.size == path.stat().st_size, 'archive/extracted bytes differ: ' + name)
        need(seen == {'transfer-manifest.json'} | {'remote/' + name for name in self.files}, 'archive member set differs')
        actual = set()
        for path in self.remote.rglob('*'):
            need(not path.is_symlink(), 'symlink in extracted evidence')
            if path.is_file():
                actual.add(str(path.relative_to(self.remote)))
        need(actual == set(self.files) and len(actual) == receipt['files'], 'extracted member set/count differs')
        self.seal = self.json('controller/measurement-seal.json')
        self.assets = self.json('controller/assets.json')
        self.setup = self.json('metadata/setup.json')
        self.binding = read(self.controls / 'delivery/binding.json')

    def json(self, name):
        return read(self.remote / relative(name))

    def file(self, remote):
        need(isinstance(remote, str) and remote.startswith(ROOT + '/'), 'file path is outside fixed root')
        name = str(relative(remote[len(ROOT) + 1:]))
        need(name in self.files, 'missing collected raw file: ' + name)
        return self.remote / name

    def native_approval(self, ir_review):
        from policy_review import decide
        prefix = 'metadata/native-approval/'
        manifest = self.json(prefix + 'manifest.json')
        required = {'root-approval.json', 'review/review.json', 'review/raw-integrity.json',
            'review/check-reproduced-analysis.json', 'review/test-reproduced-analysis.json',
            'review/source-freeze.json', 'collection/transfer-manifest.json', 'collection/receipt.json'}
        need(set(manifest['files']) == required, 'native approval payload membership differs')
        need(manifest['root'] == ROOT and manifest['host'] == HOST
             and manifest['source_freeze_sha256'] == FREEZE and manifest['measurement_seal_sha256'] == SEAL
             and manifest['variants'] == EXPECTED, 'native approval cohort differs')
        need(manifest['controller_path'] == self.setup['controller_path'], 'native approval PATH differs')
        for name, digest in manifest['files'].items():
            need(self.files[prefix + name] == digest, 'native approval payload bytes differ')
        reviewer_freeze = self.files['controller/reviewer/source-freeze.json']
        need(manifest['reviewer_source_freeze_sha256'] == reviewer_freeze
             == manifest['files']['review/source-freeze.json'], 'accepted reviewer source differs')
        accepted = self.json(prefix + 'root-approval.json')
        need(accepted['status'] == 'passed' and accepted['scope'] == 'package-id-order-independent-ir-acceptance'
             and accepted['source_freeze_sha256'] == FREEZE and accepted['measurement_seal_sha256'] == SEAL
             and accepted['variants'] == EXPECTED and accepted['reviewer_source_freeze_sha256'] == reviewer_freeze,
             'root IR acceptance differs')
        for name, field in [('review/review.json', 'review_sha256'), ('review/raw-integrity.json', 'raw_integrity_sha256'),
                            ('collection/transfer-manifest.json', 'transfer_manifest_sha256'),
                            ('collection/receipt.json', 'collection_receipt_sha256')]:
            need(accepted[field] == manifest['files'][name], 'root IR acceptance payload differs')
        need(sha(ir_review) == manifest['files']['review/review.json'], 'native uses a different independent IR review')
        ir = read(ir_review)
        need(ir['policy'] == decide('ir', ir['completed']) and ir['policy']['qualifies'], 'accepted IR primary policy differs')
        need(ir['review_source_freeze_sha256'] == reviewer_freeze
             and ir['launch_receipt_sha256'] == accepted['launch_receipt_sha256'], 'accepted IR source/launch differs')
        transfer = self.json(prefix + 'collection/transfer-manifest.json')
        need(transfer['files'] == ir['raw_file_sha256'], 'accepted IR raw file map differs')
        receipt = self.json(prefix + 'collection/receipt.json')
        need(receipt['status'] == 'passed' and receipt['phase'] == 'ir'
             and receipt['measurement_seal_sha256'] == SEAL
             and receipt['transfer_manifest_sha256'] == ir['transfer_manifest_sha256'], 'accepted IR collection differs')
        return {ROOT + '/' + prefix + name for name in required | {'manifest.json'}}

    def bind(self):
        need(sha(self.remote / 'controller/source-freeze.json') == FREEZE
             and sha(self.remote / 'controller/measurement-seal.json') == SEAL
             and sha(self.remote / 'delivery.json') == DELIVERY, 'copied control identity differs')
        need(self.binding['delivery_sha256'] == DELIVERY and self.binding['variants'] == EXPECTED
             and self.binding['source_trees'] == TREES, 'delivery binding differs')
        need(self.assets['root'] == ROOT and self.assets['host'] == HOST
             and self.assets['variants'] == self.seal['variants'] == EXPECTED
             and self.assets['source_trees'] == self.seal['source_trees'] == TREES
             and self.seal['stages'] == STAGES, 'fixed source/binary/stage identity differs')
        need(self.seal['uv']['commit'] == UV and not self.seal['uv']['status'], 'uv identity differs')
        need(self.setup['state'] == 'prepared-without-warming' and self.setup['host'] == HOST
             and self.setup['root'] == ROOT and self.setup['uv_commit'] == UV, 'setup identity differs')
        need(self.setup['configuration_catalog'] == self.seal['configuration_catalog'], 'configuration catalog differs')
        need(self.setup['controller_path'] == ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin'
             and self.setup['controller_affinity'] == [8], 'controller environment differs')
        need(self.files['controller/input-approval.json'] == sha(self.controls / 'input-approval.json'), 'input approval differs')
        need(self.seal['environment_guard'] == {'forbidden_environment_names': [],
             'absent_system_configurations': ['/etc/_rjem_malloc.conf', '/etc/malloc.conf']}, 'allocator/loader policy differs')
        need(self.setup['known_global_configuration'] == {
            'path': '/.cargo/config.toml', 'sha256': '24095bd6315880162c8f660917100ac36638cb73778dd9ec6f1c9026ea87b178',
            'evidence_copy': 'metadata/ancestor-root-config.toml'}, 'global Cargo configuration differs')
        need(sha(self.remote / 'metadata/ancestor-root-config.toml') == self.setup['known_global_configuration']['sha256'], 'global config evidence bytes differ')
        for name, digest in self.assets['files'].items():
            if name in self.files:
                need(self.files[name] == digest, 'copied asset differs: ' + name)
        for name, digest in self.seal['file_sha256'].items():
            if name.startswith(ROOT + '/') and name[len(ROOT) + 1:] in self.files:
                need(self.files[name[len(ROOT) + 1:]] == digest, 'copied sealed input differs: ' + name)
        for name, digest in self.freeze['files'].items():
            need(self.files['controller/' + name] == digest, 'delivered frozen control differs')
        for name, digest in {'controller/driver.py': DRIVER, 'controller/protocol.json': PROTOCOL,
                             'benchmark/frozen/paired.py': CORE, 'benchmark/frozen/paired_repeated.py': REPEATED}.items():
            need(self.files[name] == digest, 'measurement control differs')
        protocol = self.json('controller/protocol.json')
        need(protocol['source']['base_tree'] == TREES['baseline']
             and protocol['source']['final_tested_source_tree'] == TREES['candidate']
             and protocol['workload']['uv_commit'] == UV, 'protocol source/runtime identity differs')
        gate = {'minimum_reduction_percent': 1, 'bootstrap_confidence': 0.99,
                'positive_lower_bound': True, 'exact_two_sided_sign_p_max': 0.01,
                'both_randomized_orders_positive': True}
        need(protocol['ir']['primary_gate'] == protocol['native']['wall_time_gate'] == gate, 'protocol gate thresholds differ')
        need(protocol['ir']['order'] == protocol['native']['order'] == ['check', 'test']
             and protocol['ir']['measured_pairs_per_workflow'] == 12 and protocol['native']['measured_pairs_per_workflow'] == 30
             and protocol['ir']['warmup_pairs_per_workflow'] == protocol['native']['warmup_pairs_per_workflow'] == 2
             and protocol['ir']['calls_per_variant'] == 1 and protocol['native']['calls_per_variant_group'] == 8,
             'protocol sample units/counts/order differ')
        need(protocol['ir']['primary'] == 'check' and protocol['ir']['secondary'] == 'test'
             and protocol['ir']['secondary_claim_requires_own_full_gate'] is True
             and protocol['ir']['secondary_established_regression_blocks'] is True
             and protocol['native']['any_established_regression_blocks'] is True, 'primary/regression policy differs')
        need(protocol['statistics']['bootstrap_resamples'] == 20000 and protocol['statistics']['bootstrap_seed'] == 1701
             and protocol['statistics']['paired_log_ratios'] is True
             and protocol['statistics']['linear_quantile_before_exponentiation'] is True
             and protocol['statistics']['exact_two_sided_binomial_sign_test'] is True, 'statistical method differs')
        from proof_review import production, correctness
        production(self, APPROVAL, NAMES, TREES)
        need(self.files['controller/host-assignment.json'] == APPROVAL['host_assignment_sha256']
             == '68ed7921aa5cc28db7e61d566ce7d6872b488dcd2dd9a9103d6252820303037d', 'host assignment differs')
        assignment = self.json('controller/host-assignment.json')
        need(assignment['host'] == HOST and assignment['root'] == ROOT
             and assignment['protocol_sha256'] == PROTOCOL and assignment['production_must_finish_before_admission'], 'host amendment scope differs')
        need(self.files['controller/references/root-plan-review.json'] == APPROVAL['root_plan_review_sha256']
             == 'e90e92ef4d4df43294370a83cc07556ebc648003afcde525a6273d9176d53517', 'accepted adaptation plan differs')
        correctness(self, APPROVAL, TREES)
        need(protocol['correctness']['full_exact_source_ci_required_before_pr'] is True
             and protocol['correctness']['github_source_upload_only_after_private_performance_qualification'] is True,
             'mandatory post-qualification exact-source CI requirement differs')

    def config(self, phase, workflow):
        label = phase + '-' + workflow
        config = self.json('benchmark/' + label + '.json')
        base = self.json('controller/base-configs/' + label + '.json')
        inherited = translated_reference(self.json('controller/references/base-configs/' + label + '.json'))
        need({k: v for k, v in base.items() if k not in ('record_files', 'env')}
             == {k: v for k, v in inherited.items() if k not in ('record_files', 'env')}, 'inherited workload changed')
        need(set(inherited['env']) <= set(base['env'])
             and all(base['env'][k] == v for k, v in inherited['env'].items())
             and all(v is None for k, v in base['env'].items() if k not in inherited['env']), 'inherited environment changed')
        need(base['record_files'][:len(inherited['record_files'])] == inherited['record_files']
             and len(base['record_files']) == len(set(base['record_files'])), 'inherited input prefix changed')
        need({k: v for k, v in config.items() if k != 'record_files'}
             == {k: v for k, v in base.items() if k != 'record_files'}, 'base workload fields changed')
        extra = [ROOT + '/' + name for name in self.assets['files']]
        extra += [ROOT + '/controller/assets.json', ROOT + '/controller/measurement-seal.json',
                  ROOT + '/benchmark/' + label + '.json', ROOT + '/metadata/' + label + '-preflight/report.json']
        if phase == 'native':
            extra.append(ROOT + '/metadata/native-prerequisite.json')
        need(config['record_files'] == list(dict.fromkeys(base['record_files'] + extra)), 'record_files is not the exact base expansion')
        canonical = ROOT + '/active/bin/cargo'
        native_command = ['/usr/bin/taskset', '-c', '0-7', '{cargo}', '-Zohm-defaults=yes', workflow]
        if workflow == 'test':
            native_command.append('--no-run')
        native_command += ['--locked', '--offline', '-j', '8']
        need(config['cwd'] == ROOT + '/uv' and config['canonical_executable'] == canonical
             and config['prepare_command'] == native_command, 'canonical path or build-only workload differs')
        need(config['variants'] == {key: ROOT + '/controller/binaries/cargo-' + value for key, value in NAMES.items()}, 'variant paths differ')
        for key, suffix in [('CARGO_HOME', 'cargo-home'), ('CARGO_TARGET_DIR', 'targets/' + label),
                            ('CARGO_BUILD_BUILD_DIR', 'shared-cache/' + label)]:
            need(config['env'][key] == ROOT + '/' + suffix, 'fixture path differs')
        need(all(value is None for key, value in config['env'].items()
                 if key.startswith(('LD_', 'DYLD_', 'MALLOC', '_RJEM_', 'JEMALLOC')) or key == 'GLIBC_TUNABLES'), 'native loader/allocator override')
        if phase == 'native':
            need(config['command'] == native_command and config['repetitions'] == 8
                 and config['repeatable_workload'] == 'noop' and 'metric_files' not in config, 'native design differs')
        else:
            prefix = ['/usr/bin/taskset', '-c', '0-7', '/usr/bin/env',
                      'LD_PRELOAD=' + ROOT + '/profiling-tools/ohm-valgrind-env.so',
                      'OHM_BENCH_NORMALIZE_VALGRIND_ENV=1', ROOT + '/profiling-tools/valgrind/usr/bin/valgrind',
                      '--tool=callgrind', '--trace-children=no',
                      '--extra-debuginfo-path=' + ROOT + '/profiling-tools/valgrind/usr/lib/debug',
                      '--callgrind-out-file={output}/callgrind-{stage}-{pair}-{variant}.out']
            need(config['command'] == prefix + native_command[3:] and 'repetitions' not in config
                 and config['metric_files'] == {'cargo_ir': {'format': 'callgrind', 'event': 'Ir',
                      'path': '{output}/callgrind-{stage}-{pair}-{variant}.out'}}, 'Cargo-only instruction command differs')
        return config
