"""Independent local-production and semantic-test evidence checks; no controls imports."""
import hashlib
import json
import re


def production(evidence, approval, names, trees):
    from evidence import need
    prefix = 'controller/cohort/production/'
    audit_name = prefix + 'execution/audit.json'
    build_name = prefix + 'execution/build-result.json'
    terminal_name = prefix + 'status-local-package-id-order-stack181.json'
    provenance_name = prefix + 'provenance-local-package-id-order-stack181.json'
    review_name = 'controller/cohort/root-pair-review.json'
    audit, launch, terminal, provenance, accepted = (evidence.json(name) for name in (
        audit_name, build_name, terminal_name, provenance_name, review_name))
    need(accepted['status'] == 'passed' and accepted['scope'] == 'package-id-order-local-production-pair'
         and isinstance(accepted['checks'], dict) and accepted['checks']
         and all(type(value) is bool and value for value in accepted['checks'].values()), 'root pair review is not accepted')
    for name, field in ((audit_name, 'pair_audit_sha256'), (build_name, 'build_result_sha256'),
                        (terminal_name, 'production_terminal_status_sha256')):
        need(evidence.files[name] == accepted[field] == approval[field], 'root production receipt join differs: ' + field)
    need(evidence.files[review_name] == approval['pair_review_sha256'] == '456503fc0768cc6d861175bd7426c164815838eb4e982e44d1b5570b3993d536', 'root production acceptance bytes differ')
    need(approval['variants'] == {'baseline': '293864b23abd5a24689406f318346eaadce9938d046dbee26b8c324ae0f786bd', 'candidate': 'e22423d41d9560885d7208dcb1a8bf50d08fcd0b6cbbd961a7de954877fa0305'}, 'actual accepted production binaries differ')
    need(accepted['binaries'] == {name: approval['variants'][role] for role, name in names.items()}, 'root production binary map differs')
    need(audit['phase'] == 'audit' and audit['state'] == 'passed'
         and audit['no_compiler_or_workload_execution'] is True and audit['no_performance_claim'] is True,
         'local production artifact audit did not pass')
    need(launch['state'] == 'complete' and launch['returncode'] == 0 and launch['producer_started'] is True,
         'local production process did not complete successfully')
    need(terminal['state'] == 'complete' and terminal['completed_variants'] == list(names.values()), 'production order/count differs')
    need(audit['build_result_sha256'] == evidence.files[build_name]
         and audit['terminal_status_sha256'] == launch['terminal_status_sha256'] == evidence.files[terminal_name]
         and audit['provenance_sha256'] == evidence.files[provenance_name], 'local audit raw joins differ')
    need(provenance['host'] == 'charlie-oss' and provenance['cohort'] == 'local-package-id-order-stack181', 'production origin differs')
    need(provenance['execution_environment_sha256'] == launch['expected_build_execution_environment_sha256'], 'production inherited environment differs')
    selected = {key: provenance[key] for key in ('compiler_input_sha256', 'native_build_tool_sha256',
        'inherited_cargo_configuration_sha256', 'execution_environment_sha256', 'command', 'environment')}
    common = hashlib.sha256(json.dumps(selected, sort_keys=True).encode()).hexdigest()
    need(audit['common_build_inputs_sha256'] == provenance['common_build_inputs_sha256'] == approval['common_build_inputs_sha256'] == common,
         'production common input digest differs')
    manifest_name = 'controller/cohort/proposal/frozen/manifest.json'
    manifest = evidence.json(manifest_name)
    need(evidence.files[manifest_name] == audit['production_manifest_sha256'] == approval['production_manifest_sha256']
         == 'e962473998edd4a49c5c82dd914c5be55ae1181d9be2cbad2edc38a861f89022', 'production manifest differs')
    need(audit['production_driver_sha256'] == provenance['driver_sha256'] == manifest['driver_sha256'] == approval['production_driver_sha256']
         == 'c5734a2a75d146dc4571aaff94683504af7a785dbee91cccd7493dbb25e76b17', 'production driver differs')
    need(evidence.files[prefix + 'build_driver_local_package_id_order_stack181.py'] == audit['production_driver_sha256'], 'delivered producer source differs')
    need(provenance['expected_variant_source_trees'] == {name: trees[role] for role, name in names.items()}, 'production source map differs')
    need([row['variant'] for row in audit['records']] == list(names.values()), 'production audit record order differs')
    builds = evidence.json(prefix + 'binaries/manifest.json')
    need(set(builds) == {'cargo-' + name for name in names.values()}, 'binary manifest membership differs')
    members = {name for variant in names.values() for name in (
        'binaries/cargo-' + variant, 'binaries/stripped/cargo-' + variant, 'binaries/stripped/cargo-' + variant + '.json',
        'logs/' + variant + '.stdout', 'logs/' + variant + '.stderr', 'logs/' + variant + '.source.patch',
        'logs/' + variant + '.occupancy.json')}
    need(set(terminal['sealed_artifact_sha256']) == members, 'fourteen production artifact members differ')
    for name, digest in terminal['sealed_artifact_sha256'].items():
        if name.startswith('logs/') or name.endswith('.json'):
            need(evidence.files[prefix + name] == digest, 'sealed production metadata differs')
    for name, digest in provenance['preserved_artifact_sha256'].items():
        need(evidence.files[prefix + name] == digest, 'preserved production input differs')
    need(terminal['preserved_artifacts_verified'] == len(provenance['preserved_artifact_sha256']) == 8, 'preserved production inputs incomplete')
    for role, name in names.items():
        row = next(item for item in audit['records'] if item['variant'] == name)
        build = builds['cargo-' + name]
        strip = evidence.json(prefix + 'binaries/stripped/cargo-' + name + '.json')
        source = manifest['expected_variants'][name]
        need(row['source_tree'] == build['observed_source_tree'] == build['expected_source_tree_from_patches'] == source['tree'] == trees[role],
             'effective production source differs')
        need(build['embedded_source_commit'] == '5e5d271d763d7beb38b48755e22bd59e93f02b97'
             and build['upstream_patch_commit'] == 'd81a093becb4321a975522624c2a383970f0d164', 'production embedded/parent Git identities differ')
        need(row['stripped_sha256'] == strip['stripped_sha256'] == audit['binaries'][name] == approval['variants'][role]
             == evidence.assets['files']['controller/binaries/cargo-' + name], 'measured stripped binary differs')
        need(row['original_linker_output_sha256'] == build['original_linker_output_sha256'] == strip['source_sha256'] == strip['original_linker_output_sha256'],
             'original linker output identity differs')
        need(terminal['sealed_artifact_sha256']['binaries/cargo-' + name] == strip['source_sha256']
             and terminal['sealed_artifact_sha256']['binaries/stripped/cargo-' + name] == strip['stripped_sha256'], 'sealed binary identities differ')
        need(row['verified_allocated_sections'] == len(strip['allocated_sections']) == 31
             and build['bytes'] == strip['source_bytes'], 'strip proof differs')
        need(build['common_build_inputs_sha256'] == common and build['patch_sha256'] == source['patch_sha256'], 'per-variant build inputs differ')
        need(evidence.files[prefix + 'logs/' + name + '.source.patch'] == build['observed_diff_sha256'] == source['canonical_diff_sha256'], 'full source patch differs')
        for suffix in ('stdout', 'stderr'):
            need(evidence.files[prefix + 'logs/' + name + '.' + suffix] == build[suffix + '_sha256'], 'compiler log binding differs')
        need(evidence.json(prefix + 'logs/' + name + '.occupancy.json')['other_workloads'] == [], 'production was not quiet')
    need(audit['records'][0]['actual_rustc_settings'] == audit['records'][1]['actual_rustc_settings']
         and audit['records'][0]['version'] == audit['records'][1]['version'], 'library/CLI settings, dependencies or versions differ')


def correctness(evidence, approval, trees):
    from evidence import need, relative
    prefix = 'controller/correctness/'
    seal = evidence.json(prefix + 'seal.json')
    accepted = evidence.json(prefix + 'root-correctness-review.json')
    receipt = evidence.json(prefix + 'attempt-01/receipt.json')
    summary = evidence.json(prefix + 'correctness-summary.json')
    need(evidence.files[prefix + 'seal.json'] == approval['correctness_seal_sha256']
         == accepted['correctness_seal_sha256'] == 'e4c82bea38975ff0a1c4a97ed8157237152ee502d5ed3c15da81e60ac299e238',
         'semantic validation seal differs')
    need(evidence.files[prefix + 'root-correctness-review.json'] == approval['root_correctness_review_sha256']
         == '8da35b84c488c97fd68eab717d0537c1920ee2e2b4ede0727bd0eab483a8bb6b', 'root correctness acceptance differs')
    need(seal['status'] == accepted['status'] == receipt['status'] == summary['status'] == 'passed', 'semantic tests or acceptance failed')
    need(accepted['scope'] == 'package-id-order-final-source-and-focused-correctness', 'incorrect source acceptance scope')
    need(accepted['baseline_commit'] == receipt['baseline_commit'] == summary['baseline_commit'] == approval['source_parent_commit']
         and receipt['baseline_tree'] == summary['baseline_tree'] == trees['baseline'], 'tested baseline differs')
    need(accepted['candidate_tree'] == seal['source_tree'] == trees['candidate']
         and accepted['candidate_patch_sha256'] == approval['candidate_patch_sha256'], 'tested candidate identity differs')
    need(len(seal['files']) == 67, 'semantic evidence membership differs')
    for name, identity in seal['files'].items():
        relative(name)
        need(evidence.files[prefix + name] == identity['sha256']
             and (evidence.remote / (prefix + name)).stat().st_size == identity['bytes'], 'semantic evidence bytes differ')
    need(evidence.files[prefix + 'attempt-01/receipt.json'] == accepted['attempt_receipt_sha256']
         and evidence.files[prefix + 'correctness-summary.json'] == accepted['summary_sha256'], 'actual test attempt/summary joins differ')
    need(receipt['final_source'] == summary['final_source']
         and receipt['final_source']['tree'] == trees['candidate']
         and receipt['final_source']['patch_sha256'] == approval['candidate_patch_sha256']
         == evidence.files[prefix + 'attempt-01/final.patch'], 'tested full source patch differs')
    need(receipt['final_source']['files']['src/workspace/package_id.rs'] == accepted['candidate_file_sha256']
         == evidence.files[prefix + 'attempt-01/after-format-package_id.rs'], 'actual tested PackageId source differs')
    need(seal['external_test_executable'] == accepted['test_executable'] == receipt['test_executable'] == summary['test_executable'],
         'real Cargo library test executable identity differs')
    need(len(receipt['commands']) == 27 and all(row['returncode'] == 0 for row in receipt['commands']), 'correctness attempt did not fully pass')
    need(accepted['focused_tests'] == {'package_id_passed': 9, 'source_id_passed': 4, 'failed': 0, 'ignored': 0}
         and receipt['total_passed'] == summary['total_passed'] == 13
         and summary['total_failed'] == summary['total_ignored'] == 0, 'semantic test counts differ')
    command_prefix = ['/usr/bin/taskset', '-c', '0-7',
        '/home/dev-user/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/cargo',
        'test', '--locked', '--offline', '-p', 'cargo', '--lib', '-j', '8']
    build = next(row for row in receipt['commands'] if row['label'] == 'build-library')
    need(build['argv'] == command_prefix + ['--no-run', '--message-format=json'], 'actual library build command differs')
    for label, namespace, count, stem in (
        ('run-package-id', 'workspace::package_id::tests::', 9, '21-run-package-id'),
        ('run-source-id', 'workspace::source_id::tests::', 4, '23-run-source-id')):
        command = next(row for row in receipt['commands'] if row['label'] == label)
        need(command['argv'] == command_prefix + [namespace, '--', '--nocapture', '--test-threads=1'], 'actual semantic test command differs')
        for suffix in ('stdout', 'stderr'):
            need(evidence.files[prefix + 'attempt-01/' + stem + '.' + suffix] == command[suffix + '_sha256'], 'semantic test stream differs')
        output = (evidence.remote / (prefix + 'attempt-01/' + stem + '.stdout')).read_text()
        observed = re.findall(r'^test (.+) \.\.\. ok$', output, re.M)
        need(len(observed) == len(set(observed)) == count and all(name.startswith(namespace) for name in observed), 'semantic test names/count differ')
        need(re.search(r'^test result: ok\. ' + str(count) + r' passed; 0 failed; 0 ignored;', output, re.M), 'semantic result line differs')
        need(receipt['tests'][namespace] == summary['test_results'][namespace]
             == {'executed': observed, 'passed': count, 'failed': 0, 'ignored': 0}, 'semantic test receipt differs from raw output')
