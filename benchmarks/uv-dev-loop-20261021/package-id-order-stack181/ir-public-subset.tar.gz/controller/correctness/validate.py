#!/usr/bin/env python3
"""Bounded real Cargo library correctness validation; no performance measurements."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PROPOSAL = ROOT / 'work/package-id-order-candidate'
SOURCE = ROOT / 'work/cargo-package-id-order'
ORIGIN = ROOT / 'work/cargo-scheduler-bitsets'
TARGET = PROPOSAL / 'compiler-build'
SOURCE_PATH = 'src/workspace/package_id.rs'
BASE = 'd81a093becb4321a975522624c2a383970f0d164'
BASE_TREE = 'c4178b67e0b3a64a12b9b58f84b97323b99d734e'
EXPECTED_PROPOSAL = '1b861440d84af4103b2687730124da41d158dcd536ddfe550809f79c60c70e61'
ATTEMPT = OUT / 'attempt-01'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    temporary = Path(str(path) + '.tmp')
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    temporary.replace(path)


def save():
    write_json(ATTEMPT / 'receipt.json', record)


def run(label, argv, *, cwd=OUT, env=None, timeout=1800):
    index = len(record['commands']) + 1
    stdout_path = ATTEMPT / f'{index:02}-{label}.stdout'
    stderr_path = ATTEMPT / f'{index:02}-{label}.stderr'
    entry = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(cwd),
             'started_at': now(), 'stdout': str(stdout_path), 'stderr': str(stderr_path), 'status': 'running'}
    record['commands'].append(entry)
    save()
    try:
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            result = subprocess.run(entry['argv'], cwd=cwd, env=env, stdout=stdout, stderr=stderr,
                                    timeout=timeout)
        entry.update(returncode=result.returncode, status='passed' if result.returncode == 0 else 'failed')
        result.check_returncode()
    except BaseException as error:
        entry.update(status='failed', error=repr(error))
        raise
    finally:
        entry.update(finished_at=now())
        for key, path in [('stdout_sha256', stdout_path), ('stderr_sha256', stderr_path)]:
            if path.exists():
                entry[key] = sha(path)
        save()
    return stdout_path.read_bytes()


def git(label, *args, cwd=SOURCE):
    return run(label, ['/usr/bin/git', '--no-optional-locks', *args], cwd=cwd, env=control_env)


def check_proposal():
    assert sha(PROPOSAL / 'manifest.json') == EXPECTED_PROPOSAL
    manifest = json.loads((PROPOSAL / 'manifest.json').read_text())
    for name, row in manifest['files'].items():
        assert sha(PROPOSAL / name) == row['sha256'], name
    return {name: row['sha256'] for name, row in manifest['files'].items()}


assert set(os.sched_getaffinity(0)) == {8}
assert SOURCE.parent.resolve() == ROOT / 'work'
assert not SOURCE.exists() and not SOURCE.is_symlink()
assert not TARGET.exists() and not TARGET.is_symlink()
assert not ATTEMPT.exists()
root_review = json.loads((OUT / 'root-source-review.json').read_text())
assert root_review['candidate_manifest_sha256'] == EXPECTED_PROPOSAL
assert root_review['baseline_commit'] == BASE and root_review['baseline_tree'] == BASE_TREE
assert root_review['expected_tests'] == {'package_id': 9, 'source_id': 4}
proposal_files = check_proposal()
plan = json.loads((PROPOSAL / 'validation-plan.json').read_text())
assert plan['proposed_cwd'] == str(SOURCE) and plan['proposed_target'] == str(TARGET)
assert plan['controller_affinity'] == [8] and plan['workload_affinity'] == list(range(8))
formatter_reference = ROOT / 'work/scheduler-bitsets-candidate/focused-attempt04/receipt.json'
formatter_record = json.loads(formatter_reference.read_text())
assert formatter_record['status'] == 'passed'
formatter = formatter_record['rustfmt']
assert formatter['path'] == '/home/dev-user/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt'
assert sha(formatter['path']) == formatter['sha256']
tools = plan['toolchain_tools']
tool_hashes = {name: sha(path) for name, path in tools.items()}
assert tool_hashes == plan['historical_tool_sha256_to_reverify_before_execution']
ATTEMPT.mkdir()
control_env = os.environ.copy()
control_env['PATH'] = '/usr/bin:/bin'
record = {'started_at': now(), 'status': 'preparing', 'purpose': 'Private focused Cargo library correctness; no performance data.',
          'runner_sha256': sha(__file__), 'root_review_sha256': sha(OUT / 'root-source-review.json'),
          'proposal_manifest_sha256': EXPECTED_PROPOSAL, 'proposal_files': proposal_files,
          'baseline_commit': BASE, 'baseline_tree': BASE_TREE,
          'source_path': str(SOURCE), 'target_path': str(TARGET), 'controller_affinity': sorted(os.sched_getaffinity(0)),
          'tool_paths': tools, 'tool_sha256': tool_hashes, 'formatter': formatter,
          'formatter_reference_sha256': sha(formatter_reference), 'commands': [],
          'instructions': {'tracked_AGENTS_at_baseline': [], 'applicable_workspace_ancestor_AGENTS': [],
                           'instruction_search': 'Read-only ancestor checks and immutable baseline tree scan before setup found none.'}}
save()
try:
    # An exclusive empty directory prevents replacing a concurrently created checkout.
    SOURCE.mkdir()
    source_stat = SOURCE.stat()
    ownership = {'task': 'ohm-package-id-order-correctness', 'created_at': now(),
                 'root': str(SOURCE), 'uid': os.getuid(), 'device': source_stat.st_dev, 'inode': source_stat.st_ino}
    write_json(ATTEMPT / 'source-ownership.json', ownership)
    git('clone-local-shared-objects', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(ORIGIN), str(SOURCE), cwd=OUT)
    assert (SOURCE.stat().st_dev, SOURCE.stat().st_ino, SOURCE.stat().st_uid) == (source_stat.st_dev, source_stat.st_ino, os.getuid())
    assert (SOURCE / '.git').is_dir() and not (SOURCE / '.git').is_symlink()
    write_json(SOURCE / '.git/ohm-correctness-owner.json', ownership)
    git('checkout-exact-baseline', 'checkout', '--detach', BASE)
    assert git('baseline-head', 'rev-parse', 'HEAD').decode().strip() == BASE
    assert git('baseline-tree', 'rev-parse', 'HEAD^{tree}').decode().strip() == BASE_TREE
    assert not git('baseline-status', 'status', '--porcelain=v1', '--untracked-files=all').strip()
    git('check-reviewed-patch', 'apply', '--check', str(PROPOSAL / 'candidate.patch'))
    git('apply-reviewed-patch', 'apply', str(PROPOSAL / 'candidate.patch'))
    assert (SOURCE / SOURCE_PATH).read_bytes() == (PROPOSAL / 'package_id.rs').read_bytes()
    before_format = (SOURCE / SOURCE_PATH).read_bytes()
    (ATTEMPT / 'before-format-package_id.rs').write_bytes(before_format)
    record['formatter']['version'] = run('formatter-version', [formatter['path'], '--version'], env=control_env).decode()
    run('format-changed-file-only', [formatter['path'], '--edition', '2024', str(SOURCE / SOURCE_PATH)], env=control_env)
    after_format = (SOURCE / SOURCE_PATH).read_bytes()
    (ATTEMPT / 'after-format-package_id.rs').write_bytes(after_format)
    assert before_format.split(b'#[cfg(test)]')[0] == after_format.split(b'#[cfg(test)]')[0], 'formatter changed approved production bytes'
    formatting_diff = ''.join(difflib.unified_diff(before_format.decode().splitlines(True), after_format.decode().splitlines(True),
                                                  fromfile='reviewed/' + SOURCE_PATH, tofile='formatted/' + SOURCE_PATH))
    (ATTEMPT / 'formatting-only.patch').write_text(formatting_diff)
    record['formatting_revision'] = {'before_sha256': hashlib.sha256(before_format).hexdigest(),
                                     'after_sha256': hashlib.sha256(after_format).hexdigest(),
                                     'diff_sha256': sha(ATTEMPT / 'formatting-only.patch'),
                                     'production_prefix_unchanged': True, 'formatter_is_pinned_prior_trusted_binary': True}
    git('diff-whitespace-check', 'diff', '--check')
    assert git('changed-files', 'diff', '--name-only').decode().splitlines() == [SOURCE_PATH]
    assert not git('untracked-source-files', 'ls-files', '--others', '--exclude-standard').strip()
    git('stage-only-changed-file', 'add', '--', SOURCE_PATH)
    tree = git('final-source-tree', 'write-tree').decode().strip()
    final_patch = git('final-source-patch', 'diff', '--cached', '--binary', '--full-index', BASE)
    (ATTEMPT / 'final.patch').write_bytes(final_patch)
    final_inputs = {name: sha(SOURCE / name) for name in json.loads((PROPOSAL / 'source.json').read_text())['baseline_source']}
    for name, expected in json.loads((PROPOSAL / 'source.json').read_text())['baseline_source'].items():
        if name != SOURCE_PATH:
            assert final_inputs[name] == expected['sha256'], name
    record['final_source'] = {'tree': tree, 'patch_sha256': sha(ATTEMPT / 'final.patch'), 'files': final_inputs}
    env = os.environ.copy()
    removed = []
    for name in list(env):
        if name.startswith(tuple(plan['environment_remove_prefixes'])) or name in plan['environment_remove_names']:
            removed.append(name)
            del env[name]
    env.update(plan['environment_overrides'])
    env['PATH'] = str(Path(tools['rustc']).parent) + os.pathsep + env.get('PATH', '')
    record['environment'] = {'removed_keys': sorted(removed), 'overrides': {**plan['environment_overrides'], 'PATH': env['PATH']},
                             'taskset_resolved_explicitly_to': '/usr/bin/taskset'}
    for name, path in tools.items():
        version_args = ['--version'] if name == 'rustdoc' else ['-vV']
        record.setdefault('tool_versions', {})[name] = run(name + '-version', [path, *version_args], env=env).decode()
    TARGET.mkdir()
    record['target_initial_state'] = 'new empty task-owned directory; no copied compiler artifacts'
    record['status'] = 'building'
    save()
    print(json.dumps({'status': 'building', 'source_tree': tree, 'source_sha256': final_inputs[SOURCE_PATH],
                      'patch_sha256': record['final_source']['patch_sha256']}, indent=2), flush=True)
    for index, item in enumerate(plan['commands']):
        argv = list(item['argv'])
        assert argv[:3] == ['taskset', '-c', '0-7'] and argv[3] == tools['cargo']
        argv[0] = '/usr/bin/taskset'
        label = ['build-library', 'list-package-id', 'run-package-id', 'list-source-id', 'run-source-id'][index]
        output = run(label, argv, cwd=SOURCE, env=env)
        if index == 0:
            events = [json.loads(line) for line in output.decode().splitlines() if line.startswith('{')]
            harnesses = [row['executable'] for row in events
                         if row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == 'cargo'
                         and row.get('target', {}).get('kind') == ['lib'] and row.get('profile', {}).get('test')
                         and row.get('executable')]
            assert len(harnesses) == 1
            harness = Path(harnesses[0])
            assert harness.is_file() and TARGET.resolve() in harness.resolve().parents
            record['test_executable'] = {'path': str(harness), 'sha256': sha(harness), 'bytes': harness.stat().st_size}
            record['status'] = 'testing'
        else:
            group = 'workspace::package_id::tests::' if index in [1, 2] else 'workspace::source_id::tests::'
            expected = set(plan['expected_tests'][group])
            text = output.decode()
            if index in [1, 3]:
                selected = [line[:-6] for line in text.splitlines() if line.endswith(': test')]
                assert len(selected) == len(expected) and set(selected) == expected, (group, selected)
                record.setdefault('lists', {})[group] = selected
            else:
                executed = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
                counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
                assert len(executed) == len(expected) and set(executed) == expected, (group, executed)
                assert counts == [(str(len(expected)), '0', '0')], (group, counts)
                record.setdefault('tests', {})[group] = {'executed': executed, 'passed': len(expected), 'failed': 0, 'ignored': 0}
        save()
    assert not git('final-worktree-diff', 'diff', '--name-only').strip()
    assert git('final-staged-patch', 'diff', '--cached', '--binary', '--full-index', BASE) == final_patch
    assert git('final-tree-readback', 'write-tree').decode().strip() == tree
    assert not git('final-untracked-files', 'ls-files', '--others', '--exclude-standard').strip()
    assert check_proposal() == proposal_files
    assert {name: sha(SOURCE / name) for name in final_inputs} == final_inputs
    assert {name: sha(path) for name, path in tools.items()} == tool_hashes
    assert sha(formatter['path']) == formatter['sha256']
    assert sha(record['test_executable']['path']) == record['test_executable']['sha256']
    record.update(status='passed', finished_at=now(), source_and_tools_unchanged=True, proposal_unchanged=True,
                  total_passed=sum(row['passed'] for row in record['tests'].values()))
    save()
    print(json.dumps({'status': record['status'], 'tests_passed': record['total_passed'], 'source_tree': tree,
                      'test_executable': record['test_executable']}, indent=2), flush=True)
except BaseException as error:
    record.update(status='failed', error=repr(error), finished_at=now())
    save()
    raise
