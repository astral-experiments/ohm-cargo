"""Exact local-production schema joins; reads bytes and never launches a command."""
import hashlib
import json
from pathlib import Path
import re

PRODUCTION_ROOT = Path('/tmp/ohm-hillclimb-20261021-package-id-order-production')
COHORT = 'local-package-id-order-stack181'
NAMES = {'baseline': 'package-id-order-stack181-baseline', 'candidate': 'package-id-order-stack181-reduced'}
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '12f12327e7c56fb04386b7cfb4d61d5fd434bfc5'}
PARENT = 'd81a093becb4321a975522624c2a383970f0d164'
PINNED = '5e5d271d763d7beb38b48755e22bd59e93f02b97'
MANIFEST = 'e962473998edd4a49c5c82dd914c5be55ae1181d9be2cbad2edc38a861f89022'
DRIVER = 'c5734a2a75d146dc4571aaff94683504af7a785dbee91cccd7493dbb25e76b17'
DRIVER_NAME = 'build_driver_local_package_id_order_stack181.py'
ACCEPTED_PAIR_REVIEW_SHA = '456503fc0768cc6d861175bd7426c164815838eb4e982e44d1b5570b3993d536'
ACCEPTED_VARIANTS = {'baseline': '293864b23abd5a24689406f318346eaadce9938d046dbee26b8c324ae0f786bd', 'candidate': 'e22423d41d9560885d7208dcb1a8bf50d08fcd0b6cbbd961a7de954877fa0305'}


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def digest(value):
    assert isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) and value != '0' * 64
    return value


def validate_root_review(value, audit_sha, variants, build_sha, terminal_sha):
    assert value['status'] == 'passed' and value['scope'] == 'package-id-order-local-production-pair'
    assert isinstance(value['checks'], dict) and value['checks']
    assert all(type(item) is bool and item for item in value['checks'].values())
    assert value['pair_audit_sha256'] == digest(audit_sha)
    assert value['build_result_sha256'] == digest(build_sha)
    assert value['production_terminal_status_sha256'] == digest(terminal_sha)
    assert set(variants) == {'baseline', 'candidate'} and len(set(variants.values())) == 2
    assert value['binaries'] == {name: digest(variants[role]) for role, name in NAMES.items()}
    return value


def validate_production(production, proposal, root_review, binaries, expected=None):
    """Same checks for the original root and byte-identical delivered evidence copies."""
    production, proposal, root_review = Path(production), Path(proposal), Path(root_review)
    assert set(binaries) == set(NAMES)
    assert sha(root_review) == ACCEPTED_PAIR_REVIEW_SHA
    assert expected is None or expected == ACCEPTED_VARIANTS
    manifest_path = proposal / 'frozen/manifest.json'
    assert sha(manifest_path) == MANIFEST
    manifest, recipe = read(manifest_path), read(proposal / 'proposal.json')
    audit_path = production / 'execution/audit.json'
    build_path = production / 'execution/build-result.json'
    status_path = production / ('status-' + COHORT + '.json')
    provenance_path = production / ('provenance-' + COHORT + '.json')
    audit, launch, terminal, provenance = map(read, (audit_path, build_path, status_path, provenance_path))
    assert audit['phase'] == 'audit' and audit['state'] == 'passed'
    assert audit['no_compiler_or_workload_execution'] is True and audit['no_performance_claim'] is True
    assert launch['phase'] == 'build' and launch['state'] == 'complete'
    assert launch['returncode'] == 0 and launch['producer_started'] is True
    assert terminal['state'] == 'complete' and terminal['completed_variants'] == list(NAMES.values())
    assert launch['argv'] == recipe['future_driver_argv'] and launch['cwd'] == str(PRODUCTION_ROOT)
    assert audit['build_result_sha256'] == sha(build_path)
    assert audit['terminal_status_sha256'] == launch['terminal_status_sha256'] == sha(status_path)
    assert audit['provenance_sha256'] == sha(provenance_path)
    assert audit['production_manifest_sha256'] == MANIFEST
    assert audit['production_driver_sha256'] == provenance['driver_sha256'] == manifest['driver_sha256'] == DRIVER
    assert sha(production / DRIVER_NAME) == sha(proposal / 'frozen' / DRIVER_NAME) == DRIVER
    assert audit['proposal_source_freeze_sha256'] == sha(proposal / 'source-freeze.json')
    assert provenance['host'] == 'charlie-oss' and provenance['cohort'] == COHORT
    assert provenance['source'] == str(PRODUCTION_ROOT / 'source') and provenance['target'] == str(PRODUCTION_ROOT / 'target')
    assert provenance['source_commit'] == PINNED
    assert provenance['command'] == recipe['build_argv']
    assert provenance['execution_environment_sha256'] == launch['expected_build_execution_environment_sha256']
    common = {key: provenance[key] for key in ('compiler_input_sha256', 'native_build_tool_sha256',
        'inherited_cargo_configuration_sha256', 'execution_environment_sha256', 'command', 'environment')}
    common_sha = hashlib.sha256(json.dumps(common, sort_keys=True).encode()).hexdigest()
    assert audit['common_build_inputs_sha256'] == provenance['common_build_inputs_sha256'] == common_sha
    assert manifest['actual_upstream_parent_commit'] == PARENT
    assert manifest['actual_upstream_parent_tree'] == TREES['baseline']
    assert provenance['expected_variant_source_trees'] == {name: TREES[role] for role, name in NAMES.items()}
    assert provenance['patch_sha256'] == manifest['patch_sha256']
    for name, value in manifest['patch_sha256'].items():
        assert sha(proposal / 'frozen' / name) == sha(production / name) == value
    for name, value in provenance['preserved_artifact_sha256'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha(production / name) == value
    assert terminal['preserved_artifacts_verified'] == len(provenance['preserved_artifact_sha256']) == 8
    expected_members = {name for variant in NAMES.values() for name in (
        'binaries/cargo-' + variant, 'binaries/stripped/cargo-' + variant, 'binaries/stripped/cargo-' + variant + '.json',
        'logs/' + variant + '.stdout', 'logs/' + variant + '.stderr', 'logs/' + variant + '.source.patch',
        'logs/' + variant + '.occupancy.json')}
    assert set(terminal['sealed_artifact_sha256']) == expected_members
    for name, value in terminal['sealed_artifact_sha256'].items():
        if name.startswith('logs/') or name.endswith('.json'):
            assert sha(production / name) == value
    for suffix in ('stdout', 'stderr'):
        assert launch[suffix] == str(PRODUCTION_ROOT / 'logs' / (COHORT + '.driver.' + suffix))
        assert sha(production / 'logs' / (COHORT + '.driver.' + suffix)) == launch[suffix + '_sha256']
    assert launch['stage_receipt_sha256'] == sha(production / 'execution/stage-receipt.json')
    builds = read(production / 'binaries/manifest.json')
    assert set(builds) == {'cargo-' + name for name in NAMES.values()}
    assert [row['variant'] for row in audit['records']] == list(NAMES.values())
    actual = {}
    for role, name in NAMES.items():
        row = next(row for row in audit['records'] if row['variant'] == name)
        build = builds['cargo-' + name]
        strip_path = production / 'binaries/stripped' / ('cargo-' + name + '.json')
        strip = read(strip_path)
        expected_source = manifest['expected_variants'][name]
        assert row['source_tree'] == build['observed_source_tree'] == build['expected_source_tree_from_patches'] == expected_source['tree'] == TREES[role]
        assert build['embedded_source_commit'] == PINNED and build['upstream_patch_commit'] == PARENT
        assert build['common_build_inputs_sha256'] == common_sha and build['patch_sha256'] == expected_source['patch_sha256']
        assert build['original_linker_output_sha256'] == row['original_linker_output_sha256'] == strip['source_sha256'] == strip['original_linker_output_sha256']
        assert terminal['sealed_artifact_sha256']['binaries/cargo-' + name] == strip['source_sha256']
        actual[role] = sha(binaries[role])
        assert actual[role] == strip['stripped_sha256'] == row['stripped_sha256'] == audit['binaries'][name]
        assert terminal['sealed_artifact_sha256']['binaries/stripped/cargo-' + name] == actual[role]
        assert Path(binaries[role]).stat().st_size == strip['stripped_bytes']
        assert build['bytes'] == strip['source_bytes'] and row['verified_allocated_sections'] == len(strip['allocated_sections']) == 31
        assert sha(production / 'logs' / (name + '.source.patch')) == build['observed_diff_sha256'] == expected_source['canonical_diff_sha256']
        for suffix in ('stdout', 'stderr'):
            assert sha(production / 'logs' / (name + '.' + suffix)) == build[suffix + '_sha256']
        assert read(production / 'logs' / (name + '.occupancy.json'))['other_workloads'] == []
    assert audit['binaries'] == {name: actual[role] for role, name in NAMES.items()}
    assert audit['records'][0]['actual_rustc_settings'] == audit['records'][1]['actual_rustc_settings']
    assert audit['records'][0]['version'] == audit['records'][1]['version']
    assert actual == ACCEPTED_VARIANTS
    if expected is not None:
        assert actual == expected
    validate_root_review(read(root_review), sha(audit_path), actual, sha(build_path), sha(status_path))
    return {'variants': actual, 'source_trees': TREES, 'pair_audit_sha256': sha(audit_path),
        'pair_review_sha256': sha(root_review), 'build_result_sha256': sha(build_path),
        'production_terminal_status_sha256': sha(status_path), 'common_build_inputs_sha256': common_sha,
        'production_manifest_sha256': MANIFEST, 'production_driver_sha256': DRIVER}


def delivery_files(production, proposal, root_review):
    """Metadata and original source proofs; linked binaries remain in retained production evidence."""
    production, proposal = Path(production), Path(proposal)
    names = {'execution/audit.json', 'execution/build-result.json', 'execution/stage-receipt.json',
             'status-' + COHORT + '.json', 'provenance-' + COHORT + '.json', 'binaries/manifest.json',
             'logs/' + COHORT + '.driver.stdout', 'logs/' + COHORT + '.driver.stderr'}
    names.update(read(production / ('provenance-' + COHORT + '.json'))['preserved_artifact_sha256'])
    names.update(name for name in read(production / ('status-' + COHORT + '.json'))['sealed_artifact_sha256']
                 if name.startswith('logs/') or name.endswith('.json'))
    files = {'controller/cohort/production/' + name: production / name for name in names}
    freeze = read(proposal / 'source-freeze.json')
    files.update({'controller/cohort/proposal/' + name: proposal / name for name in freeze['files']})
    files['controller/cohort/proposal/source-freeze.json'] = proposal / 'source-freeze.json'
    files['controller/cohort/root-pair-review.json'] = Path(root_review)
    return files
