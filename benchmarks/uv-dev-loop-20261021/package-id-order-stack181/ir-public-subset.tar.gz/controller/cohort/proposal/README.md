This is a source-only proposal for a fresh matched PackageId ordering pair on
local `charlie-oss`. It has not staged a checkout, run quiet admission, compiled
anything, or contacted another host. The proposed owned root remains absent:
`/tmp/ohm-hillclimb-20261021-package-id-order-production`.

`proposal.json` records the exact build and controller argv, environment
overrides and clearing policy, future paths, input bindings, staging boundary
and required post-build audit. `frozen/manifest.json` binds both source trees
and full patches. Correctness and production-control acceptance are explicitly
unbound pending root review. There is no PackageId measurement protocol yet.

The baseline source is exact PR181 `d81a093becb4321a975522624c2a383970f0d164`,
tree `c4178b67e0b3a64a12b9b58f84b97323b99d734e`. The candidate tree is
`12f12327e7c56fb04386b7cfb4d61d5fd434bfc5`; its only incremental source file is
`src/workspace/package_id.rs`. The final formatted patch is
`bdaf1930258f5b92f3235e0d3375934c324c156304a39204effceb33cebac575`.
The complete actual correctness seal remains
`e4c82bea38975ff0a1c4a97ed8157237152ee502d5ed3c15da81e60ac299e238`:
9 PackageId and 4 SourceId tests passed, with no failures or ignored tests.

Both full source patches are applied to the same existing pinned `5e5d271`
bundle. Thus both binaries retain that embedded Git identity while their
effective source trees are exactly the PR181 baseline and PackageId candidate.
This is the accepted production cohort's existing identity-preservation method.
The new pair shares one physical source, target and private Cargo home, and runs
serially in a single driver process. Its initial target and Cargo home are empty;
no failed parser root or existing build cache is reused or changed.

The recipe is unchanged: stock Rust 1.99, `all-static,ohm-defaults`, opt level 3,
ThinLTO, one codegen unit, debug level 1, no PGO and no additional RUSTFLAGS.
The original linked executable is retained. The byte-identical strip helper
accepts its separate stripped output only when every allocated ELF section
matches. `all-static` names the established Cargo features; libc is not claimed
to be statically linked. This remains an approximation of distributed production
builds because it uses stock Rust rather than release bootstrap stage1 and no
PGO profile.

`driver.diff` is the complete delta from the accepted scheduler driver. The AST
matches after only the declared host, path, cohort, variant and candidate-source
literal substitutions in `adaptation.json`. Occupancy checks, source verification,
common-input checks, build command, serial execution, failure retention and
artifact seals remain unchanged. For local invocation, the proposed controller
uses absolute system Python with `-I -B`, `/usr/bin:/bin` PATH and explicit
affinity 0–31, reproducing the accepted build affinity without local PATH shims.
The build still uses eight Cargo jobs.

Read-only static inspection rehashed the local Cargo/rustc/rustdoc/driver, native
build tools, system helpers, CA bundle, Cargo configuration and 5.2 MB pinned
bundle. The compiler hashes match the original production reference; all seven
native tool hashes match the completed scheduler pair. The inherited Cargo
configuration and selected native build environment also match. These observations
are in `local-prerequisites.json`; they do not establish future host quietness.

There is intentionally no executable provisioner or collector in this proposal.
Separate approval must precede fresh admission, exclusive root creation, source
import and producer launch. Future collection must retain all logs, failures,
original and stripped binaries and independently audit the exact source trees,
library/CLI settings, dependency parity and common inputs. No cross-cohort binary
identity or performance result is claimed. Host2, host4 and the held host3 require
no action for this proposed local pair.
