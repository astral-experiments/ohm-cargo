#!/usr/bin/env python3
"""Freeze a local, source-only proposal. Never stage or execute its producer."""
import ast
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REFERENCE = HERE.parent / "host2-scheduler-bitsets-stack181"
VALIDATION = WORK / "package-id-order-validation"
SOURCE = WORK / "cargo-package-id-order"
FROZEN = HERE / "frozen"
FUTURE = Path("/tmp/ohm-hillclimb-20261021-package-id-order-production")
COHORT = "local-package-id-order-stack181"
DRIVER = "build_driver_local_package_id_order_stack181.py"
REFERENCE_DRIVER = "build_driver_host2_scheduler_bitsets_stack181.py"
PINNED = "5e5d271d763d7beb38b48755e22bd59e93f02b97"
BASE = "d81a093becb4321a975522624c2a383970f0d164"
BASE_TREE = "c4178b67e0b3a64a12b9b58f84b97323b99d734e"
CANDIDATE_TREE = "12f12327e7c56fb04386b7cfb4d61d5fd434bfc5"
PATCH_SHA = "bdaf1930258f5b92f3235e0d3375934c324c156304a39204effceb33cebac575"
CORRECTNESS_SHA = "e4c82bea38975ff0a1c4a97ed8157237152ee502d5ed3c15da81e60ac299e238"
REFERENCE_DRIVER_SHA = "d57ddc6b4f68fe9a274d45181a30f717b8f65af1e96451353183bd3189d07ceb"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, data):
    with path.open("xb") as stream:
        stream.write(data)


def dump(path, value):
    write(path, (json.dumps(value, indent=2, sort_keys=True) + "\n").encode())


def git(*args):
    return subprocess.check_output([
        "/usr/bin/git", "--no-optional-locks", "-C", str(SOURCE),
        "-c", "core.fsmonitor=false", *args,
    ])


def record(path):
    path = Path(path)
    result = {"path": str(path), "exists": path.exists(), "symlink": path.is_symlink()}
    if path.exists():
        metadata = path.stat()
        result.update(resolved=str(path.resolve()), size=metadata.st_size,
                      uid=metadata.st_uid, mode=oct(stat.S_IMODE(metadata.st_mode)))
        if path.is_file():
            result["sha256"] = sha(path)
    return result


def main():
    assert not FROZEN.exists()
    assert not FUTURE.exists() and not FUTURE.is_symlink()
    assert os.getuid() == 1000
    assert Path("/proc/sys/kernel/hostname").read_text().strip() == "charlie-oss"
    assert sha(VALIDATION / "seal.json") == CORRECTNESS_SHA
    assert sha(VALIDATION / "attempt-01/final.patch") == PATCH_SHA
    correctness = json.loads((VALIDATION / "correctness-summary.json").read_text())
    assert correctness["status"] == "passed" and correctness["total_passed"] == 13
    assert correctness["total_failed"] == correctness["total_ignored"] == 0
    assert correctness["final_source"]["tree"] == CANDIDATE_TREE
    assert correctness["final_source"]["patch_sha256"] == PATCH_SHA
    assert sha(REFERENCE / "frozen" / REFERENCE_DRIVER) == REFERENCE_DRIVER_SHA
    original_driver = (REFERENCE / "frozen" / REFERENCE_DRIVER).read_text()
    reference_manifest = json.loads((REFERENCE / "frozen/manifest.json").read_text())
    reference = json.loads((REFERENCE / "frozen/reference-host7-provenance.json").read_text())
    reference_actual = json.loads((REFERENCE / "results/provenance.json").read_text())
    assert sha(HERE.parent / "pinned.bundle") == reference_manifest["source_bundle_sha256"]

    def source_state():
        return {"head": git("rev-parse", "HEAD").decode().strip(),
                "head_tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
                "status": git("status", "--porcelain").decode(),
                "changed_source_sha256": sha(SOURCE / "src/workspace/package_id.rs")}

    before = source_state()
    assert before["head"] == BASE and before["head_tree"] == BASE_TREE
    assert before["status"] == "M  src/workspace/package_id.rs\n"
    assert git("diff", "--no-ext-diff", "--no-textconv", CANDIDATE_TREE) == b""
    incremental = git("diff", "--no-ext-diff", "--no-textconv", "--binary", "--full-index", BASE, CANDIDATE_TREE)
    assert incremental == (VALIDATION / "attempt-01/final.patch").read_bytes()
    assert git("diff", "--name-only", BASE, CANDIDATE_TREE) == b"src/workspace/package_id.rs\n"
    patches = {
        "stack181-baseline.patch": git("diff", "--no-ext-diff", "--no-textconv", "--binary", "--full-index", PINNED, BASE),
        "stack181-package-id-order.patch": git("diff", "--no-ext-diff", "--no-textconv", "--binary", "--full-index", PINNED, CANDIDATE_TREE),
    }
    assert patches["stack181-baseline.patch"] == (REFERENCE / "frozen/stack181-baseline.patch").read_bytes()
    patch_hashes = {name: hashlib.sha256(data).hexdigest() for name, data in patches.items()}
    substitutions = {
        "/tmp/ohm-hillclimb-20261021-scheduler-bitsets-production": str(FUTURE),
        "host2-scheduler-bitsets-stack181": COHORT,
        "host2_scheduler_bitsets_stack181": "local_package_id_order_stack181",
        "scheduler-bitsets-stack181-baseline": "package-id-order-stack181-baseline",
        "scheduler-bitsets-stack181-reduced": "package-id-order-stack181-reduced",
        "stack181-scheduler-bitsets.patch": "stack181-package-id-order.patch",
        "807c36ec5326d42ca19a921819e1b3d1e2776cb2": CANDIDATE_TREE,
        "a938ea5e0f47059d910b75c3db844d17936bdbbc19c5a09edf15bd6a75ca89c3": patch_hashes["stack181-package-id-order.patch"],
        "current181/scheduler-bitsets": "current181/package-id-order",
        "charlie-oss-2": "charlie-oss",
        "this frozen cohort is restricted to host2": "this frozen cohort is restricted to local charlie-oss",
    }
    pattern = "|".join(re.escape(key) for key in sorted(substitutions, key=len, reverse=True))
    adapted_driver = re.sub(pattern, lambda match: substitutions[match.group()], original_driver)
    ast.parse(adapted_driver)
    original_ast = ast.parse(original_driver)
    adapted_ast = ast.parse(adapted_driver)
    class Relocate(ast.NodeTransformer):
        def visit_Constant(self, node):
            if isinstance(node.value, str):
                node.value = re.sub(pattern, lambda match: substitutions[match.group()], node.value)
            return node
    assert ast.dump(Relocate().visit(original_ast)) == ast.dump(adapted_ast)

    native_names = list(reference_actual["native_build_tool_sha256"])
    static_paths = list(reference["compiler_input_sha256"]) + native_names + [
        "/usr/bin/objcopy", "/usr/bin/git", "/usr/bin/python3", "/usr/bin/taskset",
        "/etc/ssl/certs/ca-certificates.crt", "/.cargo/config.toml", "/tmp/.cargo/config.toml",
        str(HERE.parent / "pinned.bundle"),
    ]
    static = {name: record(name) for name in static_paths}
    for name, expected in reference["compiler_input_sha256"].items():
        assert static[name]["sha256"] == expected
    for name, expected in reference_actual["native_build_tool_sha256"].items():
        assert static[name]["sha256"] == expected
    configs = {name: static[name]["sha256"] for name in ("/.cargo/config.toml", "/tmp/.cargo/config.toml") if static[name]["exists"]}
    assert configs == reference["inherited_cargo_configuration_sha256"]
    native_environment = {key: os.environ.get(key) for key in reference["inherited_native_build_environment"]}
    assert native_environment == reference["inherited_native_build_environment"]
    settings = {key: value.replace("/tmp/ohm-hillclimb-20261021-production", str(FUTURE))
                for key, value in reference["environment"].items()}
    external_paths = [VALIDATION / "seal.json", VALIDATION / "correctness-summary.json",
                      VALIDATION / "root-source-review.json", VALIDATION / "attempt-01/receipt.json",
                      VALIDATION / "attempt-01/final.patch", VALIDATION / "attempt-01/formatting-only.patch",
                      WORK / "package-id-order-candidate/manifest.json",
                      WORK / "compiler-audit/package-id-order-review/manifest.json",
                      REFERENCE / "source-freeze.json", REFERENCE / "root-production-launch-review.json",
                      REFERENCE / "frozen/manifest.json", REFERENCE / "frozen" / REFERENCE_DRIVER,
                      REFERENCE / "results/provenance.json", REFERENCE / "audit.py"]
    external = {str(path): record(path) for path in external_paths}
    FROZEN.mkdir()
    write(FROZEN / DRIVER, adapted_driver.encode())
    write(HERE / "driver.diff", "".join(difflib.unified_diff(
        original_driver.splitlines(True), adapted_driver.splitlines(True),
        fromfile="accepted-scheduler/" + REFERENCE_DRIVER, tofile=DRIVER)).encode())
    for name, data in patches.items():
        write(FROZEN / name, data)
    for name in ("reference-host7-provenance.json", "strip_binaries.py"):
        write(FROZEN / name, (REFERENCE / "frozen" / name).read_bytes())
    write(FROZEN / "incremental.patch", incremental)
    dump(HERE / "local-prerequisites.json", {
        "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": "Read-only static local files, hostname and selected native environment; no process admission or tool execution.",
        "host": "charlie-oss", "uid": os.getuid(), "future_root": record(FUTURE),
        "files": static, "native_environment": native_environment,
        "compiler_hashes_match_original_host7": True,
        "native_tool_hashes_match_completed_scheduler_pair": True,
        "inherited_configuration_matches_original_host7": True,
    })
    dump(HERE / "source-proof.json", {
        "baseline_commit": BASE, "baseline_tree": BASE_TREE,
        "candidate_tree": CANDIDATE_TREE, "incremental_sha256": PATCH_SHA,
        "full_patch_sha256": patch_hashes, "source_before_and_after": before,
        "only_changed_path": "src/workspace/package_id.rs",
        "git_reads_only_no_index_object_ref_or_checkout_mutation": True,
    })
    variants = ["package-id-order-stack181-baseline", "package-id-order-stack181-reduced"]
    manifest = {
        "cohort": COHORT, "build_host": "charlie-oss", "state": "proposal-only-not-authorized-or-staged",
        "owned_build_root": str(FUTURE), "variant_order": variants,
        "driver_sha256": sha(FROZEN / DRIVER),
        "strip_helper_sha256": sha(FROZEN / "strip_binaries.py"),
        "source_bundle_sha256": reference_manifest["source_bundle_sha256"],
        "patch_sha256": patch_hashes,
        "expected_variants": {variant: {"base": PINNED, "tree": tree,
            "patch_sha256": {patch: patch_hashes[patch]}, "canonical_diff_sha256": patch_hashes[patch]}
            for variant, tree, patch in zip(variants, (BASE_TREE, CANDIDATE_TREE), patches)},
        "actual_upstream_parent_commit": BASE, "actual_upstream_parent_tree": BASE_TREE,
        "embedded_git_commit_for_both_variants": PINNED,
        "reference_host7_provenance_sha256": sha(FROZEN / "reference-host7-provenance.json"),
        "correctness_seal_sha256": CORRECTNESS_SHA, "incremental_patch_sha256": PATCH_SHA,
        "root_final_correctness_acceptance": None,
        "root_production_controls_acceptance": None,
        "performance_protocol": None,
    }
    dump(FROZEN / "manifest.json", manifest)
    dump(HERE / "proposal.json", {
        "state": "source-only-production-proposal", "cohort": COHORT,
        "manifest_sha256": sha(FROZEN / "manifest.json"),
        "source": {"baseline_commit": BASE, "baseline_tree": BASE_TREE, "candidate_tree": CANDIDATE_TREE,
                   "incremental_sha256": PATCH_SHA, "correctness_seal_sha256": CORRECTNESS_SHA},
        "build_argv": reference["command"], "build_cwd": str(FUTURE / "source"),
        "environment": {"overrides": settings,
            "clear_name_prefixes": ["RUST", "CARGO_PROFILE_", "CARGO_UNSTABLE_"],
            "clear_names": reference["cleared_environment_names"],
            "required_native_values": native_environment,
            "other_inherited_values": "Retained by the unchanged driver; full resulting environment is hashed once and verified identically before/after both builds. No environment secrets are serialized.",
            "launcher_path": "/usr/bin:/bin"},
        "future_driver_argv": ["/usr/bin/env", "PATH=/usr/bin:/bin", "/usr/bin/taskset", "-c", "0-31", "/usr/bin/python3", "-I", "-B", str(FUTURE / DRIVER)],
        "required_affinity": list(range(32)), "variant_order": variants,
        "expected_paths": {"source": str(FUTURE / "source"), "target": str(FUTURE / "target"),
            "cargo_home": str(FUTURE / "cargo-home"), "temporary": str(FUTURE / "tmp"),
            "driver": str(FUTURE / DRIVER), "driver_inputs": str(FUTURE / (COHORT + "-inputs.json")),
            "ownership": str(FUTURE / ("ownership-" + COHORT + ".json")),
            "unstripped": [str(FUTURE / "binaries" / ("cargo-" + variant)) for variant in variants],
            "stripped": [str(FUTURE / "binaries/stripped" / ("cargo-" + variant)) for variant in variants]},
        "future_setup_contract": [
            "Separate root correctness/control acceptance, current local-slot permission and fresh quiet admission before mutation.",
            "Require absolute root absent/non-symlink; create exclusively mode0700 for uid1000; never overwrite/reuse an earlier attempt.",
            "Copy only the sealed driver/manifest/full patches/reference/strip helper and existing pinned.bundle into the new root; verify exact hashes before use.",
            "Create a new source repository from the pinned bundle, its preserved shallow boundary and pinned HEAD; do not clone/copy any target or failed parser fixture.",
            "Start with empty owned target/CARGO_HOME; retain normal locked registry acquisition. Do not reuse mutable shared caches or inject credentials.",
            "Run both variants serially through the same driver, physical source/target/cache paths, compiler, settings and full execution environment.",
            "Retain every attempted command, launch stdout/stderr/exit, failed status and partial artifact. No automatic retry or producer continuation.",
            "After terminal completion, separately audit both exact source trees, full patches, Cargo library/CLI flags/dependency parity, common-input digest, original linker hashes and all allocated ELF sections before release for any performance plan.",
        ],
        "explicit_deviations": [
            "Build host changes from charlie-oss-2 to local charlie-oss; task root, cohort, variant/patch names and candidate source identities change.",
            "Local controller uses absolute system Python with -I -B and explicit /usr/bin:/bin PATH, with taskset0-31 to reproduce the accepted build affinity. No SSH/transport or host2/host4/host3 action is required.",
            "This proposal contains a reviewed-driver adaptation and setup/audit contract, not an executable provisioner or collector. Those actions remain held for root review.",
            "Correctness evidence is the actual 9 PackageId plus4 SourceId Cargo library tests and complete retained validation seal; no scheduler/parser correctness or CI result is reused.",
            "No PackageId performance protocol, final correctness acceptance, build acceptance or candidate GitHub commit is invented. Those future gates remain explicitly unbound.",
        ],
        "unchanged_recipe": "stock1.99/all-static+ohm-defaults/opt3/ThinLTO/CGU1/debug1/noPGO; identical pinned embedded Git identity; same physical paths and shared inputs within the pair; unchanged occupancy/source/common-input/artifact-preservation functions; unchanged allocated-section-checked strip helper",
        "production_limitations": ["Stock1.99 compiler rather than release bootstrap stage1; no PGO profile.", "No cross-cohort binary identity or performance equivalence claimed.", "all-static is the established Cargo feature recipe, not a claim of a fully static libc executable; runtime dependencies are recorded by ldd after linking."],
        "external_bindings": external,
    })
    dump(HERE / "adaptation.json", {"reference_driver_sha256": REFERENCE_DRIVER_SHA,
        "driver_sha256": sha(FROZEN / DRIVER), "literal_substitutions": substitutions,
        "complete_driver_ast_equals_reference_after_declared_literals": True,
        "strip_helper_byte_identical": sha(FROZEN / "strip_binaries.py") == reference_manifest["strip_helper_sha256"],
        "driver_diff_sha256": sha(HERE / "driver.diff")})
    assert source_state() == before
    assert not FUTURE.exists() and not FUTURE.is_symlink()
    assert all(sha(path) == row["sha256"] for path, row in external.items())
    dump(HERE / "source-checks.json", {"status": "passed", "source_unchanged": True,
        "canonical_source_and_patch_checks": True, "compiler_native_tools_config_reference_parity": True,
        "complete_declared_literal_ast_parity": True, "reference_files_unchanged": True,
        "future_root_remains_absent": True, "no_admission_staging_compile_or_workload_execution": True})
    print(json.dumps({"manifest_sha256": sha(FROZEN / "manifest.json"),
        "proposal_sha256": sha(HERE / "proposal.json"), "driver_sha256": sha(FROZEN / DRIVER),
        "full_patch_sha256": patch_hashes}, indent=2))


if __name__ == "__main__":
    main()
