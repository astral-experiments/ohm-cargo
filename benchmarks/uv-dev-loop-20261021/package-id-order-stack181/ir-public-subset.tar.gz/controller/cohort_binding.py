"""Fail-closed data bindings for the new cohort; no workload or host operations."""
import hashlib
import json
import os
from pathlib import Path
import re

from correctness_binding import CORRECTNESS_SHA, ROOT_REVIEW_SHA, validate_correctness
from production_binding import (PRODUCTION_ROOT, NAMES, ACCEPTED_PAIR_REVIEW_SHA, ACCEPTED_VARIANTS,
                                validate_production, validate_root_review)

ROOT = '/tmp/ohm-hillclimb-20261021/package-id-order-stack181'
HOST = 'charlie-oss'
CONTROLLER_PATH = ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin'
PROTOCOL_SHA = '86eed951e351e0d7a96575c4a27035ec2c28675bce8793e5588202c0496f1b3b'
SOURCE_PARENT_COMMIT = 'd81a093becb4321a975522624c2a383970f0d164'
PATCH_SHA = 'bdaf1930258f5b92f3235e0d3375934c324c156304a39204effceb33cebac575'
HOST_ASSIGNMENT_SHA = '68ed7921aa5cc28db7e61d566ce7d6872b488dcd2dd9a9103d6252820303037d'
ROOT_PLAN_REVIEW_SHA = 'e90e92ef4d4df43294370a83cc07556ebc648003afcde525a6273d9176d53517'
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '12f12327e7c56fb04386b7cfb4d61d5fd434bfc5'}
OLD_BINARIES = {'3164f9287711f122fa9636a7816ed8749598706ac5076d66051a036dcef51037',
                '3b1a2e4e3654b7b23816fbb54c51072cb356486c36052a5bcd6c4d3d2e6a07e9'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(value):
    assert isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'Unbound or invalid digest'
    assert value != '0' * 64, 'Placeholder digest'
    return value


def validate_input_approval(value, source_freeze_sha256):
    assert value['status'] == 'passed' and value['scope'] == 'package-id-order-production-inputs'
    assert value['source_freeze_sha256'] == digest(source_freeze_sha256)
    assert value['protocol_sha256'] == PROTOCOL_SHA
    assert value['root'] == ROOT and value['host'] == HOST
    assert 'source_commit' not in value and 'source_ci_sha256' not in value
    assert value['source_parent_commit'] == SOURCE_PARENT_COMMIT and value['source_trees'] == TREES
    assert value['candidate_patch_sha256'] == PATCH_SHA
    assert value['root_correctness_review_sha256'] == ROOT_REVIEW_SHA
    assert value['correctness_seal_sha256'] == CORRECTNESS_SHA
    assert value['host_assignment_sha256'] == HOST_ASSIGNMENT_SHA
    assert value['root_plan_review_sha256'] == ROOT_PLAN_REVIEW_SHA
    assert value['controller_path'] == CONTROLLER_PATH
    assert value['cohort'] == 'local-package-id-order-stack181'
    assert value['variants'] == ACCEPTED_VARIANTS
    assert value['pair_review_sha256'] == ACCEPTED_PAIR_REVIEW_SHA
    assert set(value['variants']) == {'baseline', 'candidate'}
    assert len(set(value['variants'].values())) == 2
    for item in value['variants'].values():
        assert digest(item) not in OLD_BINARIES
    for name in ('pair_audit_sha256', 'pair_review_sha256', 'build_result_sha256', 'common_build_inputs_sha256',
                 'production_manifest_sha256', 'production_driver_sha256',
                 'production_terminal_status_sha256', 'host_readback_sha256'):
        digest(value[name])
    assert re.fullmatch('[a-z0-9][a-z0-9-]*', value['host_readback_label'])
    assert value['checks'] == {'fresh_matched_pair': True, 'production_audit_passed': True,
        'accepted_exact_source_and_focused_correctness': True, 'focused_package_id_9_source_id_4_passed': True,
        'production_complete_before_admission': True, 'quiet_host_root_absent': True}
    return value


def load_input_approval(directory):
    directory = Path(directory)
    return validate_input_approval(json.loads((directory / 'input-approval.json').read_text()),
                                   sha(directory / 'source-freeze.json'))


def validate_source_correctness(directory, controls):
    """Exact final source/correctness; source CI is a later publication prerequisite."""
    controls = Path(controls)
    assert sha(controls / 'protocol.json') == PROTOCOL_SHA
    assert sha(controls / 'host-assignment.json') == HOST_ASSIGNMENT_SHA
    assert sha(controls / 'references/root-plan-review.json') == ROOT_PLAN_REVIEW_SHA
    protocol = json.loads((controls / 'protocol.json').read_text())
    assert protocol['source']['base_commit'] == SOURCE_PARENT_COMMIT
    assert protocol['source']['base_tree'] == TREES['baseline']
    assert protocol['source']['final_tested_source_tree'] == TREES['candidate']
    assert protocol['source']['final_tested_incremental_patch_sha256'] == PATCH_SHA
    assert protocol['correctness']['root_acceptance_sha256'] == ROOT_REVIEW_SHA
    assert protocol['correctness']['complete_validation_seal_sha256'] == CORRECTNESS_SHA
    assert protocol['correctness']['full_exact_source_ci_required_before_pr'] is True
    assert protocol['correctness']['github_source_upload_only_after_private_performance_qualification'] is True
    return validate_correctness(directory)


def validate_production_admission(cohort, review):
    """No host admission before the exact local pair has completed and been accepted."""
    cohort = Path(cohort)
    assert cohort == PRODUCTION_ROOT
    work = Path(__file__).resolve().parent.parent
    proposal = work / 'production-build/local-package-id-order-stack181'
    accepted = work / 'production-build/local-package-id-order-execution-controls/root-pair-review.json'
    binaries = {role: cohort / 'binaries/stripped' / ('cargo-' + name) for role, name in NAMES.items()}
    proof = validate_production(cohort, proposal, accepted, binaries)
    assert proof['production_terminal_status_sha256'] == review['production_terminal_status_sha256']
    assert proof['pair_audit_sha256'] == review['production_pair_audit_sha256']
    assert proof['pair_review_sha256'] == review['production_pair_review_sha256']
    return {key: review[key] for key in ('production_terminal_status_sha256', 'production_pair_audit_sha256', 'production_pair_review_sha256')} | {'build_result_sha256': proof['build_result_sha256']}


def validate_pair_review(value, audit_sha256, variants, build_result_sha256, terminal_sha256):
    return validate_root_review(value, audit_sha256, variants, build_result_sha256, terminal_sha256)


def require_controller_environment():
    assert os.environ.get('PATH') == CONTROLLER_PATH
    assert not any(name in os.environ for name in ('PYTHONHOME', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONINSPECT'))
    assert os.sched_getaffinity(0) == {8}, 'Controller must stay outside measured CPUs 0-7'


def translate_reference(value):
    old = '/tmp/ohm-hillclimb-20261021-inheritance-measurement'
    names = {'inheritance-stack180-baseline': 'package-id-order-stack181-baseline',
             'inheritance-stack180-shared': 'package-id-order-stack181-reduced'}
    if isinstance(value, str):
        value = value.replace(old, ROOT)
        for before, after in names.items():
            value = value.replace(before, after)
        return value
    if isinstance(value, list):
        return [translate_reference(item) for item in value]
    if isinstance(value, dict):
        return {key: translate_reference(item) for key, item in value.items()}
    return value


def validate_base_config(config, reference):
    expected = translate_reference(reference)
    assert {key: value for key, value in config.items() if key not in ('record_files', 'env')} == {
        key: value for key, value in expected.items() if key not in ('record_files', 'env')}
    assert set(expected['env']) <= set(config['env'])
    assert all(config['env'][key] == value for key, value in expected['env'].items())
    assert all(value is None for key, value in config['env'].items() if key not in expected['env'])
    assert config['record_files'][:len(expected['record_files'])] == expected['record_files']
    assert len(config['record_files']) == len(set(config['record_files']))
    return expected


def runtime_aliases(root):
    result = {}
    for prefix in ('ohm', 'profiling-tools'):
        for path in sorted((Path(root) / prefix).rglob('*')):
            if path.is_symlink():
                resolved = path.resolve()
                result[str(path)] = {'target': os.readlink(path), 'resolved': str(resolved),
                                     'sha256': sha(resolved) if resolved.is_file() else None}
    return result
