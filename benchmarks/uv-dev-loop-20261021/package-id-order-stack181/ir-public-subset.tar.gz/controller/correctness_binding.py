"""Bind the real PackageId/SourceId Cargo library tests; no test execution."""
import hashlib
import json
from pathlib import Path
import re

CORRECTNESS_SHA = 'e4c82bea38975ff0a1c4a97ed8157237152ee502d5ed3c15da81e60ac299e238'
ROOT_REVIEW_SHA = '8da35b84c488c97fd68eab717d0537c1920ee2e2b4ede0727bd0eab483a8bb6b'
PARENT = 'd81a093becb4321a975522624c2a383970f0d164'
BASE_TREE = 'c4178b67e0b3a64a12b9b58f84b97323b99d734e'
TREE = '12f12327e7c56fb04386b7cfb4d61d5fd434bfc5'
PATCH = 'bdaf1930258f5b92f3235e0d3375934c324c156304a39204effceb33cebac575'
SOURCE = 'a5b4c58a07c73e09708a56acf176e52e88125b77fa6fbeba0fb3ed9f74492ad2'


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def validate_correctness(directory):
    directory = Path(directory)
    assert sha(directory / 'seal.json') == CORRECTNESS_SHA
    assert sha(directory / 'root-correctness-review.json') == ROOT_REVIEW_SHA
    seal, reviewed = read(directory / 'seal.json'), read(directory / 'root-correctness-review.json')
    assert seal['status'] == reviewed['status'] == 'passed'
    assert reviewed['scope'] == 'package-id-order-final-source-and-focused-correctness'
    assert reviewed['baseline_commit'] == PARENT and reviewed['candidate_tree'] == seal['source_tree'] == TREE
    assert reviewed['candidate_patch_sha256'] == PATCH and reviewed['candidate_file_sha256'] == SOURCE
    assert reviewed['correctness_seal_sha256'] == CORRECTNESS_SHA
    assert reviewed['focused_tests'] == {'package_id_passed': 9, 'source_id_passed': 4, 'failed': 0, 'ignored': 0}
    assert len(seal['files']) == 67
    for name, identity in seal['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        path = directory / name
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(directory.resolve())
        assert sha(path) == identity['sha256'] and path.stat().st_size == identity['bytes']
    receipt_path = directory / 'attempt-01/receipt.json'
    summary_path = directory / 'correctness-summary.json'
    assert sha(receipt_path) == reviewed['attempt_receipt_sha256']
    assert sha(summary_path) == reviewed['summary_sha256']
    receipt, summary = read(receipt_path), read(summary_path)
    assert receipt['status'] == summary['status'] == 'passed'
    assert receipt['baseline_commit'] == summary['baseline_commit'] == PARENT
    assert receipt['baseline_tree'] == summary['baseline_tree'] == BASE_TREE
    assert len(receipt['commands']) == 27 and all(row['returncode'] == 0 for row in receipt['commands'])
    assert receipt['final_source'] == summary['final_source']
    assert receipt['final_source']['tree'] == TREE and receipt['final_source']['patch_sha256'] == PATCH
    assert sha(directory / 'attempt-01/final.patch') == PATCH
    assert sha(directory / 'attempt-01/after-format-package_id.rs') == SOURCE
    assert receipt['final_source']['files']['src/workspace/package_id.rs'] == SOURCE
    assert seal['external_test_executable'] == reviewed['test_executable'] == receipt['test_executable'] == summary['test_executable']
    assert receipt['total_passed'] == summary['total_passed'] == 13
    assert summary['total_failed'] == summary['total_ignored'] == 0
    prefix = ['/usr/bin/taskset', '-c', '0-7',
              '/home/dev-user/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/cargo',
              'test', '--locked', '--offline', '-p', 'cargo', '--lib', '-j', '8']
    build = next(row for row in receipt['commands'] if row['label'] == 'build-library')
    assert build['argv'] == prefix + ['--no-run', '--message-format=json']
    for label, namespace, count, output_name in (
        ('run-package-id', 'workspace::package_id::tests::', 9, '21-run-package-id'),
        ('run-source-id', 'workspace::source_id::tests::', 4, '23-run-source-id')):
        command = next(row for row in receipt['commands'] if row['label'] == label)
        assert command['argv'] == prefix + [namespace, '--', '--nocapture', '--test-threads=1']
        for suffix in ('stdout', 'stderr'):
            assert sha(directory / 'attempt-01' / (output_name + '.' + suffix)) == command[suffix + '_sha256']
        text = (directory / 'attempt-01' / (output_name + '.stdout')).read_text()
        names = re.findall(r'^test (.+) \.\.\. ok$', text, re.M)
        assert len(names) == len(set(names)) == count and all(name.startswith(namespace) for name in names)
        assert re.search(r'^test result: ok\. ' + str(count) + r' passed; 0 failed; 0 ignored;', text, re.M)
        row = receipt['tests'][namespace]
        assert row == summary['test_results'][namespace]
        assert row == {'executed': names, 'passed': count, 'failed': 0, 'ignored': 0}
    return {'source_tree': TREE, 'package_id_tests': 9, 'source_id_tests': 4,
            'failed': 0, 'ignored': 0, 'complete_source_ci_still_required_before_publication': True}
