"""Frozen scheduler acceptance policy; consumes already-completed per-workflow gates."""
import math


def decide(phase, completed):
    assert phase in ('ir', 'native')
    assert [row['workflow'] for row in completed] == ['check', 'test']
    for row in completed:
        assert type(row['passes_gate']) is bool
        assert len(row['interval_99']) == 2 and all(math.isfinite(x) for x in row['interval_99'])
        assert row['interval_99'][0] <= row['interval_99'][1]
        assert math.isfinite(row['sign_p']) and 0 <= row['sign_p'] <= 1
    regressions = [row['workflow'] for row in completed if row['interval_99'][1] < 0 and row['sign_p'] <= .01]
    qualifies = (completed[0]['passes_gate'] and 'test' not in regressions) if phase == 'ir' else not regressions
    return {'rule': 'primary-check-ir' if phase == 'ir' else 'no-established-native-regression',
            'qualifies': qualifies, 'primary_workflow': 'check',
            'primary_gate_passed': completed[0]['passes_gate'], 'secondary_gate_passed': completed[1]['passes_gate'],
            'established_regressions': regressions,
            'improvement_claims': {row['workflow']: qualifies and row['passes_gate'] for row in completed}}
