"""Accept only the exact independently reviewed IR cohort before native calls."""
import json
from pathlib import Path

from cohort_binding import CONTROLLER_PATH, HOST, ROOT, sha
from phase_policy import decide

REQUIRED = frozenset({
    'root-approval.json', 'review/review.json', 'review/raw-integrity.json',
    'review/check-reproduced-analysis.json', 'review/test-reproduced-analysis.json',
    'review/source-freeze.json', 'collection/transfer-manifest.json', 'collection/receipt.json',
})


def read(path):
    return json.loads(Path(path).read_text())


def validate_proof(directory, expected_seal, source_freeze, reviewer_freeze, variants, resolve_raw=None):
    directory = Path(directory)
    manifest = read(directory / 'manifest.json')
    assert set(manifest['files']) == REQUIRED
    assert manifest['root'] == ROOT and manifest['host'] == HOST
    assert manifest['controller_path'] == CONTROLLER_PATH
    assert manifest['measurement_seal_sha256'] == expected_seal
    assert manifest['source_freeze_sha256'] == source_freeze
    assert manifest['reviewer_source_freeze_sha256'] == reviewer_freeze
    assert manifest['variants'] == variants
    for name, digest in manifest['files'].items():
        path = directory / name
        assert path.is_file() and not path.is_symlink() and path.resolve() == path
        assert sha(path) == digest, name
    assert sha(directory / 'review/source-freeze.json') == reviewer_freeze
    accepted = read(directory / 'root-approval.json')
    assert accepted['status'] == 'passed' and accepted['scope'] == 'package-id-order-independent-ir-acceptance'
    assert accepted['source_freeze_sha256'] == source_freeze
    assert accepted['measurement_seal_sha256'] == expected_seal and accepted['variants'] == variants
    assert accepted['reviewer_source_freeze_sha256'] == reviewer_freeze
    for name, field in [('review/review.json', 'review_sha256'),
                        ('review/raw-integrity.json', 'raw_integrity_sha256'),
                        ('collection/transfer-manifest.json', 'transfer_manifest_sha256'),
                        ('collection/receipt.json', 'collection_receipt_sha256')]:
        assert accepted[field] == manifest['files'][name]
    review = read(directory / 'review/review.json')
    assert review['status'] == 'passed' and review['qualifies'] is True and review['phase'] == 'ir'
    assert review['integrity_status'] == 'passed' and review['statistics_computed'] is True
    assert review['final_evidence_and_review_source_rehash'] == 'passed'
    assert review['source_freeze_sha256'] == source_freeze
    assert review['measurement_seal_sha256'] == expected_seal and review['variants'] == variants
    assert review['review_source_freeze_sha256'] == reviewer_freeze
    assert review['launch_receipt_sha256'] == accepted['launch_receipt_sha256']
    assert review['transfer_manifest_sha256'] == manifest['files']['collection/transfer-manifest.json']
    assert review['bootstrap'] == {'confidence': 0.99, 'resamples': 20000, 'seed': 1701}
    assert [row['workflow'] for row in review['completed']] == ['check', 'test']
    assert review['policy'] == decide('ir', review['completed']) and review['policy']['qualifies']
    raw = read(directory / 'review/raw-integrity.json')
    assert raw['status'] == 'passed' and raw['phase'] == 'ir'
    assert raw['analysis_files_parsed'] is False and raw['statistics_computed'] is False
    assert raw['workflows'] == review['workflows']
    transfer = read(directory / 'collection/transfer-manifest.json')
    receipt = read(directory / 'collection/receipt.json')
    assert transfer['phase'] == receipt['phase'] == 'ir' and receipt['status'] == 'passed'
    assert transfer['root'] == ROOT and transfer['seal_sha256'] == receipt['measurement_seal_sha256'] == expected_seal
    assert receipt['transfer_manifest_sha256'] == review['transfer_manifest_sha256'] == raw['transfer_manifest_sha256']
    assert transfer['files'] == review['raw_file_sha256']
    required_raw = {'results/ir-status.json'} | {
        'results/ir-' + workflow + '/' + name for workflow in ('check', 'test')
        for name in ('manifest.json', 'samples.json', 'samples.jsonl', 'samples.csv', 'integrity.json', 'analysis.json', 'gate.json')}
    assert required_raw <= set(transfer['files'])
    if resolve_raw is not None:
        for name, digest in transfer['files'].items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert sha(resolve_raw(name)) == digest, name
    return manifest


def verify_native_approval(root, expected_seal):
    root = Path(root)
    assert str(root) == ROOT and root.resolve() == root
    assets = read(root / 'controller/assets.json')
    directory = root / 'metadata/native-approval'
    manifest = validate_proof(directory, expected_seal,
        sha(root / 'controller/source-freeze.json'), sha(root / 'controller/reviewer/source-freeze.json'),
        assets['variants'], resolve_raw=lambda name: root / name)
    return {**{str(directory / name): digest for name, digest in manifest['files'].items()},
            str(directory / 'manifest.json'): sha(directory / 'manifest.json')}
