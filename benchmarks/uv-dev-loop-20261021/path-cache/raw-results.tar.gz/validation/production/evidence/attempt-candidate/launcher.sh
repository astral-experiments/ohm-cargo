#!/bin/sh
# Preserve each test's explicit Ohm defaults and nightly channel.
case "${__CARGO_TEST_CHANNEL_OVERRIDE_DO_NOT_USE_THIS-}" in
  stable|beta|"") export __CARGO_TEST_CHANNEL_OVERRIDE_DO_NOT_USE_THIS=dev ;;
esac
if [ "${__CARGO_OHM_DEFAULTS+x}" != x ]; then
  export __CARGO_OHM_DEFAULTS=no
fi
exec /tmp/ohm-hillclimb-20261021/path-cache-validation/binaries/cargo-candidate "$@"
