#!/usr/bin/env python3
"""Seal small production evidence after all measurements and validation finish."""

import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
FIXTURE = ROOT / 'work/loader-fixtures/uv-loader-pr175'
RESULT = ROOT / 'results/loader-native-to-check-pr175-production-confirmation'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    active = subprocess.run(
        ['tmux', '-S', str(ROOT / 'tmux.sock'), 'has-session', '-t', 'loader-production-confirmation'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    assert active.returncode != 0, 'Measurement/validation session is still active'
    assert json.loads((RESULT / 'manifest.json').read_text())['state'] == 'complete'
    assert json.loads((RESULT / 'loader-fixture-validation.json').read_text())['valid']
    assert json.loads((RESULT / 'loader-mechanism.json').read_text())['all_24_samples_retained']
    assert (RESULT / 'transfer-sha256.json').is_file()
    selected = {path for path in RESULT.rglob('*') if path.is_file()}
    selected.update(FIXTURE / name for name in ('fixture.json', 'paired.json', 'journal.jsonl', 'package-home.ready.json'))
    selected.update(path for path in (FIXTURE / 'logs').iterdir() if path.is_file())
    for variant in ('baseline', 'candidate'):
        selected.update(FIXTURE / 'snapshots' / variant / name for name in ('manifest.json', 'inventory.jsonl', 'runlist.json'))
    selected.update((ROOT / 'metadata').glob('loader-production-*.json'))
    selected.update((ROOT / 'production').glob('*.json'))
    selected.update((ROOT / 'production').glob('*.patch'))
    selected.update(ROOT / 'work/benchmark' / name for name in (
        'loader_fixture.py', 'loader_fixture_delta.py', 'loader-fixture.md', 'paired.py',
        'test_loader_fixture.py', 'test_loader_fixture_delta.py',
        'loader-production-confirmation-protocol.json', 'loader-production-confirmation.md',
        'loader-pr175-production-template.pending.json', 'loader-pr175-production-template.json',
    ))
    selected.update(ROOT / name for name in (
        'finalize_loader_production.py', 'inspect_loader_production_seeds.py',
        'summarize_loader_production.py', 'collect_loader_production.py', 'seal_results.py',
        'run-loader-production-native-seeds.sh', 'run-loader-production-confirmation.sh',
        'loader-production-native-seeds.log', 'loader-production-confirmation.log',
        'loader-delta-tests.log', 'patches/loader-path-v2-final.patch', 'production-build/pr175.patch',
    ))
    for path in selected:
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT), str(path)
    file_list = ROOT / 'loader-production-evidence-files.txt'
    assert not file_list.exists()
    file_list.write_text(''.join(str(path.relative_to(ROOT)) + '\n' for path in sorted(selected)))
    selected.add(file_list)
    records = {
        str(path.relative_to(ROOT)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted(selected)
    }
    output = ROOT / 'loader-production-evidence-sha256.json'
    assert not output.exists()
    output.write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({
        'files': len(records), 'bytes': sum(row['bytes'] for row in records.values()),
        'manifest': str(output), 'manifest_sha256': sha(output),
        'large_native_trees_and_binaries_not_copied': True,
    }))


if __name__ == '__main__':
    main()
