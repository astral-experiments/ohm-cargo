#!/usr/bin/env python3
"""Bind real production assets, then archive and initialize at unchanged paths."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
BENCH = ROOT / 'work/benchmark'
PROTOCOL_SHA = '2ce14ba5355e38917985e573a5e659ec534713568bc1a5ff4d1d490d1f891479'
BASELINE_SHA = '63495905e7b0b11ad99fa4c2c2674e43657b9902a2e3142ef735fd83efa44cf8'
OLD_FIXTURE_SHA = '4775937000a1222d7e5176946b1359daf72adc13fb39a936bb2d4f1a2d9a2a1a'
OLD_RUN_SHA = '0292bae478dc9d40d5a1570138c2bb07282eac033ce0c3ae2527785094e4417d'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-sha256', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{64}', args.candidate_sha256)
    protocol_path = BENCH / 'loader-production-confirmation-protocol.json'
    assert sha(protocol_path) == PROTOCOL_SHA
    protocol = read(protocol_path)
    assert sha(ROOT / protocol['restoration']['helper']) == protocol['restoration']['sha256']
    assert sha(BENCH / 'paired.py') == protocol['harness_sha256']
    expected = {'baseline': BASELINE_SHA, 'candidate': args.candidate_sha256}
    names = {'baseline': 'cargo-pr175', 'candidate': 'cargo-pr175-loader-v2'}
    production = ROOT / 'production'
    cfg = read(BENCH / 'loader-pr175-production-template.pending.json')
    records = []
    for variant, name in names.items():
        binary = production / 'binaries' / name
        build_path = production / f'{name}.build.json'
        strip_path = production / f'{name}.strip.json'
        source_patch = production / f'{name.removeprefix("cargo-")}.source.patch'
        build, stripped = read(build_path), read(strip_path)
        assert sha(binary) == expected[variant] == stripped['stripped_sha256']
        assert build['original_linker_output_sha256'] == stripped['source_sha256']
        assert build['observed_source_tree'] == protocol['expected_source_trees'][variant]
        assert sha(source_patch) == build['observed_diff_sha256']
        assert build['embedded_source_commit'] == '5e5d271d763d7beb38b48755e22bd59e93f02b97'
        assert set(build['patch_sha256']) == ({'pr175.patch'} if variant == 'baseline' else set(protocol['expected_patch_sha256']))
        for patch, digest in build['patch_sha256'].items():
            assert digest == protocol['expected_patch_sha256'][patch]
        cfg['variants'][variant] = str(binary)
        records += [str(build_path), str(strip_path), str(source_patch)]
    baseline_provenance = production / 'provenance-pr175.json'
    candidate_provenance = production / 'provenance-pr175-loader-v2.json'
    first, second = read(baseline_provenance), read(candidate_provenance)
    equal_fields = ['source', 'target', 'source_commit', 'command', 'environment',
                    'cleared_environment_names', 'rustc_version', 'cargo_version',
                    'compiler_input_sha256', 'inherited_cargo_configuration_sha256',
                    'inherited_native_build_environment', 'cc_version', 'approximation']
    for key in equal_fields:
        assert first[key] == second[key], f'Build provenance mismatch: {key}'
    records += [str(baseline_provenance), str(candidate_provenance), str(production / 'expected-pr175-source-trees.json')]
    for patch, digest in protocol['expected_patch_sha256'].items():
        path = ROOT / ('production-build' if patch == 'pr175.patch' else 'patches') / patch
        assert sha(path) == digest
        records.append(str(path))
    runtime = {}
    environment = os.environ.copy()
    for key, value in cfg['env'].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    for variant, binary in cfg['variants'].items():
        linked = subprocess.check_output(['ldd', binary], env=environment, text=True)
        paths = []
        for line in linked.splitlines():
            match = re.search(r'(?:=>\s*)?(/\S+)\s+\(', line)
            if match:
                paths.append(str(Path(match[1]).resolve(strict=True)))
        runtime[variant] = sorted(set(paths))
    assert runtime['baseline'] == runtime['candidate']
    assert {Path(path).name for path in runtime['baseline']} == {'libc.so.6', 'libm.so.6', 'libgcc_s.so.1', 'ld-linux-x86-64.so.2'}
    cfg['record_files'] = [path for path in cfg['record_files'] if not path.startswith('/usr/lib/')]
    cfg['record_files'] = list(dict.fromkeys(cfg['record_files'] + runtime['baseline'] + records + [str(Path(__file__).resolve())]))
    del cfg['pending_frozen_assets']
    template = BENCH / 'loader-pr175-production-template.json'
    assert not template.exists()
    template.write_text(json.dumps(cfg, indent=2) + '\n')
    sys.path.insert(0, str(BENCH))
    import loader_fixture as original
    import loader_fixture_delta as fixture
    sys.path.insert(0, str(ROOT))
    import diagnose_build_output
    quiet = diagnose_build_output.quiet_snapshot()
    old, marker = original.load(protocol['fixture_name'])
    archive = original.fixture_root(protocol['archive_name'])
    assert sha(old / 'fixture.json') == OLD_FIXTURE_SHA and not archive.exists()
    original.check_inputs(marker)
    result = ROOT / 'results/loader-native-to-check-pr175-diagnostic-01'
    assert sha(result / 'manifest.json') == OLD_RUN_SHA
    assert read(result / 'manifest.json')['state'] == 'complete'
    assert read(result / 'loader-fixture-validation.json')['valid']
    with original.locked(old):
        original.reject_mounts(old)
        assert old.resolve() == old and not old.is_symlink()
        old.rename(archive)
        assert sha(archive / 'fixture.json') == OLD_FIXTURE_SHA
    manifest = fixture.initialize(protocol['fixture_name'], template, cfg['variants']['candidate'], cfg['variants']['baseline'], copy_mode='copy')
    report = {
        'initialized_at': datetime.now(timezone.utc).isoformat(), 'protocol_sha256': PROTOCOL_SHA,
        'archived_fixture': str(archive), 'archived_fixture_manifest_sha256': OLD_FIXTURE_SHA,
        'historical_run_manifest_sha256': OLD_RUN_SHA, 'variant_sha256': expected,
        'matching_build_fields': equal_fields, 'runtime_libraries': runtime,
        'record_file_sha256': manifest['recorded_files'], 'template_sha256': sha(template),
        'fixture_manifest_sha256': sha(old / 'fixture.json'), 'paired_config_sha256': sha(old / 'paired.json'),
        'host': quiet, 'native_producer_order': protocol['native_producer_order'],
    }
    output = ROOT / 'metadata/loader-production-initialized.json'
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'metadata': str(output), 'metadata_sha256': sha(output),
                      'template_sha256': report['template_sha256'], 'paired_config_sha256': report['paired_config_sha256'],
                      'variant_sha256': expected}, indent=2))


if __name__ == '__main__':
    main()
