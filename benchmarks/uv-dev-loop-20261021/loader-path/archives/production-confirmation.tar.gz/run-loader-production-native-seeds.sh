#!/bin/bash
set -euo pipefail
root=/tmp/ohm-hillclimb-20261021/confirmation-path-cache
export TMPDIR="$root/tmp"
exec >"$root/loader-production-native-seeds.log" 2>&1
python3 "$root/work/benchmark/loader_fixture_delta.py" seed --name uv-loader-pr175 --variant candidate >"$root/work/loader-fixtures/uv-loader-pr175/logs/seed-candidate-driver.json"
python3 "$root/work/benchmark/loader_fixture_delta.py" seed --name uv-loader-pr175 --variant baseline >"$root/work/loader-fixtures/uv-loader-pr175/logs/seed-baseline-driver.json"
