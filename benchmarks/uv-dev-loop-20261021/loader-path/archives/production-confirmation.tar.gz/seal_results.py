#!/usr/bin/env python3
"""Hash a completed remote batch, or verify its exact local transfer."""
import argparse
import hashlib
import json
from pathlib import Path


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('seal', 'verify'))
    parser.add_argument('directory', type=Path)
    arguments = parser.parse_args()
    directory = arguments.directory.resolve()
    transfer = directory / 'transfer-sha256.json'
    if arguments.action == 'seal':
        manifest = json.loads((directory / 'manifest.json').read_text())
        if manifest['state'] != 'complete' or not (directory / 'analysis.json').is_file():
            raise RuntimeError('only a complete analyzed batch can be sealed')
        records = {}
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():
                raise RuntimeError(f'unexpected result symlink: {path}')
            if path.is_file() and path != transfer:
                records[str(path.relative_to(directory))] = {'sha256': sha256(path), 'bytes': path.stat().st_size}
        transfer.write_text(json.dumps(records, indent=2) + '\n')
    records = json.loads(transfer.read_text())
    actual_paths = {str(path.relative_to(directory)) for path in directory.rglob('*') if path.is_file() and path != transfer}
    if actual_paths != set(records):
        raise RuntimeError('missing or extra transferred result files')
    for relative, expected in records.items():
        path = directory / relative
        if path.is_symlink() or not path.resolve().is_relative_to(directory):
            raise RuntimeError('unexpected result redirection')
        if path.stat().st_size != expected['bytes'] or sha256(path) != expected['sha256']:
            raise RuntimeError(f'result transfer mismatch: {relative}')
    print(json.dumps({'verified_files': len(records), 'verified_bytes': sum(item['bytes'] for item in records.values()),
                      'manifest_sha256': records['manifest.json']['sha256']}))


if __name__ == '__main__':
    main()
