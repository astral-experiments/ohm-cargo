#!/usr/bin/env python3
"""Summarize mechanism evidence only after the fixed production batch completes."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
FIXTURE = ROOT / 'work/loader-fixtures/uv-loader-pr175'
RESULT = ROOT / 'results/loader-native-to-check-pr175-production-confirmation'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    protocol = read(ROOT / 'work/benchmark/loader-production-confirmation-protocol.json')
    manifest = read(RESULT / 'manifest.json')
    samples = read(RESULT / 'samples.json')
    validation = read(RESULT / 'loader-fixture-validation.json')
    analysis = read(RESULT / 'analysis.json')
    seeds = read(ROOT / 'metadata/loader-production-seeds-reviewed.json')
    fixture = read(FIXTURE / 'fixture.json')
    assert manifest['state'] == 'complete'
    assert manifest['phase'] == protocol['phase'] == 'confirmation'
    assert manifest['pairs'] == protocol['pairs'] == 12
    assert manifest['warmup_pairs'] == protocol['warmup_pairs'] == 0
    assert manifest['seed'] == protocol['randomization_seed']
    assert manifest['plans'] == {'warmup': [], 'measurement': protocol['balanced_order_plan']}
    assert manifest['configuration']['command'] == protocol['command']
    assert manifest['variant_sha256'] == manifest['variant_sha256_after'] == fixture['variant_sha256']
    assert manifest['recorded_file_sha256'] == manifest['recorded_file_sha256_after']
    assert seeds['fixture_manifest_sha256'] == sha(FIXTURE / 'fixture.json')
    assert len(samples) == 24 and validation['valid'] and not validation['errors']
    assert all(sample['stage'] == 'measurement' and sample['returncode'] == 0 for sample in samples)
    assert analysis['pairs'] == 12
    details = {tuple(row['sample']): row for row in validation['samples']}
    assert len(details) == len(samples)
    records = []
    test_executables = {}
    for variant in ('baseline', 'candidate'):
        runlist = read(FIXTURE / 'snapshots' / variant / 'runlist.json')
        test_executables[variant] = {
            row['executable'] for row in runlist['artifacts']
            if row['profile']['test'] and row['executable']
        }
    for sample in samples:
        key = (sample['stage'], sample['pair'], sample['position'], sample['variant'])
        detail = details[key]
        assert detail['inventory_sha256'] == seeds['variants'][sample['variant']]['inventory_sha256']
        assert all(
            not any(argument in test_executables[sample['variant']] for argument in invocation)
            for invocation in detail['other_invocations']
        ), 'A native test executable appears in the check runlist'
        records.append({
            'pair': sample['pair'], 'position': sample['position'],
            'variant': sample['variant'], 'order': sample['order'],
            'rustc_invocations': len(detail['rustc_invocations']),
            'metadata_only_rustc_invocations': sum('link' not in command['emit'] for command in detail['rustc_invocations']),
            'other_invocations': len(detail['other_invocations']),
            'other_executable_basenames': sorted({Path(command[0]).name for command in detail['other_invocations'] if command}),
            'cached_or_executed_build_script_output_messages': len(detail['build_script_outputs']),
            'fresh_artifacts': detail['fresh_artifacts'], 'compiled_artifacts': detail['compiled_artifacts'],
            'restore_seconds_excluded': detail['restore_wall_ns_excluded'] / 1e9,
            'native_snapshot_inventory_sha256': detail['inventory_sha256'],
        })
    counts = [
        'rustc_invocations', 'metadata_only_rustc_invocations', 'other_invocations',
        'cached_or_executed_build_script_output_messages', 'fresh_artifacts', 'compiled_artifacts',
    ]
    summaries = {}
    for variant in ('baseline', 'candidate'):
        selected = [record for record in records if record['variant'] == variant]
        assert len(selected) == 12
        summaries[variant] = {
            'samples': len(selected),
            'count_frequencies': {name: dict(sorted(Counter(record[name] for record in selected).items())) for name in counts},
            'other_executable_basenames': sorted({name for record in selected for name in record['other_executable_basenames']}),
            'restore_seconds_excluded': {
                'minimum': min(record['restore_seconds_excluded'] for record in selected),
                'median': statistics.median(record['restore_seconds_excluded'] for record in selected),
                'maximum': max(record['restore_seconds_excluded'] for record in selected),
                'sum': sum(record['restore_seconds_excluded'] for record in selected),
            },
        }
    journal = [json.loads(line) for line in (FIXTURE / 'journal.jsonl').read_text().splitlines()]
    preparations = [row for row in journal if row['operation'] == 'prepare' and row['batch'] == str(RESULT)]
    assert len(preparations) == 24 and all(row['full_content_verification'] for row in preparations)
    report = {
        'kind': 'Production-settings restored-state confirmation mechanism evidence',
        'primary_analysis': 'analysis.json', 'pairs': 12, 'all_24_samples_retained': True,
        'fixture_valid': True, 'frozen_inputs_unchanged': True,
        'native_producer_order': [row['variant'] for row in journal if row['operation'] == 'seed-complete'],
        'no_normal_diagnostic_samples_pooled': True,
        'statistical_unit': protocol['independence'], 'build_regime': protocol['build_regime'],
        'variant_sha256': manifest['variant_sha256'], 'variants': summaries,
        'restoration_records': [{key: row[key] for key in ('pair', 'position', 'variant', 'restoration', 'restore_wall_ns')} for row in preparations],
        'samples': records,
    }
    assert report['native_producer_order'] == protocol['native_producer_order']
    output = RESULT / 'loader-mechanism.json'
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'mechanism_path': str(output), 'sha256': sha(output), 'variants': summaries}, indent=2))


if __name__ == '__main__':
    main()
