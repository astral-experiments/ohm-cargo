#!/usr/bin/env bash
set -euo pipefail
r=/tmp/ohm-hillclimb-20261021/confirmation-path-cache
export TMPDIR="$r/tmp"
python3 - "$r" <<'PY'
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
sys.path.insert(0, str(root))
import diagnose_build_output
sys.path.insert(0, str(root / 'work/benchmark'))
import loader_fixture_delta
fixture_root, fixture = loader_fixture_delta.load('uv-loader-pr175')
loader_fixture_delta.check_inputs(fixture)
with (fixture_root / 'fixture.json').open('rb') as stream:
    marker_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
review = json.loads((root / 'metadata/loader-production-seeds-reviewed.json').read_text())
assert review['fixture_manifest_sha256'] == marker_sha
assert not (root / 'results/loader-native-to-check-pr175-production-confirmation').exists()
assert not any(json.loads(line)['operation'] == 'prepare' for line in (fixture_root / 'journal.jsonl').read_text().splitlines())
report = {'at': datetime.now(timezone.utc).isoformat(), 'host': diagnose_build_output.quiet_snapshot(), 'fixture_manifest_sha256': marker_sha}
path = root / 'metadata/loader-production-measurement-preflight.json'
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'phase': 'preflight-passed', 'path': str(path)}), flush=True)
PY
python3 "$r/work/benchmark/paired.py" run \
  --config "$r/work/loader-fixtures/uv-loader-pr175/paired.json" \
  --output "$r/results/loader-native-to-check-pr175-production-confirmation" \
  --phase confirmation --pairs 12 --warmup-pairs 0 --seed 2026102126
python3 "$r/work/benchmark/loader_fixture_delta.py" verify \
  --name uv-loader-pr175 --results "$r/results/loader-native-to-check-pr175-production-confirmation"
python3 "$r/work/benchmark/paired.py" analyze \
  "$r/results/loader-native-to-check-pr175-production-confirmation" \
  --confidence 0.99 --resamples 20000 --seed 1701 --minimum-pairs 12 --minimum-improvement 0.01
python3 "$r/summarize_loader_production.py"
python3 "$r/seal_results.py" seal "$r/results/loader-native-to-check-pr175-production-confirmation"
