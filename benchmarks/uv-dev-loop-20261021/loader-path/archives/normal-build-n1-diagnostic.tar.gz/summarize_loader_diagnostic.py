#!/usr/bin/env python3
"""Describe the one-pair mechanism diagnostic without statistical inference."""
from pathlib import Path
import json

ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
RESULT = ROOT / 'results/loader-native-to-check-pr175-diagnostic-01'

def main():
    manifest = json.loads((RESULT / 'manifest.json').read_text())
    samples = json.loads((RESULT / 'samples.json').read_text())
    validation = json.loads((RESULT / 'loader-fixture-validation.json').read_text())
    assert manifest['state'] == 'complete' and manifest['pairs'] == 1
    assert manifest['variant_sha256'] == manifest['variant_sha256_after']
    assert manifest['recorded_file_sha256'] == manifest['recorded_file_sha256_after']
    assert len(samples) == 2 and validation['valid'] and not validation['errors']
    assert all(sample['stage'] == 'measurement' and sample['returncode'] == 0 for sample in samples)
    details = {tuple(row['sample']): row for row in validation['samples']}
    measurements = {}
    for sample in samples:
        key = (sample['stage'], sample['pair'], sample['position'], sample['variant'])
        row = details[key]
        measurements[sample['variant']] = {
            'wall_seconds': sample['wall_ns'] / 1e9,
            'child_cpu_seconds': sample['user_seconds'] + sample['system_seconds'],
            'rustc_invocations': len(row['rustc_invocations']),
            'metadata_only_rustc_invocations': sum('link' not in command['emit'] for command in row['rustc_invocations']),
            'other_invocations': len(row['other_invocations']),
            'cached_or_executed_build_script_output_messages': len(row['build_script_outputs']),
            'fresh_artifacts': row['fresh_artifacts'], 'compiled_artifacts': row['compiled_artifacts'],
            'restore_seconds_excluded_from_timing': row['restore_wall_ns_excluded'] / 1e9,
            'native_snapshot_inventory_sha256': row['inventory_sha256'],
            'order_position': sample['position'],
        }
    baseline = measurements['baseline']['wall_seconds']
    candidate = measurements['candidate']['wall_seconds']
    report = {
        'kind': 'single-pair workflow diagnostic', 'phase': manifest['phase'], 'pairs': 1,
        'statistical_inference': None,
        'limitation': 'One restored-state pair validates the fixture and mechanism only. No confidence interval, significance test, or publishable performance claim is made.',
        'seed': manifest['seed'], 'variant_sha256': manifest['variant_sha256'],
        'measurements': measurements, 'observed_wall_speedup_ratio': baseline / candidate,
        'observed_wall_time_reduction': 1 - candidate / baseline,
        'fixture_valid': True, 'frozen_inputs_unchanged': True,
    }
    output = RESULT / 'analysis.json'
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
