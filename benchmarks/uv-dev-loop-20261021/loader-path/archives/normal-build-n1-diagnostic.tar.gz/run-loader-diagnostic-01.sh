#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/tmp/ohm-hillclimb-20261021/confirmation-path-cache/tmp
exec >/tmp/ohm-hillclimb-20261021/confirmation-path-cache/loader-diagnostic-01.log 2>&1
python3 /tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/benchmark/paired.py run --config /tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/loader-fixtures/uv-loader-pr175/paired.json --output /tmp/ohm-hillclimb-20261021/confirmation-path-cache/results/loader-native-to-check-pr175-diagnostic-01 --phase exploratory --pairs 1 --warmup-pairs 0 --seed 2026102115
python3 /tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/benchmark/loader_fixture.py verify --name uv-loader-pr175 --results /tmp/ohm-hillclimb-20261021/confirmation-path-cache/results/loader-native-to-check-pr175-diagnostic-01 >/tmp/ohm-hillclimb-20261021/confirmation-path-cache/results/loader-native-to-check-pr175-diagnostic-01/fixture-verification.stdout.json
