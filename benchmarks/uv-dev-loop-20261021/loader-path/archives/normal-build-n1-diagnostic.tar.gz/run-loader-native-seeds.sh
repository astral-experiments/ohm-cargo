#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/tmp/ohm-hillclimb-20261021/confirmation-path-cache/tmp
exec >/tmp/ohm-hillclimb-20261021/confirmation-path-cache/loader-native-seeds.log 2>&1
python3 /tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/benchmark/loader_fixture.py seed --name uv-loader-pr175 --variant baseline >/tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/loader-fixtures/uv-loader-pr175/logs/seed-baseline-driver.json
python3 /tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/benchmark/loader_fixture.py seed --name uv-loader-pr175 --variant candidate >/tmp/ohm-hillclimb-20261021/confirmation-path-cache/work/loader-fixtures/uv-loader-pr175/logs/seed-candidate-driver.json
