#!/usr/bin/env python3
"""Review sealed producer evidence before the first restored-state check."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
FIXTURE = ROOT / 'work/loader-fixtures/uv-loader-pr175'
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import loader_fixture
sys.path.insert(0, str(ROOT))
import diagnose_build_output

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    active = subprocess.run(['tmux', '-S', str(ROOT / 'tmux.sock'), 'has-session', '-t', 'loader-native-seeds'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    assert active.returncode != 0, 'Native producers are still active'
    fixture = json.loads((FIXTURE / 'fixture.json').read_text())
    loader_fixture.check_inputs(fixture)
    report = {'reviewed_at': datetime.now(timezone.utc).isoformat(), 'fixture_manifest_sha256': sha(FIXTURE / 'fixture.json'), 'variants': {}, 'host': diagnose_build_output.quiet_snapshot()}
    for variant in ('baseline', 'candidate'):
        snapshot = FIXTURE / 'snapshots' / variant
        record = json.loads((snapshot / 'manifest.json').read_text())
        runs = json.loads((snapshot / 'runlist.json').read_text())
        assert record['native_only'] and record['empty_live_before_seed']
        assert record['cargo_sha256'] == fixture['variant_sha256'][variant]
        assert record['result']['returncode'] == 0
        assert sha(snapshot / 'inventory.jsonl') == record['inventory_sha256']
        assert sha(snapshot / 'runlist.json') == record['runlist_sha256']
        assert sha(FIXTURE / f'logs/seed-{variant}.stdout') == record['stdout_sha256']
        assert sha(FIXTURE / f'logs/seed-{variant}.stderr') == record['stderr_sha256']
        assert runs['rustc_invocations'] and not runs['checking_packages']
        assert all('link' in invocation['emit'] for invocation in runs['rustc_invocations'])
        test_executables = {artifact['executable'] for artifact in runs['artifacts'] if artifact['profile']['test'] and artifact['executable']}
        assert all(not any(argument in test_executables for argument in invocation) for invocation in runs['other_invocations']), 'Test binary appears in native producer commands'
        assert '--no-run' in record['command'] and 'test' in record['command']
        report['variants'][variant] = {
            'snapshot_manifest_sha256': sha(snapshot / 'manifest.json'),
            'inventory_sha256': record['inventory_sha256'], 'runlist_sha256': record['runlist_sha256'],
            'cargo_sha256': record['cargo_sha256'], 'native_only': True,
            'rustc_invocations': len(runs['rustc_invocations']), 'metadata_only_invocations': 0,
            'other_invocations': len(runs['other_invocations']),
            'other_executable_basenames': sorted({Path(invocation[0]).name for invocation in runs['other_invocations'] if invocation}),
            'compiled_test_executables': len(test_executables), 'test_executions_in_runlist': 0,
            'provenance': record['provenance'], 'files': record['files'], 'logical_bytes': record['logical_bytes'],
        }
    output = ROOT / 'metadata/loader-seeds-reviewed.json'
    assert not output.exists()
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'metadata': str(output), 'metadata_sha256': sha(output), 'variants': report['variants']}, indent=2))

if __name__ == '__main__':
    main()
