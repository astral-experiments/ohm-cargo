#!/usr/bin/env python3
"""Bind the real PR175 loader pair to the prepared native-to-check fixture."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
BASELINE = 'cargo-pr175-baseline-normal'
CANDIDATE = 'cargo-pr175-loader-v2-normal'
EXPECTED = {
    f'binaries/stripped/{BASELINE}': 'dce914c275bc0af42719d92c74477e964e51c27cd5c5aa57260627fbbf747136',
    f'binaries/stripped/{CANDIDATE}': 'b9c111d7c637aa777c632b109ffdb1e98e246a97dc72daf4bfa418a53c054a45',
    f'binaries/{CANDIDATE}.source.patch': '714656051b9beb7aaeae0502164196f12aa40257cc217ced1112d9935a4a2086',
    'production-build/pr175.patch': '30332415e2fdc6735719868cddeeb717cc856415f8cd1731ab5696c109f697dc',
    'patches/loader-path-v2-final.patch': 'be2146042f257eb1e36f3d5de804a2ff991f87676b5fe38fe4a5d6a30c4ea1e9',
}

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def main():
    assert not (ROOT / 'work/loader-fixtures/uv-loader-pr175').exists()
    prepared = read(ROOT / 'metadata/loader-fixture-prepared.json')
    for name, expected in prepared['record_file_sha256'].items():
        assert sha(name) == expected, f'Prepared input changed: {name}'
    for name, expected in EXPECTED.items():
        assert sha(ROOT / name) == expected, f'Incorrect frozen asset: {name}'
    builds = {name: read(ROOT / f'binaries/{name}.build.json') for name in (BASELINE, CANDIDATE)}
    for key in ('command', 'explicit_build_environment', 'source_path', 'target_path', 'base_commit', 'pgo'):
        assert builds[BASELINE][key] == builds[CANDIDATE][key], f'Build mismatch: {key}'
    for name in (BASELINE, CANDIDATE):
        stripped = read(ROOT / f'binaries/stripped/{name}.json')
        assert stripped['source_sha256'] == builds[name]['sha256']
        assert stripped['stripped_sha256'] == EXPECTED[f'binaries/stripped/{name}']
        assert builds[name]['returncode'] == 0
    assert builds[CANDIDATE]['source_diff_sha256'] == EXPECTED[f'binaries/{CANDIDATE}.source.patch']
    assert builds[CANDIDATE]['source_tree'] == 'fce366b238ace1b2021808769d857aa56eadcd56'
    pending = ROOT / 'work/benchmark/loader-pr175-template.pending.json'
    assert sha(pending) == prepared['template_sha256']
    cfg = read(pending)
    cfg['variants']['candidate'] = str(ROOT / f'binaries/stripped/{CANDIDATE}')
    additions = [f'binaries/{name}.build.json' for name in (BASELINE, CANDIDATE)]
    additions += [f'binaries/stripped/{CANDIDATE}.json', f'binaries/{CANDIDATE}.source.patch', 'production-build/pr175.patch', 'patches/loader-path-v2-final.patch']
    cfg['record_files'] = list(dict.fromkeys(cfg['record_files'] + [str(ROOT / name) for name in additions]))
    environment = os.environ.copy()
    for key, value in cfg['env'].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    linked = subprocess.run(['ldd', cfg['variants']['candidate']], env=environment, capture_output=True, text=True, check=True)
    paths = []
    for line in linked.stdout.splitlines():
        match = re.search(r'(?:=>\s*)?(/\S+)\s+\(', line)
        if match:
            paths.append(str(Path(match[1]).resolve(strict=True)))
    assert sorted(set(paths)) == prepared['resolved_dynamic_libraries'], 'Runtime libraries differ'
    template = ROOT / 'work/benchmark/loader-pr175-template.json'
    assert not template.exists()
    template.write_text(json.dumps(cfg, indent=2) + '\n')
    metadata = {
        'finalized_at': datetime.now(timezone.utc).isoformat(),
        'state': 'real pair frozen; approved for fixture initialization and native seeds',
        'template': str(template), 'template_sha256': sha(template),
        'variant_sha256': {name: EXPECTED[f'binaries/stripped/{binary}'] for name, binary in [('baseline', BASELINE), ('candidate', CANDIDATE)]},
        'record_file_sha256': {path: sha(path) for path in cfg['record_files']},
        'matching_build_fields': ['command', 'explicit_build_environment', 'source_path', 'target_path', 'base_commit', 'pgo'],
        'resolved_dynamic_libraries': sorted(set(paths)),
        'diagnostic_plan': {'phase': 'exploratory', 'pairs': 1, 'warmup_pairs': 0, 'seed': 2026102115},
    }
    output = ROOT / 'metadata/loader-fixture-finalized.json'
    assert not output.exists()
    output.write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps({'metadata': str(output), 'metadata_sha256': sha(output), 'template_sha256': sha(template), 'candidate_sha256': metadata['variant_sha256']['candidate']}))

if __name__ == '__main__':
    main()
