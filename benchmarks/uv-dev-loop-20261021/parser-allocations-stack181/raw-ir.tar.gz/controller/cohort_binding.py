"""Fail-closed data bindings for the new cohort; no workload or host operations."""
import hashlib
import json
import os
from pathlib import Path
import re

ROOT = '/tmp/ohm-hillclimb-20261021/parser-allocations-stack181'
HOST = 'charlie-oss-4'
CONTROLLER_PATH = ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin'
PROTOCOL_SHA = '9bb9f6348d8d845c53bf70502968e31842cebaff752a1afac1d246d8fb0367b3'
SOURCE_COMMIT = 'e546abb9353061a13a2448e7b42df52d6ac520fc'
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': 'eaf2be878e89248d1ceabff75ce7d2d3272224dd'}
OLD_BINARIES = {'3164f9287711f122fa9636a7816ed8749598706ac5076d66051a036dcef51037',
                '3b1a2e4e3654b7b23816fbb54c51072cb356486c36052a5bcd6c4d3d2e6a07e9'}
JOBS = {'Resolver tests', 'Schema tests', 'Rustfmt', 'Workspace tests',
        'Clippy (depot-ubuntu-24.04-8)', 'Clippy (depot-macos-15)',
        'Cargo tests (depot-ubuntu-24.04-16)', 'Cargo tests (depot-macos-15)'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(value):
    assert isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'Unbound or invalid digest'
    assert value != '0' * 64, 'Placeholder digest'
    return value


def validate_input_approval(value, source_freeze_sha256):
    assert value['status'] == 'passed' and value['scope'] == 'parser-allocations-production-inputs'
    assert value['source_freeze_sha256'] == digest(source_freeze_sha256)
    assert value['protocol_sha256'] == PROTOCOL_SHA
    assert value['root'] == ROOT and value['host'] == HOST
    assert value['source_commit'] == SOURCE_COMMIT and value['source_trees'] == TREES
    assert value['controller_path'] == CONTROLLER_PATH
    assert value['cohort'] == 'host2-parser-allocations-stack181'
    assert set(value['variants']) == {'baseline', 'candidate'}
    assert len(set(value['variants'].values())) == 2
    for item in value['variants'].values():
        assert digest(item) not in OLD_BINARIES
    for name in ('pair_audit_sha256', 'pair_review_sha256', 'common_build_inputs_sha256',
                 'production_manifest_sha256', 'production_driver_sha256',
                 'source_ci_sha256', 'correctness_seal_sha256', 'host_readback_sha256'):
        digest(value[name])
    assert re.fullmatch('[a-z0-9][a-z0-9-]*', value['host_readback_label'])
    assert value['checks'] == {'fresh_matched_pair': True, 'production_audit_passed': True,
        'source_ci_passed': True, 'correctness_53_passed': True, 'quiet_host_root_absent': True}
    return value


def load_input_approval(directory):
    directory = Path(directory)
    return validate_input_approval(json.loads((directory / 'input-approval.json').read_text()),
                                   sha(directory / 'source-freeze.json'))


def validate_ci(ci):
    assert ci['source_commit'] == SOURCE_COMMIT and ci['source_tree'] == TREES['candidate']
    assert ci['raw_run']['head_sha'] == SOURCE_COMMIT
    assert ci['raw_run']['status'] == 'completed' and ci['raw_run']['conclusion'] == 'success'
    assert {row['name'] for row in ci['required_jobs']} == JOBS
    assert len(ci['required_jobs']) == len(JOBS)
    assert all(row['conclusion'] == 'success' for row in ci['required_jobs'])


def require_controller_environment():
    assert os.environ.get('PATH') == CONTROLLER_PATH
    assert not any(name in os.environ for name in ('PYTHONHOME', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONINSPECT'))
    assert os.sched_getaffinity(0) == {8}, 'Controller must stay outside measured CPUs 0-7'


def translate_reference(value):
    old = '/tmp/ohm-hillclimb-20261021-inheritance-measurement'
    names = {'inheritance-stack180-baseline': 'parser-allocations-stack181-baseline',
             'inheritance-stack180-shared': 'parser-allocations-stack181-reduced'}
    if isinstance(value, str):
        value = value.replace(old, ROOT)
        for before, after in names.items():
            value = value.replace(before, after)
        return value
    if isinstance(value, list):
        return [translate_reference(item) for item in value]
    if isinstance(value, dict):
        return {key: translate_reference(item) for key, item in value.items()}
    return value


def validate_base_config(config, reference):
    expected = translate_reference(reference)
    assert {key: value for key, value in config.items() if key not in ('record_files', 'env')} == {
        key: value for key, value in expected.items() if key not in ('record_files', 'env')}
    assert set(expected['env']) <= set(config['env'])
    assert all(config['env'][key] == value for key, value in expected['env'].items())
    assert all(value is None for key, value in config['env'].items() if key not in expected['env'])
    assert config['record_files'][:len(expected['record_files'])] == expected['record_files']
    assert len(config['record_files']) == len(set(config['record_files']))
    return expected


def runtime_aliases(root):
    result = {}
    for prefix in ('ohm', 'profiling-tools'):
        for path in sorted((Path(root) / prefix).rglob('*')):
            if path.is_symlink():
                resolved = path.resolve()
                result[str(path)] = {'target': os.readlink(path), 'resolved': str(resolved),
                                     'sha256': sha(resolved) if resolved.is_file() else None}
    return result
