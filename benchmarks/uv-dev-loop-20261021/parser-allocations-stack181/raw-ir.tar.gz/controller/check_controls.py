#!/usr/bin/env python3
"""Pure source/synthetic checks; no historical effects, hosts, Cargo or fixtures."""
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(HERE))
import cohort_binding as binding
import native_approval


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def functions(path):
    return {node.name: node for node in ast.parse(path.read_text()).body if isinstance(node, ast.FunctionDef)}


def dump(node):
    return ast.dump(node, include_attributes=False)


def rejected(action):
    try:
        action()
    except (AssertionError, ValueError, KeyError, TypeError):
        return
    raise AssertionError('Malformed synthetic input was accepted')


checks = []
driver = load('parser_allocations_control_checks', HERE / 'driver.py')
sys.path.insert(0, str(HERE / 'reviewer'))
review = load('parser_allocations_review_checks', HERE / 'reviewer/review.py')
statistics_review = sys.modules['statistics_review']
for path in HERE.rglob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
checks.append('Every controller/reviewer source parses without executing any entry point')

old = functions(WORK / 'inheritance-measurement/driver.py')
new = functions(HERE / 'driver.py')
unchanged_driver = ('read', 'sha', 'load_module', 'paths', 'phase_status', 'configuration_catalog',
    'derive', 'audit_sample_tables', 'prepare', 'verify_seal', 'audit_ir', 'gate', 'run_phase', 'main')
for name in unchanged_driver:
    assert dump(old[name]) == dump(new[name]), name
checks.append('All 14 fixed driver sampling, preparation, raw-audit, statistics and entry functions have identical ASTs')
native = copy.deepcopy(new['native_prerequisite'])
native.body = [node for node in native.body if not (
    isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'accepted_review_files' for target in node.targets)
    or isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
    and dump(node.value.func) == dump(ast.parse('hashes.update').body[0].value))]
assert dump(native) == dump(old['native_prerequisite'])
checks.append('Native prerequisite only adds independent review validation and its exact hash-bound payloads')
old_review = functions(WORK / 'inheritance-raw-review/review.py')
new_review = functions(HERE / 'reviewer/review.py')
for name in set(old_review) - {'main', 'machine'}:
    assert dump(old_review[name]) == dump(new_review[name]), name
checks.append('All 12 independent raw/profile/chronology/statistical functions have identical ASTs')
old_machine = ast.get_source_segment((WORK / 'inheritance-raw-review/review.py').read_text(), old_review['machine'])
assert dump(ast.parse(old_machine.replace("set(range(8)) <= set(value['affinity'])", "set(value['affinity']) == {8}")).body[0]) == dump(new_review['machine'])
machine = {'uname': ['Linux', 'charlie-oss-4'], 'uid': 1000, 'effective_uid': 1000,
           'root_directory_owner_uid': 0, 'affinity': [8]}
review.machine(machine)
rejected(lambda: review.machine({**machine, 'affinity': list(range(32))}))
checks.append('Controller machine identity changes only to exact CPU8; timed commands retain explicit CPUs0-7')
for name, reference in [('occupancy.py', WORK / 'inheritance-measurement/occupancy.py'),
                        ('reviewer/statistics_review.py', WORK / 'inheritance-raw-review/statistics_review.py')]:
    assert (HERE / name).read_bytes() == reference.read_bytes()
checks.append('Occupancy guard and independent statistics implementation are byte-identical')

protocol = json.loads((HERE / 'protocol.json').read_text())
assert binding.sha(HERE / 'protocol.json') == binding.PROTOCOL_SHA
assert driver.STAGES['ir']['plan'] == [('check', 20261021121), ('test', 20261021122)]
assert driver.STAGES['native']['plan'] == [('check', 20261021123), ('test', 20261021124)]
assert driver.STAGES['ir']['pairs'] == 12 and driver.STAGES['native']['pairs'] == 30
for phase in driver.STAGES:
    assert dict(driver.STAGES[phase]['plan']) == protocol[phase]['seeds']
    for _, seed in driver.STAGES[phase]['plan']:
        rows = review.plan(driver.STAGES[phase]['pairs'], seed) + review.plan(2, seed ^ 0x5A17)
        assert len(rows) == driver.STAGES[phase]['pairs'] + 2
checks.append('Exact four seeds, 12/30 pairs and two warmup pairs match the prospective protocol')

for phase in ('ir', 'native'):
    for workflow in ('check', 'test'):
        reference = json.loads((HERE / 'references/base-configs' / (phase + '-' + workflow + '.json')).read_text())
        translated = binding.translate_reference(reference)
        assert len(reference['record_files']) == 760
        binding.validate_base_config(translated, reference)
        removed = copy.deepcopy(translated)
        removed['record_files'].pop()
        rejected(lambda: binding.validate_base_config(removed, reference))
        edited = copy.deepcopy(translated)
        edited['prepare_command'].append('--release')
        rejected(lambda: binding.validate_base_config(edited, reference))
        extra = copy.deepcopy(translated)
        extra['env']['RUSTUP_TOOLCHAIN'] = None
        binding.validate_base_config(extra, reference)
        extra['env']['RUSTUP_TOOLCHAIN'] = 'changed'
        rejected(lambda: binding.validate_base_config(extra, reference))
checks.append('All four full 760-input prefixes and commands survive translation; omitted inputs/changed commands/non-null extra environment reject')

with patch.dict('os.environ', {'PATH': binding.CONTROLLER_PATH}, clear=True), patch('os.sched_getaffinity', return_value={8}):
    binding.require_controller_environment()
    with patch.dict('os.environ', {'PATH': '/usr/bin:/bin'}):
        rejected(binding.require_controller_environment)
    with patch('os.sched_getaffinity', return_value={0, 8}):
        rejected(binding.require_controller_environment)
    with patch.dict('os.environ', {'PYTHONPATH': 'unexpected'}):
        rejected(binding.require_controller_environment)
checks.append('Controller exact PATH, CPU8 and clean Python environment fail closed')

identity = {name: hashlib.sha256(name.encode()).hexdigest() for name in ('source', 'seal', 'baseline', 'candidate', 'reviewer', 'launch')}
approval = {'status': 'passed', 'scope': 'parser-allocations-production-inputs',
    'source_freeze_sha256': identity['source'], 'protocol_sha256': binding.PROTOCOL_SHA,
    'root': binding.ROOT, 'host': binding.HOST, 'source_commit': binding.SOURCE_COMMIT,
    'source_trees': binding.TREES, 'controller_path': binding.CONTROLLER_PATH,
    'cohort': 'host2-parser-allocations-stack181',
    'variants': {key: identity[key] for key in ('baseline', 'candidate')}, 'host_readback_label': 'synthetic-only',
    'checks': {'fresh_matched_pair': True, 'production_audit_passed': True, 'source_ci_passed': True,
               'correctness_53_passed': True, 'quiet_host_root_absent': True}}
for name in ('pair_audit_sha256', 'pair_review_sha256', 'common_build_inputs_sha256', 'production_manifest_sha256',
             'production_driver_sha256', 'source_ci_sha256', 'correctness_seal_sha256', 'host_readback_sha256'):
    approval[name] = hashlib.sha256(name.encode()).hexdigest()
binding.validate_input_approval(approval, identity['source'])
for field, replacement in [('host', 'charlie-oss-2'), ('root', binding.ROOT + '-other'), ('status', 'pending'),
                           ('protocol_sha256', None), ('pair_audit_sha256', '0' * 64), ('source_trees', {}),
                           ('host_readback_label', '../unsafe'), ('checks', {})]:
    malformed = copy.deepcopy(approval)
    malformed[field] = replacement
    rejected(lambda: binding.validate_input_approval(malformed, identity['source']))
for replacement in (None, '0' * 64, next(iter(binding.OLD_BINARIES)), identity['baseline']):
    malformed = copy.deepcopy(approval)
    malformed['variants']['candidate'] = replacement
    rejected(lambda: binding.validate_input_approval(malformed, identity['source']))
checks.append('Real-input schema rejects pending/zero/missing/old or equal binaries, wrong source/host/root/protocol and unsafe receipt labels')

ci = {'source_commit': binding.SOURCE_COMMIT, 'source_tree': binding.TREES['candidate'],
      'raw_run': {'head_sha': binding.SOURCE_COMMIT, 'status': 'completed', 'conclusion': 'success'},
      'required_jobs': [{'name': name, 'conclusion': 'success'} for name in sorted(binding.JOBS)]}
binding.validate_ci(ci)
for mutate in (lambda value: value['required_jobs'].pop(),
               lambda value: value['required_jobs'][0].update(conclusion='skipped'),
               lambda value: value['raw_run'].update(head_sha='0' * 40)):
    malformed = copy.deepcopy(ci)
    mutate(malformed)
    rejected(lambda: binding.validate_ci(malformed))
checks.append('CI requires exact source head/tree and all eight required successful jobs')

with tempfile.TemporaryDirectory(prefix='parser-allocation-pure-') as temporary:
    directory = Path(temporary)
    profile = directory / 'profile'
    profile.write_text('events: Dr Ir Dw\nsummary: 1 12345 2\n')
    assert review.profile_count(profile) == 12345
    for bad in ('events: Ir Ir\nsummary: 1 2\n', 'events: Ir\nsummary: 1\nsummary: 2\n',
                'events: Dr\nsummary: 1\n', 'events: Ir\nsummary: -1\n'):
        profile.write_text(bad)
        rejected(lambda: review.profile_count(profile))
    checks.append('Actual profile parser selects Ir and rejects ambiguous, duplicate, absent or negative counters')
    for phase, count in [('ir', 12), ('native', 30)]:
        pairs = [{'baseline': 102.0, 'candidate': 100.0, 'order': 'AB' if index % 2 else 'BA'} for index in range(count)]
        synthetic = statistics_review.counts(pairs) if phase == 'ir' else statistics_review.paired(pairs)
        assert statistics_review.gate(phase, synthetic)['passes_gate']
        analysis = {'confidence': 0.99, 'bootstrap_resamples': 20000, 'bootstrap_seed': 1701,
                    'metrics': {'cargo_ir': {'statistics': synthetic}}} if phase == 'ir' else {
                        **synthetic, 'grouping': {'repetitions_per_variant': 8}}
        (directory / 'analysis.json').write_text(json.dumps(analysis))
        assert driver.gate(phase, directory) == statistics_review.gate(phase, synthetic)
        broken = copy.deepcopy(synthetic)
        broken['exact_two_sided_sign_p'] = 0.02
        assert not statistics_review.gate(phase, broken)['passes_gate']
        key = 'geometric_mean_ratio' if phase == 'ir' else 'geometric_mean_speedup'
        broken = copy.deepcopy(synthetic)
        broken['order']['BA'][key] = 1.0
        assert not statistics_review.gate(phase, broken)['passes_gate']
    checks.append('Synthetic positive/negative decisions agree with unchanged driver and independent gates, including exact sign/order requirements')
    native = statistics_review.paired([{'baseline': 100.0, 'candidate': 103.0, 'order': 'AB' if index % 2 else 'BA'} for index in range(30)])
    assert statistics_review.gate('native', native)['significant_native_regression']
    checks.append('Independent native regression gate rejects the same synthetic 99% negative effect')

    proof = directory / 'synthetic-proof'
    raw_directory = directory / 'synthetic-raw'
    proof.mkdir()

    def write_json(path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, sort_keys=True) + '\n')
        return binding.sha(path)

    raw_names = {'results/ir-status.json'} | {
        'results/ir-' + workflow + '/' + name for workflow in ('check', 'test')
        for name in ('manifest.json', 'samples.json', 'samples.jsonl', 'samples.csv', 'integrity.json', 'analysis.json', 'gate.json')}
    raw_files = {name: write_json(raw_directory / name, {'synthetic_only': name}) for name in sorted(raw_names)}
    reviewer_sha = write_json(proof / 'review/source-freeze.json', {'synthetic_only': True})
    transfer = {'phase': 'ir', 'root': binding.ROOT, 'seal_sha256': identity['seal'], 'files': raw_files}
    transfer_sha = write_json(proof / 'collection/transfer-manifest.json', transfer)
    receipt_sha = write_json(proof / 'collection/receipt.json', {'status': 'passed', 'phase': 'ir',
        'measurement_seal_sha256': identity['seal'], 'transfer_manifest_sha256': transfer_sha})
    workflows = [{'workflow': name, 'synthetic_only': True} for name in ('check', 'test')]
    raw_sha = write_json(proof / 'review/raw-integrity.json', {'status': 'passed', 'phase': 'ir',
        'workflows': workflows, 'analysis_files_parsed': False, 'statistics_computed': False,
        'transfer_manifest_sha256': transfer_sha})
    synthetic_review = {'status': 'passed', 'phase': 'ir', 'qualifies': True, 'integrity_status': 'passed',
        'statistics_computed': True, 'final_evidence_and_review_source_rehash': 'passed',
        'source_freeze_sha256': identity['source'], 'measurement_seal_sha256': identity['seal'],
        'variants': approval['variants'], 'review_source_freeze_sha256': reviewer_sha,
        'launch_receipt_sha256': identity['launch'], 'transfer_manifest_sha256': transfer_sha,
        'bootstrap': {'confidence': 0.99, 'resamples': 20000, 'seed': 1701},
        'completed': [{'workflow': name, 'passes_gate': True} for name in ('check', 'test')],
        'workflows': workflows, 'raw_file_sha256': raw_files}
    review_sha = write_json(proof / 'review/review.json', synthetic_review)
    for workflow in ('check', 'test'):
        write_json(proof / ('review/' + workflow + '-reproduced-analysis.json'), {'synthetic_only': True})
    write_json(proof / 'root-approval.json', {'status': 'passed',
        'scope': 'parser-allocations-independent-ir-acceptance', 'source_freeze_sha256': identity['source'],
        'measurement_seal_sha256': identity['seal'], 'variants': approval['variants'],
        'reviewer_source_freeze_sha256': reviewer_sha, 'review_sha256': review_sha,
        'raw_integrity_sha256': raw_sha, 'transfer_manifest_sha256': transfer_sha,
        'collection_receipt_sha256': receipt_sha, 'launch_receipt_sha256': identity['launch']})
    proof_manifest = {'root': binding.ROOT, 'host': binding.HOST, 'controller_path': binding.CONTROLLER_PATH,
        'measurement_seal_sha256': identity['seal'], 'source_freeze_sha256': identity['source'],
        'reviewer_source_freeze_sha256': reviewer_sha, 'variants': approval['variants'],
        'files': {name: binding.sha(proof / name) for name in sorted(native_approval.REQUIRED)}}
    write_json(proof / 'manifest.json', proof_manifest)

    def validate_proof():
        return native_approval.validate_proof(proof, identity['seal'], identity['source'], reviewer_sha,
                                             approval['variants'], lambda name: raw_directory / name)

    assert validate_proof() == proof_manifest
    checks.append('Synthetic complete native prerequisite joins all eight payloads, source/variant/seal identities and original IR raw bytes')
    for missing in sorted(native_approval.REQUIRED):
        malformed = copy.deepcopy(proof_manifest)
        del malformed['files'][missing]
        write_json(proof / 'manifest.json', malformed)
        rejected(validate_proof)
        write_json(proof / 'manifest.json', proof_manifest)
        checks.append('Native prerequisite rejects missing manifest binding: ' + missing)
    for name, field, value in [('root-approval.json', 'source_freeze_sha256', 'wrong'),
                               ('review/review.json', 'qualifies', False),
                               ('review/review.json', 'review_source_freeze_sha256', 'wrong'),
                               ('review/raw-integrity.json', 'statistics_computed', True),
                               ('collection/receipt.json', 'status', 'failed')]:
        original = (proof / name).read_bytes()
        malformed = json.loads(original)
        malformed[field] = value
        new_hash = write_json(proof / name, malformed)
        changed = copy.deepcopy(proof_manifest)
        changed['files'][name] = new_hash
        write_json(proof / 'manifest.json', changed)
        rejected(validate_proof)
        (proof / name).write_bytes(original)
        write_json(proof / 'manifest.json', proof_manifest)
        checks.append('Native prerequisite rejects altered accepted metadata: ' + name + '/' + field)
    original = (raw_directory / 'results/ir-status.json').read_bytes()
    (raw_directory / 'results/ir-status.json').write_bytes(original + b' ')
    rejected(validate_proof)
    (raw_directory / 'results/ir-status.json').write_bytes(original)
    checks.append('Native prerequisite rejects changed raw IR bytes before any calls')
    assert validate_proof() == proof_manifest

# No runtime entry can run during these checks: validate only the emitted code strings.
for filename in ('readback_host.py', 'stage.py', 'collect.py'):
    tree = ast.parse((HERE / filename).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'remote' for target in node.targets):
            value = node.value
            while isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute):
                value = value.func.value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                ast.parse(value.value)
checks.append('Every embedded remote controller parses; no remote statement was executed')
prepare = (HERE / 'prepare_host.py').read_text()
assert "command('uv-public-fetch', [str(baseline), '-Zohm-defaults=yes', 'fetch', '--locked']" in prepare
assert "'--prepare'" in prepare and "'--run-phase'" not in prepare
assert 'ref.preflight(' not in prepare
checks.append('Metadata preparation only fetches dependencies and seals inputs; fixed fixture warming is in the separately approved phase entry')
for forbidden in ('input-approval.json', 'source-review.json', 'delivery', 'collections', 'native-prerequisite', 'setup-review.json'):
    assert not (HERE / forbidden).exists(), forbidden
checks.append('No placeholder approval, delivery, fixture, collection or native prerequisite has been produced')

report = {'status': 'passed', 'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Source ASTs, reference configuration data, and temporary synthetic metadata/statistics only; no actual effects or hosts.',
    'checks': checks, 'count': len(checks), 'driver_unchanged_functions': list(unchanged_driver),
    'reviewer_unchanged_functions': sorted(set(old_review) - {'main', 'machine'}),
    'source_sha256': {str(path.relative_to(HERE)): binding.sha(path) for path in sorted(HERE.rglob('*.py'))}}
destination = HERE / 'pure-checks.json'
with destination.open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
