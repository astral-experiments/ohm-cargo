#!/usr/bin/env python3
"""Pure source and actual immutable proof-schema checks; no host or fixture entry."""
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
OLD = WORK / 'parser-allocations-measurement-controls-local-v3'
sys.path.insert(0, str(HERE))
import cohort_binding as binding


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def rejected(call):
    try:
        call()
    except (AssertionError, KeyError, TypeError, ValueError):
        return
    raise AssertionError('Invalid proof was accepted')


assert os.sched_getaffinity(0) == {8}
prep = read(HERE / 'preparation-inputs.json')
amendment = read(HERE / 'host-assignment-amendment.json')
assert sha(OLD / 'source-freeze.json') == prep['previous_source_freeze_sha256'] == amendment['original_source_freeze_sha256']
assert amendment['original_host'] == 'charlie-oss' and amendment['amended_host'] == binding.HOST == 'charlie-oss-4'
assert amendment['canonical_root'] == binding.ROOT
assert sha(HERE / 'protocol.json') == sha(OLD / 'protocol.json') == binding.PROTOCOL_SHA
checks = ['Actual predecessor freeze and original protocol bytes match the prospective host assignment']
for name, digest in prep['original_frozen_source_files'].items():
    assert sha(OLD / name) == sha(HERE / 'history/local-v3' / name) == digest, name
checks.append('All 107 original frozen source files remain byte-identical and are retained in history')
changed = []
for name in prep['runtime_files'] + ['check_controls.py']:
    original = (OLD / name).read_text()
    expected = original.replace("'charlie-oss'", "'charlie-oss-4'")
    if name == 'readback_host.py':
        expected = expected.replace('Future read-only local-host admission snapshot', 'Future read-only host4 admission snapshot')
        expected = expected.replace('read-only-local-host-admission', 'read-only-host4-admission')
    actual = (HERE / name).read_text()
    assert actual == expected, name
    ast.parse(actual)
    if actual != original:
        changed.append(name)
checks.append('All runtime bytes equal only the explicit hostname and admission-description/operation substitutions')
for name in ('driver.py', 'reviewer/evidence.py', 'reviewer/review.py', 'reviewer/review_setup.py', 'reviewer/statistics_review.py', 'occupancy.py', 'native_approval.py', 'prepare_native.py'):
    before = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse((OLD / name).read_text()).body if isinstance(node, ast.FunctionDef)}
    after = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse((HERE / name).read_text()).body if isinstance(node, ast.FunctionDef)}
    assert before.keys() == after.keys()
    for function in before:
        if (name, function) != ('driver.py', 'verify_assets'):
            assert before[function] == after[function], (name, function)
checks.append('Every raw/statistical/sampling/preflight/gate function AST is unchanged; verify_assets only changes its hostname literal')
for name in ('occupancy.py', 'native_approval.py', 'prepare_native.py', 'reviewer/review.py', 'reviewer/review_setup.py', 'reviewer/statistics_review.py'):
    assert (HERE / name).read_bytes() == (OLD / name).read_bytes()
checks.append('All original occupancy thresholds/exclusions and six complete runtime modules are byte-identical')
for phase in ('ir', 'native'):
    for workflow in ('check', 'test'):
        name = f'references/base-configs/{phase}-{workflow}.json'
        assert (HERE / name).read_bytes() == (OLD / name).read_bytes()
checks.append('Four reference configurations are byte-identical, including commands, sample counts, seeds and CPU assignments')

spec = importlib.util.spec_from_file_location('host4_source_only_driver', HERE / 'driver.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
assert driver.STAGES['ir']['plan'] == [('check', 20261021121), ('test', 20261021122)]
assert driver.STAGES['native']['plan'] == [('check', 20261021123), ('test', 20261021124)]
assert amendment['ir'] == {'workflow_order': ['check', 'test'], 'pairs': 12, 'warmup_pairs': 2, 'seeds': {'check': 20261021121, 'test': 20261021122}}
assert amendment['native'] == {'conditional_on_both_ir_gates': True, 'workflow_order': ['check', 'test'], 'pairs': 30, 'warmup_pairs': 2, 'calls_per_group': 8, 'seeds': {'check': 20261021123, 'test': 20261021124}}
checks.append('The exact check-then-test plans, 12+2 IR and conditional 30x8+2 native controls are retained')

# Execute the actual four original statements, not a reimplementation of their
# schema. Supply only immutable local build proof objects; no staged root exists.
tree = ast.parse((HERE / 'driver.py').read_text())
verify = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'verify_assets')
start = next(i for i, node in enumerate(verify.body) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'pair_review' for target in node.targets))
nodes = verify.body[start:start + 4]
assert isinstance(nodes[0], ast.Assign) and all(isinstance(node, ast.Assert) for node in nodes[1:])
assert "pair_review['variants']" in ast.unparse(nodes[-1])
proof_code = compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(nodes), type_ignores=[])), '<exact-production-review-statements>', 'exec')
cohort = WORK / 'production-build/host2-parser-allocations-stack181'
pair = read(cohort / 'results/root-pair-review.json')
assert sha(cohort / 'results/root-pair-review.json') == '32fbb1901bdd40b93c275bd136f8d910765cc039e1a91b92d5824be97cc41d46'
audit = read(cohort / 'results/audit-pair.json')
variants = {variant: next(row['stripped_sha256'] for row in audit['records'] if row['variant'] == name) for variant, name in driver.NAMES.items()}


def check_pair(value):
    scope = {'read': lambda path: value, 'cohort': cohort, 'sha': sha, 'assets': {'variants': variants}, 'NAMES': driver.NAMES}
    exec(proof_code, scope)


check_pair(pair)
checks.append('The exact driver production-review statements pass the actual frozen variants schema and audit linkage')
for kind in ('obsolete-binaries-key', 'missing-candidate', 'extra-variant', 'changed-baseline', 'pending', 'failed-check', 'wrong-audit'):
    value = copy.deepcopy(pair)
    if kind == 'obsolete-binaries-key':
        value['binaries'] = value.pop('variants')
    elif kind == 'missing-candidate':
        del value['variants'][driver.NAMES['candidate']]
    elif kind == 'extra-variant':
        value['variants']['unrelated'] = '1' * 64
    elif kind == 'changed-baseline':
        value['variants'][driver.NAMES['baseline']] = '1' * 64
    elif kind == 'pending':
        value['status'] = 'pending'
    elif kind == 'failed-check':
        value['checks'][next(iter(value['checks']))] = False
    else:
        value['pair_audit_sha256'] = '1' * 64
    rejected(lambda: check_pair(value))
    checks.append('Actual production-review statements reject ' + kind)
binding.validate_ci(read(WORK / 'parser-allocations-publication/ci-complete.json'))
correctness = read(WORK / 'parser-allocations-candidate/correctness-seal.json')
reviewed = read(WORK / 'parser-allocations-candidate/root-correctness-review.json')
assert correctness['status'] == reviewed['status'] == 'passed' and correctness['tests'] == 53
assert reviewed['tests'] == {'inheritable_workspace_fields': 28, 'lints_table': 25}
assert reviewed['correctness_seal_sha256'] == sha(WORK / 'parser-allocations-candidate/correctness-seal.json')
assert reviewed['source_tree'] == binding.TREES['candidate'] and reviewed['source_unchanged'] and reviewed['all_selected_tests_executed_and_passed']
checks.append('Actual 53-test correctness and exact eight-job successful CI proof schemas retain their original source identities')

index = read(HERE / 'lineage-index.json')
for name, row in index['copied'].items():
    assert sha(WORK / name) == sha(HERE / row['retained_as']) == row['sha256'], name
    assert (WORK / name).stat().st_ino == row['inode']
retention = read(HERE / 'lineage/root-retention-review.json')
assert sha(HERE / 'lineage/root-retention-review.json') == amendment['retention_review_sha256'] == '0d6ba9c1fe8c757c472bffde6531d32501f075281e09e0b6b992d26643aff8e8'
assert retention['status'] == 'retention-verified-capture-remains-failed'
assert retention['archive_sha256'] == amendment['failed_archive_sha256']
assert retention['before_after_inventory_sha256'] == amendment['failed_inventory_sha256']
assert amendment['capture_stays_failed'] and amendment['sshd_cwd_remains_unqualified'] and amendment['preliminary_probe_is_not_admission']
checks.append('Failure, capture, root-retention and preliminary-probe metadata retain original bytes/inodes without qualifying the old cohort')
boundary = read(HERE / 'setup-boundary-clarification.json')
old_boundary = read(OLD / 'setup-boundary-clarification.json')
assert boundary['host_assignment_amendment_sha256'] == sha(HERE / 'host-assignment-amendment.json')
assert boundary['root_assignment']['host'] == binding.HOST
boundary['host_assignment_amendment_sha256'] = old_boundary['host_assignment_amendment_sha256']
boundary['root_assignment'] = old_boundary['root_assignment']
assert boundary == old_boundary
checks.append('Four-config sealing before every workload action is unchanged; only host-assignment metadata differs')
for name in ('source-review.json', 'input-approval.json', 'delivery', 'collections', 'setup-review.json', 'native-prerequisite'):
    assert not (HERE / name).exists(), name
checks.append('No current approval, delivery, setup, fixture or phase result was manufactured')
report = {'status': 'passed', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'count': len(checks), 'checks': checks,
          'runtime_changed': changed, 'pair_review_sha256': sha(cohort / 'results/root-pair-review.json'),
          'variants': variants, 'exact_proof_statement_ast_sha256': hashlib.sha256(ast.dump(ast.Module(body=nodes, type_ignores=[]), include_attributes=False).encode()).hexdigest(),
          'scope': 'Source and immutable proof schemas only. No host, staged-root probe, fixture, effects or workload entry.',
          'full_verify_assets_called': False, 'check_source_sha256': sha(Path(__file__)),
          'source_sha256': {name: sha(HERE / name) for name in prep['runtime_files']}}
with (HERE / 'migration-checks.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'count': len(checks)}, indent=2))
