#!/usr/bin/env python3
"""Freeze prospective host4 controls after pure checks, without operational entry."""
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
OLD = WORK / 'parser-allocations-measurement-controls-local-v3'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


assert not (HERE / 'source-freeze.json').exists()
prep = read(HERE / 'preparation-inputs.json')
pure = read(HERE / 'pure-checks.json')
checks = read(HERE / 'migration-checks.json')
assert pure['status'] == checks['status'] == 'passed' and pure['count'] == 32
assert checks['check_source_sha256'] == sha(HERE / 'check_migration.py')
for name, digest in checks['source_sha256'].items():
    assert sha(HERE / name) == digest, name
for name, digest in pure['source_sha256'].items():
    assert sha(HERE / name) == digest, name
for path in HERE.rglob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
for name, digest in prep['external_inputs'].items():
    assert sha(WORK / name) == digest, name
for name, digest in prep['original_frozen_source_files'].items():
    assert sha(OLD / name) == sha(HERE / 'history/local-v3' / name) == digest, name
for name, row in read(HERE / 'lineage-index.json')['copied'].items():
    assert sha(WORK / name) == sha(HERE / row['retained_as']) == row['sha256']
    assert (WORK / name).stat().st_ino == row['inode']
assert sha(HERE / 'protocol.json') == '9bb9f6348d8d845c53bf70502968e31842cebaff752a1afac1d246d8fb0367b3'

delta = ''.join(''.join(difflib.unified_diff((OLD / name).read_text().splitlines(True),
    (HERE / name).read_text().splitlines(True), fromfile='local-v3/' + name, tofile='host4-v1/' + name))
    for name in prep['runtime_files'] + ['check_controls.py'])
with (HERE / 'source-delta.diff').open('x') as stream:
    stream.write(delta)
reviewer = read(OLD / 'reviewer/source-freeze.json')
reviewer.update(host='charlie-oss-4', recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_source_freeze_sha256=sha(OLD / 'reviewer/source-freeze.json'),
    host_assignment_amendment_sha256=sha(HERE / 'host-assignment-amendment.json'),
    scope='Prospective host4 reviewer; only evidence.HOST changes. All raw/statistical functions are unchanged.')
reviewer['files'] = {name: sha(HERE / 'reviewer' / name) for name in reviewer['files']}
write(HERE / 'reviewer/source-freeze.json', reviewer)
with (HERE / 'README.md').open('x') as stream:
    stream.write('''# Parser controls for a fresh host4 cohort

This prospective successor assigns the unchanged full protocol to charlie-oss-4,
at /tmp/ohm-hillclimb-20261021/parser-allocations-stack181. The previous local
cohort and its capture remain failed. The archive, byte-identical full inventories,
all 28 check profiles and failure/approval lineage remain preserved. No earlier
observation can be pooled, substituted, excluded selectively or used to qualify
the new cohort. No old metric values have been decoded.

The runtime diff changes only exact host literals and the readback description
and receipt-operation label. It retains the local-v3 production review's
`variants` key. The actual frozen production review is tested by executing the
exact four driver proof statements against immutable local proof data, including
seven rejection cases. This is a data/schema check; full verify_assets, the
one-shot staged-root probe and all host/setup/workload entries remain unexecuted.

The original protocol and four reference configs are byte-identical. Check then
test each have 12 IR pairs plus two warmup pairs (seeds 20261021121/122). Both
workflows must pass raw integrity and their original gates before conditional
native work: 30 paired groups of eight calls plus two warmup groups per workflow
(seeds 20261021123/124). Three fixed untimed warm commands, strict traced zero-child
and cross-switch checks, every quiet guard, CPU8 controller/CPUs0-7 workload,
53-test/eight-CI prerequisites, raw/statistical functions and acceptance gates
are unchanged. There are no retries, extensions or partial-cohort rescue.

history/local-v3 preserves all 107 prior frozen files. lineage/ preserves the
actual prior approvals, interrupted phase, capture failure, process qualification,
root retention review and preliminary host4 probe. The latter is not formal
admission. The bulky old archive/inventories are hash-bound external evidence;
they are not copied into new workload observations. Capture source metadata
retains its original 211 raw bindings. The inaccessible sshd cwd stays unqualified.
The preparation path-mapping error is retained separately; it changed no old files.

Pure checks run locally on CPU8 only. Existing 32 controls tests cover all four
configurations and the setup boundary; migration checks cover the exact source
delta, real proof schema, retained lineage and fixed plan. Every old source/input
and lineage hash is revalidated before freezing. No current execution approval,
delivery, setup, fixture or performance output is created here.

Root must review this source/amendment first, then authorize a fresh read-only
host4 admission. A new input approval and delivery, full metadata setup and
independent review of all four sealed configs must precede any phase launch.
The audited transport is unchanged apart from the host argument. The exact
next admission argv is in source-freeze.json; it is not authorized by this package.
''')
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
audit = {'status': 'passed', 'scope': 'Author source-only check, not independent approval or execution authority.',
    'recorded_at': now, 'previous_source_freeze_sha256': sha(OLD / 'source-freeze.json'),
    'source_delta_sha256': sha(HERE / 'source-delta.diff'), 'pure_checks': pure['count'],
    'migration_checks': checks['count'], 'actual_pair_review_sha256': checks['pair_review_sha256'],
    'all_raw_statistical_sampling_and_gate_functions_unchanged': True,
    'quiet_guards_unchanged': True, 'all_original_frozen_source_files_unchanged': 107,
    'external_inputs_rehashed': len(prep['external_inputs']), 'original_protocol_and_four_reference_configs_identical': True,
    'original_cohort_ineligible': True, 'capture_still_failed': True,
    'no_host_setup_workload_effects_or_github_action': True}
write(HERE / 'source-audit.json', audit)
write(HERE / 'preparation-receipt.json', {'status': 'source-only-ready-for-independent-review', 'recorded_at': now,
    'new_controls': str(HERE), 'original_controls': str(OLD), 'original_files_preserved': True,
    'source_checks_sha256': sha(HERE / 'migration-checks.json'), 'no_current_approval_or_delivery': True})
freeze = {'status': 'frozen-source-only', 'recorded_at': now, 'scope': 'Prospective fresh host4 cohort; whole interrupted local cohort stays excluded.',
    'host': 'charlie-oss-4', 'root': '/tmp/ohm-hillclimb-20261021/parser-allocations-stack181',
    'protocol_sha256': sha(HERE / 'protocol.json'), 'previous_source_freeze_sha256': sha(OLD / 'source-freeze.json'),
    'host_assignment_amendment_sha256': sha(HERE / 'host-assignment-amendment.json'),
    'reviewer_source_freeze_sha256': sha(HERE / 'reviewer/source-freeze.json'),
    'source_audit_sha256': sha(HERE / 'source-audit.json'), 'source_delta_sha256': sha(HERE / 'source-delta.diff'),
    'pure_checks': pure['count'], 'pure_checks_sha256': sha(HERE / 'pure-checks.json'),
    'migration_checks': checks['count'], 'migration_checks_sha256': sha(HERE / 'migration-checks.json'),
    'retention_review_sha256': sha(HERE / 'lineage/root-retention-review.json'),
    'lineage_index_sha256': sha(HERE / 'lineage-index.json'),
    'no_hosts_workloads_or_actual_effect_reads': True, 'no_current_approvals_or_delivery': True,
    'next_admission_argv': ['/usr/bin/taskset', '-c', '8', '/usr/bin/python3', '-I', '-B', str(HERE / 'readback_host.py'), '--label', 'host4-admission-01'],
    'files': {str(path.relative_to(HERE)): sha(path) for path in sorted(HERE.rglob('*')) if path.is_file()},
    'external_inputs': prep['external_inputs']}
write(HERE / 'source-freeze.json', freeze)
print(json.dumps({'status': 'frozen-source-only', 'source_freeze_sha256': sha(HERE / 'source-freeze.json'),
    'amendment_sha256': freeze['host_assignment_amendment_sha256'], 'reviewer_source_freeze_sha256': freeze['reviewer_source_freeze_sha256'],
    'source_delta_sha256': freeze['source_delta_sha256'], 'source_files': len(freeze['files']), 'external_inputs': len(freeze['external_inputs']),
    'pure_checks': pure['count'], 'migration_checks': checks['count'], 'next_admission_argv': freeze['next_admission_argv']}, indent=2))
