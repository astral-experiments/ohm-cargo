#!/usr/bin/env python3
"""Run the predeclared combined PR177 and PR178 native confirmations."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/tmp/ohm-hillclimb-20261021/native-pr175-confirmation')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert json.loads((ROOT/'native-path-status.json').read_text())['state']=='complete'
status={'state':'waiting for seed completion','started_at':now(),'completed':[]}
def save():
    temporary=ROOT/'native-combined-status.tmp'
    temporary.write_text(json.dumps(status,indent=2)+'\n')
    temporary.replace(ROOT/'native-combined-status.json')
save()
while True:
    seed=json.loads((ROOT/'seed-status.json').read_text())
    if seed['state']=='complete': break
    if seed['state']=='failed':
        status.update(state='blocked by failed seed',seed=seed);save();sys.exit(1)
    time.sleep(5)

steps=[('diagnose',[sys.executable,str(ROOT/'diagnose-build-output-remap-loader-v2.py')])]
runner=ROOT/'benchmark/frozen/paired_repeated.py'
assert hashlib.sha256(runner.read_bytes()).hexdigest()=='50547460e030aa73e1f48121bf477cf8f4a4538bf1bb577851af54176750b6d3'
for kind,seed in [('check',2026102143),('test',2026102144)]:
    result=ROOT/'results'/f'{kind}-build-output-remap-loader-v2-pr175-native-confirmation'
    steps.append((kind,[sys.executable,str(runner),'run','--config',str(ROOT/'benchmark'/f'{kind}-build-output-remap-loader-v2-production.json'),'--output',str(result),'--phase','confirmation','--pairs','30','--warmup-pairs','2','--seed',str(seed)]))
    steps.append((kind+'-analyze',[sys.executable,str(runner),'analyze',str(result),'--minimum-pairs','30']))
for name,command in steps:
    status.update(state='running',step=name,command=command);save()
    with (ROOT/'logs'/f'combined-confirmation-{name}.log').open('wb') as stream:
        result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        status.update(state='failed',returncode=result.returncode,finished_at=now());save();sys.exit(result.returncode)
    status['completed'].append(name);save()
status.update(state='complete',finished_at=now());save()
