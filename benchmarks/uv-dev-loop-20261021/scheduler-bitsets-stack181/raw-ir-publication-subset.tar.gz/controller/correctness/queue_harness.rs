mod util {
    // These are the exact two aliases used by the included Cargo modules.
    pub mod data_structures {
        pub use rustc_hash::FxHashMap as HashMap;
        pub use rustc_hash::FxHashSet as HashSet;
    }
}

#[path = "../cargo-scheduler-bitsets/src/util/dependency_queue.rs"]
mod candidate;
#[path = "baseline_dependency_queue.rs"]
mod baseline;

#[test]
fn original_and_candidate_scheduling_match() {
    // Compare all original dequeue decisions, priorities and artifact releases.
    // Insertion order is varied so tied priorities do not rely on node order.
    for mask in 0..1 << 10 {
        for costs in [[100; 5], [1, 0, 7, 3, 0], [0; 5]] {
            for reverse in [false, true] {
                let mut original = baseline::DependencyQueue::new();
                let mut changed = candidate::DependencyQueue::new();
                let mut dependencies = vec![Vec::new(); 5];
                let mut bit = 0;
                for node in 0..5 {
                    for dependency in 0..node {
                        if mask & (1 << bit) != 0 {
                            dependencies[node].push((dependency, 'm'));
                            if dependency % 2 == 0 {
                                dependencies[node].push((dependency, 'a'));
                            }
                        }
                        bit += 1;
                    }
                }
                for slot in 0..5 {
                    let node = if reverse { 4 - slot } else { slot };
                    original.queue(node, (), dependencies[node].clone(), costs[node]);
                    changed.queue(node, (), dependencies[node].clone(), costs[node]);
                }
                original.queue_finished();
                changed.queue_finished();
                loop {
                    assert_eq!(original.len(), changed.len());
                    let old = original.dequeue();
                    let new = changed.dequeue();
                    assert_eq!(old, new, "mask {mask}, costs {costs:?}, reversed {reverse}");
                    let Some((node, (), _)) = old else {
                        assert!(original.is_empty() && changed.is_empty());
                        break;
                    };
                    for edge in ['m', 'a'] {
                        let mut old: Vec<_> = original.finish(&node, &edge).into_iter().copied().collect();
                        let mut new: Vec<_> = changed.finish(&node, &edge).into_iter().copied().collect();
                        old.sort_unstable();
                        new.sort_unstable();
                        assert_eq!(old, new);
                    }
                }
            }
        }
    }
}

#[test]
fn original_and_candidate_empty_missing_and_repeated_preparation_match() {
    let mut old = baseline::DependencyQueue::new();
    let mut new = candidate::DependencyQueue::new();
    old.queue_finished();
    new.queue_finished();
    assert_eq!(old.dequeue(), new.dequeue());
    old.queue(0, (), [], 3);
    new.queue(0, (), [], 3);
    old.queue(1, (), [(0, ())], 5);
    new.queue(1, (), [(0, ())], 5);
    old.queue(2, (), [(99, ())], 1);
    new.queue(2, (), [(99, ())], 1);
    old.queue_finished();
    new.queue_finished();
    assert_eq!(old.dequeue(), new.dequeue());
    // The private fast path deliberately falls back after a dequeue.
    old.queue_finished();
    new.queue_finished();
    assert_eq!(old.finish(&0, &()), new.finish(&0, &()));
    assert_eq!(old.dequeue(), new.dequeue());
    assert_eq!(old.dequeue(), new.dequeue());
    assert_eq!(old.len(), 1);
    assert_eq!(new.len(), 1);
}

#[test]
fn original_and_candidate_overflow_semantics_match() {
    for costs in [[usize::MAX], [usize::MAX / 2 + 1], [0]] {
        let old = std::panic::catch_unwind(|| {
            let mut queue = baseline::DependencyQueue::<usize, (), ()>::new();
            queue.queue(0, (), [], costs[0]);
            queue.queue_finished();
            queue.dequeue()
        });
        let new = std::panic::catch_unwind(|| {
            let mut queue = candidate::DependencyQueue::<usize, (), ()>::new();
            queue.queue(0, (), [], costs[0]);
            queue.queue_finished();
            queue.dequeue()
        });
        assert_eq!(old.is_err(), new.is_err());
        if let (Ok(old), Ok(new)) = (old, new) {
            assert_eq!(old, new);
        }
    }
    // Exercise both popcount multiplication and weighted bit enumeration, in
    // checked and wrapping arithmetic, on closures containing several nodes.
    for costs in [[usize::MAX / 2; 3], [usize::MAX / 2, 1, usize::MAX / 2], [0, usize::MAX, 0]] {
        let old = std::panic::catch_unwind(|| {
            let mut queue = baseline::DependencyQueue::<usize, (), ()>::new();
            for node in 0usize..3 {
                queue.queue(node, (), node.checked_sub(1).map(|dep| (dep, ())), costs[node]);
            }
            queue.queue_finished();
            queue.dequeue()
        });
        let new = std::panic::catch_unwind(|| {
            let mut queue = candidate::DependencyQueue::<usize, (), ()>::new();
            for node in 0usize..3 {
                queue.queue(node, (), node.checked_sub(1).map(|dep| (dep, ())), costs[node]);
            }
            queue.queue_finished();
            queue.dequeue()
        });
        assert_eq!(old.is_err(), new.is_err());
        if let (Ok(old), Ok(new)) = (old, new) {
            assert_eq!(old, new);
        }
    }
}

#[test]
fn original_and_candidate_cycles_match_in_both_representations() {
    for count in [1, 2, 2049] {
        let old = std::panic::catch_unwind(|| {
            let mut queue = baseline::DependencyQueue::new();
            for node in 0..count {
                queue.queue(node, (), [(if count == 1 { 0 } else { 1 - (node % 2) }, ())], 1);
            }
            queue.queue_finished();
        });
        let new = std::panic::catch_unwind(|| {
            let mut queue = candidate::DependencyQueue::new();
            for node in 0..count {
                queue.queue(node, (), [(if count == 1 { 0 } else { 1 - (node % 2) }, ())], 1);
            }
            queue.queue_finished();
        });
        assert!(old.is_err() && new.is_err());
    }
}
