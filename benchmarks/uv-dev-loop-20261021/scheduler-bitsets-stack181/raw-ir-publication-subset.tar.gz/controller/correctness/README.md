# Bounded scheduler reachability prototype

This is an isolated source/correctness candidate on exact PR181 commit
`d81a093becb4321a975522624c2a383970f0d164`, tree
`c4178b67e0b3a64a12b9b58f84b97323b99d734e`. The local clone contains none of the
concurrent parser candidate's changes. Only `src/util/dependency_queue.rs` changes.
There has been no uv workload, performance comparison, host operation, production
build, publication or CI dispatch for this candidate.

## Motivation and scope

The retained PR181 profile attribution in `../cargo-audit/pr181-hotspots/README.md`
assigns the original `queue_finished::depth` entry 0.91% of check Cargo instructions
and 1.93% of test-build Cargo instructions. Those are existing costs, not projected
or measured savings. The test workflow has plausible 1% headroom; this function
alone does not establish 1% check headroom.

The original code memoizes a `HashSet<N>` of every node's transitive reverse
dependents, including itself. It repeatedly clones and hashes nodes while merging
those sets. The prototype retains that exact code as a fallback and adds a bounded
indexed bitset path. No dependency, feature, configuration, graph edge, job, artifact,
freshness check or scheduler selection rule changes.

## Representation and bound

- A queue with N currently queued nodes is eligible only if historical cost entries
  also number N and `N * ceil(N / 64) <= 65536`, using checked multiplication.
  This admits at most 2048 nodes and caps potential bitset words at **512 KiB**.
  Large queues and calls after a dequeue use the original sparse implementation.
- A node with no reverse dependents has an implicit singleton closure and allocates
  no bitset row. Other nodes allocate one row of `ceil(N / 64)` words. Active DFS
  rows count toward the same per-node bound; no row is allocated twice.
- Node references, dense indices, cached costs, row headers and traversal state add
  O(N) temporary storage. All are released before job execution. The bound applies
  to bitset payload, not to total temporary bytes; the existing graph is unchanged.
- The saved 703/794-node queues fit the gate. Their payload upper bounds are
  61,864/82,576 bytes before implicit-leaf savings. Sparse small graphs remain bounded;
  they are not promised a speedup. Large sparse graphs keep the existing algorithm.

## Equivalence argument

Each dense index identifies exactly one existing queued key. The helper borrows
the queue and never mutates `dep_map`, `reverse_dep_map`, costs or any edge set.
The equal cost-map/queue cardinality check is sufficient because `queue` inserts
every queued key into `cost`, while `dequeue` never removes a cost entry.

For a leaf, the closure is its own singleton. For another node, the helper starts
with its own bit and ORs the recursively complete closures of all reverse
dependents. A dependent's singleton is inserted directly. Induction over the DAG
therefore gives exactly the original set, with diamonds and repeated artifact-edge
paths counted once. Missing external prerequisites remain blocked as before:
reverse-map values are queued nodes, while an unqueued dependency is never a root.

Traversal states distinguish unseen, active and complete nodes. Revisiting an active
node rejects a cycle with the original assertion text. The recursion depth remains
the graph depth; this does not introduce an iterative traversal or solve existing
deep-recursion limitations.

Priorities remain **own cost + sum of closure costs**, so own cost is deliberately
counted twice. Equal costs are verified across all queued nodes before replacing
the sum by popcount times that common cost. Otherwise each set bit selects its
original cost. Zero costs, nonuniform costs and overlapping closures are preserved.
Because all costs are unsigned, reordered addition has the same overflow/no-overflow
boundary under checked arithmetic and the same result under wrapping arithmetic.

Only the derived `priority` map is replaced. The original `dequeue`, `finish`, queue
insertion and hash-map iteration order are unchanged. Equal-priority tie decisions
therefore remain unchanged. `source-proof.json` mechanically reconstructs the exact
original source by removing only the three added blocks.

## Focused correctness evidence

`run_focused.py` compiles the exact source module with stock rustc 1.99.0 and the
actual `rustc_hash` artifact and FxHash aliases used by this checkout. It also
includes the exact original source from PR181. It does not invoke Cargo or uv.
The stock toolchain has no rustfmt; formatting uses the already installed stable
formatter, whose identity is recorded separately. No toolchain was installed or
changed.

The final `focused-attempt04/receipt.json` binds source, harness, compiler, dependency,
flags, environment, binaries and raw logs. Both debug/checked and optimized/wrapping
builds pass **13 tests** each:

- The two existing original queue cases and the same two candidate cases.
- A weighted diamond with multiple artifact edges and independent work.
- All 1024 ordered five-node DAGs against an independent boolean reachability
  oracle, with uniform and nonuniform/zero costs (2048 cases).
- Cross-word closures, including nonuniform/zero costs, and the 2048/2049-node
  fast-path/fallback boundary.
- Cycle rejection and direct original/candidate differential coverage for cycles,
  empty queues, absent external prerequisites, repeated preparation after dequeue,
  overflow, zero costs and both arithmetic modes.
- **6144** original/candidate graph/cost/insertion-order combinations with exact
  dequeue node/priority and artifact-release comparisons, including scheduling ties.

This is module-level correctness validation, not the complete Cargo workspace or
integration suite. No performance conclusion follows from these tests. The first
setup attempt's absent formatter and the second attempt's ambiguous integer type
in a newly added test are retained. The production helper compiled once the test
binding was explicitly typed. Attempt03 passed before additional multi-node
overflow cases; attempt04 includes those cases. No test or compiler failure is hidden.

## Next decision

Independent source review should precede any matched production build or uv
measurement. A future experiment needs a fixed prospective protocol and unchanged
uv, with test-build instructions as the plausible primary endpoint and check as a
secondary/nonregression endpoint. No timing result, instruction saving or draft PR
is justified yet.
