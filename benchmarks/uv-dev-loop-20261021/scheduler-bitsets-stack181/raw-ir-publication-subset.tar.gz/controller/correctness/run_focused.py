#!/usr/bin/env python3
"""Compile the exact queue module and its tests; no Cargo or uv invocation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / 'work/cargo-scheduler-bitsets'
COMPILER = Path('/home/dev-user/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/rustc')
RUSTFMT = Path('/home/dev-user/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt')
DEPENDENCY = ROOT / 'work/required-native-leaves-candidate/compiler-build-v3/debug/deps/librustc_hash-a530e585463fe85a.rlib'
BASE = 'd81a093becb4321a975522624c2a383970f0d164'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    assert set(os.sched_getaffinity(0)) == {8}
    assert subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == BASE
    baseline = subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE), 'show', BASE + ':src/util/dependency_queue.rs'])
    baseline_path = OUT / 'baseline_dependency_queue.rs'
    if baseline_path.exists():
        assert baseline_path.read_bytes() == baseline
    else:
        baseline_path.write_bytes(baseline)
    aliases = (SOURCE / 'src/util/data_structures.rs').read_text()
    assert 'pub use rustc_hash::FxHashMap as HashMap;' in aliases
    assert 'pub use rustc_hash::FxHashSet as HashSet;' in aliases
    support = OUT / 'support'
    support.mkdir(exist_ok=True)
    dependency_copy = support / DEPENDENCY.name
    if not dependency_copy.exists():
        shutil.copy2(DEPENDENCY, dependency_copy)
    assert sha(dependency_copy) == sha(DEPENDENCY)
    assert dependency_copy.stat().st_nlink == 1
    assert dependency_copy.stat().st_ino != DEPENDENCY.stat().st_ino
    old = sorted(OUT.glob('focused-attempt[0-9][0-9]'))
    attempt = OUT / f'focused-attempt{len(old) + 1:02}'
    attempt.mkdir()
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}
    record = {'started_at': now(), 'purpose': 'focused queue correctness only', 'base': BASE,
              'runner_sha256': sha(__file__), 'environment': env,
              'compiler': {'path': str(COMPILER), 'sha256': sha(COMPILER)},
              'rustfmt': {'path': str(RUSTFMT), 'sha256': sha(RUSTFMT)},
              'dependency': {'path': str(DEPENDENCY), 'sha256': sha(DEPENDENCY)},
              'commands': [], 'status': 'running'}

    def save():
        (attempt / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    def run(label, argv):
        result = subprocess.run(list(map(str, argv)), cwd=OUT, env=env, capture_output=True)
        (attempt / (label + '.stdout')).write_bytes(result.stdout)
        (attempt / (label + '.stderr')).write_bytes(result.stderr)
        record['commands'].append({'label': label, 'argv': list(map(str, argv)), 'returncode': result.returncode,
                                   'stdout_sha256': sha(attempt / (label + '.stdout')),
                                   'stderr_sha256': sha(attempt / (label + '.stderr'))})
        save()
        result.check_returncode()
        return result.stdout.decode()

    save()
    try:
        record['compiler']['version'] = run('compiler-version', [COMPILER, '-vV'])
        run('format', [RUSTFMT, '--edition', '2024', SOURCE / 'src/util/dependency_queue.rs'])
        run('diff-check', ['git', '--no-optional-locks', '-C', SOURCE, 'diff', '--check'])
        record['inputs'] = {str(path): sha(path) for path in [SOURCE / 'src/util/dependency_queue.rs', SOURCE / 'src/util/data_structures.rs', OUT / 'queue_harness.rs', baseline_path, dependency_copy]}
        for label, options in [
            ('debug', ['-C', 'opt-level=0', '-C', 'overflow-checks=yes', '-C', 'debug-assertions=yes']),
            ('optimized', ['-C', 'opt-level=2', '-C', 'overflow-checks=no', '-C', 'debug-assertions=no']),
        ]:
            binary = attempt / (label + '-queue-tests')
            run(label + '-build', [COMPILER, '--test', OUT / 'queue_harness.rs', '--edition=2024', '--extern', 'rustc_hash=' + str(dependency_copy), '-C', 'debuginfo=0', *options, '-o', binary])
            run(label + '-tests', [binary, '--test-threads=1'])
            record.setdefault('binaries', {})[str(binary)] = sha(binary)
        assert all(sha(path) == digest for path, digest in record['inputs'].items())
        assert sha(DEPENDENCY) == record['dependency']['sha256']
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed'
        record['error'] = repr(error)
        raise
    finally:
        record['finished_at'] = now()
        save()
        print(json.dumps({'status': record['status'], 'receipt': str(attempt / 'receipt.json'), 'sha256': sha(attempt / 'receipt.json')}))


if __name__ == '__main__':
    main()
