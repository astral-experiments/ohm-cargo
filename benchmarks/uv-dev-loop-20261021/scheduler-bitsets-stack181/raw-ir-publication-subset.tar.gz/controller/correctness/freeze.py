#!/usr/bin/env python3
"""Seal source and existing focused correctness results; never run a workload."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import tempfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / 'work/cargo-scheduler-bitsets'
BASE = 'd81a093becb4321a975522624c2a383970f0d164'
FILE = 'src/util/dependency_queue.rs'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*args, env=None):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE), *args], env=env)


assert set(os.sched_getaffinity(0)) == {8}
assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == 'c4178b67e0b3a64a12b9b58f84b97323b99d734e'
assert git('diff', '--name-only', 'HEAD').decode().splitlines() == [FILE]
assert not git('ls-files', '--others', '--exclude-standard').strip()
baseline = git('show', BASE + ':' + FILE).decode()
candidate = (SOURCE / FILE).read_text()
assert (OUT / 'baseline_dependency_queue.rs').read_text() == baseline
prefix = '''        if let Some(priority) = self.bitset_priorities() {
            self.priority = priority;
            return;
        }

'''
assert candidate.count(prefix) == 1
reconstructed = candidate.replace(prefix, '', 1)
start = reconstructed.index('    /// Avoid cloning and hashing nodes while combining small dependency graphs.\n')
end = reconstructed.index('    /// Dequeues a package that is ready to be built.\n', start)
helper = reconstructed[start:end]
reconstructed = reconstructed[:start] + reconstructed[end:]
start = reconstructed.index('\n    #[test]\n    fn weighted_diamond_with_multiple_artifacts()')
assert reconstructed.endswith('}\n')
tests = reconstructed[start:-2]
reconstructed = reconstructed[:start] + '}\n'
assert reconstructed == baseline
save(OUT / 'source-proof.json', {
    'status': 'passed',
    'base_sha256': hashlib.sha256(baseline.encode()).hexdigest(),
    'candidate_sha256': sha(SOURCE / FILE),
    'original_source_reconstructed_exactly': True,
    'added_blocks': {'fast_path_dispatch_lines': len(prefix.splitlines()),
                     'bounded_helper_lines': len(helper.splitlines()),
                     'new_test_lines': len(tests.splitlines())},
    'unchanged': ['complete original HashSet calculation', 'queue', 'dequeue including ties', 'finish including artifact releases', 'public representation', 'existing tests'],
    'fast_path_payload_bound_bytes': 512 * 1024,
    'highest_admitted_node_count': 2048,
})
patch = git('diff', '--binary', '--full-index', 'HEAD')
assert not (OUT / 'candidate.patch').exists()
(OUT / 'candidate.patch').write_bytes(patch)
with tempfile.TemporaryDirectory(dir=OUT) as temporary:
    env = os.environ.copy()
    env['GIT_INDEX_FILE'] = str(Path(temporary) / 'index')
    git('read-tree', 'HEAD', env=env)
    git('add', '-u', env=env)
    tree = git('write-tree', env=env).decode().strip()
    assert git('diff', '--cached', '--binary', '--full-index', 'HEAD', env=env) == patch
receipt = json.loads((OUT / 'focused-attempt04/receipt.json').read_text())
assert receipt['status'] == 'passed'
assert all(sha(path) == digest for path, digest in receipt['inputs'].items())
assert all(sha(path) == digest for path, digest in receipt['binaries'].items())
assert receipt['compiler']['sha256'] == sha(receipt['compiler']['path'])
for label in ['debug', 'optimized']:
    text = (OUT / f'focused-attempt04/{label}-tests.stdout').read_text()
    assert 'test result: ok. 13 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in text
    assert (OUT / f'focused-attempt04/{label}-build.stderr').read_bytes() == b''
save(OUT / 'manifest.json', {
    'status': 'source_and_focused_correctness_frozen',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_path': str(SOURCE), 'branch': git('branch', '--show-current').decode().strip(),
    'base_commit': BASE, 'base_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
    'candidate_tree': tree, 'patch_sha256': sha(OUT / 'candidate.patch'),
    'files': {FILE: sha(SOURCE / FILE)},
    'cargo_toml_sha256': sha(SOURCE / 'Cargo.toml'),
    'cargo_lock_sha256': sha(SOURCE / 'Cargo.lock'),
    'source_proof_sha256': sha(OUT / 'source-proof.json'),
    'focused_receipt_sha256': sha(OUT / 'focused-attempt04/receipt.json'),
    'correctness_scope': 'exact source module and aliases; 13 tests in each of two arithmetic modes; no complete Cargo suite',
    'performance_execution': False, 'performance_claim': False,
})
files = {}
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        files[str(path.relative_to(OUT))] = {'sha256': sha(path), 'size': path.stat().st_size}
save(OUT / 'correctness-seal.json', {'status': 'sealed', 'manifest_sha256': sha(OUT / 'manifest.json'), 'files': files})
print(json.dumps({'candidate_tree': tree, 'manifest_sha256': sha(OUT / 'manifest.json'),
                  'seal_sha256': sha(OUT / 'correctness-seal.json'), 'patch_sha256': sha(OUT / 'candidate.patch'),
                  'files': len(files)}))
