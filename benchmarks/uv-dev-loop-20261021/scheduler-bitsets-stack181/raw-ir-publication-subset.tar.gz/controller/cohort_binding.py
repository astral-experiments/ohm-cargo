"""Fail-closed data bindings for the new cohort; no workload or host operations."""
import hashlib
import json
import os
from pathlib import Path
import re

ROOT = '/tmp/ohm-hillclimb-20261021/scheduler-bitsets-stack181'
HOST = 'charlie-oss-2'
CONTROLLER_PATH = ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin'
PROTOCOL_SHA = 'bdae6e7141f0111d1e826442c49295aec3b5420b027dd82c6a95efb833ea9dc0'
SOURCE_PARENT_COMMIT = 'd81a093becb4321a975522624c2a383970f0d164'
PATCH_SHA = 'ef953c7ea9c1231ef1b5e1cad139a11b53e2675e89ec13470e2541d9eef05494'
SOURCE_MANIFEST_SHA = '94916cbac402ba549509e8bf1f1d595f77f0dc79d6bb12515fe4b811bf97ded9'
SOURCE_REVIEW_SHA = '5889d2a0d18cfd88f2a7e68aa52fe4d77725aa67eb372d390dd1560ddeff2db2'
CORRECTNESS_SHA = 'fd3472a00e364a0dc83781e0434d63bf829715e7bb1017786216f33eedfb2e11'
CI_AMENDMENT_SHA = 'f7e5a3c2b53d3afee28b75d81c7a876955e334b3f0ea65da9c16a225fc669172'
HOST_ASSIGNMENT_SHA = 'a6621248d54d037740663c3289c2084d7867941c26cf48611221b92f50c0638f'
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '807c36ec5326d42ca19a921819e1b3d1e2776cb2'}
OLD_BINARIES = {'3164f9287711f122fa9636a7816ed8749598706ac5076d66051a036dcef51037',
                '3b1a2e4e3654b7b23816fbb54c51072cb356486c36052a5bcd6c4d3d2e6a07e9'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(value):
    assert isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'Unbound or invalid digest'
    assert value != '0' * 64, 'Placeholder digest'
    return value


def validate_input_approval(value, source_freeze_sha256):
    assert value['status'] == 'passed' and value['scope'] == 'scheduler-bitsets-production-inputs'
    assert value['source_freeze_sha256'] == digest(source_freeze_sha256)
    assert value['protocol_sha256'] == PROTOCOL_SHA
    assert value['root'] == ROOT and value['host'] == HOST
    assert 'source_commit' not in value and 'source_ci_sha256' not in value
    assert value['source_parent_commit'] == SOURCE_PARENT_COMMIT and value['source_trees'] == TREES
    assert value['candidate_patch_sha256'] == PATCH_SHA
    assert value['source_manifest_sha256'] == SOURCE_MANIFEST_SHA
    assert value['candidate_source_review_sha256'] == SOURCE_REVIEW_SHA
    assert value['correctness_seal_sha256'] == CORRECTNESS_SHA
    assert value['ci_sequencing_amendment_sha256'] == CI_AMENDMENT_SHA
    assert value['host_assignment_sha256'] == HOST_ASSIGNMENT_SHA
    assert value['controller_path'] == CONTROLLER_PATH
    assert value['cohort'] == 'host2-scheduler-bitsets-stack181'
    assert set(value['variants']) == {'baseline', 'candidate'}
    assert len(set(value['variants'].values())) == 2
    for item in value['variants'].values():
        assert digest(item) not in OLD_BINARIES
    for name in ('pair_audit_sha256', 'pair_review_sha256', 'common_build_inputs_sha256',
                 'production_manifest_sha256', 'production_driver_sha256',
                 'production_terminal_status_sha256', 'host_readback_sha256'):
        digest(value[name])
    assert re.fullmatch('[a-z0-9][a-z0-9-]*', value['host_readback_label'])
    assert value['checks'] == {'fresh_matched_pair': True, 'production_audit_passed': True,
        'accepted_exact_source_and_focused_correctness': True, 'focused_13_by_2_passed': True,
        'production_complete_before_admission': True, 'quiet_host_root_absent': True}
    return value


def load_input_approval(directory):
    directory = Path(directory)
    return validate_input_approval(json.loads((directory / 'input-approval.json').read_text()),
                                   sha(directory / 'source-freeze.json'))


def validate_source_correctness(directory, controls):
    """Read only the fixed exact-tree/module evidence; full CI remains a publication gate."""
    directory, controls = Path(directory), Path(controls)
    assert sha(controls / 'protocol.json') == PROTOCOL_SHA
    assert sha(controls / 'ci-sequencing-amendment.json') == CI_AMENDMENT_SHA
    assert sha(controls / 'host-assignment.json') == HOST_ASSIGNMENT_SHA
    protocol = json.loads((controls / 'protocol.json').read_text())
    assert protocol['base_commit'] == SOURCE_PARENT_COMMIT and protocol['candidate_tree'] == TREES['candidate']
    assert protocol['incremental_patch_sha256'] == PATCH_SHA
    assert protocol['original_root_source_review_sha256'] == SOURCE_REVIEW_SHA
    assert protocol['ci_sequence']['comparative_observations_before_amendment'] == 0
    assert protocol['ci_sequence']['after_fixed_performance_qualification_before_any_pr'] == (
        'Publish the unchanged exact candidate source for complete GitHub CI; all required jobs must pass before any PR.')
    assert sha(directory / 'manifest.json') == SOURCE_MANIFEST_SHA
    assert sha(directory / 'root-source-review.json') == SOURCE_REVIEW_SHA
    assert sha(directory / 'correctness-seal.json') == CORRECTNESS_SHA
    manifest = json.loads((directory / 'manifest.json').read_text())
    reviewed = json.loads((directory / 'root-source-review.json').read_text())
    correctness = json.loads((directory / 'correctness-seal.json').read_text())
    assert manifest['base_commit'] == SOURCE_PARENT_COMMIT and manifest['base_tree'] == TREES['baseline']
    assert manifest['candidate_tree'] == reviewed['candidate_tree'] == TREES['candidate']
    assert manifest['patch_sha256'] == reviewed['patch_sha256'] == sha(directory / 'candidate.patch') == PATCH_SHA
    assert reviewed['status'] == 'passed' and all(reviewed['checks'].values())
    assert reviewed['correctness_seal_sha256'] == CORRECTNESS_SHA
    assert reviewed['source_manifest_sha256'] == correctness['manifest_sha256'] == SOURCE_MANIFEST_SHA
    assert correctness['status'] == 'sealed' and len(correctness['files']) == 64
    for name, identity in correctness['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        path = directory / name
        assert path.is_file() and not path.is_symlink()
        assert sha(path) == identity['sha256'] and path.stat().st_size == identity['size']
    receipt_path = directory / 'focused-attempt04/receipt.json'
    assert sha(receipt_path) == manifest['focused_receipt_sha256']
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['base'] == SOURCE_PARENT_COMMIT
    assert all(row['returncode'] == 0 for row in receipt['commands'])
    assert receipt['inputs'][manifest['source_path'] + '/src/util/dependency_queue.rs'] == reviewed['source_sha256']
    assert sha(directory / 'focused-attempt03/dependency_queue.rs') == reviewed['source_sha256']
    for mode, overflow, debug, optimization in [('debug', 'yes', 'yes', '0'), ('optimized', 'no', 'no', '2')]:
        build = next(row for row in receipt['commands'] if row['label'] == mode + '-build')
        assert all(value in build['argv'] for value in (
            'overflow-checks=' + overflow, 'debug-assertions=' + debug, 'opt-level=' + optimization))
        test = next(row for row in receipt['commands'] if row['label'] == mode + '-tests')
        for suffix in ('stdout', 'stderr'):
            assert sha(directory / ('focused-attempt04/' + mode + '-tests.' + suffix)) == test[suffix + '_sha256']
        output = (directory / ('focused-attempt04/' + mode + '-tests.stdout')).read_text()
        assert re.search(r'^test result: ok\. 13 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', output, re.M)
        assert len(re.findall(r'^test .+ \.\.\. ok$', output, re.M)) == 13
    return {'source_tree': TREES['candidate'], 'checked_debug_tests': 13, 'wrapping_optimized_tests': 13,
            'complete_source_ci_still_required_before_publication': True}


def validate_production_admission(cohort, review):
    """The future host admission must follow this completed, reviewed build pair."""
    cohort = Path(cohort)
    terminal = cohort / 'results/scheduler-bitsets-stack181-reduced.batch-status.json'
    audit_path, pair_review_path = cohort / 'results/audit-pair.json', cohort / 'results/root-pair-review.json'
    assert sha(terminal) == review['production_terminal_status_sha256']
    assert sha(audit_path) == review['production_pair_audit_sha256']
    assert sha(pair_review_path) == review['production_pair_review_sha256']
    status, audit, accepted = (json.loads(path.read_text()) for path in (terminal, audit_path, pair_review_path))
    names = {'scheduler-bitsets-stack181-baseline', 'scheduler-bitsets-stack181-reduced'}
    assert status['state'] == 'complete' and set(status['completed_variants']) == names
    assert audit['cohort'] == 'host2-scheduler-bitsets-stack181'
    assert len(audit['records']) == 2 and {row['variant'] for row in audit['records']} == names
    variants = {role: next(row for row in audit['records'] if row['variant'] == 'scheduler-bitsets-stack181-' + suffix)['stripped_sha256']
                for role, suffix in (('baseline', 'baseline'), ('candidate', 'reduced'))}
    validate_pair_review(accepted, sha(audit_path), variants)
    return {key: review[key] for key in ('production_terminal_status_sha256', 'production_pair_audit_sha256', 'production_pair_review_sha256')}


def validate_pair_review(value, audit_sha256, variants):
    """Declared scheduler contract: the root review uses binaries, keyed by build variant."""
    assert value['status'] == 'passed'
    assert isinstance(value['checks'], dict) and value['checks']
    assert all(type(item) is bool and item for item in value['checks'].values())
    assert value['pair_audit_sha256'] == digest(audit_sha256)
    assert set(variants) == {'baseline', 'candidate'}
    for item in variants.values():
        digest(item)
    assert value['binaries'] == {'scheduler-bitsets-stack181-baseline': variants['baseline'],
                                 'scheduler-bitsets-stack181-reduced': variants['candidate']}
    return value


def require_controller_environment():
    assert os.environ.get('PATH') == CONTROLLER_PATH
    assert not any(name in os.environ for name in ('PYTHONHOME', 'PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONINSPECT'))
    assert os.sched_getaffinity(0) == {8}, 'Controller must stay outside measured CPUs 0-7'


def translate_reference(value):
    old = '/tmp/ohm-hillclimb-20261021-inheritance-measurement'
    names = {'inheritance-stack180-baseline': 'scheduler-bitsets-stack181-baseline',
             'inheritance-stack180-shared': 'scheduler-bitsets-stack181-reduced'}
    if isinstance(value, str):
        value = value.replace(old, ROOT)
        for before, after in names.items():
            value = value.replace(before, after)
        return value
    if isinstance(value, list):
        return [translate_reference(item) for item in value]
    if isinstance(value, dict):
        return {key: translate_reference(item) for key, item in value.items()}
    return value


def validate_base_config(config, reference):
    expected = translate_reference(reference)
    assert {key: value for key, value in config.items() if key not in ('record_files', 'env')} == {
        key: value for key, value in expected.items() if key not in ('record_files', 'env')}
    assert set(expected['env']) <= set(config['env'])
    assert all(config['env'][key] == value for key, value in expected['env'].items())
    assert all(value is None for key, value in config['env'].items() if key not in expected['env'])
    assert config['record_files'][:len(expected['record_files'])] == expected['record_files']
    assert len(config['record_files']) == len(set(config['record_files']))
    return expected


def runtime_aliases(root):
    result = {}
    for prefix in ('ohm', 'profiling-tools'):
        for path in sorted((Path(root) / prefix).rglob('*')):
            if path.is_symlink():
                resolved = path.resolve()
                result[str(path)] = {'target': os.readlink(path), 'resolved': str(resolved),
                                     'sha256': sha(resolved) if resolved.is_file() else None}
    return result
