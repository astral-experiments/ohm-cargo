#!/usr/bin/env python3
"""Future read-only host2 admission after its production pair; never create the fixture."""
import argparse
import datetime
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from cohort_binding import CONTROLLER_PATH, HOST, ROOT, HOST_ASSIGNMENT_SHA, sha, validate_production_admission


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label', required=True)
    args = parser.parse_args()
    assert re.fullmatch('[a-z0-9][a-z0-9-]*', args.label)
    source = json.loads((HERE / 'source-freeze.json').read_text())
    review = json.loads((HERE / 'source-review.json').read_text())
    assert review['status'] == 'passed' and review['source_freeze_sha256'] == sha(HERE / 'source-freeze.json')
    assert sha(HERE / 'host-assignment.json') == HOST_ASSIGNMENT_SHA
    production = validate_production_admission(HERE.parent / 'production-build/host2-scheduler-bitsets-stack181', review)
    for name, digest in source['files'].items():
        assert sha(HERE / name) == digest
    remote = '''import json,os,socket,shutil
from pathlib import Path
assert socket.gethostname()==HOST and os.getuid()==1000 and Path('/').stat().st_uid==0
assert os.environ.get('PATH')==CONTROLLER_PATH and os.sched_getaffinity(0)=={8}
root=Path(ROOT)
assert root.resolve()==root and not os.path.lexists(root)
if os.path.lexists(root.parent):
 assert root.parent.is_dir() and not root.parent.is_symlink() and root.parent.stat().st_uid==1000
exec(compile(OCCUPANCY,'<frozen-occupancy>','exec'))
quiet=require_quiet()
print(json.dumps({'host':socket.gethostname(),'root':ROOT,'uid':os.getuid(),'root_absent':True,
 'controller_path':CONTROLLER_PATH,'controller_affinity':sorted(os.sched_getaffinity(0)),
 'quiet':quiet,'cpu_count':os.cpu_count(),'available_tmp_bytes':shutil.disk_usage('/tmp').free},indent=2))
'''
    prefix = f'HOST={HOST!r}\nROOT={ROOT!r}\nCONTROLLER_PATH={CONTROLLER_PATH!r}\nOCCUPANCY={(HERE / "occupancy.py").read_text()!r}\n'
    command = ['/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh', HOST,
        '--', '/usr/bin/env', '-u', 'PYTHONHOME', '-u', 'PYTHONPATH', '-u', 'PYTHONSTARTUP',
        '-u', 'PYTHONINSPECT', 'PATH=' + CONTROLLER_PATH, '/usr/bin/taskset', '-c', '8',
        '/usr/bin/python3', '-I', '-B', '-c', prefix + remote]
    receipt = HERE / (args.label + '.json')
    record = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'operation': 'read-only-host2-post-build-admission', 'host': HOST, 'root': ROOT,
        **production,
        'source_freeze_sha256': sha(HERE / 'source-freeze.json'), 'controller_path': CONTROLLER_PATH}
    with receipt.open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    with (HERE / (args.label + '.stdout')).open('xb') as out, (HERE / (args.label + '.stderr')).open('xb') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    record.update(returncode=result.returncode, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        stdout_sha256=sha(HERE / (args.label + '.stdout')), stderr_sha256=sha(HERE / (args.label + '.stderr')))
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
