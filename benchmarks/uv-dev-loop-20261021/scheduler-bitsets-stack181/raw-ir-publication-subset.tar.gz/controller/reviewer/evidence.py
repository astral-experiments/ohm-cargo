"""Independent local input/transport checks; never imports experiment controls."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath
import tarfile

ROOT = '/tmp/ohm-hillclimb-20261021/scheduler-bitsets-stack181'
HOST = 'charlie-oss-2'
FREEZE = SEAL = DELIVERY = DRIVER = None
APPROVAL = None
CORE = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'
REPEATED = '50547460e030aa73e1f48121bf477cf8f4a4538bf1bb577851af54176750b6d3'
PROTOCOL = 'bdae6e7141f0111d1e826442c49295aec3b5420b027dd82c6a95efb833ea9dc0'
UV = '3d82a6ad5a7eab8c68236553b7846517767c4b61'
EXPECTED = None
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '807c36ec5326d42ca19a921819e1b3d1e2776cb2'}
NAMES = {'baseline': 'scheduler-bitsets-stack181-baseline', 'candidate': 'scheduler-bitsets-stack181-reduced'}
STAGES = {
    'ir': {'pairs': 12, 'phase': 'confirmation', 'warming_order': ['baseline', 'candidate'],
           'plan': [['test', 20261021131], ['check', 20261021132]]},
    'native': {'pairs': 30, 'phase': 'confirmation', 'warming_order': ['baseline', 'candidate'],
               'plan': [['test', 20261021133], ['check', 20261021134]]},
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def relative(name):
    need(isinstance(name, str), 'path is not a string')
    path = PurePosixPath(name)
    need(name and name != '.' and not path.is_absolute() and '..' not in path.parts
         and '\\' not in name and str(path) == name, 'unsafe path: ' + repr(name))
    return path


def configure(controls, expected_seal):
    """Bind future real identities from root-reviewed inputs, never placeholders."""
    global FREEZE, SEAL, DELIVERY, DRIVER, EXPECTED, APPROVAL
    controls = Path(controls).resolve()
    need(controls == Path(__file__).resolve().parents[1], 'review controls are outside this frozen package')
    need(isinstance(expected_seal, str) and len(expected_seal) == 64
         and set(expected_seal) <= set('0123456789abcdef') and expected_seal != '0' * 64, 'unbound measurement seal')
    FREEZE, SEAL = sha(controls / 'source-freeze.json'), expected_seal
    source = read(controls / 'source-freeze.json')
    for name, digest in source['files'].items():
        need(sha(controls / relative(name)) == digest, 'frozen control source changed')
    reviewed = read(controls / 'source-review.json')
    need(reviewed['status'] == 'passed' and reviewed['source_freeze_sha256'] == FREEZE, 'source review not bound')
    APPROVAL = read(controls / 'input-approval.json')
    need(APPROVAL['status'] == 'passed' and APPROVAL['scope'] == 'scheduler-bitsets-production-inputs'
         and APPROVAL['source_freeze_sha256'] == FREEZE and APPROVAL['protocol_sha256'] == PROTOCOL
         and APPROVAL['root'] == ROOT and APPROVAL['host'] == HOST and APPROVAL['source_trees'] == TREES
         and APPROVAL['source_parent_commit'] == 'd81a093becb4321a975522624c2a383970f0d164'
         and APPROVAL['candidate_patch_sha256'] == 'ef953c7ea9c1231ef1b5e1cad139a11b53e2675e89ec13470e2541d9eef05494'
         and APPROVAL['source_manifest_sha256'] == '94916cbac402ba549509e8bf1f1d595f77f0dc79d6bb12515fe4b811bf97ded9'
         and APPROVAL['candidate_source_review_sha256'] == '5889d2a0d18cfd88f2a7e68aa52fe4d77725aa67eb372d390dd1560ddeff2db2'
         and APPROVAL['correctness_seal_sha256'] == 'fd3472a00e364a0dc83781e0434d63bf829715e7bb1017786216f33eedfb2e11'
         and 'source_commit' not in APPROVAL and 'source_ci_sha256' not in APPROVAL, 'input approval differs')
    need(APPROVAL['controller_path'] == ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin', 'controller PATH differs')
    EXPECTED = APPROVAL['variants']
    need(set(EXPECTED) == {'baseline', 'candidate'} and len(set(EXPECTED.values())) == 2, 'production pair is incomplete')
    for value in EXPECTED.values():
        need(isinstance(value, str) and len(value) == 64 and set(value) <= set('0123456789abcdef')
             and value != '0' * 64, 'unbound production binary')
    delivery = read(controls / 'delivery/delivery.json')
    binding = read(controls / 'delivery/binding.json')
    DELIVERY = sha(controls / 'delivery/delivery.json')
    DRIVER = source['files']['driver.py']
    need(binding['delivery_sha256'] == DELIVERY and delivery['source_freeze_sha256'] == FREEZE
         and delivery['variants'] == EXPECTED and delivery['source_trees'] == TREES, 'delivery identity differs')
    need(delivery['files']['controller/input-approval.json'] == sha(controls / 'input-approval.json')
         and delivery['files']['controller/driver.py'] == DRIVER, 'input approval/driver transport differs')
    return FREEZE, SEAL, EXPECTED


def translated_reference(value):
    if isinstance(value, str):
        return value.replace('/tmp/ohm-hillclimb-20261021-inheritance-measurement', ROOT).replace(
            'inheritance-stack180-baseline', 'scheduler-bitsets-stack181-baseline').replace(
            'inheritance-stack180-shared', 'scheduler-bitsets-stack181-reduced')
    if isinstance(value, list):
        return [translated_reference(item) for item in value]
    if isinstance(value, dict):
        return {key: translated_reference(item) for key, item in value.items()}
    return value


class Evidence:
    def __init__(self, controls, phase):
        self.controls = Path(controls).resolve()
        self.phase = phase
        self.directory = self.controls / 'collections' / phase
        self.remote = self.directory / 'remote'
        freeze_path = self.controls / 'source-freeze.json'
        need(sha(freeze_path) == FREEZE, 'scheduler-bitset source freeze changed')
        self.freeze = read(freeze_path)
        for name, digest in self.freeze['files'].items():
            need(sha(self.controls / relative(name)) == digest, 'local frozen control changed: ' + name)
        source_review = read(self.controls / 'source-review.json')
        need(source_review['status'] == 'passed' and source_review['source_freeze_sha256'] == FREEZE, 'source review binding differs')
        transport, receipt = read(self.directory / 'transport.json'), read(self.directory / 'receipt.json')
        self.manifest = read(self.directory / 'transfer-manifest.json')
        need(transport['returncode'] == 0 and receipt['status'] == 'passed', 'collection transport is incomplete')
        need(sha(self.directory / 'payload.tar') == transport['archive_sha256']
             and sha(self.directory / 'transfer.stderr') == transport['stderr_sha256'], 'transport bytes differ')
        need(sha(self.directory / 'transfer-manifest.json') == receipt['transfer_manifest_sha256'], 'transfer manifest differs')
        need(self.manifest['phase'] == receipt['phase'] == phase and self.manifest['root'] == ROOT, 'collection phase/root differs')
        need(self.manifest['seal_sha256'] == receipt['measurement_seal_sha256'] == SEAL
             and self.manifest['delivery_sha256'] == DELIVERY and self.manifest['driver_sha256'] == DRIVER, 'collection identities differ')
        self.files = self.manifest['files']
        seen = set()
        with tarfile.open(self.directory / 'payload.tar', 'r:') as archive:
            for member in archive:
                relative(member.name)
                need(member.isfile() and not member.issym() and not member.islnk()
                     and member.name not in seen, 'unsafe/duplicate archive member')
                seen.add(member.name)
                if member.name == 'transfer-manifest.json':
                    need(archive.extractfile(member).read() == (self.directory / member.name).read_bytes(), 'archived manifest differs')
                    continue
                need(member.name.startswith('remote/'), 'unexpected archive prefix')
                name = member.name[len('remote/'):]
                need(name in self.files, 'unexpected remote member')
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as source:
                    while chunk := source.read(1024 * 1024):
                        digest.update(chunk)
                        size += len(chunk)
                path = self.remote / relative(name)
                need(path.is_file() and not path.is_symlink() and path.resolve() == path, 'noncanonical extracted file')
                need(digest.hexdigest() == self.files[name] == sha(path)
                     and size == member.size == path.stat().st_size, 'archive/extracted bytes differ: ' + name)
        need(seen == {'transfer-manifest.json'} | {'remote/' + name for name in self.files}, 'archive member set differs')
        actual = set()
        for path in self.remote.rglob('*'):
            need(not path.is_symlink(), 'symlink in extracted evidence')
            if path.is_file():
                actual.add(str(path.relative_to(self.remote)))
        need(actual == set(self.files) and len(actual) == receipt['files'], 'extracted member set/count differs')
        self.seal = self.json('controller/measurement-seal.json')
        self.assets = self.json('controller/assets.json')
        self.setup = self.json('metadata/setup.json')
        self.binding = read(self.controls / 'delivery/binding.json')

    def json(self, name):
        return read(self.remote / relative(name))

    def file(self, remote):
        need(isinstance(remote, str) and remote.startswith(ROOT + '/'), 'file path is outside fixed root')
        name = str(relative(remote[len(ROOT) + 1:]))
        need(name in self.files, 'missing collected raw file: ' + name)
        return self.remote / name

    def native_approval(self, ir_review):
        from policy_review import decide
        prefix = 'metadata/native-approval/'
        manifest = self.json(prefix + 'manifest.json')
        required = {'root-approval.json', 'review/review.json', 'review/raw-integrity.json',
            'review/check-reproduced-analysis.json', 'review/test-reproduced-analysis.json',
            'review/source-freeze.json', 'collection/transfer-manifest.json', 'collection/receipt.json'}
        need(set(manifest['files']) == required, 'native approval payload membership differs')
        need(manifest['root'] == ROOT and manifest['host'] == HOST
             and manifest['source_freeze_sha256'] == FREEZE and manifest['measurement_seal_sha256'] == SEAL
             and manifest['variants'] == EXPECTED, 'native approval cohort differs')
        need(manifest['controller_path'] == self.setup['controller_path'], 'native approval PATH differs')
        for name, digest in manifest['files'].items():
            need(self.files[prefix + name] == digest, 'native approval payload bytes differ')
        reviewer_freeze = self.files['controller/reviewer/source-freeze.json']
        need(manifest['reviewer_source_freeze_sha256'] == reviewer_freeze
             == manifest['files']['review/source-freeze.json'], 'accepted reviewer source differs')
        accepted = self.json(prefix + 'root-approval.json')
        need(accepted['status'] == 'passed' and accepted['scope'] == 'scheduler-bitsets-independent-ir-acceptance'
             and accepted['source_freeze_sha256'] == FREEZE and accepted['measurement_seal_sha256'] == SEAL
             and accepted['variants'] == EXPECTED and accepted['reviewer_source_freeze_sha256'] == reviewer_freeze,
             'root IR acceptance differs')
        for name, field in [('review/review.json', 'review_sha256'), ('review/raw-integrity.json', 'raw_integrity_sha256'),
                            ('collection/transfer-manifest.json', 'transfer_manifest_sha256'),
                            ('collection/receipt.json', 'collection_receipt_sha256')]:
            need(accepted[field] == manifest['files'][name], 'root IR acceptance payload differs')
        need(sha(ir_review) == manifest['files']['review/review.json'], 'native uses a different independent IR review')
        ir = read(ir_review)
        need(ir['policy'] == decide('ir', ir['completed']) and ir['policy']['qualifies'], 'accepted IR primary policy differs')
        need(ir['review_source_freeze_sha256'] == reviewer_freeze
             and ir['launch_receipt_sha256'] == accepted['launch_receipt_sha256'], 'accepted IR source/launch differs')
        transfer = self.json(prefix + 'collection/transfer-manifest.json')
        need(transfer['files'] == ir['raw_file_sha256'], 'accepted IR raw file map differs')
        receipt = self.json(prefix + 'collection/receipt.json')
        need(receipt['status'] == 'passed' and receipt['phase'] == 'ir'
             and receipt['measurement_seal_sha256'] == SEAL
             and receipt['transfer_manifest_sha256'] == ir['transfer_manifest_sha256'], 'accepted IR collection differs')
        return {ROOT + '/' + prefix + name for name in required | {'manifest.json'}}

    def bind(self):
        need(sha(self.remote / 'controller/source-freeze.json') == FREEZE
             and sha(self.remote / 'controller/measurement-seal.json') == SEAL
             and sha(self.remote / 'delivery.json') == DELIVERY, 'copied control identity differs')
        need(self.binding['delivery_sha256'] == DELIVERY and self.binding['variants'] == EXPECTED
             and self.binding['source_trees'] == TREES, 'delivery binding differs')
        need(self.assets['root'] == ROOT and self.assets['host'] == HOST
             and self.assets['variants'] == self.seal['variants'] == EXPECTED
             and self.assets['source_trees'] == self.seal['source_trees'] == TREES
             and self.seal['stages'] == STAGES, 'fixed source/binary/stage identity differs')
        need(self.seal['uv']['commit'] == UV and not self.seal['uv']['status'], 'uv identity differs')
        need(self.setup['state'] == 'prepared-without-warming' and self.setup['host'] == HOST
             and self.setup['root'] == ROOT and self.setup['uv_commit'] == UV, 'setup identity differs')
        need(self.setup['configuration_catalog'] == self.seal['configuration_catalog'], 'configuration catalog differs')
        need(self.setup['controller_path'] == ROOT + '/active/bin:' + ROOT + '/ohm/bin:/usr/bin:/bin'
             and self.setup['controller_affinity'] == [8], 'controller environment differs')
        need(self.files['controller/input-approval.json'] == sha(self.controls / 'input-approval.json'), 'input approval differs')
        need(self.seal['environment_guard'] == {'forbidden_environment_names': [],
             'absent_system_configurations': ['/etc/_rjem_malloc.conf', '/etc/malloc.conf']}, 'allocator/loader policy differs')
        need(self.setup['known_global_configuration'] == {
            'path': '/.cargo/config.toml', 'sha256': '24095bd6315880162c8f660917100ac36638cb73778dd9ec6f1c9026ea87b178',
            'evidence_copy': 'metadata/ancestor-root-config.toml'}, 'global Cargo configuration differs')
        need(sha(self.remote / 'metadata/ancestor-root-config.toml') == self.setup['known_global_configuration']['sha256'], 'global config evidence bytes differ')
        for name, digest in self.assets['files'].items():
            if name in self.files:
                need(self.files[name] == digest, 'copied asset differs: ' + name)
        for name, digest in self.seal['file_sha256'].items():
            if name.startswith(ROOT + '/') and name[len(ROOT) + 1:] in self.files:
                need(self.files[name[len(ROOT) + 1:]] == digest, 'copied sealed input differs: ' + name)
        for name, digest in self.freeze['files'].items():
            need(self.files['controller/' + name] == digest, 'delivered frozen control differs')
        for name, digest in {'controller/driver.py': DRIVER, 'controller/protocol.json': PROTOCOL,
                             'benchmark/frozen/paired.py': CORE, 'benchmark/frozen/paired_repeated.py': REPEATED}.items():
            need(self.files[name] == digest, 'measurement control differs')
        protocol = self.json('controller/protocol.json')
        need(protocol['base_tree'] == TREES['baseline'] and protocol['candidate_tree'] == TREES['candidate']
             and protocol['uv_commit'] == UV and protocol['gate'] == {
                 'minimum_reduction': 0.01, 'confidence': 0.99, 'bootstrap_resamples': 20000,
                 'bootstrap_seed': 1701, 'exact_two_sided_sign_p_max': 0.01,
                 'both_order_point_effects_positive': True, 'both_workflow_integrity_audits_before_any_effects': True,
                  'positive_99_percent_lower_bound': True, 'reduction_interval_lower_endpoint_must_exceed': 0.0,
                  'equivalent_speedup_interval_lower_endpoint_must_exceed': 1.0}, 'protocol identity/gates differ')
        audit = self.json('controller/cohort/results/audit-pair.json')
        pair_review = self.json('controller/cohort/results/root-pair-review.json')
        need(self.files['controller/cohort/results/root-pair-review.json'] == APPROVAL['pair_review_sha256']
             and pair_review['status'] == 'passed' and isinstance(pair_review['checks'], dict) and pair_review['checks']
             and all(type(item) is bool and item for item in pair_review['checks'].values())
             and pair_review['pair_audit_sha256'] == APPROVAL['pair_audit_sha256']
             and pair_review['binaries'] == {name: EXPECTED[variant] for variant, name in NAMES.items()},
             'declared scheduler root pair-review schema or binary bindings differ')
        need(self.files['controller/cohort/results/audit-pair.json']
             == APPROVAL['pair_audit_sha256'], 'fresh production pair audit differs')
        need(audit['common_build_inputs_sha256'] == APPROVAL['common_build_inputs_sha256'], 'build cohort changed')
        for variant, name in NAMES.items():
            row = next(row for row in audit['records'] if row['variant'] == name)
            build = self.json(f'controller/cohort/results/cargo-{name}.build.json')
            strip = self.json(f'controller/cohort/results/cargo-{name}.strip.json')
            need(row['source_tree'] == build['observed_source_tree'] == TREES[variant]
                 and row['stripped_sha256'] == strip['stripped_sha256'] == EXPECTED[variant]
                 and row['verified_allocated_sections'] == 31, 'production binary/source/strip identity differs')
            need(self.assets['files'][f'controller/binaries/cargo-{name}'] == EXPECTED[variant], 'delivered binary is not the fresh pair')
        need(audit['records'][0]['actual_rustc_settings'] == audit['records'][1]['actual_rustc_settings']
             and audit['records'][0]['direct_dependency_names'] == audit['records'][1]['direct_dependency_names'], 'production settings/dependencies differ')
        terminal_name = 'controller/cohort/results/scheduler-bitsets-stack181-reduced.batch-status.json'
        terminal = self.json(terminal_name)
        need(self.files[terminal_name] == APPROVAL['production_terminal_status_sha256']
             and terminal['state'] == 'complete' and set(terminal['completed_variants']) == set(NAMES.values()), 'production did not complete before admission')
        need(self.files['controller/host-assignment.json'] == APPROVAL['host_assignment_sha256']
             == 'a6621248d54d037740663c3289c2084d7867941c26cf48611221b92f50c0638f', 'host assignment differs')
        assignment = self.json('controller/host-assignment.json')
        need(assignment['host'] == HOST and assignment['root'] == ROOT
             and assignment['protocol_sha256'] == PROTOCOL and assignment['production_must_finish_before_admission'], 'host amendment scope differs')
        need(self.files['controller/ci-sequencing-amendment.json'] == APPROVAL['ci_sequencing_amendment_sha256']
             == 'f7e5a3c2b53d3afee28b75d81c7a876955e334b3f0ea65da9c16a225fc669172', 'CI sequencing amendment differs')
        correctness = self.json('controller/correctness/correctness-seal.json')
        reviewed = self.json('controller/correctness/root-source-review.json')
        source_manifest = self.json('controller/correctness/manifest.json')
        need(self.files['controller/correctness/root-source-review.json'] == APPROVAL['candidate_source_review_sha256']
             and self.files['controller/correctness/manifest.json'] == APPROVAL['source_manifest_sha256'], 'accepted source bindings differ')
        need(correctness['status'] == 'sealed' and len(correctness['files']) == 64
             and reviewed['candidate_tree'] == source_manifest['candidate_tree'] == TREES['candidate']
             and source_manifest['base_tree'] == TREES['baseline']
             and source_manifest['base_commit'] == APPROVAL['source_parent_commit']
             and reviewed['status'] == 'passed' and all(reviewed['checks'].values())
             and reviewed['patch_sha256'] == source_manifest['patch_sha256'] == APPROVAL['candidate_patch_sha256']
             == self.files['controller/correctness/candidate.patch']
             and reviewed['correctness_seal_sha256'] == self.files['controller/correctness/correctness-seal.json']
             == APPROVAL['correctness_seal_sha256']
             and correctness['manifest_sha256'] == APPROVAL['source_manifest_sha256'], 'focused correctness prerequisite differs')
        for name, identity in correctness['files'].items():
            relative(name)
            need(self.files['controller/correctness/' + name] == identity['sha256']
                 and (self.remote / 'controller/correctness' / name).stat().st_size == identity['size'], 'correctness evidence differs')
        receipt_name = 'controller/correctness/focused-attempt04/receipt.json'
        receipt = self.json(receipt_name)
        need(self.files[receipt_name] == source_manifest['focused_receipt_sha256']
             and receipt['status'] == 'passed' and receipt['base'] == APPROVAL['source_parent_commit']
             and all(row['returncode'] == 0 for row in receipt['commands']), 'focused test receipt differs')
        need(receipt['inputs'][source_manifest['source_path'] + '/src/util/dependency_queue.rs'] == reviewed['source_sha256']
             == self.files['controller/correctness/focused-attempt03/dependency_queue.rs'], 'tested module source differs')
        for mode, flags in [('debug', ('opt-level=0', 'overflow-checks=yes', 'debug-assertions=yes')),
                            ('optimized', ('opt-level=2', 'overflow-checks=no', 'debug-assertions=no'))]:
            build = next(row for row in receipt['commands'] if row['label'] == mode + '-build')
            need(all(flag in build['argv'] for flag in flags), 'focused arithmetic mode differs')
            tests = next(row for row in receipt['commands'] if row['label'] == mode + '-tests')
            for suffix in ('stdout', 'stderr'):
                need(tests[suffix + '_sha256'] == self.files['controller/correctness/focused-attempt04/' + mode + '-tests.' + suffix], 'focused output differs')
            text = (self.remote / ('controller/correctness/focused-attempt04/' + mode + '-tests.stdout')).read_text()
            need(re.search(r'^test result: ok\. 13 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', text, re.M)
                 and len(re.findall(r'^test .+ \.\.\. ok$', text, re.M)) == 13, 'expected13 focused tests did not all pass')
        need(protocol['ci_sequence']['comparative_observations_before_amendment'] == 0
             and protocol['ci_sequence']['after_fixed_performance_qualification_before_any_pr'] ==
                 'Publish the unchanged exact candidate source for complete GitHub CI; all required jobs must pass before any PR.',
             'mandatory later exact-source CI gate differs')

    def config(self, phase, workflow):
        label = phase + '-' + workflow
        config = self.json('benchmark/' + label + '.json')
        base = self.json('controller/base-configs/' + label + '.json')
        inherited = translated_reference(self.json('controller/references/base-configs/' + label + '.json'))
        need({k: v for k, v in base.items() if k not in ('record_files', 'env')}
             == {k: v for k, v in inherited.items() if k not in ('record_files', 'env')}, 'inherited workload changed')
        need(set(inherited['env']) <= set(base['env'])
             and all(base['env'][k] == v for k, v in inherited['env'].items())
             and all(v is None for k, v in base['env'].items() if k not in inherited['env']), 'inherited environment changed')
        need(base['record_files'][:len(inherited['record_files'])] == inherited['record_files']
             and len(base['record_files']) == len(set(base['record_files'])), 'inherited input prefix changed')
        need({k: v for k, v in config.items() if k != 'record_files'}
             == {k: v for k, v in base.items() if k != 'record_files'}, 'base workload fields changed')
        extra = [ROOT + '/' + name for name in self.assets['files']]
        extra += [ROOT + '/controller/assets.json', ROOT + '/controller/measurement-seal.json',
                  ROOT + '/benchmark/' + label + '.json', ROOT + '/metadata/' + label + '-preflight/report.json']
        if phase == 'native':
            extra.append(ROOT + '/metadata/native-prerequisite.json')
        need(config['record_files'] == list(dict.fromkeys(base['record_files'] + extra)), 'record_files is not the exact base expansion')
        canonical = ROOT + '/active/bin/cargo'
        native_command = ['/usr/bin/taskset', '-c', '0-7', '{cargo}', '-Zohm-defaults=yes', workflow]
        if workflow == 'test':
            native_command.append('--no-run')
        native_command += ['--locked', '--offline', '-j', '8']
        need(config['cwd'] == ROOT + '/uv' and config['canonical_executable'] == canonical
             and config['prepare_command'] == native_command, 'canonical path or build-only workload differs')
        need(config['variants'] == {key: ROOT + '/controller/binaries/cargo-' + value for key, value in NAMES.items()}, 'variant paths differ')
        for key, suffix in [('CARGO_HOME', 'cargo-home'), ('CARGO_TARGET_DIR', 'targets/' + label),
                            ('CARGO_BUILD_BUILD_DIR', 'shared-cache/' + label)]:
            need(config['env'][key] == ROOT + '/' + suffix, 'fixture path differs')
        need(all(value is None for key, value in config['env'].items()
                 if key.startswith(('LD_', 'DYLD_', 'MALLOC', '_RJEM_', 'JEMALLOC')) or key == 'GLIBC_TUNABLES'), 'native loader/allocator override')
        if phase == 'native':
            need(config['command'] == native_command and config['repetitions'] == 8
                 and config['repeatable_workload'] == 'noop' and 'metric_files' not in config, 'native design differs')
        else:
            prefix = ['/usr/bin/taskset', '-c', '0-7', '/usr/bin/env',
                      'LD_PRELOAD=' + ROOT + '/profiling-tools/ohm-valgrind-env.so',
                      'OHM_BENCH_NORMALIZE_VALGRIND_ENV=1', ROOT + '/profiling-tools/valgrind/usr/bin/valgrind',
                      '--tool=callgrind', '--trace-children=no',
                      '--extra-debuginfo-path=' + ROOT + '/profiling-tools/valgrind/usr/lib/debug',
                      '--callgrind-out-file={output}/callgrind-{stage}-{pair}-{variant}.out']
            need(config['command'] == prefix + native_command[3:] and 'repetitions' not in config
                 and config['metric_files'] == {'cargo_ir': {'format': 'callgrind', 'event': 'Ir',
                      'path': '{output}/callgrind-{stage}-{pair}-{variant}.out'}}, 'Cargo-only instruction command differs')
        return config
