#!/usr/bin/env python3
"""Package future root-accepted IR review locally; no transfer or workloads."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import tarfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from cohort_binding import CONTROLLER_PATH, HOST, ROOT, load_input_approval, sha
from native_approval import validate_proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-directory', required=True, type=Path)
    parser.add_argument('--root-approval', required=True, type=Path)
    parser.add_argument('--root-approval-sha256', required=True)
    args = parser.parse_args()
    assert sha(args.root_approval) == args.root_approval_sha256
    freeze = json.loads((HERE / 'source-freeze.json').read_text())
    for name, digest in freeze['files'].items():
        assert sha(HERE / name) == digest
    approval = load_input_approval(HERE)
    launch = json.loads((HERE / 'launch-ir.json').read_text())
    assert launch['returncode'] == 0 and launch['operation'] == 'launch-ir'
    root_approval = json.loads(args.root_approval.read_text())
    assert root_approval['launch_receipt_sha256'] == sha(HERE / 'launch-ir.json')
    mappings = {'root-approval.json': args.root_approval,
        'review/source-freeze.json': HERE / 'reviewer/source-freeze.json',
        'collection/transfer-manifest.json': HERE / 'collections/ir/transfer-manifest.json',
        'collection/receipt.json': HERE / 'collections/ir/receipt.json'}
    for name in ('review.json', 'raw-integrity.json', 'check-reproduced-analysis.json', 'test-reproduced-analysis.json'):
        mappings['review/' + name] = args.review_directory / name
    out = HERE / 'native-prerequisite'
    out.mkdir(exist_ok=False)
    payload = out / 'payload'
    payload.mkdir()
    for name, source in mappings.items():
        assert source.is_file() and not source.is_symlink()
        destination = payload / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    manifest = {'root': ROOT, 'host': HOST, 'controller_path': CONTROLLER_PATH,
        'source_freeze_sha256': sha(HERE / 'source-freeze.json'),
        'reviewer_source_freeze_sha256': sha(HERE / 'reviewer/source-freeze.json'),
        'measurement_seal_sha256': launch['sealed_inputs_sha256'], 'variants': approval['variants'],
        'files': {name: sha(source) for name, source in mappings.items()}}
    (payload / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    validate_proof(payload, launch['sealed_inputs_sha256'], manifest['source_freeze_sha256'],
                   manifest['reviewer_source_freeze_sha256'], approval['variants'],
                   resolve_raw=lambda name: HERE / 'collections/ir/remote' / name)
    with tarfile.open(out / 'payload.tar', 'x:') as archive:
        for name in [*mappings, 'manifest.json']:
            archive.add(payload / name, arcname=name, recursive=False)
    for name, source in mappings.items():
        assert sha(source) == manifest['files'][name] == sha(payload / name)
    receipt = {'status': 'packaged-only', 'manifest_sha256': sha(payload / 'manifest.json'),
        'archive_sha256': sha(out / 'payload.tar'), 'root_approval_sha256': args.root_approval_sha256,
        'measurement_seal_sha256': launch['sealed_inputs_sha256'], 'files': len(mappings),
        'source_freeze_sha256': manifest['source_freeze_sha256']}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
