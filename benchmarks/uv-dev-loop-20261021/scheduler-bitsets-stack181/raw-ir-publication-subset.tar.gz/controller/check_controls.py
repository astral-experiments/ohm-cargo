#!/usr/bin/env python3
"""Pure source/synthetic checks; no historical effects, hosts, Cargo or fixtures."""
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import itertools
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
assert os.sched_getaffinity(0) == {8}, 'Pure checks must run only on CPU8'
sys.path.insert(0, str(HERE))
import cohort_binding as binding
import native_approval
from phase_policy import decide


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def functions(path):
    return {node.name: node for node in ast.parse(path.read_text()).body if isinstance(node, ast.FunctionDef)}


def dump(node):
    return ast.dump(node, include_attributes=False)


def rejected(action):
    try:
        action()
    except (AssertionError, ValueError, KeyError, TypeError):
        return
    raise AssertionError('Malformed synthetic input was accepted')


checks = []
driver = load('scheduler_bitsets_control_checks', HERE / 'driver.py')
sys.path.insert(0, str(HERE / 'reviewer'))
review = load('scheduler_bitsets_review_checks', HERE / 'reviewer/review.py')
statistics_review = sys.modules['statistics_review']
for path in HERE.rglob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
checks.append('Every controller/reviewer source parses without executing any entry point')

BASE = WORK / 'parser-allocations-measurement-controls-local-v2'
old = functions(BASE / 'driver.py')
new = functions(HERE / 'driver.py')
unchanged_driver = ('read', 'sha', 'load_module', 'paths', 'phase_status', 'configuration_catalog',
    'derive', 'audit_sample_tables', 'prepare', 'verify_seal', 'audit_ir', 'gate', 'main')
for name in unchanged_driver:
    assert dump(old[name]) == dump(new[name]), name
checks.append('All13 fixed driver preparation, raw-audit, per-workflow statistics and entry functions have identical ASTs')
run_phase = copy.deepcopy(new['run_phase'])
policy_keywords = order_literals = 0
for node in ast.walk(run_phase):
    if isinstance(node, ast.Call):
        selected = [keyword for keyword in node.keywords if keyword.arg == 'policy']
        if selected:
            assert len(selected) == 1 and dump(selected[0].value) == dump(ast.parse("decide(phase, status['completed'])").body[0].value)
            node.keywords.remove(selected[0])
            policy_keywords += 1
    if isinstance(node, ast.List) and all(isinstance(item, ast.Constant) for item in node.elts):
        if [item.value for item in node.elts] == ['test', 'check']:
            node.elts.reverse()
            order_literals += 1
assert policy_keywords == order_literals == 1 and dump(run_phase) == dump(old['run_phase'])
checks.append('The full phase runner differs only by test-first integrity order and the terminal policy field; its complete sampling/analysis loops are unchanged')
old_review = functions(BASE / 'reviewer/review.py')
new_review = functions(HERE / 'reviewer/review.py')
for name in set(old_review) - {'main'}:
    assert dump(old_review[name]) == dump(new_review[name]), name
checks.append('All13 independent machine/raw/profile/chronology/per-workflow statistical functions have identical ASTs')
assert dump(old_review['machine']) == dump(new_review['machine'])
machine = {'uname': ['Linux', 'charlie-oss-2'], 'uid': 1000, 'effective_uid': 1000,
           'root_directory_owner_uid': 0, 'affinity': [8]}
review.machine(machine)
rejected(lambda: review.machine({**machine, 'affinity': list(range(32))}))
checks.append('Controller machine identity changes only to exact CPU8; timed commands retain explicit CPUs0-7')
for name, reference in [('occupancy.py', WORK / 'inheritance-measurement/occupancy.py'),
                        ('reviewer/statistics_review.py', WORK / 'inheritance-raw-review/statistics_review.py')]:
    assert (HERE / name).read_bytes() == reference.read_bytes()
checks.append('Occupancy guard and independent statistics implementation are byte-identical')

protocol = json.loads((HERE / 'protocol.json').read_text())
frozen_plans = json.loads((HERE / 'plans.json').read_text())
assert binding.sha(HERE / 'protocol.json') == binding.PROTOCOL_SHA
assert driver.STAGES['ir']['plan'] == [('test', 20261021131), ('check', 20261021132)]
assert driver.STAGES['native']['plan'] == [('test', 20261021133), ('check', 20261021134)]
assert driver.STAGES['ir']['pairs'] == 12 and driver.STAGES['native']['pairs'] == 30
for phase in driver.STAGES:
    assert dict(driver.STAGES[phase]['plan']) == protocol[phase]['seeds']
    for workflow, seed in driver.STAGES[phase]['plan']:
        rows = review.plan(driver.STAGES[phase]['pairs'], seed) + review.plan(2, seed ^ 0x5A17)
        assert len(rows) == driver.STAGES[phase]['pairs'] + 2
        frozen = frozen_plans['plans'][phase + '-' + workflow]
        assert frozen['seed'] == seed
        assert frozen['measurement'] == [list(row) for row in review.plan(driver.STAGES[phase]['pairs'], seed)]
        assert frozen['warmup'] == [list(row) for row in review.plan(2, seed ^ 0x5A17)]
checks.append('Exact test-first seeds131-134, 12/30 pairs and two warmup pairs match the prospective protocol')

for phase in ('ir', 'native'):
    for workflow in ('check', 'test'):
        reference = json.loads((HERE / 'references/base-configs' / (phase + '-' + workflow + '.json')).read_text())
        translated = binding.translate_reference(reference)
        assert len(reference['record_files']) == 760
        binding.validate_base_config(translated, reference)
        removed = copy.deepcopy(translated)
        removed['record_files'].pop()
        rejected(lambda: binding.validate_base_config(removed, reference))
        edited = copy.deepcopy(translated)
        edited['prepare_command'].append('--release')
        rejected(lambda: binding.validate_base_config(edited, reference))
        extra = copy.deepcopy(translated)
        extra['env']['RUSTUP_TOOLCHAIN'] = None
        binding.validate_base_config(extra, reference)
        extra['env']['RUSTUP_TOOLCHAIN'] = 'changed'
        rejected(lambda: binding.validate_base_config(extra, reference))
checks.append('All four full 760-input prefixes and commands survive translation; omitted inputs/changed commands/non-null extra environment reject')

with patch.dict('os.environ', {'PATH': binding.CONTROLLER_PATH}, clear=True), patch('os.sched_getaffinity', return_value={8}):
    binding.require_controller_environment()
    with patch.dict('os.environ', {'PATH': '/usr/bin:/bin'}):
        rejected(binding.require_controller_environment)
    with patch('os.sched_getaffinity', return_value={0, 8}):
        rejected(binding.require_controller_environment)
    with patch.dict('os.environ', {'PYTHONPATH': 'unexpected'}):
        rejected(binding.require_controller_environment)
checks.append('Controller exact PATH, CPU8 and clean Python environment fail closed')

identity = {name: hashlib.sha256(name.encode()).hexdigest() for name in ('source', 'seal', 'baseline', 'candidate', 'reviewer', 'launch')}
approval = {'status': 'passed', 'scope': 'scheduler-bitsets-production-inputs',
    'source_freeze_sha256': identity['source'], 'protocol_sha256': binding.PROTOCOL_SHA,
    'root': binding.ROOT, 'host': binding.HOST, 'source_parent_commit': binding.SOURCE_PARENT_COMMIT,
    'source_trees': binding.TREES, 'controller_path': binding.CONTROLLER_PATH,
    'candidate_patch_sha256': binding.PATCH_SHA, 'source_manifest_sha256': binding.SOURCE_MANIFEST_SHA,
    'candidate_source_review_sha256': binding.SOURCE_REVIEW_SHA, 'correctness_seal_sha256': binding.CORRECTNESS_SHA,
    'ci_sequencing_amendment_sha256': binding.CI_AMENDMENT_SHA, 'host_assignment_sha256': binding.HOST_ASSIGNMENT_SHA,
    'cohort': 'host2-scheduler-bitsets-stack181',
    'variants': {key: identity[key] for key in ('baseline', 'candidate')}, 'host_readback_label': 'synthetic-only',
    'checks': {'fresh_matched_pair': True, 'production_audit_passed': True,
               'accepted_exact_source_and_focused_correctness': True, 'focused_13_by_2_passed': True,
               'production_complete_before_admission': True, 'quiet_host_root_absent': True}}
for name in ('pair_audit_sha256', 'pair_review_sha256', 'common_build_inputs_sha256', 'production_manifest_sha256',
             'production_driver_sha256', 'production_terminal_status_sha256', 'host_readback_sha256'):
    approval[name] = hashlib.sha256(name.encode()).hexdigest()
binding.validate_input_approval(approval, identity['source'])
for field, replacement in [('host', 'charlie-oss'), ('root', binding.ROOT + '-other'), ('status', 'pending'),
                           ('protocol_sha256', None), ('pair_audit_sha256', '0' * 64), ('source_trees', {}),
                            ('source_parent_commit', '0' * 40), ('candidate_patch_sha256', '0' * 64),
                            ('candidate_source_review_sha256', None), ('host_assignment_sha256', '0' * 64),
                           ('host_readback_label', '../unsafe'), ('checks', {})]:
    malformed = copy.deepcopy(approval)
    malformed[field] = replacement
    rejected(lambda: binding.validate_input_approval(malformed, identity['source']))
for replacement in (None, '0' * 64, next(iter(binding.OLD_BINARIES)), identity['baseline']):
    malformed = copy.deepcopy(approval)
    malformed['variants']['candidate'] = replacement
    rejected(lambda: binding.validate_input_approval(malformed, identity['source']))
checks.append('Real-input schema rejects pending/zero/missing/old or equal binaries, wrong source/host/root/protocol and unsafe receipt labels')

proof = binding.validate_source_correctness(WORK / 'scheduler-bitsets-candidate', HERE)
assert proof == {'source_tree': binding.TREES['candidate'], 'checked_debug_tests': 13,
                 'wrapping_optimized_tests': 13, 'complete_source_ci_still_required_before_publication': True}
for obsolete in ('source_commit', 'source_ci_sha256'):
    rejected(lambda: binding.validate_input_approval({**approval, obsolete: 'invented'}, identity['source']))
with patch('cohort_binding.CORRECTNESS_SHA', '0' * 64):
    rejected(lambda: binding.validate_source_correctness(WORK / 'scheduler-bitsets-candidate', HERE))
checks.append('Exact accepted tree/patch/root review and all64 correctness files prove13 tests in each arithmetic mode; fabricated candidate-commit/CI fields reject')

production = WORK / 'production-build/host2-scheduler-bitsets-stack181'
manifest = json.loads((production / 'frozen/manifest.json').read_text())
assert binding.sha(production / 'frozen/manifest.json') == driver.BUILD_MANIFEST_SHA
assert binding.sha(production / 'frozen/build_driver_host2_scheduler_bitsets_stack181.py') == driver.BUILD_DRIVER_SHA == manifest['driver_sha256']
assert manifest['performance_protocol_sha256'] == binding.PROTOCOL_SHA
assert manifest['source_manifest_sha256'] == binding.SOURCE_MANIFEST_SHA and manifest['correctness_seal_sha256'] == binding.CORRECTNESS_SHA
for role, name in driver.NAMES.items():
    assert manifest['expected_variants'][name]['tree'] == binding.TREES[role]
    for name, digest in manifest['expected_variants'][name]['patch_sha256'].items():
        assert binding.sha(production / 'frozen' / name) == digest
source_proof = json.loads((production / 'source-tree-proof.json').read_text())
assert source_proof['status'] == 'passed' and source_proof['computed_candidate_tree'] == binding.TREES['candidate']
assert source_proof['incremental_sha256'] == binding.PATCH_SHA
checks.append('Available actual scheduler production manifest/driver/patches/tree replay join the frozen source and protocol; future pair identities remain unbound')

historical = WORK / 'production-build/host2-parser-allocations-stack181'
historical_audit = json.loads((historical / 'results/audit-pair.json').read_text())
historical_manifest = json.loads((historical / 'frozen/manifest.json').read_text())
historical_review = json.loads((historical / 'results/root-pair-review.json').read_text())
assert 'variants' in historical_review and 'binaries' not in historical_review
rejected(lambda: binding.validate_pair_review(historical_review, binding.sha(historical / 'results/audit-pair.json'), approval['variants']))
for row in historical_audit['records']:
    name = row['variant']
    expected = historical_manifest['expected_variants'][name]
    build = json.loads((historical / 'results' / ('cargo-' + name + '.build.json')).read_text())
    strip = json.loads((historical / 'results' / ('cargo-' + name + '.strip.json')).read_text())
    assert row['source_tree'] == build['observed_source_tree'] == build['expected_source_tree_from_patches'] == expected['tree']
    assert build['embedded_source_commit'] == '5e5d271d763d7beb38b48755e22bd59e93f02b97'
    assert build['common_build_inputs_sha256'] == row['common_build_inputs_sha256'] == historical_audit['common_build_inputs_sha256']
    assert build['original_linker_output_sha256'] == strip['source_sha256'] == row['original_linker_output_sha256']
    assert strip['stripped_sha256'] == row['stripped_sha256'] == historical_review['variants'][name]
    assert row['verified_allocated_sections'] == 31
    assert build['observed_diff_sha256'] == expected['canonical_diff_sha256']
    for suffix in ('stdout', 'stderr'):
        assert binding.sha(historical / 'results' / (name + '.' + suffix)) == build[suffix + '_sha256']
checks.append('Actual prior production record corpus covers every reused build/strip field and rejects its incompatible root-review variants schema')

synthetic_pair_review = {'status': 'passed', 'checks': {'synthetic_only': True}, 'pair_audit_sha256': identity['source'],
    'binaries': {name: approval['variants'][role] for role, name in driver.NAMES.items()}}
binding.validate_pair_review(synthetic_pair_review, identity['source'], approval['variants'])
for mutation in (lambda value: value.update(checks={}), lambda value: value['checks'].update(synthetic_only='true'),
                 lambda value: value.update(binaries={}), lambda value: value.update(pair_audit_sha256='0' * 64)):
    malformed = copy.deepcopy(synthetic_pair_review)
    mutation(malformed)
    rejected(lambda: binding.validate_pair_review(malformed, identity['source'], approval['variants']))
checks.append('Declared future root-review binaries contract accepts only exact variant identities, audit binding and nonempty true boolean checks')

with tempfile.TemporaryDirectory(prefix='scheduler-admission-synthetic-') as temporary:
    cohort = Path(temporary)
    results = cohort / 'results'
    results.mkdir()
    terminal = results / 'scheduler-bitsets-stack181-reduced.batch-status.json'
    audit_path = results / 'audit-pair.json'
    review_path = results / 'root-pair-review.json'
    terminal.write_text(json.dumps({'state': 'complete', 'completed_variants': list(driver.NAMES.values())}))
    audit_path.write_text(json.dumps({'cohort': 'host2-scheduler-bitsets-stack181',
        'records': [{'variant': name, 'stripped_sha256': approval['variants'][role]} for role, name in driver.NAMES.items()]}))
    approved_pair = copy.deepcopy(synthetic_pair_review)
    approved_pair['pair_audit_sha256'] = binding.sha(audit_path)
    review_path.write_text(json.dumps(approved_pair))
    admission_review = {'production_terminal_status_sha256': binding.sha(terminal),
        'production_pair_audit_sha256': binding.sha(audit_path), 'production_pair_review_sha256': binding.sha(review_path)}
    assert binding.validate_production_admission(cohort, admission_review) == admission_review
    terminal.write_text(json.dumps({'state': 'running', 'completed_variants': list(driver.NAMES.values())}))
    rejected(lambda: binding.validate_production_admission(cohort, admission_review))
    changed = {**admission_review, 'production_terminal_status_sha256': binding.sha(terminal)}
    rejected(lambda: binding.validate_production_admission(cohort, changed))
checks.append('Post-build admission accepts a complete hash-bound synthetic pair and rejects changed or honestly hash-bound still-running status before any host call')

policy_review = sys.modules['policy_review']
def decision(name, passed, low=.01, high=.03, sign=.001):
    return {'workflow': name, 'passes_gate': passed, 'interval_99': [low, high], 'sign_p': sign,
            'significant_native_regression': high < 0 and sign <= .01}

policy_cases = [
    ('ir', [decision('test', False), decision('check', True)], False, {'test': False, 'check': False}, [], 'secondary cannot rescue failed primary'),
    ('ir', [decision('test', True), decision('check', False, -.03, -.01)], False, {'test': False, 'check': False}, ['check'], 'established secondary IR regression blocks'),
    ('ir', [decision('test', True), decision('check', False, .003, .007)], True, {'test': True, 'check': False}, [], 'sub1percent positive secondary permits primary but no check claim'),
    ('ir', [decision('test', True), decision('check', False, -.01, .01, .2)], True, {'test': True, 'check': False}, [], 'inconclusive secondary permits primary only'),
    ('ir', [decision('test', True), decision('check', True)], True, {'test': True, 'check': True}, [], 'secondary improvement requires its own full gate'),
    ('ir', [decision('test', True), decision('check', False, -.03, -.01, .01)], False, {'test': False, 'check': False}, ['check'], 'regression sign boundary is inclusive'),
    ('ir', [decision('test', True), decision('check', False, -.03, 0, .001)], True, {'test': True, 'check': False}, [], 'zero upper endpoint is not established regression'),
    ('native', [decision('test', False, -.03, -.01), decision('check', True)], False, {'test': False, 'check': False}, ['test'], 'native primary regression blocks'),
    ('native', [decision('test', True), decision('check', False, -.03, -.01)], False, {'test': False, 'check': False}, ['check'], 'native secondary regression blocks'),
    ('native', [decision('test', False, -.01, .01, .2), decision('check', False, -.01, .01, .2)], True, {'test': False, 'check': False}, [], 'inconclusive native results retain IR qualification without wall claims'),
    ('native', [decision('test', True), decision('check', False, .003, .007)], True, {'test': True, 'check': False}, [], 'only independently passing native workflow receives wall claim'),
]
for phase, completed, qualifies, claims, regressions, label in policy_cases:
    observed = decide(phase, completed)
    assert observed == policy_review.decide(phase, completed)
    assert observed['qualifies'] is qualifies and observed['improvement_claims'] == claims and observed['established_regressions'] == regressions
    checks.append('Independent policy case: ' + label)
for completed in ([decision('check', True), decision('test', True)], [decision('test', True)],
                  [decision('test', True), decision('check', False, float('nan'), .01)]):
    rejected(lambda: decide('ir', completed))
    rejected(lambda: policy_review.decide('ir', completed))
checks.append('Both policy implementations reject incomplete/reordered/nonfinite gate evidence')

def simulated_ir_phase(fail_second_audit):
    events = []
    with tempfile.TemporaryDirectory(prefix='scheduler-policy-synthetic-') as temporary:
        root = Path(temporary)
        (root / 'logs').mkdir()
        (root / 'results').mkdir()
        tick = itertools.count()
        def atomic(path, value):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value) + '\n')
        core = SimpleNamespace(utc_now=lambda: str(next(tick)), atomic_json=atomic)
        reference = SimpleNamespace(quiet=lambda: {}, preflight=lambda unused, workflow: events.append('preflight-' + workflow), uv_identity=lambda: {'synthetic_only': True})
        def subprocess_stub(argv, **unused):
            assert argv[3] in (str(driver.CORE), str(driver.RUNNER))
            if argv[4] == 'run':
                destination = Path(argv[argv.index('--output') + 1])
                destination.mkdir()
                events.append('sample-' + destination.name.removeprefix('ir-'))
            elif argv[4] == 'analyze':
                events.append('analyze-' + Path(argv[5]).name.removeprefix('ir-'))
            else:
                raise AssertionError('Unexpected synthetic process call')
            return SimpleNamespace(returncode=0)
        def audit(unused, workflow, seed):
            events.append('raw-' + workflow)
            if fail_second_audit and workflow == 'check':
                raise ValueError('synthetic second raw audit failure')
            return {'state': 'passed'}
        def fake_gate(phase, destination):
            workflow = destination.name.removeprefix('ir-')
            return {key: value for key, value in decision(workflow, True).items() if key != 'workflow'}
        with patch.object(driver, 'ROOT', root), patch.object(driver, 'verify_assets', return_value={'variants': approval['variants']}), \
             patch.object(driver, 'verify_seal'), patch.object(driver, 'reference', return_value=reference), \
             patch.object(driver, 'audit_ir', side_effect=audit), patch.object(driver, 'gate', side_effect=fake_gate), \
             patch('subprocess.run', side_effect=subprocess_stub):
            if fail_second_audit:
                rejected(lambda: driver.run_phase(core, 'ir', identity['seal']))
            else:
                driver.run_phase(core, 'ir', identity['seal'])
        status = json.loads((root / 'results/ir-status.json').read_text())
        assert status['state'] == ('failed' if fail_second_audit else 'complete')
        if fail_second_audit:
            assert not any(event.startswith('analyze-') for event in events)
        else:
            assert max(events.index('raw-' + name) for name in ('test', 'check')) < min(events.index('analyze-' + name) for name in ('test', 'check'))
    return events

assert simulated_ir_phase(False).count('sample-test') == 1
checks.append('Pure mocked full runner completes both fixed workflows/raw audits before either analysis call')
simulated_ir_phase(True)
checks.append('Pure mocked second-workflow raw failure retains failed status and prevents every effect calculation')
main_calls = [(node.func.id, node.lineno) for node in ast.walk(new_review['main']) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
assert max(line for name, line in main_calls if name == 'raw_workflow') < min(line for name, line in main_calls if name == 'analyze')
checks.append('Independent reviewer retains both raw-workflow joins and raw-integrity receipt before its first analysis invocation')

with tempfile.TemporaryDirectory(prefix='scheduler-bitset-pure-') as temporary:
    directory = Path(temporary)
    profile = directory / 'profile'
    profile.write_text('events: Dr Ir Dw\nsummary: 1 12345 2\n')
    assert review.profile_count(profile) == 12345
    for bad in ('events: Ir Ir\nsummary: 1 2\n', 'events: Ir\nsummary: 1\nsummary: 2\n',
                'events: Dr\nsummary: 1\n', 'events: Ir\nsummary: -1\n'):
        profile.write_text(bad)
        rejected(lambda: review.profile_count(profile))
    checks.append('Actual profile parser selects Ir and rejects ambiguous, duplicate, absent or negative counters')
    for phase, count in [('ir', 12), ('native', 30)]:
        pairs = [{'baseline': 102.0, 'candidate': 100.0, 'order': 'AB' if index % 2 else 'BA'} for index in range(count)]
        synthetic = statistics_review.counts(pairs) if phase == 'ir' else statistics_review.paired(pairs)
        assert statistics_review.gate(phase, synthetic)['passes_gate']
        analysis = {'confidence': 0.99, 'bootstrap_resamples': 20000, 'bootstrap_seed': 1701,
                    'metrics': {'cargo_ir': {'statistics': synthetic}}} if phase == 'ir' else {
                        **synthetic, 'grouping': {'repetitions_per_variant': 8}}
        (directory / 'analysis.json').write_text(json.dumps(analysis))
        assert driver.gate(phase, directory) == statistics_review.gate(phase, synthetic)
        broken = copy.deepcopy(synthetic)
        broken['exact_two_sided_sign_p'] = 0.02
        assert not statistics_review.gate(phase, broken)['passes_gate']
        key = 'geometric_mean_ratio' if phase == 'ir' else 'geometric_mean_speedup'
        broken = copy.deepcopy(synthetic)
        broken['order']['BA'][key] = 1.0
        assert not statistics_review.gate(phase, broken)['passes_gate']
    checks.append('Synthetic positive/negative decisions agree with unchanged driver and independent gates, including exact sign/order requirements')
    native = statistics_review.paired([{'baseline': 100.0, 'candidate': 103.0, 'order': 'AB' if index % 2 else 'BA'} for index in range(30)])
    assert statistics_review.gate('native', native)['significant_native_regression']
    checks.append('Independent native regression gate rejects the same synthetic 99% negative effect')

    proof = directory / 'synthetic-proof'
    raw_directory = directory / 'synthetic-raw'
    proof.mkdir()

    def write_json(path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, sort_keys=True) + '\n')
        return binding.sha(path)

    raw_names = {'results/ir-status.json'} | {
        'results/ir-' + workflow + '/' + name for workflow in ('check', 'test')
        for name in ('manifest.json', 'samples.json', 'samples.jsonl', 'samples.csv', 'integrity.json', 'analysis.json', 'gate.json')}
    raw_files = {name: write_json(raw_directory / name, {'synthetic_only': name}) for name in sorted(raw_names)}
    reviewer_sha = write_json(proof / 'review/source-freeze.json', {'synthetic_only': True})
    transfer = {'phase': 'ir', 'root': binding.ROOT, 'seal_sha256': identity['seal'], 'files': raw_files}
    transfer_sha = write_json(proof / 'collection/transfer-manifest.json', transfer)
    receipt_sha = write_json(proof / 'collection/receipt.json', {'status': 'passed', 'phase': 'ir',
        'measurement_seal_sha256': identity['seal'], 'transfer_manifest_sha256': transfer_sha})
    workflows = [{'workflow': name, 'synthetic_only': True} for name in ('test', 'check')]
    raw_sha = write_json(proof / 'review/raw-integrity.json', {'status': 'passed', 'phase': 'ir',
        'workflows': workflows, 'analysis_files_parsed': False, 'statistics_computed': False,
        'transfer_manifest_sha256': transfer_sha})
    synthetic_review = {'status': 'passed', 'phase': 'ir', 'qualifies': True, 'integrity_status': 'passed',
        'statistics_computed': True, 'final_evidence_and_review_source_rehash': 'passed',
        'source_freeze_sha256': identity['source'], 'measurement_seal_sha256': identity['seal'],
        'variants': approval['variants'], 'review_source_freeze_sha256': reviewer_sha,
        'launch_receipt_sha256': identity['launch'], 'transfer_manifest_sha256': transfer_sha,
        'bootstrap': {'confidence': 0.99, 'resamples': 20000, 'seed': 1701},
        'completed': [{'workflow': 'test', 'passes_gate': True, 'interval_99': [.01, .03], 'sign_p': .001},
                      {'workflow': 'check', 'passes_gate': False, 'interval_99': [.003, .007], 'sign_p': .001}],
        'workflows': workflows, 'raw_file_sha256': raw_files}
    synthetic_review['policy'] = decide('ir', synthetic_review['completed'])
    review_sha = write_json(proof / 'review/review.json', synthetic_review)
    for workflow in ('check', 'test'):
        write_json(proof / ('review/' + workflow + '-reproduced-analysis.json'), {'synthetic_only': True})
    write_json(proof / 'root-approval.json', {'status': 'passed',
        'scope': 'scheduler-bitsets-independent-ir-acceptance', 'source_freeze_sha256': identity['source'],
        'measurement_seal_sha256': identity['seal'], 'variants': approval['variants'],
        'reviewer_source_freeze_sha256': reviewer_sha, 'review_sha256': review_sha,
        'raw_integrity_sha256': raw_sha, 'transfer_manifest_sha256': transfer_sha,
        'collection_receipt_sha256': receipt_sha, 'launch_receipt_sha256': identity['launch']})
    proof_manifest = {'root': binding.ROOT, 'host': binding.HOST, 'controller_path': binding.CONTROLLER_PATH,
        'measurement_seal_sha256': identity['seal'], 'source_freeze_sha256': identity['source'],
        'reviewer_source_freeze_sha256': reviewer_sha, 'variants': approval['variants'],
        'files': {name: binding.sha(proof / name) for name in sorted(native_approval.REQUIRED)}}
    write_json(proof / 'manifest.json', proof_manifest)

    def validate_proof():
        return native_approval.validate_proof(proof, identity['seal'], identity['source'], reviewer_sha,
                                             approval['variants'], lambda name: raw_directory / name)

    assert validate_proof() == proof_manifest
    checks.append('Synthetic native prerequisite accepts primary IR with sub1percent positive check, joining all eight payloads and exact source/variant/seal/raw identities')
    for missing in sorted(native_approval.REQUIRED):
        malformed = copy.deepcopy(proof_manifest)
        del malformed['files'][missing]
        write_json(proof / 'manifest.json', malformed)
        rejected(validate_proof)
        write_json(proof / 'manifest.json', proof_manifest)
        checks.append('Native prerequisite rejects missing manifest binding: ' + missing)
    for name, field, value in [('root-approval.json', 'source_freeze_sha256', 'wrong'),
                               ('review/review.json', 'qualifies', False),
                               ('review/review.json', 'review_source_freeze_sha256', 'wrong'),
                               ('review/raw-integrity.json', 'statistics_computed', True),
                               ('collection/receipt.json', 'status', 'failed')]:
        original = (proof / name).read_bytes()
        malformed = json.loads(original)
        malformed[field] = value
        new_hash = write_json(proof / name, malformed)
        changed = copy.deepcopy(proof_manifest)
        changed['files'][name] = new_hash
        write_json(proof / 'manifest.json', changed)
        rejected(validate_proof)
        (proof / name).write_bytes(original)
        write_json(proof / 'manifest.json', proof_manifest)
        checks.append('Native prerequisite rejects altered accepted metadata: ' + name + '/' + field)
    original = (raw_directory / 'results/ir-status.json').read_bytes()
    (raw_directory / 'results/ir-status.json').write_bytes(original + b' ')
    rejected(validate_proof)
    (raw_directory / 'results/ir-status.json').write_bytes(original)
    checks.append('Native prerequisite rejects changed raw IR bytes before any calls')
    assert validate_proof() == proof_manifest

# No runtime entry can run during these checks: validate only the emitted code strings.
for filename in ('readback_host.py', 'stage.py', 'collect.py'):
    tree = ast.parse((HERE / filename).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'remote' for target in node.targets):
            value = node.value
            while isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute):
                value = value.func.value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                ast.parse(value.value)
checks.append('Every embedded remote controller parses; no remote statement was executed')
prepare = (HERE / 'prepare_host.py').read_text()
assert "command('uv-public-fetch', [str(baseline), '-Zohm-defaults=yes', 'fetch', '--locked']" in prepare
assert "'--prepare'" in prepare and "'--run-phase'" not in prepare
assert 'ref.preflight(' not in prepare
checks.append('Metadata preparation only fetches dependencies and seals inputs; fixed fixture warming is in the separately approved phase entry')
for forbidden in ('input-approval.json', 'source-review.json', 'delivery', 'collections', 'native-prerequisite', 'setup-review.json'):
    assert not (HERE / forbidden).exists(), forbidden
checks.append('No placeholder approval, delivery, fixture, collection or native prerequisite has been produced')

report = {'status': 'passed', 'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Source ASTs, reference configuration data, and temporary synthetic metadata/statistics only; no actual effects or hosts.',
    'checks': checks, 'count': len(checks), 'driver_unchanged_functions': list(unchanged_driver),
    'reviewer_unchanged_functions': sorted(set(old_review) - {'main'}),
    'source_sha256': {str(path.relative_to(HERE)): binding.sha(path) for path in sorted(HERE.rglob('*.py'))}}
destination = HERE / 'pure-checks.json'
with destination.open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
