#!/usr/bin/env python3
"""Bind the finished matched pair to reviewed controls; package locally only."""
import argparse
import datetime
import sys
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from cohort_binding import load_input_approval, validate_source_correctness, validate_pair_review
WORK = HERE.parent
COHORT = WORK / 'production-build/host2-scheduler-bitsets-stack181'
ROOT = '/tmp/ohm-hillclimb-20261021/scheduler-bitsets-stack181'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-approval-sha256', required=True)
args = parser.parse_args()
assert sha(HERE / 'input-approval.json') == args.input_approval_sha256
approval = load_input_approval(HERE)
source = json.loads((HERE / 'source-freeze.json').read_text())
for filename, digest in source['files'].items():
    assert sha(HERE / filename) == digest, filename
for filename, digest in source['external_inputs'].items():
    assert sha(WORK / filename) == digest, filename
review = json.loads((HERE / 'source-review.json').read_text())
assert review['status'] == 'passed' and review['source_freeze_sha256'] == sha(HERE / 'source-freeze.json')
audit = json.loads((COHORT / 'results/audit-pair.json').read_text())
assert sha(COHORT / 'results/audit-pair.json') == approval['pair_audit_sha256']
assert sha(COHORT / 'results/root-pair-review.json') == approval['pair_review_sha256']
pair_review = json.loads((COHORT / 'results/root-pair-review.json').read_text())
validate_pair_review(pair_review, sha(COHORT / 'results/audit-pair.json'), approval['variants'])
assert pair_review['status'] == 'passed' and all(pair_review['checks'].values())
assert pair_review['pair_audit_sha256'] == sha(COHORT / 'results/audit-pair.json')
assert audit['cohort'] == 'host2-scheduler-bitsets-stack181'
assert audit['common_build_inputs_sha256'] == approval['common_build_inputs_sha256']
assert audit['frozen_input_manifest_sha256'] == sha(COHORT / 'frozen/manifest.json') == approval['production_manifest_sha256']
assert audit['provenance_sha256'] == sha(COHORT / 'results/provenance.json')
assert audit['audit_script_sha256'] == sha(COHORT / 'audit.py')
assert audit['collector_sha256'] == sha(COHORT / 'collect_variant.py')
names = {'baseline': 'scheduler-bitsets-stack181-baseline', 'candidate': 'scheduler-bitsets-stack181-reduced'}
trees = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e', 'candidate': '807c36ec5326d42ca19a921819e1b3d1e2776cb2'}
assert {row['variant'] for row in audit['records']} == set(names.values())
variants = {}
files = {'controller/' + name: HERE / name for name in source['files']}
files.update({'controller/source-freeze.json': HERE / 'source-freeze.json',
              'controller/source-review.json': HERE / 'source-review.json',
              'controller/protocol.json': HERE / 'protocol.json',
              'controller/input-approval.json': HERE / 'input-approval.json',
              'controller/reference-native-controller.py': WORK / 'allocator-native/native_controller-v4.py',
              'benchmark/frozen/paired.py': WORK / 'benchmark/frozen/paired.py',
              'benchmark/frozen/paired_repeated.py': WORK / 'benchmark/frozen/paired_repeated.py',
              'profiling-tools/ohm-valgrind-env.c': WORK / 'profiling-tools/ohm-valgrind-env.c',
              'profiling-tools/ohm-valgrind-env.so': WORK / 'profiling-tools/ohm-valgrind-env.so',
              'assets/ohm-1.99.0-6-x86_64-unknown-linux-gnu.tar.gz': WORK / 'ohm-1.99.0-6-x86_64-unknown-linux-gnu.tar.gz'})
readback_label = approval['host_readback_label']
readback = json.loads((HERE / (readback_label + '.json')).read_text())
assert sha(HERE / (readback_label + '.json')) == approval['host_readback_sha256']
assert readback['returncode'] == 0 and readback['host'] == 'charlie-oss-2' and readback['root'] == ROOT
assert readback['source_freeze_sha256'] == sha(HERE / 'source-freeze.json')
assert readback['production_terminal_status_sha256'] == approval['production_terminal_status_sha256']
assert readback['production_pair_audit_sha256'] == approval['pair_audit_sha256']
assert readback['production_pair_review_sha256'] == approval['pair_review_sha256']
snapshot = json.loads((HERE / (readback_label + '.stdout')).read_text())
assert snapshot['root_absent'] and snapshot['uid'] == 1000 and snapshot['root'] == ROOT
assert snapshot['host'] == 'charlie-oss-2' and not snapshot['quiet']['other_workloads']
for suffix in ('stdout', 'stderr'):
    assert sha(HERE / (readback_label + '.' + suffix)) == readback[suffix + '_sha256']
for suffix in ('json', 'stdout', 'stderr'):
    files['controller/host-readback.' + suffix] = HERE / (readback_label + '.' + suffix)
for name in ('valgrind_1%3a3.22.0-0ubuntu3_amd64.deb', 'libc6-dbg_2.39-0ubuntu8.9_amd64.deb'):
    files['assets/' + name] = WORK / 'profiling-tools' / name
for name in ('native_controller-v2.py', 'native_controller-v3.py', 'native_controller-v4.py',
             'occupancy-amendment-v4.json', 'root-occupancy-v4-review.json', 'OCCUPANCY-AMENDMENT-v4.md',
             'controller-occupancy-v4.diff', 'check_occupancy_v4.py', 'controller-occupancy-v4-checks.json',
             'warming-amendment-v3.json', 'root-warming-v3-review.json', 'WARMING-AMENDMENT-v3.md',
             'controller-warming-v3.diff', 'controller-warming-v3-ast-proof.json',
             'warming-amendment-v3-draft01.json', 'WARMING-AMENDMENT-v3-draft01.md',
             'controller-warming-v3-ast-proof-draft01.json'):
    files['controller/' + name] = WORK / 'allocator-native' / name
for path in sorted((COHORT / 'frozen').iterdir()):
    assert path.is_file() and not path.is_symlink()
    files['controller/cohort/frozen/' + path.name] = path
for name in ('audit.py', 'collect_variant.py', 'build_driver_host2_scheduler_bitsets_stack181.py'):
    files['controller/cohort/' + name] = COHORT / name
for name in ('audit-pair.json', 'root-pair-review.json', 'provenance.json', 'ownership.json'):
    files['controller/cohort/results/' + name] = COHORT / 'results' / name
for variant, name in names.items():
    binary = COHORT / 'results' / ('cargo-' + name)
    row = next(row for row in audit['records'] if row['variant'] == name)
    assert row['source_tree'] == trees[variant]
    assert row['common_build_inputs_sha256'] == audit['common_build_inputs_sha256']
    variants[variant] = sha(binary)
    assert variants[variant] == row['stripped_sha256']
    files['controller/binaries/' + binary.name] = binary
    for suffix in ('.build.json', '.strip.json'):
        files['controller/cohort/results/' + binary.name + suffix] = COHORT / 'results' / (binary.name + suffix)
    for suffix in ('.stdout', '.stderr', '.source.patch', '.occupancy.json', '.batch-status.json'):
        files['controller/cohort/results/' + name + suffix] = COHORT / 'results' / (name + suffix)
assert variants == approval['variants']
assert audit['build_driver_sha256'] == approval['production_driver_sha256']
terminal = COHORT / 'results/scheduler-bitsets-stack181-reduced.batch-status.json'
assert sha(terminal) == approval['production_terminal_status_sha256']
status = json.loads(terminal.read_text())
assert status['state'] == 'complete' and set(status['completed_variants']) == set(names.values())
correctness = WORK / 'scheduler-bitsets-candidate'
proof = json.loads((correctness / 'correctness-seal.json').read_text())
assert sha(correctness / 'correctness-seal.json') == approval['correctness_seal_sha256']
validate_source_correctness(correctness, HERE)
for name, identity in proof['files'].items():
    assert sha(correctness / name) == identity['sha256'] and (correctness / name).stat().st_size == identity['size']
    files['controller/correctness/' + name] = correctness / name
for name in ('correctness-seal.json', 'root-source-review.json'):
    files['controller/correctness/' + name] = correctness / name
out = HERE / 'delivery'
out.mkdir(exist_ok=False)
record = {'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'root': ROOT, 'host': 'charlie-oss-2',
          'source_freeze_sha256': sha(HERE / 'source-freeze.json'), 'source_review_sha256': sha(HERE / 'source-review.json'),
          'variants': variants, 'source_trees': trees, 'files': {name: sha(path) for name, path in files.items()}}
assert record['files']['assets/ohm-1.99.0-6-x86_64-unknown-linux-gnu.tar.gz'] == '98a4f4f99ea1ff36e10209258724426496afbbcab14d746294fe53a2fedad37c'
(out / 'delivery.json').write_text(json.dumps(record, indent=2) + '\n')
files['delivery.json'] = out / 'delivery.json'
with tarfile.open(out / 'payload.tar', 'x:') as archive:
    for name, path in files.items():
        assert path.is_file() and not path.is_symlink()
        archive.add(path, arcname=name, recursive=False)
for name, digest in record['files'].items():
    assert sha(files[name]) == digest, name
binding = {'delivery_sha256': sha(out / 'delivery.json'), 'archive_sha256': sha(out / 'payload.tar'),
           'variants': variants, 'source_trees': trees, 'files': len(record['files']),
           'status': 'packaged-locally-not-staged', 'no_performance_execution': True}
(out / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps(binding, indent=2))
