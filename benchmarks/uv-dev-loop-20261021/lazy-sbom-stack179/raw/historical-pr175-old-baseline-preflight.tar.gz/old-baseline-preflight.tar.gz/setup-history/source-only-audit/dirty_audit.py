#!/usr/bin/env python3
"""Audit dirty uv compiler commands and test nonexecution separately from effects."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shlex

import dirty_fixture
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def option(arguments, name):
    for index, argument in enumerate(arguments):
        if argument == name:
            return arguments[index + 1]
        if argument.startswith(name + '='):
            return argument.split('=', 1)[1]
    return None


def parse_run(stdout, stderr):
    artifacts, finished = [], []
    for line in stdout.splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get('reason') == 'compiler-artifact':
            artifacts.append(message)
        elif message.get('reason') == 'build-finished':
            finished.append(message.get('success'))
    if not artifacts or finished != [True]:
        raise ValueError('missing compiler-artifact records or successful build-finished record')
    commands, other = [], []
    for line in stderr.splitlines():
        match = re.match(r'^\s*Running `(.+)`$', line)
        if not match:
            continue
        arguments = shlex.split(match[1])
        if '--crate-name' not in arguments:
            other.append(arguments)
            continue
        source = [arg for arg in arguments if arg.endswith('.rs') and not arg.startswith('-')]
        if len(source) != 1:
            raise ValueError('rustc source argument is ambiguous')
        commands.append({
            'executable': arguments[0], 'crate': option(arguments, '--crate-name'),
            'source': source[0], 'crate_type': option(arguments, '--crate-type'),
            'test': '--test' in arguments, 'emit': option(arguments, '--emit'),
        })
    signatures = Counter(json.dumps({key: value for key, value in command.items() if key != 'executable'}, sort_keys=True) for command in commands)
    compiled = [message for message in artifacts if not message['fresh']]
    test_executables = sorted({message['executable'] for message in artifacts if message['profile']['test'] and message.get('executable')})
    return {
        'compiler_commands': commands, 'other_commands': other,
        'compiler_signatures': dict(sorted(signatures.items())),
        'compiled_packages': sorted({message['package_id'] for message in compiled}),
        'compiled_targets': sorted(({'name': message['target']['name'], 'kind': message['target']['kind'], 'test': message['profile']['test']} for message in compiled), key=lambda row: json.dumps(row, sort_keys=True)),
        'test_executables': test_executables,
        'fresh_artifacts': sum(message['fresh'] for message in artifacts),
        'compiled_artifacts': len(compiled),
        'progress_packages': dirty_fixture.compile_packages(stderr),
    }


def validate_run(report, rustc, uv_package, expected=None):
    if report['progress_packages'] != ['uv'] or report['compiled_packages'] != [uv_package]:
        raise ValueError('dirty workload compiled a package other than uv or became a no-op')
    if not report['compiler_commands'] or report['other_commands']:
        raise ValueError('expected rustc commands only; build-script/test execution is unexpected')
    if any(command['executable'] != rustc for command in report['compiler_commands']):
        raise ValueError('unexpected rustc executable')
    if any(not command['source'].startswith('crates/uv/') for command in report['compiler_commands']):
        raise ValueError('unexpected dirty crate source')
    if expected is not None:
        for key in ('compiler_signatures', 'compiled_targets', 'compiled_artifacts'):
            if report[key] != expected[key]:
                raise ValueError(f'dirty compiler work changed from frozen diagnostic: {key}')


def trace_executables(text):
    paths = []
    pending = {}
    for line in text.splitlines():
        pid = re.match(r'^(?:\[pid\s+)?(\d+)(?:\])?\s+', line)
        if '<unfinished ...>' in line:
            if pid is None or pid[1] in pending:
                raise ValueError('ambiguous unfinished execve record')
            pending[pid[1]] = line.split('<unfinished ...>', 1)[0]
            continue
        resumed = re.search(r'<\.\.\. execve(?:at)? resumed>(.*)', line)
        if resumed:
            if pid is None or pid[1] not in pending:
                raise ValueError('execve resume has no beginning')
            line = pending.pop(pid[1]) + resumed[1]
        if not re.search(r'= 0\s*$', line):
            continue
        match = re.search(r'execve\(("(?:\\.|[^"\\])*")', line)
        if match is None:
            match = re.search(r'execveat\([^,]+,\s*("(?:\\.|[^"\\])*")', line)
        if match is None:
            raise ValueError('unparsed successful execve record')
        path = json.loads(match[1])
        if not path:
            raise ValueError('successful execveat has no auditable path')
        paths.append(path)
    if pending:
        raise ValueError('unfinished execve record remains')
    return paths


def validate_no_tests(report, trace):
    executables = trace_executables(trace)
    tests = set(report['test_executables'])
    if tests.intersection(executables):
        raise ValueError('a compiled test executable actually ran')
    if not executables:
        raise ValueError('empty successful execve trace')
    return executables


def verify_batch(guard_path, state, results, expectations, workload):
    guard = dirty_guard.check(guard_path, state, restored=True)
    results = Path(results).resolve()
    fixture = dirty_fixture.verify(state, results, ['uv'])
    frozen = json.loads(Path(expectations).read_text())
    manifest = json.loads((results / 'manifest.json').read_text())
    samples = json.loads((results / 'samples.json').read_text())
    if manifest['variant_sha256'] != manifest['variant_sha256_after'] or manifest['recorded_file_sha256'] != manifest['recorded_file_sha256_after']:
        raise ValueError('frozen inputs changed during the batch')
    rows = []
    for sample in samples:
        report = parse_run(Path(sample['stdout']).read_text(), Path(sample['stderr']).read_text())
        validate_run(report, frozen['rustc'], frozen['uv_package'], frozen['workloads'][workload])
        if workload == 'test' and '--no-run' not in sample['command']:
            raise ValueError('test measurement omitted --no-run')
        rows.append({
            'stage': sample['stage'], 'pair': sample['pair'], 'variant': sample['variant'],
            'stdout_sha256': sha(sample['stdout']), 'stderr_sha256': sha(sample['stderr']), **report,
        })
    output = {
        'valid': True, 'source_restored': True, 'source_identity': guard['source_identity'],
        'fixture_validation_valid': fixture['valid'], 'expectations_sha256': sha(expectations),
        'samples': rows,
    }
    dirty_fixture.write_json(results / 'compiler-audit.json', output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--guard', required=True)
    parser.add_argument('--state', required=True)
    parser.add_argument('--results', required=True)
    parser.add_argument('--expectations', required=True)
    parser.add_argument('--workload', required=True, choices=('check', 'test'))
    args = parser.parse_args()
    result = verify_batch(args.guard, args.state, args.results, args.expectations, args.workload)
    print(json.dumps({'valid': result['valid'], 'source_restored': result['source_restored'], 'samples': len(result['samples'])}))


if __name__ == '__main__':
    main()
