#!/usr/bin/env python3
"""Seed baseline native prerequisites and record noncomparative execution evidence."""
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import traceback

import dirty_audit
import dirty_guard
import paired

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
BASELINE = '63495905e7b0b11ad99fa4c2c2674e43657b9902a2e3142ef735fd83efa44cf8'


def now():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    guard_path = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.check(guard_path, restored=True)
    setup = json.loads((ROOT / 'setup.json').read_text())
    assets = json.loads((ROOT / 'metadata/baseline-seed-assets.json').read_text())
    for path, expected in assets.items():
        assert paired.sha256(path) == expected, path
    for relative, expected in setup['frozen_helper_sha256'].items():
        assert paired.sha256(ROOT / relative) == expected
    assert paired.sha256(ROOT / 'binaries/cargo-pr175') == BASELINE
    output = ROOT / 'diagnostics/baseline-seed-01'
    output.mkdir(parents=True, exist_ok=False)
    (output / 'logs').mkdir()
    state = None
    cleanup = None
    manifest = {'state': 'running', 'started_at': now(), 'purpose': 'Baseline-only native seed and execution validation; no candidate or comparative performance samples', 'baseline_sha256': BASELINE, 'runs': []}
    write(output / 'manifest.json', manifest)
    lock = (ROOT / 'experiment.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        paired.install_variant(ROOT / 'binaries/cargo-pr175', ROOT / 'active/bin/cargo')
        for workload in ('test', 'check'):
            config = json.loads((ROOT / 'configs' / f'{workload}-ir-exploratory.pending.json').read_text())
            state = ROOT / 'fixtures' / f'{workload}-diagnostic'
            guard = dirty_guard.check(guard_path, state, restored=True)
            command = guard['commands'][workload]
            environment = os.environ.copy()
            for key, value in {**config['env'], **config['variant_env']['baseline']}.items():
                if value is None:
                    environment.pop(key, None)
                else:
                    environment[key] = str(value)
            batch = output / workload
            batch.mkdir()
            cleanup = ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'restore', '--guard', str(guard_path), '--state', str(state)]
            prepare = ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'prepare', '--guard', str(guard_path), '--state', str(state), '--batch', str(batch), '--stage', 'measurement', '--pair', '0', '--variant', 'baseline', '--', *command]
            print(f'{now()} native baseline {workload} seed started', flush=True)
            with (output / 'logs' / f'{workload}.prepare.stdout').open('xb') as stdout, (output / 'logs' / f'{workload}.prepare.stderr').open('xb') as stderr:
                result = subprocess.run(prepare, cwd=ROOT / 'uv', env=environment, stdout=stdout, stderr=stderr)
            if result.returncode:
                raise RuntimeError(f'{workload} native seed failed: {result.returncode}')
            print(f'{now()} native baseline {workload} seed complete; checking dirty execution', flush=True)
            trace = output / 'logs' / f'{workload}.execve'
            with (output / 'logs' / f'{workload}.stdout').open('xb') as stdout, (output / 'logs' / f'{workload}.stderr').open('xb') as stderr:
                result = subprocess.run(['/usr/bin/strace', '-f', '-qq', '-s', '65536', '-e', 'trace=execve,execveat', '-o', str(trace), *command], cwd=ROOT / 'uv', env=environment, stdout=stdout, stderr=stderr)
            if result.returncode:
                raise RuntimeError(f'{workload} native execution diagnostic failed: {result.returncode}')
            report = dirty_audit.parse_run((output / 'logs' / f'{workload}.stdout').read_text(), (output / 'logs' / f'{workload}.stderr').read_text())
            if len(report['compiled_packages']) != 1 or not report['compiled_packages'][0].endswith('/crates/uv#0.13.4'):
                raise ValueError('baseline dirty package identity is unexpected')
            rustc = config['env']['RUSTC']
            dirty_audit.validate_run(report, rustc, report['compiled_packages'][0])
            executed = dirty_audit.validate_no_tests(report, trace.read_text())
            if executed.count(rustc) != len(report['compiler_commands']):
                raise ValueError('execve rustc count differs from verbose compiler commands')
            manifest['runs'].append({'workload': workload, 'compiler_report': report, 'successful_execve_paths': executed, 'test_executables_run': []})
            with (output / 'logs' / f'{workload}.restore.stdout').open('xb') as stdout, (output / 'logs' / f'{workload}.restore.stderr').open('xb') as stderr:
                result = subprocess.run(cleanup, cwd=ROOT / 'uv', env=environment, stdout=stdout, stderr=stderr)
            if result.returncode:
                raise RuntimeError('baseline source restoration failed')
            state = None
            cleanup = None
            write(output / 'manifest.json', manifest)
            print(f'{now()} baseline {workload} verified: {len(report["compiler_commands"])} uv rustc invocations, no test execution; source restored', flush=True)
        dirty_guard.check(guard_path, restored=True)
        for path, expected in assets.items():
            assert paired.sha256(path) == expected, path
        manifest.update({'state': 'complete', 'finished_at': now(), 'source_restored': True})
    except BaseException as error:
        manifest.update({'state': 'failed', 'finished_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        if state is not None and cleanup is not None:
            result = subprocess.run(cleanup, cwd=ROOT / 'uv', capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
            (output / 'logs/failure-restore.stdout').write_text(result.stdout)
            (output / 'logs/failure-restore.stderr').write_text(result.stderr)
            manifest['failure_restore_returncode'] = result.returncode
        raise
    finally:
        write(output / 'manifest.json', manifest)
        lock.close()


if __name__ == '__main__':
    main()
