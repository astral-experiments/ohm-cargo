import json
import unittest

import dirty_audit


class DirtyAuditTests(unittest.TestCase):
    def fixture(self, package='path+file:///fixture/uv/crates/uv#0.13.4'):
        artifact = {'reason': 'compiler-artifact', 'package_id': package, 'fresh': False, 'profile': {'test': True}, 'target': {'name': 'uv', 'kind': ['lib']}, 'executable': '/fixture/target/uv-tests'}
        stdout = json.dumps(artifact) + '\n' + json.dumps({'reason': 'build-finished', 'success': True}) + '\n'
        stderr = '   Compiling uv v0.13.4 (/fixture/uv/crates/uv)\n     Running `/fixture/rustc --crate-name uv crates/uv/src/lib.rs --test --emit=dep-info,link`\n'
        return dirty_audit.parse_run(stdout, stderr), package

    def test_expected_compiler_work_and_no_test_execution(self):
        report, package = self.fixture()
        dirty_audit.validate_run(report, '/fixture/rustc', package, report)
        paths = dirty_audit.validate_no_tests(report, '123 execve("/fixture/rustc", ["rustc"], 0x0 /* 0 vars */) = 0\n')
        self.assertEqual(paths, ['/fixture/rustc'])

    def test_actual_test_execution_is_rejected(self):
        report, _ = self.fixture()
        with self.assertRaisesRegex(ValueError, 'actually ran'):
            dirty_audit.validate_no_tests(report, '123 execve("/fixture/target/uv-tests", ["test"], 0x0 /* 0 vars */) = 0\n')

    def test_unexpected_package_or_command_is_rejected(self):
        report, package = self.fixture()
        report['compiled_packages'].append('registry+index#unexpected@1.0.0')
        with self.assertRaisesRegex(ValueError, 'package other'):
            dirty_audit.validate_run(report, '/fixture/rustc', package)
        report, package = self.fixture()
        report['other_commands'].append(['/fixture/target/uv-tests'])
        with self.assertRaisesRegex(ValueError, 'test execution'):
            dirty_audit.validate_run(report, '/fixture/rustc', package)

    def test_changed_work_is_rejected(self):
        report, package = self.fixture()
        expected = {**report, 'compiled_artifacts': 99}
        with self.assertRaisesRegex(ValueError, 'changed from frozen'):
            dirty_audit.validate_run(report, '/fixture/rustc', package, expected)

    def test_interleaved_execve_records_are_reassembled(self):
        trace = '123 execve("/fixture/rustc", ["rustc"], 0x0 /* 0 vars */ <unfinished ...>\n456 execve("/usr/bin/cc", ["cc"], 0x0 /* 0 vars */) = 0\n123 <... execve resumed>) = 0\n'
        self.assertEqual(dirty_audit.trace_executables(trace), ['/usr/bin/cc', '/fixture/rustc'])


if __name__ == '__main__':
    unittest.main()
