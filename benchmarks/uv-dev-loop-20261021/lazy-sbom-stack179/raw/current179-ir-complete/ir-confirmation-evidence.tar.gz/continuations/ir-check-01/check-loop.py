for workload in ('check',):
    phase = next((row for row in protocol['phases'] if row['workload'] == workload and row['phase'] == phase_name and ((row['metric'] == 'cargo_ir') == instruction)))
    name = f'{workload}-{args.group}'
    config = ROOT / 'configs' / f'{name}.json'
    result = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check')
    assert paired.sha256(config) == final['config_sha256'][name]
    assert [list(order) for order in paired.make_plan(phase['pairs'], phase['seed'])] == phase['measurement_plan']
    assert [list(order) for order in paired.make_plan(phase['warmup_pairs'], phase['seed'] ^ 23063)] == phase['warmup_plan']
    occupancy = subprocess.check_output(['ps', '-eo', 'pid,comm,pcpu,pmem', '--sort=-pcpu'], text=True)
    (Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check-occupancy.txt')).write_text(occupancy)
    if any((row.split()[1] in {'cargo', 'rustc', 'cc1', 'cc1plus', 'clang', 'clang++', 'ld.lld', 'callgrind-amd64'} for row in occupancy.splitlines()[1:])):
        raise ValueError('another compiler/build/profiler process is active before the batch')
    print(f'{now()} starting {name}: {phase['pairs']} pairs, {phase['warmup_pairs']} warmup pairs', flush=True)
    command = ['/usr/bin/python3', str(ROOT / 'work/benchmark/paired.py'), 'run', '--config', str(config), '--output', str(result), '--phase', phase_name, '--pairs', str(phase['pairs']), '--warmup-pairs', str(phase['warmup_pairs']), '--seed', str(phase['seed'])]
    with (Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check.run.stdout')).open('xb') as out, (Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check.run.stderr')).open('xb') as err:
        process = subprocess.run(command, env=environment, stdout=out, stderr=err)
    if process.returncode:
        raise RuntimeError(f'{name} failed; all output and cleanup evidence retained')
    audit = dirty_audit.verify_batch(guard, ROOT / 'fixtures' / name, result, ROOT / 'metadata/diagnostic-expectations.json', workload)
    manifest = json.loads((result / 'manifest.json').read_text())
    assert manifest['plans'] == {'measurement': phase['measurement_plan'], 'warmup': phase['warmup_plan']}
    assert manifest['sample_count'] == 2 * (phase['pairs'] + phase['warmup_pairs'])
    assert len(audit['samples']) == manifest['sample_count']
    summary['completed_workloads'].append(workload)
    write(summary_path, summary)
    selected.append((workload, phase, result))
    print(f'{now()} {name} complete and source/compiler work verified; effects still uninspected', flush=True)
