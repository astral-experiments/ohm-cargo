"""Fixed continuation identities and read-only preservation/input checks."""
from __future__ import annotations
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
CAPSULE = ROOT / 'continuations/ir-check-01'
OUTPUT = ROOT / 'results/ir-completion-01'
CHECK = OUTPUT / 'check'
OLD_TEST = ROOT / 'results/test-ir-confirmation'
OLD_STATUS = ROOT / 'results/ir-confirmation.json'
FINAL = 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
COHORT = 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
PROTOCOL = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
DRIVER = '562b39da92d29ba83f38eacc9e43a589f0a38fe0a29737b61d180b286dcdfc2a'
CORE = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'
FAILED_STATUS = '3b71370c8e07057ae8a345470d0e583e4ac13e5cb72662968a08faf1169e0ac1'
FAILED_CAPTURE = 'd20d773a4f8c5016fbe6f20efc67cec9089832e53b886a767e5de2a1f0b6a109'
BOUNDARY = '95a47aaba8128ea88e419983ac3bc24f698f62841294ca75f8a06aaffe2b50e7'
SYNTHETIC = {'collection-identity.json', 'failure-boundary.json'}
CHECK_MUTABLE = {'fixtures/check-ir-confirmation/state.json', 'fixtures/check-ir-confirmation/journal.jsonl'}
NATIVE_MUTABLE = {f'fixtures/{workload}-native-confirmation/{name}' for workload in ('test', 'check')
                  for name in ('state.json', 'journal.jsonl')}


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def now():
    return datetime.now(timezone.utc).isoformat()


def relative(value):
    path = PurePosixPath(value)
    require(value and value != '.' and not path.is_absolute() and '..' not in path.parts
            and '\\' not in value and str(path) == value, 'unsafe relative name')
    return path


def regular(root, path):
    path = Path(path)
    require(path.is_relative_to(root) and path.resolve() == path and path.is_file()
            and not path.is_symlink(), 'noncanonical regular file: ' + str(path))
    return path


def record(path):
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode)}


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_capsule(capsule, expected):
    require(capsule.resolve() == capsule and capsule.is_dir(), 'noncanonical continuation capsule')
    require(sha(capsule / 'capsule-manifest.json') == expected, 'continuation capsule identity differs')
    manifest = read(capsule / 'capsule-manifest.json')
    require(manifest['operation'] == 'complete-original-fixed-check-ir-only'
            and manifest['failed_capture_sha256'] == FAILED_CAPTURE
            and manifest['original_finalized_sha256'] == FINAL, 'continuation capsule scope differs')
    require({str(path.relative_to(capsule)) for path in capsule.rglob('*') if path.is_file()}
            == set(manifest['files']) | {'capsule-manifest.json'}, 'continuation capsule member set differs')
    for name, expected_record in manifest['files'].items():
        require(record(regular(capsule, capsule / relative(name))) == expected_record,
                'continuation source/input changed: ' + name)
    require(sha(capsule / 'original/run_group.py') == DRIVER
            and sha(capsule / 'original/paired.py') == CORE
            and sha(capsule / 'boundary.py') == BOUNDARY
            and sha(capsule / 'failed/transfer-manifest.json') == FAILED_CAPTURE,
            'original source or failure identity differs')
    return manifest


def preserved(root, capsule, *, after_check=False, native=False):
    captured = read(capsule / 'failed/transfer-manifest.json')['files']
    require(len(captured) == 768, 'failed capture member count differs')
    mutable = (CHECK_MUTABLE if after_check or native else set()) | (NATIVE_MUTABLE if native else set())
    observed = {}
    for name, expected in captured.items():
        if name in SYNTHETIC:
            continue
        actual = record(regular(root, root / relative(name)))
        observed[name] = actual
        if name not in mutable:
            require(actual == expected, 'preserved pre-continuation byte/mode changed: ' + name)
    if after_check or native:
        old_journal = (capsule / 'failed/check-journal.jsonl').read_bytes()
        new_journal = (root / 'fixtures/check-ir-confirmation/journal.jsonl').read_bytes()
        require(new_journal.startswith(old_journal), 'accepted check diagnostic journal prefix changed')
    require(sha(root / 'results/ir-confirmation.json') == FAILED_STATUS,
            'original failed group status was replaced')
    return observed


def inputs(root):
    require(sha(root / 'configs-finalized.json') == FINAL
            and sha(root / 'metadata/frozen-cohort.json') == COHORT
            and sha(root / 'work/benchmark/protocol.json') == PROTOCOL, 'original input identity differs')
    final = read(root / 'configs-finalized.json')
    for path, digest in final['asset_sha256'].items():
        require(sha(path) == digest, 'frozen workload input changed: ' + path)
    require(sha(root / 'work/benchmark/run_group.py') == DRIVER
            and sha(root / 'work/benchmark/paired.py') == CORE, 'original controls changed')
    return final


def modules(root):
    inputs(root)
    sys.path.insert(0, str(root / 'work/benchmark'))
    original = load('original_sbom_group', root / 'work/benchmark/run_group.py')
    return original


def replay_test(root, capsule):
    """Execute only the frozen boundary's existing pure test-audit statements."""
    boundary = load('frozen_sbom_failure_boundary', capsule / 'boundary.py')
    source = ast.parse((capsule / 'boundary.py').read_text())
    function = next(node for node in source.body if isinstance(node, ast.FunctionDef) and node.name == 'verify_boundary')
    begin = next(index for index, node in enumerate(function.body) if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == 'final' for target in node.targets))
    body = function.body[begin:-1]
    require(isinstance(function.body[-1], ast.Return), 'test-audit source boundary changed')
    digest = hashlib.sha256(ast.dump(ast.Module(body=body, type_ignores=[]), include_attributes=False).encode()).hexdigest()
    expected = read(capsule / 'adaptation-identities.json')['pure_test_audit_ast_sha256']
    require(digest == expected, 'pure test-audit statement identity differs')
    before = boundary.inventory(root, root / 'results/test-ir-confirmation')
    status = boundary.read(root / 'results/ir-confirmation.json')
    namespace = dict(boundary.__dict__, root=root, result=root / 'results/test-ir-confirmation',
                     status=status, status_path=root / 'results/ir-confirmation.json', before=before)
    exec(compile(ast.Module(body=body, type_ignores=[]), '<frozen-pure-test-audit>', 'exec'), namespace)
    return {'valid': True, 'completed_at': now(), 'samples': 28, 'compiler_invocations_per_sample': 6,
            'pure_audit_ast_sha256': digest, 'raw_files': before,
            'compiler_audit_sha256': sha(root / 'results/test-ir-confirmation/compiler-audit.json'),
            'fixture_audit_sha256': sha(root / 'results/test-ir-confirmation/fixture-validation.json')}


def inventory(root, directory, *, exclude=()):
    result = {}
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'result directory contains symlink')
        if path.is_dir():
            continue
        regular(root, path)
        name = str(path.relative_to(directory))
        if name not in exclude:
            result[name] = sha(path)
    return result


def verify_complete(root, capsule, expected, *, native=False):
    verify_capsule(capsule, expected)
    inputs(root)
    preserved(root, capsule, after_check=True, native=native)
    result_members = {'ir-confirmation.json', 'test-ir-confirmation', 'ir-completion-01'}
    if native:
        result_members |= {'native-confirmation.json', 'test-native-confirmation', 'check-native-confirmation'}
    require({path.name for path in (root / 'results').iterdir()} == result_members,
            'unexpected additional workload results exist')
    status = read(root / 'results/ir-completion-01/status.json')
    require(status['state'] == 'complete' and status['group'] == 'ir-confirmation'
            and status['kind'] == 'continuation-of-unstarted-fixed-check'
            and status['completed_workloads'] == ['test', 'check'] and status['source_restored'] is True
            and status['capsule_manifest_sha256'] == expected
            and status['failed_status_sha256'] == FAILED_STATUS
            and status['failed_capture_sha256'] == FAILED_CAPTURE
            and status['config_manifest_sha256'] == FINAL and status['protocol_sha256'] == PROTOCOL,
            'continuation status identity/completeness differs')
    require(status['raw_integrity_sha256'] == sha(OUTPUT / 'raw-integrity.json'), 'raw boundary receipt changed')
    raw = read(OUTPUT / 'raw-integrity.json')
    require(raw['both_workflows_complete_before_effects'] is True
            and raw['test']['samples'] == raw['check']['samples'] == 28
            and raw['test']['valid'] is raw['check']['valid'] is True, 'both raw audits did not finish')
    require(read(OUTPUT / 'seal.json') == inventory(root, OUTPUT, exclude=('seal.json',)),
            'complete continuation result seal differs')
    return status
