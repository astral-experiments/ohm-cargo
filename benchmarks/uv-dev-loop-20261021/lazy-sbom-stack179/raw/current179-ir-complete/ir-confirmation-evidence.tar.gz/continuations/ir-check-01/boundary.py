"""Read-only proof of the exact completed-test / unstarted-check boundary."""
import ast
from collections import Counter
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shlex
import stat
from types import SimpleNamespace

FAILED_STATUS = '3b71370c8e07057ae8a345470d0e583e4ac13e5cb72662968a08faf1169e0ac1'
FINAL = 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
PROTOCOL = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
PARSER = 'afd0daaaffc4baaa97a2bc3d046805464974c542abb1e48476a764e61ae8a943'
FIXTURE = 'a89570fa6080462a772ebdbc73ab4471e0b968f7c357c23b197409fb12f282ad'
CONTROLLER = '562b39da92d29ba83f38eacc9e43a589f0a38fe0a29737b61d180b286dcdfc2a'
ORIGINAL = 'ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81'
CSV_FIELDS = ['stage', 'pair', 'order', 'position', 'variant', 'started_at', 'returncode',
              'wall_ns', 'user_seconds', 'system_seconds', 'minor_faults', 'major_faults',
              'voluntary_context_switches', 'involuntary_context_switches', 'stdout', 'stderr',
              'metric_cargo_ir']


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def regular(root, path):
    path = Path(path)
    require(path.is_relative_to(root) and path.resolve() == path
            and path.is_file() and not path.is_symlink(), 'noncanonical evidence path')
    return path


def inventory(root, directory):
    result = {}
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'evidence tree has a symlink')
        if path.is_dir():
            continue
        regular(root, path)
        result[str(path.relative_to(root))] = {
            'sha256': sha(path), 'bytes': path.stat().st_size,
            'mode': stat.S_IMODE(path.stat().st_mode),
        }
    return result


def validate_status(value, digest):
    require(digest == FAILED_STATUS, 'failed status bytes differ')
    require(set(value) == {'state', 'started_at', 'group', 'protocol_sha256',
                          'config_manifest_sha256', 'completed_workloads',
                          'finished_at', 'error', 'traceback'}, 'failed status schema differs')
    require(value['state'] == 'failed' and value['group'] == 'ir-confirmation'
            and value['completed_workloads'] == ['test']
            and value['protocol_sha256'] == PROTOCOL
            and value['config_manifest_sha256'] == FINAL,
            'failure is not the completed-test boundary')
    require(value['error'] == "ValueError('another compiler/build/profiler process is active before the batch')"
            and 'run_group.py\", line 83, in main' in value['traceback'],
            'failure was not the original before-check occupancy guard')
    require(datetime.fromisoformat(value['started_at']) < datetime.fromisoformat(value['finished_at']),
            'failed phase chronology differs')


def pure_parser(root):
    namespace = {'Counter': Counter, 'json': json, 'Path': Path, 're': re, 'shlex': shlex}
    for name, digest, names in (
        ('dirty_fixture.py', FIXTURE, {'compile_packages'}),
        ('dirty_audit_v2.py', PARSER, {'option', 'parse_run', 'validate_run'}),
    ):
        path = regular(root, root / 'work/benchmark' / name)
        require(sha(path) == digest, 'pinned pure parser changed')
        nodes = [node for node in ast.parse(path.read_text()).body
                 if isinstance(node, ast.FunctionDef) and node.name in names]
        require({node.name for node in nodes} == names and len(nodes) == len(names),
                'pure function set differs')
        # Only these exact hash-bound pure definitions are evaluated. Import,
        # prepare, restore, verify_batch and every writing helper are excluded.
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)
        if name == 'dirty_fixture.py':
            namespace['dirty_fixture'] = SimpleNamespace(compile_packages=namespace['compile_packages'])
    return SimpleNamespace(parse_run=namespace['parse_run'], validate_run=namespace['validate_run'])


def validate_tables(directory, samples, plans):
    require(len(samples) == 28, 'completed test observation count differs')
    expected = [(stage, pair, 'AB' if order[0] == 'baseline' else 'BA', position, variant)
                for stage in ('warmup', 'measurement') for pair, order in enumerate(plans[stage])
                for position, variant in enumerate(order)]
    require([(row['stage'], row['pair'], row['order'], row['position'], row['variant'])
             for row in samples] == expected, 'completed test sample plan differs')
    lines = (directory / 'samples.jsonl').read_text()
    require(lines.endswith('\n') and [json.loads(line) for line in lines.splitlines()] == samples,
            'JSON and JSONL observations differ')
    with (directory / 'samples.csv').open(newline='') as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    require(fields == CSV_FIELDS and len(rows) == len(samples),
            'CSV schema/count differs')
    require(all(row == {name: str(sample[name]) for name in fields}
                for row, sample in zip(rows, samples)), 'CSV observation values differ')
    require(all(row['returncode'] == row['prepare']['returncode'] == 0
                and row['executable_unchanged'] is True for row in samples),
            'completed test sample or preparation failed')


def verify_propagated_traceback(stderr, inner, source, filename):
    header = 'Traceback (most recent call last):\n'
    require(inner.startswith(header), 'in-handler traceback header differs')
    tree = ast.parse(source)
    calls = [statement for node in tree.body if isinstance(node, ast.If)
             and ast.unparse(node.test) == "__name__ == '__main__'"
             for statement in node.body if isinstance(statement, ast.Expr)
             and isinstance(statement.value, ast.Call)
             and isinstance(statement.value.func, ast.Name)
             and statement.value.func.id == 'main'
             and statement.value.args == [] and statement.value.keywords == []]
    require(len(calls) == 1, 'outer controller main call is ambiguous')
    line = calls[0].lineno
    require(source.splitlines()[line - 1].strip() == 'main()', 'outer controller call text differs')
    outer = f'  File "{filename}", line {line}, in <module>\n    main()\n'
    require(stderr == header + outer + inner[len(header):],
            'propagated traceback differs from exact outer frame and retained inner suffix')


def verify_boundary(root, historical_check):
    root = Path(root)
    status_path = regular(root, root / 'results/ir-confirmation.json')
    status_bytes = status_path.read_bytes()
    status = json.loads(status_bytes)
    validate_status(status, hashlib.sha256(status_bytes).hexdigest())
    require({path.name for path in (root / 'results').iterdir()}
            == {'ir-confirmation.json', 'test-ir-confirmation'}, 'unexpected result or check work exists')
    absent = [root / 'results/check-ir-confirmation', root / 'results/native-confirmation.json']
    absent += [root / 'logs' / ('check-ir-confirmation.run.' + suffix) for suffix in ('stdout', 'stderr')]
    absent += [root / 'logs' / (workload + '-ir-confirmation.analysis.' + suffix)
               for workload in ('test', 'check') for suffix in ('stdout', 'stderr')]
    require(all(not path.exists() and not path.is_symlink() for path in absent),
            'check execution or analysis boundary was crossed')
    result = root / 'results/test-ir-confirmation'
    before = inventory(root, result)
    require(not any(Path(name).name in ('analysis.json', 'seal.json', 'gate.json') for name in before),
            'analysis or terminal result sealing already occurred')
    require(inventory(root, root / 'fixtures/check-ir-confirmation') == historical_check,
            'check fixture changed after accepted diagnostics')
    check_occupancy = regular(root, root / 'metadata/check-ir-confirmation-occupancy.txt')
    occupancy_lines = check_occupancy.read_text().splitlines()
    names = {'cargo', 'rustc', 'cc1', 'cc1plus', 'clang', 'clang++', 'ld.lld', 'callgrind-amd64'}
    triggering_rows = [line for line in occupancy_lines[1:] if len(line.split()) >= 2 and line.split()[1] in names]
    require(triggering_rows, 'retained occupancy does not reproduce the original guard')
    controller = regular(root, root / 'logs/ir-confirmation.controller.stdout').read_text()
    require('starting test-ir-confirmation: 12 pairs, 2 warmup pairs' in controller
            and 'test-ir-confirmation complete and source/compiler work verified; effects still uninspected' in controller
            and 'starting check-ir-confirmation:' not in controller, 'controller work boundary differs')
    stderr = regular(root, root / 'logs/ir-confirmation.controller.stderr').read_text()
    controller_source = regular(root, root / 'work/benchmark/run_group.py')
    require(sha(controller_source) == CONTROLLER, 'frozen controller source changed')
    verify_propagated_traceback(stderr, status['traceback'], controller_source.read_text(), str(controller_source))
    final = read(root / 'configs-finalized.json')
    require(sha(root / 'configs-finalized.json') == FINAL, 'final config identity differs')
    protocol = read(root / 'work/benchmark/protocol.json')
    require(sha(root / 'work/benchmark/protocol.json') == PROTOCOL, 'protocol identity differs')
    phase = next(row for row in protocol['phases'] if row['workload'] == 'test'
                 and row['phase'] == 'confirmation' and row['metric'] == 'cargo_ir')
    require(phase['pairs'] == 12 and phase['warmup_pairs'] == 2 and phase['seed'] == 20261021101,
            'test protocol changed')
    plans = {'warmup': phase['warmup_plan'], 'measurement': phase['measurement_plan']}
    manifest = read(result / 'manifest.json')
    configuration = read(root / 'configs/test-ir-confirmation.json')
    require(manifest['state'] == 'complete' and manifest['plans'] == plans and manifest['sample_count'] == 28
            and manifest['pairs'] == 12 and manifest['warmup_pairs'] == 2 and manifest['seed'] == 20261021101
            and manifest['phase'] == 'confirmation' and manifest['cleanup']['returncode'] == 0,
            'test batch did not finish its complete fixed plan')
    require(manifest['configuration'] == configuration
            and manifest['configuration_sha256'] == final['config_sha256']['test-ir-confirmation']
            == sha(root / 'configs/test-ir-confirmation.json'), 'test configuration differs')
    require(manifest['variant_sha256'] == manifest['variant_sha256_after']
            and manifest['recorded_file_sha256'] == manifest['recorded_file_sha256_after'],
            'test inputs changed during observations')
    require(datetime.fromisoformat(status['started_at']) <= datetime.fromisoformat(manifest['started_at'])
            < datetime.fromisoformat(manifest['finished_at']) <= datetime.fromisoformat(status['finished_at']),
            'test completion lies outside retained phase')
    samples = read(result / 'samples.json')
    validate_tables(result, samples, plans)
    expectation = read(root / 'metadata/diagnostic-expectations.json')
    parser = pure_parser(root)
    rows = []
    for sample in samples:
        stdout, stderr = [regular(root, Path(sample[key])) for key in ('stdout', 'stderr')]
        report = parser.parse_run(stdout.read_text(), stderr.read_text(), sample['configured_environment']['CARGO_TARGET_DIR'])
        parser.validate_run(report, expectation['rustc'], expectation['uv_package'],
                            expectation['workloads']['test']['targets'][report['target_dir']])
        require(report['compiler_stage_counts'] == {'source': 2, 'rlink': 4}
                and '--no-run' in sample['command'], 'test compiler/build-only work changed')
        metric = sample['metric_files']['cargo_ir']
        require(sha(regular(root, Path(metric['path']))) == metric['sha256'], 'raw profiler bytes changed')
        rows.append({'stage': sample['stage'], 'pair': sample['pair'], 'variant': sample['variant'],
                     'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr), **report})
    audit = read(result / 'compiler-audit.json')
    require(audit['valid'] and audit['source_restored'] and audit['fixture_validation_valid']
            and audit['samples'] == rows and audit['expectations_sha256'] == sha(root / 'metadata/diagnostic-expectations.json'),
            'stored test compiler audit differs from pure replay')
    fixture = read(result / 'fixture-validation.json')
    require(fixture['valid'] and fixture['source_restored'] and fixture['errors'] == []
            and fixture['expected_compiled_packages'] == ['uv'] and len(fixture['samples']) == 28,
            'stored fixture audit was incomplete')
    require(sha(root / 'uv/crates/uv/src/lib.rs') == ORIGINAL
            and read(root / 'fixtures/test-ir-confirmation/state.json')['restored'] is True,
            'test cleanup did not restore original source')
    require(inventory(root, result) == before and sha(status_path) == FAILED_STATUS,
            'raw observations or failed status changed during validation')
    return {'state': 'preserved', 'qualifies': False, 'phase': 'ir-confirmation',
            'failed_status_sha256': FAILED_STATUS, 'completed_workloads': ['test'],
            'test_samples': 28, 'test_measurement_pairs': 12, 'test_warmup_pairs': 2,
            'test_compiler_invocations_per_sample': 6, 'check_samples': 0,
            'check_fixture_unchanged_from_diagnostics': True,
            'absent_paths': [str(path.relative_to(root)) for path in absent],
            'original_guard_triggering_rows': triggering_rows,
            'result_files': before, 'check_fixture_files': historical_check,
            'effects_inspected': False, 'source_restored': True,
            'scope': 'Read-only retention and pure compiler replay. No analysis, new work, retry or eligibility decision.'}
