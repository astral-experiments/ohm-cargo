# Completion of the unstarted current179 SBOM check batch

The original fixed group stopped at its existing occupancy guard after all 28
test observations were complete and audited, before any check preparation or
observation. The retained failed capture contains 768 payloads; its manifest is
`d20d773a4f8c5016fbe6f20efc67cec9089832e53b886a767e5de2a1f0b6a109`.
The root's preservation review is
`e12f288103a2a6d533b2f365ca61358d3f4929be7de5bc34e5bca79b835246d9`.
No comparative effects were inspected before this amendment.

Complete only the original check IR plan: 12 measurement pairs, two warmup
pairs, seed 20261021102, one dirty invocation per variant and pair. The
baseline/candidate binaries, original protocol, six configs, final asset seal,
target assignment, canonical Cargo/target/shared paths, native preparation,
three-call check convergence proof, strict one-unit check requirement,
profiler scope, affinity, statistics and acceptance gates are unchanged.
There are no additional test observations, exclusions, substitutions, or
extensions to the fixed plans.

All existing test files, the original failed status, its occupancy rows and
controller logs remain byte- and mode-identical. The original check fixture
is reused; its accepted diagnostic journal is an immutable prefix. New check
results go to `results/ir-completion-01/check`; this changes the batch identifier
used by the unchanged deterministic comment generator. The comment remains
equal-length and identical within each pair, unique across pairs, and exactly
restored. Both raw compiler/fixture audits and actual Ir summary joins must
finish before any effect analysis. An inherited-environment and host/affinity
identity comparison against the completed test manifest must pass before new
work, and again afterward.

The fixed check loop is extracted from the original controller. Its only
changes are selecting `check` and redirecting its result, occupancy and run
log paths. The original analysis/gate tail changes only its stdout/stderr
destinations. It receives byte-identical copies of each raw manifest, samples
and compiler audit in new analysis directories, so it never writes inside the
old test directory. All original source/input guards remain. An operational
failure creates a new failed continuation status and stops; it cannot silently
restart or overwrite this attempt.

The collector retains the complete failure lineage, new capsule and results,
original diagnostics and all unchanged asset/runtime checks. The independent
reviewer changes only evidence paths, seal/lineage joins and the native IR
prerequisite. Its compiler parser, raw per-sample checks and statistical
functions remain unchanged. It audits both workflows before recomputing the
original 99% / 20,000-resample / seed-1701 statistics and gates.

Native execution remains a separate decision after independent IR review.
The native controller has one source change: its prior-IR status lookup points
to the completed continuation. A separate root-approved, hash-bound prerequisite
must bind the accepted independent IR review and every accepted IR payload.
Native plans remain 30 single-call pairs plus two warmup pairs, with original
seeds 20261021103 and 20261021104. No native execution is authorized by preparing
or staging this capsule.

Stage and launch scripts require a root approval bound to the complete source
freeze and capsule manifest. Staging writes only a new, absent owned capsule;
it cannot modify the existing fixture or source. A distinct launch receipt and
session are retained. No host action is performed while preparing this package.
