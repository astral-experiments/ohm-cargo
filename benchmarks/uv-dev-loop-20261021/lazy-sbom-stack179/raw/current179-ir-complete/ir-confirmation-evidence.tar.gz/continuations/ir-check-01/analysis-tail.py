summary['results'] = {}
for workload, phase, result in selected:
    command = ['/usr/bin/python3', str(ROOT / 'work/benchmark/paired.py'), 'analyze', str(result), '--confidence', str(protocol['acceptance']['confidence']), '--resamples', str(protocol['acceptance']['bootstrap_resamples']), '--seed', str(protocol['acceptance']['bootstrap_seed']), '--minimum-pairs', str(phase['pairs']), '--minimum-improvement', str(protocol['acceptance']['minimum_geometric_reduction'])]
    with (Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/analysis-logs') / f'{workload}-{args.group}.analysis.stdout').open('xb') as out, (Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/analysis-logs') / f'{workload}-{args.group}.analysis.stderr').open('xb') as err:
        subprocess.run(command, env=environment, stdout=out, stderr=err, check=True)
    analysis = json.loads((result / 'analysis.json').read_text())
    statistics = analysis['metrics']['cargo_ir']['statistics'] if instruction else analysis
    summary['results'][workload] = {'passes': gate(statistics, instruction, protocol['acceptance'], phase['pairs']), 'primary': phase['primary'], 'statistics': statistics, 'analysis_sha256': paired.sha256(result / 'analysis.json'), 'compiler_audit_sha256': paired.sha256(result / 'compiler-audit.json')}
    sealed = {str(path.relative_to(result)): paired.sha256(path) for path in sorted(result.rglob('*')) if path.is_file()}
    write(result / 'seal.json', sealed)
dirty_guard.check(guard, restored=True)
input_catalog.check(ROOT / 'metadata/input-catalog.json')
for path, expected in final['asset_sha256'].items():
    if paired.sha256(path) != expected:
        raise ValueError(f'frozen input changed during the group: {path}')
summary.update({'state': 'complete', 'finished_at': now(), 'primary_passes': summary['results']['test']['passes'], 'secondary_passes': summary['results']['check']['passes'], 'source_restored': True})
