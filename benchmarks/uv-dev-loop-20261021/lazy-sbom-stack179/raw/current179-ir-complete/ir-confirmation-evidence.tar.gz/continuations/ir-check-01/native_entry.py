#!/usr/bin/env python3
"""Require separately accepted continued IR evidence, then use the original native controller."""
import argparse
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import contract


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capsule-manifest-sha256', required=True)
    parser.add_argument('--prerequisite-sha256', required=True)
    args = parser.parse_args()
    root, capsule = contract.ROOT, Path(__file__).resolve().parent
    contract.require(capsule == contract.CAPSULE, 'native controller capsule differs')
    status = contract.verify_complete(root, capsule, args.capsule_manifest_sha256)
    binding = root / 'continuations/native-prerequisite-01'
    manifest_path = contract.regular(root, binding / 'manifest.json')
    contract.require(contract.sha(manifest_path) == args.prerequisite_sha256, 'native prerequisite manifest differs')
    manifest = contract.read(manifest_path)
    contract.require(manifest['operation'] == 'root-approved-native-after-independent-ir-review'
                     and manifest['capsule_manifest_sha256'] == args.capsule_manifest_sha256
                     and manifest['continuation_status_sha256'] == contract.sha(contract.OUTPUT / 'status.json'),
                     'native prerequisite does not bind this continued IR result')
    for name, row in manifest['files'].items():
        contract.require(contract.record(contract.regular(binding, binding / contract.relative(name))) == row,
                         'native prerequisite payload differs: ' + name)
    review = contract.read(binding / 'review/review.json')
    approval = contract.read(binding / 'root-approval.json')
    seal = contract.read(binding / 'review/seal.json')
    contract.require(set(seal) == {'review.json', 'raw-integrity.json', 'effects.json'}, 'independent review seal differs')
    for name, digest in seal.items():
        contract.require(contract.sha(binding / 'review' / name) == digest, 'independent review file changed')
    contract.require(review['valid'] is True and review['phase'] == 'ir-confirmation'
                     and review['raw_integrity_before_effects'] is True and review['primary_passes'] is True
                     and status['primary_passes'] is True
                     and review['cohort_sha256'] == contract.COHORT
                     and review['finalized_sha256'] == contract.FINAL
                     and approval['valid'] is True
                     and approval['accepted_ir_review_sha256'] == contract.sha(binding / 'review/review.json')
                     and approval['reviewer_source_freeze_sha256'] == review['source_freeze_sha256']
                     and approval['continuation_status_sha256'] == manifest['continuation_status_sha256']
                     and approval['capsule_manifest_sha256'] == args.capsule_manifest_sha256,
                     'independent IR acceptance is absent or mismatched')
    transfer = contract.read(binding / 'transfer-manifest.json')
    receipt = contract.read(binding / 'collection-receipt.json')
    contract.require(contract.sha(binding / 'transfer-manifest.json') == review['transfer_manifest_sha256']
                     and contract.sha(binding / 'collection-receipt.json') == review['collection_receipt_sha256']
                     and receipt['transfer_manifest_sha256'] == review['transfer_manifest_sha256'],
                     'accepted IR collection identity differs')
    for name, row in transfer['files'].items():
        if name != 'collection-identity.json':
            contract.require(contract.record(contract.regular(root, root / contract.relative(name))) == row,
                             'accepted IR bytes changed before native run: ' + name)
    identities = contract.read(capsule / 'adaptation-identities.json')
    native = capsule / 'native-original-controller.py'
    contract.require(contract.sha(native) == identities['native_controller_sha256'], 'native path-only adaptation changed')
    sys.path.insert(0, str(root / 'work/benchmark'))
    module = contract.load('continued_sbom_native_controller', native)
    sys.argv = [str(native), 'native-confirmation']
    # Its only source delta is the previous-IR status lookup. The fixed native
    # loop, occupancy/source/input checks, sample plans, analysis and gates are
    # otherwise the original frozen controller, including its own lock.
    module.main()


if __name__ == '__main__':
    main()
