#!/usr/bin/env python3
"""Continue only the untouched fixed check batch; never rerun the completed test batch."""
import argparse
import ast
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
from types import SimpleNamespace
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
import contract


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capsule-manifest-sha256', required=True)
    args = parser.parse_args()
    root, capsule, output = contract.ROOT, Path(__file__).resolve().parent, contract.OUTPUT
    contract.require(capsule == contract.CAPSULE and socket.gethostname() == 'charlie-oss-4'
                     and os.getuid() == 1000 and root.resolve() == root
                     and root.stat().st_uid == 1000 and Path('/').stat().st_uid == 0,
                     'continuation host/path/ownership differs')
    contract.verify_capsule(capsule, args.capsule_manifest_sha256)
    lock = contract.regular(root, root / 'experiment.lock').open('rb')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    contract.require(not output.exists() and not output.is_symlink(), 'continuation already attempted')
    original = contract.modules(root)
    boundary = contract.load('frozen_sbom_failure_boundary', capsule / 'boundary.py')
    before = contract.preserved(root, capsule)
    boundary_report = boundary.verify_boundary(root, contract.read(capsule / 'failed/failure-boundary.json')['check_fixture_files'])
    original.dirty_guard.check(root / 'work/benchmark/source-guard.json', restored=True)
    original.input_catalog.check(root / 'metadata/input-catalog.json')
    protocol = contract.read(root / 'work/benchmark/protocol.json')
    final = contract.inputs(root)
    retained_manifest = contract.read(contract.OLD_TEST / 'manifest.json')
    contract.require(original.paired.build_environment_metadata() == retained_manifest['inherited_build_environment'],
                     'controller inherited build environment differs before new work')
    current_machine = original.paired.machine_metadata()
    for key in ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid'):
        contract.require(current_machine[key] == retained_manifest['machine'][key],
                         'controller machine identity differs before new work: ' + key)
    output.mkdir()
    (output / 'analysis-logs').mkdir()
    failed = contract.read(contract.OLD_STATUS)
    summary_path = output / 'status.json'
    summary = {'state': 'running', 'group': 'ir-confirmation',
               'kind': 'continuation-of-unstarted-fixed-check', 'started_at': failed['started_at'],
               'continuation_started_at': contract.now(), 'completed_workloads': ['test'],
               'protocol_sha256': contract.PROTOCOL, 'config_manifest_sha256': contract.FINAL,
               'failed_status_sha256': contract.FAILED_STATUS, 'failed_capture_sha256': contract.FAILED_CAPTURE,
               'capsule_manifest_sha256': args.capsule_manifest_sha256,
               'original_test_result': str(contract.OLD_TEST), 'continued_check_result': str(contract.CHECK)}
    original.write(summary_path, summary)
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSAFEPATH'):
        environment.pop(key, None)
    identities = contract.read(capsule / 'adaptation-identities.json')
    namespace = dict(original.__dict__, ROOT=root, args=SimpleNamespace(group='ir-confirmation'),
                     instruction=True, phase_name='confirmation', protocol=protocol, final=final,
                     guard=root / 'work/benchmark/source-guard.json', summary_path=summary_path,
                     summary=summary, environment=environment, selected=[])
    try:
        # This is the original per-workload loop, limited to check, with only its
        # result/occupancy/run-log paths changed. All guards and sample arguments
        # are byte/AST-bound to the original controller.
        source = (capsule / 'check-loop.py').read_text()
        contract.require(hashlib.sha256(source.encode()).hexdigest() == identities['check_loop_sha256'],
                         'fixed check loop source changed')
        exec(compile(source, str(capsule / 'check-loop.py'), 'exec'), namespace)
        selected_check = namespace['selected']
        contract.require(len(selected_check) == 1 and selected_check[0][0] == 'check'
                         and selected_check[0][2] == contract.CHECK, 'continuation ran an unexpected workload')
        test = contract.replay_test(root, capsule)
        check_manifest = contract.read(contract.CHECK / 'manifest.json')
        check_samples = contract.read(contract.CHECK / 'samples.json')
        phase = selected_check[0][1]
        boundary.validate_tables(contract.CHECK, check_samples,
                                 {'warmup': phase['warmup_plan'], 'measurement': phase['measurement_plan']})
        audit = contract.read(contract.CHECK / 'compiler-audit.json')
        contract.require(audit['valid'] and audit['source_restored'] and len(audit['samples']) == 28
                         and all(row['compiler_stage_counts'] == {'source': 1} and not row['other_commands']
                                 for row in audit['samples']), 'strict one-unit check audit differs')
        test_manifest = contract.read(contract.OLD_TEST / 'manifest.json')
        contract.require(check_manifest['inherited_build_environment'] == test_manifest['inherited_build_environment'],
                         'workflow inherited build environment changed')
        for key in ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid'):
            contract.require(check_manifest['machine'][key] == test_manifest['machine'][key],
                             'workflow machine identity changed: ' + key)
        for directory in (contract.OLD_TEST, contract.CHECK):
            for sample in contract.read(directory / 'samples.json'):
                metric = sample['metric_files']['cargo_ir']
                contract.require(contract.sha(metric['path']) == metric['sha256']
                                 and original.paired.read_callgrind_summary(metric['path'], 'Ir') == sample['metric_cargo_ir'],
                                 'raw profiler count/hash differs from recorded observation')
        contract.preserved(root, capsule, after_check=True)
        raw = {'both_workflows_complete_before_effects': True, 'completed_at': contract.now(),
               'test': test, 'check': {'valid': True, 'samples': 28,
                   'compiler_audit_sha256': contract.sha(contract.CHECK / 'compiler-audit.json'),
                   'fixture_audit_sha256': contract.sha(contract.CHECK / 'fixture-validation.json')},
               'original_failed_status_sha256': contract.FAILED_STATUS,
               'original_test_files_preserved': True}
        contract.write_new(output / 'raw-integrity.json', raw)
        contract.write_new(output / 'raw-seals.json', {
            'test': contract.inventory(root, contract.OLD_TEST),
            'check': contract.inventory(root, contract.CHECK),
        })
        summary['raw_integrity_sha256'] = contract.sha(output / 'raw-integrity.json')
        selected = []
        copies = {}
        for workload, directory in (('test', contract.OLD_TEST), ('check', contract.CHECK)):
            phase = next(row for row in protocol['phases'] if row['workload'] == workload
                         and row['phase'] == 'confirmation' and row['metric'] == 'cargo_ir')
            destination = output / (workload + '-analysis')
            destination.mkdir()
            copies[workload] = {}
            # Original paired.analyze reads only manifest.json and samples.json;
            # the controller also records compiler-audit.json's existing hash.
            for name in ('manifest.json', 'samples.json', 'compiler-audit.json'):
                shutil.copyfile(directory / name, destination / name)
                contract.require(contract.sha(destination / name) == contract.sha(directory / name),
                                 'analysis input copy differs')
                copies[workload][name] = contract.sha(destination / name)
            selected.append((workload, phase, destination))
        contract.write_new(output / 'analysis-input-copies.json', copies)
        namespace.update(selected=selected)
        tail = (capsule / 'analysis-tail.py').read_text()
        contract.require(hashlib.sha256(tail.encode()).hexdigest() == identities['analysis_tail_sha256'],
                         'original analysis/gate tail changed')
        exec(compile(tail, str(capsule / 'analysis-tail.py'), 'exec'), namespace)
        contract.preserved(root, capsule, after_check=True)
        contract.verify_capsule(capsule, args.capsule_manifest_sha256)
        contract.inputs(root)
        summary['completed_at'] = summary['finished_at']
    except BaseException as error:
        summary.update(state='failed', finished_at=contract.now(), error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        original.write(summary_path, summary)
        if summary['state'] == 'complete':
            contract.write_new(output / 'seal.json', contract.inventory(root, output, exclude=('seal.json',)))
        lock.close()
    print(json.dumps({'state': summary['state'], 'group': 'ir-confirmation',
                      'original_failed_status_preserved': True, 'new_check_samples': 28,
                      'original_test_samples_unchanged': 28, 'status_sha256': contract.sha(summary_path)}))


if __name__ == '__main__':
    main()
