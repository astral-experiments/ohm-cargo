"""Launch the unchanged continuation with its retained PATH; preserve attempt 01."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
CAPSULE = ROOT / 'continuations/ir-check-01'
HISTORY = ROOT / 'continuations/ir-check-01-environment-attempt02'
CAPSULE_SHA = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
FAILED_STDERR = 'c93a5eca0735e877580f9cc81dcbea2352617de34719f62588dae706c2149b33'
EMPTY = hashlib.sha256(b'').hexdigest()


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')


def controller_command(retained):
    need(set(retained) == {'PATH'} and isinstance(retained['PATH'], str) and retained['PATH'],
         'retained inherited environment is no longer the observed PATH-only context')
    return ['/usr/bin/env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
            'PYTHONDONTWRITEBYTECODE=1', 'PATH=' + retained['PATH'], '/usr/bin/python3', '-B',
            str(CAPSULE / 'complete_ir.py'), '--capsule-manifest-sha256', CAPSULE_SHA]


def main():
    raw_request = sys.stdin.buffer.read()
    need(hashlib.sha256(raw_request).hexdigest() == sys.argv[1], 'request transfer differs')
    request = json.loads(raw_request)
    need(request['operation'] == 'launch-unchanged-fixed-check-with-retained-path'
         and request['capsule_manifest_sha256'] == CAPSULE_SHA,
         'wrong operation/capsule')
    need(socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000
         and ROOT.resolve() == ROOT and ROOT.stat().st_uid == 1000 and Path('/').stat().st_uid == 0,
         'wrong host/root/identity')
    lock = (ROOT / 'experiment.lock').open('rb')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    need(sha(CAPSULE / 'contract.py') == '3b39ed7a47ca7433aef4f0861f1006cbf6724b5afefb6e46aaa78d063e3c5bca',
         'frozen contract source differs')
    sys.path.insert(0, str(CAPSULE))
    import contract
    contract.verify_capsule(CAPSULE, CAPSULE_SHA)
    contract.inputs(ROOT)
    originals = contract.preserved(ROOT, CAPSULE)
    need(len(originals) == 766, 'original file count differs')
    boundary = contract.read(CAPSULE / 'failed/failure-boundary.json')
    fixture = {name: contract.record(contract.regular(ROOT, ROOT / name))
               for name in boundary['check_fixture_files']}
    need(fixture == boundary['check_fixture_files'] and len(fixture) == 5, 'check fixture changed')
    need({str(path.relative_to(ROOT)) for path in (ROOT / 'fixtures/check-ir-confirmation').rglob('*') if path.is_file()}
         == set(fixture), 'check fixture member set differs')
    need({path.name for path in (ROOT / 'results').iterdir()} == {'ir-confirmation.json', 'test-ir-confirmation'},
         'unexpected result namespace')
    absent = list(boundary['absent_paths']) + ['results/ir-completion-01']
    need(all(not (ROOT / name).exists() and not (ROOT / name).is_symlink() for name in absent),
         'new workload or analysis output already exists')
    need(not HISTORY.exists() and not HISTORY.is_symlink(), 'attempt02 metadata already exists')
    failed_logs = {}
    for suffix, digest in (('stdout', EMPTY), ('stderr', FAILED_STDERR)):
        path = ROOT / ('logs/ir-completion-01.controller.' + suffix)
        need(sha(contract.regular(ROOT, path)) == digest, 'attempt01 controller log differs')
        failed_logs[suffix] = path.read_bytes()
        need(request['failed_controller_log_sha256'][suffix] == digest, 'request failed log binding differs')
    manifest_path = ROOT / 'results/test-ir-confirmation/manifest.json'
    need(sha(manifest_path) == request['retained_test_manifest_sha256'], 'retained test manifest differs')
    retained = contract.read(manifest_path)['inherited_build_environment']
    need(retained == request['retained_inherited_build_environment'], 'retained environment request differs')
    command = controller_command(retained)
    session = 'ohm-sbom179-ir-completion-02'
    for prior_session in ('ohm-sbom179-ir-completion-01', session):
        check = subprocess.run(['/usr/bin/tmux', 'has-session', '-t', prior_session], capture_output=True)
        need(check.returncode == 1, 'continuation session exists or tmux check failed')
    logs = {suffix: ROOT / ('logs/ir-completion-02.controller.' + suffix) for suffix in ('stdout', 'stderr')}
    need(all(not path.exists() and not path.is_symlink() for path in logs.values()), 'attempt02 logs already exist')
    # Only new task-owned lineage files are written. Original logs, capsule,
    # fixtures, measurements, and input files are left in place and unchanged.
    HISTORY.mkdir()
    with (HISTORY / 'request.json').open('xb') as stream:
        stream.write(raw_request)
    for name, text in request['source_text'].items():
        need(name in {'launch_remote.py', 'amendment.md'}
             and hashlib.sha256(text.encode()).hexdigest() == request['source_sha256'][name],
             'retained launch source differs')
        with (HISTORY / name).open('x') as stream:
            stream.write(text)
    need(set(request['source_text']) == {'launch_remote.py', 'amendment.md'}, 'incomplete retained launch sources')
    for suffix, data in failed_logs.items():
        with (HISTORY / ('failed-attempt01.controller.' + suffix)).open('xb') as stream:
            stream.write(data)
    write(HISTORY / 'before.json', {'verified_at': datetime.now(timezone.utc).isoformat(),
        'source_freeze_sha256': request['source_freeze_sha256'], 'capture_sha256': request['capture_sha256'],
        'root_approval_sha256': request['root_approval_sha256'], 'request_sha256': sys.argv[1],
        'capsule_manifest_sha256': CAPSULE_SHA, 'protected_originals': originals,
        'untouched_check_fixture': fixture, 'absent_paths': absent,
        'retained_inherited_build_environment': retained, 'environment_changes': {'PATH': retained['PATH']},
        'original_controller_and_sample_analysis_code_unchanged': True,
        'test_measurements_to_repeat': 0, 'fixed_check_pairs': 12, 'warmup_pairs': 2, 'seed': 20261021102})
    write(HISTORY / 'seal.json', {path.name: sha(path) for path in sorted(HISTORY.iterdir())})
    # Release this observation lock before launching the controller, which takes
    # the same original exclusive lock and repeats every input/environment guard.
    lock.close()
    shell = 'set -C; exec ' + shlex.join(command) + ' > ' + shlex.quote(str(logs['stdout'])) + ' 2> ' + shlex.quote(str(logs['stderr']))
    subprocess.run(['/usr/bin/tmux', 'new-session', '-d', '-s', session, '/bin/sh', '-c', shell], check=True)
    print(json.dumps({'launched': True, 'session': session, 'command': command,
        'request_sha256': sys.argv[1], 'history': str(HISTORY), 'history_seal_sha256': sha(HISTORY / 'seal.json'),
        'stdout': str(logs['stdout']), 'stderr': str(logs['stderr']),
        'original_failed_logs_preserved': True, 'original_capsule_unchanged': True,
        'fixed_check_pairs': 12, 'warmup_pairs': 2, 'seed': 20261021102, 'test_samples_to_rerun': 0}, sort_keys=True))


if __name__ == '__main__':
    main()
