The first fixed-check continuation stopped at complete_ir.py:44, before its output
directory was created and before any new check or test call. The original test
batch remains intact and uninspected. Read-only capture at 17:13 UTC verified all
766 retained original files, all 21 frozen capsule members, the exact five-file
check fixture, and absent continuation outputs. Its empty stdout and 625-byte
stderr (c93a5eca…) are preserved exactly.

The frozen paired.py metadata function records only PATH in the retained test
controller environment. Current tmux server/global reconstruction differs only
in PATH. The first launcher supplied a single command string through tmux's
default /usr/bin/zsh; the continuation explicitly used /bin/sh -c. That difference
is consistent with the observed PATH discrepancy. The failed process has exited,
so its complete environment is unavailable; the capture labels current observed
and reconstructed environments without claiming they are a historical snapshot.

This amendment permits one new launch of the byte-identical original continuation
capsule, setting only the inherited PATH to the value already recorded by the
completed test batch. The original strict inherited-environment and machine
guards remain unchanged. Per-sample configuration already supplies an explicit
different PATH, which remains byte-identical. All fixed sample counts, order,
seeds, command, canonical binary paths, compiler work, freshness checks, quiet
guard, raw audits, analysis and gates are unchanged. No completed observations
are repeated, replaced, omitted, pooled or extended.

The new launcher requires exact root approval, rehashes all 766 original files and
the complete capsule, checks the untouched fixture and absence boundary, and
retains a request/source/before/seal receipt in a new task-owned metadata namespace.
Original logs remain in place and are also copied into that history. New controller
logs use attempt02 names. It then invokes the original complete_ir.py once. Any
new failure is retained and requires another explicit review; no automatic retry.

The original collector already includes all logs and continuation namespaces. Its
sampling and statistical reviewer need no change. Before any effects or native
eligibility, an additional read-only lineage join must bind the final collection
to this source freeze, request/approval, preserved failed logs, and history seal,
and verify that the resulting check manifest inherited environment matches the
original test manifest. Native use remains held behind the separately required
strict prerequisite-membership amendment and accepted final IR review.

This is an operational repair before the remaining workflow starts. Any actual
performance-gate failure still rejects the candidate. No comparative effect was
inspected to choose this amendment.
