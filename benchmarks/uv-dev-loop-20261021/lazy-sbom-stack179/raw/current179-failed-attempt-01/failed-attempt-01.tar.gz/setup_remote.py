#!/usr/bin/env python3
"""Prepare a fresh current179 fixture; do not run Cargo or install a placeholder."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import traceback

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
OLD = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import input_catalog


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def run(argv, **kwargs):
    return subprocess.check_output(argv, text=True, **kwargs).strip()


def write(name, value):
    with (ROOT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'setup_remote.py'
    assert socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000
    assert ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid()
    ownership = json.loads((ROOT / 'ownership.json').read_text())
    assert ownership == {'root': str(ROOT), 'uid': os.getuid(), 'cohort': 'current179-lazy-sbom'}
    assert not (ROOT / 'setup.json').exists()
    for relative, record in json.loads((ROOT / 'stage-assets.json').read_text()).items():
        assert sha(ROOT / relative) == record['sha256'], relative
    started = datetime.now(timezone.utc).isoformat()
    rows = run(['ps', '-eo', 'pid=,comm=,pcpu=,pmem=', '--sort=-pcpu']).splitlines()
    builders = {'cargo', 'rustc', 'rustdoc', 'valgrind', 'callgrind-amd64',
                'ld', 'ld.lld', 'cc1', 'cc1plus', 'clang', 'clang++'}
    assert not [row for row in rows if row.split()[1] in builders], 'host has active compiler/profiler work'
    assert shutil.disk_usage(ROOT).free >= 40 * 1024**3
    assert run(['git', '-C', str(OLD / 'uv'), 'rev-parse', 'HEAD']) == '3d82a6ad5a7eab8c68236553b7846517767c4b61'
    assert not run(['git', '-C', str(OLD / 'uv'), 'status', '--porcelain'])
    for name in ('tmp', 'logs', 'metadata', 'binaries', 'build', 'active/bin',
                 'targets', 'fixtures', 'results', 'cargo-home', 'shared'):
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    assert not (ROOT / 'uv').exists()
    subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--quiet',
                    '--no-hardlinks', str(OLD / 'uv'), str(ROOT / 'uv')], check=True)
    copied_cache = []
    for name in ('registry', 'git'):
        source = OLD / 'cargo-home' / name
        if source.exists():
            subprocess.run(['cp', '-a', '--reflink=never', '--', str(source),
                            str(ROOT / 'cargo-home' / name)], check=True)
            copied_cache.append(name)
    assert set(path.name for path in (ROOT / 'cargo-home').iterdir()) == set(copied_cache)
    for filename in ('valgrind.deb', 'libc6-dbg.deb'):
        subprocess.run(['dpkg-deb', '-x', str(ROOT / 'profiling-tools' / filename),
                        str(ROOT / 'profiling-tools/valgrind')], check=True)
    loader = Path('/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2')
    match = re.search(r'Build ID: ([0-9a-f]+)', run(['readelf', '-n', str(loader)]))
    assert match
    build_id = match[1]
    debug = ROOT / 'profiling-tools/valgrind/usr/lib/debug/.build-id' / build_id[:2] / (build_id[2:] + '.debug')
    assert debug.is_file(), 'matching loader debuginfo is required by Callgrind'
    configured = json.loads((ROOT / 'work/benchmark/environment.json').read_text())
    env = os.environ.copy()
    for key, value in configured.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    # Setup launches use the system interpreter without login-shell activation.
    env.pop('PYTHONSAFEPATH', None)
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    catalog = input_catalog.create(ROOT / 'metadata/input-catalog.json', ROOT / 'uv',
                                   ROOT / 'cargo-home', configured['PATH'])
    with (ROOT / 'logs/helper-tests.stdout').open('xb') as out, (ROOT / 'logs/helper-tests.stderr').open('xb') as err:
        tested = subprocess.run([sys.executable, '-m', 'unittest', '-v',
                                 'test_dirty_fixture', 'test_dirty_guard', 'test_dirty_audit_v2'],
                                cwd=ROOT / 'work/benchmark', env=env, stdout=out, stderr=err)
    assert tested.returncode == 0, 'helper tests failed; preserve setup logs'
    test_text = (ROOT / 'logs/helper-tests.stderr').read_text()
    assert 'Ran 29 tests' in test_text and test_text.rstrip().endswith('OK')
    frozen = {str(path.relative_to(ROOT)): sha(path)
              for path in sorted((ROOT / 'work/benchmark').iterdir()) if path.is_file()}
    profiler = {str(path.relative_to(ROOT)): sha(path)
                for path in sorted((ROOT / 'profiling-tools').rglob('*')) if path.is_file()}
    runtime = [loader, Path('/usr/lib/x86_64-linux-gnu/libc.so.6'),
               Path('/usr/lib/x86_64-linux-gnu/libm.so.6'), Path('/usr/lib/x86_64-linux-gnu/libgcc_s.so.1'),
               Path('/etc/ssl/certs/ca-certificates.crt'), Path(sys.executable)]
    record = {
        'state': 'ready-for-matched-pair', 'started_at': started,
        'finished_at': datetime.now(timezone.utc).isoformat(), 'root': str(ROOT), 'uid': os.getuid(),
        'source_input_root_read_only': str(OLD),
        'source_revision': run(['git', '-C', str(ROOT / 'uv'), 'rev-parse', 'HEAD']),
        'source_status': run(['git', '-C', str(ROOT / 'uv'), 'status', '--porcelain']),
        'package_cache_source': str(OLD / 'cargo-home'), 'package_cache_copied_children': copied_cache,
        'frozen_helper_sha256': frozen, 'profiler_file_sha256': profiler,
        'runtime_file_sha256': {str(path): sha(path) for path in runtime},
        'input_catalog_sha256': sha(ROOT / 'metadata/input-catalog.json'),
        'native_input_files': input_catalog.record_files(catalog),
        'valgrind_version': run([str(ROOT / 'profiling-tools/valgrind/usr/bin/valgrind'), '--version'], env=env),
        'loader_build_id': build_id, 'loader_debug_sha256': sha(debug),
        'helper_tests': {'count': 29, 'passed': True,
                         'stderr_sha256': sha(ROOT / 'logs/helper-tests.stderr')},
        'pre_setup_processes': rows[:20], 'disk_available_after': shutil.disk_usage(ROOT).free,
        'no_cargo_build_or_benchmark_executed': True,
    }
    assert not record['source_status']
    input_catalog.check(ROOT / 'metadata/input-catalog.json')
    write('setup.json', record)
    print(json.dumps({'state': record['state'], 'setup_sha256': sha(ROOT / 'setup.json'),
                      'tests': record['helper_tests'], 'root': str(ROOT)}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        write('setup-failure.json', {'at': datetime.now(timezone.utc).isoformat(),
                                    'traceback': traceback.format_exc()})
        raise
