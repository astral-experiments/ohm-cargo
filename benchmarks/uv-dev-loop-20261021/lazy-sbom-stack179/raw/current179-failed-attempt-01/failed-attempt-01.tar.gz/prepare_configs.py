#!/usr/bin/env python3
"""Bind the real matched host3 pair and exact fixture hooks before diagnostics."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
OLD = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
PROTOCOL_SHA = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
TREES = {'baseline': 'f4ce59f92aa17461fe3c8b68923c88539136045a',
         'candidate': 'c377ade816d378aa75f629313ac7b116da10c6da'}
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_fixture
import dirty_guard
import input_catalog


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'prepare_configs.py'
    assert ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid() == 1000
    setup = json.loads((ROOT / 'setup.json').read_text())
    assert setup['state'] == 'ready-for-matched-pair'
    for relative, record in json.loads((ROOT / 'stage-assets.json').read_text()).items():
        assert sha(ROOT / relative) == record['sha256'], relative
    assert sha(ROOT / 'metadata/input-catalog.json') == setup['input_catalog_sha256']
    assert setup['helper_tests']['passed'] and setup['helper_tests']['count'] == 29
    assert sha(ROOT / 'logs/helper-tests.stderr') == setup['helper_tests']['stderr_sha256']
    pair = json.loads((ROOT / 'matched-pair.json').read_text())
    assert pair['cohort'] == 'host3-sbom-stack179'
    assert set(pair['variants']) == set(TREES)
    assert not (ROOT / 'metadata/frozen-cohort.json').exists()
    protocol_path = ROOT / 'work/benchmark/protocol.json'
    assert sha(protocol_path) == PROTOCOL_SHA
    protocol = json.loads(protocol_path.read_text())
    assert protocol['root'] == str(ROOT) and protocol['cohort'] == 'current179-lazy-sbom'
    for relative, expected in setup['frozen_helper_sha256'].items():
        assert sha(ROOT / relative) == expected, relative
    for relative, row in pair['files'].items():
        path = ROOT / relative
        assert path.is_relative_to(ROOT) and path.resolve() == path
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], relative
    for variant, record in pair['variants'].items():
        path = Path(record['binary'])
        assert path.parent == ROOT / 'binaries' and path.resolve() == path
        assert path.stat().st_mode & 0o111 and sha(path) == record['sha256']
        assert record['source_tree'] == TREES[variant]
    audit = json.loads((ROOT / 'build/host3/audit-pair.json').read_text())
    assert audit['cohort'] == 'host3-sbom-stack179' and len(audit['records']) == 2
    assert audit['common_build_inputs_sha256'] == pair['common_build_inputs_sha256']
    assert {row['source_tree'] for row in audit['records']} == set(TREES.values())
    assert {row['stripped_sha256'] for row in audit['records']} == {
        row['sha256'] for row in pair['variants'].values()}
    input_catalog.check(ROOT / 'metadata/input-catalog.json')
    source = ROOT / 'uv/crates/uv/src/lib.rs'
    canonical = ROOT / 'active/bin/cargo'
    environment = json.loads((ROOT / 'work/benchmark/environment.json').read_text())
    assert environment['CARGO_HOME'] == str(ROOT / 'cargo-home')
    assert environment['CARGO_BUILD_BUILD_DIR'] == str(ROOT / 'shared')
    assert environment['LD_LIBRARY_PATH'] is None and environment['LD_PRELOAD'] is None
    assert 'CARGO_TARGET_DIR' not in environment
    commands = {}
    for workload in ('test', 'check'):
        command = ['taskset', '-c', '0-7', '{cargo}', '-Zohm-defaults=yes', workload]
        if workload == 'test':
            command.append('--no-run')
        command += ['--locked', '--offline', '-j', '8', '--message-format=json', '-v']
        commands[workload] = command
    phases = list(protocol['phases'])
    assert len(phases) == 4
    for workload in ('test', 'check'):
        phases.append({'workload': workload, 'metric': 'cargo_ir', 'phase': 'diagnostic-forward',
                       'target_assignment': {'baseline': 'base', 'candidate': 'cand'},
                       'diagnostic_only': True})
    state_specs, plans = {}, []
    for phase in phases:
        metric = 'ir' if phase['metric'] == 'cargo_ir' else 'native'
        name = f"{phase['workload']}-{metric}-{phase['phase']}"
        state = ROOT / 'fixtures' / name
        targets = {variant: str(ROOT / 'targets' / phase['workload'] / leaf)
                   for variant, leaf in phase['target_assignment'].items()}
        assert set(targets) == set(TREES)
        assert {Path(path).name for path in targets.values()} == {'base', 'cand'}
        dirty_fixture.initialize(state, source, ROOT / 'uv', targets, ROOT / 'shared')
        state_specs[str(state)] = {'targets': targets, 'shared_build_dir': str(ROOT / 'shared'),
                                  'workload': phase['workload']}
        plans.append((name, phase, state))
    guard = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.create(ROOT, ROOT / 'uv', source,
                       {workload: [arg.replace('{cargo}', str(canonical)) for arg in command]
                        for workload, command in commands.items()}, state_specs, guard)
    dirty_guard.check(guard, restored=True)
    cohort_path = ROOT / 'metadata/frozen-cohort.json'
    expected_path = ROOT / 'metadata/diagnostic-expectations.json'
    common = [str(OLD / 'ohm/bin/rustc'), str(OLD / 'ohm/bin/rustdoc'),
              str(OLD / 'ohm/lib/librustc_driver-b03bf00bec23bb9a.so'),
              str(ROOT / 'uv/Cargo.lock'), str(source), str(guard), str(ROOT / 'setup.json'),
              str(ROOT / 'ownership.json'), str(ROOT / 'stage-assets.json'),
              str(ROOT / 'matched-pair.json'), str(ROOT / 'metadata/input-catalog.json'),
              str(ROOT / 'setup_remote.py'), str(ROOT / 'prepare_configs.py'),
              str(ROOT / 'logs/helper-tests.stdout'), str(ROOT / 'logs/helper-tests.stderr'),
              str(cohort_path), str(expected_path),
              *[str(ROOT / name) for name in setup['frozen_helper_sha256']],
              *list(setup['runtime_file_sha256']), *setup['native_input_files'],
              *[str(path) for path in sorted((ROOT / 'build').rglob('*')) if path.is_file()]]
    for relative, expected in setup['profiler_file_sha256'].items():
        assert sha(ROOT / relative) == expected, relative
    for path, expected in setup['runtime_file_sha256'].items():
        assert sha(path) == expected, path
    assets = {Path(row['binary']) for row in pair['variants'].values()}
    prepared, bindings = {}, []
    for name, phase, state in plans:
        native = commands[phase['workload']]
        command, metric_files = native, None
        records = common + [str(state / 'manifest.json'), str(state / 'original.bin')]
        if phase['metric'] == 'cargo_ir':
            command = ['taskset', '-c', '0-7', 'env',
                       'LD_PRELOAD=' + str(ROOT / 'profiling-tools/ohm-valgrind-env.so'),
                       'OHM_BENCH_NORMALIZE_VALGRIND_ENV=1',
                       str(ROOT / 'profiling-tools/valgrind/usr/bin/valgrind'),
                       '--tool=callgrind', '--trace-children=no',
                       '--extra-debuginfo-path=' + str(ROOT / 'profiling-tools/valgrind/usr/lib/debug'),
                       '--callgrind-out-file={output}/callgrind-{stage}-{pair}-{variant}.out', *native[3:]]
            metric_files = {'cargo_ir': {'format': 'callgrind', 'event': 'Ir',
                                         'path': '{output}/callgrind-{stage}-{pair}-{variant}.out'}}
            records += [str(ROOT / relative) for relative in setup['profiler_file_sha256']]
        config = {
            'cwd': str(ROOT / 'uv'), 'canonical_executable': str(canonical),
            'variants': {variant: row['binary'] for variant, row in pair['variants'].items()},
            'command': command, 'env': environment,
            'variant_env': {variant: {'CARGO_TARGET_DIR': target}
                            for variant, target in state_specs[str(state)]['targets'].items()},
            'prepare_command': ['/usr/bin/python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'prepare',
                                '--guard', str(guard), '--state', str(state), '--batch', '{output}',
                                '--stage', '{stage}', '--pair', '{pair}', '--variant', '{variant}',
                                '--', *native],
            'cleanup_command': ['/usr/bin/python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'restore',
                                '--guard', str(guard), '--state', str(state)],
            'record_files': sorted(set(records)),
            'pending_frozen_assets': ['successful matched native/instrumented diagnostic expectations'],
        }
        if metric_files is not None:
            config['metric_files'] = metric_files
        path = ROOT / 'configs' / f'{name}.prepared.json'
        write(path, config)
        prepared[str(path)] = sha(path)
        bindings.append({'config': str(path), 'sha256': sha(path), 'state': str(state),
                         'diagnostic_only': phase.get('diagnostic_only', False), **state_specs[str(state)]})
        assets.add(path)
        assets.update(Path(item) for item in records if item not in {str(cohort_path), str(expected_path)})
    assert len(prepared) == 6
    binding_path = ROOT / 'metadata/preflight-fixture-bindings.json'
    write(binding_path, {'valid': True, 'source_restored': True, 'configs': bindings})
    assets.add(binding_path)
    for path in assets:
        assert path.is_file(), path
    frozen = {
        'frozen_at': datetime.now(timezone.utc).isoformat(), 'cohort': 'current179-lazy-sbom',
        'state': 'Real matched binaries and six exact fixture hooks frozen; no diagnostic or comparative samples yet',
        'variant_sha256': {variant: row['sha256'] for variant, row in pair['variants'].items()},
        'source_trees': TREES, 'protocol_sha256': PROTOCOL_SHA,
        'matched_pair_sha256': sha(ROOT / 'matched-pair.json'),
        'prepared_config_sha256': prepared,
        'asset_sha256': {str(path): sha(path) for path in sorted(assets)},
    }
    write(cohort_path, frozen)
    dirty_guard.check(guard, restored=True)
    input_catalog.check(ROOT / 'metadata/input-catalog.json')
    print(json.dumps({'cohort_sha256': sha(cohort_path), 'variant_sha256': frozen['variant_sha256'],
                      'prepared_config_sha256': prepared, 'source_restored': True}, indent=2))


if __name__ == '__main__':
    main()
