#!/usr/bin/env python3
"""Record Cargo configuration presence and resolved native tool identities."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    if not path.exists() and not path.is_symlink():
        return {'exists': False}
    row = {'exists': path.exists(), 'mode': stat.S_IMODE(path.lstat().st_mode),
           'symlink': os.readlink(path) if path.is_symlink() else None,
           'resolved': str(path.resolve())}
    if path.exists():
        if not path.is_file():
            raise ValueError(f'configured input must be a regular file: {path}')
        row.update({'sha256': sha(path), 'bytes': path.stat().st_size,
                    'resolved_mode': stat.S_IMODE(path.stat().st_mode)})
    return row


def snapshot(workspace, cargo_home, native_path, tool_names):
    workspace, cargo_home = Path(workspace), Path(cargo_home)
    configs = {parent / '.cargo' / name
               for parent in (workspace, *workspace.parents)
               for name in ('config', 'config.toml')}
    configs.update(cargo_home / name for name in ('config', 'config.toml'))
    for name in ('config', 'config.toml'):
        path = cargo_home / name
        if path.exists() or path.is_symlink():
            raise ValueError('the dedicated Cargo home must remain configuration-free')
    tools = {}
    for name in tool_names:
        resolved = shutil.which(name, path=native_path)
        if resolved is None:
            raise ValueError(f'native tool not found on the frozen PATH: {name}')
        tools[name] = {'path': resolved, **identity(resolved)}
    return {'workspace': str(workspace), 'cargo_home': str(cargo_home),
            'native_path': native_path, 'tool_names': tool_names,
            'configs': {str(path): identity(path) for path in sorted(configs)},
            'tools': tools}


def create(path, workspace, cargo_home, native_path):
    names = ['python3', 'taskset', 'env', 'git', 'cp', 'strace', 'cc', 'ar',
             'ld', 'as', 'ranlib', 'make', 'perl', 'readelf', 'pkg-config']
    record = {'created_at': datetime.now(timezone.utc).isoformat(),
              'snapshot': snapshot(workspace, cargo_home, native_path, names)}
    with Path(path).open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    return record


def check(path):
    record = json.loads(Path(path).read_text())
    expected = record['snapshot']
    actual = snapshot(expected['workspace'], expected['cargo_home'],
                      expected['native_path'], expected['tool_names'])
    if actual != expected:
        raise ValueError('Cargo configuration presence or native tool identity changed')
    return record


def record_files(record):
    snapshot = record['snapshot']
    return sorted({path for path, row in snapshot['configs'].items() if row['exists']}
                  | {row['path'] for row in snapshot['tools'].values()})
