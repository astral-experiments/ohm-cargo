import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import dirty_fixture as fixture


class DirtyFixtureTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        self.source = self.workspace / "lib.rs"
        self.original = b"pub fn value() -> i32 { 1 }\n"
        self.source.write_bytes(self.original)
        self.state = self.root / "state"
        self.targets = {name: self.root / "targets" / leaf for name, leaf in (("baseline", "base"), ("candidate", "cand"))}
        self.shared = self.root / "shared"
        fixture.initialize(self.state, self.source, self.workspace, self.targets, self.shared)
        self.batch = self.root / "results"

    def tearDown(self):
        self.temporary.cleanup()

    def environment(self, variant):
        return {"CARGO_TARGET_DIR": str(self.targets[variant]), "CARGO_BUILD_BUILD_DIR": str(self.shared)}

    def prepare(self, variant, pair=0, batch=None, returncode=0):
        with mock.patch("dirty_fixture.subprocess.run", return_value=subprocess.CompletedProcess(["cargo", "check"], returncode)):
            return fixture.prepare(self.state, batch or self.batch, "measurement", pair, variant, ["cargo", "check"], self.environment(variant))

    def test_initialization_does_not_edit_source(self):
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_paired_input_bytes_match_and_restore(self):
        warmed = []
        def warm(command, **kwargs):
            warmed.append(self.source.read_bytes())
            return subprocess.CompletedProcess(command, 0)
        with mock.patch("dirty_fixture.subprocess.run", side_effect=warm):
            first = fixture.prepare(self.state, self.batch, "measurement", 0, "candidate", ["cargo", "check"], self.environment("candidate"))
            first_after = self.source.read_bytes()
            second = fixture.prepare(self.state, self.batch, "measurement", 0, "baseline", ["cargo", "check"], self.environment("baseline"))
        self.assertEqual(warmed[0], warmed[1])
        self.assertEqual(first_after, self.source.read_bytes())
        self.assertNotEqual(warmed[0], first_after)
        self.assertEqual(len(warmed[0]), len(first_after))
        self.assertEqual(first["before_sha256"], second["before_sha256"])
        self.assertEqual(first["after_sha256"], second["after_sha256"])
        fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_next_pair_and_new_batch_change_content(self):
        first = self.prepare("baseline")
        second = self.prepare("baseline", pair=1)
        third = self.prepare("baseline", pair=1, batch=self.root / "another-batch")
        self.assertEqual(len({first["after_sha256"], second["after_sha256"], third["after_sha256"]}), 3)

    def test_repeated_step_and_wrong_target_fail(self):
        self.prepare("baseline")
        with self.assertRaisesRegex(ValueError, "already prepared"):
            self.prepare("baseline")
        with self.assertRaisesRegex(ValueError, "isolated target"):
            fixture.prepare(self.state, self.batch, "measurement", 0, "candidate", ["cargo", "check"], self.environment("baseline"))

    def test_external_edit_is_never_overwritten(self):
        self.prepare("baseline")
        self.source.write_bytes(b"an unrelated user edit\n")
        with self.assertRaisesRegex(ValueError, "unrelated edit"):
            fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), b"an unrelated user edit\n")

    def test_failed_warm_is_restorable(self):
        with self.assertRaisesRegex(RuntimeError, "warm command failed"):
            self.prepare("baseline", returncode=1)
        fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_test_execution_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "--no-run"):
            fixture.prepare(self.state, self.batch, "measurement", 0, "baseline", ["cargo", "test"], self.environment("baseline"))

    def test_target_aliases_are_rejected(self):
        with self.assertRaises(ValueError):
            fixture.validate_paths({"baseline": self.targets["baseline"], "candidate": self.targets["baseline"]}, self.shared)

    def make_results(self, stderr="    Checking uv v0.1 (/workspace)\n    Finished dev profile\n"):
        self.batch.mkdir()
        samples = []
        for variant in ("baseline", "candidate"):
            self.prepare(variant)
            log = self.batch / f"{variant}.stderr"
            log.write_text(stderr)
            samples.append({"stage": "measurement", "pair": 0, "variant": variant, "command": ["cargo", "check"], "stderr": str(log), "returncode": 0})
        fixture.restore(self.state)
        (self.batch / "samples.json").write_text(json.dumps(samples))
        (self.batch / "manifest.json").write_text(json.dumps({"state": "complete"}))

    def test_verifier_confirms_edit_and_restore(self):
        self.make_results()
        result = fixture.verify(self.state, self.batch, ["uv"])
        self.assertTrue(result["valid"])
        self.assertTrue(result["source_restored"])
        self.assertEqual(len(result["samples"]), 2)

    def test_verifier_rejects_noop_or_extra_rebuilds(self):
        self.make_results("    Finished dev profile\n")
        with self.assertRaisesRegex(ValueError, "compiled packages"):
            fixture.verify(self.state, self.batch, ["uv"])
        self.assertFalse(json.loads((self.batch / "fixture-validation.json").read_text())["valid"])

    def test_verifier_rejects_empty_or_failed_run(self):
        self.batch.mkdir()
        (self.batch / "samples.json").write_text("[]")
        (self.batch / "manifest.json").write_text(json.dumps({"state": "failed"}))
        with self.assertRaisesRegex(ValueError, "no samples"):
            fixture.verify(self.state, self.batch, ["uv"])


if __name__ == "__main__":
    unittest.main()
