import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile
import unittest
from unittest import mock

import dirty_fixture
import dirty_guard


class DirtyGuardTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.workspace = self.root / 'uv'
        self.workspace.mkdir()
        self.source = self.workspace / 'lib.rs'
        self.source.write_text('pub fn value() {}\n')
        (self.workspace / 'other.rs').write_text('// stable\n')
        subprocess.run(['git', 'init', '-q', str(self.workspace)], check=True)
        subprocess.run(['git', '-C', str(self.workspace), 'add', '.'], check=True)
        subprocess.run(['git', '-C', str(self.workspace), '-c', 'user.name=Fixture Test', '-c', 'user.email=test@example.invalid', '-c', 'commit.gpgsign=false', 'commit', '-q', '-m', 'fixture'], check=True)
        self.state = self.root / 'state'
        self.targets = {v: str(self.root / 'targets' / p) for v, p in [('baseline', 'base'), ('candidate', 'cand')]}
        self.shared = str(self.root / 'shared')
        dirty_fixture.initialize(self.state, self.source, self.workspace, self.targets, self.shared)
        self.path = self.root / 'guard.json'
        identity, rows = dirty_guard.source_inventory(self.workspace, self.source)
        self.guard = {
            'root': str(self.root), 'workspace': str(self.workspace), 'source': str(self.source),
            'source_sha256': dirty_guard.sha(self.source.read_bytes()), 'source_mode': stat.S_IMODE(self.source.stat().st_mode),
            'source_identity': identity, 'source_inventory': rows, 'commands': {'check': ['cargo', 'check']},
            'states': {str(self.state): {'targets': self.targets, 'shared_build_dir': self.shared}},
        }
        self.path.write_text(json.dumps(self.guard))

    def tearDown(self):
        self.temporary.cleanup()

    def test_normal_prepare_and_exact_restore(self):
        dirty_guard.check(self.path, self.state, restored=True)
        with mock.patch('dirty_fixture.subprocess.run', return_value=subprocess.CompletedProcess([], 0)):
            dirty_fixture.prepare(self.state, self.root / 'batch', 'measurement', 0, 'baseline', ['cargo', 'check'], {'CARGO_TARGET_DIR': self.targets['baseline'], 'CARGO_BUILD_BUILD_DIR': self.shared})
        dirty_guard.check(self.path, self.state)
        with self.assertRaisesRegex(ValueError, 'restored exactly'):
            dirty_guard.check(self.path, self.state, restored=True)
        dirty_fixture.restore(self.state)
        dirty_guard.check(self.path, self.state, restored=True)

    def test_unrelated_tracked_edit_is_rejected(self):
        (self.workspace / 'other.rs').write_text('// changed\n')
        with self.assertRaisesRegex(ValueError, 'another tracked'):
            dirty_guard.check(self.path, self.state)

    def test_untracked_source_is_rejected(self):
        (self.workspace / 'unexpected.rs').write_text('// new\n')
        with self.assertRaisesRegex(ValueError, 'unexpected staged, untracked'):
            dirty_guard.check(self.path, self.state)

    def test_symlink_and_outside_paths_are_rejected(self):
        link = self.root / 'alias'
        link.symlink_to(self.workspace, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'symlinks'):
            dirty_guard.owned(self.root, link / 'lib.rs', True)
        with self.assertRaisesRegex(ValueError, 'outside'):
            dirty_guard.owned(self.root, self.root.parent / 'external')

    def test_changed_target_assignment_is_rejected(self):
        path = self.state / 'manifest.json'
        data = json.loads(path.read_text())
        data['targets']['baseline'] = data['targets']['candidate']
        path.write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError, 'assignment differs'):
            dirty_guard.check(self.path, self.state)

    def test_source_mode_is_rejected(self):
        self.source.chmod(0o600)
        with self.assertRaisesRegex(ValueError, 'mode changed'):
            dirty_guard.check(self.path, self.state)


if __name__ == '__main__':
    unittest.main()
