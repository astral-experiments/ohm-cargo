import json
import unittest

import dirty_audit_v2 as dirty_audit


class DirtyAuditTests(unittest.TestCase):
    def fixture(self, package='path+file:///fixture/uv/crates/uv#0.13.4'):
        artifact = {'reason': 'compiler-artifact', 'package_id': package, 'fresh': False, 'profile': {'test': True}, 'target': {'name': 'uv', 'kind': ['lib']}, 'executable': '/fixture/target/uv-tests'}
        stdout = json.dumps(artifact) + '\n' + json.dumps({'reason': 'build-finished', 'success': True}) + '\n'
        stderr = '   Compiling uv v0.13.4 (/fixture/uv/crates/uv)\n     Running `/fixture/rustc --crate-name uv crates/uv/src/lib.rs --test --emit=dep-info,link`\n'
        return dirty_audit.parse_run(stdout, stderr), package

    def test_expected_compiler_work_and_no_test_execution(self):
        report, package = self.fixture()
        dirty_audit.validate_run(report, '/fixture/rustc', package, report)
        paths = dirty_audit.validate_no_tests(report, '123 execve("/fixture/rustc", ["rustc"], 0x0 /* 0 vars */) = 0\n')
        self.assertEqual(paths, ['/fixture/rustc'])

    def test_actual_test_execution_is_rejected(self):
        report, _ = self.fixture()
        with self.assertRaisesRegex(ValueError, 'actually ran'):
            dirty_audit.validate_no_tests(report, '123 execve("/fixture/target/uv-tests", ["test"], 0x0 /* 0 vars */) = 0\n')

    def test_unexpected_package_or_command_is_rejected(self):
        report, package = self.fixture()
        report['compiled_packages'].append('registry+index#unexpected@1.0.0')
        with self.assertRaisesRegex(ValueError, 'package other'):
            dirty_audit.validate_run(report, '/fixture/rustc', package)
        report, package = self.fixture()
        report['other_commands'].append(['/fixture/target/uv-tests'])
        with self.assertRaisesRegex(ValueError, 'test execution'):
            dirty_audit.validate_run(report, '/fixture/rustc', package)

    def test_changed_work_is_rejected(self):
        report, package = self.fixture()
        expected = {**report, 'compiled_artifacts': 99}
        with self.assertRaisesRegex(ValueError, 'changed from frozen'):
            dirty_audit.validate_run(report, '/fixture/rustc', package, expected)

    def test_interleaved_execve_records_are_reassembled(self):
        trace = '123 execve("/fixture/rustc", ["rustc"], 0x0 /* 0 vars */ <unfinished ...>\n456 execve("/usr/bin/cc", ["cc"], 0x0 /* 0 vars */) = 0\n123 <... execve resumed>) = 0\n'
        self.assertEqual(dirty_audit.trace_executables(trace), ['/usr/bin/cc', '/fixture/rustc'])

    def rlink_fixture(self, target='/fixture/target/base', source_target=None, package='uv', mode='-Z link-only'):
        source_target = target if source_target is None else source_target
        artifact = {'reason': 'compiler-artifact', 'package_id': 'path+file:///fixture/uv/crates/uv#0.13.4', 'fresh': False, 'profile': {'test': False}, 'target': {'name': 'uvx', 'kind': ['bin']}, 'executable': '/fixture/target/uvx'}
        stdout = json.dumps(artifact) + '\n' + json.dumps({'reason': 'build-finished', 'success': True}) + '\n'
        source = source_target + '/debug/build/workspaces/1111111111111111/2222222222222222/' + package + '/3333333333333333/out/uvx.rlink'
        stderr = f'   Compiling uv v0.13.4 (/fixture/uv/crates/uv)\n     Running `/fixture/rustc --crate-name uvx {source} --out-dir {source.rsplit("/", 1)[0]} --emit=dep-info,link {mode}`\n'
        return stdout, stderr

    def test_rlink_normalizes_only_the_assigned_target_prefix(self):
        first = dirty_audit.parse_run(*self.rlink_fixture(), '/fixture/target/base')
        second = dirty_audit.parse_run(*self.rlink_fixture('/fixture/target/cand'), '/fixture/target/cand')
        self.assertEqual(first['compiler_signatures'], second['compiler_signatures'])
        self.assertNotEqual(first['compiler_commands'][0]['input_path'], second['compiler_commands'][0]['input_path'])
        self.assertEqual(first['compiler_stage_counts'], {'rlink': 1})
        with self.assertRaisesRegex(ValueError, 'target_dir'):
            dirty_audit.validate_run(first, '/fixture/rustc', 'path+file:///fixture/uv/crates/uv#0.13.4', second)

    def test_bound_target_namespaces_allow_only_the_expected_prefix_difference(self):
        first = dirty_audit.parse_run(*self.rlink_fixture(), '/fixture/target/base')
        stdout, stderr = self.rlink_fixture('/fixture/target/cand')
        stderr = stderr.replace('1111111111111111', 'aaaaaaaaaaaaaaaa')
        second = dirty_audit.parse_run(stdout, stderr, '/fixture/target/cand')
        dirty_audit.validate_work_equivalence(second, first)
        self.assertNotEqual(first['compiler_signatures'], second['compiler_signatures'])
        for old, new in [('2222222222222222', 'bbbbbbbbbbbbbbbb'), ('3333333333333333', 'cccccccccccccccc')]:
            altered = dirty_audit.parse_run(stdout, stderr.replace(old, new), '/fixture/target/cand')
            with self.assertRaisesRegex(ValueError, 'beyond the bound'):
                dirty_audit.validate_work_equivalence(altered, first)

    def test_unexpected_namespace_for_the_same_target_is_rejected(self):
        stdout, stderr = self.rlink_fixture()
        expected = dirty_audit.parse_run(stdout, stderr, '/fixture/target/base')
        altered = dirty_audit.parse_run(stdout, stderr.replace('1111111111111111', 'aaaaaaaaaaaaaaaa'), '/fixture/target/base')
        with self.assertRaisesRegex(ValueError, 'workspace_namespaces'):
            dirty_audit.validate_run(altered, '/fixture/rustc', 'path+file:///fixture/uv/crates/uv#0.13.4', expected)

    def test_rustc_output_must_remain_in_the_assigned_target(self):
        stdout, stderr = self.rlink_fixture()
        stderr = stderr.replace('--out-dir /fixture/target/base/', '--out-dir /fixture/target/cand/')
        with self.assertRaisesRegex(ValueError, 'output is outside'):
            dirty_audit.parse_run(stdout, stderr, '/fixture/target/base')

    def test_rlink_outside_assigned_target_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'outside its assigned target'):
            dirty_audit.parse_run(*self.rlink_fixture(source_target='/fixture/target/cand'), '/fixture/target/base')

    def test_rlink_requires_link_only_mode_and_target(self):
        with self.assertRaisesRegex(ValueError, 'assigned target and link-only'):
            dirty_audit.parse_run(*self.rlink_fixture())
        with self.assertRaisesRegex(ValueError, 'assigned target and link-only'):
            dirty_audit.parse_run(*self.rlink_fixture(mode=''), '/fixture/target/base')

    def test_rlink_cannot_substitute_another_workspace_package(self):
        with self.assertRaisesRegex(ValueError, 'generated uv workspace artifact'):
            dirty_audit.parse_run(*self.rlink_fixture(package='other'), '/fixture/target/base')


if __name__ == '__main__':
    unittest.main()
