# Dirty uv root-library build fixture

This fixture appends a deterministic non-doc comment to
`work/uv/crates/uv/src/lib.rs`. It measures rebuilding after a source-content edit
with unchanged Rust semantics. It does not represent a public API change or a
substantial code-generation change. Both workloads keep the original uv source
path: `cargo check` and `cargo test --no-run` with the frozen command, compiler,
features, profile, and job count. No tests execute.

`dirty_fixture.py init` saves original bytes and mode without editing the source.
For every warmup and measured sample, `prepare` does the following outside the
timer:

1. Check that the source still matches the original or a fixture-owned edit.
2. Write deterministic BEFORE content for this batch, stage, and pair.
3. Run the exact workload with the installed variant to warm that target's
   BEFORE state. This also refreshes the shared registry cache's last-use state.
4. Write deterministic AFTER content of the same byte length.

The timed command then rebuilds the edited crate. BEFORE and AFTER hashes are
identical across the two variants in a pair. The marker contains no variant or
AB/BA position. Each pair, stage, and batch has distinct content. Preparation
records source hashes, byte lengths, mtimes, target directory, warm argv and
duration in `journal.jsonl`; its subprocess output stays in the harness's
per-sample preparation logs.

The baseline and candidate use separate equal-length canonical target paths,
ending in `base` and `cand`. Ohm includes the canonical target directory in
`shared_workspace_namespace_version` in `src/compiler/layout.rs`; mutable
workspace outputs therefore stay isolated while `CARGO_BUILD_BUILD_DIR` remains
the same shared registry cache. One variant cannot consume the other's warmed
workspace result. Simply changing a shared source once per pair with one target
would not provide this property. Check and test need their own target cohorts.

Fixed path assignment can itself be a confound. Reverse the baseline/candidate
target assignment for independent confirmation, using a new fixture state
directory and the same equal-length paths. The untimed BEFORE build rewarms the
chosen variant in its reassigned namespace. Compare both order groups and both
directory assignments before making a performance claim.

## Configuration and initialization

The following configuration generation is a proposed setup step, not a benchmark.
Review and freeze the generated JSON, helper, fixture manifests, and binaries
before measurement. It clones the existing native configs so their toolchain and
environment remain explicit. It creates separate exploratory and confirmation
configs; initialization is a separate step and does not edit uv.

```sh
python3 - <<'PY'
import json
from pathlib import Path
root = Path.cwd().resolve()
bench = root / 'work/benchmark'
for workload in ('check', 'test'):
    for phase in ('exploratory', 'confirmation'):
        config = json.loads((bench / f'{workload}-path-cache.json').read_text())
        state = bench / 'fixtures' / f'dirty-{workload}-{phase}'
        target = root / 'work/targets' / f'dirty-{workload}'
        leaves = ('base', 'cand') if phase == 'exploratory' else ('cand', 'base')
        config['variants']['candidate'] = str(root / 'work/binaries/cargo-lazy-sbom')
        config['env'].pop('CARGO_TARGET_DIR', None)
        config['variant_env'] = {
            variant: {'CARGO_TARGET_DIR': str(target / leaf)}
            for variant, leaf in zip(('baseline', 'candidate'), leaves)
        }
        helper = str(bench / 'dirty_fixture.py')
        config['prepare_command'] = [
            'python3', helper, 'prepare', '--state', str(state), '--batch', '{output}',
            '--stage', '{stage}', '--pair', '{pair}', '--variant', '{variant}', '--',
            *config['command'],
        ]
        config['cleanup_command'] = ['python3', helper, 'restore', '--state', str(state)]
        config['record_files'] += [
            helper, str(bench / 'paired.py'), str(state / 'manifest.json'),
            str(state / 'original.bin'), str(root / 'work/uv/crates/uv/src/lib.rs'),
        ]
        name = f'{workload}-lazy-sbom-dirty-{phase}.json'
        (bench / name).write_text(json.dumps(config, indent=2) + '\n')
PY
```

Initialize each state once, with uv restored between workloads. For exploratory
check, from the workspace root:

```sh
python3 work/benchmark/dirty_fixture.py init \
  --state work/benchmark/fixtures/dirty-check-exploratory \
  --source work/uv/crates/uv/src/lib.rs --workspace work/uv \
  --baseline-target work/targets/dirty-check/base \
  --candidate-target work/targets/dirty-check/cand \
  --shared-build-dir work/shared-cache
```

Use `dirty-test` for the test cohort. For confirmation, change the state suffix to
`confirmation` and swap the baseline/candidate target leaves. A state directory
must be new; initialization rejects an existing fixture marker. No fixture or
other Cargo workload may run concurrently against this uv checkout. Locks guard
individual helper operations, not an entire timed subprocess.

Before measurement, use a disposable diagnostic config with `-vv` on the timed
command to inspect the expected root uv rustc invocation(s). `cargo test` must
retain `--no-run`. Freeze expected compiled package names after this diagnostic;
the default validator expects exactly `uv`. Do not relax this expectation to
hide a package that unexpectedly starts rebuilding during confirmation.

Run all actual Cargo workloads through escalated host execution. New target
namespaces may make the first untimed warm command expensive; that warm command
is outside the timer. Preserve normal randomized warmup pairs afterward.

```sh
python3 work/benchmark/paired.py run \
  --config work/benchmark/check-lazy-sbom-dirty-exploratory.json \
  --output work/benchmark/results/dirty-check-exploratory-1 \
  --phase exploratory --pairs 30 --warmup-pairs 2 --seed 71001
python3 work/benchmark/dirty_fixture.py verify \
  --state work/benchmark/fixtures/dirty-check-exploratory \
  --results work/benchmark/results/dirty-check-exploratory-1
python3 work/benchmark/paired.py analyze work/benchmark/results/dirty-check-exploratory-1
```

The validation step is required before interpreting the statistics. It checks
successful completion, one preparation for every sample, equal paired source
hashes, nonempty `Checking uv` or `Compiling uv` progress in every timed log,
absence of unexpected rebuilt packages, and exact original source restoration.
It writes `fixture-validation.json` and fails if any invariant fails. It uses
package-level Cargo progress; the separate verbose diagnostic establishes the
specific target/compiler behavior. All failed or unexpected samples stay in the
raw logs; investigate and rerun a complete frozen batch rather than dropping
individual samples.

For Callgrind, wrap only the timed command in the existing process-only
instrumentation configuration and retain a native prepare command. Instrumented
Cargo counts exclude child compiler/linker work; dirty native wall confirmation
still requires a fresh batch of at least 30 pairs with the frozen candidate.

## Restoration

The harness cleanup hook restores source bytes on ordinary completion and errors,
before checking immutable input hashes. It preserves mode and leaves a fresh
mtime so Cargo notices restoration. It refuses to overwrite unrecognized edits.
After a killed interpreter or host interruption, run:

```sh
python3 work/benchmark/dirty_fixture.py restore \
  --state work/benchmark/fixtures/dirty-check-exploratory
```

The helper records intended content before atomic replacement so an interruption
around the rename remains recoverable. It protects source contents against
unrelated edits, but it is not a filesystem crash-recovery system. Keep the saved
`original.bin` and immutable fixture manifest with the raw results.
