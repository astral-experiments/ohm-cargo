#!/usr/bin/env python3
"""Bind both real host2 artifacts and derive configs before dirty comparisons."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'work/benchmark/freeze_cohort.py'
    guard = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.check(guard, restored=True)
    assert sha(ROOT / 'work/benchmark/protocol.json') == 'e4d278ba9169dc2ce0445dca05734ef7b7646a19bb5f063fcb73f6c07636b5df'
    assert sha(ROOT / 'work/benchmark/protocol-amendment-host2.json') == '26409dbc7e8c3bc0888eef248c428623b0badf4b5be08662df6a00f7ef072ef3'
    transfer = json.loads((ROOT / 'metadata/host2-transfer.json').read_text())
    for path, expected in transfer['asset_sha256'].items():
        assert sha(path) == expected, path
    provenance = json.loads((ROOT / 'build/host2/provenance.json').read_text())
    assert provenance['host'] == 'charlie-oss-2'
    assert provenance['cohort'] == 'host2-pr175-sbom'
    assert provenance['driver_sha256'] == '519396de0f3d48fe34fd3116ac04356c3a46606cead02e38095c75be6706a04d'
    assert provenance['source'] == '/tmp/ohm-hillclimb-20261021-production/source'
    assert provenance['target'] == '/tmp/ohm-hillclimb-20261021-production/target'
    settings = provenance['environment']
    assert settings['CARGO_PROFILE_RELEASE_LTO'] == 'thin'
    assert settings['CARGO_PROFILE_RELEASE_CODEGEN_UNITS'] == '1'
    assert settings['CFG_RELEASE_CHANNEL'] == 'dev'
    assert settings['LIBZ_SYS_STATIC'] == '1'
    assert 'all-static,ohm-defaults' in provenance['command']
    assert 'no PGO' in provenance['approximation']
    variants = {'baseline': ROOT / 'binaries/cargo-pr175-host2',
                'candidate': ROOT / 'binaries/cargo-pr175-lazy-sbom-host2'}
    expected_trees = {'baseline': '3d67bfb965bc0b6452ab78205045c5154db0acf7',
                      'candidate': 'ec684868eed8347beeb23d1a998e7f2cb997bc7a'}
    identity = {}
    for variant, path in variants.items():
        name = 'cargo-pr175' if variant == 'baseline' else 'cargo-pr175-lazy-sbom'
        build = json.loads((ROOT / 'build/host2' / (name + '.build.json')).read_text())
        stripped = json.loads((ROOT / 'build/host2' / (name + '.strip.json')).read_text())
        assert sha(path) == stripped['stripped_sha256']
        assert path.stat().st_size == stripped['stripped_bytes']
        assert build['original_linker_output_sha256'] == stripped['source_sha256'] == stripped['original_linker_output_sha256']
        assert build['observed_source_tree'] == build['expected_source_tree_from_patches'] == expected_trees[variant]
        assert build['common_build_inputs_sha256'] == provenance['common_build_inputs_sha256']
        assert build['embedded_source_commit'] == '5e5d271d763d7beb38b48755e22bd59e93f02b97'
        assert sha(ROOT / 'build/host2' / (name.removeprefix('cargo-') + '.source.patch')) == build['observed_diff_sha256']
        identity[variant] = {'binary': str(path), 'sha256': sha(path), 'source_tree': expected_trees[variant],
                             'original_linker_output_sha256': build['original_linker_output_sha256']}
    amendment = json.loads((ROOT / 'metadata/audit-amendment-01.json').read_text())
    assert amendment['tests_passed']
    assert sha(ROOT / 'logs/helper-tests-03.stderr') == amendment['test_stderr_sha256']
    assert 'Ran 26 tests' in (ROOT / 'logs/helper-tests-03.stderr').read_text()
    extra = [ROOT / 'work/benchmark/protocol-amendment-host2.json', ROOT / 'metadata/audit-amendment-01.json',
             ROOT / 'metadata/host2-helper-adjustment.json', ROOT / 'metadata/host2-transfer.json',
             ROOT / 'logs/helper-tests-03.stdout', ROOT / 'logs/helper-tests-03.stderr']
    extra.extend(path for path in (ROOT / 'build/host2').iterdir() if path.is_file())
    extra.extend(path for path in (ROOT / 'work/benchmark').iterdir() if path.is_file())
    all_assets = set(extra) | set(variants.values())
    prepared_hashes = {}
    for pending in sorted((ROOT / 'configs').glob('*.pending.json')):
        config = json.loads(pending.read_text())
        config['variants'] = {key: str(path) for key, path in variants.items()}
        records = [Path(path) for path in config['record_files']
                   if not Path(path).is_relative_to(ROOT / 'build')
                   and path not in (str(ROOT / 'metadata/frozen-candidate.json'), str(ROOT / 'metadata/diagnostic-expectations.json'))]
        # These are bound as inputs when measurements are finalized, after diagnostics.
        records.extend(extra)
        config['record_files'] = sorted({str(path) for path in records} | {
            str(ROOT / 'metadata/frozen-cohort.json'), str(ROOT / 'metadata/diagnostic-expectations.json')})
        config['pending_frozen_assets'] = ['successful matched native/instrumented diagnostic expectations']
        output = pending.with_name(pending.name.removesuffix('.pending.json') + '.prepared.json')
        write(output, config)
        prepared_hashes[str(output)] = sha(output)
        all_assets.update(records)
        all_assets.add(output)
    assert len(prepared_hashes) == 6
    for path in all_assets:
        assert path.is_file(), path
    frozen = {
        'frozen_at': datetime.now(timezone.utc).isoformat(), 'cohort': 'host2-pr175-sbom',
        'state': 'Both real matched artifacts frozen before full preflight or comparative samples',
        'identities': identity, 'variant_sha256': {key: value['sha256'] for key, value in identity.items()},
        'common_build_inputs_sha256': provenance['common_build_inputs_sha256'],
        'prepared_config_sha256': prepared_hashes,
        'asset_sha256': {str(path): sha(path) for path in sorted(all_assets)},
        'earlier_baseline_role': 'Untimed seeding only; excluded from both comparative variant inputs',
    }
    write(ROOT / 'metadata/frozen-cohort.json', frozen)
    print(json.dumps({'cohort': frozen['cohort'], 'variant_sha256': frozen['variant_sha256'],
                      'prepared_config_sha256': prepared_hashes, 'source_restored': True}, indent=2))


if __name__ == '__main__':
    main()
