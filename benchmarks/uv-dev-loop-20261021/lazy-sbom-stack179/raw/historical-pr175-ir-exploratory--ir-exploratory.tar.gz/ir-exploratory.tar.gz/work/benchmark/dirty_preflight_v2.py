#!/usr/bin/env python3
"""Run untimed dirty-workload execution diagnostics before comparative sampling."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback

import dirty_audit_v2 as dirty_audit
import dirty_guard
import paired

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')


def now():
    return datetime.now(timezone.utc).isoformat()


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def run(command, environment, stdout, stderr):
    with stdout.open('xb') as out, stderr.open('xb') as err:
        process = subprocess.run(command, cwd=ROOT / 'uv', env=environment, stdout=out, stderr=err)
    if process.returncode:
        raise RuntimeError(f'diagnostic command failed ({process.returncode}); see {stderr}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    if not args.name.replace('-', '').isalnum():
        raise ValueError('diagnostic name must be a simple owned-directory component')
    guard_path = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.check(guard_path, restored=True)
    frozen = json.loads((ROOT / 'metadata/frozen-cohort-v2.json').read_text())
    amendment = json.loads((ROOT / 'work/benchmark/protocol-amendment-target-bindings.json').read_text())
    for path, expected in frozen['asset_sha256'].items():
        if paired.sha256(path) != expected:
            raise ValueError(f'frozen asset changed: {path}')
    output = ROOT / 'diagnostics' / args.name
    output.mkdir(parents=True, exist_ok=False)
    (output / 'logs').mkdir()
    manifest = {'state': 'running', 'started_at': now(), 'purpose': 'Untimed correctness and execution-shape diagnostics; never performance samples', 'variant_sha256': frozen['variant_sha256'], 'runs': []}
    write(output / 'manifest.json', manifest)
    original = (ROOT / 'uv/crates/uv/src/lib.rs').read_bytes()
    expectations = {'rustc': str(Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc')), 'uv_package': None, 'workloads': {}, 'diagnostic_directory': str(output)}
    active_state = None
    cleanup = None
    lock = (ROOT / 'experiment.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for workload in ('test', 'check'):
            for assignment in ('forward', 'reverse'):
                work_output = output / f'{workload}-{assignment}'
                work_output.mkdir()
                config_phase = 'exploratory' if assignment == 'forward' else 'confirmation'
                config = json.loads((ROOT / 'configs' / f'{workload}-ir-{config_phase}.prepared-v2.json').read_text())
                active_state = ROOT / 'fixtures' / f'{workload}-diagnostic'
                guard = dirty_guard.check(guard_path, active_state, restored=True)
                native = guard['commands'][workload]
                cleanup = ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'restore', '--guard', str(guard_path), '--state', str(active_state)]
                for pair, metric in enumerate(('native', 'ir')):
                    for position, variant in enumerate(('baseline', 'candidate')):
                        label = f'{workload}-{assignment}-{metric}-{variant}'
                        print(f'{now()} preparing {label}', flush=True)
                        context = {'cargo': ROOT / 'active/bin/cargo', 'variant': variant, 'pair': pair, 'stage': 'measurement', 'phase': 'diagnostic', 'output': work_output, 'position': position}
                        environment = os.environ.copy()
                        configured = {**config['env'], **config['variant_env'][variant]}
                        for key, value in configured.items():
                            if value is None:
                                environment.pop(key, None)
                            else:
                                environment[key] = paired.substitute(str(value), context)
                        environment.update({'OHM_BENCH_' + key.upper(): str(value) for key, value in context.items() if key != 'cargo'})
                        paired.install_variant(Path(config['variants'][variant]), ROOT / 'active/bin/cargo')
                        if paired.sha256(ROOT / 'active/bin/cargo') != frozen['variant_sha256'][variant]:
                            raise ValueError('canonical Cargo does not match frozen variant')
                        prepare = ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'prepare', '--guard', str(guard_path), '--state', str(active_state), '--batch', str(work_output), '--stage', 'measurement', '--pair', str(pair), '--variant', variant, '--', *native]
                        run(prepare, environment, output / 'logs' / (label + '.prepare.stdout'), output / 'logs' / (label + '.prepare.stderr'))
                        command = native if metric == 'native' else [paired.substitute(arg, context) for arg in config['command']]
                        trace = output / 'logs' / (label + '.execve')
                        traced = ['/usr/bin/strace', '-f', '-qq', '-s', '65536', '-e', 'trace=execve,execveat', '-o', str(trace), *command]
                        stdout = output / 'logs' / (label + '.stdout')
                        stderr = output / 'logs' / (label + '.stderr')
                        run(traced, environment, stdout, stderr)
                        report = dirty_audit.parse_run(stdout.read_text(), stderr.read_text(), environment['CARGO_TARGET_DIR'])
                        if expectations['uv_package'] is None:
                            if len(report['compiled_packages']) != 1 or not report['compiled_packages'][0].endswith('/crates/uv#0.13.4'):
                                raise ValueError('first diagnostic did not identify the pinned uv package')
                            expectations['uv_package'] = report['compiled_packages'][0]
                        target = environment['CARGO_TARGET_DIR']
                        targets = expectations['workloads'].setdefault(workload, {'targets': {}})['targets']
                        dirty_audit.validate_run(report, expectations['rustc'], expectations['uv_package'], targets.get(target))
                        observed = dirty_audit.target_expectation(report)
                        known = amendment['known_test_namespaces'].get(target)
                        if known is not None and observed['workspace_namespaces'] != [known]:
                            raise ValueError('observed workspace namespace differs from the predeclared target binding')
                        if targets:
                            dirty_audit.validate_work_equivalence(report, next(iter(targets.values())))
                        executed = dirty_audit.validate_no_tests(report, trace.read_text())
                        if executed.count(expectations['rustc']) != len(report['compiler_commands']):
                            raise ValueError('execve rustc count differs from the verbose compiler command count')
                        if metric == 'ir':
                            callgrind = work_output / f'callgrind-measurement-{pair}-{variant}.out'
                            if paired.read_callgrind_summary(callgrind) <= 0:
                                raise ValueError('diagnostic did not produce valid Cargo-only Ir')
                        if target not in targets:
                            targets[target] = observed
                        dirty_guard.check(guard_path, active_state)
                        manifest['runs'].append({'workload': workload, 'assignment': assignment, 'metric': metric, 'variant': variant, 'command': command, 'stdout': str(stdout), 'stderr': str(stderr), 'execve': str(trace), 'successful_execve_paths': executed, 'test_executables_run': [], 'compiler_report': report})
                        write(output / 'manifest.json', manifest)
                        print(f'{now()} verified {label}: {len(report["compiler_commands"])} uv rustc invocations; no tests executed', flush=True)
                run(cleanup, environment, output / 'logs' / f'{workload}-{assignment}-restore.stdout', output / 'logs' / f'{workload}-{assignment}-restore.stderr')
                active_state = None
                cleanup = None
        dirty_guard.check(guard_path, restored=True)
        if (ROOT / 'uv/crates/uv/src/lib.rs').read_bytes() != original:
            raise ValueError('preflight failed to restore original source bytes')
        for path, expected in frozen['asset_sha256'].items():
            if paired.sha256(path) != expected:
                raise ValueError(f'frozen asset changed during diagnostics: {path}')
        expected_path = ROOT / 'metadata/diagnostic-expectations.json'
        if expected_path.exists():
            raise ValueError('diagnostic expectations must be frozen at a new path')
        write(expected_path, expectations)
        manifest.update({'state': 'complete', 'finished_at': now(), 'source_restored': True, 'expectations_sha256': paired.sha256(expected_path)})
        write(output / 'manifest.json', manifest)
    except BaseException as error:
        manifest.update({'state': 'failed', 'finished_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        if active_state is not None and cleanup is not None:
            result = subprocess.run(cleanup, cwd=ROOT / 'uv', capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
            (output / 'logs/failure-restore.stdout').write_text(result.stdout)
            (output / 'logs/failure-restore.stderr').write_text(result.stderr)
            manifest['failure_restore_returncode'] = result.returncode
        write(output / 'manifest.json', manifest)
        raise
    finally:
        lock.close()
    print(json.dumps({'state': manifest['state'], 'runs': len(manifest['runs']), 'expectations_sha256': manifest['expectations_sha256']}))


if __name__ == '__main__':
    main()
