#!/usr/bin/env python3
"""Preserve v2 and bind preflight to each unchanged config's fixture hooks."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'work/benchmark/freeze_cohort_v3.py'
    guard = dirty_guard.check(ROOT / 'work/benchmark/source-guard.json', restored=True)
    previous_path = ROOT / 'metadata/frozen-cohort-v2.json'
    assert sha(previous_path) == '466b6673f99462a133023a814f4d237f25ea5b6f5c0c735dfe2b8812f1c5b119'
    previous = json.loads(previous_path.read_text())
    for path, expected in previous['asset_sha256'].items():
        assert sha(path) == expected, path
    amendment_path = ROOT / 'work/benchmark/protocol-amendment-preflight-fixture.json'
    amendment = json.loads(amendment_path.read_text())
    assert amendment['comparative_samples_run'] == 0
    assert amendment['protocol_sha256'] == sha(ROOT / 'work/benchmark/protocol.json')
    assert amendment['previous_cohort_sha256'] == sha(previous_path)
    for name, expected in amendment['helper_sha256'].items():
        assert sha(ROOT / 'work/benchmark' / name) == expected, name
    for name, expected in amendment['unchanged_helper_sha256'].items():
        assert sha(ROOT / 'work/benchmark' / name) == expected, name
    stopped = ROOT / 'diagnostics/host2-preflight-03'
    stopped_manifest = json.loads((stopped / 'manifest.json').read_text())
    assert stopped_manifest['state'] == 'failed' and stopped_manifest['failure_restore_returncode'] == 0
    assert len(stopped_manifest['runs']) == 4
    assert {(row['assignment'], row['metric'], row['variant']) for row in stopped_manifest['runs']} == {
        ('forward', metric, variant) for metric in ('native', 'ir') for variant in ('baseline', 'candidate')}
    failure_seal = ROOT / 'metadata/preflight-v2-stopped-seal.json'
    write(failure_seal, {
        'reason': 'The ownership guard rejected a reverse target against a forward fixture before Cargo; cleanup succeeded.',
        'files': {str(path.relative_to(ROOT)): {'sha256': sha(path), 'bytes': path.stat().st_size}
                  for path in sorted(stopped.rglob('*')) if path.is_file()},
    })
    bindings = []
    for path, expected in previous['prepared_config_sha256'].items():
        assert sha(path) == expected, path
        config = json.loads(Path(path).read_text())
        prepare, cleanup = config['prepare_command'], config['cleanup_command']
        assert prepare.count('--state') == cleanup.count('--state') == 1
        state = prepare[prepare.index('--state') + 1]
        assert cleanup[cleanup.index('--state') + 1] == state
        spec = guard['states'][state]
        assert spec['targets'] == {name: row['CARGO_TARGET_DIR'] for name, row in config['variant_env'].items()}
        assert spec['shared_build_dir'] == config['env']['CARGO_BUILD_BUILD_DIR']
        assert spec['workload'] in ('test', 'check')
        dirty_guard.check(ROOT / 'work/benchmark/source-guard.json', Path(state), restored=True)
        bindings.append({'config': path, 'sha256': expected, 'state': state, **spec})
    assert len(bindings) == 6
    binding_path = ROOT / 'metadata/preflight-fixture-bindings.json'
    write(binding_path, {'valid': True, 'source_restored': True, 'configs': bindings})
    extra = {previous_path, amendment_path, failure_seal, binding_path,
             ROOT / 'metadata/preflight-fixture-transfer.json',
             ROOT / 'work/benchmark/preflight-fixture-helper.diff',
             stopped / 'manifest.json', stopped / 'logs/failure-restore.stdout',
             stopped / 'logs/failure-restore.stderr'}
    extra.update(ROOT / 'work/benchmark' / name for name in amendment['helper_sha256'])
    output_path = ROOT / 'metadata/frozen-cohort-v3.json'
    assets = {Path(path) for path in previous['asset_sha256']} | extra
    prepared = {}
    for old_path, expected in previous['prepared_config_sha256'].items():
        path = Path(old_path)
        assert sha(path) == expected
        config = json.loads(path.read_text())
        records = set(config['record_files']) | {str(item) for item in extra} | {str(output_path)}
        config['record_files'] = sorted(records)
        new_path = path.with_name(path.name.removesuffix('.prepared-v2.json') + '.prepared-v3.json')
        write(new_path, config)
        prepared[str(new_path)] = sha(new_path)
        assets.add(new_path)
        assets.update(Path(item) for item in records if item not in {
            str(output_path), str(ROOT / 'metadata/diagnostic-expectations.json')})
    assert len(prepared) == 6
    for path in assets:
        assert path.is_file(), path
    frozen = {**previous,
              'frozen_at': datetime.now(timezone.utc).isoformat(),
              'state': 'Exact configured fixture hooks frozen before rerunning the full preflight; no comparative samples.',
              'previous_cohort_sha256': sha(previous_path),
              'preflight_fixture_amendment_sha256': sha(amendment_path),
              'prepared_config_sha256': prepared,
              'asset_sha256': {str(path): sha(path) for path in sorted(assets)}}
    write(output_path, frozen)
    print(json.dumps({'cohort_sha256': sha(output_path), 'variant_sha256': frozen['variant_sha256'],
                      'prepared_config_sha256': prepared, 'source_restored': True}, indent=2))


if __name__ == '__main__':
    main()
