#!/usr/bin/env python3
"""Run both frozen dirty workloads serially; inspect effects only after both finish."""
import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import traceback

import dirty_audit_v2 as dirty_audit
import dirty_guard
import paired

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')


def write(path, value):
    paired.atomic_json(path, value)


def now():
    return datetime.now(timezone.utc).isoformat()


def gate(statistics, instruction, acceptance, pairs):
    ratio = 'ratio' if instruction else 'speedup'
    reduction = 'count_reduction' if instruction else 'time_reduction'
    return (
        statistics['pairs'] == pairs
        and statistics['paired_geometric_mean_' + reduction] >= acceptance['minimum_geometric_reduction']
        and statistics['bootstrap_' + ratio + '_interval'][0] > 1
        and statistics['exact_two_sided_sign_p'] <= acceptance['exact_two_sided_sign_p_maximum']
        and set(statistics['order']) == {'AB', 'BA'}
        and all(row['geometric_mean_' + ratio] > 1 for row in statistics['order'].values())
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('group', choices=('ir-exploratory', 'ir-confirmation', 'native-confirmation'))
    args = parser.parse_args()
    instruction = args.group.startswith('ir-')
    phase_name = args.group.split('-', 1)[1]
    protocol = json.loads((ROOT / 'work/benchmark/protocol.json').read_text())
    final = json.loads((ROOT / 'configs-finalized.json').read_text())
    previous = {'ir-confirmation': 'ir-exploratory', 'native-confirmation': 'ir-confirmation'}.get(args.group)
    if previous is not None:
        prior = json.loads((ROOT / 'results' / f'{previous}.json').read_text())
        if prior['state'] != 'complete' or not prior['primary_passes']:
            raise ValueError('predeclared primary selection gate did not pass')
    for path, expected in final['asset_sha256'].items():
        if paired.sha256(path) != expected:
            raise ValueError(f'frozen input changed: {path}')
    guard = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.check(guard, restored=True)
    summary_path = ROOT / 'results' / f'{args.group}.json'
    if summary_path.exists():
        raise ValueError('group already attempted; preserve it and review before any replacement')
    summary = {'state': 'running', 'started_at': now(), 'group': args.group, 'protocol_sha256': paired.sha256(ROOT / 'work/benchmark/protocol.json'), 'config_manifest_sha256': paired.sha256(ROOT / 'configs-finalized.json'), 'completed_workloads': []}
    write(summary_path, summary)
    lock = (ROOT / 'experiment.lock').open('a')
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        selected = []
        for workload in ('test', 'check'):
            phase = next(row for row in protocol['phases'] if row['workload'] == workload and row['phase'] == phase_name and (row['metric'] == 'cargo_ir') == instruction)
            name = f'{workload}-{args.group}'
            config = ROOT / 'configs' / f'{name}.json'
            result = ROOT / 'results' / name
            assert paired.sha256(config) == final['config_sha256'][name]
            assert [list(order) for order in paired.make_plan(phase['pairs'], phase['seed'])] == phase['measurement_plan']
            assert [list(order) for order in paired.make_plan(phase['warmup_pairs'], phase['seed'] ^ 0x5A17)] == phase['warmup_plan']
            occupancy = subprocess.check_output(['ps', '-eo', 'pid,comm,pcpu,pmem', '--sort=-pcpu'], text=True)
            (ROOT / 'metadata' / f'{name}-occupancy.txt').write_text(occupancy)
            if any(row.split()[1] in {'cargo', 'rustc', 'cc1', 'cc1plus', 'clang', 'clang++', 'ld.lld', 'callgrind-amd64'} for row in occupancy.splitlines()[1:]):
                raise ValueError('another compiler/build/profiler process is active before the batch')
            print(f'{now()} starting {name}: {phase["pairs"]} pairs, {phase["warmup_pairs"]} warmup pairs', flush=True)
            command = ['python3', str(ROOT / 'work/benchmark/paired.py'), 'run', '--config', str(config), '--output', str(result), '--phase', phase_name, '--pairs', str(phase['pairs']), '--warmup-pairs', str(phase['warmup_pairs']), '--seed', str(phase['seed'])]
            with (ROOT / 'logs' / f'{name}.run.stdout').open('xb') as out, (ROOT / 'logs' / f'{name}.run.stderr').open('xb') as err:
                process = subprocess.run(command, env=environment, stdout=out, stderr=err)
            if process.returncode:
                raise RuntimeError(f'{name} failed; all output and cleanup evidence retained')
            audit = dirty_audit.verify_batch(guard, ROOT / 'fixtures' / name, result, ROOT / 'metadata/diagnostic-expectations.json', workload)
            manifest = json.loads((result / 'manifest.json').read_text())
            assert manifest['plans'] == {'measurement': phase['measurement_plan'], 'warmup': phase['warmup_plan']}
            assert manifest['sample_count'] == 2 * (phase['pairs'] + phase['warmup_pairs'])
            assert len(audit['samples']) == manifest['sample_count']
            summary['completed_workloads'].append(workload)
            write(summary_path, summary)
            selected.append((workload, phase, result))
            print(f'{now()} {name} complete and source/compiler work verified; effects still uninspected', flush=True)
        summary['results'] = {}
        for workload, phase, result in selected:
            command = ['python3', str(ROOT / 'work/benchmark/paired.py'), 'analyze', str(result), '--confidence', str(protocol['acceptance']['confidence']), '--resamples', str(protocol['acceptance']['bootstrap_resamples']), '--seed', str(protocol['acceptance']['bootstrap_seed']), '--minimum-pairs', str(phase['pairs']), '--minimum-improvement', str(protocol['acceptance']['minimum_geometric_reduction'])]
            with (ROOT / 'logs' / f'{workload}-{args.group}.analysis.stdout').open('xb') as out, (ROOT / 'logs' / f'{workload}-{args.group}.analysis.stderr').open('xb') as err:
                subprocess.run(command, env=environment, stdout=out, stderr=err, check=True)
            analysis = json.loads((result / 'analysis.json').read_text())
            statistics = analysis['metrics']['cargo_ir']['statistics'] if instruction else analysis
            summary['results'][workload] = {'passes': gate(statistics, instruction, protocol['acceptance'], phase['pairs']), 'primary': phase['primary'], 'statistics': statistics, 'analysis_sha256': paired.sha256(result / 'analysis.json'), 'compiler_audit_sha256': paired.sha256(result / 'compiler-audit.json')}
            sealed = {str(path.relative_to(result)): paired.sha256(path) for path in sorted(result.rglob('*')) if path.is_file()}
            write(result / 'seal.json', sealed)
        dirty_guard.check(guard, restored=True)
        for path, expected in final['asset_sha256'].items():
            if paired.sha256(path) != expected:
                raise ValueError(f'frozen input changed during the group: {path}')
        summary.update({'state': 'complete', 'finished_at': now(), 'primary_passes': summary['results']['test']['passes'], 'secondary_passes': summary['results']['check']['passes'], 'source_restored': True})
    except BaseException as error:
        summary.update({'state': 'failed', 'finished_at': now(), 'error': repr(error), 'traceback': traceback.format_exc()})
        raise
    finally:
        write(summary_path, summary)
        lock.close()
    print(json.dumps({'state': summary['state'], 'group': args.group, 'primary_passes': summary['primary_passes'], 'secondary_passes': summary['secondary_passes']}))


if __name__ == '__main__':
    main()
