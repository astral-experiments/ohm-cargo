#!/usr/bin/env python3
"""Add target-specific execution auditing without changing any experiment setting."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'work/benchmark/freeze_cohort_v2.py'
    dirty_guard.check(ROOT / 'work/benchmark/source-guard.json', restored=True)
    original_path = ROOT / 'metadata/frozen-cohort.json'
    assert sha(original_path) == '7790209643a7602a1707b32a9fdd5ff40c5cc64744bac6179da6d9d35b51220a'
    original = json.loads(original_path.read_text())
    for path, expected in original['asset_sha256'].items():
        assert sha(path) == expected, path
    amendment_path = ROOT / 'work/benchmark/protocol-amendment-target-bindings.json'
    amendment = json.loads(amendment_path.read_text())
    assert amendment['comparative_samples_run'] == 0
    assert amendment['protocol_sha256'] == sha(ROOT / 'work/benchmark/protocol.json')
    assert amendment['original_cohort_sha256'] == sha(original_path)
    for name, expected in amendment['helper_sha256'].items():
        assert sha(ROOT / 'work/benchmark' / name) == expected, name
    tests = ROOT / 'logs/helper-tests-04.stderr'
    assert 'Ran 29 tests' in tests.read_text() and tests.read_text().rstrip().endswith('OK')
    retained_audit = ROOT / 'metadata/retained-preflight-v2-audit.json'
    assert json.loads(retained_audit.read_text())['valid']
    failures = [ROOT / 'diagnostics/host2-preflight-01', ROOT / 'diagnostics/host2-preflight-02']
    first = json.loads((failures[0] / 'manifest.json').read_text())
    second = json.loads((failures[1] / 'manifest.json').read_text())
    assert first['state'] == 'failed-before-Cargo'
    assert second['state'] == 'failed' and second['failure_restore_returncode'] == 0
    failure_seal = ROOT / 'metadata/preflight-failures-seal.json'
    write(failure_seal, {
        'reason': 'Both stopped attempts retained before any comparative samples; original source is restored.',
        'files': {str(path.relative_to(ROOT)): {'sha256': sha(path), 'bytes': path.stat().st_size}
                  for directory in failures for path in sorted(directory.rglob('*')) if path.is_file()},
    })
    extra = {original_path, amendment_path, failure_seal, tests, retained_audit,
             ROOT / 'logs/helper-tests-04.stdout', ROOT / 'metadata/target-bindings-transfer.json',
             ROOT / 'work/benchmark/target-bindings-helper.diff',
             ROOT / 'work/benchmark/target-bindings-layout-source.rs', Path('/usr/bin/python3')}
    extra.update(ROOT / 'work/benchmark' / name for name in amendment['helper_sha256'])
    extra.update(directory / 'manifest.json' for directory in failures)
    extra.update(failures[1] / 'logs' / name for name in ('failure-restore.stdout', 'failure-restore.stderr'))
    output_path = ROOT / 'metadata/frozen-cohort-v2.json'
    assets = {Path(path) for path in original['asset_sha256']} | extra
    prepared = {}
    for old_path, expected in original['prepared_config_sha256'].items():
        path = Path(old_path)
        assert sha(path) == expected
        config = json.loads(path.read_text())
        records = set(config['record_files']) | {str(item) for item in extra} | {str(output_path)}
        config['record_files'] = sorted(records)
        new_path = path.with_name(path.name.removesuffix('.prepared.json') + '.prepared-v2.json')
        write(new_path, config)
        prepared[str(new_path)] = sha(new_path)
        assets.add(new_path)
        assets.update(Path(item) for item in records if item not in {
            str(output_path), str(ROOT / 'metadata/diagnostic-expectations.json')})
    assert len(prepared) == 6
    for path in assets:
        assert path.is_file(), path
    frozen = {**original,
              'frozen_at': datetime.now(timezone.utc).isoformat(),
              'state': 'Target-bound execution audit frozen before both-assignment preflight; no comparative samples.',
              'original_cohort_sha256': sha(original_path),
              'target_binding_amendment_sha256': sha(amendment_path),
              'prepared_config_sha256': prepared,
              'asset_sha256': {str(path): sha(path) for path in sorted(assets)}}
    write(output_path, frozen)
    print(json.dumps({'cohort_sha256': sha(output_path), 'variant_sha256': frozen['variant_sha256'],
                      'prepared_config_sha256': prepared, 'source_restored': True}, indent=2))


if __name__ == '__main__':
    main()
