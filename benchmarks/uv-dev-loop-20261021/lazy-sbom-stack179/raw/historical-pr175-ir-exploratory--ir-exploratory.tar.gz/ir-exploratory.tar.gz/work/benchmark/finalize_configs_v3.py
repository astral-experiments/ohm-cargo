#!/usr/bin/env python3
"""Seal successful diagnostics and freeze all six prospective measurement configs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'work/benchmark/finalize_configs_v3.py'
    dirty_guard.check(ROOT / 'work/benchmark/source-guard.json', restored=True)
    cohort_path = ROOT / 'metadata/frozen-cohort-v3.json'
    cohort = json.loads(cohort_path.read_text())
    for path, expected in cohort['asset_sha256'].items():
        assert sha(path) == expected, path
    expected_path = ROOT / 'metadata/diagnostic-expectations.json'
    expected = json.loads(expected_path.read_text())
    diagnostics = Path(expected['diagnostic_directory'])
    assert diagnostics.is_relative_to(ROOT / 'diagnostics') and diagnostics.resolve() == diagnostics
    manifest = json.loads((diagnostics / 'manifest.json').read_text())
    assert manifest['state'] == 'complete' and manifest['source_restored']
    assert manifest['variant_sha256'] == cohort['variant_sha256']
    assert manifest['expectations_sha256'] == sha(expected_path)
    assert {(row['workload'], row['assignment'], row['metric'], row['variant']) for row in manifest['runs']} == {
        (workload, assignment, metric, variant) for workload in ('test', 'check')
        for assignment in ('forward', 'reverse')
        for metric in ('native', 'ir') for variant in ('baseline', 'candidate')}
    assert len(manifest['runs']) == 16
    seal_path = ROOT / 'metadata/diagnostic-seal.json'
    seal = {'diagnostic_directory': str(diagnostics), 'files': {
        str(path.relative_to(diagnostics)): {'sha256': sha(path), 'bytes': path.stat().st_size}
        for path in sorted(diagnostics.rglob('*')) if path.is_file()}}
    write(seal_path, seal)
    assets = {Path(path) for path in cohort['asset_sha256']}
    assets.update((cohort_path, expected_path, seal_path, diagnostics / 'manifest.json'))
    configs = {}
    for prepared in sorted((ROOT / 'configs').glob('*.prepared-v3.json')):
        assert sha(prepared) == cohort['prepared_config_sha256'][str(prepared)]
        config = json.loads(prepared.read_text())
        assert config.pop('pending_frozen_assets') == ['successful matched native/instrumented diagnostic expectations']
        records = set(config['record_files']) | {str(seal_path), str(diagnostics / 'manifest.json')}
        config['record_files'] = sorted(records)
        for path in records:
            assert Path(path).is_file(), path
        name = prepared.name.removesuffix('.prepared-v3.json')
        path = prepared.with_name(name + '.json')
        write(path, config)
        configs[name] = sha(path)
        assets.add(path)
        assets.update(Path(record) for record in records)
    assert len(configs) == 6
    final = {
        'frozen_at': datetime.now(timezone.utc).isoformat(),
        'state': 'All six configs and gates frozen; full matched preflight passed; no comparative samples yet',
        'cohort': cohort['cohort'], 'variant_sha256': cohort['variant_sha256'],
        'config_sha256': configs, 'asset_sha256': {str(path): sha(path) for path in sorted(assets)},
        'protocol_sha256': sha(ROOT / 'work/benchmark/protocol.json'),
        'protocol_amendment_sha256': sha(ROOT / 'work/benchmark/protocol-amendment-host2.json'),
        'preflight_fixture_amendment_sha256': sha(ROOT / 'work/benchmark/protocol-amendment-preflight-fixture.json'),
        'target_binding_amendment_sha256': sha(ROOT / 'work/benchmark/protocol-amendment-target-bindings.json'),
        'diagnostic_expectations_sha256': sha(expected_path),
        'diagnostic_seal_sha256': sha(seal_path), 'source_restored': True,
    }
    write(ROOT / 'configs-finalized.json', final)
    print(json.dumps({key: final[key] for key in ('state', 'variant_sha256', 'config_sha256',
                                                 'diagnostic_expectations_sha256', 'source_restored')}, indent=2))


if __name__ == '__main__':
    main()
