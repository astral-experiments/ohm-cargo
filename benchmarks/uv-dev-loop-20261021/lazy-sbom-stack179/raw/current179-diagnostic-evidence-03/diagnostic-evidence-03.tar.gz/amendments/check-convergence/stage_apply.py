"""Stage the explicitly reviewed current-only overlay and run its metadata reseal."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--manifest-sha256', required=True)
args = parser.parse_args()
manifest_bytes = (HERE / 'manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == args.manifest_sha256
manifest = json.loads(manifest_bytes)
payload = {}
for name, record in manifest['files'].items():
    data = (HERE / name).read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
    payload[name] = data
payload['manifest.json'] = manifest_bytes
expected = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in payload.items()}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, data in sorted(payload.items()):
        item = tarfile.TarInfo(name)
        item.mode = 0o644
        item.size = len(data)
        archive.addfile(item, io.BytesIO(data))
remote = r'''
from pathlib import Path
import hashlib, json, os, socket, subprocess, sys, tarfile
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
here = root / 'amendments/check-convergence'
expected = json.loads(sys.argv[1])
assert socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000
assert root.resolve() == root and root.stat().st_uid == os.getuid()
assert json.loads((root / 'ownership.json').read_text()) == {
    'root': str(root), 'uid': os.getuid(), 'cohort': 'current179-lazy-sbom'}
assert not here.exists()
here.parent.mkdir(exist_ok=True)
assert here.parent.resolve() == here.parent and here.parent.stat().st_uid == os.getuid()
here.mkdir(mode=0o700)
seen = set()
with tarfile.open(fileobj=sys.stdin.buffer, mode='r|') as archive:
    for item in archive:
        assert item.isfile() and item.name in expected and item.name not in seen
        assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        data = archive.extractfile(item).read()
        row = expected[item.name]
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        path = here / item.name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
        path.chmod(0o644)
        seen.add(item.name)
assert seen == set(expected)
with (here / 'apply.stdout').open('xb') as out, (here / 'apply.stderr').open('xb') as err:
    result = subprocess.run(['env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
                             'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
                             str(here / 'apply_overlay.py'), expected['manifest.json']['sha256']],
                            stdout=out, stderr=err)
print(json.dumps({'returncode': result.returncode, 'manifest_sha256': expected['manifest.json']['sha256'],
                  'stdout': (here / 'apply.stdout').read_text(), 'stderr': (here / 'apply.stderr').read_text()}))
sys.exit(result.returncode)
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
                         '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-c',
                         remote, json.dumps(expected, separators=(',', ':'))],
                        input=buffer.getvalue(), capture_output=True)
for suffix, data in (('stdout', result.stdout), ('stderr', result.stderr)):
    with (HERE / ('apply-transfer.' + suffix)).open('xb') as stream:
        stream.write(data)
if result.returncode:
    raise SystemExit((result.stderr + result.stdout).decode(errors='replace'))
record = json.loads(result.stdout)
with (HERE / 'apply-transfer.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(record['stdout'])
