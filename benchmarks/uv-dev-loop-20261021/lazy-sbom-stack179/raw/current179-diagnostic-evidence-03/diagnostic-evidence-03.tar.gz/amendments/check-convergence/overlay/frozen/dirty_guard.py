#!/usr/bin/env python3
"""Add task ownership and complete-checkout checks around the frozen dirty fixture."""
import argparse
import functools
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

import dirty_fixture
import check_convergence


def sha(data):
    return hashlib.sha256(data).hexdigest()


def owned(root, path, exists=False):
    root, path = Path(root).absolute(), Path(path).absolute()
    if root.resolve() != root or path.resolve() != path:
        raise ValueError('owned paths must not contain symlinks')
    if path != root and root not in path.parents:
        raise ValueError('path is outside the owned benchmark root')
    if exists and not path.exists():
        raise ValueError('required owned path is missing')
    for node in (path, *path.parents):
        if node.exists() and node.stat().st_uid != os.getuid():
            raise ValueError('owned path has unexpected owner')
        if node == root:
            break
    return path


def source_inventory(workspace, mutable):
    workspace, mutable = Path(workspace), Path(mutable)
    revision = subprocess.check_output(['git', '-C', str(workspace), 'rev-parse', 'HEAD'], text=True).strip()
    tracked = subprocess.check_output(['git', '-C', str(workspace), 'ls-files', '-z']).split(b'\0')
    rows = []
    for raw in sorted(name for name in tracked if name):
        name = os.fsdecode(raw)
        path = workspace / name
        if path == mutable:
            continue
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            content, kind = os.fsencode(os.readlink(path)), 'symlink'
        elif stat.S_ISREG(info.st_mode):
            content, kind = path.read_bytes(), 'file'
        else:
            raise ValueError('unexpected tracked source file kind')
        rows.append({'path': name, 'kind': kind, 'mode': stat.S_IMODE(info.st_mode), 'sha256': sha(content)})
    serialized = (json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
    return {'revision': revision, 'tracked_immutable_files': len(rows), 'sha256': sha(serialized)}, rows


def create(root, workspace, source, commands, states, output):
    root = owned(root, root, True)
    workspace = owned(root, workspace, True)
    source = owned(root, source, True)
    if not source.is_file() or source.stat().st_nlink != 1:
        raise ValueError('mutable source must be an independent regular file')
    if subprocess.check_output(['git', '-C', str(workspace), 'status', '--porcelain', '--untracked-files=all']):
        raise ValueError('source checkout must be clean before freezing the guard')
    identity, rows = source_inventory(workspace, source)
    if identity['revision'] != '3d82a6ad5a7eab8c68236553b7846517767c4b61':
        raise ValueError('uv checkout is not pinned')
    record = {
        'schema_version': 1, 'root': str(root), 'workspace': str(workspace),
        'source': str(source), 'source_sha256': sha(source.read_bytes()),
        'source_mode': stat.S_IMODE(source.stat().st_mode),
        'source_identity': identity, 'source_inventory': rows,
        'commands': commands, 'states': states,
    }
    output = owned(root, output)
    if output.exists():
        raise ValueError('guard must be frozen at a new path')
    output.write_text(json.dumps(record, indent=2) + '\n')
    return record


def check(path, state=None, restored=False):
    path = Path(path).absolute()
    guard = json.loads(path.read_text())
    root = owned(guard['root'], guard['root'], True)
    owned(root, path, True)
    workspace = owned(root, guard['workspace'], True)
    source = owned(root, guard['source'], True)
    if not source.is_file() or source.stat().st_nlink != 1:
        raise ValueError('mutable source is no longer an independent regular file')
    if stat.S_IMODE(source.stat().st_mode) != guard['source_mode']:
        raise ValueError('mutable source mode changed')
    identity, _ = source_inventory(workspace, source)
    if identity != guard['source_identity']:
        raise ValueError('another tracked uv source file or revision changed')
    status = subprocess.check_output(['git', '-C', str(workspace), 'status', '--porcelain', '--untracked-files=all'], text=True).splitlines()
    expected_modified = ' M ' + str(source.relative_to(workspace))
    if any(line != expected_modified for line in status):
        raise ValueError('unexpected staged, untracked or modified uv source')
    if restored and (status or sha(source.read_bytes()) != guard['source_sha256']):
        raise ValueError('uv source was not restored exactly')
    if state is not None:
        state = owned(root, state, True)
        specification = guard['states'].get(str(state))
        if specification is None:
            raise ValueError('fixture state is not frozen in this guard')
        for filename in ('manifest.json', 'original.bin', 'state.json', 'lock', 'journal.jsonl'):
            owned(root, state / filename, filename not in ('lock',))
        manifest = json.loads((state / 'manifest.json').read_text())
        if manifest['source'] != guard['source'] or manifest['workspace'] != guard['workspace']:
            raise ValueError('fixture source/workspace differs from guard')
        if manifest['source_sha256'] != guard['source_sha256'] or manifest['source_mode'] != guard['source_mode']:
            raise ValueError('fixture original identity differs from guard')
        if manifest['targets'] != specification['targets'] or manifest['shared_build_dir'] != specification['shared_build_dir']:
            raise ValueError('fixture target/cache assignment differs from guard')
        for target in manifest['targets'].values():
            owned(root, target)
        owned(root, manifest['shared_build_dir'])
        if sha((state / 'original.bin').read_bytes()) != guard['source_sha256']:
            raise ValueError('saved original source changed')
    return guard


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('prepare', 'restore', 'check'))
    parser.add_argument('--guard', required=True)
    parser.add_argument('--state')
    parser.add_argument('--batch')
    parser.add_argument('--stage', choices=('warmup', 'measurement'))
    parser.add_argument('--pair', type=int)
    parser.add_argument('--variant', choices=('baseline', 'candidate'))
    parser.add_argument('--restored', action='store_true')
    arguments = sys.argv[1:]
    command = []
    if '--' in arguments:
        separator = arguments.index('--')
        arguments, command = arguments[:separator], arguments[separator + 1:]
    args = parser.parse_args(arguments)
    guard = check(args.guard, args.state, args.restored)
    if args.operation == 'prepare':
        if command not in guard['commands'].values():
            raise ValueError('native prepare command differs from frozen commands')
        owned(guard['root'], args.batch, True)
        warm_runner = None
        if command == guard['commands']['check']:
            directory = check_convergence.proof_directory(args.batch, args.stage, args.pair, args.variant)
            owned(guard['root'], directory)
            warm_runner = functools.partial(check_convergence.run, directory=directory,
                                            source=Path(guard['source']), identity={
                                                'batch': str(Path(args.batch).resolve()), 'stage': args.stage,
                                                'pair': args.pair, 'variant': args.variant})
        result = dirty_fixture.prepare(args.state, args.batch, args.stage, args.pair, args.variant, command,
                                       warm_runner=warm_runner)
        if warm_runner is not None:
            check_convergence.verify_record(result)
        check(args.guard, args.state)
    elif args.operation == 'restore':
        result = dirty_fixture.restore(args.state)
        check(args.guard, args.state, restored=True)
    else:
        result = {'valid': True, 'source_identity': guard['source_identity'], 'restored_required': args.restored}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
