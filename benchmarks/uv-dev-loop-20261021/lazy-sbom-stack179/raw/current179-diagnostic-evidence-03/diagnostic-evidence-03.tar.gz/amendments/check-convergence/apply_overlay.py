"""Apply only the reviewed preparation overlay, archive inputs, and reseal metadata.

This runs Python helper tests but never Cargo, a producer, or a benchmark.
Existing untimed prerequisites remain in their task-owned target/shared paths.
"""
from datetime import datetime, timezone
import hashlib
import fcntl
import json
import os
from pathlib import Path
import shutil
import socket
import stat
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
HERE = ROOT / 'amendments/check-convergence'
OLD_COHORT = '0d524bb20f7a1a41381c64e7991cb6a73935f42824d9768e20cc0b0bf0a4df9f'
PROTOCOL = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def replace(path, data):
    assert path.is_relative_to(ROOT) and path.parent.resolve() == path.parent
    mode = 0o644
    if path.exists():
        assert path.resolve() == path and path.is_file() and path.stat().st_uid == os.getuid()
        mode = stat.S_IMODE(path.stat().st_mode)
    temporary = path.with_name(path.name + '.check-convergence-update')
    with temporary.open('xb') as stream:
        stream.write(data)
    temporary.chmod(mode)
    os.replace(temporary, path)


def create(path, value):
    assert not path.exists()
    with path.open('xb') as stream:
        stream.write(encoded(value))


def main():
    assert Path(__file__).resolve() == HERE / 'apply_overlay.py'
    assert socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000
    assert ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid()
    assert json.loads((ROOT / 'ownership.json').read_text()) == {
        'root': str(ROOT), 'uid': os.getuid(), 'cohort': 'current179-lazy-sbom'}
    experiment_lock = (ROOT / 'experiment.lock').open('r')
    fcntl.flock(experiment_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert len(sys.argv) == 2 and sha(HERE / 'manifest.json') == sys.argv[1]
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for relative, row in manifest['files'].items():
        path = HERE / relative
        assert path.resolve() == path and path.is_relative_to(HERE)
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], relative
    amendment = json.loads((HERE / 'protocol-amendment-check-convergence.json').read_text())
    assert amendment['original_protocol_sha256'] == PROTOCOL
    cohort_path = ROOT / 'metadata/frozen-cohort.json'
    assert sha(cohort_path) == OLD_COHORT
    cohort = json.loads(cohort_path.read_text())
    for path, digest in cohort['asset_sha256'].items():
        assert sha(path) == digest, path
    assert sha(ROOT / 'work/benchmark/protocol.json') == PROTOCOL
    failed_path = ROOT / 'diagnostics/current179-preflight-02/manifest.json'
    assert sha(failed_path) == amendment['failed_attempt_manifest_sha256']
    failed = json.loads(failed_path.read_text())
    assert failed['state'] == 'failed' and len(failed['runs']) == 8
    assert all(row['workload'] == 'test' for row in failed['runs'])
    probe_path = ROOT / 'diagnostics/current179-check-convergence-01/manifest.json'
    assert sha(probe_path) == amendment['convergence_probe_manifest_sha256']
    convergence = json.loads(probe_path.read_text())
    assert convergence['state'] == 'complete'
    assert [(row['returncode'], row['rustc_execve_count']) for row in convergence['runs']] == [(0, 1), (0, 0)]
    assert failed['failure_restore_returncode'] == 0
    assert not (ROOT / 'metadata/diagnostic-expectations.json').exists()
    assert not (ROOT / 'configs-finalized.json').exists()
    assert not list((ROOT / 'results').rglob('*'))
    probe = subprocess.Popen(['ps', '-eo', 'pid=,pcpu=,comm='], stdout=subprocess.PIPE, text=True)
    text, _ = probe.communicate()
    assert probe.returncode == 0
    heavy = []
    for line in text.splitlines():
        pid, cpu, name = line.split(None, 2)
        if int(pid) not in (os.getpid(), probe.pid) and (
            name in {'cargo', 'rustc', 'clang', 'clang++', 'cc1', 'cc1plus',
                     'ld', 'ld.lld', 'valgrind', 'callgrind-amd64'} or float(cpu) > 40
        ):
            heavy.append({'pid': int(pid), 'comm': name, 'cpu': float(cpu)})
    assert not heavy, heavy
    sys.path.insert(0, str(ROOT / 'work/benchmark'))
    import dirty_guard
    import input_catalog
    guard = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.check(guard, restored=True)
    input_catalog.check(ROOT / 'metadata/input-catalog.json')

    # Preserve all small setup/control/state files and the complete failed run.
    # Binary/compiler/profiler inputs are unchanged and remain hash-bound below.
    before = HERE / 'before'
    before.mkdir()
    selected = set()
    for relative in ('work/benchmark', 'metadata', 'configs', 'fixtures', 'logs',
                     'diagnostics'):
        selected.update(path for path in (ROOT / relative).rglob('*') if path.is_file())
    for relative in ('ownership.json', 'setup.json', 'stage-assets.json', 'matched-pair.json',
                     'review-seal.json', 'setup_remote.py', 'prepare_configs.py', 'setup.log',
                     'run-setup.sh', 'uv/crates/uv/src/lib.rs'):
        path = ROOT / relative
        if path.exists():
            selected.add(path)
    copied = {}
    for path in sorted(selected):
        assert path.resolve() == path and path.stat().st_uid == os.getuid()
        relative = path.relative_to(ROOT)
        destination = before / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        assert not destination.exists()
        source_stat = path.stat()
        digest = sha(path)
        shutil.copy2(path, destination)
        assert sha(destination) == digest and sha(path) == digest
        assert destination.stat().st_mtime_ns == source_stat.st_mtime_ns
        assert stat.S_IMODE(destination.stat().st_mode) == stat.S_IMODE(source_stat.st_mode)
        copied[str(relative)] = {'sha256': digest, 'bytes': source_stat.st_size,
                                 'mtime_ns': source_stat.st_mtime_ns,
                                 'mode': stat.S_IMODE(source_stat.st_mode)}
    create(before / 'manifest.json', {'original_cohort_sha256': OLD_COHORT, 'files': copied})
    for path, digest in cohort['asset_sha256'].items():
        assert sha(path) == digest, path
    old_setup_sha = sha(ROOT / 'setup.json')
    stage_assets = json.loads((ROOT / 'stage-assets.json').read_text())
    changed = set()
    for relative, row in amendment['overlay'].items():
        destination = ROOT / (relative.replace('frozen/', 'work/benchmark/', 1)
                              if relative.startswith('frozen/') else relative)
        source = HERE / 'overlay' / relative
        assert sha(source) == row['new_sha256']
        if row['old_sha256'] is None:
            assert not os.path.lexists(destination)
        else:
            assert sha(destination) == row['old_sha256']
        replace(destination, source.read_bytes())
        changed.add(str(destination))
        stage_assets[str(destination.relative_to(ROOT))] = {
            'bytes': destination.stat().st_size, 'sha256': sha(destination)}
    amendment_path = ROOT / 'work/benchmark/protocol-amendment-check-convergence.json'
    assert not amendment_path.exists()
    replace(amendment_path, (HERE / 'protocol-amendment-check-convergence.json').read_bytes())
    stage_assets[str(amendment_path.relative_to(ROOT))] = {
        'bytes': amendment_path.stat().st_size, 'sha256': sha(amendment_path)}
    for relative in (*manifest['files'], 'manifest.json'):
        path = HERE / relative
        stage_assets[str(path.relative_to(ROOT))] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    replace(ROOT / 'stage-assets.json', encoded(stage_assets))
    changed.add(str(ROOT / 'stage-assets.json'))

    environment = os.environ.copy()
    for key, value in json.loads((ROOT / 'work/benchmark/environment.json').read_text()).items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    for key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSAFEPATH'):
        environment.pop(key, None)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    with (HERE / 'tests.stdout').open('xb') as out, (HERE / 'tests.stderr').open('xb') as err:
        tested = subprocess.run(['/usr/bin/python3', '-m', 'unittest', '-v',
                                 'test_dirty_fixture', 'test_dirty_guard', 'test_dirty_audit_v2', 'test_check_convergence'],
                                cwd=ROOT / 'work/benchmark', env=environment, stdout=out, stderr=err)
    assert tested.returncode == 0
    test_text = (HERE / 'tests.stderr').read_text()
    assert 'Ran 48 tests' in test_text and test_text.rstrip().endswith('OK')
    for suffix in ('stdout', 'stderr'):
        destination = ROOT / ('logs/helper-tests.' + suffix)
        replace(destination, (HERE / ('tests.' + suffix)).read_bytes())
        changed.add(str(destination))
    setup = json.loads((ROOT / 'setup.json').read_text())
    setup['initial_setup_metadata_sha256'] = old_setup_sha
    setup['initial_setup_metadata_archive'] = str(before / 'setup.json')
    setup['amended_at'] = datetime.now(timezone.utc).isoformat()
    setup['amendment'] = str(amendment_path)
    setup['no_cargo_build_or_benchmark_executed'] = False
    setup['no_comparative_samples_executed'] = True
    setup['prior_untimed_attempt'] = {'manifest': str(failed_path), 'state': 'failed',
                                    'successful_historical_test_diagnostics': 8,
                                    'eligible_diagnostics_in_new_cohort': 0, 'source_restored': True}
    setup['untimed_convergence_probe'] = {'manifest': str(probe_path), 'state': 'complete',
                                         'compiler_counts': [1, 0], 'source_restored': True}
    setup['helper_tests'] = {'count': 48, 'passed': True,
                             'stderr_sha256': sha(ROOT / 'logs/helper-tests.stderr')}
    setup['frozen_helper_sha256'] = {
        relative: sha(ROOT / relative) for relative in setup['frozen_helper_sha256']}
    setup['frozen_helper_sha256'][str(amendment_path.relative_to(ROOT))] = sha(amendment_path)
    for relative in amendment['overlay']:
        if relative.startswith('frozen/'):
            path = ROOT / relative.replace('frozen/', 'work/benchmark/', 1)
            setup['frozen_helper_sha256'][str(path.relative_to(ROOT))] = sha(path)
    replace(ROOT / 'setup.json', encoded(setup))
    changed.add(str(ROOT / 'setup.json'))

    receipt_path = ROOT / 'metadata/check-convergence-amendment.json'
    create(receipt_path, {
        'applied_at': setup['amended_at'], 'original_protocol_sha256': PROTOCOL,
        'original_cohort_sha256': OLD_COHORT, 'amendment_sha256': sha(amendment_path),
        'staged_manifest_sha256': sha(HERE / 'manifest.json'),
        'archive_manifest_sha256': sha(before / 'manifest.json'),
        'helper_tests': setup['helper_tests'], 'overlay': amendment['overlay'],
        'no_cargo_or_producer_or_benchmark_run_by_amendment': True,
        'comparative_samples': 0, 'accepted_diagnostics': 0,
        'unchanged_measured_commands_and_statistical_settings': True,
        'setup_preparation_changed': True, 'check_native_BEFORE_calls': 3,
        'test_native_BEFORE_calls': 1, 'prior_successful_test_diagnostics_preserved': 8,
    })
    extra = {amendment_path, receipt_path, HERE / 'manifest.json', before / 'manifest.json',
             HERE / 'tests.stdout', HERE / 'tests.stderr'}
    extra.update(HERE / relative for relative in manifest['files'])
    extra.update(ROOT / (relative.replace('frozen/', 'work/benchmark/', 1)
                        if relative.startswith('frozen/') else relative)
                 for relative in amendment['overlay'])
    extra.update(before / relative for relative in copied)
    prepared = {}
    for path_string in cohort['prepared_config_sha256']:
        path = Path(path_string)
        config = json.loads(path.read_text())
        original_settings = {key: value for key, value in config.items() if key != 'record_files'}
        config['record_files'] = sorted(set(config['record_files']) | {str(path) for path in extra})
        assert {key: value for key, value in config.items() if key != 'record_files'} == original_settings
        replace(path, encoded(config))
        changed.add(str(path))
        prepared[str(path)] = sha(path)
    binding_path = ROOT / 'metadata/preflight-fixture-bindings.json'
    bindings = json.loads(binding_path.read_text())
    for row in bindings['configs']:
        row['sha256'] = prepared[row['config']]
    replace(binding_path, encoded(bindings))
    changed.add(str(binding_path))
    for path, digest in cohort['asset_sha256'].items():
        if path not in changed:
            assert sha(path) == digest, path
    assets = {Path(path) for path in cohort['asset_sha256']} | extra
    cohort.update({
        'frozen_at': datetime.now(timezone.utc).isoformat(),
        'state': 'Three-call check preparation amended; complete new16 diagnostic matrix required before comparisons',
        'previous_frozen_cohort_sha256': OLD_COHORT,
        'check_preparation_amendment_sha256': sha(amendment_path),
        'prepared_config_sha256': prepared,
        'asset_sha256': {str(path): sha(path) for path in sorted(assets)},
    })
    replace(cohort_path, encoded(cohort))
    dirty_guard.check(guard, restored=True)
    input_catalog.check(ROOT / 'metadata/input-catalog.json')
    for path, digest in cohort['asset_sha256'].items():
        assert sha(path) == digest, path
    assert sha(ROOT / 'work/benchmark/protocol.json') == PROTOCOL
    print(json.dumps({'cohort_sha256': sha(cohort_path), 'prepared_config_sha256': prepared,
                      'archive_manifest_sha256': sha(before / 'manifest.json'),
                      'amendment_sha256': sha(amendment_path), 'helper_tests': 48,
                      'source_restored': True, 'no_cargo_run': True}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        import traceback
        failure = HERE / 'apply-failure.json'
        if not failure.exists():
            create(failure, {'error': repr(error), 'traceback': traceback.format_exc()})
        raise
