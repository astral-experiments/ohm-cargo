"""Three fixed native BEFORE checks; prove the final call is fully fresh."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import traceback


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    temporary = path.with_suffix('.tmp')
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    temporary.replace(path)


def proof_directory(batch, stage, pair, variant):
    if stage not in ('warmup', 'measurement') or variant not in ('baseline', 'candidate'):
        raise ValueError('invalid check preparation identity')
    if not isinstance(pair, int) or not 0 <= pair <= 99999999:
        raise ValueError('invalid check preparation pair')
    return Path(batch).absolute() / 'check-preparation' / f'{stage}-{pair:08d}-{variant}'


def snapshot(source):
    info = source.stat()
    if source.resolve() != source or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('check preparation source must remain an independent regular file')
    return {'path': str(source), 'sha256': sha(source), 'bytes': info.st_size,
            'mtime_ns': info.st_mtime_ns, 'mode': stat.S_IMODE(info.st_mode)}


def validate_fresh(stdout, stderr, trace, allowed):
    # Reuse the frozen, strict unfinished/resumed execve parser. Import lazily
    # because the existing batch auditor also calls this helper during replay.
    from dirty_audit_v2 import trace_executables
    executed = trace_executables(trace)
    if executed != allowed:
        raise ValueError('final preparation executed a compiler, build script, test, or unexpected process')
    if re.search(r'^\s*Running `', stderr, re.MULTILINE):
        raise ValueError('final preparation still reports executable work')
    messages = [json.loads(line) for line in stdout.splitlines()]
    finished = [row for row in messages if row.get('reason') == 'build-finished']
    if finished != [{'reason': 'build-finished', 'success': True}] or messages[-1] != finished[0]:
        raise ValueError('final preparation did not finish successfully')
    artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact']
    if not artifacts or any(row.get('fresh') is not True for row in artifacts):
        raise ValueError('final preparation contains missing or nonfresh artifact records')
    return {'artifact_records': len(artifacts), 'all_artifacts_fresh': True,
            'successful_execve_paths': executed, 'compiler_build_script_test_executions': 0}


def run(command, *, cwd, env, directory, source, identity):
    if command[:3] != ['taskset', '-c', '0-7'] or 'check' not in command:
        raise ValueError('check convergence requires the frozen native command')
    if '--message-format=json' not in command or '-v' not in command or not Path(command[3]).is_absolute():
        raise ValueError('check convergence command lacks auditable native outputs')
    directory, source = Path(directory).absolute(), Path(source).absolute()
    if directory != proof_directory(**identity) or directory.resolve() != directory:
        raise ValueError('check preparation directory does not match sample identity')
    directory.parent.mkdir(exist_ok=True)
    directory.mkdir(exist_ok=False)
    taskset = shutil.which('taskset', path=env.get('PATH'))
    if taskset != '/usr/bin/taskset':
        raise ValueError('cannot resolve the frozen taskset executable')
    allowed = [taskset, command[3]]
    original = snapshot(source)
    record = {'state': 'running', 'identity': identity, 'command': command,
              'target': env['CARGO_TARGET_DIR'], 'shared_build_dir': env['CARGO_BUILD_BUILD_DIR'],
              'environment_sha256': hashlib.sha256(json.dumps(env, sort_keys=True).encode()).hexdigest(),
              'source': original, 'fixed_native_calls': 3, 'allowed_final_executables': allowed, 'calls': []}
    manifest = directory / 'manifest.json'
    write(manifest, record)
    try:
        for number in range(1, 4):
            if snapshot(source) != original:
                raise ValueError('BEFORE source changed between preparation calls')
            stdout = directory / f'call-{number}.stdout'
            stderr = directory / f'call-{number}.stderr'
            trace = directory / f'call-{number}.execve'
            actual = command if number < 3 else [
                '/usr/bin/strace', '-f', '-qq', '-s', '65536', '-e', 'trace=execve,execveat',
                '-o', str(trace), *command]
            with stdout.open('x') as out, stderr.open('x') as err:
                result = subprocess.run(actual, cwd=cwd, env=env, stdout=out, stderr=err)
            row = {'number': number, 'returncode': result.returncode,
                   'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)}
            if number == 3:
                row['execve_sha256'] = sha(trace)
            record['calls'].append(row)
            write(manifest, record)
            if result.returncode:
                raise RuntimeError('fixed native check preparation failed')
            if snapshot(source) != original:
                raise ValueError('native preparation changed the BEFORE source')
            if number == 3:
                record['final_freshness'] = validate_fresh(
                    stdout.read_text(), stderr.read_text(), trace.read_text(), allowed)
        record['state'] = 'complete'
    except BaseException as error:
        record.update(state='failed', error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        write(manifest, record)
    result = subprocess.CompletedProcess(command, 0)
    result.preparation_proof = {'path': str(manifest), 'sha256': sha(manifest)}
    return result


def verify_record(entry):
    identity = {key: entry[key] for key in ('batch', 'stage', 'pair', 'variant')}
    directory = proof_directory(**identity)
    path = directory / 'manifest.json'
    proof = entry.get('preparation_proof')
    if path.resolve() != path or proof != {'path': str(path), 'sha256': sha(path)}:
        raise ValueError('missing or changed check preparation proof')
    record = json.loads(path.read_text())
    if record['state'] != 'complete' or record['fixed_native_calls'] != 3:
        raise ValueError('fixed three-call check preparation is incomplete')
    if record['identity'] != identity or record['command'] != entry['warm_command']:
        raise ValueError('check preparation identity or command changed')
    if record['target'] != entry['target'] or record['shared_build_dir'] != entry['shared_build_dir']:
        raise ValueError('check preparation target/cache binding changed')
    if record['source']['sha256'] != entry['before_sha256'] or record['source']['bytes'] != entry['before_bytes']:
        raise ValueError('check preparation did not use the exact BEFORE source')
    if [(row['number'], row['returncode']) for row in record['calls']] != [(1, 0), (2, 0), (3, 0)]:
        raise ValueError('check preparation call count or outcome changed')
    for row in record['calls']:
        suffixes = ('stdout', 'stderr', 'execve') if row['number'] == 3 else ('stdout', 'stderr')
        for suffix in suffixes:
            raw = directory / f"call-{row['number']}.{suffix}"
            if raw.resolve() != raw or sha(raw) != row[suffix + '_sha256']:
                raise ValueError('check preparation raw log changed')
    if record['allowed_final_executables'] != ['/usr/bin/taskset', entry['warm_command'][3]]:
        raise ValueError('check preparation executable allowlist changed')
    observed = validate_fresh((directory / 'call-3.stdout').read_text(),
                              (directory / 'call-3.stderr').read_text(),
                              (directory / 'call-3.execve').read_text(),
                              record['allowed_final_executables'])
    if observed != record['final_freshness']:
        raise ValueError('check preparation freshness replay differs')
    return {'proof': proof, 'fixed_native_calls': 3, **observed}


def verify_journal(state, batch, stage, pair, variant):
    entries = [json.loads(line) for line in (Path(state) / 'journal.jsonl').read_text().splitlines()]
    matches = [row for row in entries if row['operation'] == 'prepare' and
               (row['batch'], row['stage'], row['pair'], row['variant']) ==
               (str(Path(batch).resolve()), stage, pair, variant)]
    if len(matches) != 1:
        raise ValueError('check preparation journal entry is missing or duplicated')
    return verify_record(matches[0])
