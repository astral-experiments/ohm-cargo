#!/usr/bin/env python3
"""Audit dirty uv compiler commands and test nonexecution separately from effects."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shlex

import dirty_fixture
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def option(arguments, name):
    for index, argument in enumerate(arguments):
        if argument == name:
            return arguments[index + 1]
        if argument.startswith(name + '='):
            return argument.split('=', 1)[1]
    return None


def parse_run(stdout, stderr, target=None):
    artifacts, finished = [], []
    for line in stdout.splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get('reason') == 'compiler-artifact':
            artifacts.append(message)
        elif message.get('reason') == 'build-finished':
            finished.append(message.get('success'))
    if not artifacts or finished != [True]:
        raise ValueError('missing compiler-artifact records or successful build-finished record')
    commands, other, namespaces = [], [], set()
    for line in stderr.splitlines():
        match = re.match(r'^\s*Running `(.+)`$', line)
        if not match:
            continue
        arguments = shlex.split(match[1])
        if '--crate-name' not in arguments:
            other.append(arguments)
            continue
        source = [arg for arg in arguments if arg.endswith(('.rs', '.rlink')) and not arg.startswith('-')]
        if len(source) != 1:
            raise ValueError('rustc source argument is ambiguous')
        original_input = source[0]
        link_only = any(
            argument in ('-Zlink-only', '-Zlink-only=yes')
            or (argument == '-Z' and index + 1 < len(arguments) and arguments[index + 1] in ('link-only', 'link-only=yes'))
            for index, argument in enumerate(arguments)
        )
        input_kind = 'source'
        if source[0].endswith('.rlink'):
            if target is None or not link_only:
                raise ValueError('rlink input requires its assigned target and link-only mode')
            try:
                relative = Path(source[0]).relative_to(Path(target))
            except ValueError as error:
                raise ValueError('rlink input is outside its assigned target') from error
            parts = relative.parts
            if (
                len(parts) != 9 or parts[:3] != ('debug', 'build', 'workspaces')
                or parts[5] != 'uv' or parts[7] != 'out'
                or any(re.fullmatch('[0-9a-f]{16}', parts[index]) is None for index in (3, 6))
                or re.fullmatch('v2-[0-9a-f]{16}', parts[4]) is None
                or parts[8] not in (option(arguments, '--crate-name') + '.rlink', option(arguments, '--crate-name') + '-' + parts[6] + '.rlink')
            ):
                raise ValueError('rlink input is not a generated uv workspace artifact')
            source[0] = '@target/' + relative.as_posix()
            input_kind = 'rlink'
        elif link_only:
            raise ValueError('link-only rustc invocation unexpectedly takes Rust source')
        output_directory = option(arguments, '--out-dir')
        if target is not None:
            if output_directory is None:
                raise ValueError('rustc invocation has no auditable output directory')
            try:
                relative_output = Path(output_directory).relative_to(Path(target))
            except ValueError as error:
                raise ValueError('rustc output is outside its assigned target') from error
            output_parts = relative_output.parts
            if (
                len(output_parts) != 8 or output_parts[:3] != ('debug', 'build', 'workspaces')
                or output_parts[5] != 'uv' or output_parts[7] != 'out'
                or any(re.fullmatch('[0-9a-f]{16}', output_parts[index]) is None for index in (3, 6))
                or re.fullmatch('v2-[0-9a-f]{16}', output_parts[4]) is None
            ):
                raise ValueError('rustc output is not an assigned uv workspace artifact')
            if input_kind == 'rlink' and Path(original_input).parent != Path(output_directory):
                raise ValueError('rlink input and rustc output directories differ')
            namespaces.add(output_parts[3])
            output_directory = '@target/' + relative_output.as_posix()
        commands.append({
            'executable': arguments[0], 'crate': option(arguments, '--crate-name'),
            'source': source[0], 'crate_type': option(arguments, '--crate-type'),
            'test': '--test' in arguments, 'emit': option(arguments, '--emit'),
            'input_kind': input_kind, 'input_path': original_input, 'link_only': link_only,
            'output_directory': output_directory,
        })
    signatures = Counter(json.dumps({key: value for key, value in command.items() if key not in ('executable', 'input_path')}, sort_keys=True) for command in commands)
    compiled = [message for message in artifacts if not message['fresh']]
    test_executables = sorted({message['executable'] for message in artifacts if message['profile']['test'] and message.get('executable')})
    return {
        'target_dir': str(target) if target is not None else None,
        'workspace_namespaces': sorted(namespaces),
        'compiler_commands': commands, 'other_commands': other,
        'compiler_signatures': dict(sorted(signatures.items())),
        'compiler_stage_counts': dict(sorted(Counter(command['input_kind'] for command in commands).items())),
        'compiled_packages': sorted({message['package_id'] for message in compiled}),
        'compiled_targets': sorted(({'name': message['target']['name'], 'kind': message['target']['kind'], 'test': message['profile']['test']} for message in compiled), key=lambda row: json.dumps(row, sort_keys=True)),
        'test_executables': test_executables,
        'fresh_artifacts': sum(message['fresh'] for message in artifacts),
        'compiled_artifacts': len(compiled),
        'progress_packages': dirty_fixture.compile_packages(stderr),
    }


def validate_run(report, rustc, uv_package, expected=None):
    if report['progress_packages'] != ['uv'] or report['compiled_packages'] != [uv_package]:
        raise ValueError('dirty workload compiled a package other than uv or became a no-op')
    if not report['compiler_commands'] or report['other_commands']:
        raise ValueError('expected rustc commands only; build-script/test execution is unexpected')
    if any(command['executable'] != rustc for command in report['compiler_commands']):
        raise ValueError('unexpected rustc executable')
    if any(
        (command['input_kind'] == 'source' and not command['source'].startswith('crates/uv/'))
        or (command['input_kind'] == 'rlink' and not command['source'].startswith('@target/debug/build/workspaces/'))
        for command in report['compiler_commands']
    ):
        raise ValueError('unexpected dirty crate source')
    if expected is not None:
        for key in ('target_dir', 'workspace_namespaces', 'compiler_signatures', 'compiled_targets', 'compiled_artifacts'):
            if report[key] != expected[key]:
                raise ValueError(f'dirty compiler work changed from frozen diagnostic: {key}')


def target_expectation(report):
    if report['target_dir'] is None or len(report['workspace_namespaces']) != 1:
        raise ValueError('expected one exact workspace namespace for the assigned target')
    return {key: report[key] for key in (
        'target_dir', 'workspace_namespaces', 'compiler_signatures', 'compiled_targets', 'compiled_artifacts')}


def validate_work_equivalence(report, reference):
    """Compare work using only the two already-bound target namespace prefixes.

    Full signatures, including every hash, remain frozen separately per target.
    This setup-only comparison substitutes the exact observed namespace prefix;
    compiler-context/unit hashes and all other signature fields remain literal.
    """
    actual = target_expectation(report)
    expected = target_expectation(reference)
    actual_prefix = '@target/debug/build/workspaces/' + actual['workspace_namespaces'][0] + '/'
    expected_prefix = '@target/debug/build/workspaces/' + expected['workspace_namespaces'][0] + '/'
    signatures = Counter()
    for serialized, count in actual['compiler_signatures'].items():
        command = json.loads(serialized)
        for key in ('source', 'output_directory'):
            value = command[key]
            if value is not None and value.startswith('@target/debug/build/workspaces/'):
                if not value.startswith(actual_prefix):
                    raise ValueError('signature contains an unexpected workspace namespace')
                command[key] = expected_prefix + value[len(actual_prefix):]
        signatures[json.dumps(command, sort_keys=True)] += count
    if dict(sorted(signatures.items())) != expected['compiler_signatures']:
        raise ValueError('compiler work differs beyond the bound target workspace namespace')
    for key in ('compiled_targets', 'compiled_artifacts'):
        if actual[key] != expected[key]:
            raise ValueError(f'compiler work differs between assigned targets: {key}')


def trace_executables(text):
    paths = []
    pending = {}
    for line in text.splitlines():
        pid = re.match(r'^(?:\[pid\s+)?(\d+)(?:\])?\s+', line)
        if '<unfinished ...>' in line:
            if pid is None or pid[1] in pending:
                raise ValueError('ambiguous unfinished execve record')
            pending[pid[1]] = line.split('<unfinished ...>', 1)[0]
            continue
        resumed = re.search(r'<\.\.\. execve(?:at)? resumed>(.*)', line)
        if resumed:
            if pid is None or pid[1] not in pending:
                raise ValueError('execve resume has no beginning')
            line = pending.pop(pid[1]) + resumed[1]
        if not re.search(r'= 0\s*$', line):
            continue
        match = re.search(r'execve\(("(?:\\.|[^"\\])*")', line)
        if match is None:
            match = re.search(r'execveat\([^,]+,\s*("(?:\\.|[^"\\])*")', line)
        if match is None:
            raise ValueError('unparsed successful execve record')
        path = json.loads(match[1])
        if not path:
            raise ValueError('successful execveat has no auditable path')
        paths.append(path)
    if pending:
        raise ValueError('unfinished execve record remains')
    return paths


def validate_no_tests(report, trace):
    executables = trace_executables(trace)
    tests = set(report['test_executables'])
    if tests.intersection(executables):
        raise ValueError('a compiled test executable actually ran')
    if not executables:
        raise ValueError('empty successful execve trace')
    return executables


def verify_batch(guard_path, state, results, expectations, workload):
    guard = dirty_guard.check(guard_path, state, restored=True)
    results = Path(results).resolve()
    fixture = dirty_fixture.verify(state, results, ['uv'], require_check_convergence=(workload == 'check'))
    frozen = json.loads(Path(expectations).read_text())
    manifest = json.loads((results / 'manifest.json').read_text())
    samples = json.loads((results / 'samples.json').read_text())
    if manifest['variant_sha256'] != manifest['variant_sha256_after'] or manifest['recorded_file_sha256'] != manifest['recorded_file_sha256_after']:
        raise ValueError('frozen inputs changed during the batch')
    rows = []
    for sample in samples:
        report = parse_run(Path(sample['stdout']).read_text(), Path(sample['stderr']).read_text(), sample['configured_environment']['CARGO_TARGET_DIR'])
        expected = frozen['workloads'][workload]['targets'][report['target_dir']]
        validate_run(report, frozen['rustc'], frozen['uv_package'], expected)
        if workload == 'test' and '--no-run' not in sample['command']:
            raise ValueError('test measurement omitted --no-run')
        rows.append({
            'stage': sample['stage'], 'pair': sample['pair'], 'variant': sample['variant'],
            'stdout_sha256': sha(sample['stdout']), 'stderr_sha256': sha(sample['stderr']), **report,
        })
    output = {
        'valid': True, 'source_restored': True, 'source_identity': guard['source_identity'],
        'fixture_validation_valid': fixture['valid'], 'expectations_sha256': sha(expectations),
        'samples': rows,
    }
    dirty_fixture.write_json(results / 'compiler-audit.json', output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--guard', required=True)
    parser.add_argument('--state', required=True)
    parser.add_argument('--results', required=True)
    parser.add_argument('--expectations', required=True)
    parser.add_argument('--workload', required=True, choices=('check', 'test'))
    args = parser.parse_args()
    result = verify_batch(args.guard, args.state, args.results, args.expectations, args.workload)
    print(json.dumps({'valid': result['valid'], 'source_restored': result['source_restored'], 'samples': len(result['samples'])}))


if __name__ == '__main__':
    main()
