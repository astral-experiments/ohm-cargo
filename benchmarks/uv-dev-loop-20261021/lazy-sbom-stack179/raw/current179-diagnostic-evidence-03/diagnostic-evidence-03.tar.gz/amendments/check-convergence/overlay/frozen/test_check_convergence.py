import functools
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import check_convergence as convergence
import dirty_fixture as fixture


class CheckConvergenceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.workspace = self.root / 'workspace'
        self.workspace.mkdir()
        self.source = self.workspace / 'lib.rs'
        self.source.write_bytes(b'pub fn value() -> u8 { 1 }\n')
        self.original = self.source.read_bytes()
        self.batch = self.root / 'results'
        self.batch.mkdir()
        self.state = self.root / 'state'
        self.targets = {'baseline': self.root / 'targets/base', 'candidate': self.root / 'targets/cand'}
        self.shared = self.root / 'shared'
        fixture.initialize(self.state, self.source, self.workspace, self.targets, self.shared)
        self.command = ['taskset', '-c', '0-7', str(self.root / 'cargo'), 'check', '--message-format=json', '-v']
        self.identity = {'batch': str(self.batch), 'stage': 'measurement', 'pair': 0, 'variant': 'baseline'}
        self.directory = convergence.proof_directory(**self.identity)
        self.environment = {'PATH': '/usr/bin', 'CARGO_TARGET_DIR': str(self.targets['baseline']),
                            'CARGO_BUILD_BUILD_DIR': str(self.shared)}
        self.allowed = ['/usr/bin/taskset', self.command[3]]

    def tearDown(self):
        self.temporary.cleanup()

    def messages(self, fresh=True):
        return '\n'.join(json.dumps(row) for row in [
            {'reason': 'compiler-artifact', 'fresh': fresh},
            {'reason': 'build-finished', 'success': True}]) + '\n'

    def trace(self, paths=None):
        return ''.join(f'123 execve({json.dumps(path)}, [], 0x0) = 0\n' for path in (paths or self.allowed))

    def prepare(self, *, fresh=True, paths=None, failure_call=None, change_mtime=False):
        observed = []
        def native(command, **kwargs):
            observed.append((list(command), self.source.read_bytes()))
            number = len(observed)
            kwargs['stdout'].write(self.messages(fresh=fresh if number == 3 else False))
            kwargs['stderr'].write('')
            if number == 3:
                Path(command[command.index('-o') + 1]).write_text(self.trace(paths))
            if change_mtime and number == 1:
                import os
                info = self.source.stat()
                os.utime(self.source, ns=(info.st_atime_ns, info.st_mtime_ns + 1))
            return subprocess.CompletedProcess(command, int(number == failure_call))
        runner = functools.partial(convergence.run, directory=self.directory,
                                   source=self.source, identity=self.identity)
        with mock.patch('check_convergence.subprocess.run', side_effect=native):
            entry = fixture.prepare(self.state, self.batch, 'measurement', 0, 'baseline',
                                    self.command, self.environment, warm_runner=runner)
        return entry, observed

    def test_three_calls_share_before_bytes_then_apply_after(self):
        entry, observed = self.prepare()
        self.assertEqual(len(observed), 3)
        self.assertEqual(len({content for _, content in observed}), 1)
        self.assertEqual(observed[0][0], self.command)
        self.assertEqual(observed[1][0], self.command)
        self.assertEqual(observed[2][0][-len(self.command):], self.command)
        self.assertNotEqual(observed[-1][1], self.source.read_bytes())
        self.assertEqual(convergence.verify_record(entry)['compiler_build_script_test_executions'], 0)
        self.assertEqual(convergence.verify_journal(self.state, self.batch, 'measurement', 0, 'baseline')['fixed_native_calls'], 3)
        fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_default_test_preparation_still_calls_once(self):
        command = ['cargo', 'test', '--no-run']
        with mock.patch('dirty_fixture.subprocess.run', return_value=subprocess.CompletedProcess(command, 0)) as runner:
            entry = fixture.prepare(self.state, self.batch, 'measurement', 0, 'baseline', command, self.environment)
        self.assertEqual(runner.call_count, 1)
        self.assertNotIn('preparation_proof', entry)

    def test_nonfresh_final_call_does_not_apply_after(self):
        with self.assertRaisesRegex(ValueError, 'nonfresh'):
            self.prepare(fresh=False)
        self.assertIn(b'state=before', self.source.read_bytes())
        self.assertEqual(json.loads((self.directory / 'manifest.json').read_text())['state'], 'failed')
        fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_compiler_execution_is_rejected_despite_fresh_json(self):
        with self.assertRaisesRegex(ValueError, 'unexpected process'):
            self.prepare(paths=self.allowed + ['/toolchain/bin/rustc'])

    def test_build_script_execution_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unexpected process'):
            convergence.validate_fresh(self.messages(), '', self.trace(self.allowed + ['/target/build-script-build']), self.allowed)

    def test_test_execution_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unexpected process'):
            convergence.validate_fresh(self.messages(), '', self.trace(self.allowed + ['/target/debug/deps/uv-test']), self.allowed)

    def test_missing_artifact_records_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'missing or nonfresh'):
            convergence.validate_fresh('{"reason":"build-finished","success":true}\n', '', self.trace(), self.allowed)

    def test_failed_or_missing_finished_message_is_rejected(self):
        for value in ('', '{"reason":"build-finished","success":false}\n'):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, 'finish successfully'):
                convergence.validate_fresh(value, '', self.trace(), self.allowed)

    def test_reported_running_work_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'executable work'):
            convergence.validate_fresh(self.messages(), ' Running `/hidden/compiler`\n', self.trace(), self.allowed)

    def test_unfinished_execve_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unfinished'):
            convergence.validate_fresh(self.messages(), '', '123 execve("/usr/bin/taskset", <unfinished ...>\n', self.allowed)

    def test_failed_preparation_is_retained_and_restorable(self):
        with self.assertRaisesRegex(RuntimeError, 'preparation failed'):
            self.prepare(failure_call=2)
        record = json.loads((self.directory / 'manifest.json').read_text())
        self.assertEqual(record['state'], 'failed')
        self.assertEqual(len(record['calls']), 2)
        self.assertIn(b'state=before', self.source.read_bytes())
        fixture.restore(self.state)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_source_mtime_change_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'changed the BEFORE source'):
            self.prepare(change_mtime=True)

    def test_raw_log_mutation_is_rejected(self):
        entry, _ = self.prepare()
        (self.directory / 'call-1.stdout').write_text('changed\n')
        with self.assertRaisesRegex(ValueError, 'raw log changed'):
            convergence.verify_record(entry)

    def test_missing_proof_is_rejected(self):
        entry, _ = self.prepare()
        entry.pop('preparation_proof')
        with self.assertRaisesRegex(ValueError, 'missing or changed'):
            convergence.verify_record(entry)

    def test_wrong_before_source_binding_is_rejected(self):
        entry, _ = self.prepare()
        entry['before_sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'exact BEFORE source'):
            convergence.verify_record(entry)

    def test_duplicate_journal_entry_is_rejected(self):
        entry, _ = self.prepare()
        fixture.journal(self.state, entry)
        with self.assertRaisesRegex(ValueError, 'missing or duplicated'):
            convergence.verify_journal(self.state, self.batch, 'measurement', 0, 'baseline')


if __name__ == '__main__':
    unittest.main()
