#!/bin/bash
set -euo pipefail
exec env -u PYTHONPATH -u PYTHONHOME -u PYTHONSAFEPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 /tmp/ohm-hillclimb-20261021/lazy-sbom-current179/setup_remote.py >/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/setup.log 2>&1
