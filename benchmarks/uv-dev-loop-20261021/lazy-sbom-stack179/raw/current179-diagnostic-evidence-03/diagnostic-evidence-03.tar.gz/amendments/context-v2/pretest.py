from pathlib import Path
import base64, hashlib, json, subprocess
HERE=Path(__file__).resolve().parent
PACKAGE=HERE.parents[1]
files={name:(HERE/'overlay/frozen'/name if name in ('dirty_audit_v2.py','test_dirty_audit_v2.py') else PACKAGE/'frozen'/name) for name in ('dirty_audit_v2.py','test_dirty_audit_v2.py','dirty_fixture.py','dirty_guard.py','paired.py','test_dirty_fixture.py','test_dirty_guard.py')}
payload={name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'data':base64.b64encode(path.read_bytes()).decode()} for name,path in files.items()}
remote=r'''from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,json,os,socket,subprocess,sys
root=Path('/tmp/ohm-hillclimb-20261021/context-v2-auditor-tests')
assert socket.gethostname()=='charlie-oss-4' and os.getuid()==1000
assert root.parent.resolve()==root.parent and root.parent.stat().st_uid==1000
assert not root.exists()
root.mkdir(mode=0o700)
(root/'ownership.json').write_text(json.dumps({'root':str(root),'uid':os.getuid(),'purpose':'Isolated Python-only parser tests; no Cargo or fixture mutation.'},indent=2)+'\n')
bench=root/'work/benchmark';bench.mkdir(parents=True)
payload=json.load(sys.stdin)
assert len(payload)==7
for name,row in payload.items():
 assert Path(name).name==name
 data=base64.b64decode(row['data']);assert hashlib.sha256(data).hexdigest()==row['sha256']
 (bench/name).write_bytes(data)
env=os.environ.copy()
for key in ('PYTHONPATH','PYTHONHOME','PYTHONSAFEPATH'):env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
result=subprocess.run(['/usr/bin/python3','-m','unittest','-v','test_dirty_fixture','test_dirty_guard','test_dirty_audit_v2'],cwd=bench,env=env,capture_output=True)
(root/'tests.stdout').write_bytes(result.stdout);(root/'tests.stderr').write_bytes(result.stderr)
report={'at':datetime.now(timezone.utc).isoformat(),'root':str(root),'returncode':result.returncode,'files':{name:row['sha256'] for name,row in payload.items()},'stdout':result.stdout.decode(),'stderr':result.stderr.decode(),'python_sha256':hashlib.sha256(Path('/usr/bin/python3').resolve().read_bytes()).hexdigest()}
assert result.returncode==0 and 'Ran 32 tests' in report['stderr'] and report['stderr'].rstrip().endswith('OK'),report
sys.path.insert(0,str(bench));import dirty_audit_v2 as audit
old=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
prefix=old/'diagnostics/current179-preflight-01/logs/test-forward-native-baseline'
read=lambda suffix:Path(str(prefix)+suffix).read_text()
parsed=audit.parse_run(read('.stdout'),read('.stderr'),str(old/'targets/test/base'))
assert parsed['compiled_packages']==['path+file://'+str(old/'uv/crates/uv')+'#0.13.4'],parsed['compiled_packages']
audit.validate_run(parsed,'/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc',parsed['compiled_packages'][0])
audit.validate_no_tests(parsed,read('.execve'))
assert parsed['compiler_stage_counts']=={'source':2,'rlink':4} and len(parsed['compiler_commands'])==6
report['retained_log_reparse']={'purpose':'Mechanism check only, not an accepted diagnostic or performance sample.','compiler_stage_counts':parsed['compiler_stage_counts'],'compiler_signatures':parsed['compiler_signatures'],'workspace_namespaces':parsed['workspace_namespaces'],'test_executables_executed':[]}
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
'''
helper='/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result=subprocess.run([helper,'charlie-oss-4','--','env','-u','PYTHONPATH','-u','PYTHONHOME','-u','PYTHONSAFEPATH','PYTHONDONTWRITEBYTECODE=1','taskset','-c','8','/usr/bin/python3','-c',remote],input=json.dumps(payload).encode(),capture_output=True)
for suffix,data in (('stdout',result.stdout),('stderr',result.stderr)):
 with (HERE/('pretest.'+suffix)).open('xb') as stream:stream.write(data)
if result.returncode:raise SystemExit(result.stderr.decode())
record=json.loads(result.stdout)
with (HERE/'pretest-report.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({'returncode':record['returncode'],'tests':32,'retained_stage_counts':record['retained_log_reparse']['compiler_stage_counts'],'report_sha256':hashlib.sha256((HERE/'pretest-report.json').read_bytes()).hexdigest()},indent=2))
