
from pathlib import Path
import json,hashlib,base64,stat,fcntl,os
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179');p=root/'continuations/native-admission-history/attempt-01'
assert os.getuid()==root.stat().st_uid==1000 and p.resolve()==p
lock=(root/'experiment.lock').open('rb');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert all(not (root/n).exists() for n in ['results/native-confirmation.json','results/test-native-confirmation','results/check-native-confirmation','continuations/native-prerequisite-launch-01','logs/native-confirmation-01.controller.stdout','logs/native-confirmation-01.controller.stderr','metadata/test-native-confirmation-occupancy.txt'])
files={}
for f in sorted(p.rglob('*')):
 assert not f.is_symlink()
 if f.is_file():
  data=f.read_bytes();files[str(f.relative_to(p))]=dict(bytes=len(data),mode=stat.S_IMODE(f.stat().st_mode),sha256=hashlib.sha256(data).hexdigest(),base64=base64.b64encode(data).decode())
print(json.dumps(dict(files=files,native_still_unstarted=True)))
