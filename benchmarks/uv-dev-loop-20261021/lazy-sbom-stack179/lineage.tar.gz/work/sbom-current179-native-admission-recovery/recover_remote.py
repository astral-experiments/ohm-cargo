#!/usr/bin/env python3
"""Retain exactly one zero-work native admission; never launch a workload."""
import base64
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
BINDING = ROOT / 'continuations/native-prerequisite-01'
RETENTION = ROOT / 'continuations/native-admission-history/attempt-01'
CAPTURE = '069cf4e62ef50e28414f644794c3e2f16f0b37cfd968b6e72d421210226f0127'
FAILED = '653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2'
PREREQUISITE = 'b24ace5a04c82adde807489b4d28a8a1a4e708430f9d73f9ad0e81d17c470b48'
CONTROLS = 'af6c551f3ddd21562dd7859d67ec885d24507a256fabecccd653459df78ebf67'
VALIDATOR = '4a6f72e2bcb0d1817bd8ca2988bc92a9edc067e22f3a0fca787634e6c30ce432'
NATIVE_CONTROLLER = 'd1f05e3909e83fccb93c4d1c8b6445921333a68cddc275f888198121dc5177fb'
HISTORY = 'continuations/native-prerequisite-launch-01'
MOVES = (HISTORY, 'results/native-confirmation.json', 'metadata/test-native-confirmation-occupancy.txt',
         'logs/native-confirmation-01.controller.stdout', 'logs/native-confirmation-01.controller.stderr')
HISTORY_NAMES = {'before.json', 'entry-receipt.json', 'receipt.json', 'remote.py', 'request.json', 'root-approval.json', 'seal.json'}
EXPECTED = {HISTORY + '/' + name for name in HISTORY_NAMES} | set(MOVES[1:])
ABSENT = tuple('results/' + workload + '-native-confirmation' for workload in ('test', 'check')) + tuple(
    'logs/' + workload + '-native-confirmation.' + kind + '.' + suffix
    for workload in ('test', 'check') for kind in ('run', 'analysis') for suffix in ('stdout', 'stderr')) + (
    'metadata/check-native-confirmation-occupancy.txt',)


def need(value, reason):
    if not value:
        raise ValueError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    info = path.lstat()
    need(path.resolve() == path and stat.S_ISREG(info.st_mode), 'noncanonical regular input')
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'sha256': value, 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def write_new(path, data, mode=0o644):
    need(path.parent.resolve() == path.parent, 'noncanonical output parent')
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(mode)


def guard_clear(occupancy):
    # The exact original admission predicate, with no new exceptions or threshold.
    return not any(row.split()[1] in {'cargo', 'rustc', 'cc1', 'cc1plus', 'clang', 'clang++', 'ld.lld', 'callgrind-amd64'}
                   for row in occupancy.splitlines()[1:])


def validate_failed(status, capture):
    need(capture['state'] == 'failed' and capture['completed_workloads'] == []
         and capture['returncode'] == 0 and capture['no_native_workload_or_sample_directories'] is True
         and set(capture['files']) == EXPECTED
         and capture['files']['results/native-confirmation.json']['sha256'] == FAILED, 'failed capture scope differs')
    need(status['state'] == 'failed' and status['group'] == 'native-confirmation'
         and status['completed_workloads'] == [] and 'results' not in status
         and status['error'] == "ValueError('another compiler/build/profiler process is active before the batch')"
         and 'native-original-controller.py\", line 83, in main' in status['traceback'], 'failure was not the zero-work admission')


def require_absent(root):
    need(all(not (root / name).exists() and not (root / name).is_symlink() for name in ABSENT),
         'native workload, analysis or second-workload admission has already begun')


def retained_files(root, capture):
    need(all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in root.rglob('*')),
         'unexpected retained file type')
    need({str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()} == EXPECTED,
         'retained metadata member set differs')
    need(all(record(root / name) == row for name, row in capture['files'].items()), 'retained metadata bytes/modes changed')


def main():
    sys.dont_write_bytecode = True
    data = sys.stdin.buffer.read()
    need(len(sys.argv) == 3 and digest(data) == sys.argv[1], 'recovery request identity differs')
    request = json.loads(data)
    decode = lambda name: base64.b64decode(request[name], validate=True)
    approval_bytes, capture_bytes = decode('approval_base64'), decode('capture_base64')
    source, freeze_bytes = decode('source_base64'), decode('source_freeze_base64')
    need(digest(approval_bytes) == sys.argv[2] == request['approval_sha256']
         and digest(capture_bytes) == CAPTURE and digest(freeze_bytes) == request['source_freeze_sha256'], 'approved recovery envelope differs')
    approval, capture, freeze = map(json.loads, (approval_bytes, capture_bytes, freeze_bytes))
    need(request['operation'] == 'retain-zero-work-native-admission-01'
         and approval['valid'] is True and approval['authorized_operation'] == request['operation']
         and approval['source_freeze_sha256'] == request['source_freeze_sha256']
         and approval['recovery_source_sha256'] == digest(source) == freeze['files']['recover_remote.py']['sha256']
         and approval['capture_sha256'] == CAPTURE and approval['failed_status_sha256'] == FAILED
         and approval['prerequisite_manifest_sha256'] == PREREQUISITE
         and approval['controls_source_freeze_sha256'] == CONTROLS
         and approval['remote_root'] == str(ROOT) and approval['retention_root'] == str(RETENTION), 'recovery approval differs')
    need(socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000 and ROOT.resolve() == ROOT
         and ROOT.stat().st_uid == 1000 and Path('/').stat().st_uid == 0
         and Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(), 'recovery host/root/identity differs')
    need(not RETENTION.exists() and not RETENTION.is_symlink() and RETENTION.resolve() == RETENTION, 'retention already attempted')
    lock = (ROOT / 'experiment.lock').open('rb'); fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    need(record(BINDING / 'manifest.json')['sha256'] == PREREQUISITE
         and record(BINDING / 'controls/remote.py')['sha256'] == VALIDATOR, 'original native controls changed')
    spec = importlib.util.spec_from_file_location('frozen_native_recovery_validator', BINDING / 'controls/remote.py')
    validator = importlib.util.module_from_spec(spec); spec.loader.exec_module(validator)
    manifest, contents = validator.read_binding()
    need(manifest['controls_source_freeze_sha256'] == CONTROLS, 'original controls freeze changed')
    contract = validator.load_contract()
    contract.verify_capsule(contract.CAPSULE, validator.CAPSULE_SHA)
    contract.inputs(ROOT); contract.preserved(ROOT, contract.CAPSULE, after_check=True)
    transfer = json.loads(contents['transfer-manifest.json'])['files']
    need(not EXPECTED.intersection(transfer), 'metadata relocation would touch accepted IR input')
    for name, row in transfer.items():
        if name != 'collection-identity.json':
            need(record(ROOT / contract.relative(name)) == row, 'accepted IR/native-fixture bytes changed: ' + name)
    need({path.name for path in (ROOT / 'results').iterdir()} ==
         {'ir-confirmation.json', 'test-ir-confirmation', 'ir-completion-01', 'native-confirmation.json'}, 'unexpected phase results')
    need(record(contract.CAPSULE / 'native-original-controller.py')['sha256'] == NATIVE_CONTROLLER, 'original native controller changed')
    require_absent(ROOT)
    need({path.name for path in (ROOT / HISTORY).iterdir()} == HISTORY_NAMES, 'launch history contains unexpected entries')
    need(all(record(ROOT / name) == row for name, row in capture['files'].items()), 'captured failed metadata changed')
    validate_failed(json.loads((ROOT / 'results/native-confirmation.json').read_bytes()), capture)
    need((ROOT / 'logs/native-confirmation-01.controller.stdout').read_bytes() == b'', 'native controller passed admission')
    for session in ('ohm-sbom179-ir-completion-01', 'ohm-sbom179-ir-completion-02', validator.SESSION):
        need(subprocess.run(['/usr/bin/tmux', 'has-session', '-t', session], capture_output=True).returncode == 1,
             'an experiment session remains active or tmux probe failed')
    occupancy = subprocess.check_output(['ps', '-eo', 'pid,comm,pcpu,pmem', '--sort=-pcpu'], text=True)
    need(guard_clear(occupancy), 'original occupancy predicate is still blocked')
    # All eligibility and quiet checks precede the first metadata write/rename.
    RETENTION.mkdir(parents=True, mode=0o700)
    for name, value in (('request.json', data), ('root-approval.json', approval_bytes), ('capture.json', capture_bytes),
                        ('source-freeze.json', freeze_bytes), ('occupancy-before.txt', occupancy.encode())):
        write_new(RETENTION / name, value)
    write_new(RETENTION / 'recover_remote.py', source, freeze['files']['recover_remote.py']['mode'])
    plan = {name: {'origin': str(ROOT / name), 'retained': str(RETENTION / 'retained' / name), **row}
            for name, row in capture['files'].items()}
    write_new(RETENTION / 'move-plan.json', encoded(plan))
    retained = RETENTION / 'retained'; retained.mkdir()
    for name in MOVES:
        destination = retained / name; destination.parent.mkdir(parents=True, exist_ok=True)
        need(destination.parent.resolve() == destination.parent and not destination.exists() and not destination.is_symlink(), 'retention destination exists')
        (ROOT / name).rename(destination)
    retained_files(retained, capture)
    need(all(not (ROOT / name).exists() and not (ROOT / name).is_symlink() for name in MOVES), 'canonical admission metadata was not freed')
    require_absent(ROOT)
    validator.accepted_live_bytes(contract, manifest, contents)
    validator.read_binding()
    receipt = {'valid': True, 'operation': request['operation'], 'completed_at': datetime.now(timezone.utc).isoformat(),
               'capture_sha256': CAPTURE, 'failed_status_sha256': FAILED, 'source_freeze_sha256': request['source_freeze_sha256'],
               'recovery_source_sha256': digest(source), 'approval_sha256': digest(approval_bytes), 'request_sha256': digest(data),
               'prerequisite_manifest_sha256': PREREQUISITE, 'controls_source_freeze_sha256': CONTROLS,
               'retention_root': str(RETENTION), 'retained_files': plan, 'rename_units': list(MOVES),
               'all_accepted_ir_bytes_and_native_fixtures_unchanged': True, 'all_original_metadata_preserved': True,
               'native_workload_or_analysis_executed': False, 'replay_authorized_by_this_receipt': False}
    write_new(RETENTION / 'receipt.json', encoded(receipt))
    write_new(RETENTION / 'seal.json', encoded({str(p.relative_to(RETENTION)): record(p) for p in sorted(RETENTION.rglob('*')) if p.is_file()}))
    retained_files(retained, capture); require_absent(ROOT)
    print(json.dumps({'receipt': receipt, 'receipt_sha256': record(RETENTION / 'receipt.json')['sha256'],
                      'seal_sha256': record(RETENTION / 'seal.json')['sha256']}, sort_keys=True))


if __name__ == '__main__':
    main()
