#!/usr/bin/env python3
"""Prepare only a byte-identical sibling of the original local launch controls."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import recover_remote as contract

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ORIGINAL = WORK / 'sbom-current179-native-launch-controls-alias-v2'
REPLAY = WORK / 'sbom-current179-native-launch-replay02'


def copy_exact(source, destination, expected):
    contract.need(contract.record(source) == expected, 'source changed before local copy')
    destination.parent.mkdir(parents=True, exist_ok=True)
    contract.need(destination.parent.resolve() == destination.parent and not destination.exists() and not destination.is_symlink(), 'copy destination already exists')
    with source.open('rb') as incoming, destination.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    destination.chmod(expected['mode'])
    contract.need(contract.record(source) == contract.record(destination) == expected
                  and (source.stat().st_dev, source.stat().st_ino) != (destination.stat().st_dev, destination.stat().st_ino),
                  'copy changed input bytes or reused its inode')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source-freeze-sha256', 'approval', 'approval-sha256', 'recovery-receipt', 'recovery-receipt-sha256'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    freeze_path = HERE / 'source-freeze.json'
    contract.need(contract.record(freeze_path)['sha256'] == args.source_freeze_sha256, 'recovery source freeze differs')
    freeze = json.loads(freeze_path.read_bytes())
    for name, row in freeze['files'].items():
        contract.need(contract.record(HERE / name) == row, 'recovery source changed')
    approval_path, receipt_path = Path(args.approval).absolute(), Path(args.recovery_receipt).absolute()
    contract.need(approval_path.is_relative_to(WORK) and receipt_path.is_relative_to(WORK)
                  and contract.record(approval_path)['sha256'] == args.approval_sha256
                  and contract.record(receipt_path)['sha256'] == args.recovery_receipt_sha256, 'local preparation approval/receipt differs')
    approval, receipt = json.loads(approval_path.read_bytes()), json.loads(receipt_path.read_bytes())
    contract.need(approval['valid'] is True and approval['authorized_operation'] == 'prepare-byte-identical-native-replay02'
                  and approval['source_freeze_sha256'] == args.source_freeze_sha256
                  and approval['recovery_receipt_sha256'] == args.recovery_receipt_sha256
                  and approval['original_directory'] == str(ORIGINAL) and approval['replay_directory'] == str(REPLAY), 'copy is not approved for these paths')
    contract.need(receipt['valid'] is True and receipt['operation'] == 'retain-zero-work-native-admission-01'
                  and receipt['source_freeze_sha256'] == args.source_freeze_sha256
                  and receipt['capture_sha256'] == contract.CAPTURE and receipt['failed_status_sha256'] == contract.FAILED
                  and receipt['prerequisite_manifest_sha256'] == contract.PREREQUISITE
                  and receipt['all_original_metadata_preserved'] is True
                  and receipt['all_accepted_ir_bytes_and_native_fixtures_unchanged'] is True
                  and receipt['native_workload_or_analysis_executed'] is False, 'zero-work remote recovery has not passed')
    index = json.loads((HERE / 'replay-copy-inputs.json').read_bytes())
    protected = index['protected_original_files']
    contract.need(all(name and str(Path(name)) == name and not Path(name).is_absolute() and '..' not in Path(name).parts
                      for name in set(protected) | set(index['copied_files'])), 'unsafe copied input name')
    for name, row in protected.items():
        contract.need(contract.record(ORIGINAL / name) == row, 'original local source/history changed')
    contract.need(not REPLAY.exists() and not REPLAY.is_symlink() and REPLAY.resolve() == REPLAY, 'replay copy already exists')
    REPLAY.mkdir(mode=0o700)
    for name, row in index['copied_files'].items():
        copy_exact(ORIGINAL / name, REPLAY / name, row)
    contract.need(not (REPLAY / 'launch-attempt01').exists(), 'replay launch was not absent')
    contract.need({str(path.relative_to(REPLAY)) for path in REPLAY.rglob('*') if path.is_file()} == set(index['copied_files']), 'replay copy has unexpected members')
    # Exercise the unchanged producer's own local source/payload guards only.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(REPLAY))
    spec = importlib.util.spec_from_file_location('verified_native_replay_prepare', REPLAY / 'prepare.py')
    original = importlib.util.module_from_spec(spec); spec.loader.exec_module(original)
    original.freeze_check(contract.CONTROLS); original.verify_prepared()
    for name, row in protected.items():
        contract.need(contract.record(ORIGINAL / name) == row, 'original local bytes changed during copy')
    for name, row in freeze['files'].items():
        contract.need(contract.record(HERE / name) == row, 'recovery source changed during copy')
    report = {'valid': True, 'operation': approval['authorized_operation'], 'source_freeze_sha256': args.source_freeze_sha256,
              'recovery_receipt_sha256': args.recovery_receipt_sha256, 'approval_sha256': args.approval_sha256,
              'original_directory': str(ORIGINAL), 'replay_directory': str(REPLAY), 'copied_files': index['copied_files'],
              'all_original_local_paths_unchanged': True, 'unchanged_original_source_and_prepared_guards_passed': True,
              'launch_attempt_absent': True, 'host_or_workload_operations': False}
    contract.write_new(HERE / 'replay-copy-receipt.json', contract.encoded(report))
    print(json.dumps({'valid': True, 'files': len(index['copied_files']),
                      'receipt_sha256': contract.record(HERE / 'replay-copy-receipt.json')['sha256']}, sort_keys=True))


if __name__ == '__main__':
    main()
