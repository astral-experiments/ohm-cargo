#!/usr/bin/env python3
"""Read only the captured zero-work boundary and freeze exact local replay inputs."""
import ast
import base64
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import recover_remote as contract

WORK = HERE.parent
CAPTURE = WORK / 'sbom-current179-native-failed-launch01'
ORIGINAL = WORK / 'sbom-current179-native-launch-controls-alias-v2'
CONTINUATION = WORK / 'sbom-current179-ir-continuation'


def main():
    capture_path = CAPTURE / 'capture.json'
    contract.need(contract.record(capture_path)['sha256'] == contract.CAPTURE, 'captured boundary identity differs')
    capture = json.loads(capture_path.read_bytes())
    for filename, field in (('transport.stdout', 'transport_stdout_sha256'), ('transport.stderr', 'transport_stderr_sha256'),
                            ('capture-source.py', 'capture_source_sha256')):
        contract.need(contract.record(CAPTURE / filename)['sha256'] == capture[field], 'capture source/stream changed')
    transported = json.loads((CAPTURE / 'transport.stdout').read_bytes())
    contract.need(set(transported['files']) == contract.EXPECTED, 'transported failure member set differs')
    for key in ('state', 'completed_workloads', 'recorded_at', 'no_native_workload_or_sample_directories', 'current_compiler_processes'):
        contract.need(transported[key] == capture[key], 'capture envelope does not join stdout')
    for name, row in capture['files'].items():
        observed = contract.record(CAPTURE / 'evidence' / name)
        transmitted = transported['files'][name]
        contract.need(observed == row == {k: transmitted[k] for k in ('sha256', 'bytes', 'mode')}
                      and base64.b64decode(transmitted['base64'], validate=True) == (CAPTURE / 'evidence' / name).read_bytes(),
                      'captured payload changed')
    status = json.loads((CAPTURE / 'evidence/results/native-confirmation.json').read_bytes())
    contract.validate_failed(status, capture)
    contract.need((CAPTURE / 'evidence/logs/native-confirmation-01.controller.stdout').read_bytes() == b'', 'controller passed admission')
    native = CONTINUATION / 'native-original-controller.py'
    contract.need(contract.record(native)['sha256'] == contract.NATIVE_CONTROLLER, 'original native controller differs')
    tree = ast.parse(native.read_text())
    loop = next(node for node in ast.walk(tree) if isinstance(node, ast.For) and isinstance(node.target, ast.Name)
                and node.target.id == 'workload')
    admission = next(index for index, node in enumerate(loop.body) if isinstance(node, ast.If)
                     and isinstance(node.test, ast.Call) and isinstance(node.test.func, ast.Name) and node.test.func.id == 'any')
    paired = next(index for index, node in enumerate(loop.body) if isinstance(node, ast.With))
    contract.need(admission < paired and isinstance(loop.body[admission].body[0], ast.Raise)
                  and loop.body[admission].body[0].lineno == 83, 'failure no longer precedes paired invocation')
    history = CAPTURE / 'evidence' / contract.HISTORY
    entry, before, request = (json.loads((history / name).read_bytes()) for name in ('entry-receipt.json', 'before.json', 'request.json'))
    contract.need(entry['valid'] is True and entry['original_controller_not_yet_executed'] is True
                  and entry['before_sha256'] == contract.record(history / 'before.json')['sha256']
                  and entry['launch_request_sha256'] == before['request_sha256'] == contract.record(history / 'request.json')['sha256']
                  and entry['prerequisite_manifest_sha256'] == before['prerequisite_manifest_sha256'] == contract.PREREQUISITE
                  and before['approval_sha256'] == request['approval_sha256'] == contract.record(history / 'root-approval.json')['sha256'],
                  'original actual entry/approval joins differ')
    freeze = json.loads((ORIGINAL / 'source-freeze.json').read_bytes())
    contract.need(contract.record(ORIGINAL / 'source-freeze.json')['sha256'] == contract.CONTROLS, 'original controls freeze differs')
    for name, row in freeze['files'].items():
        contract.need(contract.record(ORIGINAL / name) == row, 'original frozen source changed')
    manifest_path = ORIGINAL / 'prepared/manifest.json'
    contract.need(contract.record(manifest_path)['sha256'] == contract.PREREQUISITE, 'original prerequisite changed')
    manifest = json.loads(manifest_path.read_bytes())
    copied = set(freeze['files']) | {'source-freeze.json', 'prepared/manifest.json'}
    copied |= {'prepared/' + name for name in manifest['files']}
    copied |= {'stage-attempt01/' + path.name for path in (ORIGINAL / 'stage-attempt01').iterdir() if path.is_file()}
    contract.need(not any(name.startswith('launch-attempt01/') for name in copied), 'old local launch included in active replay')
    protected = {str(path.relative_to(ORIGINAL)): contract.record(path) for path in sorted(ORIGINAL.rglob('*')) if path.is_file()}
    copy_rows = {name: protected[name] for name in sorted(copied)}
    local_launch = json.loads((ORIGINAL / 'launch-attempt01/receipt.json').read_bytes())
    contract.need(local_launch['returncode'] == 0 and local_launch['remote_success_validated'] is True
                  and local_launch['remote']['remote_receipt_sha256'] == contract.record(history / 'receipt.json')['sha256'],
                  'local initial launch does not bind captured remote history')
    occupancy = (CAPTURE / 'evidence/metadata/test-native-confirmation-occupancy.txt').read_text()
    contract.need(not contract.guard_clear(occupancy), 'captured occupancy does not explain original guard failure')
    report = {'valid': True, 'reviewed_at': datetime.now(timezone.utc).isoformat(), 'capture_sha256': contract.CAPTURE,
              'failed_status_sha256': contract.FAILED, 'remote_files_verified': len(capture['files']),
              'original_native_controller_sha256': contract.NATIVE_CONTROLLER, 'first_guard_raise_line': 83,
              'paired_process_or_fixture_preparation_started': False, 'native_effects_exist': False,
              'captured_absence_proof': 'Two native result directories and four paired run logs were absent at capture.',
              'required_fresh_live_proof': 'Rehash all accepted IR files and both native fixture sets; require all native run/analysis outputs absent before relocation.',
              'local_original_paths_must_remain_unchanged': True, 'remote_rename_units': list(contract.MOVES),
              'local_replay_inputs': len(copy_rows), 'protected_local_original_files': len(protected),
              'host_operations': False, 'effects_read_or_recomputed': False}
    contract.write_new(HERE / 'replay-copy-inputs.json', contract.encoded({'copied_files': copy_rows, 'protected_original_files': protected}))
    contract.write_new(HERE / 'boundary-review.json', contract.encoded(report))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
