"""Pure/source-corpus tests; subprocess and socket operations are prohibited."""
import ast
import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import recover_remote as contract
import prepare_replay

WORK = HERE.parent
ORIGINAL = prepare_replay.ORIGINAL
CAPTURE = WORK / 'sbom-current179-native-failed-launch01'


def prohibit(event, arguments):
    if event in {'subprocess.Popen', 'socket.connect', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork'}:
        raise AssertionError('Source checks must not execute processes or contact hosts')


class BoundaryChecks(unittest.TestCase):
    def setUp(self):
        self.capture = json.loads((CAPTURE / 'capture.json').read_bytes())
        self.status = json.loads((CAPTURE / 'evidence/results/native-confirmation.json').read_bytes())

    def test_captured_zero_work_failure_qualifies_for_retention(self):
        contract.validate_failed(self.status, self.capture)

    def test_any_completed_workload_blocks(self):
        self.status['completed_workloads'] = ['test']
        with self.assertRaises(ValueError): contract.validate_failed(self.status, self.capture)

    def test_effects_or_other_failure_cannot_be_retried(self):
        for mutation in ('results', 'error', 'state'):
            status = copy.deepcopy(self.status)
            status[mutation] = {} if mutation == 'results' else 'other'
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                contract.validate_failed(status, self.capture)

    def test_incomplete_or_different_capture_blocks(self):
        self.capture['files'].pop('logs/native-confirmation-01.controller.stdout')
        with self.assertRaises(ValueError): contract.validate_failed(self.status, self.capture)

    def test_original_occupancy_predicate_is_identical(self):
        original = ast.parse((WORK / 'sbom-current179-ir-continuation/native-original-controller.py').read_text())
        guard = ast.parse((HERE / 'recover_remote.py').read_text())
        predicate = lambda tree: next(node for node in ast.walk(tree) if isinstance(node, ast.Call)
                                      and isinstance(node.func, ast.Name) and node.func.id == 'any')
        self.assertEqual(ast.dump(predicate(original)), ast.dump(predicate(guard)))
        for command in ('cargo', 'rustc', 'cc1', 'cc1plus', 'clang', 'clang++', 'ld.lld', 'callgrind-amd64'):
            self.assertFalse(contract.guard_clear('PID COMMAND CPU MEM\n1 ' + command + ' 0 0\n'))
        self.assertTrue(contract.guard_clear('PID COMMAND CPU MEM\n1 tmux: server 0 0\n'))

    def test_any_native_output_or_dangling_alias_blocks(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            contract.require_absent(root)
            output = root / contract.ABSENT[0]; output.parent.mkdir(); output.mkdir()
            with self.assertRaises(ValueError): contract.require_absent(root)
            output.rmdir(); output.symlink_to(root / 'absent-target')
            with self.assertRaises(ValueError): contract.require_absent(root)

    def test_copy_preserves_source_bytes_mode_and_independent_inode(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve(); source = root / 'source'; source.write_bytes(b'opaque original'); source.chmod(0o640)
            row = contract.record(source); target = root / 'copy'
            prepare_replay.copy_exact(source, target, row)
            self.assertEqual(contract.record(source), row); self.assertEqual(contract.record(target), row)
            with self.assertRaises(ValueError): prepare_replay.copy_exact(source, target, row)
            self.assertEqual(source.read_bytes(), b'opaque original')

    def test_retained_metadata_requires_exact_bytes_and_types(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            for name, row in self.capture['files'].items():
                target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((CAPTURE / 'evidence' / name).read_bytes()); target.chmod(row['mode'])
            contract.retained_files(root, self.capture)
            (root / 'unbound-link').symlink_to(root / 'missing')
            with self.assertRaises(ValueError): contract.retained_files(root, self.capture)

    def test_unchanged_transport_uses_new_sibling_without_touching_original(self):
        index = json.loads((HERE / 'replay-copy-inputs.json').read_bytes())
        with tempfile.TemporaryDirectory(prefix='sbom-native-replay-source-check-', dir=WORK) as directory:
            replica = Path(directory).resolve()
            for name, row in index['copied_files'].items():
                prepare_replay.copy_exact(ORIGINAL / name, replica / name, row)
            saved_path, saved_modules = list(sys.path), {name: sys.modules.get(name) for name in ('prepare', 'remote')}
            for name in saved_modules: sys.modules.pop(name, None)
            sys.path.insert(0, str(replica))
            try:
                spec = importlib.util.spec_from_file_location('original_transport_source_test', replica / 'transport.py')
                transport = importlib.util.module_from_spec(spec); spec.loader.exec_module(transport)
                self.assertEqual(transport.HERE, replica)
                self.assertEqual(transport.PREPARED, replica / 'prepared')
                transport.freeze_check(contract.CONTROLS); manifest, unused = transport.verify_prepared()
                stage_path = replica / 'stage-attempt01/receipt.json'; stage = json.loads(stage_path.read_bytes())
                approval = {'valid': True, 'authorized_operation': 'launch-fixed-native-prerequisites',
                    'controls_source_freeze_sha256': contract.CONTROLS, 'prerequisite_manifest_sha256': contract.PREREQUISITE,
                    'stage_receipt_sha256': contract.record(stage_path)['sha256'],
                    'remote_stage_receipt_sha256': stage['remote']['remote_receipt_sha256']}
                approval_path = replica / 'synthetic-approval.json'; approval_path.write_bytes(contract.encoded(approval))
                argv = [str(replica / 'transport.py'), 'launch', '--source-freeze-sha256', contract.CONTROLS,
                        '--approval', str(approval_path), '--approval-sha256', contract.record(approval_path)['sha256']]
                calls = []
                def fake_transport(command, **arguments):
                    calls.append(command)
                    return SimpleNamespace(returncode=255, stdout=b'', stderr=b'SYNTHETIC: transport was not executed\n')
                with patch.object(sys, 'argv', argv), patch.object(transport.subprocess, 'run', fake_transport), contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaises(SystemExit) as stopped: transport.main()
                self.assertEqual(stopped.exception.code, 1); self.assertEqual(len(calls), 1)
                self.assertEqual(calls[0][1], 'charlie-oss-4')
                self.assertEqual(contract.digest(calls[0][calls[0].index('-c') + 1].encode()), contract.VALIDATOR)
                receipt = json.loads((replica / 'launch-attempt01/receipt.json').read_bytes())
                self.assertEqual(receipt['returncode'], 255); self.assertFalse(receipt['remote_success_validated'])
                self.assertTrue((ORIGINAL / 'launch-attempt01/receipt.json').is_file())
            finally:
                sys.path[:] = saved_path
                for name, value in saved_modules.items():
                    sys.modules.pop(name, None)
                    if value is not None: sys.modules[name] = value
            for name, row in index['protected_original_files'].items():
                self.assertEqual(contract.record(ORIGINAL / name), row)


if __name__ == '__main__':
    sys.addaudithook(prohibit)
    assert sorted(os.sched_getaffinity(0)) == [8]
    unittest.main(verbosity=2)
