"""Verify collected diagnostic bytes and authorize only the fixed IR phase."""
import ast
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import stat
import tarfile

LOCAL = Path(__file__).resolve().parent
E = LOCAL / 'diagnostic-evidence-03'
REMOTE = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

transfer = E / 'transfer-manifest.json'
assert sha(transfer) == '3b1bd66c915b2a66682973204d1f67fe9f8539e4448eb19f1b8a1ea0ab8e8838'
files = read(transfer)['files']
assert len(files) == 612
for name, row in files.items():
    rel = Path(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    path = E / rel
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    assert stat.S_IMODE(path.stat().st_mode) == row['mode']
expected_names = set(files) | {'transfer-manifest.json'}
assert {str(p.relative_to(E)) for p in E.rglob('*') if p.is_file()} == expected_names
archive = LOCAL / 'diagnostic-evidence-03.tar.gz'
assert sha(archive) == '9dfa415bf040187bcf222059e40abff516ba9ba7b9dac351c914bbba7884c489'
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(expected_names)
    assert {m.name for m in members} == expected_names
    for member in members:
        assert member.isfile()
        with tar.extractfile(member) as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha(E / member.name)
        assert member.size == (E / member.name).stat().st_size

final = read(E / 'configs-finalized.json')
assert sha(E / 'configs-finalized.json') == 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
assert final['source_restored'] is True
assert final['variant_sha256'] == {
    'baseline': 'a25d7c3e1678a4076b7006b1ca3880da116de8ba43b93f5b1c45c8fc260c8e47',
    'candidate': '060043e733873dfd9a27e29cdb526713479cc90079609b23df92ff088d469e90'}
for key, rel in [('protocol_sha256', 'work/benchmark/protocol.json'),
                 ('input_catalog_sha256', 'metadata/input-catalog.json'),
                 ('diagnostic_expectations_sha256', 'metadata/diagnostic-expectations.json'),
                 ('diagnostic_seal_sha256', 'metadata/diagnostic-seal.json')]:
    assert sha(E / rel) == final[key]
assert final['protocol_sha256'] == '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
for name, digest in final['config_sha256'].items():
    path = E / 'configs' / (name + '.json')
    assert sha(path) == digest
    before = read(path.with_name(name + '.prepared.json'))
    after = read(path)
    assert before.pop('pending_frozen_assets') == ['successful matched native/instrumented diagnostic expectations']
    old, new = set(before.pop('record_files')), set(after.pop('record_files'))
    assert before == after and old <= new
    assert new - old == {str(REMOTE / 'metadata/diagnostic-seal.json'), str(REMOTE / 'diagnostics/current179-preflight-03/manifest.json')}
assert len(final['config_sha256']) == 4
copied_assets = 0
for remote, digest in final['asset_sha256'].items():
    path = Path(remote)
    if path.is_relative_to(REMOTE) and str(path.relative_to(REMOTE)) in files:
        assert sha(E / path.relative_to(REMOTE)) == digest
        copied_assets += 1
seal = read(E / 'metadata/diagnostic-seal.json')
assert seal['diagnostic_directory'] == str(REMOTE / 'diagnostics/current179-preflight-03')
for rel, row in seal['files'].items():
    path = E / 'diagnostics/current179-preflight-03' / rel
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']

replay_path = LOCAL / 'diagnostic-03-raw-replay.json'
replay = read(replay_path)
assert sha(replay_path) == 'c77a5f9c09b9c3f840c9d1ff440c0f5cfd1935aed690134a86bab76a95b1b27c'
assert replay['review_script_sha256'] == sha(LOCAL / 'audit_diagnostic_evidence_03.py') == '55e961a312f5a2f4958d6343921930ff30b78a1ffecd61618da8e200938610d0'
assert replay['valid'] and replay['payloads_reverified'] == 612 and replay['comparative_samples'] == 0
assert replay['transfer_manifest_sha256'] == sha(transfer)
assert replay['finalized_sha256'] == sha(E / 'configs-finalized.json')
assert replay['final_configs'] == final['config_sha256'] and replay['variant_sha256'] == final['variant_sha256']
assert replay['cohort_sha256'] == 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
assert replay['check_preparation_proofs_replayed'] == 8
for key in ('all_final_before_checks_fresh_with_zero_child_work', 'all_measured_check_cases_exactly_one_uv_compiler', 'all_test_cases_two_source_four_rlink_no_tests_executed'):
    assert replay[key] is True
assert {(x['workload'], x['assignment'], x['metric'], x['variant']) for x in replay['diagnostics']} == set(itertools.product(('check', 'test'), ('forward', 'reverse'), ('ir', 'native'), ('baseline', 'candidate')))
identity = read(E / 'collection-identity.json')
assert identity['all_cohort_assets_verified'] and identity['diagnostics_complete']
assert identity['accepted_diagnostics'] == 16 and not identity['comparative_samples_exist']
assert identity['uv_status'] == '' and identity['uv_head'] == '3d82a6ad5a7eab8c68236553b7846517767c4b61'
assert sha(E / 'uv/crates/uv/src/lib.rs') == identity['source_sha256'] == 'ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81'
controller = E / 'work/benchmark/run_group.py'
assert sha(controller) == '562b39da92d29ba83f38eacc9e43a589f0a38fe0a29737b61d180b286dcdfc2a'
ast.parse(controller.read_text()); ast.parse((LOCAL / 'launch_group.py').read_text())
result = {
    'status': 'passed', 'reviewed_at': datetime.now(timezone.utc).isoformat(),
    'authorized_group': 'ir-confirmation', 'launcher_sha256': sha(LOCAL / 'launch_group.py'),
    'config_manifest_sha256': sha(E / 'configs-finalized.json'),
    'diagnostic_transfer_manifest_sha256': sha(transfer), 'archive_sha256': sha(archive),
    'verified_payloads': 612, 'verified_copied_final_assets': copied_assets,
    'independent_raw_replay_sha256': sha(replay_path), 'root_review_script_sha256': sha(__file__),
    'source_review': ['Both fixed workload batches and raw compiler/source audits finish before either analysis.',
                      'Twelve pairs and two warmup pairs per IR workflow; plans and thresholds remain frozen.',
                      'All 16 diagnostics, eight check convergence proofs, config derivation, and restored uv identity verified.',
                      'The launcher requires this exact source-bound review before any host action.',
                      'Native phase remains held for independent IR outcome review; historical samples are not pooled.'],
}
out = LOCAL / 'root-ir-confirmation-launch-review.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({'status': result['status'], 'verified_payloads': 612, 'copied_assets': copied_assets, 'review_sha256': sha(out)}))
