from pathlib import Path
import json,subprocess
LOCAL=Path(__file__).resolve().parent
code=r'''from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert json.loads((root/'ownership.json').read_text())=={'root':str(root),'uid':os.getuid(),'cohort':'current179-lazy-sbom'}
assert sha(root/'metadata/frozen-cohort.json')=='0d524bb20f7a1a41381c64e7991cb6a73935f42824d9768e20cc0b0bf0a4df9f'
assert sha(root/'work/benchmark/finalize_configs.py')=='feaf6f0f72165840c6c5f3f98784422f28dfed9628fa02e0400cf3c2b26fb119'
manifest=json.loads((root/'diagnostics/current179-preflight-02/manifest.json').read_text())
assert manifest['state']=='complete' and manifest['source_restored'] and len(manifest['runs'])==16
assert subprocess.run(['tmux','has-session','-t','ohm-sbom179-preflight-02'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
assert not (root/'configs-finalized.json').exists()
assert not list((root/'results').rglob('*'))
with (root/'logs/finalize-configs-02.stdout').open('xb') as out,(root/'logs/finalize-configs-02.stderr').open('xb') as err:
 result=subprocess.run(['env','-u','PYTHONPATH','-u','PYTHONHOME','-u','PYTHONSAFEPATH','PYTHONDONTWRITEBYTECODE=1','/usr/bin/python3',str(root/'work/benchmark/finalize_configs.py')],stdout=out,stderr=err)
record={'returncode':result.returncode,'stdout':(root/'logs/finalize-configs-02.stdout').read_text(),'stderr':(root/'logs/finalize-configs-02.stderr').read_text()}
if result.returncode==0:
 record['finalized_sha256']=sha(root/'configs-finalized.json');record['diagnostic_seal_sha256']=sha(root/'metadata/diagnostic-seal.json')
print(json.dumps(record,indent=2))
raise SystemExit(result.returncode)
'''
r=subprocess.run(['/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh','charlie-oss-4','--','env','-u','PYTHONPATH','-u','PYTHONHOME','-u','PYTHONSAFEPATH','PYTHONDONTWRITEBYTECODE=1','taskset','-c','8','/usr/bin/python3','-c',code],capture_output=True)
for suffix,data in (('stdout',r.stdout),('stderr',r.stderr)):
 with (LOCAL/('finalize-diagnostics-02.'+suffix)).open('xb') as stream:stream.write(data)
if r.returncode:raise SystemExit((r.stderr+r.stdout).decode(errors='replace'))
record=json.loads(r.stdout)
with (LOCAL/'finalize-diagnostics-02.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
