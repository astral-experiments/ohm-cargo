"""Read-only collection of a completed fixed comparison and all frozen diagnostic evidence."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import io
import json
import subprocess
import tarfile

LOCAL = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--finalized-sha256", required=True)
parser.add_argument("phase", choices=("ir-confirmation", "native-confirmation"))
args = parser.parse_args()
DEST = LOCAL / "evidence" / args.phase
SSH = "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh"
REMOTE = r'''
from pathlib import Path
from datetime import datetime, timezone
import hashlib, io, json, os, stat, subprocess, sys, tarfile
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
ownership = json.loads((root / 'ownership.json').read_text())
assert ownership['root'] == str(root) and ownership['uid'] == os.getuid()
cohort = json.loads((root / 'metadata/frozen-cohort.json').read_text())
assert sha(root / 'metadata/frozen-cohort.json') == 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
assert sha(root / 'configs-finalized.json') == sys.argv[1]
final = json.loads((root / 'configs-finalized.json').read_text())
assert sys.argv[1] == 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
phase = sys.argv[2]
assert phase in ('ir-confirmation', 'native-confirmation')
phase_status_path = root / 'results' / (phase + '.json')
phase_status_bytes = phase_status_path.read_bytes()
phase_state = json.loads(phase_status_bytes)
validated_result_files = {str(phase_status_path.relative_to(root)): hashlib.sha256(phase_status_bytes).hexdigest()}
assert phase_state['state'] == 'complete' and phase_state['group'] == phase
assert phase_state['completed_workloads'] == ['test', 'check'] and phase_state['source_restored']
assert phase_state['config_manifest_sha256'] == sys.argv[1]
assert phase_state['protocol_sha256'] == final['protocol_sha256']
assert subprocess.run(['tmux', 'has-session', '-t', 'ohm-sbom179-' + phase], capture_output=True).returncode == 1
protocol = json.loads((root / 'work/benchmark/protocol.json').read_text())
for workload in ('test', 'check'):
    name = workload + '-' + phase
    result = root / 'results' / name
    frozen_phase = next(row for row in protocol['phases'] if row['workload'] == workload and row['phase'] == 'confirmation' and (row['metric'] == 'cargo_ir') == phase.startswith('ir-'))
    run = json.loads((result / 'manifest.json').read_text())
    assert run['plans'] == {'measurement': frozen_phase['measurement_plan'], 'warmup': frozen_phase['warmup_plan']}
    assert run['sample_count'] == 2 * (frozen_phase['pairs'] + frozen_phase['warmup_pairs'])
    assert sha(root / 'configs' / (name + '.json')) == final['config_sha256'][name]
    seal_bytes = (result / 'seal.json').read_bytes()
    sealed = json.loads(seal_bytes)
    validated_result_files[str((result / 'seal.json').relative_to(root))] = hashlib.sha256(seal_bytes).hexdigest()
    assert {str(path.relative_to(result)) for path in result.rglob('*') if path.is_file() and path != result / 'seal.json'} == set(sealed)
    for relative, digest in sealed.items():
        path = result / relative
        assert path.resolve() == path and path.is_relative_to(result) and not path.is_symlink()
        assert sha(path) == digest
        validated_result_files[str(path.relative_to(root))] = digest
    assert phase_state['results'][workload]['analysis_sha256'] == sha(result / 'analysis.json')
    assert phase_state['results'][workload]['compiler_audit_sha256'] == sha(result / 'compiler-audit.json')
for path, digest in final['asset_sha256'].items():
    assert sha(path) == digest, path
expected = json.loads((root / 'metadata/diagnostic-expectations.json').read_text())
diagnostic = root / 'diagnostics/current179-preflight-03'
assert expected['diagnostic_directory'] == str(diagnostic)
complete = json.loads((diagnostic / 'manifest.json').read_text())
assert complete['state'] == 'complete' and complete['source_restored']
assert len(complete['runs']) == 16
assert {(row['workload'], row['assignment'], row['metric'], row['variant']) for row in complete['runs']} == {
    (workload, assignment, metric, variant) for workload in ('test', 'check')
    for assignment in ('forward', 'reverse') for metric in ('native', 'ir')
    for variant in ('baseline', 'candidate')}
assert complete['expectations_sha256'] == sha(root / 'metadata/diagnostic-expectations.json')
for row in complete['runs']:
    assert row['test_executables_run'] == []
    assert row['compiler_report']['compiler_stage_counts'] == ({'source': 2, 'rlink': 4} if row['workload'] == 'test' else {'source': 1})
seal = json.loads((root / 'metadata/diagnostic-seal.json').read_text())
assert seal['diagnostic_directory'] == str(diagnostic)
for relative, row in seal['files'].items():
    path = diagnostic / relative
    assert path.resolve() == path and path.is_relative_to(diagnostic)
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], relative
assert {str(path.relative_to(diagnostic)) for path in diagnostic.rglob('*') if path.is_file()} == set(seal['files'])
for path, digest in cohort['asset_sha256'].items():
    assert sha(path) == digest, path
selected = [root / name for name in (
    'ownership.json', 'setup.json', 'stage-assets.json', 'matched-pair.json',
    'metadata/frozen-cohort.json', 'metadata/preflight-fixture-bindings.json',
    'metadata/input-catalog.json', 'work/benchmark/source-guard.json',
    'work/benchmark/protocol.json', 'work/benchmark/environment.json',
    'work/benchmark/diagnostic-rules.json',
    'logs/helper-tests.stdout', 'logs/helper-tests.stderr')]
selected += sorted((root / 'configs').glob('*.json'))
selected += [path for path in sorted((root / 'fixtures').rglob('*')) if path.is_file()]
assert len(list((root / 'configs').glob('*.prepared.json'))) == 6
for directory in ('metadata', 'work/benchmark', 'amendments/context-v2', 'amendments/check-convergence', 'diagnostics', 'logs', 'build', 'results'):
    selected += [path for path in sorted((root / directory).rglob('*')) if path.is_file()]
selected += [root / name for name in ('setup_remote.py', 'prepare_configs.py', 'configs-finalized.json',
                                     'uv/Cargo.lock', 'uv/crates/uv/src/lib.rs')]
selected = sorted(set(selected))
payload, manifest = {}, {}
for path in selected:
    assert path.is_file() and not path.is_symlink(), path
    name = str(path.relative_to(root))
    data = path.read_bytes()
    payload[name] = data
    manifest[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                      'mode': stat.S_IMODE(path.stat().st_mode)}
def git(*args):
    return subprocess.check_output(['git', '-C', str(root / 'uv'), *args], text=True).strip()
assert git('rev-parse', 'HEAD') == '3d82a6ad5a7eab8c68236553b7846517767c4b61'
assert git('status', '--porcelain=v1') == ''
runtime = {}
recorded = {Path(path).resolve() for path in json.loads((root / 'configs/test-native-confirmation.prepared.json').read_text())['record_files']}
pair = json.loads((root / 'matched-pair.json').read_text())
for variant, row in pair['variants'].items():
    process = subprocess.run(['/usr/bin/ldd', row['binary']], capture_output=True, text=True, check=True)
    files = {}
    for line in process.stdout.splitlines():
        paths = [token for token in line.split() if token.startswith('/')]
        for value in paths:
            path = Path(value).resolve()
            assert path in recorded, str(path)
            files[str(path)] = sha(path)
    assert files
    runtime[variant] = {'stdout': process.stdout, 'stderr': process.stderr, 'files': files}
assert runtime['baseline']['files'] == runtime['candidate']['files']
identity = {
    'collected_at': datetime.now(timezone.utc).isoformat(), 'root': str(root),
    'uid': os.getuid(), 'uv_head': git('rev-parse', 'HEAD'), 'uv_status': git('status', '--porcelain=v1'),
    'source_sha256': sha(root / 'uv/crates/uv/src/lib.rs'),
    'cohort_sha256': sha(root / 'metadata/frozen-cohort.json'),
    'all_cohort_assets_verified': True, 'diagnostics_complete': True, 'accepted_diagnostics': 16, 'comparative_samples_exist': True, 'completed_phase': phase, 'phase_state_sha256': sha(root / 'results' / (phase + '.json')), 'finalized_sha256': sha(root / 'configs-finalized.json'),
    'variant_sha256': cohort['variant_sha256'], 'dynamic_libraries': runtime,
}
for name, data in payload.items():
    assert sha(root / name) == manifest[name]['sha256'], name
for name, expected in validated_result_files.items():
    assert name in payload
    assert hashlib.sha256(payload[name]).hexdigest() == expected, name
    assert sha(root / name) == expected, name
for path, digest in cohort['asset_sha256'].items():
    assert sha(path) == digest, path
assert sha(root / 'configs-finalized.json') == sys.argv[1]
for path, digest in final['asset_sha256'].items():
    assert sha(path) == digest, path
for relative, row in seal['files'].items():
    assert sha(diagnostic / relative) == row['sha256'], relative
payload['collection-identity.json'] = (json.dumps(identity, indent=2, sort_keys=True) + '\n').encode()
manifest['collection-identity.json'] = {'sha256': hashlib.sha256(payload['collection-identity.json']).hexdigest(), 'bytes': len(payload['collection-identity.json']), 'mode': 0o644}
payload['transfer-manifest.json'] = (json.dumps({'files': manifest}, indent=2, sort_keys=True) + '\n').encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for name, data in sorted(payload.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = manifest[name]['mode'] if name in manifest else 0o644
        archive.addfile(entry, io.BytesIO(data))
sys.stdout.buffer.write(buffer.getvalue())
'''

assert not DEST.exists(), DEST
process = subprocess.run([
    SSH, "charlie-oss-4", "--", "env", "-u", "PYTHONPATH", "-u", "PYTHONHOME",
    "-u", "PYTHONSAFEPATH", "PYTHONDONTWRITEBYTECODE=1", "taskset", "-c", "8",
    "/usr/bin/python3", "-c", REMOTE, args.finalized_sha256, args.phase,
], capture_output=True)
with (LOCAL / (args.phase + "-collection.stderr")).open("xb") as stream:
    stream.write(process.stderr)
if process.returncode:
    raise SystemExit(process.stderr.decode(errors="replace"))
with (LOCAL / (args.phase + "-evidence.tar.gz")).open("xb") as stream:
    stream.write(process.stdout)
with tarfile.open(fileobj=io.BytesIO(process.stdout), mode="r:gz") as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert len(set(names)) == len(names)
    manifest = json.load(archive.extractfile("transfer-manifest.json"))
    assert set(names) == set(manifest["files"]) | {"transfer-manifest.json"}
    DEST.mkdir(parents=True)
    for member in members:
        relative = PurePosixPath(member.name)
        assert member.isfile() and not relative.is_absolute() and ".." not in relative.parts
        data = archive.extractfile(member).read()
        if member.name in manifest["files"]:
            row = manifest["files"][member.name]
            assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
        destination = DEST.joinpath(*relative.parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(data)
        destination.chmod(member.mode)
receipt = {"valid": True, "files": len(manifest["files"]),
           "archive_sha256": hashlib.sha256(process.stdout).hexdigest(),
           "transfer_manifest_sha256": hashlib.sha256((DEST / "transfer-manifest.json").read_bytes()).hexdigest(),
           "cohort_sha256": hashlib.sha256((DEST / "metadata/frozen-cohort.json").read_bytes()).hexdigest()}
receipt["phase"] = args.phase
receipt["collector_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with (LOCAL / (args.phase + "-collection-receipt.json")).open("x") as stream:
    stream.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
