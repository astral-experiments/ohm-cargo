"""Collect completed untimed convergence diagnostics without executing Cargo."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
DEST = HERE / 'check-convergence-evidence'
REMOTE = r'''
from pathlib import Path
import fcntl, hashlib, io, json, os, sys, tarfile
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
directory = root / 'diagnostics/current179-check-convergence-01'
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
assert root.resolve() == root and root.stat().st_uid == os.getuid() == 1000
owner = json.loads((root / 'ownership.json').read_text())
assert owner['root'] == str(root) and owner['uid'] == os.getuid()
lock = (root / 'experiment.lock').open('r')
fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
manifest = json.loads((directory / 'manifest.json').read_text())
assert manifest['state'] == 'complete'
assert manifest['all_assets_verified_after'] and manifest['source_restored_unchanged']
assert manifest['controller_sha256'] == sha(directory / 'controller.py') == '9be3ae0c535b5d6fee4356a9a6aa4937ed9456b6710bcd88a74b73582fbdd834'
assert manifest['cohort_sha256'] == sha(root / 'metadata/frozen-cohort.json') == '0d524bb20f7a1a41381c64e7991cb6a73935f42824d9768e20cc0b0bf0a4df9f'
assert [(row['label'], row['returncode']) for row in manifest['runs']] == [('restored-source', 0), ('unchanged-source-repeat', 0)]
for row in manifest['runs']:
    for suffix in ('stdout', 'stderr', 'execve'):
        assert sha(directory / (row['label'] + '.' + suffix)) == row[suffix + '_sha256']
source = root / 'uv/crates/uv/src/lib.rs'
assert sha(source) == manifest['source_sha256'] == 'ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81'
assert source.stat().st_mtime_ns == manifest['source_mtime_ns']
assert not list((root / 'results').rglob('*'))
files = {}
for path in sorted(directory.iterdir()):
    assert path.is_file() and not path.is_symlink()
    files[path.name] = sha(path)
record = {'root': str(root), 'directory': str(directory), 'files': files,
          'scope': 'Untimed unchanged-source convergence diagnostics only; no comparative samples.'}
data = (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|') as archive:
    entry = tarfile.TarInfo('transfer-manifest.json'); entry.size = len(data); entry.mode = 0o644
    archive.addfile(entry, io.BytesIO(data))
    for name, digest in files.items():
        content = (directory / name).read_bytes()
        assert hashlib.sha256(content).hexdigest() == digest
        entry = tarfile.TarInfo('remote/' + name); entry.size = len(content); entry.mode = 0o644
        archive.addfile(entry, io.BytesIO(content))
for name, digest in files.items(): assert sha(directory / name) == digest
fcntl.flock(lock, fcntl.LOCK_UN)
'''


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


DEST.mkdir(exist_ok=False)
command = ['/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh',
           'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
           '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-c', REMOTE]
with (DEST / 'payload.tar').open('xb') as output, (DEST / 'transfer.stderr').open('xb') as error:
    process = subprocess.run(command, stdout=output, stderr=error)
transport = {'returncode': process.returncode, 'archive_sha256': sha(DEST / 'payload.tar'),
             'stderr_sha256': sha(DEST / 'transfer.stderr')}
(DEST / 'transport.json').write_text(json.dumps(transport, indent=2) + '\n')
assert process.returncode == 0, transport
with tarfile.open(DEST / 'payload.tar', 'r:') as archive:
    first = archive.next()
    assert first.name == 'transfer-manifest.json' and first.isfile()
    data = archive.extractfile(first).read()
    manifest = json.loads(data)
    (DEST / first.name).write_bytes(data)
    seen = set()
    for entry in iter(archive.next, None):
        path = Path(entry.name)
        assert entry.isfile() and not path.is_absolute() and '..' not in path.parts
        assert len(path.parts) == 2 and path.parts[0] == 'remote' and path.name in manifest['files']
        assert entry.name not in seen
        seen.add(entry.name)
        archive.extract(entry, DEST, filter='data')
        assert sha(DEST / path) == manifest['files'][path.name]
    assert seen == {'remote/' + name for name in manifest['files']}
receipt = {'status': 'passed', 'files': len(seen), 'transfer_manifest_sha256': sha(DEST / 'transfer-manifest.json'),
           'archive_sha256': transport['archive_sha256'], 'collector_sha256': sha(Path(__file__))}
(DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
