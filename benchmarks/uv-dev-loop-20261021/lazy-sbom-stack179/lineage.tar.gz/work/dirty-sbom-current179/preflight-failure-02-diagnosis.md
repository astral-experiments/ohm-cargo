The second current179 preflight stopped correctly because the first AFTER check compiled 45 workspace units instead of the declared single `uv` unit. This is not a parser-format failure. All eight preceding test diagnostics passed; no comparative performance samples exist.

The first rejected output was:

```
/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/targets/check/base/debug/build/workspaces/f44d6c46475f5ab0/v2-8218330fa4ebf267/uv-git/610751fd1e8fa92b/out
```

The preceding BEFORE preparation was the first check on this isolated target and ran 213 compiler commands. It built `uv-version` both as a native dependency of `uv-macros` and as a checked workspace library:

| Artifact | Unit directory | Emission | Recorded artifact mtime (UTC) |
| --- | --- | --- | --- |
| Native `uv-version` | `d257d5c3616703aa` | `dep-info,metadata,link` | 14:17:36.181502 |
| Checked `uv-version` | `f563a74b417e9f1e` | `dep-info,metadata` | 14:17:45.568466 |
| BEFORE `uv-git` | `d597b02e7aa525a5` | `dep-info,metadata` | 14:17:50.593447 |
| AFTER `uv-git` | `610751fd1e8fa92b` | `dep-info,metadata` | 14:18:12.160364 |

BEFORE `uv-git` imported the checked `f563…` metadata; AFTER imported the newly available native `d257…` metadata. The sole changed dependency outside the 45 recompiled units is this `uv_version` substitution. All 45 commands retain their scalar compiler flags, and `uv-git` retains `-Cmetadata=42158188a7c08a3a`; dependency paths, unit directories, and extra filenames change. Both `uv-version` compilations retain `-Cmetadata=babf6cc0f3f0e773`. The AFTER JSON reports the native `uv-version` artifact as fresh and contains no corresponding rustc execution.

The current source explains the transition:

- Pinned uv's `crates/uv-macros/Cargo.toml:21` depends on `uv-version`, requiring its native compilation for the procedural macro.
- `src/compiler/unit_dependencies.rs:357` can promote a check dependency to Build mode. The predicate at line 1231 explicitly includes owned workspace members.
- `src/compiler/build_runner/mod.rs:1562` validates the proposed native artifacts before rustc work; lines 1650–1653 require existing rlib/rmeta outputs and a fresh fingerprint. A cold target cannot initially validate the native artifact that the same invocation will later produce.
- `src/compiler/build_runner/compilation_files.rs:2616` incorporates dependency unit hashes into consumer unit hashes. The next invocation's newly eligible native dependency therefore changes downstream unit paths.

The recorded native `uv-version` provenance has `compiler_search_directories: []` and `loader_injected: false`. Its compiler driver and v2 context match the frozen inputs. The preparation and AFTER command derive the same configured environment and exact native command from the frozen config; the helper passes that environment through. Full child environments were not captured, so this evidence does not claim an independent byte-for-byte environment trace. The argument and artifact evidence supports first-check native-dependency promotion rather than a loader-variable mismatch.

All 210 retained payloads are in `failed-attempt-02/`; transfer manifest SHA256 is `d24afda41a4423c5a1c2ceab8a128704bd239ce32a02783ac6596319b868250a`. The full 45-unit argument/dependency chain is `preflight-failure-02-compiler-chain.json` (SHA256 `3ca3e7483e9d2dd30210d2b6b9243f21da722d635e62b028238ed4a85882f64c`). The four relevant unit directories' 34 file identities, timestamps, and selected loader provenance are in `preflight-failure-02-artifact-snapshot.json`. Original source bytes were restored to SHA256 `ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81`, and git is clean.

The authorized follow-up is two explicitly untimed checks with the restored source held byte- and mtime-identical: a restored-source check followed by an unchanged-source repeat. It will retain actual compiler/execve counts and all logs, without changing the one-unit edit requirement or any statistical setting. Its first launch stopped before Cargo at the occupancy guard because an unrelated compiler build began on host4 around 14:28. That stopped launch is retained as `check-convergence-01.*`; no convergence result exists yet.

If the unchanged-source repeat is fresh, a prospective setup amendment can require native prerequisite stabilization before the diagnostic matrix: unchanged source, unchanged binary/config/target binding, and a no-edit invocation with zero compiler executions and all artifacts fresh. The subsequent deterministic BEFORE→AFTER edit must still compile exactly the declared uv units in every diagnostic and measured sample. Eligibility of the eight already-passed test diagnostics remains unchanged pending the parent review.
