"""Launch one reviewed fixed group; never retry or inspect partial effects."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

LOCAL = Path(__file__).resolve().parent
SSH = "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh"
FINAL = "f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad"
REMOTE = r'''
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shlex, subprocess, sys
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
group = sys.argv[1]
assert group in ('ir-confirmation', 'native-confirmation')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert root.resolve() == root and root.stat().st_uid == os.getuid() == 1000
assert json.loads((root / 'ownership.json').read_text()) == {'root': str(root), 'uid': 1000, 'cohort': 'current179-lazy-sbom'}
assert sha(root / 'metadata/frozen-cohort.json') == 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
assert sha(root / 'configs-finalized.json') == 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
assert sha(root / 'work/benchmark/run_group.py') == '562b39da92d29ba83f38eacc9e43a589f0a38fe0a29737b61d180b286dcdfc2a'
assert sha(root / 'work/benchmark/protocol.json') == '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
protocol = json.loads((root / 'work/benchmark/protocol.json').read_text())
assert not (root / 'results' / (group + '.json')).exists()
for workflow in ('test', 'check'):
    assert not (root / 'results' / (workflow + '-' + group)).exists()
if group == 'ir-confirmation':
    assert not list((root / 'results').rglob('*'))
else:
    prior = json.loads((root / 'results/ir-confirmation.json').read_text())
    assert prior['state'] == 'complete' and prior['primary_passes'] and prior['source_restored']
    assert prior['config_manifest_sha256'] == sha(root / 'configs-finalized.json')
session = 'ohm-sbom179-' + group
assert subprocess.run(['tmux', 'has-session', '-t', session], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
probe = subprocess.Popen(['ps', '-eo', 'pid=,pcpu=,comm='], stdout=subprocess.PIPE, text=True)
processes, _ = probe.communicate()
assert probe.returncode == 0
excluded = {os.getpid(), probe.pid}
heavy = []
for line in processes.splitlines():
    parts = line.split(None, 2)
    if len(parts) != 3:
        continue
    pid, cpu, name = parts
    if int(pid) not in excluded and (name in {'rustc', 'cargo', 'clang', 'clang++', 'cc1', 'cc1plus', 'ld.lld', 'valgrind', 'callgrind-amd64'} or float(cpu) > 40):
        heavy.append({'pid': int(pid), 'cpu': float(cpu), 'comm': name})
assert not heavy, heavy
stdout = root / 'logs' / (group + '.controller.stdout')
stderr = root / 'logs' / (group + '.controller.stderr')
assert not stdout.exists() and not stderr.exists()
command = ['env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
           'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
           str(root / 'work/benchmark/run_group.py'), group]
launch = 'exec ' + shlex.join(command) + ' >' + shlex.quote(str(stdout)) + ' 2>' + shlex.quote(str(stderr))
subprocess.run(['tmux', 'new-session', '-d', '-s', session, '-c', str(root), launch], check=True)
print(json.dumps({'started_at': datetime.now(timezone.utc).isoformat(), 'root': str(root),
    'group': group, 'session': session, 'command': command, 'stdout': str(stdout), 'stderr': str(stderr),
    'heavy_processes_before': heavy, 'own_probe_excluded_pids': sorted(excluded),
    'config_manifest_sha256': sha(root / 'configs-finalized.json'),
    'purpose': 'Fixed test then check groups; no interim effects or altered sample counts.'}))
'''

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("group", choices=("ir-confirmation", "native-confirmation"))
parser.add_argument("--attempt", type=int, default=1)
args = parser.parse_args()
assert 1 <= args.attempt <= 99
name = f"launch-{args.group}-attempt{args.attempt:02d}"
assert all(not (LOCAL / (name + "." + suffix)).exists() for suffix in ("json", "stdout", "stderr"))
assert hashlib.sha256((LOCAL / "diagnostic-evidence-03/configs-finalized.json").read_bytes()).hexdigest() == FINAL
review_path = LOCAL / ("root-" + args.group + "-launch-review.json")
review = json.loads(review_path.read_text())
assert review["status"] == "passed" and review["authorized_group"] == args.group
assert review["config_manifest_sha256"] == FINAL
assert review["launcher_sha256"] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert review["diagnostic_transfer_manifest_sha256"] == hashlib.sha256(
    (LOCAL / "diagnostic-evidence-03/transfer-manifest.json").read_bytes()
).hexdigest()
process = subprocess.run([
    SSH, "charlie-oss-4", "--", "env", "-u", "PYTHONPATH", "-u", "PYTHONHOME", "-u",
    "PYTHONSAFEPATH", "PYTHONDONTWRITEBYTECODE=1", "/usr/bin/python3", "-c", REMOTE, args.group,
], capture_output=True)
for suffix, data in (("stdout", process.stdout), ("stderr", process.stderr)):
    with (LOCAL / (name + "." + suffix)).open("xb") as stream:
        stream.write(data)
record = {"returncode": process.returncode, "group": args.group, "attempt": args.attempt,
          "launcher_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "config_manifest_sha256": FINAL,
          "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
          "stderr_sha256": hashlib.sha256(process.stderr).hexdigest()}
if process.returncode == 0:
    record["launch"] = json.loads(process.stdout)
reviews = set(LOCAL.glob("root-*.json"))
for directory in ("context-v2", "check-convergence"):
    reviews.update((LOCAL / "amendments" / directory).glob("root-*.json"))
reviews.add(LOCAL / "diagnostic-03-raw-replay.json")
record["local_review_sha256"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(reviews)}
with (LOCAL / (name + ".json")).open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record, indent=2))
if process.returncode:
    raise SystemExit(process.stderr.decode(errors="replace"))
