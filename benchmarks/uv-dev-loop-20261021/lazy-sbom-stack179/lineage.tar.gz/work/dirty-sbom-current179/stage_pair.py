#!/usr/bin/env python3
"""Stage only the completed, independently audited host3 pair; run no Cargo."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BUILD = ROOT / 'work/production-build/host3-sbom-stack179'
REMOTE = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
NAMES = {'baseline': 'sbom-stack179-baseline', 'candidate': 'sbom-stack179-lazy'}
TREES = {'baseline': 'f4ce59f92aa17461fe3c8b68923c88539136045a',
         'candidate': 'c377ade816d378aa75f629313ac7b116da10c6da'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--review-seal-sha256', required=True)
args = parser.parse_args()
assert sha(HERE / 'review-seal.json') == args.review_seal_sha256
for relative, expected in json.loads((HERE / 'review-seal.json').read_text()).items():
    assert sha(HERE / relative) == expected, relative
audit = json.loads((BUILD / 'results/audit-pair.json').read_text())
assert audit['cohort'] == 'host3-sbom-stack179' and len(audit['records']) == 2
assert audit['frozen_input_manifest_sha256'] == sha(BUILD / 'frozen/manifest.json')
records = {row['variant']: row for row in audit['records']}
assert set(records) == set(NAMES.values())
variants, files = {}, {}
for variant, name in NAMES.items():
    binary = BUILD / 'results' / ('cargo-' + name)
    assert records[name]['stripped_sha256'] == sha(binary)
    assert records[name]['source_tree'] == TREES[variant]
    assert records[name]['common_build_inputs_sha256'] == audit['common_build_inputs_sha256']
    relative = 'binaries/' + binary.name
    files[relative] = binary
    variants[variant] = {'binary': str(REMOTE / relative), 'sha256': sha(binary),
                         'source_tree': TREES[variant]}
binary_names = {path.name for path in files.values()}
for path in sorted((BUILD / 'results').iterdir()):
    if path.is_file() and path.name not in binary_names:
        files['build/host3/' + path.name] = path
for path in sorted((BUILD / 'frozen').iterdir()):
    if path.is_file():
        files['build/host3/frozen/' + path.name] = path
for name in ('audit.py', 'collect_variant.py', 'provision.py', 'review-seal.json',
             'source-manifest.json', 'protocol-patch-identity-correction.json'):
    files['build/host3/' + name] = BUILD / name
files['build/source-publication.json'] = ROOT / 'work/sbom-current179-publication/code-publication.json'
expected = {name: {'sha256': sha(path), 'bytes': path.stat().st_size,
                   'mode': 0o755 if name.startswith('binaries/') else 0o644}
            for name, path in sorted(files.items())}
record = {'prepared_at': datetime.now(timezone.utc).isoformat(),
          'cohort': 'host3-sbom-stack179', 'root': str(REMOTE), 'variants': variants,
          'common_build_inputs_sha256': audit['common_build_inputs_sha256'],
          'files': expected, 'review_seal_sha256': args.review_seal_sha256,
          'no_cargo_or_measurement_launched': True}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected[name]['sha256']
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), expected[name]['mode'], 0
        archive.addfile(item, io.BytesIO(data))
remote = r'''
import hashlib,json,os,socket,sys,tarfile
from pathlib import Path
record=json.loads(sys.argv[1]);root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
assert socket.gethostname()=='charlie-oss-4' and os.getuid()==1000
assert root.resolve()==root and root.stat().st_uid==os.getuid()
assert json.loads((root/'ownership.json').read_text())=={'root':str(root),'uid':os.getuid(),'cohort':'current179-lazy-sbom'}
assert json.loads((root/'setup.json').read_text())['state']=='ready-for-matched-pair'
assert hashlib.sha256((root/'review-seal.json').read_bytes()).hexdigest()==record['review_seal_sha256']
assert record['root']==str(root) and not (root/'matched-pair.json').exists()
expected=record['files'];seen=set()
for relative in expected:
    path=root/relative
    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
    assert path.resolve()==path and not path.exists()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|') as archive:
    for item in archive:
        assert item.isfile() and item.name in expected and item.name not in seen
        data=archive.extractfile(item).read();entry=expected[item.name]
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
        path=root/item.name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(data)
        path.chmod(entry['mode']);seen.add(item.name)
assert seen==set(expected)
for relative,entry in expected.items():
    with (root/relative).open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
    assert actual==entry['sha256']
with (root/'matched-pair.json').open('x') as stream:stream.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({'state':'matched-pair-staged','variant_sha256':{name:row['sha256'] for name,row in record['variants'].items()},'files':len(expected)}))
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', '/usr/bin/python3', '-c', remote,
                         json.dumps(record, separators=(',', ':'))],
                        input=buffer.getvalue(), capture_output=True)
(HERE / 'stage-pair.stdout').write_bytes(result.stdout)
(HERE / 'stage-pair.stderr').write_bytes(result.stderr)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
if result.returncode == 0:
    with (HERE / 'matched-pair-transfer.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
raise SystemExit(result.returncode)
