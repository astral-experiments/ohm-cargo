from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
LOCAL=Path(__file__).resolve().parent
code=r'''from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
path=root/'diagnostics/current179-preflight-02/manifest.json'
r={'at':datetime.now(timezone.utc).isoformat(),'session_alive':subprocess.run(['tmux','has-session','-t','ohm-sbom179-preflight-02'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0}
try:
 m=json.loads(path.read_text())
 r.update({'state':m['state'],'completed_runs':len(m['runs']),'runs':[{'workload':x['workload'],'assignment':x['assignment'],'metric':x['metric'],'variant':x['variant'],'compiler_stages':x['compiler_report']['compiler_stage_counts']} for x in m['runs']]})
 for key in ('error','traceback','failure_restore_returncode','source_restored','expectations_sha256'):
  if key in m:r[key]=m[key]
except FileNotFoundError:r['state']='manifest_not_created_yet'
except json.JSONDecodeError:r['state']='manifest_write_in_progress'
print(json.dumps(r,indent=2))
'''
r=subprocess.run(['/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh','charlie-oss-4','--','env','-u','PYTHONPATH','-u','PYTHONHOME','-u','PYTHONSAFEPATH','/usr/bin/python3','-c',code],capture_output=True)
name='preflight-02-status-'+datetime.now(timezone.utc).strftime('%H%M%S%f')
for suffix,data in (('stdout',r.stdout),('stderr',r.stderr)):
 with (LOCAL/(name+'.'+suffix)).open('xb') as f:f.write(data)
if r.returncode:raise SystemExit(r.stderr.decode())
record=json.loads(r.stdout)
with (LOCAL/(name+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
