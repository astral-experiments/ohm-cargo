"""Launch the reviewed untimed diagnostic matrix; never acceptance samples."""
from pathlib import Path
import hashlib
import json
import subprocess

LOCAL = Path(__file__).resolve().parent
SSH = "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh"
REMOTE = r'''
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shlex, subprocess
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
session = 'ohm-sbom179-preflight-01'
assert json.loads((root / 'ownership.json').read_text())['uid'] == os.getuid() == 1000
assert hashlib.sha256((root / 'metadata/frozen-cohort.json').read_bytes()).hexdigest() == 'a7e4293b4eace14056099227ed6d9f3fbffe449082b648e91666e9d0a1b1e466'
assert not (root / 'diagnostics/current179-preflight-01').exists()
assert not (root / 'metadata/diagnostic-expectations.json').exists()
assert subprocess.run(['tmux', 'has-session', '-t', session], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
probe = subprocess.Popen(['ps', '-eo', 'pid=,pcpu=,comm='], stdout=subprocess.PIPE, text=True)
processes, _ = probe.communicate()
assert probe.returncode == 0
excluded = {os.getpid(), probe.pid}
heavy = []
for line in processes.splitlines():
    parts = line.split(None, 2)
    if len(parts) != 3:
        continue
    pid, cpu, name = parts
    if int(pid) in excluded:
        continue
    if name in {'rustc', 'cargo', 'clang', 'clang++', 'cc1', 'cc1plus', 'ld.lld', 'valgrind', 'callgrind-amd64'} or float(cpu) > 40:
        heavy.append({'pid': int(pid), 'cpu': float(cpu), 'comm': name})
assert not heavy, heavy
stdout = root / 'logs/current179-preflight-01.stdout'
stderr = root / 'logs/current179-preflight-01.stderr'
assert not stdout.exists() and not stderr.exists()
command = ['env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
           'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
           str(root / 'work/benchmark/dirty_preflight.py'), '--name', 'current179-preflight-01']
launch = 'exec ' + shlex.join(command) + ' >' + shlex.quote(str(stdout)) + ' 2>' + shlex.quote(str(stderr))
subprocess.run(['tmux', 'new-session', '-d', '-s', session, '-c', str(root), launch], check=True)
print(json.dumps({'started_at': datetime.now(timezone.utc).isoformat(), 'root': str(root),
    'session': session, 'command': command, 'stdout': str(stdout), 'stderr': str(stderr),
    'heavy_processes_before': heavy, 'own_probe_excluded_pids': sorted(excluded),
    'purpose': 'Approved untimed 16-way execution and signature diagnostics; no acceptance samples.'}))
'''

assert not (LOCAL / "preflight-launch-02.json").exists()
process = subprocess.run([
    SSH, "charlie-oss-4", "--", "env", "-u", "PYTHONPATH", "-u", "PYTHONHOME", "-u",
    "PYTHONSAFEPATH", "PYTHONDONTWRITEBYTECODE=1", "/usr/bin/python3", "-c", REMOTE,
], capture_output=True)
for name, data in (("stdout", process.stdout), ("stderr", process.stderr)):
    with (LOCAL / f"preflight-launch-02.{name}").open("xb") as stream:
        stream.write(data)
if process.returncode:
    raise SystemExit(process.stderr.decode(errors="replace"))
record = json.loads(process.stdout)
record["local_review_sha256"] = {
    str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (
        LOCAL / "root-generated-config-review.json",
        LOCAL.parent / "production-build/host3-sbom-stack179/root-pair-review.json",
    )
}
record["launcher_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with (LOCAL / "preflight-launch-02.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record, indent=2))
