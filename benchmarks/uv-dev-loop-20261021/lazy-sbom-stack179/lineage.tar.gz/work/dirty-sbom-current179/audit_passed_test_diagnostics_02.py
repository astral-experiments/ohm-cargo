"""Replay the eight retained test diagnostics without changing their eligibility."""
from pathlib import Path
from collections import Counter
import hashlib
import itertools
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "failed-attempt-02"
REMOTE = Path("/tmp/ohm-hillclimb-20261021/lazy-sbom-current179")
sys.path.insert(0, str(EVIDENCE / "work/benchmark"))
import dirty_audit_v2 as audit


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


transfer = json.loads((EVIDENCE / "transfer-manifest.json").read_text())
for name, row in transfer["files"].items():
    path = EVIDENCE / name
    assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"], name
assert sha(EVIDENCE / "work/benchmark/dirty_audit_v2.py") == "f906e5902034b5d81e7a53e4e2f2488dba9782d03460dbfac02ced6551b58907"
cohort = json.loads((EVIDENCE / "metadata/frozen-cohort.json").read_text())
manifest_path = EVIDENCE / "diagnostics/current179-preflight-02/manifest.json"
manifest = json.loads(manifest_path.read_text())
assert manifest["state"] == "failed" and manifest["failure_restore_returncode"] == 0
assert manifest["variant_sha256"] == cohort["variant_sha256"]
expected = set(itertools.product(("test",), ("forward", "reverse"), ("native", "ir"), ("baseline", "candidate")))
observed = {(row["workload"], row["assignment"], row["metric"], row["variant"]) for row in manifest["runs"]}
assert observed == expected and len(manifest["runs"]) == 8
rustc = "/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc"
package = "path+file:///tmp/ohm-hillclimb-20261021/lazy-sbom-current179/uv/crates/uv#0.13.4"
targets = {}
rows = []
for entry in manifest["runs"]:
    paths = {key: EVIDENCE / Path(entry[key]).relative_to(REMOTE) for key in ("stdout", "stderr", "execve")}
    phase = "diagnostic-forward" if entry["assignment"] == "forward" else "confirmation"
    config_path = EVIDENCE / f"configs/test-ir-{phase}.prepared.json"
    config = json.loads(config_path.read_text())
    target = config["variant_env"][entry["variant"]]["CARGO_TARGET_DIR"]
    report = audit.parse_run(paths["stdout"].read_text(), paths["stderr"].read_text(), target)
    assert report == entry["compiler_report"]
    assert len(report["compiler_commands"]) == 6
    assert Counter(row["input_kind"] for row in report["compiler_commands"]) == {"source": 2, "rlink": 4}
    audit.validate_run(report, rustc, package, targets.get(target))
    if targets:
        audit.validate_work_equivalence(report, next(iter(targets.values())))
    targets.setdefault(target, audit.target_expectation(report))
    executed = audit.validate_no_tests(report, paths["execve"].read_text())
    assert executed == entry["successful_execve_paths"] and executed.count(rustc) == 6
    assert entry["test_executables_run"] == []
    assert "test" in entry["command"] and "--no-run" in entry["command"]
    rows.append({
        "assignment": entry["assignment"], "metric": entry["metric"], "variant": entry["variant"],
        "target": target, "workspace_namespace": report["workspace_namespaces"],
        "compiler_stages": {"source": 2, "rlink": 4}, "rustc_execve_count": 6,
        "config_sha256": sha(config_path),
        "raw_file_sha256": {key: sha(path) for key, path in paths.items()},
    })
output = {
    "valid": True, "purpose": "Read-only replay of eight passed test diagnostics; eligibility unchanged",
    "comparative_samples": 0,
    "transfer_manifest_sha256": sha(EVIDENCE / "transfer-manifest.json"),
    "diagnostic_manifest_sha256": sha(manifest_path),
    "cohort_sha256": sha(EVIDENCE / "metadata/frozen-cohort.json"),
    "auditor_sha256": sha(EVIDENCE / "work/benchmark/dirty_audit_v2.py"),
    "protocol_sha256": sha(EVIDENCE / "work/benchmark/protocol.json"),
    "variant_sha256": cohort["variant_sha256"],
    "all_210_payloads_reverified": len(transfer["files"]) == 210,
    "test_targets": targets, "diagnostics": rows,
}
path = ROOT / "passed-test-diagnostics-02-audit.json"
with path.open("x") as stream:
    json.dump(output, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({"valid": True, "diagnostics": len(rows), "targets": list(targets),
                  "audit_sha256": sha(path)}, indent=2))
