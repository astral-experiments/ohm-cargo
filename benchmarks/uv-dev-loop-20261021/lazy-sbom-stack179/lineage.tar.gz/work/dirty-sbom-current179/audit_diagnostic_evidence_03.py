"""Replay all sixteen untimed cases and their fixed preparation proofs locally."""
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
LOCAL = Path(__file__).resolve().parent
EVIDENCE = LOCAL / "diagnostic-evidence-03"
REMOTE = Path("/tmp/ohm-hillclimb-20261021/lazy-sbom-current179")
COHORT = "f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736"
ORIGINAL = "ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def copied(remote):
    path = Path(remote)
    assert path.is_absolute() and path.is_relative_to(REMOTE) and ".." not in path.parts
    local = EVIDENCE / path.relative_to(REMOTE)
    assert local.is_file() and not local.is_symlink()
    return local


def content(original, batch, pair, position):
    # Reproduce the documented comment bytes independently of the fixture helper.
    batch_id = hashlib.sha256(batch.encode()).hexdigest()[:16]
    separator = b"\n" if original.endswith(b"\n") else b"\n\n"
    return original + separator + (
        f"// ohm-dev-loop-fixture batch={batch_id} stage=meas pair={pair:08d} state={position}\n"
    ).encode()


def preparation(entry, config, workload, assignment, metric, variant, audit):
    state = config["prepare_command"][config["prepare_command"].index("--state") + 1]
    state_manifest = read(copied(str(Path(state) / "manifest.json")))
    original_path = copied(str(Path(state) / "original.bin"))
    original = original_path.read_bytes()
    assert sha(original_path) == ORIGINAL == state_manifest["source_sha256"]
    assert read(copied(str(Path(state) / "state.json")))["restored"] is True
    batch = str(REMOTE / "diagnostics/current179-preflight-03" / f"{workload}-{assignment}")
    pair = 0 if metric == "native" else 1
    identity = {"batch": batch, "stage": "measurement", "pair": pair, "variant": variant}
    journal_path = copied(str(Path(state) / "journal.jsonl"))
    journal = [json.loads(line) for line in journal_path.read_text().splitlines()]
    matches = [row for row in journal if row["operation"] == "prepare"
               and all(row[key] == value for key, value in identity.items())]
    assert len(matches) == 1
    prepared = matches[0]
    target = config["variant_env"][variant]["CARGO_TARGET_DIR"]
    assert prepared["target"] == state_manifest["targets"][variant] == target
    assert prepared["shared_build_dir"] == state_manifest["shared_build_dir"] == str(REMOTE / "shared")
    for position, key in (("before", "before"), ("after_", "after")):
        data = content(original, batch, pair, position)
        assert prepared[key + "_sha256"] == hashlib.sha256(data).hexdigest()
        assert prepared[key + "_bytes"] == len(data)
    assert prepared["before_bytes"] == prepared["after_bytes"]
    assert prepared["before_sha256"] != prepared["after_sha256"]
    native = ["taskset", "-c", "0-7", str(REMOTE / "active/bin/cargo"), "-Zohm-defaults=yes", workload]
    if workload == "test":
        native.append("--no-run")
    native += ["--locked", "--offline", "-j", "8", "--message-format=json", "-v"]
    assert prepared["warm_command"] == native
    base = {"journal_sha256": sha(journal_path), "before_sha256": prepared["before_sha256"],
            "after_sha256": prepared["after_sha256"], "equal_length_edit_bytes": prepared["before_bytes"],
            "native_before_command": native}
    if workload == "test":
        assert entry["check_preparation"] is None and "preparation_proof" not in prepared
        return {**base, "native_before_calls": 1}
    directory = Path(batch) / "check-preparation" / f"measurement-{pair:08d}-{variant}"
    proof_path = copied(str(directory / "manifest.json"))
    expected_pointer = {"path": str(directory / "manifest.json"), "sha256": sha(proof_path)}
    assert prepared["preparation_proof"] == expected_pointer
    proof = read(proof_path)
    assert proof["state"] == "complete" and proof["fixed_native_calls"] == 3
    assert proof["identity"] == identity and proof["command"] == native
    assert proof["target"] == target and proof["shared_build_dir"] == prepared["shared_build_dir"]
    assert proof["source"]["path"] == state_manifest["source"]
    assert proof["source"]["sha256"] == prepared["before_sha256"]
    assert proof["source"]["bytes"] == prepared["before_bytes"]
    assert proof["source"]["mode"] == state_manifest["source_mode"]
    assert proof["source"]["mtime_ns"] < prepared["source_mtime_ns"]
    assert re.fullmatch("[0-9a-f]{64}", proof["environment_sha256"])
    assert [(row["number"], row["returncode"]) for row in proof["calls"]] == [(1, 0), (2, 0), (3, 0)]
    raw = {}
    for call in proof["calls"]:
        for suffix in ("stdout", "stderr", "execve") if call["number"] == 3 else ("stdout", "stderr"):
            name = f"call-{call['number']}.{suffix}"
            path = copied(str(directory / name))
            assert sha(path) == call[suffix + "_sha256"]
            raw[name] = sha(path)
        messages = [json.loads(line) for line in copied(str(directory / f"call-{call['number']}.stdout")).read_text().splitlines()]
        assert [row for row in messages if row.get("reason") == "build-finished"] == [{"reason": "build-finished", "success": True}]
    allowed = ["/usr/bin/taskset", str(REMOTE / "active/bin/cargo")]
    assert proof["allowed_final_executables"] == allowed
    executed = audit.trace_executables(copied(str(directory / "call-3.execve")).read_text())
    assert executed == allowed
    stderr = copied(str(directory / "call-3.stderr")).read_text()
    assert not re.search(r"^\s*Running `", stderr, re.MULTILINE)
    assert messages[-1] == {"reason": "build-finished", "success": True}
    artifacts = [row for row in messages if row.get("reason") == "compiler-artifact"]
    assert artifacts and all(row.get("fresh") is True for row in artifacts)
    freshness = {"artifact_records": len(artifacts), "all_artifacts_fresh": True,
                 "successful_execve_paths": executed, "compiler_build_script_test_executions": 0}
    assert proof["final_freshness"] == freshness
    assert entry["check_preparation"] == {"proof": expected_pointer, "fixed_native_calls": 3, **freshness}
    return {**base, "native_before_calls": 3, "proof": expected_pointer,
            "raw_file_sha256": raw, "freshness": freshness}


def main():
    transfer = read(EVIDENCE / "transfer-manifest.json")
    for name, row in transfer["files"].items():
        path = EVIDENCE / name
        assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"], name
    assert sha(EVIDENCE / "metadata/frozen-cohort.json") == COHORT
    cohort = read(EVIDENCE / "metadata/frozen-cohort.json")
    auditor_path = EVIDENCE / "work/benchmark/dirty_audit_v2.py"
    assert sha(auditor_path) == cohort["asset_sha256"][str(REMOTE / "work/benchmark/dirty_audit_v2.py")]
    sys.path.insert(0, str(auditor_path.parent))
    import dirty_audit_v2 as audit
    manifest_path = EVIDENCE / "diagnostics/current179-preflight-03/manifest.json"
    manifest = read(manifest_path)
    assert manifest["state"] == "complete" and manifest["source_restored"] is True
    assert manifest["variant_sha256"] == cohort["variant_sha256"]
    expected_cases = list(itertools.product(("test", "check"), ("forward", "reverse"),
                                            ("native", "ir"), ("baseline", "candidate")))
    assert [(row["workload"], row["assignment"], row["metric"], row["variant"]) for row in manifest["runs"]] == expected_cases
    frozen = read(EVIDENCE / "metadata/diagnostic-expectations.json")
    assert sha(EVIDENCE / "metadata/diagnostic-expectations.json") == manifest["expectations_sha256"]
    assert frozen["rustc"] == "/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc"
    assert frozen["uv_package"] == "path+file:///tmp/ohm-hillclimb-20261021/lazy-sbom-current179/uv/crates/uv#0.13.4"
    seal = read(EVIDENCE / "metadata/diagnostic-seal.json")
    assert seal["diagnostic_directory"] == str(REMOTE / "diagnostics/current179-preflight-03")
    directory = manifest_path.parent
    assert {str(path.relative_to(directory)) for path in directory.rglob("*") if path.is_file()} == set(seal["files"])
    for name, row in seal["files"].items():
        assert sha(directory / name) == row["sha256"] and (directory / name).stat().st_size == row["bytes"]
    targets = {"test": {}, "check": {}}
    rows = []
    for entry in manifest["runs"]:
        workload, assignment, metric, variant = (entry[key] for key in ("workload", "assignment", "metric", "variant"))
        phase = "diagnostic-forward" if assignment == "forward" else "confirmation"
        config_path = EVIDENCE / f"configs/{workload}-ir-{phase}.prepared.json"
        config = read(config_path)
        target = config["variant_env"][variant]["CARGO_TARGET_DIR"]
        raw = {key: copied(entry[key]) for key in ("stdout", "stderr", "execve")}
        report = audit.parse_run(raw["stdout"].read_text(), raw["stderr"].read_text(), target)
        assert report == entry["compiler_report"]
        stages = {"source": 2, "rlink": 4} if workload == "test" else {"source": 1}
        assert Counter(row["input_kind"] for row in report["compiler_commands"]) == stages
        audit.validate_run(report, frozen["rustc"], frozen["uv_package"], targets[workload].get(target))
        if targets[workload]:
            audit.validate_work_equivalence(report, next(iter(targets[workload].values())))
        targets[workload].setdefault(target, audit.target_expectation(report))
        executed = audit.validate_no_tests(report, raw["execve"].read_text())
        assert executed == entry["successful_execve_paths"]
        assert executed.count(frozen["rustc"]) == sum(stages.values())
        assert entry["test_executables_run"] == [] and workload in entry["command"]
        if workload == "test":
            assert "--no-run" in entry["command"]
        prep = preparation(entry, config, workload, assignment, metric, variant, audit)
        profile_sha256 = None
        if metric == "native":
            assert entry["command"] == prep["native_before_command"]
        else:
            batch = str(REMOTE / "diagnostics/current179-preflight-03" / f"{workload}-{assignment}")
            context = {"cargo": str(REMOTE / "active/bin/cargo"), "variant": variant, "pair": 1,
                       "stage": "measurement", "phase": "diagnostic", "output": batch,
                       "position": 0 if variant == "baseline" else 1}
            command = list(config["command"])
            for key, value in context.items():
                command = [part.replace("{" + key + "}", str(value)) for part in command]
            assert entry["command"] == command and "--trace-children=no" in command
            profile = copied(str(Path(batch) / f"callgrind-measurement-1-{variant}.out"))
            lines = profile.read_text().splitlines()
            events = [line.partition(":")[2].split() for line in lines if line.startswith("events:")]
            summaries = [line.partition(":")[2].split() for line in lines if line.startswith("summary:")]
            assert len(events) == len(summaries) == 1
            assert len(set(events[0])) == len(events[0]) == len(summaries[0]) and "Ir" in events[0]
            values = [int(value) for value in summaries[0]]
            assert all(value >= 0 for value in values) and values[events[0].index("Ir")] > 0
            profile_sha256 = sha(profile)
        rows.append({"workload": workload, "assignment": assignment, "metric": metric, "variant": variant,
                     "target": target, "workspace_namespace": report["workspace_namespaces"],
                     "compiler_stages": stages, "rustc_execve_count": sum(stages.values()),
                     "config_sha256": sha(config_path), "raw_file_sha256": {key: sha(path) for key, path in raw.items()},
                     "preparation": prep, "diagnostic_profile_sha256": profile_sha256})
    assert frozen["workloads"] == {name: {"targets": values} for name, values in targets.items()}
    assert all(len(values) == 2 for values in targets.values())
    final = read(EVIDENCE / "configs-finalized.json")
    assert final["diagnostic_seal_sha256"] == sha(EVIDENCE / "metadata/diagnostic-seal.json")
    assert final["diagnostic_expectations_sha256"] == sha(EVIDENCE / "metadata/diagnostic-expectations.json")
    for name, digest in final["asset_sha256"].items():
        remote = Path(name)
        if remote.is_relative_to(REMOTE) and str(remote.relative_to(REMOTE)) in transfer["files"]:
            assert sha(copied(name)) == digest
    configs = {}
    for name, digest in final["config_sha256"].items():
        path = EVIDENCE / "configs" / (name + ".json")
        assert sha(path) == digest
        before = read(path.with_name(name + ".prepared.json"))
        after = read(path)
        assert before.pop("pending_frozen_assets") == ["successful matched native/instrumented diagnostic expectations"]
        old_records, new_records = set(before.pop("record_files")), set(after.pop("record_files"))
        assert before == after
        assert new_records - old_records == {str(REMOTE / "metadata/diagnostic-seal.json"),
                                             str(REMOTE / "diagnostics/current179-preflight-03/manifest.json")}
        assert old_records <= new_records
        configs[name] = digest
    assert len(configs) == 4 and final["source_restored"] is True
    assert sha(EVIDENCE / "uv/crates/uv/src/lib.rs") == ORIGINAL
    # Close the read-only replay against the exact collected bytes.
    for name, row in transfer["files"].items():
        assert sha(EVIDENCE / name) == row["sha256"]
    result = {"valid": True, "scope": "Independent local raw replay; no performance statistics or workload execution",
              "comparative_samples": 0, "diagnostics": rows, "target_expectations": targets,
              "payloads_reverified": len(transfer["files"]), "check_preparation_proofs_replayed": 8,
              "all_final_before_checks_fresh_with_zero_child_work": True,
              "all_measured_check_cases_exactly_one_uv_compiler": True,
              "all_test_cases_two_source_four_rlink_no_tests_executed": True,
              "cohort_sha256": COHORT, "variant_sha256": cohort["variant_sha256"],
              "transfer_manifest_sha256": sha(EVIDENCE / "transfer-manifest.json"),
              "diagnostic_manifest_sha256": sha(manifest_path), "auditor_sha256": sha(auditor_path),
              "finalized_sha256": sha(EVIDENCE / "configs-finalized.json"), "final_configs": configs,
              "review_script_sha256": sha(Path(__file__))}
    path = LOCAL / "diagnostic-03-raw-replay.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"valid": True, "diagnostics": len(rows), "check_proofs": 8,
                      "audit_sha256": sha(path)}, indent=2))


if __name__ == "__main__":
    main()
