from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess
p=Path(__file__).resolve().parent
name='ir-terminal-'+datetime.now(timezone.utc).strftime('%H%M%S%f')
remote="if tmux has-session -t ohm-sbom179-ir-confirmation 2>/dev/null; then printf '%s\n' '{\"session_active\":true}'; else cat /tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-confirmation.json; fi"
args=['/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh','charlie-oss-4','--','/bin/sh','-c',remote]
r=subprocess.run(args,capture_output=True)
for ext,data in [('stdout',r.stdout),('stderr',r.stderr)]:
 with (p/(name+'.'+ext)).open('xb') as f:f.write(data)
record={'observed_at':datetime.now(timezone.utc).isoformat(),'returncode':r.returncode,'command':args,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
with (p/(name+'.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'receipt':str(p/(name+'.json')),'returncode':r.returncode}))
if r.returncode:raise SystemExit(r.stderr.decode(errors='replace'))
d=json.loads(r.stdout)
print(json.dumps({k:d[k] for k in ('session_active','state','group','started_at','finished_at','completed_workloads') if k in d}))
