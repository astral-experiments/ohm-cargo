"""Read-only collection of resealed current179 inputs before diagnostic restart."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import io
import json
import subprocess
import tarfile

LOCAL = Path(__file__).resolve().parent
DEST = LOCAL / "amended-inputs-context-v2"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--cohort-sha256", required=True)
args = parser.parse_args()
SSH = "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh"
REMOTE = r'''
from pathlib import Path
from datetime import datetime, timezone
import hashlib, io, json, os, stat, subprocess, sys, tarfile
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
ownership = json.loads((root / 'ownership.json').read_text())
assert ownership['root'] == str(root) and ownership['uid'] == os.getuid()
cohort = json.loads((root / 'metadata/frozen-cohort.json').read_text())
assert sha(root / 'metadata/frozen-cohort.json') == sys.argv[1]
assert cohort['previous_frozen_cohort_sha256'] == 'a7e4293b4eace14056099227ed6d9f3fbffe449082b648e91666e9d0a1b1e466'
assert cohort['context_parser_amendment_sha256'] == 'a427e7bd94b0d4c278b108b288a318f6521cbe70e16a184f8fec15d9ebd8e8cb'
failed = json.loads((root / 'diagnostics/current179-preflight-01/manifest.json').read_text())
assert failed['state'] == 'failed' and failed['runs'] == [] and failed['failure_restore_returncode'] == 0
assert not list((root / 'results').rglob('*'))
assert not (root / 'configs-finalized.json').exists()
assert not (root / 'metadata/diagnostic-expectations.json').exists()
for path, digest in cohort['asset_sha256'].items():
    assert sha(path) == digest, path
selected = [root / name for name in (
    'ownership.json', 'setup.json', 'stage-assets.json', 'matched-pair.json',
    'metadata/frozen-cohort.json', 'metadata/preflight-fixture-bindings.json',
    'metadata/input-catalog.json', 'work/benchmark/source-guard.json',
    'work/benchmark/protocol.json', 'work/benchmark/environment.json',
    'work/benchmark/diagnostic-rules.json',
    'logs/helper-tests.stdout', 'logs/helper-tests.stderr')]
selected += sorted((root / 'configs').glob('*.prepared.json'))
selected += [path for path in sorted((root / 'fixtures').rglob('*')) if path.is_file()]
assert len(list((root / 'configs').glob('*.prepared.json'))) == 6
selected += [path for path in sorted((root / 'amendments/context-v2').rglob('*')) if path.is_file()]
selected += [path for path in sorted((root / 'work/benchmark').glob('*')) if path.is_file()]
selected += [root / name for name in ('setup_remote.py', 'prepare_configs.py', 'metadata/context-v2-amendment.json')]
selected = sorted(set(selected))
payload, manifest = {}, {}
for path in selected:
    assert path.is_file() and not path.is_symlink(), path
    name = str(path.relative_to(root))
    data = path.read_bytes()
    payload[name] = data
    manifest[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                      'mode': stat.S_IMODE(path.stat().st_mode)}
def git(*args):
    return subprocess.check_output(['git', '-C', str(root / 'uv'), *args], text=True).strip()
assert git('rev-parse', 'HEAD') == '3d82a6ad5a7eab8c68236553b7846517767c4b61'
assert git('status', '--porcelain=v1') == ''
runtime = {}
recorded = {Path(path).resolve() for path in json.loads((root / 'configs/test-native-confirmation.prepared.json').read_text())['record_files']}
pair = json.loads((root / 'matched-pair.json').read_text())
for variant, row in pair['variants'].items():
    process = subprocess.run(['/usr/bin/ldd', row['binary']], capture_output=True, text=True, check=True)
    files = {}
    for line in process.stdout.splitlines():
        paths = [token for token in line.split() if token.startswith('/')]
        for value in paths:
            path = Path(value).resolve()
            assert path in recorded, str(path)
            files[str(path)] = sha(path)
    assert files
    runtime[variant] = {'stdout': process.stdout, 'stderr': process.stderr, 'files': files}
assert runtime['baseline']['files'] == runtime['candidate']['files']
identity = {
    'collected_at': datetime.now(timezone.utc).isoformat(), 'root': str(root),
    'uid': os.getuid(), 'uv_head': git('rev-parse', 'HEAD'), 'uv_status': git('status', '--porcelain=v1'),
    'source_sha256': sha(root / 'uv/crates/uv/src/lib.rs'),
    'cohort_sha256': sha(root / 'metadata/frozen-cohort.json'),
    'all_cohort_assets_verified': True, 'pending_diagnostic_restart': True, 'prior_failed_attempts': 1, 'accepted_diagnostics': 0, 'comparative_samples_exist': False,
    'variant_sha256': cohort['variant_sha256'], 'dynamic_libraries': runtime,
}
for name, data in payload.items():
    assert sha(root / name) == manifest[name]['sha256'], name
for path, digest in cohort['asset_sha256'].items():
    assert sha(path) == digest, path
payload['collection-identity.json'] = (json.dumps(identity, indent=2, sort_keys=True) + '\n').encode()
manifest['collection-identity.json'] = {'sha256': hashlib.sha256(payload['collection-identity.json']).hexdigest(), 'bytes': len(payload['collection-identity.json']), 'mode': 0o644}
payload['transfer-manifest.json'] = (json.dumps({'files': manifest}, indent=2, sort_keys=True) + '\n').encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for name, data in sorted(payload.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = manifest[name]['mode'] if name in manifest else 0o644
        archive.addfile(entry, io.BytesIO(data))
sys.stdout.buffer.write(buffer.getvalue())
'''

assert not DEST.exists(), DEST
process = subprocess.run([
    SSH, "charlie-oss-4", "--", "env", "-u", "PYTHONPATH", "-u", "PYTHONHOME",
    "-u", "PYTHONSAFEPATH", "PYTHONDONTWRITEBYTECODE=1", "taskset", "-c", "8",
    "/usr/bin/python3", "-c", REMOTE, args.cohort_sha256,
], capture_output=True)
(LOCAL / "amended-inputs-context-v2-collection.stderr").write_bytes(process.stderr)
if process.returncode:
    raise SystemExit(process.stderr.decode(errors="replace"))
with (LOCAL / "amended-inputs-context-v2.tar.gz").open("xb") as stream:
    stream.write(process.stdout)
with tarfile.open(fileobj=io.BytesIO(process.stdout), mode="r:gz") as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert len(set(names)) == len(names)
    manifest = json.load(archive.extractfile("transfer-manifest.json"))
    assert set(names) == set(manifest["files"]) | {"transfer-manifest.json"}
    DEST.mkdir()
    for member in members:
        relative = PurePosixPath(member.name)
        assert member.isfile() and not relative.is_absolute() and ".." not in relative.parts
        data = archive.extractfile(member).read()
        if member.name in manifest["files"]:
            row = manifest["files"][member.name]
            assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
        destination = DEST.joinpath(*relative.parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(data)
        destination.chmod(member.mode)
receipt = {"valid": True, "files": len(manifest["files"]),
           "archive_sha256": hashlib.sha256(process.stdout).hexdigest(),
           "transfer_manifest_sha256": hashlib.sha256((DEST / "transfer-manifest.json").read_bytes()).hexdigest(),
           "cohort_sha256": hashlib.sha256((DEST / "metadata/frozen-cohort.json").read_bytes()).hexdigest()}
(LOCAL / "amended-inputs-context-v2-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
