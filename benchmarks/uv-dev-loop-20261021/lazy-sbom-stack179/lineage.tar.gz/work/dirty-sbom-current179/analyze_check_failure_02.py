"""Read-only compiler argument comparison for the retained failed check diagnostic."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shlex

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "failed-attempt-02/diagnostics/current179-preflight-02/logs"
PREFIX = "check-forward-native-baseline"


def parse(path):
    rows = {}
    other_rustc = []
    for line in path.read_text().splitlines():
        match = re.match(r"^\s*Running `(.+)`$", line)
        if not match:
            continue
        args = shlex.split(match[1])
        if "--crate-name" not in args:
            continue
        name = args[args.index("--crate-name") + 1]
        if "--out-dir" not in args:
            other_rustc.append(args)
            continue
        source = next((x for x in args if x.endswith(".rs") and not x.startswith("-")), None)
        kind = args[args.index("--crate-type") + 1] if "--crate-type" in args else None
        externs = {}
        for index, arg in enumerate(args[:-1]):
            if arg == "--extern":
                dependency, separator, value = args[index + 1].partition("=")
                externs[dependency] = value if separator else None
        out = args[args.index("--out-dir") + 1]
        scalars = []
        skip = False
        for index, arg in enumerate(args):
            if skip:
                skip = False
                continue
            if arg in ("--out-dir", "--extern", "-L"):
                skip = True
                continue
            if arg == "-C" and args[index + 1].startswith(("metadata=", "extra-filename=")):
                skip = True
                continue
            scalars.append(arg)
        emit = next((arg for arg in args if arg.startswith("--emit=")), None)
        target = args[args.index("--target") + 1] if "--target" in args else None
        cfgs = tuple(sorted(args[index + 1] for index, arg in enumerate(args[:-1]) if arg == "--cfg"))
        key = (name, source, kind, "--test" in args, emit, target, cfgs)
        assert key not in rows, key
        rows[key] = {"args": args, "externs": externs, "out": out, "scalars": scalars}
    return rows, other_rustc


before_path = LOGS / (PREFIX + ".prepare.stderr")
after_path = LOGS / (PREFIX + ".stderr")
before, before_other = parse(before_path)
after, after_other = parse(after_path)
changes = []
for key, new in after.items():
    old = before.get(key)
    if old is None:
        changes.append({"key": key, "absent_before": True})
        continue
    changed = {
        name: {"before": old["externs"].get(name), "after": new["externs"].get(name)}
        for name in sorted(set(old["externs"]) | set(new["externs"]))
        if old["externs"].get(name) != new["externs"].get(name)
    }
    changes.append({
        "key": key, "before_out": old["out"], "after_out": new["out"],
        "scalar_diff": list(difflib.unified_diff(old["scalars"], new["scalars"], lineterm="")),
        "changed_externs": changed,
        "exact_argument_diff": list(difflib.unified_diff(old["args"], new["args"], lineterm="")),
    })

report = {
    "purpose": "Diagnostic-only argument/path comparison; no performance analysis or eligibility change",
    "log_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                   for path in (before_path, after_path)},
    "before_count": len(before), "after_count": len(after),
    "before_other_rustc": before_other, "after_other_rustc": after_other,
    "changes": changes,
    "before_dirty_lines": [line for line in before_path.read_text().splitlines()
                           if re.match(r"^\s*Dirty\b", line)],
    "after_dirty_lines": [line for line in after_path.read_text().splitlines()
                          if re.match(r"^\s*Dirty\b", line)],
}
output = ROOT / "preflight-failure-02-compiler-chain.json"
with output.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps({
    "before_count": len(before), "after_count": len(after),
    "first_change": {key: value for key, value in changes[0].items() if key != "exact_argument_diff"},
    "root_changes": [row["key"] for row in changes if not row.get("changed_externs")],
    "report_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
}, indent=2))
