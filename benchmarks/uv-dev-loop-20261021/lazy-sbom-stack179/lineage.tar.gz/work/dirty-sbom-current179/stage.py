#!/usr/bin/env python3
"""Transfer only frozen setup inputs and launch setup in the owned host4 root."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--review-seal-sha256', required=True)
args = parser.parse_args()
seal_path = HERE / 'review-seal.json'
assert hashlib.sha256(seal_path.read_bytes()).hexdigest() == args.review_seal_sha256
for relative, expected in json.loads(seal_path.read_text()).items():
    assert hashlib.sha256((HERE / relative).read_bytes()).hexdigest() == expected, relative
files = {f'work/benchmark/{path.name}': path for path in (HERE / 'frozen').iterdir() if path.is_file()}
files.update({
    'work/benchmark/protocol.json': HERE / 'protocol.json',
    'setup_remote.py': HERE / 'setup_remote.py',
    'prepare_configs.py': HERE / 'prepare_configs.py',
    'review-seal.json': HERE / 'review-seal.json',
    'profiling-tools/valgrind.deb': ROOT / 'work/profiling-tools/valgrind_1%3a3.22.0-0ubuntu3_amd64.deb',
    'profiling-tools/libc6-dbg.deb': ROOT / 'work/profiling-tools/libc6-dbg_2.39-0ubuntu8.9_amd64.deb',
    'profiling-tools/ohm-valgrind-env.c': ROOT / 'work/profiling-tools/ohm-valgrind-env.c',
    'profiling-tools/ohm-valgrind-env.so': ROOT / 'work/profiling-tools/ohm-valgrind-env.so',
    'build/source-manifest.json': ROOT / 'work/production-build/host3-sbom-stack179/source-manifest.json',
})
expected = {}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        expected[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        item = tarfile.TarInfo(name); item.mode = 0o644; item.size = len(data); item.mtime = 0
        archive.addfile(item, io.BytesIO(data))
(HERE / 'stage-assets.json').write_text(json.dumps(expected, indent=2) + '\n')
remote = r'''
import hashlib,json,os,socket,subprocess,sys,tarfile
from pathlib import Path
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
expected=json.loads(sys.argv[1])
assert os.getuid()==1000 and socket.gethostname()=='charlie-oss-4'
assert root.parent.resolve()==root.parent and root.parent.stat().st_uid==os.getuid()
assert not root.exists(), 'new dedicated dirty experiment root required'
root.mkdir(mode=0o700)
(root/'ownership.json').write_text(json.dumps({'root':str(root),'uid':os.getuid(),'cohort':'current179-lazy-sbom'},indent=2)+'\n')
seen=set()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|') as archive:
    for item in archive:
        assert item.isfile() and item.name in expected and item.name not in seen
        assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        data=archive.extractfile(item).read();record=expected[item.name]
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
        path=root/item.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(0o644);seen.add(item.name)
assert seen==set(expected)
(root/'stage-assets.json').write_text(json.dumps(expected,indent=2)+'\n')
launcher=root/'run-setup.sh'
launcher.write_text('#!/bin/bash\nset -euo pipefail\nexec env -u PYTHONPATH -u PYTHONHOME -u PYTHONSAFEPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 '+str(root/'setup_remote.py')+' >'+str(root/'setup.log')+' 2>&1\n')
subprocess.run(['tmux','-S',str(root/'tmux.sock'),'new-session','-d','-s','setup','bash',str(launcher)],check=True)
print(json.dumps({'root':str(root),'staged_files':len(expected),'session':'setup','state':'setup-launched'}))
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', '/usr/bin/python3', '-c', remote, json.dumps(expected, separators=(',', ':'))], input=buffer.getvalue(), capture_output=True)
(HERE / 'stage.stdout').write_bytes(result.stdout)
(HERE / 'stage.stderr').write_bytes(result.stderr)
sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
