"""Run two explicitly untimed checks on unchanged, restored source; never a comparison."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

LOCAL = Path(__file__).resolve().parent
REMOTE = r'''
from pathlib import Path
from datetime import datetime, timezone
import fcntl, hashlib, json, os, re, shlex, stat, subprocess, sys, traceback
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
sys.path.insert(0, str(root / 'work/benchmark'))
import dirty_audit_v2, dirty_guard, input_catalog, paired
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
owner = json.loads((root / 'ownership.json').read_text())
assert owner['root'] == str(root) and owner['uid'] == os.getuid()
cohort_path = root / 'metadata/frozen-cohort.json'
assert sha(cohort_path) == '0d524bb20f7a1a41381c64e7991cb6a73935f42824d9768e20cc0b0bf0a4df9f'
cohort = json.loads(cohort_path.read_text())
assert not list((root / 'results').rglob('*'))
assert not (root / 'metadata/diagnostic-expectations.json').exists()
assert not (root / 'configs-finalized.json').exists()
config_path = root / 'configs/check-ir-diagnostic-forward.prepared.json'
assert sha(config_path) == '5bd4b652e9b65e65bb9fbc997c2e2335810de47d57897f3346ddf5ed0947c9a1'
config = json.loads(config_path.read_text())
guard_path = root / 'work/benchmark/source-guard.json'
guard = dirty_guard.check(guard_path, restored=True)
input_catalog.check(root / 'metadata/input-catalog.json')
for path, digest in cohort['asset_sha256'].items():
    assert sha(path) == digest, path
canonical = root / 'active/bin/cargo'
assert sha(canonical) == cohort['variant_sha256']['baseline']
source = root / 'uv/crates/uv/src/lib.rs'
source_stat = source.stat()
assert sha(source) == 'ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81'
probe = subprocess.Popen(['ps', '-eo', 'pid,pcpu,comm'], stdout=subprocess.PIPE, text=True)
occupancy = probe.communicate()[0]
assert probe.returncode == 0
busy = []
for line in occupancy.splitlines()[1:]:
    fields = line.split(None, 2)
    if len(fields) != 3:
        continue
    pid, cpu, name = int(fields[0]), float(fields[1]), fields[2]
    if pid in (os.getpid(), probe.pid):
        continue
    if cpu > 40 or name in ('rustc', 'cargo', 'clang', 'clang++', 'cc1', 'cc1plus', 'ld.lld', 'valgrind', 'callgrind-amd64'):
        busy.append({'pid': pid, 'pcpu': cpu, 'comm': name})
assert not busy, busy
output = root / 'diagnostics/current179-check-convergence-01'
output.mkdir(exist_ok=False)
(output / 'controller.py').write_text(sys.argv[2])
assert sha(output / 'controller.py') == sys.argv[1]
lock = (root / 'experiment.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
context = {'cargo': canonical, 'variant': 'baseline', 'pair': 0, 'stage': 'measurement',
           'phase': 'diagnostic', 'output': root / 'diagnostics/current179-preflight-02/check-forward', 'position': 0}
environment = os.environ.copy()
configured = {**config['env'], **config['variant_env']['baseline']}
for key, value in configured.items():
    if value is None:
        environment.pop(key, None)
    else:
        environment[key] = paired.substitute(str(value), context)
environment.update({'OHM_BENCH_' + key.upper(): str(value) for key, value in context.items() if key != 'cargo'})
command = guard['commands']['check']
assert command == ['taskset', '-c', '0-7', str(canonical), '-Zohm-defaults=yes', 'check', '--locked', '--offline', '-j', '8', '--message-format=json', '-v']
rustc = str(Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc'))
tests = set()
for variant in ('baseline', 'candidate'):
    path = root / f'diagnostics/current179-preflight-02/logs/test-forward-native-{variant}.stdout'
    for line in path.read_text().splitlines():
        row = json.loads(line)
        if row.get('reason') == 'compiler-artifact' and row.get('profile', {}).get('test') and row.get('executable'):
            tests.add(row['executable'])
assert tests
unit_roots = [
    root / 'targets/check/base/debug/build/workspaces/f44d6c46475f5ab0/v2-8218330fa4ebf267' / package / unit
    for package, unit in [('uv-version', 'd257d5c3616703aa'), ('uv-version', 'f563a74b417e9f1e'),
                          ('uv-git', 'd597b02e7aa525a5'), ('uv-git', '610751fd1e8fa92b')]
]
def inventory():
    rows = {}
    for unit_root in unit_roots:
        assert unit_root.is_dir()
        for path in sorted(unit_root.rglob('*')):
            if not path.is_file():
                continue
            assert path.resolve().is_relative_to(root)
            info = path.stat()
            rows[str(path.relative_to(root))] = {'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns,
                'mode': stat.S_IMODE(info.st_mode), 'sha256': sha(path),
                'symlink': os.readlink(path) if path.is_symlink() else None}
    return rows
record = {'purpose': 'Two untimed same-source diagnostics; no benchmark comparison, no eligibility change',
          'state': 'running', 'started_at': datetime.now(timezone.utc).isoformat(),
          'controller_sha256': sys.argv[1], 'cohort_sha256': sha(cohort_path), 'config_sha256': sha(config_path),
          'canonical_cargo_sha256': sha(canonical), 'command': command,
          'configured_environment': configured,
          'environment_sha256': hashlib.sha256(json.dumps(environment, sort_keys=True).encode()).hexdigest(),
          'source_sha256': sha(source), 'source_mtime_ns': source_stat.st_mtime_ns,
          'test_executable_paths_checked': sorted(tests), 'runs': []}
write(output / 'manifest.json', record)
write(output / 'unit-artifacts-before.json', inventory())
try:
    for label in ('restored-source', 'unchanged-source-repeat'):
        assert sha(source) == record['source_sha256'] and source.stat().st_mtime_ns == source_stat.st_mtime_ns
        trace = output / (label + '.execve')
        stdout = output / (label + '.stdout')
        stderr = output / (label + '.stderr')
        with stdout.open('w') as out, stderr.open('w') as err:
            process = subprocess.run(['/usr/bin/strace', '-f', '-qq', '-s', '65536', '-e', 'trace=execve,execveat', '-o', str(trace), *command],
                                     cwd=root / 'uv', env=environment, stdout=out, stderr=err)
        compilers = []
        for line in stderr.read_text().splitlines():
            match = re.match(r'^\s*Running `(.+)`$', line)
            if match:
                args = shlex.split(match[1])
                if args and args[0] == rustc:
                    compilers.append(args)
        executed = dirty_audit_v2.validate_no_tests({'test_executables': sorted(tests)}, trace.read_text())
        row = {'label': label, 'returncode': process.returncode, 'compiler_commands': compilers,
               'rustc_execve_count': executed.count(rustc), 'executed_programs': executed,
               'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr), 'execve_sha256': sha(trace)}
        record['runs'].append(row)
        write(output / 'manifest.json', record)
        assert process.returncode == 0, row
        assert executed.count(rustc) == len(compilers)
        dirty_guard.check(guard_path, restored=True)
        assert source.stat().st_mtime_ns == source_stat.st_mtime_ns
    write(output / 'unit-artifacts-after.json', inventory())
    input_catalog.check(root / 'metadata/input-catalog.json')
    for path, digest in cohort['asset_sha256'].items():
        assert sha(path) == digest, path
    assert sha(canonical) == record['canonical_cargo_sha256']
    assert not list((root / 'results').rglob('*'))
    record['state'] = 'complete'
    record['all_assets_verified_after'] = True
    record['source_restored_unchanged'] = True
except BaseException as error:
    record['state'] = 'failed'
    record['error'] = repr(error)
    record['traceback'] = traceback.format_exc()
    raise
finally:
    record['finished_at'] = datetime.now(timezone.utc).isoformat()
    write(output / 'manifest.json', record)
    fcntl.flock(lock, fcntl.LOCK_UN)
print(json.dumps({'state': record['state'], 'output': str(output),
                  'runs': [{'label': row['label'], 'compiler_count': len(row['compiler_commands']),
                            'rustc_execve_count': row['rustc_execve_count']} for row in record['runs']],
                  'manifest_sha256': sha(output / 'manifest.json')}, indent=2))
'''

ast.parse(REMOTE)
digest = hashlib.sha256(REMOTE.encode()).hexdigest()
freeze = {"purpose": "Untimed unchanged-source diagnostics only", "controller_sha256": digest,
          "commands": 2, "labels": ["restored-source", "unchanged-source-repeat"],
          "no_comparative_samples": True, "source_edits": False}
with (LOCAL / "check-convergence-02-freeze.json").open("x") as stream:
    json.dump(freeze, stream, indent=2)
    stream.write("\n")
process = subprocess.run([
    "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh", "charlie-oss-4", "--",
    "env", "-u", "PYTHONPATH", "-u", "PYTHONHOME", "-u", "PYTHONSAFEPATH", "PYTHONDONTWRITEBYTECODE=1",
    "taskset", "-c", "8", "/usr/bin/python3", "-c", REMOTE, digest, REMOTE,
], capture_output=True)
(LOCAL / "check-convergence-02.stdout").write_bytes(process.stdout)
(LOCAL / "check-convergence-02.stderr").write_bytes(process.stderr)
print(process.stdout.decode())
if process.returncode:
    print(process.stderr.decode())
raise SystemExit(process.returncode)
