
from pathlib import Path
import json,hashlib,base64,stat,os,subprocess,datetime
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179');assert root.resolve()==root and root.stat().st_uid==os.getuid()==1000
names=['results/native-confirmation.json','metadata/test-native-confirmation-occupancy.txt','logs/native-confirmation-01.controller.stdout','logs/native-confirmation-01.controller.stderr']
history=root/'continuations/native-prerequisite-launch-01';names += [str(p.relative_to(root)) for p in sorted(history.iterdir()) if p.is_file()]
status=json.loads((root/names[0]).read_text());assert status['state']=='failed' and status['completed_workloads']==[] and status['error']=="ValueError('another compiler/build/profiler process is active before the batch')"
assert all(not (root/n).exists() for n in ['results/test-native-confirmation','results/check-native-confirmation','logs/test-native-confirmation.run.stdout','logs/test-native-confirmation.run.stderr','logs/check-native-confirmation.run.stdout','logs/check-native-confirmation.run.stderr'])
files={}
for name in names:
 p=root/name;assert p.resolve()==p and p.is_file() and not p.is_symlink();data=p.read_bytes();files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode),'base64':base64.b64encode(data).decode()}
processes=[]
for line in subprocess.check_output(['ps','-eo','pid,comm,pcpu,pmem,etimes'],text=True).splitlines()[1:]:
 fields=line.split()
 if len(fields)==5 and fields[1] in {'cargo','rustc','cc1','cc1plus','clang','clang++','ld.lld','callgrind-amd64'}:
  pid=int(fields[0]);row={'pid':pid,'comm':fields[1],'pcpu':fields[2],'pmem':fields[3],'elapsed_seconds':fields[4]}
  try:row['cwd']=os.readlink('/proc/'+str(pid)+'/cwd')
  except OSError:row['cwd']=None
  processes.append(row)
print(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':status['state'],'completed_workloads':status['completed_workloads'],'no_native_workload_or_sample_directories':True,'current_compiler_processes':processes,'files':files}))
