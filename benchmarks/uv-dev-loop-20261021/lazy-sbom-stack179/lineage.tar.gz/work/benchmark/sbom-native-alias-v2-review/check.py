#!/usr/bin/env python3
"""Independent source/hash/synthetic review only; never reads real effects."""
import ast
import copy
import datetime
import difflib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import unittest


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
CONTROLS = WORK / 'sbom-current179-native-launch-controls-alias-v2'
PREVIOUS = WORK / 'sbom-current179-native-launch-controls'
ALIAS = WORK / 'sbom-current179-ir-reviewer-profiler-alias-v2'
EXPECTED = 'af6c551f3ddd21562dd7859d67ec885d24507a256fabecccd653459df78ebf67'
OLD = 'b6f1045794853ebb62963cc67c6830379896c3fa417fc0e538d890eab39f32e1'
REVIEWER = '97cdbcc36928777579b1b3c6e5b8adf7bdae37d97a2b0f2200a57cdd0ec4f067'
OLD_REVIEWER = 'fb2529078308fd3e4c816402aa3df1d4a01e52cb32a079a86e9366d5dbedbd6b'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def audit_event(event, values):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'socket.connect'}:
        raise AssertionError('Independent source checks cannot launch processes or access a host')


def observe(path):
    path = Path(path)
    metadata = path.lstat()
    assert path.resolve() == path and stat.S_ISREG(metadata.st_mode), str(path)
    return {'sha256': sha(path), 'bytes': metadata.st_size, 'mode': stat.S_IMODE(metadata.st_mode)}


def verify_all(frozen):
    observed = {}
    for name, expected in frozen['files'].items():
        path = CONTROLS / name
        assert path.is_relative_to(CONTROLS) and '..' not in Path(name).parts
        observed[str(path)] = observe(path)
        assert observed[str(path)] == expected, name
    for name, expected in frozen['external_files'].items():
        path = Path(name)
        assert path.is_relative_to(WORK), name
        observed[name] = observe(path)
        assert observed[name] == expected, name
    assert sha(CONTROLS / 'source-freeze.json') == EXPECTED
    return observed


def assignment(tree, name):
    values = [node for node in tree.body if isinstance(node, ast.Assign)
              and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
              and node.targets[0].id == name]
    assert len(values) == 1
    return values[0]


def main():
    sys.addaudithook(audit_event)
    assert sorted(os.sched_getaffinity(0)) == [8]
    assert sha(CONTROLS / 'source-freeze.json') == EXPECTED
    frozen = json.loads((CONTROLS / 'source-freeze.json').read_text())
    assert len(frozen['files']) == 40 and len(frozen['external_files']) == 352
    before = verify_all(frozen)
    assert sha(PREVIOUS / 'source-freeze.json') == OLD
    assert sha(ALIAS / 'source-freeze.json') == REVIEWER
    assert frozen['previous_controls_source_freeze_sha256'] == OLD
    assert frozen['accepted_raw_reviewer_sha256'] == REVIEWER
    old_freeze = json.loads((PREVIOUS / 'source-freeze.json').read_text())
    for name, row in old_freeze['files'].items():
        assert before[str(PREVIOUS / name)] == row, name
    for name, row in old_freeze['external_files'].items():
        assert before[name] == row, name
    alias_freeze = json.loads((ALIAS / 'source-freeze.json').read_text())
    for name, row in alias_freeze['files'].items():
        assert set(row) <= {'sha256', 'bytes', 'mode'} and {'sha256', 'bytes'} <= set(row), name
        assert {key: before[str(ALIAS / name)][key] for key in row} == row, name

    original = (PREVIOUS / 'remote.py').read_text()
    current = (CONTROLS / 'remote.py').read_text()
    old_ast, new_ast = ast.parse(original), ast.parse(current)
    old_assignment = assignment(old_ast, 'RAW_REVIEWER')
    new_assignment = assignment(new_ast, 'RAW_REVIEWER')
    assert ast.literal_eval(old_assignment.value) == OLD_REVIEWER
    assert ast.literal_eval(new_assignment.value) == REVIEWER
    new_assignment.value = copy.deepcopy(old_assignment.value)
    assert ast.dump(new_ast, include_attributes=False) == ast.dump(old_ast, include_attributes=False)
    assert current == original.replace("RAW_REVIEWER = '" + OLD_REVIEWER + "'", "RAW_REVIEWER = '" + REVIEWER + "'", 1)
    unchanged = ('prepare.py', 'environment_entry.py', 'transport.py', 'run_pure_checks.py', 'reference/protocol.json')
    for name in unchanged:
        assert (CONTROLS / name).read_bytes() == (PREVIOUS / name).read_bytes(), name
    final_pure = json.loads((CONTROLS / 'pure-check-attempt04/result.json').read_text())
    assert final_pure['valid'] is True and final_pure['tests'] == 16
    assert final_pure['errors'] == final_pure['failures'] == 0
    for name, expected in final_pure['source_sha256'].items():
        assert sha(CONTROLS / name) == expected, name
    pure_history = []
    for number in ('01', '02', '03', '04'):
        path = CONTROLS / ('pure-check-attempt' + number) / 'result.json'
        record = json.loads(path.read_text())
        pure_history.append({'attempt': number, 'sha256': sha(path),
                             **{key: record[key] for key in ('valid', 'tests', 'failures', 'errors')}})

    # The independently inspected suite uses synthetic dictionaries and source
    # AST/signature checks. It never invokes a real prerequisite or reviewer.
    spec = importlib.util.spec_from_file_location('independent_sbom_native_alias_tests', CONTROLS / 'test_controls.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    with (HERE / 'pure-checks.txt').open('x') as output:
        output.write(stream.getvalue())
    assert result.wasSuccessful() and result.testsRun == 16
    after = verify_all(frozen)
    assert before == after
    with (HERE / 'remote-only.diff').open('x') as output:
        output.write(''.join(difflib.unified_diff(original.splitlines(True), current.splitlines(True),
                                               fromfile='reviewed-original/remote.py', tofile='alias-v2/remote.py')))
    report = {
        'status': 'passed_source_review', 'reviewed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_freeze_sha256': EXPECTED, 'previous_source_freeze_sha256': OLD,
        'accepted_alias_reviewer_sha256': REVIEWER,
        'local_records_verified_before_and_after': 40,
        'external_records_verified_before_and_after': 352,
        'total_verified_bytes_per_pass': sum(row['bytes'] for row in before.values()),
        'all_prior_control_and_external_bindings_preserved': True,
        'all_alias_reviewer_source_bindings_present': True,
        'runtime_delta': 'Exactly one RAW_REVIEWER literal, from the failed original reviewer freeze to the authenticated alias-reviewer freeze. Complete module AST identical after restoring that one value.',
        'unchanged_control_sha256': {name: sha(CONTROLS / name) for name in unchanged},
        'independent_pure_tests': {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'passed': result.wasSuccessful()},
        'retained_pure_attempts': pure_history,
        'native_plan': {'order': ['test', 'check'], 'pairs_per_workflow': 30, 'warmup_pairs': 2,
                        'invocations_per_variant_per_pair': 1, 'seeds': [20261021103, 20261021104],
                        'protocol_sha256': '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'},
        'open_findings': [],
        'scope': 'Source/hash/AST and synthetic checks only. No host access, staging, prerequisite preparation, launch, real review, real effects, sampling or statistical recomputation.',
        'limitation': 'This source review does not accept the actual IR evidence or authorize native execution. Root must bind the new review/execution/lineage approvals and retain the original plan.',
    }
    with (HERE / 'review.json').open('x') as output:
        json.dump(report, output, indent=2)
        output.write('\n')
    print(json.dumps({'status': report['status'], 'records': 392, 'tests': 16, 'review_sha256': sha(HERE / 'review.json')}, indent=2))


if __name__ == '__main__':
    main()
