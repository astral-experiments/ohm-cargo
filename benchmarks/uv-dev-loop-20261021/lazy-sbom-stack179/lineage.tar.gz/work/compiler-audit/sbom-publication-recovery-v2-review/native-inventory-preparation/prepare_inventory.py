#!/usr/bin/env python3
"""Create only a proposed file inventory; do not assemble, review effects or publish."""
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[3]
CONTROLS = 'work/sbom-current179-ir-continuation'
PACKAGE = 'work/sbom-current179-publication-recovery-v2'
LINEAGE = CONTROLS + '/independent-native-recovery-lineage-v2'
RAW = CONTROLS + '/independent-native-review-profiler-alias-v2'
PEER = 'work/compiler-audit/sbom-publication-recovery-v2-review'
ACCEPTANCE = CONTROLS + '/root-native-profiler-alias-v2-acceptance.json'
ACCEPTANCE_SHA = 'b16b9a7cf56cc507c7b5d7b7e0300c3ce32f8175163373ebbfa074d37872cec6'
REVIEW_SHA = '8279a442adae11aa35e8037d0ad7952928754fe16d333ce0bce84ef177aaf16e'
INDEX_SHA = '287972e5610086958c88262329ba484110f01f7130c9847f2a18f3e1e585d7c3'
BINDINGS = {
    'lineage_review': (LINEAGE + '/review.json', 'e3b3214270083e5f7f89a25a439fb3419b40e8f57f37136a9cc5adcfa6fbf1bf'),
    'root_acceptance_bridge': (CONTROLS + '/native-recovery-root-acceptance.json', '40cb800cab72963799140e603bf05bc7489c5e9166b20cd7d94c7cc3d3ebd6c3'),
    'lineage_execution_approval': ('work/sbom-current179-native-admission-review-v2/root-execution-approval.json', 'ed54d25c9fbbb763bb5f6348bba1a412ad573564c713c38785fbd7dcde9b9554'),
    'raw_execution_approval': (CONTROLS + '/native-raw-execution-approval.json', 'bdd2e27c43e8daaa7f7230d07a074caff05d8f6d3579583097718d6f123c9c12'),
    'lineage_execution_receipt': (CONTROLS + '/native-lineage-execution/receipt.json', 'e5ddabfa927b7a5f9abd7823fc59698abd9c8714667928cbaa9c7ca3986dc85b'),
    'raw_execution_receipt': (CONTROLS + '/native-raw-execution/receipt.json', '9b8f8cc952a209c83f6bbdae6f9eb46b9fa5adfd1411ce9ee70304085d0607ed'),
}


def record(path):
    before = path.lstat()
    if path.resolve() != path or not stat.S_ISREG(before.st_mode):
        raise ValueError('noncanonical/nonregular input: ' + str(path))
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.lstat()
    if any(getattr(before, key) != getattr(after, key) for key in
           ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')):
        raise ValueError('input changed while hashing: ' + str(path))
    return {'sha256': digest, 'bytes': before.st_size, 'mode': stat.S_IMODE(before.st_mode)}


def main():
    files = {}

    def bind(name, expected=None):
        path = WORKSPACE / name
        if not path.is_relative_to(WORKSPACE / 'work') or str(path.relative_to(WORKSPACE)) != name:
            raise ValueError('input outside canonical work paths')
        row = record(path)
        if name in files and files[name] != row or expected is not None and row != expected:
            raise ValueError('retained input changed: ' + name)
        files[name] = row
        return row

    def pinned(name, digest):
        if bind(name)['sha256'] != digest:
            raise ValueError('fixed input hash differs: ' + name)

    def read_metadata(name):
        bind(name)
        return json.loads((WORKSPACE / name).read_text())

    def retain_tree(name):
        root = WORKSPACE / name
        if not root.is_dir() or root.resolve() != root:
            raise ValueError('noncanonical required tree: ' + name)
        for path in sorted(root.rglob('*')):
            if path.is_symlink() or not (path.is_file() or path.is_dir()):
                raise ValueError('special lineage member: ' + str(path))
            if path.is_file():
                bind(str(path.relative_to(WORKSPACE)))

    pinned(LINEAGE + '/local-inputs.json', INDEX_SHA)
    index = read_metadata(LINEAGE + '/local-inputs.json')
    if len(index['files']) != 680:
        raise ValueError('accepted local index must contain exactly 680 entries')
    for absolute, row in index['files'].items():
        bind(str(Path(absolute).relative_to(WORKSPACE)), row)
    for name in ('work/sbom-current179-native-launch-controls-alias-v2',
                 'work/sbom-current179-native-failed-launch01',
                 'work/sbom-current179-native-admission-recovery',
                 'work/sbom-current179-native-launch-replay02',
                 'work/sbom-current179-native-admission-review-v2', LINEAGE, RAW,
                 CONTROLS + '/native-lineage-execution', CONTROLS + '/native-raw-execution'):
        retain_tree(name)
    for name, digest in BINDINGS.values():
        pinned(name, digest)
    pinned(ACCEPTANCE, ACCEPTANCE_SHA)
    pinned(RAW + '/review.json', REVIEW_SHA)
    pinned(PACKAGE + '/source-freeze.json', '5090df38ee6b7338750357cdcaa00f64da70102579a2c861909793f3a9ac7e96')
    frozen = read_metadata(PACKAGE + '/source-freeze.json')
    for name, row in frozen['files'].items():
        bind(PACKAGE + '/' + name, row)
    for name, row in frozen['external_files'].items():
        bind(name, row)
    pinned(PACKAGE + '/root-source-review.json', '63d4017486a604ef17c1fc95d4ef13c949c4160edd9469f1dc2ebd685ccc11af')
    pinned(PEER + '/seal.json', '84dcd390698d133a3aaee1747aeee28d9fa5aa8f651c543a74fffad60f69a907')
    for name, row in read_metadata(PEER + '/seal.json').items():
        bind(PEER + '/' + name, row)
    for name in ('work/compiler-audit/review_sbom_publication_recovery_v2.py',
                 'work/sbom-current179-qualified-publication/publish_evidence.py',
                 'work/sbom-current179-qualified-publication/source-live-readback.json',
                 str(Path(__file__).relative_to(WORKSPACE))):
        bind(name)

    original = 'work/sbom-current179-native-launch-controls-alias-v2'
    replay = 'work/sbom-current179-native-launch-replay02'
    coverage = {
        'source_controls': [PACKAGE + '/source-freeze.json', PACKAGE + '/root-source-review.json',
                            PEER + '/review.json', PEER + '/seal.json', original + '/source-freeze.json',
                            'work/sbom-current179-qualified-publication/publish_evidence.py',
                            'work/sbom-current179-qualified-publication/source-live-readback.json'],
        'preparation': [original + '/preparation-execution.json', original + '/prepared/manifest.json',
                        original + '/prepared/preparation.json', original + '/prepared/root-approval.json'],
        'stage': [original + '/stage-execution.json', original + '/stage-attempt01/receipt.json',
                  original + '/stage-attempt01/seal.json'],
        'launch': [original + '/launch-execution.json', replay + '/launch-execution.json', replay + '/root-launch-approval.json'],
        'collection': [CONTROLS + '/native-confirmation-collection-receipt.json',
                       CONTROLS + '/evidence/native-confirmation/transfer-manifest.json',
                       CONTROLS + '/native-confirmation-evidence.tar.gz'],
        'review': [LINEAGE + '/review.json', LINEAGE + '/seal.json', LINEAGE + '/local-inputs.json',
                   RAW + '/review.json', RAW + '/seal.json', ACCEPTANCE] + [name for name, unused in BINDINGS.values()],
        'failed_admission': sorted(name for name in files if name.startswith('work/sbom-current179-native-failed-launch01/')
                                   or name.startswith('work/sbom-current179-native-admission-recovery/launch-quiet.')),
    }
    for category, names in coverage.items():
        coverage[category] = sorted(set(names))
        if not names or any(name not in files for name in names):
            raise ValueError('missing actual category member: ' + category)
    if '653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2' not in {row['sha256'] for row in files.values()}:
        raise ValueError('known failed native status omitted')
    for name, row in files.items():
        if record(WORKSPACE / name) != row:
            raise ValueError('input changed during inventory preparation: ' + name)
    document = {'status': 'reviewed-complete', 'phase': 'native-confirmation', 'review_sha256': REVIEW_SHA,
                'native_acceptance_sha256': ACCEPTANCE_SHA, 'all_native_attempts_retained': True,
                'coverage': coverage, 'files': files,
                'recovery_bindings': {key: {'path': name, 'sha256': digest} for key, (name, digest) in BINDINGS.items()}}
    output = HERE / 'proposed-native-lineage-inventory.json'
    with output.open('x') as stream:
        json.dump(document, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': 'proposed-inventory-only', 'files': len(files),
                      'accepted_local_index_files_retained': 680, 'category_counts': {key: len(value) for key, value in coverage.items()},
                      'output': str(output), 'output_record': record(output),
                      'effects_parsed': False, 'validators_or_assembly_executed': False}, indent=2))


if __name__ == '__main__':
    main()
