This directory contains a proposed native lineage inventory for root review. The
metadata-only helper prepared it after root supplied the actual accepted native
review (`8279a442…`) and acceptance (`b16b9a7c…`) hashes. No acceptance was authored
here. The inventory's `reviewed-complete` field refers to those existing accepted
evidence records; this proposal still requires root inspection and the unchanged
publication preparer's full validation.

The 780 file records retain every one of the accepted lineage index's 680 entries,
the complete recovery/replay/failed-admission/control/review/execution trees, six
exact recovery bindings, actual members for all seven required coverage categories,
the packaging source and root/independent reviews, and the proposed publisher's
source/live readback. The helper hashes review and stream bytes without parsing
effects. It parses only the existing local-input index, packaging source freeze,
and independent source-review seal. It rehashes every retained input before writing
the new proposal and refuses to overwrite an existing proposal.

The native archive remains its exact original 100,475,996 bytes. This inventory
does not copy, extract or recompress it. The unchanged assembler retains its
existing 90,000,000-byte lossless chunk path. Future mutable publisher receipts
are not included.

Preparation ran on CPU 8 and exited successfully; stdout/stderr are retained.
Only Python syntax compilation and straightforward file/inventory checks were
performed here. No new test framework, statistical review, final-input preparation,
assembly, host operation or publication was run.

After reviewing this proposal, root can pass its path and exact SHA256 as the
existing `prepare_evidence_inputs.py` arguments `--native-lineage-inventory` and
`--native-lineage-inventory-sha256`. The preparer still enforces all original raw,
statistical, source, CI, archive and recovery-lineage gates before creating final
inputs. No source or historical freeze was modified.
