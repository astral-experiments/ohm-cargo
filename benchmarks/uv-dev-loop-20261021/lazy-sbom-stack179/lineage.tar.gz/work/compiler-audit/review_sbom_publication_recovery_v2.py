#!/usr/bin/env python3
"""Independent source/pure review; no real assembly, effects, host or publication operations."""
import ast
import contextlib
import copy
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

WORKSPACE = Path(__file__).resolve().parents[2]
SOURCE = WORKSPACE / 'work/sbom-current179-publication-recovery-v2'
ORIGINAL = WORKSPACE / 'work/sbom-current179-publication'
OUTPUT = WORKSPACE / 'work/compiler-audit/sbom-publication-recovery-v2-review'
EXPECTED = '5090df38ee6b7338750357cdcaa00f64da70102579a2c861909793f3a9ac7e96'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def record(path):
    info = path.lstat()
    assert path.resolve() == path and stat.S_ISREG(info.st_mode)
    return {'sha256': sha(path), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    with (OUTPUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def functions(path):
    return {node.name: node for node in ast.parse(path.read_text()).body if isinstance(node, ast.FunctionDef)}


def dump(node):
    return ast.dump(node, include_attributes=False)


def reject(action):
    try:
        action()
    except (AssertionError, ValueError, KeyError, TypeError):
        return
    raise AssertionError('Malformed synthetic lineage was accepted')


def main():
    assert os.sched_getaffinity(0) == {8}
    assert sha(SOURCE / 'source-freeze.json') == EXPECTED
    frozen = read(SOURCE / 'source-freeze.json')
    protected = {str(SOURCE / name): row for name, row in frozen['files'].items()}
    protected.update({str(WORKSPACE / name): row for name, row in frozen['external_files'].items()})
    protected[str(SOURCE / 'source-freeze.json')] = record(SOURCE / 'source-freeze.json')
    for name, row in protected.items():
        assert record(Path(name)) == row, name
    OUTPUT.mkdir(exist_ok=False)
    write('verified-inputs-before.json', protected)

    previous, current = functions(ORIGINAL / 'assemble_evidence.py'), functions(SOURCE / 'assemble_evidence.py')
    changed = {'frozen_source', 'source_and_acceptance', 'main'}
    unchanged = sorted(set(previous) - changed)
    assert set(current) == set(previous) | {'validate_recovery_lineage'}
    for name in unchanged:
        assert dump(previous[name]) == dump(current[name]), name
    entry = copy.deepcopy(current['main'])
    additions = [node for node in entry.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                 and isinstance(node.value.func, ast.Name) and node.value.func.id == 'validate_recovery_lineage']
    assert len(additions) == 1
    entry.body.remove(additions[0])
    assert dump(entry) == dump(previous['main'])
    source = copy.deepcopy(current['source_and_acceptance'])
    class RestoreSource(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'PUBLICATION_SOURCE':
                return ast.copy_location(ast.Name(id='HERE', ctx=node.ctx), node)
            return node
    assert dump(RestoreSource().visit(source)) == dump(previous['source_and_acceptance'])
    frozen_function = copy.deepcopy(current['frozen_source'])
    assert isinstance(frozen_function.body[-1], ast.For) and 'external_files' in dump(frozen_function.body[-1])
    frozen_function.body.pop()
    assert dump(frozen_function) == dump(previous['frozen_source'])
    for name in ('test_assemble_evidence.py', 'snapshot_evidence_inputs.py', 'existing-inputs.json', 'PR.md', 'REPRODUCE.md'):
        assert (SOURCE / name).read_bytes() == (ORIGINAL / name).read_bytes(), name
    old_constants = {dump(node.targets[0]): dump(node.value) for node in ast.parse((ORIGINAL / 'assemble_evidence.py').read_text()).body if isinstance(node, ast.Assign)}
    new_constants = {dump(node.targets[0]): dump(node.value) for node in ast.parse((SOURCE / 'assemble_evidence.py').read_text()).body if isinstance(node, ast.Assign)}
    assert all(new_constants[key] == value for key, value in old_constants.items())
    write('source-comparison.json', {'status': 'passed', 'unchanged_assembler_functions': unchanged,
        'main_adds_only_recovery_validation': True, 'source_ci_gate_only_relocates_original_inputs': True,
        'original_constants_tests_catalog_snapshotter_and_reproduction_unchanged': True,
        'frozen_source_only_adds_external_hash_checks': True})

    # Redirect only the two report destinations in memory. All imports and source
    # hashes still resolve to the exact frozen package, never a copied substitute.
    runner = SOURCE / 'run_packaging_checks.py'
    tree = ast.parse(runner.read_text())
    redirects = []
    class RedirectReports(ast.NodeTransformer):
        def visit_BinOp(self, node):
            self.generic_visit(node)
            if (isinstance(node.op, ast.Div) and isinstance(node.left, ast.Name) and node.left.id == 'HERE'
                    and isinstance(node.right, ast.Constant) and node.right.value in ('pure-checks.txt', 'pure-checks.json')):
                redirects.append(node.right.value)
                node.left = ast.copy_location(ast.Name(id='INDEPENDENT_OUTPUT', ctx=ast.Load()), node.left)
            return node
    tree = ast.fix_missing_locations(RedirectReports().visit(tree))
    assert sorted(redirects) == ['pure-checks.json', 'pure-checks.txt']
    allowed_sources = {str(path) for path in SOURCE.glob('*.py')}
    allowed_sources.add(str(Path(__file__).resolve()))
    opened = set()
    def source_reads_only(event, arguments):
        if event == 'open' and isinstance(arguments[0], (str, bytes, os.PathLike)):
            name = os.fsdecode(arguments[0])
            path = Path(name)
            if path.is_absolute() and path.is_relative_to(WORKSPACE / 'work'):
                if path.is_relative_to(OUTPUT):
                    return
                if path.suffix == '.pyc' and not path.exists():
                    return
                assert str(path) in allowed_sources, 'Synthetic replay attempted non-source workspace input: ' + str(path)
                opened.add(str(path))
    sys.addaudithook(source_reads_only)
    with (OUTPUT / 'pure-replay.stdout').open('x') as out, (OUTPUT / 'pure-replay.stderr').open('x') as err:
        namespace = {'__name__': '__main__', '__file__': str(runner), 'INDEPENDENT_OUTPUT': OUTPUT}
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            exec(compile(tree, str(runner), 'exec'), namespace)
    result = read(OUTPUT / 'pure-checks.json')
    assert result['valid'] and result['tests'] == 32 and result['errors'] == result['failures'] == 0

    # Additional independent pure cases exercise receipt types, exact CLI and
    # the retained replay directory without opening any actual native evidence.
    tests = sys.modules.get('synthetic_recovery_tests')
    if tests is None:
        spec = importlib.util.spec_from_file_location('independent_recovery_fixture', SOURCE / 'test_recovery_binding.py')
        tests = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(tests)
    recovery = sys.modules['recovery_binding']
    extras = []
    def synthetic(label, mutate, accept=False):
        with tempfile.TemporaryDirectory(prefix='sbom-publication-independent-') as temporary:
            fixture = tests.Fixture(Path(temporary).resolve())
            mutate(fixture)
            if accept:
                fixture.run()
            else:
                reject(fixture.run)
            extras.append(label)
    synthetic('optional absolute taskset CPU8 prefixes remain accepted',
        lambda f: [f.docs[name].update(argv=['/usr/bin/taskset', '-c', '8'] + f.docs[name]['argv'])
                   for name in (recovery.LINEAGE_EXECUTION, recovery.RAW_EXECUTION)], True)
    synthetic('boolean false does not impersonate integer returncode zero',
        lambda f: f.docs[recovery.RAW_EXECUTION].update(returncode=False))
    synthetic('lineage execution cannot finish after bridge acceptance',
        lambda f: f.docs[recovery.LINEAGE_EXECUTION].update(finished_at='2026-10-21T19:04:00+00:00'))
    synthetic('timezone-free root bridge time is rejected',
        lambda f: f.docs[recovery.BRIDGE_PATH].update(accepted_at='2026-10-21T19:03:00'))
    synthetic('lineage CLI source-freeze argument cannot change',
        lambda f: f.docs[recovery.LINEAGE_EXECUTION]['argv'].__setitem__(5, '0' * 64))
    synthetic('outer raw receipt must appear in the final assembly inventory',
        lambda f: f.inputs['files'].pop(recovery.RAW_EXECUTION))
    synthetic('unindexed real replay file is rejected',
        lambda f: (f.root / 'work/sbom-current179-native-launch-replay02/extra.stderr').write_bytes(b'synthetic retained stream'))
    synthetic('recovery directory symlink is rejected',
        lambda f: (f.root / 'work/sbom-current179-native-admission-recovery/extra-link').symlink_to(f.root / 'work/predecessor/source-freeze.json'))
    write('independent-pure-cases.json', {'status': 'passed', 'count': len(extras), 'cases': extras,
        'only_source_workspace_files_opened_during_replay': sorted(opened),
        'report_destination_only_ast_redirects': redirects,
        'actual_effects_reviews_assembly_hosts_and_publication_executed': False})
    # The audit hook intentionally remains active. Rehash via the already-bound
    # descriptors only after explicitly permitting these declared source inputs.
    allowed_sources.update(protected)
    after = {name: record(Path(name)) for name in protected}
    assert after == protected
    write('verified-inputs-after.json', after)
    report = {'status': 'passed-source-only', 'reviewed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_freeze_sha256': EXPECTED, 'source_files_verified': len(frozen['files']),
        'external_files_verified': len(frozen['external_files']), 'original_synthetic_tests_passed': 32,
        'additional_independent_pure_cases_passed': len(extras), 'affinity': [8],
        'checks': {'exact_v2_lineage_source_and_root_source_review_bound': True,
            'actual_collection_approval_review_seal_and_index_joins_required': True,
            'all_recovery_replay_failure_and_execution_files_required': True,
            'root_bridge_and_lineage_finish_precede_raw_execution': True,
            'exact_original_reviewer_argv_and_outer_stream_paths_required': True,
            'original_raw_statistical_archive_source_and_ci_gates_unchanged': True,
            'all_frozen_files_unchanged_after_pure_replay': True},
        'findings': [], 'real_inputs_and_execution': 'Not approved by this review; actual terminal collection, lineage/bridge/raw acceptance remain required.',
        'host_calls_real_assembly_native_effects_and_publication': False,
        'reviewer_sha256': sha(Path(__file__))}
    write('review.json', report)
    write('seal.json', {str(path.relative_to(OUTPUT)): record(path) for path in sorted(OUTPUT.iterdir()) if path.is_file()})
    print(json.dumps({'status': report['status'], 'review_sha256': sha(OUTPUT / 'review.json'),
        'seal_sha256': sha(OUTPUT / 'seal.json'), 'source_files': len(frozen['files']),
        'external_files': len(frozen['external_files']), 'pure_cases': 32 + len(extras)}, indent=2))


if __name__ == '__main__':
    main()
