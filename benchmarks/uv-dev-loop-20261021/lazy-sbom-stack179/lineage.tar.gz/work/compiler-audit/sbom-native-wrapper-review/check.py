#!/usr/bin/env python3
"""Source-only strict-wrapper validation, including preserved unexecuted history."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import unittest

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
PROJECT = OUT.parents[2]
ROOT = PROJECT / 'work/sbom-current179-native-prerequisite-amendment'
ORIGINAL = PROJECT / 'work/sbom-current179-ir-continuation'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def deny_execution(event, values):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'socket.connect'}:
        raise AssertionError('Pure wrapper review cannot execute a workload or host command')


sys.addaudithook(deny_execution)
assert sorted(os.sched_getaffinity(0)) == [8]
assert sha(ROOT / 'source-freeze.json') == '8792edd14627d3315876c83b7cce3bf3a52ea437cc4385a755cc3d497b3f7086'
protected = {}
for root in [ROOT, ORIGINAL]:
    for name, row in read(root / 'source-freeze.json')['files'].items():
        path = root / name
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], name
        protected[str(path)] = row['sha256']
for name in ['native_entry.py', 'capsule-manifest.json', 'source-freeze.json']:
    assert (ROOT / 'reference' / name).read_bytes() == (ORIGINAL / name).read_bytes()
old = read(ROOT / 'history/interface-v1/source-freeze.json')
with tarfile.open(ROOT / 'history/interface-v1/complete-original-package.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names))
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    payloads = {m.name: archive.extractfile(m).read() for m in members}
    for name, row in old['files'].items():
        assert hashlib.sha256(payloads[name]).hexdigest() == row['sha256'] and len(payloads[name]) == row['bytes']
    assert payloads['source-freeze.json'] == (ROOT / 'history/interface-v1/source-freeze.json').read_bytes()
assert 'contract.verify_capsule(ROOT, CAPSULE, args.capsule_manifest_sha256)' in (ROOT / 'history/interface-v1/strict_native_entry.py').read_text()
assert 'contract.verify_capsule(CAPSULE, args.capsule_manifest_sha256)' in (ROOT / 'strict_native_entry.py').read_text()
assert read(ROOT / 'history/interface-v1/pure-checks.json')['tests'] == 5
assert read(ROOT / 'history/initial-test-attempt.json')['returncode'] == 1

spec = importlib.util.spec_from_file_location('strict_wrapper_pure_tests', ROOT / 'test_guard.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
output = io.StringIO()
result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
with (OUT / 'pure-checks.txt').open('x') as stream:
    stream.write(output.getvalue())
assert result.wasSuccessful() and result.testsRun == 6
assert len(module.guard.REQUIRED_FILES) == 8
for path, expected in protected.items():
    assert sha(path) == expected, path
report = {'status': 'passed', 'pure_tests': result.testsRun, 'required_payloads': sorted(module.guard.REQUIRED_FILES),
          'original_frozen_inputs': len(read(ORIGINAL / 'source-freeze.json')['files']),
          'wrapper_frozen_inputs': len(read(ROOT / 'source-freeze.json')['files']),
          'preserved_v1_archive_members': names, 'preserved_v1_frozen_inputs': len(old['files']),
          'interface_v1_was_an_unexecuted_source_defect': True,
          'initial_import_failure_separately_preserved': True,
          'protected_files': protected, 'actual_wrapper_or_entry_executed': False,
          'host_commands_executed': False, 'effects_inspected': False}
with (OUT / 'source-checks.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({k: report[k] for k in ['status', 'pure_tests', 'original_frozen_inputs', 'wrapper_frozen_inputs']}))
