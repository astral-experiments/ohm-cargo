#!/usr/bin/env python3
"""Replay only frozen source checks; forbid subprocess and network operations."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
PROJECT = OUT.parents[2]
PACKAGES = {
    'sbom-current179-ir-environment': 'c804e29e539b50dac4eae00bb71f2541016698a1aa0edfc639a73b052384ca69',
    'sbom-current179-ir-environment-review': '6f734b8eb9bbac6a61a7f93b105c068f542f9300d9dddb66482ef16611f002c4',
}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def forbid_execution(event, values):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork',
                 'socket.connect', 'socket.bind'}:
        raise AssertionError('Source-only review cannot execute workloads or access hosts')


sys.addaudithook(forbid_execution)
assert sorted(os.sched_getaffinity(0)) == [8]
protected = {}
results = {}
for package, expected in PACKAGES.items():
    root = PROJECT / 'work' / package
    freeze = root / 'source-freeze.json'
    assert sha(freeze) == expected
    protected[str(freeze)] = expected
    for name, row in read(freeze)['files'].items():
        path = root / name
        assert path.resolve() == path and not path.is_symlink()
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], name
        protected[str(path)] = row['sha256']
    spec = importlib.util.spec_from_file_location(package.replace('-', '_') + '_checks', root / 'test_source.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    with (OUT / (package + '.tests.txt')).open('x') as stream:
        stream.write(output.getvalue())
    assert result.wasSuccessful(), output.getvalue()
    results[package] = {'tests': result.testsRun, 'failures': len(result.failures),
                        'errors': len(result.errors), 'skipped': len(result.skipped)}

original = PROJECT / 'work/sbom-current179-ir-continuation'
original_freeze = original / 'source-freeze.json'
assert sha(original_freeze) == '5f9374511f5f9d1ca00a1b1cc11bb1845914e4d20d19b458051cf78c17507624'
original_rows = read(original_freeze)['files']
for name, row in original_rows.items():
    path = original / name
    assert sha(path) == row['sha256'], name
    protected[str(path)] = row['sha256']
raw_review_freeze = original / 'reviewer/source-freeze.json'
assert sha(raw_review_freeze) == 'fb2529078308fd3e4c816402aa3df1d4a01e52cb32a079a86e9366d5dbedbd6b'
protected[str(raw_review_freeze)] = sha(raw_review_freeze)

environment = PROJECT / 'work/sbom-current179-ir-environment'
for name in ['launch-receipt.json', 'capsule-manifest.json', 'source-freeze.json']:
    assert (environment / 'reference' / name).read_bytes() == (original / name).read_bytes()
for path, expected in protected.items():
    assert sha(path) == expected, path

report = {
    'completed_at': datetime.now(timezone.utc).isoformat(),
    'status': 'passed', 'packages': PACKAGES, 'tests': results,
    'original_frozen_files_verified': len(original_rows),
    'protected_files': protected,
    'subprocess_or_host_execution': False,
    'actual_lineage_or_raw_reviewer_executed': False,
    'effects_inspected': False,
}
with (OUT / 'source-checks.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'tests': results, 'protected_files': len(protected)}))
