"""Run one authorized read-only observation and preserve all returned bytes locally."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SSH = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
source = HERE / 'capture_remote.py'
output = HERE / 'capture-01'
output.mkdir()
source_bytes = source.read_bytes()
(output / 'capture_remote.py').write_bytes(source_bytes)
started = datetime.now(timezone.utc).isoformat()
process = subprocess.run([SSH, 'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
    '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-I', '-B', '-c', source_bytes.decode()],
    capture_output=True)
for name, data in (('stdout.json', process.stdout), ('stderr.txt', process.stderr)):
    with (output / name).open('xb') as stream:
        stream.write(data)
receipt = {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
    'returncode': process.returncode, 'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
    'stdout_sha256': hashlib.sha256(process.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(process.stderr).hexdigest(),
    'remote_mutations': False, 'effects_inspected': False}
with (output / 'receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(process.returncode)
