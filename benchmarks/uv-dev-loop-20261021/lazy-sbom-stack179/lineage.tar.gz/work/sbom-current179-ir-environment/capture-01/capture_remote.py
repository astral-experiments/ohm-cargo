"""Read-only terminal boundary and whitelisted environment observation; no effects."""
import ast
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import stat
import subprocess
from types import SimpleNamespace

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
CAPSULE = ROOT / 'continuations/ir-check-01'
CAPSULE_SHA = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
FAILED_CAPTURE = 'd20d773a4f8c5016fbe6f20efc67cec9089832e53b886a767e5de2a1f0b6a109'
CORE_SHA = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'
ERROR_SHA = 'c93a5eca0735e877580f9cc81dcbea2352617de34719f62588dae706c2149b33'


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def record(path):
    need(path.resolve() == path and path.is_file() and not path.is_symlink(), 'noncanonical file: ' + str(path))
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode)}


def read(path):
    return json.loads(path.read_text())


def run(argv):
    result = subprocess.run(argv, capture_output=True, text=True)
    return {'argv': argv, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}


def metadata(source, environment):
    tree = ast.parse(source)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                    and node.name == 'build_environment_metadata')
    namespace = {'os': SimpleNamespace(environ=environment)}
    exec(compile(ast.Module(body=[function], type_ignores=[]), '<frozen-build-environment-only>', 'exec'), namespace)
    return namespace['build_environment_metadata']()


def main():
    need(socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000
         and ROOT.resolve() == ROOT and ROOT.stat().st_uid == 1000 and Path('/').stat().st_uid == 0,
         'wrong host/root/identity')
    lock = (ROOT / 'experiment.lock').open('rb')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    session = run(['/usr/bin/tmux', 'has-session', '-t', 'ohm-sbom179-ir-completion-01'])
    need(session['returncode'] == 1, 'continuation session is not terminal')
    need(sha(CAPSULE / 'capsule-manifest.json') == CAPSULE_SHA, 'capsule manifest differs')
    capsule = read(CAPSULE / 'capsule-manifest.json')
    need({str(path.relative_to(CAPSULE)) for path in CAPSULE.rglob('*') if path.is_file()}
         == set(capsule['files']) | {'capsule-manifest.json'}, 'capsule members differ')
    capsule_records = {name: record(CAPSULE / name) for name in capsule['files']}
    need(capsule_records == capsule['files'], 'capsule bytes differ')
    capsule_records['capsule-manifest.json'] = record(CAPSULE / 'capsule-manifest.json')
    old_capture = CAPSULE / 'failed/transfer-manifest.json'
    need(sha(old_capture) == FAILED_CAPTURE, 'original capture differs')
    old_files = read(old_capture)['files']
    need(len(old_files) == 768, 'original capture count differs')
    protected = {}
    for name, expected in old_files.items():
        path = PurePosixPath(name)
        need(str(path) == name and not path.is_absolute() and '..' not in path.parts, 'unsafe retained name')
        if name in {'collection-identity.json', 'failure-boundary.json'}:
            continue
        protected[name] = record(ROOT / name)
        need(protected[name] == expected, 'retained original differs: ' + name)
    boundary = read(CAPSULE / 'failed/failure-boundary.json')
    fixture = {name: record(ROOT / name) for name in boundary['check_fixture_files']}
    need(fixture == boundary['check_fixture_files'] and len(fixture) == 5, 'untouched check fixture differs')
    need({str(path.relative_to(ROOT)) for path in (ROOT / 'fixtures/check-ir-confirmation').rglob('*') if path.is_file()}
         == set(fixture), 'unexpected check fixture member')
    absent = list(boundary['absent_paths']) + ['results/ir-completion-01',
        'results/ir-completion-01/check.run.stdout', 'results/ir-completion-01/check.run.stderr',
        'results/ir-completion-01/check-occupancy.txt']
    absent_state = {name: not (ROOT / name).exists() and not (ROOT / name).is_symlink() for name in absent}
    need(all(absent_state.values()), 'new check work/output exists')
    need({path.name for path in (ROOT / 'results').iterdir()} == {'ir-confirmation.json', 'test-ir-confirmation'},
         'unexpected result directory')
    logs = {}
    for suffix in ('stdout', 'stderr'):
        path = ROOT / ('logs/ir-completion-01.controller.' + suffix)
        logs[path.name] = {**record(path), 'text': path.read_text()}
    need(logs['ir-completion-01.controller.stdout']['bytes'] == 0
         and logs['ir-completion-01.controller.stderr']['sha256'] == ERROR_SHA
         and logs['ir-completion-01.controller.stderr']['bytes'] == 625,
         'terminal controller logs differ')
    error = logs['ir-completion-01.controller.stderr']['text']
    need('complete_ir.py", line 44, in main' in error
         and 'controller inherited build environment differs before new work' in error,
         'failure control-flow boundary differs')
    core = ROOT / 'work/benchmark/paired.py'
    need(sha(core) == CORE_SHA, 'frozen environment extractor differs')
    source = core.read_text()
    manifest_path = ROOT / 'results/test-ir-confirmation/manifest.json'
    manifest = read(manifest_path)
    expected = manifest['inherited_build_environment']
    direct = metadata(source, dict(os.environ))
    # Read only build-setting variables from the tmux server, never emit full
    # process environments, registry credentials, or unrelated environment values.
    tmux_pid = run(['/usr/bin/tmux', 'display-message', '-p', '#{pid}'])
    need(tmux_pid['returncode'] == 0 and tmux_pid['stdout'].strip().isdigit(), 'tmux server unavailable')
    pid = int(tmux_pid['stdout'])
    proc = Path('/proc') / str(pid)
    need(proc.stat().st_uid == os.getuid(), 'tmux server owner differs')
    server_raw = {}
    for field in (proc / 'environ').read_bytes().split(b'\0'):
        if b'=' in field:
            key, value = field.split(b'=', 1)
            server_raw[key.decode()] = value.decode()
    server = metadata(source, server_raw)
    # Names come from the exact frozen extractor; values outside this allowlist
    # are neither retained nor displayed. Dynamic CARGO_PROFILE_ names already
    # present in the observed contexts are included.
    function = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)
                    and node.name == 'build_environment_metadata')
    fixed_names = ast.literal_eval(function.body[0].value)
    # Discover build-profile names without retaining other global values.
    global_probe = subprocess.run(['/usr/bin/tmux', 'show-environment', '-g'], capture_output=True, text=True)
    need(global_probe.returncode == 0, 'tmux global environment discovery failed')
    profile_names = {line.lstrip('-').split('=', 1)[0] for line in global_probe.stdout.splitlines()
                     if line.lstrip('-').startswith('CARGO_PROFILE_')}
    names = sorted(set(fixed_names) | set(expected) | set(direct) | set(server) | profile_names)
    del global_probe
    global_rows, merged = {}, dict(server)
    for name in names:
        result = run(['/usr/bin/tmux', 'show-environment', '-g', name])
        need(result['returncode'] in (0, 1), 'tmux environment lookup failed')
        global_rows[name] = result
        if result['returncode'] == 0:
            value = result['stdout'].rstrip('\n')
            if value == '-' + name:
                merged.pop(name, None)
            else:
                need(value.startswith(name + '='), 'unexpected tmux environment response')
                merged[name] = value[len(name) + 1:]
    reconstructed = metadata(source, merged)
    delta = {name: {'retained_test': expected.get(name), 'current_tmux_reconstruction': reconstructed.get(name)}
             for name in sorted(set(expected) | set(reconstructed)) if expected.get(name) != reconstructed.get(name)}
    options = {name: run(['/usr/bin/tmux', 'show-options', '-g', name])
               for name in ('default-shell', 'default-command', 'update-environment')}
    # Final preservation rehashes, without interpreting sample timing/count data.
    need(all(record(ROOT / name) == row for name, row in protected.items()), 'original changed during capture')
    need(all(record(CAPSULE / name) == row for name, row in capsule_records.items()), 'capsule changed during capture')
    need(all(record(ROOT / name) == row for name, row in fixture.items()), 'fixture changed during capture')
    need(all(not (ROOT / name).exists() and not (ROOT / name).is_symlink() for name in absent), 'output appeared during capture')
    print(json.dumps({'status': 'passed', 'captured_at': datetime.now(timezone.utc).isoformat(),
        'host': socket.gethostname(), 'root': str(ROOT), 'uid': os.getuid(), 'affinity': sorted(os.sched_getaffinity(0)),
        'read_only': True, 'effects_inspected': False, 'new_check_samples': 0, 'new_test_samples': 0,
        'session': session, 'logs': logs, 'protected_original_files': protected, 'capsule_files': capsule_records,
        'untouched_check_fixture': fixture, 'absent_paths': absent_state,
        'retained_test_manifest': record(manifest_path), 'environment_extractor_sha256': CORE_SHA,
        'retained_test_inherited_build_environment': expected, 'current_ssh_inherited_build_environment': direct,
        'current_tmux_server_inherited_build_environment': server, 'current_tmux_global_queries': global_rows,
        'current_tmux_reconstructed_inherited_build_environment': reconstructed, 'current_tmux_delta': delta,
        'tmux_options': options, 'tmux_pid': pid,
        'environment_provenance_limit': 'The failed controller has exited. Current SSH/server/global environments are observed; the failed process environment is not retroactively captured. The reconstruction is current tmux state, not a claimed historical process snapshot.',
        'retained_test_machine': {key: manifest['machine'][key] for key in ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid')},
        'final_rehash': 'passed'}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
