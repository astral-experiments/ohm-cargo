"""Pure source/captured-metadata checks; no host, workloads, or effects."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / 'sbom-current179-ir-continuation'
spec = importlib.util.spec_from_file_location('environment_launcher', HERE / 'launch_remote.py')
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class SourceTests(unittest.TestCase):
    def test_only_path_added_to_original_controller_command(self):
        expected = json.loads((ORIGINAL / 'launch-receipt.json').read_text())['remote']['command']
        actual = launcher.controller_command({'PATH': '/captured/test/path'})
        self.assertEqual(actual[0], '/usr/bin/env')
        self.assertEqual(actual[8], 'PATH=/captured/test/path')
        del actual[8]
        actual[0] = 'env'
        self.assertEqual(actual, expected)

    def test_extra_or_missing_inherited_settings_are_rejected(self):
        for value in ({}, {'PATH': ''}, {'PATH': '/x', 'RUSTFLAGS': '-Zfoo'}):
            with self.assertRaises(ValueError):
                launcher.controller_command(value)

    def test_capture_proves_zero_work_boundary_and_only_observed_path_delta(self):
        capture = json.loads((HERE / 'capture-01/stdout.json').read_text())
        self.assertEqual(capture['status'], 'passed')
        self.assertEqual(len(capture['protected_original_files']), 766)
        self.assertEqual(len(capture['capsule_files']), 21)
        self.assertEqual(len(capture['untouched_check_fixture']), 5)
        self.assertTrue(all(capture['absent_paths'].values()))
        self.assertEqual(set(capture['current_tmux_delta']), {'PATH'})
        self.assertEqual(set(capture['retained_test_inherited_build_environment']), {'PATH'})
        self.assertEqual(capture['new_check_samples'], 0)
        self.assertEqual(capture['new_test_samples'], 0)
        self.assertIs(capture['effects_inspected'], False)

    def test_both_terminal_controller_logs_are_exact(self):
        capture = json.loads((HERE / 'capture-01/stdout.json').read_text())
        for name, row in capture['logs'].items():
            data = (HERE / 'capture-01' / name).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), row['sha256'])
            self.assertEqual(data, row['text'].encode())
        self.assertEqual(capture['logs']['ir-completion-01.controller.stderr']['sha256'], launcher.FAILED_STDERR)

    def test_frozen_capsule_and_original_launch_unchanged(self):
        manifest = ORIGINAL / 'capsule-manifest.json'
        self.assertEqual(hashlib.sha256(manifest.read_bytes()).hexdigest(), launcher.CAPSULE_SHA)
        for name, row in json.loads(manifest.read_text())['files'].items():
            self.assertEqual(hashlib.sha256((ORIGINAL / name).read_bytes()).hexdigest(), row['sha256'])
        freeze = json.loads((ORIGINAL / 'source-freeze.json').read_text())
        for name, row in freeze['files'].items():
            self.assertEqual(hashlib.sha256((ORIGINAL / name).read_bytes()).hexdigest(), row['sha256'])

    def test_environment_guard_precedes_any_new_output_or_work(self):
        tree = ast.parse((ORIGINAL / 'complete_ir.py').read_text())
        main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
        environment_guard = next(node for node in main.body if isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call) and node.value.args
            and any(isinstance(part, ast.Constant) and part.value == 'controller inherited build environment differs before new work'
                    for part in ast.walk(node)))
        output_create = next(node for node in main.body if isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
            and isinstance(node.value.func.value, ast.Name) and node.value.func.value.id == 'output'
            and node.value.func.attr == 'mkdir')
        self.assertEqual(environment_guard.lineno, 44)
        self.assertLess(environment_guard.lineno, output_create.lineno)
        self.assertLess(output_create.lineno, next(node.lineno for node in main.body if isinstance(node, ast.Try)))

    def test_launcher_does_not_mutate_old_logs_or_controller(self):
        source = (HERE / 'launch_remote.py').read_text()
        self.assertNotIn('os.environ[', source)
        self.assertNotIn('unlink(', source)
        self.assertNotIn('rename(', source)
        self.assertNotIn('replace(', source)
        self.assertIn("'logs/ir-completion-02.controller.'", source)
        self.assertIn("'ohm-sbom179-ir-completion-02'", source)
        self.assertEqual(source.count("str(CAPSULE / 'complete_ir.py')"), 1)
        self.assertNotIn("'analyze'", source)
        self.assertNotIn("'cargo'", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
