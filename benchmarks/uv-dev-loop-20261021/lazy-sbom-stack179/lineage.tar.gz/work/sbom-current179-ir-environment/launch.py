"""Launch only after exact source/capture approval; preserve this attempt's streams."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
SSH = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
CAPSULE_SHA = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(value, reason):
    if not value:
        raise ValueError(reason)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approval', type=Path, required=True)
    args = parser.parse_args()
    freeze_path = HERE / 'source-freeze.json'
    freeze = json.loads(freeze_path.read_text())
    for name, row in freeze['files'].items():
        path = HERE / name
        need(path.resolve() == path and path.is_file() and not path.is_symlink()
             and sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'frozen input differs: ' + name)
    approval = json.loads(args.approval.read_text())
    capture_path = HERE / 'capture-01/stdout.json'
    need(approval['status'] == 'passed' and approval['authorized_operation'] == 'launch-unchanged-fixed-check-with-retained-path'
         and approval['source_freeze_sha256'] == sha(freeze_path)
         and approval['capture_sha256'] == sha(capture_path)
         and approval['capsule_manifest_sha256'] == CAPSULE_SHA, 'exact root launch approval required')
    output = HERE / 'launch-attempt02'
    need(not output.exists(), 'attempt02 already used')
    capture = json.loads(capture_path.read_text())
    need(capture['status'] == 'passed' and capture['final_rehash'] == 'passed'
         and set(capture['current_tmux_delta']) == {'PATH'} and capture['effects_inspected'] is False,
         'reviewed environment boundary differs')
    sources = {name: (HERE / name).read_text() for name in ('launch_remote.py', 'amendment.md')}
    request = {'operation': approval['authorized_operation'], 'source_freeze_sha256': sha(freeze_path),
        'root_approval_sha256': sha(args.approval), 'capture_sha256': sha(capture_path),
        'capsule_manifest_sha256': CAPSULE_SHA,
        'retained_test_manifest_sha256': capture['retained_test_manifest']['sha256'],
        'retained_inherited_build_environment': capture['retained_test_inherited_build_environment'],
        'failed_controller_log_sha256': {suffix: capture['logs']['ir-completion-01.controller.' + suffix]['sha256']
                                         for suffix in ('stdout', 'stderr')},
        'source_text': sources, 'source_sha256': {name: hashlib.sha256(value.encode()).hexdigest() for name, value in sources.items()}}
    payload = (json.dumps(request, indent=2, sort_keys=True) + '\n').encode()
    output.mkdir()
    (output / 'request.json').write_bytes(payload)
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run([SSH, 'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
        '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-I', '-B', '-c', sources['launch_remote.py'],
        hashlib.sha256(payload).hexdigest()], input=payload, capture_output=True)
    for suffix, data in (('stdout', process.stdout), ('stderr', process.stderr)):
        with (output / suffix).open('xb') as stream:
            stream.write(data)
    receipt = {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
        'returncode': process.returncode, 'request_sha256': sha(output / 'request.json'),
        'source_freeze_sha256': sha(freeze_path), 'approval_sha256': sha(args.approval),
        'stdout_sha256': sha(output / 'stdout'), 'stderr_sha256': sha(output / 'stderr')}
    if process.returncode == 0:
        receipt['remote'] = json.loads(process.stdout)
    with (output / 'receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(receipt, indent=2))
    raise SystemExit(process.returncode)


if __name__ == '__main__':
    main()
