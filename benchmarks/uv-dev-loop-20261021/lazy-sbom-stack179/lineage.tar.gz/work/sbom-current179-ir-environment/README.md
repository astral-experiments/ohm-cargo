The first continuation failed before output creation at the unchanged inherited
environment guard. `capture-01/` contains the authorized read-only host4 capture,
its exact source/receipt, and both terminal controller logs. No effects were read.
`amendment.md` explains the current PATH evidence and its historical limitation.

`launch.py` is prepared only. It requires a root approval JSON with:

```
status: passed
authorized_operation: launch-unchanged-fixed-check-with-retained-path
source_freeze_sha256: <this package's source-freeze.json SHA>
capture_sha256: 433c3d6c87efe7d5e21d7f6a5d6b4dc410cc63d7e50253a8ea1ad80215b557c3
capsule_manifest_sha256: 16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc
```

After independent review and explicit root release, the single-use command is:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-ir-environment/launch.py \
  --approval ABSOLUTE_ROOT_APPROVAL_JSON
```

It preserves attempt01 in place, adds one new metadata namespace with request,
source, raw failed logs, before-boundary and seal, and uses distinct attempt02
controller logs. Only PATH is set to the retained test controller value; the
frozen capsule and sample/analysis/gate code stay unchanged. Its strict original
environment and machine guards remain active. A second attempt is never automatic.

After terminal status, retain the complete original collector output. Its existing
recursive continuation/log selection includes the new lineage. Before the original
independent reviewer may inspect effects, join the final captured history/request,
its seal, this source freeze and the root approval to the attempt02 launch receipt;
verify exact failed-log copies and matching check/test inherited environments.
This additional pre-effect join will be reviewed separately. The original raw,
statistics and performance-gate functions need no changes. No native phase is
authorized by this launcher.
