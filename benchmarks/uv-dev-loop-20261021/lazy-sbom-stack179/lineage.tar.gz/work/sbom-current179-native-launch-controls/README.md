These are prospective source-only controls for the already frozen current179
SBOM native confirmation. At freeze, no real prerequisite package, transfer or
native launch has been performed. Root review is required before any use.

The original 174-input continuation, original native entry/controller, fixed
protocol and strict prerequisite wrapper remain unchanged. This package copies
the exact strict wrapper; it adds no sample, analysis, exclusion or retry logic.
Native test and check remain 30 pairs plus 2 warmup pairs each, one invocation per
variant per pair, with original seeds 20261021103/104 and the original reversed
target assignment. All statistical gates remain in the original controller.

The two separately accepted prerequisites are the existing current179 IR raw and
statistics review and the new PATH-continuation lineage review. Effects payloads
are copied and hashed without interpretation. The original native entry still
checks the accepted primary IR gate. Passing the lineage review alone cannot
authorize native measurement.

The controller PATH is the exact retained test/check value pinned in remote.py.
An additional entry guard checks the actual tmux child's complete recorded build
environment and machine identity against accepted IR, records that proof, and
execs the unchanged strict wrapper. Unexpected extra build settings fail before
the original native controller runs. Per-sample environments and commands remain
the original frozen configs.

There are three distinct future operations:

1. `prepare.py` creates only the new local `prepared/` directory. It requires
   accepted source-bound reviews, approvals, every collected IR payload, the
   original archive, all lineage-bound inputs and every protected source input.
   It emits a complete prerequisite manifest and retained input records, then
   rehashes everything. Existing metadata is read-only.
2. `transport.py stage` requires a separate root approval of the exact prepared
   manifest. It transfers only those metadata/source payloads to the new owned
   remote `continuations/native-prerequisite-01`, while holding the existing
   experiment lock and verifying accepted IR bytes before and after. No Cargo,
   sampling, analysis or fixture preparation runs. Root reviews the returned
   complete payload index and actual stage receipts before launch.
3. `transport.py launch` requires another root approval binding both the local
   and remote stage receipts. It verifies the same inputs without modifying the
   staged prerequisite, preserves a new launch history, and starts exactly one
   native controller via the entry guard and existing strict wrapper.

No operation is automatic. Each uses an absent fixed attempt directory and
exclusive file creation. SSH errors and ambiguous remote outcomes are retained;
there is no retry. Local attempt directories are `stage-attempt01` and
`launch-attempt01`. Remote histories are `native-prerequisite-stage-01` and
`native-prerequisite-launch-01`; logs and tmux session have unique native suffixes.
The entry receipt is written by the child after launch, so it is deliberately
outside the transport history seal and will be bound by the final collection.
The existing collector already captures the complete continuations tree.

Future approval contracts

First retain the original raw-review execution approval exactly as used by the
unchanged reviewer. Before invoking that reviewer, root should write a separate
lineage acceptance with these fields:

```
valid: true
authorized_operation: accept-path-lineage-before-current179-ir-review
accepted_path_lineage_review_sha256: <passing lineage review hash>
source_freeze_sha256: 6f734b8eb9bbac6a61a7f93b105c068f542f9300d9dddb66482ef16611f002c4
ir_review_execution_approval_sha256: <unchanged future raw-review invocation approval>
collection_receipt_sha256: <same completed IR collection receipt>
reviewed_at: <actual UTC acceptance time>
```

The producer requires lineage review time <= root lineage acceptance time <= raw
review completion time. It binds the exact raw-review execution approval too.
Do not manufacture or backdate an acceptance, or modify an invocation approval
after it has been used. If those records do not exist, retain the condition for
root review; these controls must not silently weaken it.

After both reviews pass and the primary IR gate qualifies, a root preparation
approval must contain:

```
valid: true
authorized_operation: prepare-native-prerequisites-only
output: <absolute path to this package's prepared directory>
controls_source_freeze_sha256: <this package's final freeze>
accepted_ir_review_sha256: <review/review.json>
accepted_path_lineage_review_sha256: <lineage review>
accepted_path_lineage_approval_sha256: <root lineage acceptance above>
ir_review_execution_approval_sha256: <original review invocation approval>
reviewer_source_freeze_sha256: fb2529078308fd3e4c816402aa3df1d4a01e52cb32a079a86e9366d5dbedbd6b
strict_native_entry_sha256: 1f795f62bf284f934e5de79c4a589ff829dcacf9cb1058a8772c6b0b8b31bfe2
continuation_status_sha256: <accepted results/ir-completion-01/status.json>
capsule_manifest_sha256: 16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc
```

`prepare.py` additionally takes explicit paths to the IR review directory, its
original execution approval, the lineage review, and root lineage acceptance;
`--root-approval-sha256` and `--source-freeze-sha256` are mandatory. All inputs must
be canonical regular task files. No real input paths or hashes are invented here.

For stage, the separate root approval requires `valid: true`,
`authorized_operation: stage-fixed-native-prerequisites`,
`controls_source_freeze_sha256` and `prerequisite_manifest_sha256`.
For launch, use `authorized_operation: launch-fixed-native-prerequisites` and add
`stage_receipt_sha256` and `remote_stage_receipt_sha256` from the reviewed actual
transfer. Both transport invocations require explicit approval and source hashes.

All controllers use system Python with PYTHONPATH, PYTHONHOME and PYTHONSAFEPATH
removed and bytecode writes disabled. Pure checks use the same clean launch,
CPU 8, synthetic metadata only, and an audit hook denying subprocesses, exec and
network connections. No effects, host commands or real review execution occur
during the source/pure validation.

For a fresh pure replay, run `run_pure_checks.py --output <new immediate child
directory of this package>` under clean system Python on CPU 8. The first passing
pure attempts and their exact source versions are retained. The final passing
attempt also binds every call to the original contract's actual function signature.
