"""Run pure source/synthetic checks with actual collection/execution disabled."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import check_source


def main():
    destination = HERE / 'pure-check-attempt02'
    if destination.exists():
        raise ValueError('retain the existing pure-check attempt')
    before = check_source.verify()
    sources = {str(path.relative_to(HERE)): check_source.sha(path) for path in HERE.rglob('*.py')}

    def deny(event, args):
        if event in ['subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.exec',
                     'os.fork', 'socket.connect', 'socket.bind']:
            raise RuntimeError('pure check blocked external action: ' + event)

    sys.addaudithook(deny)
    import evidence

    def denied_collection(*args, **kwargs):
        raise RuntimeError('actual collection review is forbidden during pure checks')

    evidence.Collection.__init__ = denied_collection
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromName('test_review'),
                                unittest.defaultTestLoader.loadTestsFromName('test_profiler_alias')])
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    after = check_source.verify()
    assert before == after
    assert all(check_source.sha(HERE / name) == expected for name, expected in sources.items())
    output = stream.getvalue()
    destination.mkdir()
    (destination / 'stdout').write_text('')
    (destination / 'stderr').write_text(output)
    report = {'checked_at': datetime.now(timezone.utc).isoformat(), 'valid': result.wasSuccessful(),
              'returncode': 0 if result.wasSuccessful() else 1, 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'source_sha256': sources,
              'stdout_sha256': hashlib.sha256(b'').hexdigest(),
              'stderr_sha256': hashlib.sha256(output.encode()).hexdigest(),
              'actual_collection_constructor_disabled': True,
              'subprocess_network_execution_blocked': True, 'actual_reviewer_or_effects_executed': False,
              'source_audit': after}
    (destination / 'result.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(output)
    print(json.dumps({'valid': report['valid'], 'tests': result.testsRun,
                      'result_sha256': check_source.sha(destination / 'result.json')}))
    return report['returncode']


if __name__ == '__main__':
    raise SystemExit(main())
