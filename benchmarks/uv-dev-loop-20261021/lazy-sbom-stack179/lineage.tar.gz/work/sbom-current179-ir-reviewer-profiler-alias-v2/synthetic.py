import lineage
"""Tiny synthetic collected batches for pure review tests; never runs Cargo."""
from datetime import datetime, timezone
import csv
import json
from pathlib import Path
import stat

from evidence import BINARIES, CSV_FIELDS, ORIGINAL, REFERENCE, REMOTE, digest, read, sha
from parser import load
from preparation import edited
from raw import plan, recorded_files, substitute


def timestamp(seconds):
    return datetime.fromtimestamp(1792587600 + seconds, timezone.utc).isoformat()


class SyntheticCollection:
    def __init__(self, root, phase):
        self.root, self.phase, self.files = Path(root), phase, {}

    def path(self, name):
        return self.root / name.removeprefix(REMOTE + '/')

    def put(self, name, value):
        path = self.path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value)
        return path

    def dump(self, name, value):
        return self.put(name, json.dumps(value, indent=2) + '\n')

    def json(self, name):
        return read(self.path(name))

    def refresh(self):
        self.files = {str(path.relative_to(self.root)): {'sha256': sha(path), 'bytes': path.stat().st_size,
                      'mode': stat.S_IMODE(path.stat().st_mode)} for path in self.root.rglob('*') if path.is_file()}

    def verify_seal(self, directory):
        from evidence import Collection
        return Collection.verify_seal(self, directory)


def compiler_logs(expectations, target, workload):
    frozen = expectations['workloads'][workload]['targets'][target]
    commands = []
    for text, count in frozen['compiler_signatures'].items():
        row = json.loads(text)
        for _ in range(count):
            args = [expectations['rustc'], '--crate-name', row['crate']]
            for option, key in [('--crate-type', 'crate_type'), ('--emit', 'emit')]:
                if row[key] is not None:
                    args += [option, row[key]]
            if row['test']:
                args += ['--test']
            if row['link_only']:
                args += ['-Zlink-only']
            args += ['--out-dir', row['output_directory'].replace('@target', target),
                     row['source'].replace('@target', target)]
            commands.append('     Running `' + ' '.join(args) + '`')
    artifacts = [{'reason': 'compiler-artifact', 'package_id': expectations['uv_package'],
                  'target': {'name': row['name'], 'kind': row['kind']}, 'profile': {'test': row['test']},
                  'fresh': False, 'executable': None} for row in frozen['compiled_targets']]
    stdout = '\n'.join(json.dumps(row) for row in artifacts + [{'reason': 'build-finished', 'success': True}]) + '\n'
    return stdout, '    Checking uv v0.0.0\n' + '\n'.join(commands) + '\n'


def build(root, workload, instruction):
    group = 'ir-confirmation' if instruction else 'native-confirmation'
    collection = SyntheticCollection(root, group)
    name, batch = workload + '-' + group, REMOTE + '/' + lineage.result_name(workload, group)
    analysis = REMOTE + '/' + lineage.analysis_name(workload, group)
    config = read(REFERENCE / (name + '.json'))
    final, protocol = read(REFERENCE / 'configs-finalized.json'), read(REFERENCE / 'protocol.json')
    guard, expectations = read(REFERENCE / 'source-guard.json'), read(REFERENCE / 'diagnostic-expectations.json')
    catalog = read(REFERENCE / 'input-catalog.json')
    for remote, reference in [('configs/' + name + '.json', name + '.json'),
                              ('work/benchmark/source-guard.json', 'source-guard.json'),
                              ('metadata/diagnostic-expectations.json', 'diagnostic-expectations.json'),
                              ('metadata/input-catalog.json', 'input-catalog.json'),
                              ('stage-assets.json', 'profiler-stage-assets.json')]:
        collection.put(remote, (REFERENCE / reference).read_text())
    original = (REFERENCE / 'original.bin').read_bytes()
    source = collection.path('uv/crates/uv/src/lib.rs')
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(original)
    source.chmod(guard['source_mode'])
    state_path = REMOTE + '/fixtures/' + name
    collection.put(state_path + '/original.bin', original.decode())
    targets = {variant: config['variant_env'][variant]['CARGO_TARGET_DIR'] for variant in BINARIES}
    fixture_manifest = {'source': guard['source'], 'workspace': config['cwd'], 'source_sha256': ORIGINAL,
                        'source_mode': guard['source_mode'], 'targets': targets,
                        'shared_build_dir': config['env']['CARGO_BUILD_BUILD_DIR']}
    collection.dump(state_path + '/manifest.json', fixture_manifest)
    phase = next(row for row in protocol['phases'] if row['workload'] == workload
                 and row['metric'] == ('cargo_ir' if instruction else 'native_wall_seconds'))
    orders = {'warmup': plan(2, phase['seed'] ^ 0x5A17), 'measurement': plan(phase['pairs'], phase['seed'])}
    samples, journal, compiler, validation, last_tokens = [], [], [], [], {}
    journal.append({'at': timestamp(0), 'operation': 'initialize', 'source_sha256': ORIGINAL})
    parser = load()
    for stage, pairs in orders.items():
        for pair, variants in enumerate(pairs):
            for position, variant in enumerate(variants):
                index = len(samples)
                clock = 10 + index * 10
                label = f'{stage}-{pair:04d}-{position}-{variant}'
                context = {'cargo': config['canonical_executable'], 'output': batch, 'stage': stage,
                           'pair': pair, 'variant': variant, 'position': position, 'phase': 'confirmation'}
                environment = dict(config['env'], **config['variant_env'][variant])
                before, after = (edited(original, batch, stage, pair, marker) for marker in ('before', 'after_'))
                entry = {'at': timestamp(clock - 1), 'operation': 'prepare', 'batch': batch,
                         'stage': stage, 'pair': pair, 'variant': variant, 'target': targets[variant],
                         'shared_build_dir': config['env']['CARGO_BUILD_BUILD_DIR'],
                         'before_sha256': digest(before), 'after_sha256': digest(after),
                         'before_bytes': len(before), 'after_bytes': len(after),
                         'warm_command': guard['commands'][workload], 'warm_wall_ns': 100000000,
                         'source_mtime_ns': int((1792587600 + clock - 1) * 1000000000)}
                if workload == 'check':
                    proof_dir = batch + f'/check-preparation/{stage}-{pair:08d}-{variant}'
                    identity = {key: entry[key] for key in ('batch', 'stage', 'pair', 'variant')}
                    fresh = json.dumps({'reason': 'compiler-artifact', 'fresh': True}) + '\n'
                    fresh += json.dumps({'reason': 'build-finished', 'success': True}) + '\n'
                    calls = []
                    allowed = ['/usr/bin/taskset', config['canonical_executable']]
                    for number in range(1, 4):
                        out = collection.put(proof_dir + f'/call-{number}.stdout', fresh)
                        err = collection.put(proof_dir + f'/call-{number}.stderr', '')
                        call = {'number': number, 'returncode': 0, 'stdout_sha256': sha(out), 'stderr_sha256': sha(err)}
                        if number == 3:
                            trace = collection.put(proof_dir + '/call-3.execve', ''.join(
                                f'1 execve({json.dumps(path)}, [], []) = 0\n' for path in allowed))
                            call['execve_sha256'] = sha(trace)
                        calls.append(call)
                    proof = {'state': 'complete', 'identity': identity, 'fixed_native_calls': 3,
                             'command': entry['warm_command'], 'target': targets[variant],
                             'shared_build_dir': entry['shared_build_dir'], 'environment_sha256': 'a' * 64,
                             'source': {'path': guard['source'], 'sha256': digest(before), 'bytes': len(before),
                                        'mode': guard['source_mode'], 'mtime_ns': entry['source_mtime_ns'] - 1},
                             'calls': calls, 'allowed_final_executables': allowed,
                             'final_freshness': {'artifact_records': 1, 'all_artifacts_fresh': True,
                                                 'successful_execve_paths': allowed,
                                                 'compiler_build_script_test_executions': 0}}
                    proof_path = collection.dump(proof_dir + '/manifest.json', proof)
                    entry['preparation_proof'] = {'path': proof_dir + '/manifest.json', 'sha256': sha(proof_path)}
                journal.append(entry)
                last_tokens[variant] = digest(after)
                stdout, stderr = compiler_logs(expectations, targets[variant], workload)
                out = collection.put(batch + '/logs/' + label + '.stdout', stdout)
                err = collection.put(batch + '/logs/' + label + '.stderr', stderr)
                record = {key: value for key, value in entry.items() if key != 'at'}
                prep_stdout = (json.dumps({'reason': 'build-finished', 'success': True}) + '\n' if workload == 'test' else '')
                collection.put(batch + '/logs/' + label + '.prepare.stdout', prep_stdout + json.dumps(record, indent=2) + '\n')
                collection.put(batch + '/logs/' + label + '.prepare.stderr', '')
                outcome = {'returncode': 0, 'wall_ns': 200000000, 'user_seconds': 0.05, 'system_seconds': 0.01,
                           'minor_faults': 1, 'major_faults': 0, 'voluntary_context_switches': 2,
                           'involuntary_context_switches': 0}
                sample = {'stage': stage, 'pair': pair, 'order': 'AB' if variants[0] == 'baseline' else 'BA',
                          'position': position, 'variant': variant, 'started_at': timestamp(clock),
                          'command': [substitute(value, context) for value in config['command']],
                          'configured_environment': environment, 'installed_sha256': BINARIES[variant],
                          'load_average_before': [0, 0, 0], 'load_average_after': [0, 0, 0],
                          'executable_unchanged': True, 'metrics': {}, 'metric_files': {}, **outcome,
                          'stdout': batch + '/logs/' + label + '.stdout',
                          'stderr': batch + '/logs/' + label + '.stderr',
                          'prepare': {**outcome, 'stdout': batch + '/logs/' + label + '.prepare.stdout',
                                      'stderr': batch + '/logs/' + label + '.prepare.stderr'}}
                if instruction:
                    value = 1000 if variant == 'baseline' else 900
                    profile_name = batch + f'/callgrind-{stage}-{pair}-{variant}.out'
                    cargo_index = sample['command'].index(config['canonical_executable'])
                    profile_path = collection.put(profile_name, 'creator: callgrind-3.22.0\ncmd:  '
                        + ' '.join(sample['command'][cargo_index:]) + '\nevents: Ir\nsummary: ' + str(value) + '\n')
                    sample.update(metric_cargo_ir=value, metrics={'cargo_ir': value},
                                  metric_files={'cargo_ir': {'path': profile_name, 'sha256': sha(profile_path)}})
                samples.append(sample)
                compiler.append({'stage': stage, 'pair': pair, 'variant': variant, 'stdout_sha256': sha(out),
                                 'stderr_sha256': sha(err), **parser.parse_run(stdout, stderr, targets[variant])})
                validation.append({'stage': stage, 'pair': pair, 'variant': variant, 'compiled_packages': ['uv'],
                                   'before_sha256': digest(before), 'after_sha256': digest(after), 'target': targets[variant]})
    finish = 10 + (len(samples) - 1) * 10 + 1
    restored = {'operation': 'restore', 'source': guard['source'], 'sha256': ORIGINAL}
    journal.append({'at': timestamp(finish - 0.5), **restored})
    collection.put(state_path + '/journal.jsonl', ''.join(json.dumps(row) + '\n' for row in journal))
    collection.dump(state_path + '/state.json', {'current_sha256': ORIGINAL, 'restored': True, 'last_tokens': last_tokens})
    collection.dump(batch + '/logs/cleanup.stdout', restored)
    collection.put(batch + '/logs/cleanup.stderr', '')
    collection.dump(batch + '/samples.json', samples)
    collection.put(batch + '/samples.jsonl', ''.join(json.dumps(row) + '\n' for row in samples))
    with collection.path(batch + '/samples.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS + (['metric_cargo_ir'] if instruction else []), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(samples)
    collection.dump(batch + '/compiler-audit.json', {
        'valid': True, 'source_restored': True, 'source_identity': guard['source_identity'],
        'fixture_validation_valid': True, 'expectations_sha256': sha(collection.path('metadata/diagnostic-expectations.json')),
        'samples': compiler})
    collection.dump(batch + '/fixture-validation.json', {'valid': True, 'expected_compiled_packages': ['uv'],
                     'source_restored': True, 'samples': validation, 'errors': []})
    collection.dump(analysis + '/analysis.json', {'synthetic_no_effects_computed': True})
    records = recorded_files(config, final, catalog, collection.json('stage-assets.json'))
    manifest = {'state': 'complete', 'phase': 'confirmation', 'seed': phase['seed'], 'pairs': phase['pairs'],
                'warmup_pairs': 2, 'plans': orders, 'configuration': config, 'sample_count': len(samples),
                'configuration_path': REMOTE + '/configs/' + name + '.json',
                'configuration_sha256': final['config_sha256'][name], 'variant_sha256': BINARIES,
                'variant_sha256_after': BINARIES, 'variant_paths': config['variants'],
                'canonical_executable': config['canonical_executable'], 'recorded_file_sha256': records,
                'recorded_file_sha256_after': records, 'started_at': timestamp(1), 'finished_at': timestamp(finish),
                'machine': {'uid': 1000, 'effective_uid': 1000, 'root_directory_owner_uid': 0,
                            'uname': ['Linux', 'synthetic', 'r', 'v', 'x86_64', ''], 'affinity': list(range(8))},
                'cleanup': {**outcome, 'stdout': batch + '/logs/cleanup.stdout', 'stderr': batch + '/logs/cleanup.stderr'}}
    collection.dump(batch + '/manifest.json', manifest)
    state = {'started_at': timestamp(0), 'finished_at': timestamp(finish + 1),
             'results': {workload: {'primary': workload == 'test',
                'analysis_sha256': sha(collection.path(analysis + '/analysis.json')),
                'compiler_audit_sha256': sha(collection.path(batch + '/compiler-audit.json'))}}}
    result_dir = collection.path(batch)
    raw_sealed = {str(path.relative_to(result_dir)): sha(path)
                  for path in result_dir.rglob('*') if path.is_file()}
    if instruction:
        collection.dump('results/ir-completion-01/raw-seals.json', {workload: raw_sealed})
    else:
        collection.dump(batch + '/seal.json', raw_sealed)
    collection.refresh()
    return collection, protocol, final, state
