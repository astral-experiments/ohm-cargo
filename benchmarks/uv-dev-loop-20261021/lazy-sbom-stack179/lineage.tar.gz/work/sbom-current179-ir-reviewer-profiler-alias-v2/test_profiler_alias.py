"""Pure package/identity boundaries; retained corpus contains input maps only."""
import ast
import copy
import unittest

import evidence
import profiler_alias as alias
import raw


class ProfilerAliasChecks(unittest.TestCase):
    def setUp(self):
        self.config = evidence.read(evidence.REFERENCE / 'test-ir-confirmation.json')
        self.final = evidence.read(evidence.REFERENCE / 'configs-finalized.json')
        self.catalog = evidence.read(evidence.REFERENCE / 'input-catalog.json')
        self.stage = evidence.read(evidence.REFERENCE / 'profiler-stage-assets.json')
        self.proof = evidence.read(evidence.REFERENCE / 'profiler-alias-package-proof.json')

    def mapping(self):
        return alias.exact_alias(self.config, self.final, self.stage, self.proof)

    def test_exact_package_mapping(self):
        self.assertEqual(self.mapping(), {alias.ALIAS: alias.CANONICAL})
        result = raw.recorded_files(self.config, self.final, self.catalog, self.stage)
        self.assertEqual(len(result), 994)
        self.assertNotIn(alias.ALIAS, result)
        self.assertEqual(result[alias.CANONICAL], alias.CONTENT)

    def test_retained_input_map_corpus_matches_without_reviewing_outcomes(self):
        corpus = evidence.read(evidence.REFERENCE / 'input-map-corpus.json')
        self.assertEqual([row['workload'] for row in corpus['workloads']], ['test', 'check'])
        for row in corpus['workloads']:
            self.assertIs(row['both_fields_equal'], True)
            config = evidence.read(evidence.REFERENCE / (row['workload'] + '-ir-confirmation.json'))
            self.assertEqual(raw.recorded_files(config, self.final, self.catalog, self.stage),
                             row['recorded_files'])

    def test_wrong_alias_content_rejected(self):
        self.final['asset_sha256'][alias.ALIAS] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'frozen content differs'):
            self.mapping()

    def test_wrong_target_content_rejected(self):
        self.final['asset_sha256'][alias.CANONICAL] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'frozen content differs'):
            self.mapping()

    def test_wrong_package_identity_rejected(self):
        for key, value in [('sha256', '0' * 64), ('bytes', 1)]:
            with self.subTest(key=key):
                self.stage[alias.PACKAGE_KEY] = {**alias.PACKAGE, key: value}
                with self.assertRaisesRegex(ValueError, 'exact staged package'):
                    self.mapping()

    def test_missing_package_binding_rejected(self):
        for stage in [None, {}, {'another.deb': alias.PACKAGE}]:
            self.stage = stage
            with self.assertRaisesRegex(ValueError, 'exact staged package'):
                self.mapping()

    def test_wrong_symlink_target_rejected(self):
        for target in ['other.gz', '../valgrind.1.gz', '/usr/share/man/man1/valgrind.1.gz']:
            self.proof['members']['./usr/share/man/man1/valgrind.bin.1.gz']['linkname'] = target
            with self.assertRaisesRegex(ValueError, 'member/target/content proof differs'):
                self.mapping()

    def test_wrong_member_type_rejected(self):
        self.proof['members']['./usr/share/man/man1/valgrind.bin.1.gz']['type'] = '1'
        with self.assertRaisesRegex(ValueError, 'member/target/content proof differs'):
            self.mapping()

    def test_wrong_archive_content_rejected(self):
        self.proof['members']['./usr/share/man/man1/valgrind.1.gz']['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'member/target/content proof differs'):
            self.mapping()

    def test_unbound_canonical_input_rejected(self):
        self.config['record_files'].remove(alias.CANONICAL)
        with self.assertRaisesRegex(ValueError, 'target is not a frozen input'):
            self.mapping()

    def test_unbound_other_alias_cannot_disappear(self):
        unknown = alias.ALIAS + '.unproven'
        self.config['record_files'].append(unknown)
        self.final['asset_sha256'][unknown] = alias.CONTENT
        result = raw.recorded_files(self.config, self.final, self.catalog, self.stage)
        self.assertEqual(result[unknown], alias.CONTENT)
        observed_with_unproven_alias_collapsed = copy.deepcopy(result)
        del observed_with_unproven_alias_collapsed[unknown]
        with self.assertRaisesRegex(ValueError, 'before/after input hashes differ'):
            evidence.need(observed_with_unproven_alias_collapsed == result,
                          'before/after input hashes differ')

    def test_conflicting_catalog_rejected(self):
        self.catalog['snapshot']['tools']['unproven'] = {
            'path': alias.ALIAS, 'resolved': alias.CANONICAL + '.other'}
        with self.assertRaisesRegex(ValueError, 'conflicting profiler alias catalog'):
            raw.recorded_files(self.config, self.final, self.catalog, self.stage)

    def test_native_configuration_needs_no_profiler_package(self):
        self.config = evidence.read(evidence.REFERENCE / 'test-native-confirmation.json')
        self.stage = None
        self.assertEqual(self.mapping(), {})
        old = ast.parse((evidence.HERE / 'history/original-raw.py').read_text())
        function = next(node for node in old.body
                        if isinstance(node, ast.FunctionDef) and node.name == 'recorded_files')
        namespace = {'need': evidence.need}
        exec(compile(ast.Module(body=[function], type_ignores=[]), '<original recorded_files>', 'exec'), namespace)
        self.assertEqual(raw.recorded_files(self.config, self.final, self.catalog),
                         namespace['recorded_files'](self.config, self.final, self.catalog))

    def test_wrong_package_proof_rejected(self):
        self.proof['package']['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'package proof differs'):
            self.mapping()

    def test_extra_unbound_archive_alias_rejected(self):
        self.proof['members']['./usr/share/man/man1/unproven.gz'] = {
            'type': '2', 'linkname': 'valgrind.1.gz'}
        with self.assertRaisesRegex(ValueError, 'member/target/content proof differs'):
            self.mapping()


if __name__ == '__main__':
    unittest.main()
