"""Accept one package-proven profiler alias; never infer aliases from results."""
from evidence import REFERENCE, REMOTE, need, read

ALIAS = REMOTE + '/profiling-tools/valgrind/usr/share/man/man1/valgrind.bin.1.gz'
CANONICAL = REMOTE + '/profiling-tools/valgrind/usr/share/man/man1/valgrind.1.gz'
CONTENT = '3450eac3468a85242920ccb538d3a2cbe452e4bf726113b348c80a77d20063f3'
PACKAGE_KEY = 'profiling-tools/valgrind.deb'
PACKAGE = {'bytes': 14911212,
           'sha256': '744e081e5cf3d5c598b499dbb7d2250ea3f2869dde4a4d7b231fe6114f347d7d'}
MEMBERS = {
    './usr/share/man/man1/valgrind.bin.1.gz': {
        'name': './usr/share/man/man1/valgrind.bin.1.gz', 'type': '2',
        'linkname': 'valgrind.1.gz', 'size': 0, 'mode': 511, 'uid': 0, 'gid': 0,
    },
    './usr/share/man/man1/valgrind.1.gz': {
        'name': './usr/share/man/man1/valgrind.1.gz', 'type': '0',
        'linkname': '', 'size': 38612, 'mode': 420, 'uid': 0, 'gid': 0,
        'sha256': CONTENT,
    },
}


def exact_alias(configuration, final, stage_assets, proof):
    """Return no generic symlink policy: only the exact authenticated pair."""
    if ALIAS not in configuration['record_files']:
        return {}
    need(isinstance(stage_assets, dict) and stage_assets.get(PACKAGE_KEY) == PACKAGE,
         'profiler alias is not bound to the exact staged package')
    need(proof.get('status') == 'passed' and proof.get('package') == PACKAGE
         and proof.get('stage_asset_key') == PACKAGE_KEY,
         'profiler alias package proof differs')
    need(proof.get('members') == MEMBERS, 'profiler alias member/target/content proof differs')
    need(CANONICAL in configuration['record_files'], 'profiler alias target is not a frozen input')
    need(final['asset_sha256'].get(ALIAS) == final['asset_sha256'].get(CANONICAL) == CONTENT,
         'profiler alias/target frozen content differs')
    return {ALIAS: CANONICAL}


def frozen_alias(configuration, final, stage_assets):
    return exact_alias(configuration, final, stage_assets,
                       read(REFERENCE / 'profiler-alias-package-proof.json'))
