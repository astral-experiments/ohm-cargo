"""Source/retained-input checks only; never instantiate an actual collection."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify():
    protected = json.loads((HERE / 'history/protected-original-inputs.json').read_text())['files']
    for name, expected in protected.items():
        assert sha(Path(name)) == expected, name
    original = HERE.parent / 'sbom-current179-ir-continuation/reviewer'
    unchanged = ['evidence.py', 'review.py', 'statistics_review.py', 'lineage.py',
                 'parser.py', 'preparation.py']
    for name in unchanged:
        assert sha(HERE / name) == sha(original / name), name
    old = ast.parse((original / 'raw.py').read_text())
    new = ast.parse((HERE / 'raw.py').read_text())
    imported = [node for node in new.body if isinstance(node, ast.ImportFrom)
                and node.module == 'profiler_alias']
    assert len(imported) == 1 and [row.name for row in imported[0].names] == ['ALIAS', 'frozen_alias']
    new.body.remove(imported[0])
    functions = {node.name: node for node in new.body if isinstance(node, ast.FunctionDef)}
    recorded = functions['recorded_files']
    assert recorded.args.args[-1].arg == 'stage_assets'
    assert ast.dump(recorded.args.defaults[0]) == 'Constant(value=None)'
    recorded.args.args.pop()
    recorded.args.defaults.clear()
    addition = recorded.body.pop(2)
    expected = ast.parse("""for alias, canonical in frozen_alias(configuration, final, stage_assets).items():
    need(aliases.get(alias, canonical) == canonical
         and aliases.get(canonical, canonical) == canonical, 'conflicting profiler alias catalog')
    aliases[alias] = canonical
""").body[0]
    assert ast.dump(addition) == ast.dump(expected)
    calls = [node for node in ast.walk(functions['audit_workload'])
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
             and node.func.id == 'recorded_files']
    assert len(calls) == 1 and len(calls[0].args) == 4
    argument = calls[0].args.pop()
    expected_argument = ast.parse("collection.json('stage-assets.json') if ALIAS in configuration['record_files'] else None", mode='eval').body
    assert ast.dump(argument) == ast.dump(expected_argument)
    assert ast.dump(new) == ast.dump(old), 'raw audit changed beyond exact input alias handling'
    proof = json.loads((HERE / 'reference/profiler-alias-package-proof.json').read_text())
    stage = json.loads((HERE / 'reference/profiler-stage-assets.json').read_text())
    assert sha(HERE / 'reference/profiler-stage-assets.json') == proof['stage_assets_sha256']
    assert stage[proof['stage_asset_key']] == proof['package']
    collection = HERE.parent / 'sbom-current179-ir-continuation/evidence/ir-confirmation'
    transfer = json.loads((collection / 'transfer-manifest.json').read_text())
    assert sha(collection / 'transfer-manifest.json') == proof['transfer_manifest_sha256']
    assert transfer['files']['stage-assets.json']['sha256'] == proof['stage_assets_sha256']
    corpus = json.loads((HERE / 'reference/input-map-corpus.json').read_text())
    for row in corpus['workloads']:
        source = Path(row['source'])
        relative = str(source.relative_to(collection))
        assert sha(source) == transfer['files'][relative]['sha256'] == row['source_sha256']
        fields = json.loads(source.read_text())
        assert fields['recorded_file_sha256'] == fields['recorded_file_sha256_after'] == row['recorded_files']
    prior = json.loads((HERE / 'pure-check-attempt01/result.json').read_text())
    assert prior['valid'] and prior['tests'] == 38
    assert sha(HERE / 'history/raw-pure-attempt01.py') == prior['source_sha256']['raw.py']
    assert sha(HERE / 'history/original-freeze.py') == prior['source_sha256']['freeze.py']
    return {'status': 'passed', 'protected_original_files': len(protected),
            'unchanged_review_modules': {name: sha(HERE / name) for name in unchanged},
            'raw_ast_identical_except_exact_alias_function_addition_and_call_argument': True,
            'statistics_and_acceptance_unchanged': True,
            'actual_collection_review_or_effects_executed': False,
            'native_recorded_input_algorithm_unchanged': True,
            'package_proof_sha256': sha(HERE / 'reference/profiler-alias-package-proof.json')}


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2, sort_keys=True))
