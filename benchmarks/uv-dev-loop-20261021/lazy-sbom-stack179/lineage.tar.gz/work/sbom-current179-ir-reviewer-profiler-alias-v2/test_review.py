"""Pure checks against synthetic batches only; never opens comparative results."""
import ast
from contextlib import contextmanager
import json
import math
from pathlib import Path
import random
import statistics
import tempfile
import unittest
from unittest.mock import patch

import evidence
import parser
import preparation
import raw
import review
import statistics_review
import synthetic


class Checks(unittest.TestCase):
    @contextmanager
    def batch(self, workload='test', instruction=True):
        with tempfile.TemporaryDirectory(prefix='sbom-review-pure-') as directory:
            yield synthetic.build(directory, workload, instruction)

    def audit(self, data, workload='test'):
        collection, protocol, final, state = data
        return raw.audit_workload(collection, workload, protocol, final, state, parser.load())

    def test_complete_ir_test(self):
        with self.batch() as data:
            result = self.audit(data)
            self.assertEqual(result['raw']['samples'], 28)
            self.assertEqual(len(result['instruction_pairs']), 12)

    def test_complete_ir_check(self):
        with self.batch('check') as data:
            result = self.audit(data, 'check')
            self.assertEqual(len(result['raw']['preparation']['check_convergence']), 28)

    def test_complete_native_test_is_thirty_single_calls(self):
        with self.batch('test', False) as data:
            result = self.audit(data)
            self.assertEqual(result['raw']['samples'], 64)
            self.assertEqual(len(result['wall_pairs']), 30)
            self.assertEqual(result['instruction_pairs'], [])
            self.assertEqual(result['raw']['invocations_per_variant_per_pair'], 1)

    def test_complete_native_check(self):
        with self.batch('check', False) as data:
            result = self.audit(data, 'check')
            self.assertEqual(len(result['raw']['preparation']['check_convergence']), 64)

    def test_controller_affinity_is_separate_from_frozen_child_binding(self):
        with self.batch() as data:
            collection = data[0]
            name = 'results/test-ir-confirmation/manifest.json'
            manifest = collection.json(name)
            manifest['machine']['affinity'] = [8]
            collection.dump(name, manifest)
            seal_name = 'results/ir-completion-01/raw-seals.json'
            seal = collection.json(seal_name)
            seal['test']['manifest.json'] = evidence.sha(collection.path(name))
            collection.dump(seal_name, seal)
            collection.refresh()
            self.assertTrue(self.audit(data)['raw']['valid'])

    def test_raw_failure_prevents_all_effects(self):
        collection = type('Collection', (), {'phase': 'ir-confirmation'})()
        with tempfile.TemporaryDirectory(prefix='sbom-review-boundary-') as directory:
            with patch.object(review, 'collection_inputs', return_value=({}, {})), \
                 patch.object(review, 'audit_workload', side_effect=[{}, ValueError('second raw audit failed')]), \
                 patch.object(review, 'analysis_for') as effects:
                with self.assertRaisesRegex(ValueError, 'second raw audit failed'):
                    review.review_group(collection, Path(directory), 'unused', {})
                effects.assert_not_called()
                self.assertEqual(list(Path(directory).iterdir()), [])

    def test_recorded_tool_aliases_are_exact(self):
        config = evidence.read(evidence.REFERENCE / 'test-ir-confirmation.json')
        final = evidence.read(evidence.REFERENCE / 'configs-finalized.json')
        catalog = evidence.read(evidence.REFERENCE / 'input-catalog.json')
        records = raw.recorded_files(config, final, catalog,
                                     evidence.read(evidence.REFERENCE / 'profiler-stage-assets.json'))
        self.assertNotIn('/usr/bin/cc', records)
        self.assertEqual(records[catalog['snapshot']['tools']['cc']['resolved']],
                         final['asset_sha256']['/usr/bin/cc'])

    def test_csv_disagreement_rejected(self):
        with self.batch() as data:
            collection = data[0]
            path = collection.path('results/test-ir-confirmation/samples.csv')
            path.write_text(path.read_text().replace('200000000', '200000001', 1))
            with self.assertRaisesRegex(ValueError, 'CSV sample fields differ'):
                raw.tables(path.parent, collection.json('results/test-ir-confirmation/samples.json'), True)

    def test_jsonl_disagreement_rejected(self):
        with self.batch() as data:
            collection = data[0]
            path = collection.path('results/test-ir-confirmation/samples.jsonl')
            rows = path.read_text().splitlines()
            rows[0], rows[1] = rows[1], rows[0]
            path.write_text('\n'.join(rows) + '\n')
            with self.assertRaisesRegex(ValueError, 'JSON/JSONL'):
                raw.tables(path.parent, collection.json('results/test-ir-confirmation/samples.json'), True)

    def test_profiler_count_and_command_bound(self):
        with tempfile.TemporaryDirectory(prefix='sbom-review-profile-') as directory:
            path = Path(directory) / 'p'
            path.write_text('creator: callgrind-3.22.0\ncmd: /cargo check\nevents: Ir\nsummary: 42\n')
            self.assertEqual(raw.profile(path, ['/cargo', 'check']), 42)
            with self.assertRaisesRegex(ValueError, 'another executable'):
                raw.profile(path, ['/cargo', 'test', '--no-run'])
            path.write_text(path.read_text() + 'summary: 42\n')
            with self.assertRaisesRegex(ValueError, 'summary schema'):
                raw.profile(path, ['/cargo', 'check'])

    def test_negative_zero_or_ambiguous_profile_rejected(self):
        with tempfile.TemporaryDirectory(prefix='sbom-review-profile-') as directory:
            path = Path(directory) / 'p'
            for summary in ('-1', '0', '1 2'):
                path.write_text('creator: callgrind-3.22.0\ncmd: /cargo check\nevents: Ir\nsummary: ' + summary + '\n')
                with self.assertRaises(ValueError):
                    raw.profile(path, ['/cargo', 'check'])

    def test_exact_v2_context_required(self):
        expected = evidence.read(evidence.REFERENCE / 'diagnostic-expectations.json')
        target = next(iter(expected['workloads']['check']['targets']))
        stdout, stderr = synthetic.compiler_logs(expected, target, 'check')
        pure = parser.load()
        pure.parse_run(stdout, stderr, target)
        for changed in (stderr.replace('/v2-', '/'), stderr.replace('/v2-', '/v3-')):
            with self.assertRaises(ValueError):
                pure.parse_run(stdout, changed, target)

    def test_parser_rejects_other_target(self):
        expected = evidence.read(evidence.REFERENCE / 'diagnostic-expectations.json')
        target = next(iter(expected['workloads']['check']['targets']))
        stdout, stderr = synthetic.compiler_logs(expected, target, 'check')
        with self.assertRaisesRegex(ValueError, 'outside its assigned target'):
            parser.load().parse_run(stdout, stderr, target + '-other')

    def test_extra_successful_process_fails_check_convergence(self):
        with self.batch('check') as data:
            collection = data[0]
            rows = [json.loads(line) for line in collection.path('fixtures/check-ir-confirmation/journal.jsonl').read_text().splitlines()]
            entry = rows[1]
            path = collection.path(entry['preparation_proof']['path'])
            proof = evidence.read(path)
            trace = path.parent / 'call-3.execve'
            trace.write_text(trace.read_text() + '1 execve("/unexpected-test", [], []) = 0\n')
            proof['calls'][2]['execve_sha256'] = evidence.sha(trace)
            path.write_text(json.dumps(proof))
            entry['preparation_proof']['sha256'] = evidence.sha(path)
            guard = evidence.read(evidence.REFERENCE / 'source-guard.json')
            with self.assertRaisesRegex(ValueError, 'executed compiler/build-script/test work'):
                preparation.convergence(collection, entry, guard['source'], guard['source_mode'], parser.load())

    def test_nonfresh_final_prepare_rejected(self):
        text = json.dumps({'reason': 'compiler-artifact', 'fresh': False}) + '\n'
        text += json.dumps({'reason': 'build-finished', 'success': True}) + '\n'
        with self.assertRaisesRegex(ValueError, 'not fully fresh'):
            preparation.successful_json_build(text, True)

    def test_three_call_guard_rejects_extension(self):
        with self.batch('check') as data:
            collection = data[0]
            entry = json.loads(collection.path('fixtures/check-ir-confirmation/journal.jsonl').read_text().splitlines()[1])
            path = collection.path(entry['preparation_proof']['path'])
            proof = evidence.read(path)
            proof['fixed_native_calls'] = 4
            path.write_text(json.dumps(proof))
            entry['preparation_proof']['sha256'] = evidence.sha(path)
            guard = evidence.read(evidence.REFERENCE / 'source-guard.json')
            with self.assertRaisesRegex(ValueError, 'call count'):
                preparation.convergence(collection, entry, guard['source'], guard['source_mode'], parser.load())

    def test_edits_equal_length_unique_pairs_and_stages(self):
        original = b'fn main() {}\n'
        tokens = set()
        for stage in ('warmup', 'measurement'):
            for pair in range(3):
                before = preparation.edited(original, '/owned/result', stage, pair, 'before')
                after = preparation.edited(original, '/owned/result', stage, pair, 'after_')
                self.assertEqual(len(before), len(after))
                self.assertNotEqual(before, after)
                tokens.add(evidence.digest(after))
        self.assertEqual(len(tokens), 6)

    def test_bad_sample_counters_rejected(self):
        row = {'returncode': 0, 'wall_ns': 1, 'user_seconds': 0, 'system_seconds': 0,
               'minor_faults': 0, 'major_faults': 0, 'voluntary_context_switches': 0, 'involuntary_context_switches': 0}
        raw.outcome(row)
        for key, value in [('wall_ns', 0), ('returncode', False), ('user_seconds', math.nan), ('major_faults', -1)]:
            with self.assertRaises(ValueError):
                raw.outcome(dict(row, **{key: value}))

    def test_payload_paths_reject_escape_and_alias(self):
        for name in ('/absolute', '../escape', 'a/../b', 'a//b', '.', ''):
            with self.assertRaises(ValueError):
                evidence.relative(name)
        with self.assertRaises(ValueError):
            evidence.remote_relative(evidence.REMOTE + '-other/p')

    def test_missing_native_prerequisite_rejected(self):
        with self.assertRaisesRegex(ValueError, 'requires the accepted'):
            review.accepted_ir(None, None, {}, 'unused')

    def test_fixed_plans_match_all_protocol_rows(self):
        for row in evidence.read(evidence.REFERENCE / 'protocol.json')['phases']:
            self.assertEqual(raw.plan(row['pairs'], row['seed']), row['measurement_plan'])
            self.assertEqual(raw.plan(2, row['seed'] ^ 0x5A17), row['warmup_plan'])
        with self.assertRaises(ValueError):
            raw.plan(8, 1)

    def test_independent_statistics_match_frozen_method_on_synthetic_data(self):
        source = (evidence.REFERENCE / 'paired.py').read_text()
        names = {'quantile', 'exact_sign_test', 'paired_statistics', 'paired_count_statistics'}
        nodes = [node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name in names]
        scope = {'math': math, 'random': random, 'statistics': statistics}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), '<frozen-pure-statistics>', 'exec'), scope)
        for count in (12, 30):
            rows = [{'baseline': 100 + number, 'candidate': 92 + number, 'order': 'AB' if number % 2 else 'BA'}
                    for number in range(count)]
            statistics_review.equal(statistics_review.paired(rows), scope['paired_statistics'](rows, .99, 20000, 1701))
            statistics_review.equal(statistics_review.counts(rows), scope['paired_count_statistics'](rows, .99, 20000, 1701))

    def test_gate_requires_both_orders_and_individual_thresholds(self):
        rows = [{'baseline': 100, 'candidate': 90, 'order': 'AB' if number % 2 else 'BA'} for number in range(12)]
        value = statistics_review.counts(rows)
        self.assertTrue(statistics_review.gate('ir', value)['passes_gate'])
        for key, replacement in [('pairs', 11), ('paired_geometric_mean_count_reduction', .009),
                                 ('bootstrap_count_reduction_interval', [0, .1]),
                                 ('exact_two_sided_sign_p', .02), ('order', {'AB': value['order']['AB']})]:
            self.assertFalse(statistics_review.gate('ir', dict(value, **{key: replacement}))['passes_gate'])


if __name__ == '__main__':
    unittest.main()
