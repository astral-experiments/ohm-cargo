#!/usr/bin/env python3
"""Future metadata-only prerequisite transfer or separately approved native launch."""
import argparse
import base64
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import socket
import stat
import subprocess
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
CAPSULE = ROOT / 'continuations/ir-check-01'
BINDING = ROOT / 'continuations/native-prerequisite-01'
CAPSULE_SHA = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
CONTRACT_SHA = '3b39ed7a47ca7433aef4f0861f1006cbf6724b5afefb6e46aaa78d063e3c5bca'
WRAPPER_SHA = '1f795f62bf284f934e5de79c4a589ff829dcacf9cb1058a8772c6b0b8b31bfe2'
RAW_REVIEWER = 'fb2529078308fd3e4c816402aa3df1d4a01e52cb32a079a86e9366d5dbedbd6b'
LINEAGE_REVIEWER = '6f734b8eb9bbac6a61a7f93b105c068f542f9300d9dddb66482ef16611f002c4'
ENVIRONMENT = 'c804e29e539b50dac4eae00bb71f2541016698a1aa0edfc639a73b052384ca69'
CAPTURE = '433c3d6c87efe7d5e21d7f6a5d6b4dc410cc63d7e50253a8ea1ad80215b557c3'
PROTOCOL = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
COHORT = 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
FINAL = 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
RETAINED_PATH = '/usr/local/bin:/home/dev-user/.local/bin:/home/dev-user/.cargo/bin:/usr/local/bin:/home/linuxbrew/.linuxbrew/bin:/home/linuxbrew/.linuxbrew/sbin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
REQUIRED = frozenset({'strict_native_entry.py', 'root-approval.json', 'review/seal.json',
    'review/review.json', 'review/raw-integrity.json', 'review/effects.json',
    'transfer-manifest.json', 'collection-receipt.json', 'lineage/review.json',
    'lineage/root-approval.json', 'review/root-execution-approval.json',
    'controls/source-freeze.json', 'controls/environment_entry.py', 'controls/remote.py'})
SESSION = 'ohm-sbom179-native-confirmation-01'


def need(value, reason):
    if not value:
        raise ValueError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def relative(name):
    need(isinstance(name, str), 'non-string payload name')
    path = PurePosixPath(name)
    need(name and name != '.' and not path.is_absolute() and '..' not in path.parts
         and '\\' not in name and str(path) == name, 'unsafe payload name')
    return path


def record(path):
    need(path.resolve() == path and path.is_file() and not path.is_symlink(), 'noncanonical regular file')
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode)}


def encode_json(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def write_new(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    need(path.parent.resolve() == path.parent, 'symlinked output parent')
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(mode)


def validate_bindings(manifest, contents):
    """Pure binding checks. Effects bytes are hashed but never interpreted here."""
    need(REQUIRED <= set(manifest['files']), 'missing required prerequisite payload')
    need(set(contents) == set(manifest['files']), 'prerequisite member set differs')
    for name, row in manifest['files'].items():
        relative(name)
        need(set(row) == {'sha256', 'bytes', 'mode'} and isinstance(row['mode'], int)
             and row['mode'] & ~0o777 == 0, 'unsupported payload record')
        need(digest(contents[name]) == row['sha256'] and len(contents[name]) == row['bytes'], 'payload bytes differ: ' + name)
    load = lambda name: json.loads(contents[name])
    frozen = load('controls/source-freeze.json')
    need(digest(contents['controls/source-freeze.json']) == manifest['controls_source_freeze_sha256'], 'controls freeze differs')
    for name, row in frozen['files'].items():
        relative(name)
        need('controls/' + name in manifest['files'] and manifest['files']['controls/' + name] == row,
             'frozen producer source is absent or changed')
    need(digest(contents['strict_native_entry.py']) == WRAPPER_SHA, 'strict wrapper changed')
    approval, review = load('root-approval.json'), load('review/review.json')
    lineage, lineage_approval = load('lineage/review.json'), load('lineage/root-approval.json')
    execution = load('review/root-execution-approval.json')
    transfer, receipt = load('transfer-manifest.json'), load('collection-receipt.json')
    seal = load('review/seal.json')
    need(set(seal) == {'review.json', 'raw-integrity.json', 'effects.json'}, 'IR review seal differs')
    need(all(digest(contents['review/' + name]) == value for name, value in seal.items()), 'IR review payload changed')
    need(review['valid'] is True and review['phase'] == 'ir-confirmation'
         and review['raw_integrity_before_effects'] is True and review['primary_passes'] is True
         and review['source_freeze_sha256'] == RAW_REVIEWER and review['cohort_sha256'] == COHORT
         and review['finalized_sha256'] == FINAL and review['protocol_sha256'] == PROTOCOL
         and review['raw_integrity_sha256'] == digest(contents['review/raw-integrity.json'])
         and review['effects_sha256'] == digest(contents['review/effects.json']), 'current179 IR has not qualified')
    need(lineage['status'] == 'passed' and lineage['source_freeze_sha256'] == LINEAGE_REVIEWER
         and lineage['environment_source_freeze_sha256'] == ENVIRONMENT and lineage['capture_sha256'] == CAPTURE
         and lineage['original_capsule_unchanged'] is True and lineage['original_test_observations_unchanged'] == 28
         and lineage['new_fixed_check_observations'] == 28
         and lineage['actual_check_test_inherited_environment_equal'] is True
         and lineage['only_launch_path_setting_changed'] is True and lineage['effects_inspected'] is False
         and lineage['original_raw_and_statistics_reviewer_still_required'] is True
         and lineage['final_rehash'] == 'passed', 'PATH continuation lineage has not qualified')
    review_sha, lineage_sha = digest(contents['review/review.json']), digest(contents['lineage/review.json'])
    execution_sha = digest(contents['review/root-execution-approval.json'])
    need(execution['valid'] is True and execution['phase'] == 'ir-confirmation'
         and execution['source_freeze_sha256'] == RAW_REVIEWER
         and execution['output'] == manifest['input_paths']['ir_review']
         and review['approval_sha256'] == execution_sha, 'original IR review execution approval differs')
    need(lineage_approval['valid'] is True
         and lineage_approval['authorized_operation'] == 'accept-path-lineage-before-current179-ir-review'
         and lineage_approval['accepted_path_lineage_review_sha256'] == lineage_sha
         and lineage_approval['source_freeze_sha256'] == LINEAGE_REVIEWER
         and lineage_approval['ir_review_execution_approval_sha256'] == execution_sha,
         'root acceptance of PATH lineage is absent or mismatched')
    need(datetime.fromisoformat(lineage['reviewed_at']) <= datetime.fromisoformat(lineage_approval['reviewed_at'])
         <= datetime.fromisoformat(review['reviewed_at']), 'lineage acceptance chronology differs')
    transfer_sha, receipt_sha = digest(contents['transfer-manifest.json']), digest(contents['collection-receipt.json'])
    need(receipt['valid'] is True and receipt['phase'] == 'ir-confirmation'
         and receipt['transfer_manifest_sha256'] == transfer_sha
         and review['transfer_manifest_sha256'] == lineage['transfer_manifest_sha256'] == transfer_sha
         and review['collection_receipt_sha256'] == lineage['collection_receipt_sha256'] == receipt_sha
         and execution['collection_receipt_sha256'] == receipt_sha
         and lineage_approval['collection_receipt_sha256'] == receipt_sha, 'accepted IR collection identities differ')
    status_name = 'results/ir-completion-01/status.json'
    need(status_name in transfer['files'] and transfer['files'][status_name]['sha256'] == manifest['continuation_status_sha256'],
         'continued IR status is unbound')
    need(approval['valid'] is True and approval['authorized_operation'] == 'prepare-native-prerequisites-only'
         and approval['accepted_ir_review_sha256'] == review_sha
         and approval['accepted_path_lineage_review_sha256'] == lineage_sha
         and approval['accepted_path_lineage_approval_sha256'] == digest(contents['lineage/root-approval.json'])
         and approval['ir_review_execution_approval_sha256'] == execution_sha
         and approval['reviewer_source_freeze_sha256'] == RAW_REVIEWER
         and approval['strict_native_entry_sha256'] == WRAPPER_SHA
         and approval['continuation_status_sha256'] == manifest['continuation_status_sha256']
         and approval['capsule_manifest_sha256'] == manifest['capsule_manifest_sha256'] == CAPSULE_SHA
         and approval['controls_source_freeze_sha256'] == manifest['controls_source_freeze_sha256'],
         'native preparation root approval is absent or mismatched')
    need(manifest['operation'] == 'root-approved-native-after-independent-ir-review'
         and manifest['retained_inherited_build_environment'] == {'PATH': RETAINED_PATH}
         and manifest['protocol_sha256'] == PROTOCOL, 'native prerequisite scope or PATH differs')
    protocol = load('controls/reference/protocol.json')
    need(digest(contents['controls/reference/protocol.json']) == PROTOCOL, 'original protocol changed')
    phases = [phase for phase in protocol['phases'] if phase['metric'] == 'native_wall_seconds']
    need(manifest['native_phases'] == phases and len(phases) == 2, 'native phases differ')
    for phase, workload, seed in zip(phases, ('test', 'check'), (20261021103, 20261021104)):
        need((phase['workload'], phase['phase'], phase['pairs'], phase['warmup_pairs'],
              phase['invocations_per_variant_per_pair'], phase['seed']) == (workload, 'confirmation', 30, 2, 1, seed),
             'fixed single-call native plan differs')
    return {'ir_review_sha256': review_sha, 'lineage_review_sha256': lineage_sha,
            'transfer_manifest_sha256': transfer_sha, 'collection_receipt_sha256': receipt_sha}


def controller_command(prerequisite_sha):
    return ['/usr/bin/env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
            'PYTHONDONTWRITEBYTECODE=1', 'PATH=' + RETAINED_PATH, '/usr/bin/python3', '-B',
            str(BINDING / 'controls/environment_entry.py'), '--capsule-manifest-sha256', CAPSULE_SHA,
            '--prerequisite-sha256', prerequisite_sha]


def load_contract():
    need(record(CAPSULE / 'contract.py')['sha256'] == CONTRACT_SHA, 'original contract changed')
    spec = importlib.util.spec_from_file_location('native_preparation_original_contract', CAPSULE / 'contract.py')
    contract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(contract)
    return contract


def read_binding():
    record(BINDING / 'manifest.json')
    manifest = json.loads((BINDING / 'manifest.json').read_bytes())
    contents = {}
    for name, row in manifest['files'].items():
        path = BINDING / relative(name)
        need(record(path) == row, 'staged prerequisite differs')
        contents[name] = path.read_bytes()
    need({str(path.relative_to(BINDING)) for path in BINDING.rglob('*') if path.is_file()}
         == set(contents) | {'manifest.json'}, 'unexpected staged prerequisite member')
    validate_bindings(manifest, contents)
    return manifest, contents


def accepted_live_bytes(contract, manifest, contents):
    contract.verify_complete(ROOT, CAPSULE, CAPSULE_SHA)
    transfer = json.loads(contents['transfer-manifest.json'])['files']
    for name, row in transfer.items():
        if name != 'collection-identity.json':
            need(contract.record(contract.regular(ROOT, ROOT / contract.relative(name))) == row,
                 'accepted IR byte changed before native preparation: ' + name)
    need(sha(ROOT / 'results/ir-completion-01/status.json') == manifest['continuation_status_sha256'], 'IR status changed')
    retained = json.loads((ROOT / 'results/test-ir-confirmation/manifest.json').read_bytes())['inherited_build_environment']
    checked = json.loads((ROOT / 'results/ir-completion-01/check/manifest.json').read_bytes())['inherited_build_environment']
    need(retained == checked == manifest['retained_inherited_build_environment'] == {'PATH': RETAINED_PATH}, 'retained PATH differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('stage', 'launch'))
    parser.add_argument('request_sha256')
    args = parser.parse_args()
    data = sys.stdin.buffer.read()
    need(digest(data) == args.request_sha256, 'request transfer changed')
    request = json.loads(data)
    need(request['operation'] == args.operation and request['capsule_manifest_sha256'] == CAPSULE_SHA, 'request operation differs')
    need(socket.gethostname() == 'charlie-oss-4' and os.getuid() == 1000 and ROOT.resolve() == ROOT
         and ROOT.stat().st_uid == 1000 and Path('/').stat().st_uid == 0, 'host/root/ownership differs')
    need(Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(), 'system Python required')
    lock = (ROOT / 'experiment.lock').open('rb')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    contract = load_contract()
    history = ROOT / 'continuations' / ('native-prerequisite-' + args.operation + '-01')
    need(not history.exists() and not history.is_symlink(), 'operation was already attempted')
    approval_bytes = base64.b64decode(request['approval_base64'], validate=True)
    need(digest(approval_bytes) == request['approval_sha256'], 'operation approval transfer changed')
    approval = json.loads(approval_bytes)
    need(approval['valid'] is True and approval['authorized_operation'] == args.operation + '-fixed-native-prerequisites'
         and approval['controls_source_freeze_sha256'] == request['controls_source_freeze_sha256']
         and approval['prerequisite_manifest_sha256'] == request['prerequisite_manifest_sha256'], 'operation root approval differs')
    if args.operation == 'stage':
        need(not BINDING.exists() and not BINDING.is_symlink(), 'native prerequisite already exists')
        payload = {name: base64.b64decode(value, validate=True) for name, value in request['payload_base64'].items()}
        need('manifest.json' in payload and digest(payload['manifest.json']) == request['prerequisite_manifest_sha256'], 'prerequisite manifest transfer differs')
        manifest = json.loads(payload.pop('manifest.json'))
        validate_bindings(manifest, payload)
        contents = payload
    else:
        need('payload_base64' not in request, 'launch must not modify staged prerequisites')
        need(sha(BINDING / 'manifest.json') == request['prerequisite_manifest_sha256'], 'staged manifest differs')
        manifest, contents = read_binding()
        stage = json.loads((ROOT / 'continuations/native-prerequisite-stage-01/receipt.json').read_bytes())
        need(stage['valid'] is True and stage['operation'] == 'stage'
             and stage['prerequisite_manifest_sha256'] == request['prerequisite_manifest_sha256']
             and sha(ROOT / 'continuations/native-prerequisite-stage-01/receipt.json') == approval['remote_stage_receipt_sha256'],
             'launch does not bind the reviewed stage receipt')
    need(manifest['controls_source_freeze_sha256'] == request['controls_source_freeze_sha256'], 'request controls freeze differs')
    need(digest(request['remote_source_text'].encode()) == manifest['files']['controls/remote.py']['sha256'], 'transport source differs')
    accepted_live_bytes(contract, manifest, contents)
    need(all(not (ROOT / name).exists() and not (ROOT / name).is_symlink() for name in
             ('results/native-confirmation.json', 'results/test-native-confirmation', 'results/check-native-confirmation')),
         'native workload has already been attempted')
    logs = {suffix: ROOT / ('logs/native-confirmation-01.controller.' + suffix) for suffix in ('stdout', 'stderr')}
    need(all(not path.exists() and not path.is_symlink() for path in logs.values()), 'native launch log already exists')
    if args.operation == 'launch':
        for session in ('ohm-sbom179-ir-completion-01', 'ohm-sbom179-ir-completion-02', SESSION):
            need(subprocess.run(['/usr/bin/tmux', 'has-session', '-t', session], capture_output=True).returncode == 1,
                 'prior/current session still exists or tmux probe failed')
    history.mkdir(mode=0o700)
    write_new(history / 'request.json', data)
    write_new(history / 'root-approval.json', approval_bytes)
    write_new(history / 'remote.py', request['remote_source_text'].encode())
    if args.operation == 'stage':
        BINDING.mkdir(mode=0o700)
        for name, value in contents.items():
            write_new(BINDING / relative(name), value, manifest['files'][name]['mode'])
        write_new(BINDING / 'manifest.json', encode_json(manifest))
        need(sha(BINDING / 'manifest.json') == request['prerequisite_manifest_sha256'], 'manifest serialization differs')
        read_binding()
        accepted_live_bytes(contract, manifest, contents)
    receipt = {'valid': True, 'operation': args.operation, 'verified_at': datetime.now(timezone.utc).isoformat(),
        'request_sha256': args.request_sha256, 'approval_sha256': request['approval_sha256'],
        'controls_source_freeze_sha256': request['controls_source_freeze_sha256'],
        'prerequisite_manifest_sha256': request['prerequisite_manifest_sha256'],
        'capsule_manifest_sha256': CAPSULE_SHA, 'payloads': manifest['files'],
        'retained_inherited_build_environment': {'PATH': RETAINED_PATH},
        'fixed_pairs_per_workload': 30, 'warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
        'seeds': {'test': 20261021103, 'check': 20261021104}, 'all_accepted_ir_bytes_preserved': True,
        'original_native_entry_and_controller_unchanged': True, 'history': str(history)}
    if args.operation == 'launch':
        command = controller_command(request['prerequisite_manifest_sha256'])
        receipt.update({'command': command, 'session': SESSION, 'stdout': str(logs['stdout']), 'stderr': str(logs['stderr'])})
        write_new(history / 'before.json', encode_json(receipt))
        lock.close()
        shell = 'set -C; exec ' + shlex.join(command) + ' > ' + shlex.quote(str(logs['stdout'])) + ' 2> ' + shlex.quote(str(logs['stderr']))
        subprocess.run(['/usr/bin/tmux', 'new-session', '-d', '-s', SESSION, '/bin/sh', '-c', shell], check=True)
        receipt['launched'] = True
    else:
        receipt['workload_launched'] = False
    write_new(history / 'receipt.json', encode_json(receipt))
    # The tmux child writes its separately collected entry receipt concurrently.
    # Keep this transfer/launch seal independent of that arrival race.
    write_new(history / 'seal.json', encode_json({path.name: sha(path) for path in sorted(history.iterdir())
                                                if path.name != 'entry-receipt.json'}))
    print(json.dumps({'receipt': receipt, 'remote_receipt_sha256': sha(history / 'receipt.json'),
                      'history_seal_sha256': sha(history / 'seal.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
