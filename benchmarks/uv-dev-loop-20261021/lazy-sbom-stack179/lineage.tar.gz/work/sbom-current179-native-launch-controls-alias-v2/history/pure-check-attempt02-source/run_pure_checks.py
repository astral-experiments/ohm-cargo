#!/usr/bin/env python3
"""Run only synthetic/source cases with subprocess, exec and networking denied."""
import ast
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent


def prohibit(event, values):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'socket.connect'}:
        raise AssertionError('Pure native-control checks cannot execute a host action or workload')


sys.addaudithook(prohibit)
assert sorted(os.sched_getaffinity(0)) == [8]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
destination = args.output.absolute()
assert destination.parent == HERE and destination.resolve() == destination
destination.mkdir()
source_hashes = {}
for path in sorted(HERE.glob('*.py')):
    data = path.read_bytes()
    ast.parse(data, filename=str(path))
    source_hashes[path.name] = hashlib.sha256(data).hexdigest()
spec = importlib.util.spec_from_file_location('native_controls_pure_test_module', HERE / 'test_controls.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
output = io.StringIO()
result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
with (destination / 'stdout').open('x') as stream:
    stream.write(output.getvalue())
for name, expected in source_hashes.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected
report = {'valid': result.wasSuccessful(), 'checked_at': datetime.now(timezone.utc).isoformat(),
    'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'source_sha256': source_hashes, 'actual_reviews_or_effects_read': False,
    'preparation_transfer_launch_executed': False, 'host_workload_calls_prohibited': True}
with (destination / 'result.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({key: report[key] for key in ('valid', 'tests', 'failures', 'errors')}, sort_keys=True))
raise SystemExit(0 if result.wasSuccessful() else 1)
