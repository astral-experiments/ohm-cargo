"""Synthetic metadata and source checks only; no real review, transfer or workload."""
import ast
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import remote
import environment_entry

HERE = Path(__file__).resolve().parent


def synthetic(overrides=None):
    overrides = overrides or {}
    contents = {}

    def emit(name, value):
        if isinstance(value, dict):
            value = dict(value)
            value.update(overrides.get(name, {}))
            contents[name] = remote.encode_json(value)
        else:
            contents[name] = overrides.get(name, value)
        return remote.digest(contents[name])

    def h(name):
        return remote.digest(contents[name])

    wrapper = HERE.parent / 'sbom-current179-native-prerequisite-amendment/strict_native_entry.py'
    emit('strict_native_entry.py', wrapper.read_bytes())
    for name in ('remote.py', 'environment_entry.py', 'reference/protocol.json'):
        emit('controls/' + name, (HERE / name).read_bytes())
    freeze_sha = emit('controls/source-freeze.json', {'files': {
        name.removeprefix('controls/'): {'sha256': h(name), 'bytes': len(value), 'mode': 0o644}
        for name, value in contents.items() if name.startswith('controls/')}})
    emit('transfer-manifest.json', {'files': {'results/ir-completion-01/status.json': {
        'sha256': '1' * 64, 'bytes': 100, 'mode': 0o644}}})
    emit('collection-receipt.json', {'valid': True, 'phase': 'ir-confirmation', 'transfer_manifest_sha256': h('transfer-manifest.json')})
    emit('review/root-execution-approval.json', {'valid': True, 'phase': 'ir-confirmation',
        'source_freeze_sha256': remote.RAW_REVIEWER, 'output': '/synthetic/approved-review',
        'collection_receipt_sha256': h('collection-receipt.json')})
    emit('lineage/review.json', {'status': 'passed', 'source_freeze_sha256': remote.LINEAGE_REVIEWER,
        'environment_source_freeze_sha256': remote.ENVIRONMENT, 'capture_sha256': remote.CAPTURE,
        'original_capsule_unchanged': True, 'original_test_observations_unchanged': 28,
        'new_fixed_check_observations': 28, 'actual_check_test_inherited_environment_equal': True,
        'only_launch_path_setting_changed': True, 'effects_inspected': False,
        'original_raw_and_statistics_reviewer_still_required': True, 'final_rehash': 'passed',
        'reviewed_at': '2000-01-01T01:00:00+00:00',
        'transfer_manifest_sha256': h('transfer-manifest.json'), 'collection_receipt_sha256': h('collection-receipt.json')})
    emit('lineage/root-approval.json', {'valid': True,
        'authorized_operation': 'accept-path-lineage-before-current179-ir-review',
        'accepted_path_lineage_review_sha256': h('lineage/review.json'),
        'source_freeze_sha256': remote.LINEAGE_REVIEWER,
        'ir_review_execution_approval_sha256': h('review/root-execution-approval.json'),
        'collection_receipt_sha256': h('collection-receipt.json'), 'reviewed_at': '2000-01-01T01:01:00+00:00'})
    emit('review/raw-integrity.json', {'synthetic': True})
    emit('review/effects.json', b'{"synthetic":true}\n')
    emit('review/review.json', {'valid': True, 'phase': 'ir-confirmation', 'raw_integrity_before_effects': True,
        'primary_passes': True, 'source_freeze_sha256': remote.RAW_REVIEWER, 'cohort_sha256': remote.COHORT,
        'finalized_sha256': remote.FINAL, 'protocol_sha256': remote.PROTOCOL,
        'raw_integrity_sha256': h('review/raw-integrity.json'), 'effects_sha256': h('review/effects.json'),
        'approval_sha256': h('review/root-execution-approval.json'), 'reviewed_at': '2000-01-01T01:02:00+00:00',
        'transfer_manifest_sha256': h('transfer-manifest.json'), 'collection_receipt_sha256': h('collection-receipt.json')})
    emit('review/seal.json', {name: h('review/' + name) for name in ('review.json', 'raw-integrity.json', 'effects.json')})
    emit('root-approval.json', {'valid': True, 'authorized_operation': 'prepare-native-prerequisites-only',
        'accepted_ir_review_sha256': h('review/review.json'), 'accepted_path_lineage_review_sha256': h('lineage/review.json'),
        'accepted_path_lineage_approval_sha256': h('lineage/root-approval.json'),
        'ir_review_execution_approval_sha256': h('review/root-execution-approval.json'),
        'reviewer_source_freeze_sha256': remote.RAW_REVIEWER, 'strict_native_entry_sha256': remote.WRAPPER_SHA,
        'continuation_status_sha256': '1' * 64, 'capsule_manifest_sha256': remote.CAPSULE_SHA,
        'controls_source_freeze_sha256': freeze_sha})
    protocol = json.loads(contents['controls/reference/protocol.json'])
    manifest = {'files': {name: {'sha256': h(name), 'bytes': len(data), 'mode': 0o644} for name, data in contents.items()},
        'controls_source_freeze_sha256': freeze_sha, 'input_paths': {'ir_review': '/synthetic/approved-review'},
        'continuation_status_sha256': '1' * 64, 'capsule_manifest_sha256': remote.CAPSULE_SHA,
        'operation': 'root-approved-native-after-independent-ir-review', 'protocol_sha256': remote.PROTOCOL,
        'retained_inherited_build_environment': {'PATH': remote.RETAINED_PATH},
        'native_phases': [phase for phase in protocol['phases'] if phase['metric'] == 'native_wall_seconds']}
    return manifest, contents


class BindingTests(unittest.TestCase):
    def test_complete_synthetic_binding(self):
        result = remote.validate_bindings(*synthetic())
        self.assertEqual(set(result), {'ir_review_sha256', 'lineage_review_sha256', 'transfer_manifest_sha256', 'collection_receipt_sha256'})

    def test_every_required_payload_missing_rejects(self):
        for name in remote.REQUIRED:
            manifest, contents = synthetic()
            del manifest['files'][name]
            del contents[name]
            with self.subTest(name=name), self.assertRaises(ValueError):
                remote.validate_bindings(manifest, contents)

    def test_every_payload_byte_mutation_rejects(self):
        original, inputs = synthetic()
        for name in inputs:
            contents = dict(inputs)
            contents[name] += b' '
            with self.subTest(name=name), self.assertRaises(ValueError):
                remote.validate_bindings(original, contents)

    def test_invalid_root_or_review_acceptance_rejects_despite_consistent_hashes(self):
        cases = [
            ('root-approval.json', 'valid', False),
            ('root-approval.json', 'authorized_operation', 'launch-native-now'),
            ('root-approval.json', 'accepted_path_lineage_approval_sha256', '0' * 64),
            ('review/review.json', 'primary_passes', False),
            ('review/review.json', 'raw_integrity_before_effects', False),
            ('review/review.json', 'source_freeze_sha256', '0' * 64),
            ('review/root-execution-approval.json', 'valid', False),
            ('review/root-execution-approval.json', 'output', '/different/review'),
            ('lineage/review.json', 'status', 'failed'),
            ('lineage/review.json', 'source_freeze_sha256', '0' * 64),
            ('lineage/review.json', 'effects_inspected', True),
            ('lineage/review.json', 'actual_check_test_inherited_environment_equal', False),
            ('lineage/review.json', 'new_fixed_check_observations', 26),
            ('lineage/root-approval.json', 'valid', False),
            ('lineage/root-approval.json', 'ir_review_execution_approval_sha256', '0' * 64),
            ('collection-receipt.json', 'valid', False),
            ('collection-receipt.json', 'transfer_manifest_sha256', '0' * 64),
        ]
        for name, field, value in cases:
            with self.subTest(name=name, field=field), self.assertRaises(ValueError):
                remote.validate_bindings(*synthetic({name: {field: value}}))

    def test_lineage_acceptance_after_raw_review_rejects(self):
        with self.assertRaisesRegex(ValueError, 'chronology'):
            remote.validate_bindings(*synthetic({'lineage/root-approval.json': {'reviewed_at': '2000-01-01T01:03:00+00:00'}}))

    def test_effects_bytes_are_opaque(self):
        remote.validate_bindings(*synthetic({'review/effects.json': b'opaque synthetic effects; never parsed\n'}))

    def test_path_and_repeated_native_changes_reject(self):
        for field, value in [('pairs', 31), ('warmup_pairs', 0), ('invocations_per_variant_per_pair', 8), ('seed', 20261021105)]:
            manifest, contents = synthetic()
            manifest['native_phases'][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                remote.validate_bindings(manifest, contents)
        manifest, contents = synthetic()
        manifest['retained_inherited_build_environment']['PATH'] = '/usr/bin'
        with self.assertRaises(ValueError):
            remote.validate_bindings(manifest, contents)

    def test_unknown_and_special_mode_payloads_reject(self):
        manifest, contents = synthetic()
        contents['unbound.json'] = b'{}'
        with self.assertRaises(ValueError):
            remote.validate_bindings(manifest, contents)
        manifest, contents = synthetic()
        manifest['files']['root-approval.json']['mode'] = 0o4644
        with self.assertRaises(ValueError):
            remote.validate_bindings(manifest, contents)

    def test_unsafe_member_names_reject(self):
        for name in ('', '.', '../x', '/tmp/x', 'x/../y', 'x//y', 'x\\y', 1):
            with self.subTest(name=name), self.assertRaises(ValueError):
                remote.relative(name)

    def test_command_retains_exact_path_and_original_wrapper_arguments(self):
        command = remote.controller_command('a' * 64)
        self.assertEqual(command[:8], ['/usr/bin/env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1'])
        self.assertEqual(command[8], 'PATH=' + remote.RETAINED_PATH)
        self.assertEqual(command[-4:], ['--capsule-manifest-sha256', remote.CAPSULE_SHA, '--prerequisite-sha256', 'a' * 64])


class EnvironmentTests(unittest.TestCase):
    def test_original_contract_call_interfaces(self):
        source = HERE.parent / 'sbom-current179-ir-continuation/contract.py'
        self.assertEqual(remote.sha(source), remote.CONTRACT_SHA)
        spec = importlib.util.spec_from_file_location('native_pure_contract_interfaces', source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        observed = set()
        for name in ('remote.py', 'environment_entry.py'):
            for node in ast.walk(ast.parse((HERE / name).read_text())):
                if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and isinstance(node.func.value, ast.Name) and node.func.value.id == 'contract'):
                    observed.add(node.func.attr)
                    inspect.signature(getattr(module, node.func.attr)).bind(
                        *[None for _ in node.args], **{item.arg: None for item in node.keywords})
        self.assertEqual(observed, {'verify_complete', 'record', 'regular', 'relative', 'load'})

    def test_actual_extra_or_changed_build_setting_rejects(self):
        machine = dict(uname=['Linux'], platform='synthetic', cpu_count=4, affinity=[0, 1], uid=1000,
                       effective_uid=1000, root_directory_owner_uid=0)
        expected = {'PATH': remote.RETAINED_PATH}
        self.assertEqual(environment_entry.validate_environment(expected, expected, machine, machine), machine)
        for actual in ({'PATH': '/different'}, dict(expected, RUSTFLAGS='-Copt-level=3'), {}):
            with self.subTest(actual=actual), self.assertRaises(ValueError):
                environment_entry.validate_environment(actual, expected, machine, machine)
        for key, value in [('affinity', [0]), ('uid', 0), ('root_directory_owner_uid', 1000)]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                environment_entry.validate_environment(expected, expected, dict(machine, **{key: value}), machine)

    def test_environment_proof_precedes_unchanged_strict_wrapper(self):
        source = (HERE / 'environment_entry.py').read_text()
        tree = ast.parse(source)
        calls = [(node.lineno, ast.unparse(node.func)) for node in ast.walk(tree) if isinstance(node, ast.Call)]
        self.assertLess(next(line for line, name in calls if name == 'validate_environment'),
                        next(line for line, name in calls if name == 'os.execv'))
        self.assertEqual(sum(name == 'os.execv' for _, name in calls), 1)
        self.assertIn("str(BINDING / 'strict_native_entry.py')", source)

    def test_producer_and_entry_do_not_implement_workload_or_statistics_loops(self):
        for name in ('prepare.py', 'environment_entry.py'):
            source = (HERE / name).read_text()
            self.assertNotIn('subprocess.', source)
            self.assertNotIn('analyze(', source)
            self.assertNotIn('statistics_review', source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
