#!/usr/bin/env python3
"""Separately approve stage and launch; retain unique local and remote receipts."""
import argparse
import base64
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import HERE, PREPARED, freeze_check, regular_local, verify_prepared
import remote

SSH = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('stage', 'launch'))
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--approval', required=True)
    parser.add_argument('--approval-sha256', required=True)
    args = parser.parse_args()
    freeze_check(args.source_freeze_sha256)
    manifest, contents = verify_prepared()
    manifest_sha = remote.sha(PREPARED / 'manifest.json')
    remote.need(manifest['controls_source_freeze_sha256'] == args.source_freeze_sha256, 'prepared controls cohort differs')
    approval_path = regular_local(args.approval)
    approval_bytes = approval_path.read_bytes()
    remote.need(remote.digest(approval_bytes) == args.approval_sha256, 'operation approval bytes differ')
    approval = json.loads(approval_bytes)
    remote.need(approval['valid'] is True and approval['authorized_operation'] == args.operation + '-fixed-native-prerequisites'
                and approval['controls_source_freeze_sha256'] == args.source_freeze_sha256
                and approval['prerequisite_manifest_sha256'] == manifest_sha, 'operation root approval absent or mismatched')
    if args.operation == 'launch':
        stage_dir = HERE / 'stage-attempt01'
        stage = json.loads(regular_local(stage_dir / 'receipt.json').read_bytes())
        remote.need(stage['returncode'] == 0 and stage['operation'] == 'stage'
                    and stage['prerequisite_manifest_sha256'] == manifest_sha
                    and stage['remote']['receipt']['payloads'] == manifest['files']
                    and approval['stage_receipt_sha256'] == remote.sha(stage_dir / 'receipt.json')
                    and approval['remote_stage_receipt_sha256'] == stage['remote']['remote_receipt_sha256'],
                    'root has not accepted the exact staged prerequisites')
        for suffix in ('stdout', 'stderr'):
            remote.need(remote.sha(stage_dir / suffix) == stage[suffix + '_sha256'], 'stage transport stream changed')
        remote.need(json.loads((stage_dir / 'stdout').read_bytes()) == stage['remote'], 'stage stdout differs from receipt')
    destination = HERE / (args.operation + '-attempt01')
    remote.need(not destination.exists() and not destination.is_symlink(), 'operation already attempted; no automatic retry')
    source = (HERE / 'remote.py').read_text()
    request = {'operation': args.operation, 'created_at': datetime.now(timezone.utc).isoformat(),
        'controls_source_freeze_sha256': args.source_freeze_sha256, 'capsule_manifest_sha256': remote.CAPSULE_SHA,
        'prerequisite_manifest_sha256': manifest_sha, 'approval_sha256': args.approval_sha256,
        'approval_base64': base64.b64encode(approval_bytes).decode(), 'remote_source_text': source}
    if args.operation == 'stage':
        request['payload_base64'] = {name: base64.b64encode(data).decode() for name, data in contents.items()}
        request['payload_base64']['manifest.json'] = base64.b64encode((PREPARED / 'manifest.json').read_bytes()).decode()
    request_bytes = remote.encode_json(request)
    destination.mkdir(mode=0o700)
    remote.write_new(destination / 'request.json', request_bytes)
    command = [SSH, 'charlie-oss-4', '--', '/usr/bin/env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
               'PYTHONDONTWRITEBYTECODE=1', 'PATH=' + remote.RETAINED_PATH, '/usr/bin/python3', '-B', '-c', source,
               args.operation, remote.digest(request_bytes)]
    remote.write_new(destination / 'before.json', remote.encode_json({'requested_at': datetime.now(timezone.utc).isoformat(),
        'operation': args.operation, 'request_sha256': remote.digest(request_bytes),
        'source_freeze_sha256': args.source_freeze_sha256, 'approval_sha256': args.approval_sha256,
        'prerequisite_manifest_sha256': manifest_sha, 'host': 'charlie-oss-4',
        'remote_source_sha256': remote.digest(source.encode()), 'retry_allowed': False}))
    # Exactly one transport attempt. SSH failure is retained, never interpreted as
    # proof that the remote action did not occur and never retried automatically.
    error = None
    try:
        process = subprocess.run(command, input=request_bytes, capture_output=True)
        code, stdout, stderr = process.returncode, process.stdout, process.stderr
    except BaseException as caught:
        code, stdout, stderr = None, b'', b''
        error = repr(caught)
    remote.write_new(destination / 'stdout', stdout)
    remote.write_new(destination / 'stderr', stderr)
    receipt = {'operation': args.operation, 'completed_at': datetime.now(timezone.utc).isoformat(),
        'returncode': code, 'transport_exception': error, 'request_sha256': remote.digest(request_bytes),
        'source_freeze_sha256': args.source_freeze_sha256, 'approval_sha256': args.approval_sha256,
        'prerequisite_manifest_sha256': manifest_sha, 'stdout_sha256': remote.digest(stdout),
        'stderr_sha256': remote.digest(stderr), 'remote_success_validated': False}
    if code == 0:
        try:
            result = json.loads(stdout)
            body = result['receipt']
            remote.need(body['valid'] is True and body['operation'] == args.operation
                        and body['request_sha256'] == remote.digest(request_bytes)
                        and body['approval_sha256'] == args.approval_sha256
                        and body['controls_source_freeze_sha256'] == args.source_freeze_sha256
                        and body['prerequisite_manifest_sha256'] == manifest_sha
                        and body['payloads'] == manifest['files']
                        and body['retained_inherited_build_environment'] == {'PATH': remote.RETAINED_PATH}
                        and result['remote_receipt_sha256'] == remote.digest(remote.encode_json(body)), 'remote receipt does not join transfer')
            if args.operation == 'stage':
                remote.need(body['workload_launched'] is False, 'staging unexpectedly launched a workload')
            else:
                remote.need(body['launched'] is True and body['command'] == remote.controller_command(manifest_sha)
                            and body['session'] == remote.SESSION, 'native launch command differs')
            receipt.update(remote=result, remote_success_validated=True)
        except BaseException as caught:
            receipt['validation_exception'] = repr(caught)
    remote.write_new(destination / 'receipt.json', remote.encode_json(receipt))
    remote.write_new(destination / 'seal.json', remote.encode_json({path.name: remote.sha(path) for path in sorted(destination.iterdir())}))
    freeze_check(args.source_freeze_sha256)
    verify_prepared()
    print(json.dumps({key: receipt[key] for key in ('operation', 'returncode', 'remote_success_validated', 'prerequisite_manifest_sha256')}, sort_keys=True))
    raise SystemExit(0 if receipt['remote_success_validated'] else 1)


if __name__ == '__main__':
    main()
