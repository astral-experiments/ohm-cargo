#!/usr/bin/env python3
"""Build a new local prerequisite package only after separately approved IR reviews."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import remote

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
WORK = PROJECT / 'work'
ORIGINAL = WORK / 'sbom-current179-ir-continuation'
WRAPPER = WORK / 'sbom-current179-native-prerequisite-amendment'
PREPARED = HERE / 'prepared'


def regular_local(path):
    path = Path(path).absolute()
    remote.need(path.is_relative_to(WORK) and path.resolve() == path and path.is_file()
                and not path.is_symlink(), 'input is outside canonical task work files')
    return path


def freeze_check(expected):
    freeze_path = regular_local(HERE / 'source-freeze.json')
    remote.need(remote.sha(freeze_path) == expected, 'producer source freeze differs')
    frozen = json.loads(freeze_path.read_bytes())
    for name, row in frozen['files'].items():
        remote.need(remote.record(regular_local(HERE / remote.relative(name))) == row, 'producer source changed')
    for name, row in frozen['external_files'].items():
        remote.need(remote.record(regular_local(name)) == row, 'protected original source changed')
    remote.need(frozen['original_frozen_inputs'] == 174, 'original input scope differs')
    return frozen


def verify_prepared():
    manifest_path = regular_local(PREPARED / 'manifest.json')
    manifest = json.loads(manifest_path.read_bytes())
    contents = {}
    for name, row in manifest['files'].items():
        path = regular_local(PREPARED / remote.relative(name))
        remote.need(remote.record(path) == row, 'prepared bytes or modes changed')
        contents[name] = path.read_bytes()
    remote.need({str(path.relative_to(PREPARED)) for path in PREPARED.rglob('*') if path.is_file()}
                == set(contents) | {'manifest.json'}, 'unexpected local prepared file')
    remote.validate_bindings(manifest, contents)
    return manifest, contents


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--root-approval', required=True)
    parser.add_argument('--root-approval-sha256', required=True)
    parser.add_argument('--ir-review', required=True)
    parser.add_argument('--ir-review-execution-approval', required=True)
    parser.add_argument('--path-lineage-review', required=True)
    parser.add_argument('--path-lineage-root-approval', required=True)
    args = parser.parse_args()
    frozen = freeze_check(args.source_freeze_sha256)
    remote.need(not PREPARED.exists() and not PREPARED.is_symlink(), 'local preparation already attempted')
    protected, contents, rows = {}, {}, {}

    def capture(path):
        path = regular_local(path)
        row = remote.record(path)
        data = path.read_bytes()
        remote.need(remote.digest(data) == row['sha256'] and len(data) == row['bytes'], 'input changed while reading')
        protected[str(path)] = row
        return data, row

    def add(name, path):
        remote.relative(name)
        remote.need(name not in contents, 'duplicate prerequisite destination')
        contents[name], rows[name] = capture(path)

    approval_path = regular_local(args.root_approval)
    remote.need(remote.sha(approval_path) == args.root_approval_sha256, 'native preparation approval differs')
    approval = json.loads(approval_path.read_bytes())
    remote.need(approval['valid'] is True and approval['authorized_operation'] == 'prepare-native-prerequisites-only'
                and approval['controls_source_freeze_sha256'] == args.source_freeze_sha256
                and approval['output'] == str(PREPARED), 'native preparation is not approved for this output')
    review_dir = Path(args.ir_review).absolute()
    remote.need(review_dir.is_relative_to(WORK) and review_dir.resolve() == review_dir and review_dir.is_dir(), 'unsafe IR review directory')
    add('root-approval.json', approval_path)
    add('strict_native_entry.py', WRAPPER / 'strict_native_entry.py')
    for name in ('review.json', 'raw-integrity.json', 'effects.json', 'seal.json'):
        add('review/' + name, review_dir / name)
    add('review/root-execution-approval.json', args.ir_review_execution_approval)
    add('lineage/review.json', args.path_lineage_review)
    add('lineage/root-approval.json', args.path_lineage_root_approval)
    add('collection-receipt.json', ORIGINAL / 'ir-confirmation-collection-receipt.json')
    collection = ORIGINAL / 'evidence/ir-confirmation'
    add('transfer-manifest.json', collection / 'transfer-manifest.json')
    for name in frozen['files']:
        add('controls/' + name, HERE / remote.relative(name))
    add('controls/source-freeze.json', HERE / 'source-freeze.json')
    transfer = json.loads(contents['transfer-manifest.json'])
    receipt = json.loads(contents['collection-receipt.json'])
    remote.need(receipt['valid'] is True and receipt['phase'] == 'ir-confirmation'
                and receipt['cohort_sha256'] == remote.COHORT
                and receipt['continuation_capsule_sha256'] == remote.CAPSULE_SHA
                and receipt['files'] == len(transfer['files']), 'IR collection receipt scope differs')
    for name, row in transfer['files'].items():
        path = regular_local(collection / remote.relative(name))
        remote.need(remote.record(path) == row, 'collected accepted IR bytes changed: ' + name)
        protected[str(path)] = row
    archive = regular_local(ORIGINAL / 'ir-confirmation-evidence.tar.gz')
    remote.need(remote.sha(archive) == receipt['archive_sha256'], 'accepted IR archive changed')
    protected[str(archive)] = remote.record(archive)
    lineage = json.loads(contents['lineage/review.json'])
    for name, expected in lineage['bound_files'].items():
        path = regular_local(name)
        remote.need(remote.sha(path) == expected, 'accepted PATH lineage input changed')
        protected[str(path)] = remote.record(path)
    status_name = 'results/ir-completion-01/status.json'
    protocol = json.loads(contents['controls/reference/protocol.json'])
    manifest = {'operation': 'root-approved-native-after-independent-ir-review',
        'created_at': datetime.now(timezone.utc).isoformat(), 'capsule_manifest_sha256': remote.CAPSULE_SHA,
        'controls_source_freeze_sha256': args.source_freeze_sha256,
        'continuation_status_sha256': transfer['files'][status_name]['sha256'],
        'protocol_sha256': remote.PROTOCOL, 'retained_inherited_build_environment': {'PATH': remote.RETAINED_PATH},
        'native_phases': [phase for phase in protocol['phases'] if phase['metric'] == 'native_wall_seconds'],
        'input_paths': {'ir_review': str(review_dir)}, 'files': rows}
    remote.validate_bindings(manifest, contents)
    preparation = remote.encode_json({'valid': True, 'prepared_at': datetime.now(timezone.utc).isoformat(),
        'root_approval_sha256': args.root_approval_sha256, 'controls_source_freeze_sha256': args.source_freeze_sha256,
        'input_records': protected, 'no_host_or_workload_execution': True,
        'effects_recomputed_or_interpreted': False, 'original_inputs_unchanged': 174})
    contents['preparation.json'] = preparation
    rows['preparation.json'] = {'sha256': remote.digest(preparation), 'bytes': len(preparation), 'mode': 0o644}
    remote.validate_bindings(manifest, contents)
    remote.need(all(remote.record(regular_local(name)) == row for name, row in protected.items()), 'input changed during preparation')
    freeze_check(args.source_freeze_sha256)
    PREPARED.mkdir(mode=0o700)
    for name, data in contents.items():
        remote.write_new(PREPARED / remote.relative(name), data, rows[name]['mode'])
    remote.write_new(PREPARED / 'manifest.json', remote.encode_json(manifest))
    verify_prepared()
    remote.need(all(remote.record(regular_local(name)) == row for name, row in protected.items()), 'input changed while writing local package')
    freeze_check(args.source_freeze_sha256)
    print(json.dumps({'valid': True, 'prerequisite_manifest_sha256': remote.sha(PREPARED / 'manifest.json'),
                      'prepared': str(PREPARED), 'payloads': len(rows), 'no_host_or_workload_execution': True}, sort_keys=True))


if __name__ == '__main__':
    main()
