#!/usr/bin/env python3
"""Freeze only new prospective controls; verify and preserve every referenced source."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import remote

HERE = Path(__file__).resolve().parent
WORK = HERE.parent


def main():
    remote.need(not (HERE / 'source-freeze.json').exists(), 'source freeze already exists')
    remote.need(all(not (HERE / name).exists() for name in ('prepared', 'stage-attempt01', 'launch-attempt01')),
                'real preparation or transport has already been attempted')
    pins = {
        'sbom-current179-ir-continuation': '5f9374511f5f9d1ca00a1b1cc11bb1845914e4d20d19b458051cf78c17507624',
        'sbom-current179-native-prerequisite-amendment': '8792edd14627d3315876c83b7cce3bf3a52ea437cc4385a755cc3d497b3f7086',
        'sbom-current179-ir-environment': remote.ENVIRONMENT,
        'sbom-current179-ir-environment-review': remote.LINEAGE_REVIEWER,
        'sbom-current179-native-launch-controls': 'b6f1045794853ebb62963cc67c6830379896c3fa417fc0e538d890eab39f32e1',
        'sbom-current179-ir-reviewer-profiler-alias-v2': remote.RAW_REVIEWER,
    }
    external = {}
    counts = {}
    for name, expected in pins.items():
        root = WORK / name
        path = root / 'source-freeze.json'
        remote.need(remote.sha(path) == expected, 'referenced freeze changed')
        external[str(path)] = remote.record(path)
        frozen = json.loads(path.read_bytes())
        counts[name] = len(frozen['files'])
        for member, row in frozen['files'].items():
            member_path = root / remote.relative(member)
            observed = remote.record(member_path)
            remote.need(all(observed[key] == value for key, value in row.items()), 'referenced frozen source changed')
            if str(member_path) in external:
                remote.need(external[str(member_path)] == observed, 'conflicting reference records')
            external[str(member_path)] = observed
    remote.need(counts['sbom-current179-ir-continuation'] == 174, 'original input count differs')
    original = WORK / 'sbom-current179-ir-continuation'
    remote.need(remote.sha(original / 'reviewer/source-freeze.json') == 'fb2529078308fd3e4c816402aa3df1d4a01e52cb32a079a86e9366d5dbedbd6b',
                'historical raw reviewer source changed')
    alias = WORK / 'sbom-current179-ir-reviewer-profiler-alias-v2'
    remote.need(remote.sha(alias / 'source-freeze.json') == remote.RAW_REVIEWER, 'accepted alias reviewer changed')
    previous = WORK / 'sbom-current179-native-launch-controls'
    prior_freeze = json.loads((previous / 'source-freeze.json').read_bytes())
    for name, row in prior_freeze['external_files'].items():
        remote.need(remote.record(Path(name)) == row, 'historical native-control input changed')
        remote.need(external.get(name, row) == row, 'conflicting historical input binding')
        external[name] = row
    historical = json.loads((alias / 'history/protected-original-inputs.json').read_bytes())['files']
    for name, expected in historical.items():
        path = Path(name)
        observed = remote.record(path)
        remote.need(observed['sha256'] == expected, 'alias correction retained input changed')
        remote.need(external.get(name, observed) == observed, 'conflicting alias history binding')
        external[name] = observed
    failed_names = ('root-ir-review-execution-approval.json', 'root-path-lineage-acceptance.json',
                    'independent-ir-review-execution.json', 'independent-ir-review.stdout',
                    'independent-ir-review.stderr')
    for name in failed_names:
        path, retained = original / name, alias / 'history/failed-review' / name
        remote.need(remote.sha(path) == remote.sha(retained), 'failed review receipt copy differs')
        external[str(path)] = remote.record(path)
    failed_output = original / 'independent-ir-review'
    remote.need(failed_output.resolve() == failed_output and failed_output.is_dir()
                and not list(failed_output.iterdir()), 'failed pre-effect output was changed')
    remote.need(remote.sha(original / 'contract.py') == remote.CONTRACT_SHA, 'original contract changed')
    remote.need(remote.sha(original / 'native-original-controller.py') == 'd1f05e3909e83fccb93c4d1c8b6445921333a68cddc275f888198121dc5177fb',
                'original native controller changed')
    remote.need(remote.sha(original / 'native_entry.py') == 'db5b699ac719b699899402eb207e6a5d7527faa9bff02145cd8b9ead44703a8e',
                'original continued native entry changed')
    remote.need(remote.sha(HERE / 'reference/protocol.json') == remote.PROTOCOL, 'native protocol changed')
    wrapper_review = WORK / 'compiler-audit/sbom-native-wrapper-review'
    remote.need(remote.sha(wrapper_review / 'seal.json') == '5658981dc92f7c3a633f66b9b23f9efdf50aa5a98f91a2e0545ac51c733183d3',
                'wrapper source review changed')
    for name, expected in json.loads((wrapper_review / 'seal.json').read_bytes()).items():
        path = wrapper_review / remote.relative(name)
        remote.need(remote.sha(path) == expected, 'wrapper review payload changed')
        external[str(path)] = remote.record(path)
    external[str(wrapper_review / 'seal.json')] = remote.record(wrapper_review / 'seal.json')
    pure = json.loads((HERE / 'pure-check-attempt04/result.json').read_bytes())
    remote.need(pure['valid'] is True and pure['tests'] == 16 and pure['failures'] == pure['errors'] == 0,
                'final pure checks did not pass')
    for name, expected in pure['source_sha256'].items():
        remote.need(remote.sha(HERE / name) == expected, 'tested source changed')
    for attempt in ('01', '02', '03'):
        prior = json.loads((HERE / ('pure-check-attempt' + attempt) / 'result.json').read_bytes())
        for name, expected in prior['source_sha256'].items():
            remote.need(remote.sha(HERE / 'history' / ('pure-check-attempt' + attempt + '-source') / name) == expected,
                        'earlier pure source history changed')
    audit = {'valid': True, 'audited_at': datetime.now(timezone.utc).isoformat(),
        'scope': 'Source-only successor accepting the exact authenticated alias reviewer; all native loops/statistics preserved.',
        'source_freeze_pins': pins, 'referenced_file_counts': counts,
        'original_native_controller_sha256': remote.sha(original / 'native-original-controller.py'),
        'original_native_entry_sha256': remote.sha(original / 'native_entry.py'),
        'strict_wrapper_sha256': remote.WRAPPER_SHA, 'protocol_sha256': remote.PROTOCOL,
        'pure_tests': 16, 'pure_result_sha256': remote.sha(HERE / 'pure-check-attempt04/result.json'),
        'previous_controls_source_freeze_sha256': pins['sbom-current179-native-launch-controls'],
        'accepted_raw_reviewer_sha256': remote.RAW_REVIEWER,
        'historical_failed_review_records': {name: remote.sha(original / name) for name in failed_names},
        'historical_failed_review_output_empty': True,
        'new_review_requires_new_execution_approval_and_pre_review_lineage_acceptance': True,
        'runtime_source_delta': 'remote.py RAW_REVIEWER literal only',
        'native_plan': {'pairs_per_workload': 30, 'warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
                        'test_seed': 20261021103, 'check_seed': 20261021104},
        'producer_accepts_two_separately_root_approved_reviews': True,
        'actual_tmux_child_environment_guard': True,
        'transfer_and_launch_separately_approved': True,
        'unique_receipts_no_automatic_retry': True,
        'existing_freezes_modified': False, 'actual_reviews_or_effects_read': False,
        'preparation_transfer_launch_executed': False, 'host_actions_performed': False}
    remote.write_new(HERE / 'source-audit.json', remote.encode_json(audit))
    files = {str(path.relative_to(HERE)): remote.record(path) for path in sorted(HERE.rglob('*')) if path.is_file()}
    remote.need(all(remote.record(Path(name)) == row for name, row in external.items()), 'reference changed during freeze')
    freeze = {'scope': 'Source-only future native prerequisite producer/launcher; requires independent root review before use.',
        'created_at': datetime.now(timezone.utc).isoformat(), 'files': files, 'external_files': external,
        'original_frozen_inputs': 174, 'original_capsule_manifest_sha256': remote.CAPSULE_SHA,
        'strict_wrapper_sha256': remote.WRAPPER_SHA, 'effects_inspected': False,
        'host_actions_performed': False, 'real_preparation_performed': False,
        'pure_tests': 16, 'source_audit_sha256': remote.sha(HERE / 'source-audit.json'),
        'previous_controls_source_freeze_sha256': pins['sbom-current179-native-launch-controls'],
        'accepted_raw_reviewer_sha256': remote.RAW_REVIEWER}
    remote.write_new(HERE / 'source-freeze.json', remote.encode_json(freeze))
    print(json.dumps({'source_freeze_sha256': remote.sha(HERE / 'source-freeze.json'),
                      'files': len(files), 'protected_external_files': len(external),
                      'source_audit_sha256': remote.sha(HERE / 'source-audit.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
