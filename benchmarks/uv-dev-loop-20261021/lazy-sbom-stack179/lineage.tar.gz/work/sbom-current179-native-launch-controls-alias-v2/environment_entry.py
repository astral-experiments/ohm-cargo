#!/usr/bin/env python3
"""Prove the actual tmux child environment, then exec the unchanged strict wrapper."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
BINDING = ROOT / 'continuations/native-prerequisite-01'
CAPSULE_SHA = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
CORE_SHA = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def validate_environment(actual, expected, observed, retained):
    need(set(expected) == {'PATH'} and actual == expected,
         'actual native controller build environment differs from accepted IR')
    keys = ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid')
    machine = {key: observed[key] for key in keys}
    need(machine == {key: retained[key] for key in keys}, 'actual native controller machine differs')
    return machine


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capsule-manifest-sha256', required=True)
    parser.add_argument('--prerequisite-sha256', required=True)
    args = parser.parse_args()
    need(args.capsule_manifest_sha256 == CAPSULE_SHA and Path(__file__).resolve() == BINDING / 'controls/environment_entry.py'
         and ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid() == 1000
         and Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(), 'entry root/identity differs')
    manifest_path = BINDING / 'manifest.json'
    need(manifest_path.resolve() == manifest_path and not manifest_path.is_symlink()
         and sha(manifest_path) == args.prerequisite_sha256, 'approved prerequisite manifest differs')
    manifest = json.loads(manifest_path.read_bytes())
    # Authenticate the shared validation module before importing it. The expected
    # source is contained in the separately approved immutable prerequisite index.
    source = BINDING / 'controls/remote.py'
    row = manifest['files']['controls/remote.py']
    need(source.resolve() == source and source.is_file() and not source.is_symlink()
         and sha(source) == row['sha256'] and source.stat().st_size == row['bytes']
         and stat.S_IMODE(source.stat().st_mode) == row['mode'], 'bound entry validator changed')
    spec = importlib.util.spec_from_file_location('native_entry_validation', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    validated, contents = module.read_binding()
    need(validated == manifest, 'prerequisite changed while entering')
    contract = module.load_contract()
    module.accepted_live_bytes(contract, manifest, contents)
    paired_path = ROOT / 'work/benchmark/paired.py'
    need(module.record(paired_path)['sha256'] == CORE_SHA, 'original paired harness changed')
    paired = contract.load('native_entry_original_paired', paired_path)
    actual = paired.build_environment_metadata()
    retained = json.loads((ROOT / 'results/test-ir-confirmation/manifest.json').read_bytes())['machine']
    observed = paired.machine_metadata()
    machine = validate_environment(actual, manifest['retained_inherited_build_environment'], observed, retained)
    history = ROOT / 'continuations/native-prerequisite-launch-01'
    before = json.loads((history / 'before.json').read_bytes())
    request = json.loads((history / 'request.json').read_bytes())
    approval = json.loads((history / 'root-approval.json').read_bytes())
    need(sha(history / 'request.json') == before['request_sha256']
         and sha(history / 'root-approval.json') == before['approval_sha256'] == request['approval_sha256']
         and before['prerequisite_manifest_sha256'] == args.prerequisite_sha256
         and before['command'] == module.controller_command(args.prerequisite_sha256)
         and approval['valid'] is True and approval['authorized_operation'] == 'launch-fixed-native-prerequisites'
         and approval['prerequisite_manifest_sha256'] == args.prerequisite_sha256,
         'actual native entry lacks the reviewed launch binding')
    command = ['/usr/bin/python3', '-B', str(BINDING / 'strict_native_entry.py'),
               '--capsule-manifest-sha256', args.capsule_manifest_sha256,
               '--prerequisite-sha256', args.prerequisite_sha256]
    module.write_new(history / 'entry-receipt.json', module.encode_json({
        'valid': True, 'verified_at': datetime.now(timezone.utc).isoformat(),
        'prerequisite_manifest_sha256': args.prerequisite_sha256,
        'actual_inherited_build_environment': actual, 'machine': machine,
        'launch_request_sha256': sha(history / 'request.json'), 'before_sha256': sha(history / 'before.json'),
        'environment_entry_sha256': sha(Path(__file__)), 'strict_native_entry_sha256': module.WRAPPER_SHA,
        'command': command, 'original_controller_not_yet_executed': True}))
    os.execv('/usr/bin/python3', command)


if __name__ == '__main__':
    main()
