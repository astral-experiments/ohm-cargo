#!/usr/bin/env python3
"""Hash-bind the complete native prerequisite before the unchanged original entrypoint."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import os
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
CAPSULE = ROOT / 'continuations/ir-check-01'
BINDING = ROOT / 'continuations/native-prerequisite-01'
CAPSULE_SHA256 = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
CONTRACT_SHA256 = '3b39ed7a47ca7433aef4f0861f1006cbf6724b5afefb6e46aaa78d063e3c5bca'
REQUIRED_FILES = frozenset({
    'strict_native_entry.py', 'root-approval.json', 'review/seal.json',
    'review/review.json', 'review/raw-integrity.json', 'review/effects.json',
    'transfer-manifest.json', 'collection-receipt.json',
})


def require(condition, message):
    if not condition:
        raise ValueError(message)


def required_payloads(files):
    require(isinstance(files, dict), 'native prerequisite file index is not an object')
    require(REQUIRED_FILES <= set(files), 'native prerequisite omits a required hash-bound payload')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capsule-manifest-sha256', required=True)
    parser.add_argument('--prerequisite-sha256', required=True)
    args = parser.parse_args()
    require(args.capsule_manifest_sha256 == CAPSULE_SHA256, 'unexpected original IR capsule')
    require(Path(__file__).resolve() == BINDING / 'strict_native_entry.py'
            and ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid() == 1000,
            'strict wrapper is outside its owned prerequisite binding')
    require(Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(),
            'strict wrapper requires the system Python')
    source = CAPSULE / 'contract.py'
    require(source.resolve() == source and source.is_file() and not source.is_symlink()
            and sha(source) == CONTRACT_SHA256, 'original contract changed')
    spec = importlib.util.spec_from_file_location('strict_native_original_contract', source)
    contract = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = contract
    spec.loader.exec_module(contract)
    contract.verify_capsule(CAPSULE, args.capsule_manifest_sha256)
    manifest_path = contract.regular(BINDING, BINDING / 'manifest.json')
    require(sha(manifest_path) == args.prerequisite_sha256, 'native prerequisite manifest changed')
    manifest = json.loads(manifest_path.read_text())
    required_payloads(manifest['files'])
    for name, expected in manifest['files'].items():
        path = contract.regular(BINDING, BINDING / contract.relative(name))
        require(contract.record(path) == expected, 'native prerequisite payload changed: ' + name)
    approval = json.loads((BINDING / 'root-approval.json').read_text())
    require(approval['strict_native_entry_sha256'] == sha(Path(__file__)),
            'root approval does not bind the strict native prerequisite guard')
    # The original entry performs every original acceptance, source, raw-byte,
    # native-plan and occupancy check. Its frozen file and capsule stay unchanged.
    os.execv('/usr/bin/python3', ['/usr/bin/python3', '-B', str(CAPSULE / 'native_entry.py'),
        '--capsule-manifest-sha256', args.capsule_manifest_sha256,
        '--prerequisite-sha256', args.prerequisite_sha256])


if __name__ == '__main__':
    main()
