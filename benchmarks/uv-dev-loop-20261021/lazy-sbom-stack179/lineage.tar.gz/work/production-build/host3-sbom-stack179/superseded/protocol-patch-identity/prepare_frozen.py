#!/usr/bin/env python3
"""Prepare reviewed build inputs locally; this script never contacts a host."""

import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
REFERENCE = ROOT.parent / "host5-allocator"
FROZEN = ROOT / "frozen"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, data):
    with path.open("xb") as stream:
        stream.write(data if isinstance(data, bytes) else data.encode())


def write_json(path, value):
    write_new(path, json.dumps(value, indent=2) + "\n")


def plan(count, seed):
    orders = [["baseline", "candidate"] for _ in range(count // 2)]
    orders += [["candidate", "baseline"] for _ in range(count // 2)]
    random.Random(seed).shuffle(orders)
    return orders


def replace(text, old, new):
    assert old in text, old
    return text.replace(old, new)


source = json.loads((ROOT / "source-manifest.json").read_text())
assert source["candidate_tree"] == "c377ade816d378aa75f629313ac7b116da10c6da"
reference_manifest = json.loads((REFERENCE / "frozen/manifest.json").read_text())
reference_driver = REFERENCE / "frozen/build_driver_host5_allocator.py"
assert sha(reference_driver) == reference_manifest["driver_sha256"] == "260613622598cbda7d6947b5b0ce13ae538375898fd7a98b3d4f856f12d1f763"

protocol = json.loads((WORK / "dirty-sbom/protocol.json").read_text())
protocol.update({
    "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "state": "Prospective current179 protocol; no current-cohort builds or comparisons have run",
    "cohort": "current179-lazy-sbom",
    "root": "/tmp/ohm-hillclimb-20261021/lazy-sbom-current179",
    "historical_protocol_sha256": sha(WORK / "dirty-sbom/protocol.json"),
    "historical_results_scope": "The completed PR175 screen and confirmation select this unchanged source optimization only. Their samples are not pooled with or presented as current179 incremental results. The old-parent native phase is held because the proposed parent changed.",
    "baseline": "Current PR179 commit 19718e6d1637244ffbb193334f50bae3ffca1be5, tree f4ce59f92aa17461fe3c8b68923c88539136045a, represented atop fixed embedded Cargo HEAD 5e5d271d763d7beb38b48755e22bd59e93f02b97",
    "candidate_tree": source["candidate_tree"],
    "candidate_full_patch_sha256": source["patch_sha256"]["stack179-lazy-sbom.patch"],
    "candidate_incremental_patch_sha256": source["patch_sha256"]["lazy-sbom-stack179.patch"],
    "build_host": "charlie-oss-3",
    "measurement_host": "charlie-oss-4",
    "build_pair": "Fresh current179 baseline and unchanged lazy-SBOM candidate, built serially in one host3 session at the same absolute source/target paths and with identical sealed compiler, native tools, flags and inherited environment. Do not mix this pair with earlier binaries.",
    "selection": "Run both fixed current179 instruction confirmations without inspecting interim effects. Proceed to both fixed native validations only if the primary dirty test-build instruction confirmation passes its complete gate. A secondary check result never rescues a failed primary. Each metric/workload claim requires its own gate and no established native regression. No pooling with historical samples or across workloads/metrics.",
    "isolation": "Use a new owned root and clean uv checkout, fresh shared cache and per-workload equal-length base/cand targets. Preserve the historical PR175 root and all loader fixtures. Public package-cache inputs may be copied read-only. Prepare native prerequisites outside timing, then run the existing per-sample BEFORE build/AFTER edit protocol. Use cohort-specific edit labels; paired bytes stay identical. No concurrent producer, restore, transfer or other benchmark on host4 during timing.",
    "preflight": "Before comparisons, use both real frozen binaries on both target assignments in native and instrumented modes for both workloads (16 diagnostics). Bind each canonical target to its exact observed workspace hash, retaining compiler-context and unit hashes. Require the expected six uv test-build compiler stages and one uv check source compilation, equal between variants, with no test execution. A mismatch stops setup for review; it does not widen the auditor automatically.",
    "validation": protocol["validation"] + " Use the reviewed v2 namespace auditor and exact configured prepare/cleanup hooks from the successful v3 preflight. The paired core, dirty fixture, source guard and statistical calculations remain unchanged. Adapt only cohort paths, binary/input identities and predeclared phase labels/seeds; freeze generated configs and expectation hashes after diagnostics and before any comparison.",
    "pending_assets": [
        "Both matched host3 current179 binaries plus their source/build/strip and independent pair audit",
        "New host4 ownership/source/runtime/package-cache seals and frozen setup adaptation",
        "All 16 untimed diagnostics, expected compiler signatures and exact target namespace bindings",
        "Final measured configs with binary and input hashes; no placeholder executable is permitted",
    ],
})
protocol.pop("baseline_binary_sha256")
protocol["phases"] = []
for metric, count, seeds in (
    ("cargo_ir", 12, (20261021101, 20261021102)),
    ("native_wall_seconds", 30, (20261021103, 20261021104)),
):
    for workload, seed in zip(("test", "check"), seeds):
        protocol["phases"].append({
            "metric": metric, "phase": "confirmation", "workload": workload,
            "primary": workload == "test", "pairs": count, "warmup_pairs": 2,
            "invocations_per_variant_per_pair": 1, "seed": seed,
            "measurement_plan": plan(count, seed), "warmup_plan": plan(2, seed ^ 0x5A17),
            "target_assignment": {"baseline": "cand", "candidate": "base"},
        })
write_json(FROZEN / "protocol.json", protocol)

for name in ("strip_binaries.py", "reference-host7-provenance.json", "stack179-current.patch"):
    write_new(FROZEN / name, (REFERENCE / "frozen" / name).read_bytes())

original = reference_driver.read_text()
driver = original
replacements = {
    "host5-allocator": "host3-sbom-stack179",
    "host5_allocator": "host3_sbom_stack179",
    "charlie-oss-5": "charlie-oss-3",
    "host5": "host3",
    "allocator-baseline": "sbom-stack179-baseline",
    "allocator-jemalloc": "sbom-stack179-lazy",
    "stack179-linux-jemalloc.patch": "stack179-lazy-sbom.patch",
    "0ce92d594919d69e6284d0920207aef3c4990c4638730976df0af3b6c7043f70": source["patch_sha256"]["stack179-lazy-sbom.patch"],
    "b4561c66951de3c6717b8ce6a99d0ea45ff73b41": source["candidate_tree"],
    "current179/allocator": "current179/lazy-SBOM",
}
for old, new in replacements.items():
    driver = replace(driver, old, new)
driver = replace(driver, '    for name in ("status-host3-sbom-stack179.json",', '''    owner = json.loads((ROOT / "ownership-host3-sbom-stack179.json").read_text())
    expected_owner = {"cohort": "host3-sbom-stack179", "root": str(ROOT), "uid": os.getuid(),
                      "inputs_sha256": sha(ROOT / "host3-sbom-stack179-inputs.json")}
    if owner != expected_owner or ROOT.stat().st_uid != os.getuid() or SOURCE.resolve() != SOURCE:
        raise RuntimeError("production root ownership or source path differs from the frozen task")
    for name in ("status-host3-sbom-stack179.json",''')
driver = replace(driver, '"host3-sbom-stack179-inputs.json", "build_driver_host3_sbom_stack179.py",',
                 '"host3-sbom-stack179-inputs.json", "ownership-host3-sbom-stack179.json", "build_driver_host3_sbom_stack179.py",')
assert "allocator" not in driver and "jemalloc" not in driver
ast.parse(driver)
write_new(ROOT / "build_driver_host3_sbom_stack179.py", driver)
write_new(FROZEN / "build_driver_host3_sbom_stack179.py", driver)
write_new(ROOT / "driver.diff", "".join(difflib.unified_diff(original.splitlines(True), driver.splitlines(True), fromfile="reviewed-host5-driver", tofile="prospective-host3-sbom-driver")))

variants = {
    "sbom-stack179-baseline": ("stack179-current.patch", source["base_tree"], "1864ecf029d0bb36c102264b5648cc25848b8be7537597e16944078b562d23fb"),
    "sbom-stack179-lazy": ("stack179-lazy-sbom.patch", source["candidate_tree"], source["patch_sha256"]["stack179-lazy-sbom.patch"]),
}
manifest = {
    "cohort": "host3-sbom-stack179", "build_host": "charlie-oss-3",
    "variant_order": list(variants), "driver_sha256": sha(FROZEN / "build_driver_host3_sbom_stack179.py"),
    "strip_helper_sha256": sha(FROZEN / "strip_binaries.py"),
    "source_bundle_sha256": sha(ROOT.parent / "pinned.bundle"),
    "patch_sha256": {name: sha(FROZEN / name) for name, _, _ in variants.values()},
    "expected_variants": {
        variant: {"base": "5e5d271d763d7beb38b48755e22bd59e93f02b97", "tree": tree,
                  "patch_sha256": {name: sha(FROZEN / name)}, "canonical_diff_sha256": canonical}
        for variant, (name, tree, canonical) in variants.items()
    },
    "reference_host7_provenance_sha256": sha(FROZEN / "reference-host7-provenance.json"),
    "reviewed_driver_parent_sha256": sha(reference_driver),
    "performance_protocol_sha256": sha(FROZEN / "protocol.json"),
    "source_manifest_sha256": sha(ROOT / "source-manifest.json"),
    "host3_readonly_input_check_sha256": sha(ROOT / "host3-readonly-inputs.json"),
}
write_json(FROZEN / "manifest.json", manifest)
print(json.dumps({"driver_sha256": manifest["driver_sha256"], "manifest_sha256": sha(FROZEN / "manifest.json"), "protocol_sha256": manifest["performance_protocol_sha256"], "source_tree": source["candidate_tree"]}, indent=2))
