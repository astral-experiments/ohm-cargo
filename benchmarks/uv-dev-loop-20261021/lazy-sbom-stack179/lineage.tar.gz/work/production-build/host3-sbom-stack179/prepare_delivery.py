#!/usr/bin/env python3
"""Adapt the reviewed provisioning/collection/audit tools without running them."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent / "host5-allocator"


def change(text, old, new):
    assert old in text, old
    return text.replace(old, new)


def adapt(text):
    for old, new in (
        ("host5-allocator", "host3-sbom-stack179"),
        ("host5_allocator", "host3_sbom_stack179"),
        ("charlie-oss-5", "charlie-oss-3"),
        ("host5", "host3"),
        ("allocator-baseline", "sbom-stack179-baseline"),
        ("allocator-jemalloc", "sbom-stack179-lazy"),
        ("stack179-linux-jemalloc.patch", "stack179-lazy-sbom.patch"),
    ):
        text = text.replace(old, new)
    return text


generated = {}
original = (REFERENCE / "provision.py").read_text()
provision = adapt(original)
provision = change(provision, 'import hashlib\n', 'import argparse\nimport hashlib\n')
provision = change(provision, 'FROZEN = ROOT / "frozen"\n', '''FROZEN = ROOT / "frozen"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
assert hashlib.sha256((FROZEN / "manifest.json").read_bytes()).hexdigest() == args.manifest_sha256
manifest = json.loads((FROZEN / "manifest.json").read_text())
''')
provision = change(provision, 'archive_path = ROOT / "provision-inputs.tar"', '''assert hashes["build_driver_host3_sbom_stack179.py"] == manifest["driver_sha256"]
assert hashes["pinned.bundle"] == manifest["source_bundle_sha256"]
assert hashes["tools/strip_binaries.py"] == manifest["strip_helper_sha256"]
assert hashes["reference-host7-provenance.json"] == manifest["reference_host7_provenance_sha256"]
for name, expected_hash in manifest["patch_sha256"].items():
    assert hashes[name] == expected_hash
archive_path = ROOT / "provision-inputs.tar"''')
provision = change(provision, "assert root.resolve()==root", "assert root.resolve()==root and os.getuid()==1000")
provision = change(provision, "source=root/'source'", '''owner={'cohort':'host3-sbom-stack179','root':str(root),'uid':os.getuid(),
       'inputs_sha256':hashlib.sha256(payload['host3-sbom-stack179-inputs.json']).hexdigest()}
with (root/'ownership-host3-sbom-stack179.json').open('x') as stream:
 stream.write(json.dumps(owner,indent=2)+'\\n')
source=root/'source' ''')
provision = provision.replace("fresh, isolated host2 cohort", "fresh, isolated host3 SBOM cohort")
generated["provision.py"] = (original, provision)

original = (REFERENCE / "collect_variant.py").read_text()
collector = adapt(original)
collector = change(collector, 'import io,json,sys,tarfile\n', 'import io,json,os,socket,sys,tarfile\n')
collector = change(collector, "variant=sys.argv[1]\n", "assert socket.gethostname()=='charlie-oss-3' and root.resolve()==root and root.stat().st_uid==os.getuid()==1000\nvariant=sys.argv[1]\n")
collector = change(collector, "'provenance.json':root/'provenance-host3-sbom-stack179.json'}", "'provenance.json':root/'provenance-host3-sbom-stack179.json',\n       'ownership.json':root/'ownership-host3-sbom-stack179.json'}")
generated["collect_variant.py"] = (original, collector)

original = (REFERENCE / "audit.py").read_text()
audit = adapt(original)
audit = change(audit, 'variants = sys.argv[1:] or list(INPUTS["expected_variants"])', '''baseline_line = next(line for line in (RESULTS / "sbom-stack179-baseline.stderr").read_text().splitlines()
                     if "--crate-name cargo " in line and "src/bin/cargo/main.rs" in line)
baseline_args = shlex.split(baseline_line.strip().removeprefix("Running `").removesuffix("`"))
baseline_dependencies = sorted(baseline_args[i+1].split("=",1)[0]
                               for i, value in enumerate(baseline_args[:-1]) if value == "--extern")
owner = json.loads((RESULTS / "ownership.json").read_text())
assert owner == {"cohort": "host3-sbom-stack179", "root": "/tmp/ohm-hillclimb-20261021-production", "uid": 1000,
                 "inputs_sha256": sha(FROZEN / "manifest.json")}
variants = sys.argv[1:] or list(INPUTS["expected_variants"])''')
audit = change(audit, 'assert ("tikv_jemallocator" in dependency_names) == (variant == "sbom-stack179-lazy")',
               'assert dependency_names == baseline_dependencies')
generated["audit.py"] = (original, audit)

for name, (before, after) in generated.items():
    ast.parse(after)
    if name in ("provision.py", "collect_variant.py"):
        tree = ast.parse(after)
        embedded = next(node.value.value for node in tree.body if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == "remote" for target in node.targets))
        ast.parse(embedded)
    assert "allocator" not in after and "jemalloc" not in after
    with (ROOT / name).open("x") as stream:
        stream.write(after)
    with (ROOT / (name + ".diff")).open("x") as stream:
        stream.write("".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="reviewed-host5-" + name, tofile="prospective-host3-" + name)))

files = sorted(path for path in ROOT.rglob("*") if path.is_file() and path.name != "review-seal.json")
seal = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
with (ROOT / "review-seal.json").open("x") as stream:
    stream.write(json.dumps(seal, indent=2) + "\n")
print(json.dumps({"review_seal_sha256": hashlib.sha256((ROOT / "review-seal.json").read_bytes()).hexdigest(),
                  "files": len(seal), "generated_helpers": {name: seal[name] for name in generated}}, indent=2))
