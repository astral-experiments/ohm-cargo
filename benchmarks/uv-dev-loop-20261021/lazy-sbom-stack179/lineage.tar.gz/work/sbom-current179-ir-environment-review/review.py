"""Local pre-effect join for the unchanged SBOM continuation's PATH-only launch."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat

HERE = Path(__file__).resolve().parent
ENVIRONMENT = HERE.parent / 'sbom-current179-ir-environment'
ORIGINAL = HERE.parent / 'sbom-current179-ir-continuation'
SOURCE = 'c804e29e539b50dac4eae00bb71f2541016698a1aa0edfc639a73b052384ca69'
CAPTURE = '433c3d6c87efe7d5e21d7f6a5d6b4dc410cc63d7e50253a8ea1ad80215b557c3'
CAPSULE = '16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc'
HISTORY = 'continuations/ir-check-01-environment-attempt02/'
REMOTE = '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179'
EMPTY = hashlib.sha256(b'').hexdigest()


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def relative(name):
    path = PurePosixPath(name)
    need(name and name != '.' and str(path) == name and not path.is_absolute()
         and '..' not in path.parts and '\\' not in name, 'unsafe relative path')
    return path


def matching_request(request, capture, approval_sha):
    need(request['operation'] == 'launch-unchanged-fixed-check-with-retained-path'
         and request['source_freeze_sha256'] == SOURCE and request['capture_sha256'] == CAPTURE
         and request['capsule_manifest_sha256'] == CAPSULE and request['root_approval_sha256'] == approval_sha,
         'launch request identity differs')
    need(request['retained_test_manifest_sha256'] == capture['retained_test_manifest']['sha256']
         and request['retained_inherited_build_environment'] == capture['retained_test_inherited_build_environment']
         and set(request['retained_inherited_build_environment']) == {'PATH'}, 'launch environment differs')
    need(request['failed_controller_log_sha256'] == {suffix: capture['logs']['ir-completion-01.controller.' + suffix]['sha256']
                                                    for suffix in ('stdout', 'stderr')}, 'failed-log request join differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--controls', type=Path, required=True)
    parser.add_argument('--launch-approval', type=Path, required=True)
    parser.add_argument('--collection-receipt-sha256', required=True)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    own_freeze = HERE / 'source-freeze.json'
    need(sha(own_freeze) == args.source_freeze_sha256, 'lineage reviewer freeze differs')
    frozen = read(own_freeze)
    protected = {own_freeze: args.source_freeze_sha256,
                 ENVIRONMENT / 'source-freeze.json': SOURCE,
                 ENVIRONMENT / 'capture-01/stdout.json': CAPTURE}
    for name, row in frozen['files'].items():
        path = HERE / relative(name)
        need(path.resolve() == path and path.is_file() and not path.is_symlink()
             and sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'lineage source differs')
        protected[path] = row['sha256']
    need(sha(ENVIRONMENT / 'source-freeze.json') == SOURCE and sha(ENVIRONMENT / 'capture-01/stdout.json') == CAPTURE,
         'reviewed launch/capture binding differs')
    for name, row in read(ENVIRONMENT / 'source-freeze.json')['files'].items():
        path = ENVIRONMENT / relative(name)
        need(sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'environment source changed')
        protected[path] = row['sha256']
    controls = args.controls.absolute()
    need(controls.resolve() == controls, 'controls path is not canonical')
    root = controls / 'evidence/ir-confirmation'
    receipt_path = controls / 'ir-confirmation-collection-receipt.json'
    need(sha(receipt_path) == args.collection_receipt_sha256, 'terminal collection receipt differs')
    receipt = read(receipt_path)
    manifest_path = root / 'transfer-manifest.json'
    need(receipt['valid'] is True and receipt['phase'] == 'ir-confirmation'
         and receipt['continuation_capsule_sha256'] == CAPSULE
         and receipt['collector_sha256'] == sha(ORIGINAL / 'collect.py')
         and receipt['transfer_manifest_sha256'] == sha(manifest_path), 'collection identity differs')
    files = read(manifest_path)['files']
    protected[receipt_path] = args.collection_receipt_sha256
    protected[manifest_path] = receipt['transfer_manifest_sha256']
    def path(name):
        value = root / relative(name)
        need(name in files and value.resolve() == value and value.is_file() and not value.is_symlink(), 'unbound lineage member')
        row = files[name]
        need(sha(value) == row['sha256'] and value.stat().st_size == row['bytes']
             and stat.S_IMODE(value.stat().st_mode) == row['mode'], 'collected lineage member differs')
        protected[value] = row['sha256']
        return value
    capture = read(ENVIRONMENT / 'capture-01/stdout.json')
    launch_path = ENVIRONMENT / 'launch-attempt02/receipt.json'
    launch = read(launch_path)
    protected[launch_path] = sha(launch_path)
    approval = read(args.launch_approval)
    approval_sha = sha(args.launch_approval)
    protected[args.launch_approval] = approval_sha
    need(approval['status'] == 'passed' and approval['source_freeze_sha256'] == SOURCE
         and approval['capture_sha256'] == CAPTURE and approval['capsule_manifest_sha256'] == CAPSULE
         and approval['authorized_operation'] == 'launch-unchanged-fixed-check-with-retained-path', 'root launch approval differs')
    need(launch['returncode'] == 0 and launch['source_freeze_sha256'] == SOURCE
         and launch['approval_sha256'] == approval_sha, 'launch did not return a bound success receipt')
    local_request = ENVIRONMENT / 'launch-attempt02/request.json'
    request_path = path(HISTORY + 'request.json')
    need(sha(local_request) == sha(request_path) == launch['request_sha256'], 'local/remote launch request differs')
    protected[local_request] = launch['request_sha256']
    request = read(request_path)
    matching_request(request, capture, approval_sha)
    for suffix in ('stdout', 'stderr'):
        value = ENVIRONMENT / 'launch-attempt02' / suffix
        need(sha(value) == launch[suffix + '_sha256'], 'local launch stream differs')
        protected[value] = sha(value)
    remote_launch = json.loads((ENVIRONMENT / 'launch-attempt02/stdout').read_text())
    need(remote_launch == launch['remote'] and remote_launch['launched'] is True
         and remote_launch['session'] == 'ohm-sbom179-ir-completion-02'
         and remote_launch['request_sha256'] == sha(request_path)
         and remote_launch['history'] == REMOTE + '/' + HISTORY.rstrip('/'), 'remote launch receipt differs')
    need((remote_launch['fixed_check_pairs'], remote_launch['warmup_pairs'], remote_launch['seed'], remote_launch['test_samples_to_rerun'])
         == (12, 2, 20261021102, 0), 'fixed continuation plan differs')
    original_command = read(ENVIRONMENT / 'reference/launch-receipt.json')['remote']['command']
    expected_command = list(original_command)
    expected_command[0] = '/usr/bin/env'
    expected_command.insert(8, 'PATH=' + request['retained_inherited_build_environment']['PATH'])
    need(remote_launch['command'] == expected_command, 'launch changed more than the captured PATH')
    expected_history = {'request.json', 'launch_remote.py', 'amendment.md', 'before.json', 'seal.json',
                        'failed-attempt01.controller.stdout', 'failed-attempt01.controller.stderr'}
    need({name[len(HISTORY):] for name in files if name.startswith(HISTORY)} == expected_history,
         'environment history member set differs')
    seal_path = path(HISTORY + 'seal.json')
    need(sha(seal_path) == remote_launch['history_seal_sha256'], 'history seal differs from launch')
    seal = read(seal_path)
    need(set(seal) == expected_history - {'seal.json'}, 'history seal incomplete')
    for name, digest in seal.items():
        need(sha(path(HISTORY + name)) == digest, 'history sealed byte differs')
    for name in ('launch_remote.py', 'amendment.md'):
        value = path(HISTORY + name)
        need(value.read_text() == request['source_text'][name]
             and sha(value) == request['source_sha256'][name] == sha(ENVIRONMENT / name), 'launch source lineage differs')
    before = read(path(HISTORY + 'before.json'))
    need(before['source_freeze_sha256'] == SOURCE and before['capture_sha256'] == CAPTURE
         and before['root_approval_sha256'] == approval_sha and before['request_sha256'] == sha(request_path)
         and before['capsule_manifest_sha256'] == CAPSULE
         and before['protected_originals'] == capture['protected_original_files']
         and before['untouched_check_fixture'] == capture['untouched_check_fixture']
         and before['environment_changes'] == request['retained_inherited_build_environment']
         and before['original_controller_and_sample_analysis_code_unchanged'] is True,
         'prelaunch preservation/environment proof differs')
    mutable = {'fixtures/check-ir-confirmation/state.json', 'fixtures/check-ir-confirmation/journal.jsonl'}
    for name, row in capture['protected_original_files'].items():
        if name not in mutable:
            need(files.get(name) == row, 'previous observation/control changed: ' + name)
    for name, row in capture['capsule_files'].items():
        need(files.get('continuations/ir-check-01/' + name) == row, 'original capsule changed')
    for suffix in ('stdout', 'stderr'):
        digest = request['failed_controller_log_sha256'][suffix]
        need(sha(path('logs/ir-completion-01.controller.' + suffix))
             == sha(path(HISTORY + 'failed-attempt01.controller.' + suffix)) == digest, 'failed attempt01 log changed')
        need(remote_launch[suffix] == REMOTE + '/logs/ir-completion-02.controller.' + suffix, 'attempt02 log binding differs')
    need(sha(path('logs/ir-completion-02.controller.stderr')) == EMPTY, 'attempt02 controller stderr is nonempty')
    stdout = path('logs/ir-completion-02.controller.stdout').read_text()
    need('starting check-ir-confirmation: 12 pairs, 2 warmup pairs' in stdout
         and 'check-ir-confirmation complete and source/compiler work verified; effects still uninspected' in stdout,
         'attempt02 controller did not complete the fixed check boundary')
    test_path = path('results/test-ir-confirmation/manifest.json')
    check_path = path('results/ir-completion-01/check/manifest.json')
    test, check = read(test_path), read(check_path)
    need(sha(test_path) == capture['retained_test_manifest']['sha256']
         and test['inherited_build_environment'] == check['inherited_build_environment']
             == request['retained_inherited_build_environment'], 'actual check/test inherited environment differs')
    need(check['state'] == 'complete' and check['sample_count'] == 28
         and (check['pairs'], check['warmup_pairs'], check['seed']) == (12, 2, 20261021102),
         'completed check metadata differs')
    state = read(path('results/ir-completion-01/status.json'))
    need(state['state'] == 'complete' and state['completed_workloads'] == ['test', 'check']
         and state['source_restored'] is True and state['capsule_manifest_sha256'] == CAPSULE,
         'continued terminal state differs')
    need(datetime.fromisoformat(capture['captured_at']) <= datetime.fromisoformat(before['verified_at'])
         <= datetime.fromisoformat(check['started_at']) < datetime.fromisoformat(check['finished_at']),
         'capture/launch/workflow chronology differs')
    need(all(sha(value) == digest for value, digest in protected.items()), 'lineage changed during review')
    output = args.output.absolute()
    need(output.resolve() == output and not output.exists(), 'lineage output must be new')
    result = {'status': 'passed', 'reviewed_at': datetime.now(timezone.utc).isoformat(),
        'source_freeze_sha256': args.source_freeze_sha256, 'environment_source_freeze_sha256': SOURCE,
        'capture_sha256': CAPTURE, 'collection_receipt_sha256': args.collection_receipt_sha256,
        'transfer_manifest_sha256': sha(manifest_path), 'launch_receipt_sha256': sha(launch_path),
        'root_launch_approval_sha256': approval_sha, 'remote_history_seal_sha256': sha(seal_path),
        'original_capsule_unchanged': True, 'original_test_observations_unchanged': 28,
        'new_fixed_check_observations': 28, 'actual_check_test_inherited_environment_equal': True,
        'only_launch_path_setting_changed': True, 'effects_inspected': False,
        'original_raw_and_statistics_reviewer_still_required': True,
        'final_rehash': 'passed', 'bound_files': {str(value): digest for value, digest in sorted(protected.items())}}
    with output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps({'status': result['status'], 'review_sha256': sha(output), 'effects_inspected': False}))


if __name__ == '__main__':
    main()
