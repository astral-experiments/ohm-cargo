"""Synthetic request-join rejection tests; no real reviews or effects."""
import ast
import copy
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sbom_environment_lineage', HERE / 'review.py')
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


class LineageTests(unittest.TestCase):
    def fixture(self):
        capture = {'retained_test_manifest': {'sha256': 'manifest'},
            'retained_test_inherited_build_environment': {'PATH': '/retained'},
            'logs': {'ir-completion-01.controller.stdout': {'sha256': 'empty'},
                     'ir-completion-01.controller.stderr': {'sha256': 'failed'}}}
        request = {'operation': 'launch-unchanged-fixed-check-with-retained-path',
            'source_freeze_sha256': review.SOURCE, 'capture_sha256': review.CAPTURE,
            'capsule_manifest_sha256': review.CAPSULE, 'root_approval_sha256': 'approval',
            'retained_test_manifest_sha256': 'manifest', 'retained_inherited_build_environment': {'PATH': '/retained'},
            'failed_controller_log_sha256': {'stdout': 'empty', 'stderr': 'failed'}}
        return request, capture

    def test_exact_join_is_accepted_without_effects(self):
        request, capture = self.fixture()
        review.matching_request(request, capture, 'approval')

    def test_every_direct_identity_join_is_required(self):
        original, capture = self.fixture()
        for key in ('operation', 'source_freeze_sha256', 'capture_sha256', 'capsule_manifest_sha256',
                    'root_approval_sha256', 'retained_test_manifest_sha256'):
            with self.subTest(key=key):
                request = copy.deepcopy(original); request[key] = 'different'
                with self.assertRaises(ValueError): review.matching_request(request, capture, 'approval')

    def test_environment_value_mismatch_is_rejected(self):
        request, capture = self.fixture(); request['retained_inherited_build_environment']['PATH'] = '/different'
        with self.assertRaises(ValueError): review.matching_request(request, capture, 'approval')

    def test_an_extra_setting_is_rejected_even_if_both_records_agree(self):
        request, capture = self.fixture()
        request['retained_inherited_build_environment']['RUSTFLAGS'] = '-Zunexpected'
        capture['retained_test_inherited_build_environment']['RUSTFLAGS'] = '-Zunexpected'
        with self.assertRaises(ValueError): review.matching_request(request, capture, 'approval')

    def test_both_failed_logs_are_required(self):
        for suffix in ('stdout', 'stderr'):
            request, capture = self.fixture(); request['failed_controller_log_sha256'][suffix] = 'different'
            with self.assertRaises(ValueError): review.matching_request(request, capture, 'approval')

    def test_safe_relative_names(self):
        self.assertEqual(str(review.relative('continuations/a/request.json')), 'continuations/a/request.json')
        for name in ('', '.', '/tmp/x', '../x', 'a/../b', 'a//b', 'a\\b'):
            with self.subTest(name=name), self.assertRaises(ValueError): review.relative(name)

    def test_source_has_no_host_workload_or_statistics_imports(self):
        tree = ast.parse((HERE / 'review.py').read_text())
        imports = {alias.name for node in tree.body if isinstance(node, ast.Import) for alias in node.names}
        self.assertFalse(imports & {'subprocess', 'statistics', 'random', 'socket', 'requests'})
        self.assertFalse(any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                             and node.func.id in {'exec', 'eval'} for node in ast.walk(tree)))

    def test_original_reviewer_is_not_modified_or_invoked(self):
        source = (HERE / 'review.py').read_text()
        tree = ast.parse(source)
        names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
        self.assertNotIn('statistics_review', names)
        self.assertNotIn('analysis.json', source)
        self.assertNotIn('effects.json', source)
        self.assertIn("'original_raw_and_statistics_reviewer_still_required': True", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
