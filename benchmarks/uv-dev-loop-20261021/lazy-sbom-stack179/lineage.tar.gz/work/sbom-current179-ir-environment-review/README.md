This is a separate local pre-effect lineage check for the source-frozen PATH-only
SBOM continuation launch. It does not alter or invoke the original raw/statistical
reviewer. It performs no host access, workload, resampling or effect calculation.

Run only after the fixed continuation is terminal and the original reviewed
collector has produced its complete archive/receipt. Root must first accept this
source and the concrete terminal collection identity:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-ir-environment-review/review.py \
  --controls /ABS/work/sbom-current179-ir-continuation \
  --launch-approval /ABS/ROOT_LAUNCH_APPROVAL.json \
  --collection-receipt-sha256 REVIEWED_TERMINAL_RECEIPT_SHA \
  --source-freeze-sha256 THIS_REVIEWER_FREEZE_SHA \
  --output /ABS/NEW_ENVIRONMENT_LINEAGE_REVIEW.json
```

The check binds the 26-file launcher freeze and prior read-only boundary to the
exact root approval, new local/remote launch request and streams, seven-file remote
history seal, preserved failed logs and unchanged original capsule. It verifies
all original transfer rows except the two intended check-fixture mutable files,
the actual completed check/test inherited environments, fixed check metadata and
chronology, then rehashes every accessed input. It does not open analysis.json or
effects.json. The terminal status JSON is read only for completion/identity fields;
its embedded performance statistics are never accessed.

A passing output establishes only this operational lineage. Root must require
and bind it before authorizing the unchanged independent reviewer, which still
checks every raw byte/plan/compiler call and both workflows before recomputing
the original gates. This check cannot qualify a candidate or authorize native.
