The staged IR continuation and its capsule remain unchanged. This prospective,
native-only wrapper closes a required-membership gap in the original native
entrypoint: every approval, independent review seal and its three payloads,
transfer manifest, collection receipt, and this wrapper must belong to the exact
hash/mode/size-bound prerequisite index before the original entrypoint executes.

The wrapper goes in the future owned `continuations/native-prerequisite-01`
directory. Its immutable source must be indexed by that prerequisite manifest,
and the separately reviewed root approval must name `strict_native_entry_sha256`.
The launcher must invoke this wrapper with the exact separately approved
prerequisite-manifest hash. Every original native acceptance check and the
original native controller then executes unchanged from the original IR capsule.

This package authorizes no host action, prerequisite construction, measurement,
analysis, or native launch. A later prerequisite producer/launcher still requires
source review and accepted independent IR evidence. No staged file, fixed IR
sample plan, statistical gate, or earlier receipt is modified.
