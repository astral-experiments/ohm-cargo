"""Pure validation of required prerequisite membership; no host or workload."""
import ast
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent))
import strict_native_entry as guard


class GuardTests(unittest.TestCase):
    def test_complete_required_index(self):
        guard.required_payloads(dict.fromkeys(guard.REQUIRED_FILES, {}))

    def test_each_required_payload_missing_rejects(self):
        for name in guard.REQUIRED_FILES:
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'omits'):
                guard.required_payloads(dict.fromkeys(guard.REQUIRED_FILES - {name}, {}))

    def test_additional_bound_payloads_allowed(self):
        guard.required_payloads(dict.fromkeys(guard.REQUIRED_FILES | {'review/source-freeze.json'}, {}))

    def test_nonobject_index_rejects(self):
        for value in (None, [], list(guard.REQUIRED_FILES), ''):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, 'not an object'):
                guard.required_payloads(value)

    def test_original_entry_is_invoked_only_after_membership_and_hash_checks(self):
        source = Path(guard.__file__).read_text()
        main = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        membership = next(n.lineno for n in ast.walk(main) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'required_payloads')
        record = next(n.lineno for n in ast.walk(main) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'record')
        execute = next(n.lineno for n in ast.walk(main) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'execv')
        self.assertLess(membership, record)
        self.assertLess(record, execute)
        self.assertEqual(source.count('os.execv('), 1)
        self.assertNotIn('subprocess.', source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
