#!/usr/bin/env python3
"""Independent source/pure-test admission review; never inspect native outcomes."""
import ast
import base64
import contextlib
import datetime
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[1]
ROOT = WORK / 'sbom-current179-native-admission-review-v2'
OLD = WORK / 'sbom-current179-native-admission-review'
RECOVERY = WORK / 'sbom-current179-native-admission-recovery'
LAUNCH = WORK / 'sbom-current179-native-launch-controls-alias-v2'
REPLAY = WORK / 'sbom-current179-native-launch-replay02'
RAW = WORK / 'sbom-current179-ir-reviewer-profiler-alias-v2'
FREEZE = '1782c13172607d9dbd50baab7cb56e17a0ec668a138530a60e8b1298643e43ba'
IR = '242bc12bdd883f25a56baf59f5e6a16666e8f8f8b7d5819dbcaa21ad8e907d17'
APPROVAL = '9522fac4b0dd275e7ae50b33e03597c48975fbe77f66916370ce395c51f1b20b'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    info = path.lstat()
    assert path.resolve() == path and stat.S_ISREG(info.st_mode)
    return {'sha256': sha(path), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode),
            'mtime_ns': info.st_mtime_ns, 'inode': info.st_ino, 'links': info.st_nlink}


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


assert os.sched_getaffinity(0) == {8}
assert sha(ROOT / 'source-freeze.json') == FREEZE
roles = [(ROOT, 'lineage-v2', 'external_inputs', (10, 16)),
         (OLD, 'lineage-v1', 'external_inputs', (8, 14)),
         (RECOVERY, 'recovery', 'external_files', (12, 139)),
         (LAUNCH, 'launch', 'external_files', (40, 352)),
         (RAW, 'raw-reviewer', None, (75, 0))]
protected = {}
schema_counts = {}
for directory, role, external_field, counts in roles:
    freeze = read(directory / 'source-freeze.json')
    internal, external = freeze['files'], freeze[external_field] if external_field else {}
    assert (len(internal), len(external)) == counts
    schema_counts[role] = {'internal': len(internal), 'external': len(external),
                           'external_field': external_field, 'source_freeze_sha256': sha(directory / 'source-freeze.json')}
    protected[str(directory / 'source-freeze.json')] = identity(directory / 'source-freeze.json')
    for entries in ({str(directory / name): row for name, row in internal.items()}, external):
        for name, row in entries.items():
            actual = identity(Path(name))
            assert all(actual[key] == expected for key, expected in row.items()), name
            assert name not in protected or protected[name] == actual
            protected[name] = actual
inventory = read(ROOT / 'predecessor-inventory.json')
assert inventory['directory'] == str(OLD) and len(inventory['files']) == 9
for name, row in inventory['files'].items():
    assert all(protected[str(OLD / name)][key] == value for key, value in row.items())

# Read only already-retained launch/admission metadata, never native samples,
# terminal collection or native effects. Actual collection remains held elsewhere.
for name in ['root-launch-approval.json', 'launch-execution.json',
             'launch-attempt01/before.json', 'launch-attempt01/request.json',
             'launch-attempt01/receipt.json', 'launch-attempt01/seal.json',
             'launch-attempt01/stdout', 'launch-attempt01/stderr', 'stage-attempt01/receipt.json']:
    protected[str(REPLAY / name)] = identity(REPLAY / name)
write('protected-inputs-before.json', protected)
approval = read(REPLAY / 'root-launch-approval.json')
assert sha(REPLAY / 'root-launch-approval.json') == APPROVAL
request = read(REPLAY / 'launch-attempt01/request.json')
before = read(REPLAY / 'launch-attempt01/before.json')
receipt = read(REPLAY / 'launch-attempt01/receipt.json')
remote = receipt['remote']['receipt']
execution = read(REPLAY / 'launch-execution.json')
request_sha = sha(REPLAY / 'launch-attempt01/request.json')
for row in (request, before, receipt, remote, execution):
    assert row['approval_sha256'] == APPROVAL
for row in (before, receipt, remote):
    assert row['request_sha256'] == request_sha
assert base64.b64decode(request['approval_base64'], validate=True) == (REPLAY / 'root-launch-approval.json').read_bytes()
assert receipt['returncode'] == 0 and receipt['transport_exception'] is None and receipt['remote_success_validated'] is True
assert remote['launched'] is True and approval['valid'] is True
assert approval['authorized_operation'] == 'launch-fixed-native-prerequisites'
assert read(REPLAY / 'launch-attempt01/stdout') == receipt['remote']
for suffix in ('stdout', 'stderr'):
    assert receipt[suffix + '_sha256'] == sha(REPLAY / 'launch-attempt01' / suffix)
for name, digest in read(REPLAY / 'launch-attempt01/seal.json').items():
    assert sha(REPLAY / 'launch-attempt01' / name) == digest
for field, path in [('recovery_receipt_sha256', RECOVERY / 'retention-attempt01/remote-receipt.json'),
                    ('recovery_review_sha256', RECOVERY / 'root-retention-review.json'),
                    ('recovery_source_freeze_sha256', RECOVERY / 'source-freeze.json'),
                    ('replay_copy_receipt_sha256', RECOVERY / 'replay-copy-receipt.json'),
                    ('stage_receipt_sha256', REPLAY / 'stage-attempt01/receipt.json')]:
    assert approval[field] == sha(path), field
stage = read(REPLAY / 'stage-attempt01/receipt.json')
assert approval['remote_stage_receipt_sha256'] == stage['remote']['remote_receipt_sha256']
manifest = read(REPLAY / 'prepared/manifest.json')
assert approval['prerequisite_manifest_sha256'] == sha(REPLAY / 'prepared/manifest.json')
assert manifest['files']['review/review.json']['sha256'] == IR
assert sha(WORK / 'sbom-current179-ir-continuation/independent-ir-review-profiler-alias-v2/review.json') == IR
assert approval['expected_controller_command'] == remote['command']

# Prove the narrow validator delta independently of its prose description.
old_tree = ast.parse((OLD / 'review_recovery.py').read_text())
new_tree = ast.parse((ROOT / 'review_recovery.py').read_text())
old_functions = {node.name: node for node in old_tree.body if isinstance(node, ast.FunctionDef)}
new_functions = {node.name: node for node in new_tree.body if isinstance(node, ast.FunctionDef)}
assert set(new_functions) - set(old_functions) == {'is_sha256', 'validate_freeze_schema'}
modified = {'verify_freeze', 'copy_and_launch', 'main'}
for name in set(old_functions) - modified:
    assert ast.dump(old_functions[name], include_attributes=False) == ast.dump(new_functions[name], include_attributes=False), name
copy_node = new_functions['copy_and_launch']
copy_node.body = [node for node in copy_node.body if not (isinstance(node, ast.Expr)
    and isinstance(node.value, ast.Call) and any(isinstance(value, ast.Constant)
        and value.value == 'actual accepted IR review differs from the explicit binding' for value in node.value.args))]
assert ast.dump(copy_node, include_attributes=False) == ast.dump(old_functions['copy_and_launch'], include_attributes=False)
main_node = new_functions['main']
main_node.body = [node for node in main_node.body if not (isinstance(node, ast.Expr)
    and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
    and node.value.func.id == 'verify_freeze' and len(node.value.args) == 3
    and isinstance(node.value.args[1], ast.Name) and node.value.args[1].id == 'PREDECESSOR')]
assert ast.dump(main_node, include_attributes=False) == ast.dump(old_functions['main'], include_attributes=False)

# Replay the exact 22-case runner with only its three output destinations
# redirected in memory. Keep __file__/HERE unchanged for every source/input join.
scratch = OUT / 'synthetic-temporary'
scratch.mkdir()
tempfile.tempdir = str(scratch)
process_events = []
def source_only(event, args):
    if event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.posix_spawn')) or event in ('os.system', 'pty.spawn'):
        process_events.append(event)
        raise RuntimeError('Source-only review forbids process/network: ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        mode, flags = args[1], args[2]
        writes = isinstance(mode, str) and any(char in mode for char in 'wax+')
        writes = writes or isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)
        if writes and not Path(args[0]).resolve().is_relative_to(OUT):
            raise RuntimeError('Frozen source write blocked: ' + str(args[0]))
sys.addaudithook(source_only)
runner = ast.parse((ROOT / 'run_pure_checks.py').read_text())
changes = 0
for node in ast.walk(runner):
    if isinstance(node, ast.With):
        for item in node.items:
            call = item.context_expr
            if (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                and call.func.attr == 'open' and isinstance(call.func.value, ast.BinOp)
                and isinstance(call.func.value.left, ast.Name) and call.func.value.left.id == 'HERE'
                and isinstance(call.func.value.right, ast.Name) and call.func.value.right.id == 'name'):
                call.func.value.left = ast.Name(id='__replay_output__', ctx=ast.Load())
                changes += 1
assert changes == 1
ast.fix_missing_locations(runner)
captured = io.StringIO()
namespace = {'__name__': '__main__', '__file__': str(ROOT / 'run_pure_checks.py'), '__replay_output__': OUT}
with contextlib.redirect_stdout(captured):
    try:
        exec(compile(runner, str(ROOT / 'run_pure_checks.py'), 'exec'), namespace)
    except SystemExit as exit_result:
        assert exit_result.code == 0
assert not process_events
replayed = read(OUT / 'pure-checks.json')
original = read(ROOT / 'pure-checks.json')
assert replayed['passed'] and replayed['tests'] == 22 and replayed['errors'] == replayed['failures'] == 0
assert {key: value for key, value in replayed.items() if key != 'checked_at'} == {
    key: value for key, value in original.items() if key != 'checked_at'}
write('pure-replay-adaptation.json', {'source_sha256': sha(ROOT / 'run_pure_checks.py'),
    'in_memory_changes': 'One output-loop path expression: HERE/name -> independent __replay_output__/name.',
    'inputs_and_tests_unchanged': True, 'process_or_network_events': process_events})
after = {name: identity(Path(name)) for name in protected}
assert after == protected
write('protected-inputs-after.json', after)
report = {'status': 'passed', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Independent source/hash/schema/retained-admission review and pure tests only; no hosts, collection, real native review or effects.',
    'source_freeze_sha256': FREEZE, 'validator_sha256': sha(ROOT / 'review_recovery.py'),
    'accepted_ir_review_sha256': IR, 'actual_replay_launch_approval_sha256': APPROVAL,
    'source_schema_counts': schema_counts, 'protected_unique_files': len(protected),
    'all_protected_bytes_modes_mtimes_inodes_unchanged': True,
    'pure_tests_replayed': 22, 'pure_test_failures': 0, 'pure_test_errors': 0,
    'checks': {'complete_exact_external_map_coverage_no_silent_omission': True,
        'all_nine_v1_files_preserved': True, 'full_ir_hash_matches_local_and_prepared_manifest': True,
        'actual_replay_approval_request_before_receipt_stream_copy_recovery_and_stage_joins': True,
        'only_schema_ir_join_and_predecessor_runtime_changes': True,
        'both_terminal_fixed_30_pair_single_call_workflows_required_before_lineage_report': True,
        'original_collector_raw_statistics_and_effect_boundary_unchanged': True,
        'no_execution_hook_and_new_owned_output_guard_present': True},
    'findings': [],
    'limits': ['This is a source review, not a completed-native lineage/raw/statistical pass.',
        'Actual future collection/entry/phase chronology and every native sample still require terminal collection and the original raw reviewer.',
        'The original raw reviewer does not enforce the extra lineage-acceptance field; root must separately bind and accept the lineage proof before invoking it, as documented.']}
write('review.json', report)
write('seal.json', {'status': 'passed', 'source_freeze_sha256': FREEZE,
    'files': {str(path.relative_to(OUT)): sha(path) for path in sorted(OUT.iterdir()) if path.is_file()}})
print(json.dumps({'status': 'passed', 'review_sha256': sha(OUT / 'review.json'),
    'seal_sha256': sha(OUT / 'seal.json'), 'protected_files': len(protected), 'pure_tests': 22}, indent=2))
