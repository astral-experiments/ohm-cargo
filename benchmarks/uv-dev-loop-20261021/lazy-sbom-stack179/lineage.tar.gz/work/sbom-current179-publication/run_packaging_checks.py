#!/usr/bin/env python3
"""Run only synthetic packaging checks, prohibiting process and host operations."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prohibit(event, arguments):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'socket.connect'}:
        raise AssertionError('Pure packaging checks cannot execute processes or connect to hosts')


def main():
    sys.addaudithook(prohibit)
    assert sorted(os.sched_getaffinity(0)) == [8]
    names = ('assemble_evidence.py', 'prepare_evidence_inputs.py', 'snapshot_evidence_inputs.py',
             'test_assemble_evidence.py', 'run_packaging_checks.py')
    before = {name: sha(HERE / name) for name in names}
    for name in names:
        tree = ast.parse((HERE / name).read_text())
        assert not any(isinstance(node, (ast.Import, ast.ImportFrom)) and
                       any(alias.name.split('.')[0] in {'subprocess', 'socket', 'statistics', 'random'} for alias in node.names)
                       for node in ast.walk(tree)), name
    sys.path.insert(0, str(HERE))
    spec = importlib.util.spec_from_file_location('synthetic_sbom_package_tests', HERE / 'test_assemble_evidence.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    with (HERE / 'pure-checks.txt').open('x') as stream:
        stream.write(output.getvalue())
    assert before == {name: sha(HERE / name) for name in names}
    record = {'valid': result.wasSuccessful(), 'tests': result.testsRun, 'failures': len(result.failures),
              'errors': len(result.errors), 'checked_at': datetime.now(timezone.utc).isoformat(),
              'source_sha256': before, 'real_package_or_input_preparation_executed': False,
              'host_or_workload_calls_prohibited': True, 'real_effects_recomputed': False}
    with (HERE / 'pure-checks.json').open('x') as stream:
        json.dump(record, stream, indent=2); stream.write('\n')
    print(json.dumps(record, indent=2))
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
