This is source-only publication preparation. Native validation is pending. Neither helper may run on real inputs until both fixed native workflows are terminal, both independent raw audits pass, root accepts that exact review, and neither workflow establishes a native regression. No helper publishes, starts a process, contacts a host or recomputes statistics.

The draft is `PR.md`. `existing-inputs.json` is an immutable index of the current source, accepted IR, retained original archives and local failure/source lineage. Historical PR175 archives have a separate namespace and cannot satisfy any current179 gate. Original archives are copied exactly; any archive exceeding 90 MB is split losslessly into ordered byte chunks, with its original hash retained. No profiles are omitted to meet the Git blob limit.

After terminal native acceptance, root supplies a `reviewed-complete` native lineage inventory. It must bind every local native control, preparation, stage, launch, collection, review and failed-attempt record, with SHA256, size and mode. It must include `phase: native-confirmation`, the exact `review_sha256`, `native_acceptance_sha256`, `all_native_attempts_retained: true`, and coverage entries `source_controls`, `preparation`, `stage`, `launch`, `collection`, `review`, `failed_admission`. The known first native admission's failed status, SHA `653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2`, must appear in that final inventory. Its original capture and occupancy/log/history bytes are already indexed under `work/sbom-current179-native-failed-launch01`; any recovery must add its reviewed source and complete receipts without replacing those inputs.

The native acceptance uses `valid: true`, `authorized_operation: accept-current179-native-review-for-publication`, exact `accepted_native_review_sha256`, `accepted_ir_review_sha256`, `native_transfer_manifest_sha256`, `candidate_commit`, `candidate_tree`, plus `both_native_raw_audits_passed: true` and `no_established_native_regression: true`. These declarations accompany the actual sealed reviews and full capture; they do not replace their verification.

Prepare the final inputs only after those conditions, using workspace-relative paths:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-publication/prepare_evidence_inputs.py \
  --source-freeze-sha256 REVIEWED_PACKAGING_FREEZE \
  --native-controls work/sbom-current179-ir-continuation \
  --native-review ACCEPTED_NATIVE_REVIEW_DIRECTORY \
  --native-review-sha256 ACCEPTED_NATIVE_REVIEW_SHA \
  --native-acceptance ROOT_NATIVE_ACCEPTANCE_PATH \
  --native-acceptance-sha256 ROOT_NATIVE_ACCEPTANCE_SHA \
  --native-lineage-inventory REVIEWED_NATIVE_LINEAGE_INDEX \
  --native-lineage-inventory-sha256 REVIEWED_NATIVE_LINEAGE_INDEX_SHA
```

Independently review the newly created `final-inputs/inputs.json` before assembly:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-publication/assemble_evidence.py \
  --inputs work/sbom-current179-publication/final-inputs/inputs.json \
  --inputs-sha256 REVIEWED_FINAL_INPUT_SHA
```

The initially absent output is `work/pr-evidence/lazy-sbom-stack179`, with an adjacent file manifest suitable for the existing private evidence publisher. Final assembly validates both complete captured file sets and original archive members, all accepted review seals, fixed counts/seeds and raw-table joins, unchanged IR bytes through native validation, exact source/CI and matched production identities. It creates final native text from the accepted summaries without recalculating statistics. It rehashes every copied input and checks its lossless archives before sealing the output. Failed assembly outputs remain present for diagnosis.

Root must review the completed package, update the local PR draft's native paragraph and immutable evidence link, then perform any publication. These helpers have no Git, network or PR operations. The archived build executables/runtime payloads are not duplicated; their hashes, full build/strip records and reproducible source inputs are retained.
