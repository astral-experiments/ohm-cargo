#!/usr/bin/env python3
"""Retain complete old-cohort baseline preflight evidence outside measurements."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
remote = r'''
import hashlib,io,json,sys,tarfile
from pathlib import Path
r=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
assert json.loads((r/'diagnostics/baseline-seed-02/manifest.json').read_text())['state']=='complete'
names=['setup.json','configs-prepared.json','baseline-seed.log','baseline-seed-02.log','stage-assets.json','stage-update-assets.json']
directories=['diagnostics/baseline-seed-01','diagnostics/baseline-seed-02','setup-history','work/benchmark','configs','build','fixtures/test-diagnostic','fixtures/check-diagnostic']
for directory in directories:
 names += [str(p.relative_to(r)) for p in sorted((r/directory).rglob('*')) if p.is_file()]
names += [str(p.relative_to(r)) for p in sorted((r/'logs').glob('helper-tests*'))]
names += [str(p.relative_to(r)) for p in sorted((r/'metadata').glob('*')) if p.is_file()]
names=sorted(set(names));rows=[]
for n in names:
 p=r/n;assert p.is_file() and not p.is_symlink()
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 rows.append({'path':n,'bytes':p.stat().st_size,'sha256':digest})
out=r/'evidence';out.mkdir(exist_ok=True);archive=out/'old-baseline-preflight.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for n in names:t.add(r/n,arcname=n,recursive=False)
 seal=json.dumps(rows,indent=2).encode()+b'\n';item=tarfile.TarInfo('SEAL.json');item.size=len(seal);item.mode=0o644;t.addfile(item,io.BytesIO(seal))
with archive.open('rb') as f:archive_sha=hashlib.file_digest(f,'sha256').hexdigest()
manifest=out/'old-baseline-preflight.manifest.json';manifest.write_text(json.dumps({'role':'Untimed old-cohort prerequisite seeding and execution diagnostics only; no comparative samples','archive_sha256':archive_sha,'archive_bytes':archive.stat().st_size,'files':rows},indent=2)+'\n')
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as t:
 for p in (archive,manifest):t.add(p,arcname=p.name,recursive=False)
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', 'python3', '-c', remote], capture_output=True)
if result.returncode:
    print(result.stderr.decode()); raise SystemExit(result.returncode)
output = HERE / 'evidence'; output.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(result.stdout), mode='r:') as archive:
    for item in archive:
        assert item.isfile() and item.name in ('old-baseline-preflight.tar.gz', 'old-baseline-preflight.manifest.json')
        data = archive.extractfile(item).read(); target = output / item.name
        assert not target.exists(); target.write_bytes(data)
manifest = json.loads((output / 'old-baseline-preflight.manifest.json').read_text())
assert hashlib.sha256((output / 'old-baseline-preflight.tar.gz').read_bytes()).hexdigest() == manifest['archive_sha256']
expected = {row['path']: row for row in manifest['files']}
with tarfile.open(output / 'old-baseline-preflight.tar.gz', mode='r:gz') as archive:
    actual = {}
    for item in archive:
        assert item.isfile()
        data = archive.extractfile(item).read()
        if item.name == 'SEAL.json':
            assert json.loads(data) == manifest['files']; continue
        assert item.name in expected and item.name not in actual
        assert hashlib.sha256(data).hexdigest() == expected[item.name]['sha256']
        actual[item.name] = len(data)
        if item.name.endswith('/manifest.json') and item.name.startswith('diagnostics/'):
            (output / (Path(item.name).parent.name + '.json')).write_bytes(data)
    assert set(actual) == set(expected)
print(json.dumps({'archive': str(output / 'old-baseline-preflight.tar.gz'), 'sha256': manifest['archive_sha256'], 'bytes': manifest['archive_bytes'], 'verified_files': len(expected)}, indent=2))
