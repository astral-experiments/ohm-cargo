#!/usr/bin/env python3
"""Stage the complete audited host2 cohort; do not run workloads."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
BUILD = WORKSPACE / 'work/production-build/host2'
RESULTS = BUILD / 'results'
REMOTE = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
HELPER = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


audit = json.loads((RESULTS / 'audit-pair.json').read_text())
assert audit['cohort'] == 'host2-pr175-sbom'
assert {row['variant'] for row in audit['records']} == {'pr175', 'pr175-lazy-sbom'}
files = {}
for row in audit['records']:
    variant = row['variant']
    name = 'cargo-' + variant
    assert sha(RESULTS / name) == row['stripped_sha256']
    files['binaries/' + name + '-host2'] = RESULTS / name
    for suffix in ('.build.json', '.strip.json'):
        files['build/host2/' + name + suffix] = RESULTS / (name + suffix)
    for suffix in ('.source.patch', '.occupancy.json', '.stdout', '.stderr', '.batch-status.json'):
        files['build/host2/' + variant + suffix] = RESULTS / (variant + suffix)
for name in ('provenance.json', 'audit-pair.json'):
    files['build/host2/' + name] = RESULTS / name
for name in ('build_driver_host2_pr175_sbom.py', 'strip_binaries.py', 'manifest.json', 'pr175.patch', 'lazy-sbom.patch'):
    files['build/host2/' + name] = BUILD / 'frozen' / name
for name in ('freeze_cohort.py', 'finalize_configs.py'):
    files['work/benchmark/' + name] = HERE / 'frozen' / name
manifest = {
    'created_at': datetime.now(timezone.utc).isoformat(),
    'cohort': 'host2-pr175-sbom', 'audit_pair_sha256': sha(RESULTS / 'audit-pair.json'),
    'asset_sha256': {str(REMOTE / name): sha(path) for name, path in files.items()},
}
manifest_path = HERE / 'host2-transfer.json'
with manifest_path.open('x') as stream:
    stream.write(json.dumps(manifest, indent=2) + '\n')
files['metadata/host2-transfer.json'] = manifest_path
code = r'''
import hashlib,json,pathlib,sys,tarfile
root=pathlib.Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
assert not (root/'build/host2').exists()
assert not (root/'metadata/frozen-cohort.json').exists()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|') as archive:
 for item in archive:
  relative=pathlib.Path(item.name)
  assert item.isfile() and not relative.is_absolute() and '..' not in relative.parts
  assert relative.parts[:2] in [('build','host2'),('work','benchmark')] or relative.parts[0] in ['binaries','metadata']
  path=root/relative
  assert not path.exists() and not path.is_symlink(),path
  path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as stream:stream.write(archive.extractfile(item).read())
  path.chmod(item.mode&0o777)
manifest=json.loads((root/'metadata/host2-transfer.json').read_text())
for filename,expected in manifest['asset_sha256'].items():
 with pathlib.Path(filename).open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,filename
print(json.dumps({'staged_files':len(manifest['asset_sha256']),'cohort':manifest['cohort'],'no_cargo_or_workload_executed':True}))
'''
process = subprocess.Popen([HELPER, 'charlie-oss-4', '--', 'python3', '-c', code], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
process.stdin = None
stdout, stderr = process.communicate(timeout=120)
(HERE / 'stage-host2.stdout').write_bytes(stdout)
(HERE / 'stage-host2.stderr').write_bytes(stderr)
print(stdout.decode()); print(stderr.decode())
raise SystemExit(process.returncode)
