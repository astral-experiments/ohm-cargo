#!/usr/bin/env python3
"""Seal and copy a completed dirty-SBOM phase, including its raw evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
SSH = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
REMOTE_ROOT = '/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty'
HOST = 'charlie-oss-4'
REMOTE = r'''
from pathlib import Path
import hashlib,json,os,sys,tarfile,datetime
root=Path(sys.argv[1]); phase=sys.argv[2]
assert root==Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
assert root.resolve()==root and root.stat().st_uid==os.getuid()==1000
assert phase in ('ir-exploratory','ir-confirmation','native-confirmation')
state=json.loads((root/'results'/(phase+'.json')).read_text())
assert state['state']=='complete',state['state']
assert state['completed_workloads']==['test','check']
exports=root/'exports'; exports.mkdir(exist_ok=True)
archive=exports/(phase+'.tar.gz'); manifest_path=exports/(phase+'.manifest.json'); proof_path=exports/(phase+'.archive.json')
assert not archive.exists() and not manifest_path.exists() and not proof_path.exists()
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=[]
for directory in ['configs','metadata','logs','diagnostics','fixtures','build','work/benchmark']:
 path=root/directory
 if path.exists():
  for p in sorted(path.rglob('*')):
   if '__pycache__' not in p.parts and p.is_file():files.append(p)
files += [p for p in sorted(root.glob('*.json')) if p.is_file()]
for workload in ['test','check']:
 directory=root/'results'/(workload+'-'+phase)
 assert directory.is_dir()
 files += [p for p in sorted(directory.rglob('*')) if p.is_file()]
files.append(root/'results'/(phase+'.json'))
files=sorted(set(files))
rows={}
for p in files:
 assert not p.is_symlink() and p.resolve()==p and p.is_relative_to(root),p
 s=p.stat();rows[str(p.relative_to(root))]={'sha256':sha(p),'bytes':s.st_size,'mode':s.st_mode & 0o7777}
manifest={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'phase':phase,'phase_state':state,'files':rows,'scope':'Full completed phase raw results plus frozen inputs, all setup diagnostics, logs and fixture journals; caches and already-sealed toolchain/binary payloads remain in their original owned locations.'}
with manifest_path.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
with tarfile.open(archive,'x:gz',compresslevel=1,dereference=True) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
 tar.add(manifest_path,arcname='phase.manifest.json',recursive=False)
for relative,row in rows.items():
 p=root/relative;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],relative
proof={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'manifest_sha256':sha(manifest_path),'file_count':len(rows)}
with proof_path.open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
print(json.dumps(proof))
'''

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['ir-exploratory','ir-confirmation','native-confirmation'])
    args = parser.parse_args()
    out = HERE / 'evidence' / args.phase
    out.mkdir(exist_ok=False)
    with (out/'seal.stderr').open('xb') as error:
        result = subprocess.run([SSH, HOST, '--', 'python3', '-c', REMOTE, REMOTE_ROOT, args.phase], stdout=subprocess.PIPE, stderr=error, check=True)
    (out/'archive.json').write_bytes(result.stdout)
    proof = json.loads(result.stdout)
    archive = out / (args.phase+'.tar.gz')
    code = "from pathlib import Path;import sys;p=Path(sys.argv[1]);assert p.is_file() and not p.is_symlink();sys.stdout.buffer.write(p.read_bytes())"
    with archive.open('xb') as stream, (out/'copy.stderr').open('xb') as error:
        subprocess.run([SSH, HOST, '--', 'python3', '-c', code, proof['archive']], stdout=stream, stderr=error, check=True)
    assert digest(archive)==proof['sha256'] and archive.stat().st_size==proof['bytes']
    remote = out/'remote'
    remote.mkdir()
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            name=Path(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            target=remote/name
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:
                stream.write(tar.extractfile(member).read())
    manifest_path=remote/'phase.manifest.json'
    assert digest(manifest_path)==proof['manifest_sha256']
    manifest=json.loads(manifest_path.read_text())
    assert len(manifest['files'])==proof['file_count']
    for name, row in manifest['files'].items():
        p=remote/name
        assert digest(p)==row['sha256'] and p.stat().st_size==row['bytes'],name
    print(json.dumps({'state':'copied-and-verified','phase':args.phase,'directory':str(out),'archive_sha256':proof['sha256'],'files':proof['file_count']},indent=2))

if __name__=='__main__':
    main()
