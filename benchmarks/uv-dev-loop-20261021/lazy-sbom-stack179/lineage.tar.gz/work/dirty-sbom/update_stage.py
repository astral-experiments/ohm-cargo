#!/usr/bin/env python3
"""Preserve the initial test fixture, add audits, and finish remote setup."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
files = {f'work/benchmark/{name}': HERE / 'frozen' / name for name in ('test_dirty_guard.py', 'dirty_audit.py', 'test_dirty_audit.py')}
files['finalize_setup.py'] = HERE / 'finalize_setup.py'
expected = {}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes(); expected[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        item = tarfile.TarInfo(name); item.mode = 0o644; item.size = len(data); item.mtime = 0
        archive.addfile(item, io.BytesIO(data))
remote = r'''
import hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
expected=json.loads(sys.argv[1]);original=json.loads((root/'stage-assets.json').read_text())
assert root.resolve()==root and root.stat().st_uid==os.getuid()
assert not (root/'setup.json').exists()
seen=set()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|') as archive:
    for item in archive:
        assert item.isfile() and item.name in expected and item.name not in seen
        data=archive.extractfile(item).read();record=expected[item.name]
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
        path=root/item.name
        if path.exists():
            assert item.name=='work/benchmark/test_dirty_guard.py'
            assert hashlib.sha256(path.read_bytes()).hexdigest()==original[item.name]['sha256']
            saved=root/'setup-history/initial-test_dirty_guard.py';saved.parent.mkdir(exist_ok=True)
            assert not saved.exists();path.rename(saved)
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(0o644);seen.add(item.name)
assert seen==set(expected)
(root/'stage-update-assets.json').write_text(json.dumps(expected,indent=2)+'\n')
result=subprocess.run(['python3',str(root/'finalize_setup.py')],capture_output=True,text=True)
(root/'finalize-setup.stdout').write_text(result.stdout);(root/'finalize-setup.stderr').write_text(result.stderr)
if result.returncode:
    print(result.stderr,file=sys.stderr)
    print((root/'logs/helper-tests-02.stderr').read_text(),file=sys.stderr)
    raise SystemExit(result.returncode)
record=json.loads((root/'setup.json').read_text())
print(json.dumps({'setup':record,'setup_sha256':hashlib.sha256((root/'setup.json').read_bytes()).hexdigest(),'test_log':(root/'logs/helper-tests-02.stderr').read_text(),'initial_test_log':(root/'logs/helper-tests.stderr').read_text()}))
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', 'python3', '-c', remote, json.dumps(expected, separators=(',', ':'))], input=buffer.getvalue(), capture_output=True)
(HERE / 'update-stage.stdout').write_bytes(result.stdout); (HERE / 'update-stage.stderr').write_bytes(result.stderr)
if result.returncode:
    sys.stderr.buffer.write(result.stderr); raise SystemExit(result.returncode)
record = json.loads(result.stdout)
(HERE / 'remote-setup.json').write_text(json.dumps(record['setup'], indent=2) + '\n')
(HERE / 'helper-tests-02.log').write_text(record['test_log'])
(HERE / 'helper-tests-01-failed.log').write_text(record['initial_test_log'])
print(json.dumps({'state': record['setup']['state'], 'setup_sha256': record['setup_sha256'], 'tests': record['setup']['helper_tests'], 'source_status': record['setup']['source_status'], 'profiler_version': record['setup']['valgrind_version']}, indent=2))
