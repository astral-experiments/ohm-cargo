#!/usr/bin/env python3
"""Freeze dirty fixture states and pending configs without running Cargo."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
OLD = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')
sys.path.insert(0, str(ROOT / 'work/benchmark'))
import dirty_fixture
import dirty_guard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    assert Path(__file__).resolve() == ROOT / 'prepare_configs.py'
    setup = json.loads((ROOT / 'setup.json').read_text())
    assert setup['state'] == 'ready-for-frozen-candidate'
    assert not (ROOT / 'configs-prepared.json').exists()
    protocol_path = ROOT / 'work/benchmark/protocol.json'
    assert sha(protocol_path) == 'e4d278ba9169dc2ce0445dca05734ef7b7646a19bb5f063fcb73f6c07636b5df'
    protocol = json.loads(protocol_path.read_text())
    for relative, expected in setup['frozen_helper_sha256'].items():
        assert sha(ROOT / relative) == expected
    source = ROOT / 'uv/crates/uv/src/lib.rs'
    canonical = ROOT / 'active/bin/cargo'
    environment = json.loads((OLD / 'work/loader-fixtures/uv-loader-pr175/fixture.json').read_text())['environment']
    environment.update({
        'CARGO_HOME': str(ROOT / 'cargo-home'), 'CARGO_BUILD_BUILD_DIR': str(ROOT / 'shared'),
        'TMPDIR': str(ROOT / 'tmp'), 'VALGRIND_LIB': str(ROOT / 'profiling-tools/valgrind/usr/libexec/valgrind'),
        'OHM_BENCH_NORMALIZE_VALGRIND_ENV': None, 'PYTHONDONTWRITEBYTECODE': '1',
    })
    environment.pop('CARGO_TARGET_DIR', None)
    commands = {}
    for workload in ('test', 'check'):
        command = ['taskset', '-c', '0-7', '{cargo}', '-Zohm-defaults=yes', workload]
        if workload == 'test':
            command.append('--no-run')
        command += ['--locked', '--offline', '-j', '8', '--message-format=json', '-v']
        commands[workload] = command
    state_specs = {}
    plans = []
    for phase in protocol['phases']:
        metric = 'ir' if phase['metric'] == 'cargo_ir' else 'native'
        name = f"{phase['workload']}-{metric}-{phase['phase']}"
        state = ROOT / 'fixtures' / name
        targets = {variant: str(ROOT / 'targets' / phase['workload'] / leaf) for variant, leaf in phase['target_assignment'].items()}
        dirty_fixture.initialize(state, source, ROOT / 'uv', targets, ROOT / 'shared')
        state_specs[str(state)] = {'targets': targets, 'shared_build_dir': str(ROOT / 'shared'), 'workload': phase['workload']}
        plans.append((name, phase, state))
    for workload in ('test', 'check'):
        state = ROOT / 'fixtures' / f'{workload}-diagnostic'
        targets = {variant: str(ROOT / 'targets' / workload / leaf) for variant, leaf in [('baseline', 'base'), ('candidate', 'cand')]}
        dirty_fixture.initialize(state, source, ROOT / 'uv', targets, ROOT / 'shared')
        state_specs[str(state)] = {'targets': targets, 'shared_build_dir': str(ROOT / 'shared'), 'workload': workload}
    guard = ROOT / 'work/benchmark/source-guard.json'
    dirty_guard.create(ROOT, ROOT / 'uv', source, {workload: [arg.replace('{cargo}', str(canonical)) for arg in command] for workload, command in commands.items()}, state_specs, guard)
    dirty_guard.check(guard, restored=True)
    metadata_names = ('cargo-pr175.build.json', 'cargo-pr175.strip.json', 'pr175.source.patch', 'provenance-pr175.json', 'cargo-pr175-lazy-sbom.build.json', 'cargo-pr175-lazy-sbom.strip.json', 'pr175-lazy-sbom.source.patch', 'provenance-pr175-lazy-sbom.json', 'pr175.patch', 'lazy-sbom.patch')
    common = [
        str(OLD / 'ohm/bin/rustc'), str(OLD / 'ohm/bin/rustdoc'),
        str(OLD / 'ohm/lib/librustc_driver-b03bf00bec23bb9a.so'),
        str(ROOT / 'uv/Cargo.lock'), str(source), str(guard), str(ROOT / 'setup.json'),
        str(ROOT / 'metadata/frozen-candidate.json'), str(ROOT / 'metadata/diagnostic-expectations.json'),
        *[str(ROOT / 'build' / name) for name in metadata_names],
        *[str(ROOT / name) for name in setup['frozen_helper_sha256']],
        *list(setup['runtime_file_sha256']),
    ]
    pending = {}
    for name, phase, state in plans:
        native = commands[phase['workload']]
        command = native
        metric_files = None
        records = common + [str(state / 'manifest.json'), str(state / 'original.bin')]
        if phase['metric'] == 'cargo_ir':
            command = ['taskset', '-c', '0-7', 'env',
                'LD_PRELOAD=' + str(ROOT / 'profiling-tools/ohm-valgrind-env.so'),
                'OHM_BENCH_NORMALIZE_VALGRIND_ENV=1',
                str(ROOT / 'profiling-tools/valgrind/usr/bin/valgrind'), '--tool=callgrind', '--trace-children=no',
                '--extra-debuginfo-path=' + str(ROOT / 'profiling-tools/valgrind/usr/lib/debug'),
                '--callgrind-out-file={output}/callgrind-{stage}-{pair}-{variant}.out', *native[3:]]
            metric_files = {'cargo_ir': {'format': 'callgrind', 'event': 'Ir', 'path': '{output}/callgrind-{stage}-{pair}-{variant}.out'}}
            records += [str(ROOT / relative) for relative in setup['profiler_file_sha256']]
        config = {
            'cwd': str(ROOT / 'uv'), 'canonical_executable': str(canonical),
            'variants': {'baseline': str(ROOT / 'binaries/cargo-pr175'), 'candidate': str(ROOT / 'binaries/cargo-pr175-lazy-sbom')},
            'command': command, 'env': environment,
            'variant_env': {variant: {'CARGO_TARGET_DIR': target} for variant, target in state_specs[str(state)]['targets'].items()},
            'prepare_command': ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'prepare', '--guard', str(guard), '--state', str(state), '--batch', '{output}', '--stage', '{stage}', '--pair', '{pair}', '--variant', '{variant}', '--', *native],
            'cleanup_command': ['python3', str(ROOT / 'work/benchmark/dirty_guard.py'), 'restore', '--guard', str(guard), '--state', str(state)],
            'record_files': sorted(set(records)),
            'pending_frozen_assets': ['actual candidate and matching provenance', 'successful native/instrumented diagnostic expectations'],
        }
        if metric_files is not None:
            config['metric_files'] = metric_files
        path = ROOT / 'configs' / f'{name}.pending.json'
        write(path, config)
        pending[name] = {'config': str(path), 'sha256': sha(path), 'state': str(state), 'phase': phase}
    report = {'prepared_at': datetime.now(timezone.utc).isoformat(), 'protocol_sha256': sha(protocol_path), 'source_guard_sha256': sha(guard), 'source_sha256': sha(source), 'configs': pending, 'no_source_edit_or_cargo_command_executed': True}
    write(ROOT / 'configs-prepared.json', report)
    print(json.dumps({'source_guard_sha256': report['source_guard_sha256'], 'prepared_configs': {name: row['sha256'] for name, row in pending.items()}, 'source_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
