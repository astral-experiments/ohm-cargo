#!/usr/bin/env python3
"""Preserve and correct the preflight-only audit's missing rlink support."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
names = ('dirty_audit.py', 'test_dirty_audit.py', 'baseline_seed.py', 'dirty_preflight.py', 'run_group.py')
expected = {}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name in names:
        data = (HERE / 'frozen' / name).read_bytes()
        expected[name] = hashlib.sha256(data).hexdigest()
        item = tarfile.TarInfo(name); item.size = len(data); item.mode = 0o644
        archive.addfile(item, io.BytesIO(data))
remote = r'''
import ast,hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
root=Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty');expected=json.loads(sys.argv[1]);setup=json.loads((root/'setup.json').read_text())
assert json.loads((root/'diagnostics/baseline-seed-01/manifest.json').read_text())['failure_restore_returncode']==0
prior={name:setup['frozen_helper_sha256']['work/benchmark/'+name] for name in ('dirty_audit.py','test_dirty_audit.py')}
prior['baseline_seed.py']='067919d35993f0ad6ac411fcca210ea5066075ee974143cf095dd32265f412cb'
seen=set()
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|') as archive:
 for item in archive:
  assert item.isfile() and item.name in expected and item.name not in seen
  data=archive.extractfile(item).read();assert hashlib.sha256(data).hexdigest()==expected[item.name];ast.parse(data)
  path=root/'work/benchmark'/item.name
  if path.exists():
   assert item.name in prior and hashlib.sha256(path.read_bytes()).hexdigest()==prior[item.name]
   saved=root/'setup-history/source-only-audit'/item.name;saved.parent.mkdir(parents=True,exist_ok=True);assert not saved.exists();path.rename(saved)
  path.write_bytes(data);seen.add(item.name)
assert seen==set(expected)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(root/'tmp'))
run=subprocess.run(['python3','-m','unittest','-v','test_dirty_fixture','test_dirty_guard','test_dirty_audit'],cwd=root/'work/benchmark',env=env,capture_output=True,text=True)
(root/'logs/helper-tests-03.stdout').write_text(run.stdout);(root/'logs/helper-tests-03.stderr').write_text(run.stderr)
record={'reason':'Baseline-only successful Cargo preflight includes Ohm link-only rustc commands taking generated .rlink inputs. The original audit rejected them. No candidate or comparative samples exist. Preserve the original failed attempt; bind generated uv rlink inputs to the assigned target and link-only mode, retaining all context/unit hashes while normalizing only the target prefix.','prior_helper_sha256':prior,'helper_sha256':expected,'tests_passed':run.returncode==0,'test_stderr_sha256':hashlib.sha256(run.stderr.encode()).hexdigest()}
(root/'metadata/audit-amendment-01.json').write_text(json.dumps(record,indent=2)+'\n')
if run.returncode:
 print(run.stderr,file=sys.stderr);raise SystemExit(run.returncode)
sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'work/benchmark'));import dirty_audit,dirty_guard
dirty_guard.check(root/'work/benchmark/source-guard.json',restored=True)
attempt=root/'diagnostics/baseline-seed-01';report=dirty_audit.parse_run((attempt/'logs/test.stdout').read_text(),(attempt/'logs/test.stderr').read_text(),str(root/'targets/test/base'))
package='path+file://'+str(root/'uv/crates/uv')+'#0.13.4';rustc='/tmp/ohm-hillclimb-20261021/confirmation-path-cache/ohm/bin/rustc'
dirty_audit.validate_run(report,rustc,package);executed=dirty_audit.validate_no_tests(report,(attempt/'logs/test.execve').read_text());assert executed.count(rustc)==len(report['compiler_commands'])
corrected={'valid':True,'original_attempt_remains_failed':True,'source_restored':True,'compiler_report':report,'successful_execve_paths':executed,'tests_executed':[]}
(attempt/'corrected-read-only-audit.json').write_text(json.dumps(corrected,indent=2)+'\n')
print(json.dumps({'tests':run.stderr,'amendment':record,'baseline_compiler_stages':report['compiler_stage_counts'],'source_restored':True}))
'''
helper = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
result = subprocess.run([helper, 'charlie-oss-4', '--', 'python3', '-c', remote, json.dumps(expected, separators=(',', ':'))], input=buffer.getvalue(), capture_output=True)
(HERE / 'amend-audit.stdout').write_bytes(result.stdout); (HERE / 'amend-audit.stderr').write_bytes(result.stderr)
if result.returncode:
    print(result.stderr.decode()); raise SystemExit(result.returncode)
record = json.loads(result.stdout)
(HERE / 'helper-tests-03.log').write_text(record['tests'])
(HERE / 'audit-amendment-01.json').write_text(json.dumps(record['amendment'], indent=2) + '\n')
print(json.dumps({'tests_passed': record['amendment']['tests_passed'], 'baseline_compiler_stages': record['baseline_compiler_stages'], 'source_restored': record['source_restored'], 'helper_sha256': record['amendment']['helper_sha256']}, indent=2))
