#!/usr/bin/env python3
"""Finish setup after preserving the original remote helper-test attempt."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-dirty')
OLD = Path('/tmp/ohm-hillclimb-20261021/confirmation-path-cache')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def run(argv, **kwargs):
    return subprocess.check_output(argv, text=True, **kwargs).strip()


def main():
    assert Path(__file__).resolve() == ROOT / 'finalize_setup.py'
    assert ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.getuid()
    assert not (ROOT / 'setup.json').exists()
    assert not (ROOT / 'logs/helper-tests-02.stderr').exists()
    env = os.environ.copy()
    env.update(TMPDIR=str(ROOT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
    with (ROOT / 'logs/helper-tests-02.stdout').open('wb') as out, (ROOT / 'logs/helper-tests-02.stderr').open('wb') as err:
        tested = subprocess.run(['python3', '-m', 'unittest', '-v', 'test_dirty_fixture', 'test_dirty_guard', 'test_dirty_audit'], cwd=ROOT / 'work/benchmark', env=env, stdout=out, stderr=err)
    assert tested.returncode == 0, 'helper tests failed; preserve all attempts'
    text = (ROOT / 'logs/helper-tests-02.stderr').read_text()
    assert 'Ran 22 tests' in text and text.rstrip().endswith('OK')
    loader = Path('/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2')
    build_id = re.search(r'Build ID: ([0-9a-f]+)', run(['readelf', '-n', str(loader)]))[1]
    debug = ROOT / 'profiling-tools/valgrind/usr/lib/debug/.build-id' / build_id[:2] / (build_id[2:] + '.debug')
    assert debug.is_file()
    runtime = [loader, Path('/usr/lib/x86_64-linux-gnu/libc.so.6'), Path('/usr/lib/x86_64-linux-gnu/libm.so.6'), Path('/usr/lib/x86_64-linux-gnu/libgcc_s.so.1'), Path('/etc/ssl/certs/ca-certificates.crt')]
    record = {
        'state': 'ready-for-frozen-candidate', 'finished_at': datetime.now(timezone.utc).isoformat(),
        'root': str(ROOT), 'uid': os.getuid(), 'source_input_root_read_only': str(OLD),
        'source_revision': run(['git', '-C', str(ROOT / 'uv'), 'rev-parse', 'HEAD']),
        'source_status': run(['git', '-C', str(ROOT / 'uv'), 'status', '--porcelain']),
        'package_cache_source': str(OLD / 'cargo-home'), 'package_cache_copied_children': sorted(path.name for path in (ROOT / 'cargo-home').iterdir()),
        'baseline_sha256': sha(ROOT / 'binaries/cargo-pr175'),
        'frozen_helper_sha256': {str(path.relative_to(ROOT)): sha(path) for path in sorted((ROOT / 'work/benchmark').iterdir()) if path.is_file()},
        'profiler_file_sha256': {str(path.relative_to(ROOT)): sha(path) for path in sorted((ROOT / 'profiling-tools').rglob('*')) if path.is_file()},
        'runtime_file_sha256': {str(path): sha(path) for path in runtime},
        'valgrind_version': run([str(ROOT / 'profiling-tools/valgrind/usr/bin/valgrind'), '--version']),
        'loader_build_id': build_id, 'loader_debug_sha256': sha(debug),
        'helper_tests': {'count': 22, 'passed': True, 'stderr_sha256': sha(ROOT / 'logs/helper-tests-02.stderr')},
        'initial_helper_test_failure': 'Guard test fixture assumed mode 0644; remote umask creates 0664. Test now records actual original mode. Runtime guard behavior unchanged. Original attempt logs and source are retained.',
        'disk_available_after': shutil.disk_usage(ROOT).free, 'no_cargo_build_or_benchmark_executed': True,
    }
    assert record['source_revision'] == '3d82a6ad5a7eab8c68236553b7846517767c4b61' and not record['source_status']
    assert record['package_cache_copied_children'] == ['registry']
    assert record['baseline_sha256'] == '63495905e7b0b11ad99fa4c2c2674e43657b9902a2e3142ef735fd83efa44cf8'
    (ROOT / 'setup.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'state': record['state'], 'setup_sha256': sha(ROOT / 'setup.json'), 'tests': record['helper_tests'], 'root': str(ROOT)}), flush=True)


if __name__ == '__main__':
    main()
