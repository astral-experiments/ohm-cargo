"""Synthetic acceptance, archive and lossless-retention checks; no real effects."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch
import assemble_evidence as package


def documents(phase='native-confirmation'):
    native = phase == 'native-confirmation'
    prior = {'review_sha256': package.IR_REVIEW, 'transfer_manifest_sha256': package.IR_TRANSFER} if native else None
    review = {'valid': True, 'phase': phase, 'source_freeze_sha256': package.REVIEWER,
              'raw_integrity_before_effects': True, 'variant_sha256': package.BINARIES,
              'cohort_sha256': package.COHORT, 'finalized_sha256': package.FINAL, 'protocol_sha256': package.PROTOCOL,
              'transfer_manifest_sha256': 'a' * 64, 'primary_passes': not native, 'secondary_passes': False,
              'accepted_ir': prior}
    raw = {'valid': True, 'phase': phase, 'source_freeze_sha256': package.REVIEWER,
           'both_workflows_complete_before_effects': True, 'transfer_manifest_sha256': 'a' * 64,
           'accepted_ir': prior, 'workloads': {}}
    for workload in ('test', 'check'):
        raw['workloads'][workload] = {'valid': True, 'workload': workload, 'measurement_pairs': 30 if native else 12,
            'samples': 64 if native else 28, 'warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
            'native_test_executions': 0, 'compiler_invocations_per_sample': 6 if workload == 'test' else 1,
            'expected_stage_counts': {'rlink': 4, 'source': 2} if workload == 'test' else {'source': 1}}
    effects = {'phase': phase, 'fixed_method': {'confidence': 0.99, 'bootstrap_resamples': 20000,
        'bootstrap_seed': 1701, 'minimum_reduction': 0.01, 'maximum_sign_p': 0.01},
        'workloads': {w: {'gate': {'passes_gate': (w == 'test' and not native), 'significant_native_regression': False}}
                      for w in ('test', 'check')}}
    return review, raw, effects


class ProofTests(unittest.TestCase):
    def test_primary_only_ir_claim_is_accepted(self):
        review, raw, effects = documents('ir-confirmation')
        package.validate_raw(review, raw, 'ir-confirmation')
        package.validate_effects(review, effects, 'ir-confirmation')

    def test_inconclusive_native_can_validate_without_wall_claim(self):
        review, raw, effects = documents()
        package.validate_raw(review, raw, 'native-confirmation')
        package.validate_effects(review, effects, 'native-confirmation')

    def test_both_raw_audits_required(self):
        for change in ('absent', 'failed', 'premature'):
            review, raw, effects = documents()
            if change == 'absent': del raw['workloads']['check']
            elif change == 'failed': raw['workloads']['check']['valid'] = False
            else: raw['both_workflows_complete_before_effects'] = False
            with self.subTest(change=change), self.assertRaises(ValueError):
                package.validate_raw(review, raw, 'native-confirmation')

    def test_wrong_counts_and_test_execution_rejected(self):
        for field, value in [('samples', 62), ('measurement_pairs', 31), ('warmup_pairs', 0),
                             ('invocations_per_variant_per_pair', 8), ('native_test_executions', 1),
                             ('compiler_invocations_per_sample', 1)]:
            review, raw, effects = documents(); raw['workloads']['test'][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                package.validate_raw(review, raw, 'native-confirmation')

    def test_previous_binary_or_review_cannot_qualify(self):
        for field, value in [('variant_sha256', {'baseline': 'old', 'candidate': 'old'}),
                             ('source_freeze_sha256', 'old'), ('protocol_sha256', 'old')]:
            review, raw, effects = documents(); review[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                package.validate_raw(review, raw, 'native-confirmation')

    def test_native_binds_exact_accepted_ir(self):
        review, raw, effects = documents(); review['accepted_ir'] = {'review_sha256': 'old', 'transfer_manifest_sha256': package.IR_TRANSFER}
        with self.assertRaises(ValueError): package.validate_raw(review, raw, 'native-confirmation')

    def test_each_native_regression_blocks(self):
        for workload in ('test', 'check'):
            review, raw, effects = documents(); effects['workloads'][workload]['gate']['significant_native_regression'] = True
            with self.subTest(workload=workload), self.assertRaises(ValueError):
                package.validate_effects(review, effects, 'native-confirmation')

    def test_method_and_gate_changes_rejected(self):
        review, raw, effects = documents(); effects['fixed_method']['bootstrap_resamples'] = 1000
        with self.assertRaises(ValueError): package.validate_effects(review, effects, 'native-confirmation')
        review, raw, effects = documents(); effects['workloads']['check']['gate']['passes_gate'] = True
        with self.assertRaises(ValueError): package.validate_effects(review, effects, 'native-confirmation')

    def test_failed_native_admission_must_remain_bound(self):
        row = {'sha256': 'f' * 64, 'bytes': 100, 'mode': 0o644}
        document = {'status': 'reviewed-complete', 'phase': 'native-confirmation', 'review_sha256': 'r',
                    'native_acceptance_sha256': 'a', 'all_native_attempts_retained': True,
                    'coverage': ['source_controls', 'preparation', 'stage', 'launch', 'collection', 'review', 'failed_admission'],
                    'files': {'work/failure.json': row}}
        inputs = {'reviews': {'native': {'review_sha256': 'r'}}, 'native_acceptance': {'record': {'sha256': 'a'}},
                  'files': {'work/failure.json': row}}
        catalog = {'required_native_failed_status_sha256': ['f' * 64]}
        package.validate_native_lineage(document, inputs, catalog)
        for mutation in ('missing_failure', 'no_history', 'unbound_file'):
            value = copy.deepcopy(document)
            if mutation == 'missing_failure': value['files'] = {}
            elif mutation == 'no_history': value['all_native_attempts_retained'] = False
            else: value['files']['work/extra'] = row
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                package.validate_native_lineage(value, inputs, catalog)


class StorageTests(unittest.TestCase):
    def test_safe_paths(self):
        for name in ('', '.', '../x', '/x', 'a//b', 'a/../b', 'a\\b', 1):
            with self.subTest(name=name), self.assertRaises(ValueError): package.relative(name)

    def test_lossless_ordered_chunks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve(); source = root / 'original.tar.gz'; source.write_bytes(bytes(range(37)))
            receipt = package.copy_lossless(source, root / 'out/archive.tar.gz', limit=8)
            chunks = receipt['chunks_in_concatenation_order']
            self.assertEqual([row['bytes'] for row in chunks], [8, 8, 8, 8, 5])
            self.assertEqual(b''.join((root / 'out' / row['name']).read_bytes() for row in chunks), source.read_bytes())
            self.assertEqual(receipt['original']['sha256'], hashlib.sha256(source.read_bytes()).hexdigest())

    def test_small_archive_is_byte_identical(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve(); source = root / 'original'; source.write_bytes(b'original archive bytes')
            receipt = package.copy_lossless(source, root / 'copy')
            self.assertEqual((root / 'copy').read_bytes(), source.read_bytes())
            self.assertEqual(len(receipt['chunks_in_concatenation_order']), 1)

    def test_existing_output_cannot_be_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve(); source = root / 'original'; source.write_bytes(b'a'); target = root / 'copy'; target.write_bytes(b'b')
            with self.assertRaises(FileExistsError): package.copy_lossless(source, target)
            self.assertEqual(target.read_bytes(), b'b')

    def test_symlink_input_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve(); source = root / 'original'; source.write_bytes(b'a'); link = root / 'link'; link.symlink_to(source)
            with self.assertRaises(ValueError): package.item(link)

    def test_archive_members_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve(); directory = root / 'capture'; directory.mkdir()
            payload = directory / 'sample.stdout'; payload.write_bytes(b'synthetic only\n'); payload.chmod(0o644)
            manifest = directory / 'transfer-manifest.json'; manifest.write_bytes(package.encoded({'files': {'sample.stdout': package.item(payload)}})); manifest.chmod(0o644)
            archive_path = root / 'original.tar.gz'
            with tarfile.open(archive_path, 'w:gz') as archive:
                for source in (payload, manifest):
                    member = tarfile.TarInfo(source.name); member.size = source.stat().st_size; member.mode = 0o644
                    archive.addfile(member, io.BytesIO(source.read_bytes()))
            receipt_path = root / 'receipt.json'; receipt_path.write_bytes(package.encoded({'valid': True, 'cohort_sha256': package.COHORT,
                'archive_sha256': package.sha(archive_path), 'transfer_manifest_sha256': package.sha(manifest)}))
            spec = {'directory': 'capture', 'archive': 'original.tar.gz', 'receipt': 'receipt.json',
                    'archive_record': package.item(archive_path), 'receipt_record': package.item(receipt_path),
                    'manifest_record': package.item(manifest)}
            with patch.object(package, 'WORKSPACE', root):
                result = package.verify_capture(spec); self.assertEqual(len(result['members']), 2)
                (directory / 'unbound').write_bytes(b'x')
                with self.assertRaises(ValueError): package.verify_capture(spec)


if __name__ == '__main__':
    unittest.main(verbosity=2)
