#!/usr/bin/env python3
"""Create the source-only immutable input index; hash archives without parsing effects."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import assemble_evidence as package


def main():
    destination = package.HERE / 'existing-inputs.json'
    package.need(not destination.exists(), 'input catalog already exists')
    files, archives = {}, {}

    def bind(path):
        path = Path(path).absolute()
        name = str(path.relative_to(package.WORKSPACE))
        row = package.item(path)
        package.need(name not in files or files[name] == row, 'conflicting input identity')
        files[name] = row
        return row

    def tree(path, excluded=()):
        for entry in sorted(path.rglob('*')):
            relative = entry.relative_to(path)
            if any(part in {'__pycache__', '.git'} for part in relative.parts) or any(
                    relative == Path(name) or Path(name) in relative.parents for name in excluded):
                continue
            package.need(not entry.is_symlink(), 'unexpected source-lineage symlink')
            if entry.is_file():
                bind(entry)

    current = package.WORKSPACE / 'work/dirty-sbom-current179'
    archive_paths = {f'current179-{path.name.removesuffix(".tar.gz")}': path for path in current.glob('*.tar.gz')}
    archive_paths['current179-check-convergence-untimed'] = current / 'check-convergence-evidence/payload.tar'
    archive_paths['current179-ir-complete'] = package.WORKSPACE / 'work/sbom-current179-ir-continuation/ir-confirmation-evidence.tar.gz'
    archive_paths['current179-production-inputs'] = package.WORKSPACE / 'work/production-build/host3-sbom-stack179/provision-inputs.tar'
    historical = package.WORKSPACE / 'work/dirty-sbom/evidence'
    for path in sorted(historical.rglob('*')):
        if path.is_file() and path.name.endswith(('.tar', '.tar.gz')):
            label = 'historical-pr175-' + str(path.relative_to(historical)).replace('/', '--')
            package.need(label not in archive_paths, 'duplicate historical archive label')
            archive_paths[label] = path
    for label, path in sorted(archive_paths.items()):
        bind(path)
        archives[label] = {'path': str(path.relative_to(package.WORKSPACE)),
                           'scope': 'historical-pr175' if label.startswith('historical-') else 'current179'}

    roots = ('sbom-current179-ir-continuation', 'sbom-current179-ir-environment',
             'sbom-current179-ir-environment-review', 'sbom-current179-ir-reviewer-profiler-alias-v2',
             'sbom-current179-native-prerequisite-amendment', 'sbom-current179-native-launch-controls',
             'sbom-current179-native-launch-controls-alias-v2')
    for name in roots:
        root = package.WORKSPACE / 'work' / name
        freeze = root / 'source-freeze.json'
        bind(freeze)
        for relative, expected in package.read(freeze)['files'].items():
            observed = bind(root / package.relative(relative))
            package.need(all(observed[key] == value for key, value in expected.items()), 'source freeze input differs')
    for name in ('sbom-current179-ir-environment', 'sbom-current179-ir-environment-review',
                 'benchmark/sbom-native-alias-v2-review', 'compiler-audit/sbom-native-wrapper-review',
                 'compiler-audit/sbom-path-continuation-source-review', 'cargo-audit/sbom-native-launch-controls-review',
                 'sbom-current179-native-failed-launch01'):
        tree(package.WORKSPACE / 'work' / name)
    original = package.WORKSPACE / 'work/sbom-current179-ir-continuation'
    for path in sorted(original.iterdir()):
        if path.is_file() and not path.name.endswith(('.tar', '.tar.gz')) and not path.name.startswith('native-'):
            bind(path)
    tree(original / 'independent-ir-review-profiler-alias-v2')
    for path in sorted(current.iterdir()):
        if path.is_file() and not path.name.endswith(('.tar', '.tar.gz')):
            bind(path)
    for name in ('frozen',):
        if (current / name).is_dir():
            tree(current / name)
    production = package.WORKSPACE / 'work/production-build/host3-sbom-stack179'
    tree(production, ('results/cargo-sbom-stack179-baseline', 'results/cargo-sbom-stack179-lazy', 'provision-inputs.tar'))
    old = package.WORKSPACE / 'work/dirty-sbom'
    for path in sorted(old.iterdir()):
        if path.is_file():
            bind(path)
    for name in ('frozen', 'configs'):
        tree(old / name)
    for name in ('', 'ir-exploratory', 'ir-confirmation'):
        for path in sorted((historical / name).iterdir()):
            if path.is_file() and not path.name.endswith(('.tar', '.tar.gz')):
                bind(path)
    for name in ('work/compiler-audit/lazy-sbom-stack179-review.json', 'work/logs/sbom-tests.log',
                 'work/logs/sbom-matched-tests.log', 'work/logs/cargo-lazy-sbom-tests-build.log',
                 'work/logs/cargo-lazy-sbom-build.log', 'work/binaries/stripped/cargo-lazy-sbom.json',
                 'work/sbom-current179-publication/code-publication.json', 'work/sbom-current179-publication/ci-validation.json',
                 'work/sbom-current179-publication/ci-dispatch.json', 'work/sbom-current179-publication/ci-status-01.json'):
        bind(package.WORKSPACE / name)

    def capture(root, phase):
        directory, archive, receipt = root / 'evidence' / phase, root / (phase + '-evidence.tar.gz'), root / (phase + '-collection-receipt.json')
        return {'directory': str(directory.relative_to(package.WORKSPACE)),
                'archive': str(archive.relative_to(package.WORKSPACE)), 'receipt': str(receipt.relative_to(package.WORKSPACE)),
                'archive_record': bind(archive), 'receipt_record': bind(receipt),
                'manifest_record': bind(directory / 'transfer-manifest.json')}

    captures = {'ir-failed': capture(current, 'ir-failed-before-check'), 'ir': capture(original, 'ir-confirmation')}
    need = package.need
    need(captures['ir']['manifest_record']['sha256'] == package.IR_TRANSFER, 'accepted IR manifest differs')
    need(package.sha(original / 'independent-ir-review-profiler-alias-v2/review.json') == package.IR_REVIEW, 'accepted IR review differs')
    need(package.sha(original / 'root-ir-profiler-alias-v2-acceptance.json') == package.IR_ACCEPTANCE, 'root IR acceptance differs')
    catalog = {'status': 'source-only-native-pending', 'files': files, 'archives': archives, 'captures': captures,
               'reviews': {'ir': {'directory': 'work/sbom-current179-ir-continuation/independent-ir-review-profiler-alias-v2',
                                  'review_sha256': package.IR_REVIEW}},
               'required_native_failed_status_sha256': ['653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2'],
               'scope': 'Full original archives retained. Historical PR175 files are provenance/selection evidence only. Native capture, both raw audits, root acceptance and all failed native admission/recovery lineage remain required.'}
    with destination.open('xb') as stream:
        stream.write(package.encoded(catalog))
    print(package.encoded({'status': catalog['status'], 'files': len(files), 'archives': len(archives),
                           'catalog_sha256': package.sha(destination)}).decode(), end='')


if __name__ == '__main__':
    main()
