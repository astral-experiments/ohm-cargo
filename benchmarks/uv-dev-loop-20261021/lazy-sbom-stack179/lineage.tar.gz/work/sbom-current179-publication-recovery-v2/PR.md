Skip SBOM construction when no output is requested

Compute the requested SBOM output paths before constructing the document, and skip construction when that list is empty. Requested SBOM generation and serialization retain their existing behavior.

Against PR179 (`19718e6d`), the fixed dirty uv `cargo test --no-run` confirmation used **5.54% fewer Cargo-process instructions** (99% CI **5.45–5.60%**, 12/12 paired wins, exact two-sided sign p = 0.0004883; both execution orders improved). The secondary `cargo check` result was +0.53% (99% CI 0.44–0.61%), below the predeclared 1% minimum, so it does not qualify for a check claim. These counters exclude child compiler/linker work and do not establish a wall-time improvement.

Native validation is pending and must finish with both raw audits accepted and no established regression before publication. The exact source passed [CI](https://github.com/astral-sh/ohm-cargo/actions/runs/39607088231). The evidence will retain full profiles, fixed sample tables, matched build provenance, historical PR175 runs, and every operational failure and continuation separately.

Local draft only. Replace this pending paragraph with the accepted native findings and an immutable evidence link before opening the draft PR.
