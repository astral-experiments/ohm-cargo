"""Synthetic recovery/approval joins; never read the real native collection."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import assemble_evidence as package
import recovery_binding as recovery


class Fixture:
    """Synthetic document store, with explicit stand-ins for immutable hashes."""
    def __init__(self, root):
        self.root, self.docs, self.rows = root, {}, {}
        def put(name, value, digest=None):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            data = package.encoded(value)
            path.write_bytes(data)
            self.docs[name] = value
            self.rows[name] = {'sha256': digest or hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'mode': 0o644}
            return self.rows[name]
        self.put = put
        c = recovery.CONTROLS
        source = recovery.LINEAGE_SOURCE
        ld, rd = recovery.LINEAGE_DIRECTORY, recovery.RAW_DIRECTORY
        la, ra = c + '/lineage-approval.json', c + '/raw-approval.json'
        collection, transfer = 'c' * 64, 'd' * 64
        script = put(source + '/review_recovery.py', {'synthetic': True})
        external = put('work/predecessor/source-freeze.json', {'synthetic': True})
        put(source + '/source-freeze.json', {'files': {'review_recovery.py': script},
            'external_inputs': {str(root / 'work/predecessor/source-freeze.json'): external}}, recovery.LINEAGE_FREEZE)
        put(source + '/root-source-review.json', {'status': 'passed', 'source_freeze_sha256': recovery.LINEAGE_FREEZE}, recovery.SOURCE_REVIEW)
        for name in ('launch-quiet.stdout', 'launch-quiet.stderr'):
            put('work/sbom-current179-native-admission-recovery/' + name, {'synthetic': True},
                recovery.QUIET_STDERR if name.endswith('stderr') else None)
        put('work/sbom-current179-native-launch-replay02/root-launch-approval.json', {'synthetic': True}, recovery.LAUNCH_APPROVAL)
        put(la, {'valid': True, 'authorized_operation': 'review-zero-work-native-recovery-lineage',
            'source_freeze_sha256': recovery.LINEAGE_FREEZE, 'output': str(root / ld),
            'collection_receipt_sha256': collection, 'recovery_receipt_sha256': recovery.RECOVERY_RECEIPT,
            'replay_copy_receipt_sha256': recovery.COPY_RECEIPT, 'launch_approval_sha256': recovery.LAUNCH_APPROVAL})
        index = {'files': {str(root / 'work/predecessor/source-freeze.json'): external},
                 'native_transfer_manifest_sha256': transfer}
        put(ld + '/local-inputs.json', index)
        lineage = {'valid': True, 'phase': 'native-confirmation', 'source_freeze_sha256': recovery.LINEAGE_FREEZE,
            'original_reviewer_source_freeze_sha256': recovery.RAW_FREEZE, 'accepted_ir_review_sha256': recovery.IR_REVIEW,
            'original_controls_source_freeze_sha256': recovery.CONTROLS_FREEZE, 'recovery_source_freeze_sha256': recovery.RECOVERY_FREEZE,
            'prerequisite_manifest_sha256': recovery.PREREQUISITE, 'original_native_controller_sha256': recovery.CONTROLLER,
            'retained_failure_files': 11, 'retention_files': 20, 'original_local_files_preserved': 119,
            'byte_identical_replay_files': 101, 'both_fixed_native_workflows_terminal': True,
            'native_pairs_per_workflow': 30, 'native_warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
            'native_effects_inspected_or_computed': False, 'original_both_workflow_raw_and_statistical_review_required': True,
            'final_rehash': 'passed', 'collection_receipt_sha256': collection, 'transfer_manifest_sha256': transfer,
            'approval_sha256': self.rows[la]['sha256'], 'local_inputs_sha256': self.rows[ld + '/local-inputs.json']['sha256'],
            'recovery_receipt_sha256': recovery.RECOVERY_RECEIPT, 'replay_copy_receipt_sha256': recovery.COPY_RECEIPT,
            'launch_approval_sha256': recovery.LAUNCH_APPROVAL, 'reviewed_at': '2026-10-21T19:01:00+00:00'}
        put(ld + '/review.json', lineage)
        put(ld + '/seal.json', {n: self.rows[ld + '/' + n] for n in ('review.json', 'local-inputs.json')})
        put(ra, {'valid': True, 'phase': 'native-confirmation', 'source_freeze_sha256': recovery.RAW_FREEZE,
            'output': str(root / rd), 'collection_receipt_sha256': collection,
            'accepted_ir_review_sha256': recovery.IR_REVIEW,
            'accepted_native_recovery_lineage_review_sha256': self.rows[ld + '/review.json']['sha256']})
        put(recovery.BRIDGE_PATH, {'status': 'passed', 'phase': 'native-confirmation',
            'lineage_source_freeze_sha256': recovery.LINEAGE_FREEZE, 'lineage_source_review_sha256': recovery.SOURCE_REVIEW,
            'lineage_review_directory': str(root / ld), 'lineage_review_sha256': self.rows[ld + '/review.json']['sha256'],
            'lineage_seal_sha256': self.rows[ld + '/seal.json']['sha256'],
            'lineage_execution_approval_sha256': self.rows[la]['sha256'], 'collection_receipt_sha256': collection,
            'accepted_ir_review_sha256': recovery.IR_REVIEW, 'original_raw_reviewer_source_freeze_sha256': recovery.RAW_FREEZE,
            'raw_review_output': str(root / rd), 'raw_review_execution_approval_path': str(root / ra),
            'raw_review_execution_approval_sha256': self.rows[ra]['sha256'], 'accepted_before_raw_review': True,
            'native_effects_inspected_or_computed': False, 'accepted_at': '2026-10-21T19:03:00+00:00'})
        put(rd + '/review.json', {'approval_sha256': self.rows[ra]['sha256'], 'source_freeze_sha256': recovery.RAW_FREEZE,
            'collection_receipt_sha256': collection, 'transfer_manifest_sha256': transfer, 'reviewed_at': '2026-10-21T19:05:00+00:00'})
        lineage_argv = ['/usr/bin/python3', '-I', '-B', str(root / source / 'review_recovery.py'),
            '--source-freeze-sha256', recovery.LINEAGE_FREEZE, '--approval', str(root / la),
            '--approval-sha256', self.rows[la]['sha256'], '--output', str(root / ld)]
        raw_argv = ['/usr/bin/python3', '-B', str(root / 'work/sbom-current179-ir-reviewer-profiler-alias-v2/review.py'),
            'native-confirmation', '--controls', str(root / c), '--approval', str(root / ra), '--output', str(root / rd),
            '--accepted-ir', str(root / c / 'independent-ir-review-profiler-alias-v2')]
        for path, approval, argv, minute in ((recovery.LINEAGE_EXECUTION, la, lineage_argv, 0), (recovery.RAW_EXECUTION, ra, raw_argv, 4)):
            value = {'returncode': 0, 'approval_sha256': self.rows[approval]['sha256'], 'argv': argv,
                'started_at': f'2026-10-21T19:0{minute}:00+00:00', 'finished_at': f'2026-10-21T19:0{minute + 2}:00+00:00'}
            if path == recovery.RAW_EXECUTION:
                value['bridge_sha256'] = self.rows[recovery.BRIDGE_PATH]['sha256']
            for stream in ('stdout', 'stderr'):
                name = str(Path(path).parent / stream)
                put(name, {'synthetic': True})
                value[stream + '_path'] = str(root / name)
                value[stream + '_sha256'] = self.rows[name]['sha256']
            put(path, value)
        self.document = {'files': copy.deepcopy(self.rows), 'recovery_bindings': {}}
        for key, path in [('lineage_review', ld + '/review.json'), ('root_acceptance_bridge', recovery.BRIDGE_PATH),
                          ('lineage_execution_approval', la), ('raw_execution_approval', ra),
                          ('lineage_execution_receipt', recovery.LINEAGE_EXECUTION), ('raw_execution_receipt', recovery.RAW_EXECUTION)]:
            self.document['recovery_bindings'][key] = {'path': path, 'sha256': self.rows[path]['sha256']}
        self.inputs = {'files': copy.deepcopy(self.rows), 'captures': {'native': {
            'receipt_record': {'sha256': collection}, 'manifest_record': {'sha256': transfer}}},
            'reviews': {'native': {'directory': rd, 'review_sha256': self.rows[rd + '/review.json']['sha256']}}}

    def run(self):
        recovery.validate(self.document, self.inputs, self.root,
            lambda p: self.rows[str(p.relative_to(self.root))],
            lambda p: self.docs[str(p.relative_to(self.root))], package.need, package.relative)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.fixture = Fixture(Path(self.temporary.name).resolve())

    def test_full_reviewed_lineage_passes(self):
        self.fixture.run()

    def test_isolated_assembler_loads_explicit_frozen_helper(self):
        fixture = self.fixture
        with patch.object(package, 'WORKSPACE', fixture.root), \
             patch.object(package, 'item', lambda p: fixture.rows[str(p.relative_to(fixture.root))]), \
             patch.object(package, 'read', lambda p: fixture.docs[str(p.relative_to(fixture.root))]):
            package.validate_recovery_lineage(fixture.document, fixture.inputs)

    def test_category_labels_cannot_replace_recovery_proof(self):
        del self.fixture.document['recovery_bindings']
        with self.assertRaises((KeyError, ValueError)): self.fixture.run()

    def test_missing_source_external_is_rejected(self):
        del self.fixture.document['files']['work/predecessor/source-freeze.json']
        with self.assertRaises(ValueError): self.fixture.run()

    def test_truncated_or_old_accepted_ir_is_rejected(self):
        self.fixture.docs[recovery.LINEAGE_DIRECTORY + '/review.json']['accepted_ir_review_sha256'] = recovery.IR_REVIEW[:-2]
        with self.assertRaises(ValueError): self.fixture.run()

    def test_bridge_must_bind_actual_approval(self):
        self.fixture.docs[recovery.BRIDGE_PATH]['raw_review_execution_approval_sha256'] = 'a' * 64
        with self.assertRaises(ValueError): self.fixture.run()

    def test_ignored_raw_approval_field_is_required(self):
        approval = self.fixture.document['recovery_bindings']['raw_execution_approval']['path']
        del self.fixture.docs[approval]['accepted_native_recovery_lineage_review_sha256']
        with self.assertRaises((KeyError, ValueError)): self.fixture.run()

    def test_posthoc_bridge_is_rejected(self):
        self.fixture.docs[recovery.BRIDGE_PATH]['accepted_at'] = '2026-10-21T19:07:00+00:00'
        with self.assertRaises(ValueError): self.fixture.run()

    def test_raw_execution_must_bind_bridge(self):
        self.fixture.docs[recovery.RAW_EXECUTION]['bridge_sha256'] = 'b' * 64
        with self.assertRaises(ValueError): self.fixture.run()

    def test_raw_execution_failure_is_rejected(self):
        self.fixture.docs[recovery.RAW_EXECUTION]['returncode'] = 1
        with self.assertRaises(ValueError): self.fixture.run()

    def test_changed_command_is_rejected(self):
        self.fixture.docs[recovery.RAW_EXECUTION]['argv'].insert(1, '-I')
        with self.assertRaises(ValueError): self.fixture.run()

    def test_stream_substitution_is_rejected(self):
        self.fixture.docs[recovery.RAW_EXECUTION]['stderr_path'] = self.fixture.docs[recovery.LINEAGE_EXECUTION]['stderr_path']
        with self.assertRaises(ValueError): self.fixture.run()

    def test_extra_quiet_failure_cannot_be_omitted(self):
        del self.fixture.document['files']['work/sbom-current179-native-admission-recovery/launch-quiet.stderr']
        with self.assertRaises(ValueError): self.fixture.run()

    def test_unindexed_actual_recovery_stream_is_rejected(self):
        path = self.fixture.root / 'work/sbom-current179-native-admission-recovery/extra.stderr'
        path.write_bytes(b'synthetic new stream')
        with self.assertRaises(ValueError): self.fixture.run()

    def test_local_review_input_index_cannot_omit_payload(self):
        self.fixture.put('work/protected-review-input', {'synthetic': True})
        index = self.fixture.docs[recovery.LINEAGE_DIRECTORY + '/local-inputs.json']
        index['files'][str(self.fixture.root / 'work/protected-review-input')] = self.fixture.rows['work/protected-review-input']
        with self.assertRaises(ValueError): self.fixture.run()

    def test_partial_retention_cannot_pass(self):
        self.fixture.docs[recovery.LINEAGE_DIRECTORY + '/review.json']['retention_files'] = 19
        with self.assertRaises(ValueError): self.fixture.run()

    def test_another_collection_cannot_pass(self):
        self.fixture.inputs['captures']['native']['receipt_record']['sha256'] = 'e' * 64
        with self.assertRaises(ValueError): self.fixture.run()
