#!/usr/bin/env python3
"""Prepare a new local package input manifest only after accepted terminal native review."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import assemble_evidence as package


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--native-controls', required=True)
    parser.add_argument('--native-review', required=True)
    parser.add_argument('--native-review-sha256', required=True)
    parser.add_argument('--native-acceptance', required=True)
    parser.add_argument('--native-acceptance-sha256', required=True)
    parser.add_argument('--native-lineage-inventory', required=True)
    parser.add_argument('--native-lineage-inventory-sha256', required=True)
    args = parser.parse_args()
    package.frozen_source(args.source_freeze_sha256)
    plan = package.read(package.HERE / 'existing-inputs.json')
    files = dict(plan['files'])

    def bind(name):
        path = package.WORKSPACE / package.relative(name)
        observed = package.item(path)
        package.need(name not in files or files[name] == observed, 'historical input changed: ' + name)
        files[name] = observed
        return observed

    def capture(controls, phase):
        directory = controls + '/evidence/' + phase
        archive, receipt = controls + '/' + phase + '-evidence.tar.gz', controls + '/' + phase + '-collection-receipt.json'
        return {'directory': directory, 'archive': archive, 'receipt': receipt,
                'archive_record': bind(archive), 'receipt_record': bind(receipt),
                'manifest_record': bind(directory + '/transfer-manifest.json')}

    acceptance = bind(args.native_acceptance)
    package.need(acceptance['sha256'] == args.native_acceptance_sha256, 'native acceptance hash differs')
    package.need(bind(args.native_lineage_inventory)['sha256'] == args.native_lineage_inventory_sha256, 'final native lineage inventory differs')
    lineage = package.read(package.WORKSPACE / args.native_lineage_inventory)
    package.need(lineage['status'] == 'reviewed-complete' and lineage['phase'] == 'native-confirmation'
                 and lineage['review_sha256'] == args.native_review_sha256
                 and lineage['native_acceptance_sha256'] == args.native_acceptance_sha256,
                 'native source/launch/collection lineage has not been reviewed')
    package.need({'source_controls', 'preparation', 'stage', 'launch', 'collection', 'review', 'failed_admission'} <= set(lineage['coverage']),
                 'native lineage lacks a required control/attempt category')
    for name, expected in lineage['files'].items():
        package.need(bind(name) == expected, 'final native lineage payload differs')
    captures = dict(plan['captures'])
    captures['native'] = capture(args.native_controls, 'native-confirmation')
    reviews = dict(plan['reviews'])
    reviews['native'] = {'directory': args.native_review, 'review_sha256': args.native_review_sha256}
    for spec in reviews.values():
        for name in ('review.json', 'raw-integrity.json', 'effects.json', 'seal.json'):
            bind(spec['directory'] + '/' + name)
    source_prefix = str(package.HERE.relative_to(package.WORKSPACE))
    bind(source_prefix + '/source-freeze.json')
    source_freeze = package.read(package.HERE / 'source-freeze.json')
    for name in source_freeze['files']:
        bind(source_prefix + '/' + name)
    for name, expected in source_freeze['external_files'].items():
        package.need(bind(name) == expected, 'external packaging source changed')
    inputs = {'status': 'reviewed-ready', 'assembler_sha256': package.sha(package.HERE / 'assemble_evidence.py'),
              'packaging_source_freeze_sha256': args.source_freeze_sha256, 'files': files,
              'captures': captures, 'reviews': reviews,
              'native_acceptance': {'path': args.native_acceptance, 'record': acceptance},
              'native_lineage_inventory': {'path': args.native_lineage_inventory, 'sha256': args.native_lineage_inventory_sha256}}
    package.validate_native_lineage(lineage, inputs, plan)
    package.validate_recovery_lineage(lineage, inputs)
    # Validate the fixed native proof and root acceptance before creating final-inputs.
    reviewed_capture = package.verify_capture(captures['native'])
    review, unused_effects = package.phase_review(reviews['native'], reviewed_capture, 'native-confirmation')
    package.source_and_acceptance(inputs, review)
    for name, row in files.items():
        package.need(package.item(package.WORKSPACE / name) == row, 'input changed while preparing')
    package.frozen_source(args.source_freeze_sha256)
    destination = package.HERE / 'final-inputs'
    destination.mkdir(exist_ok=False)
    output = destination / 'inputs.json'
    with output.open('xb') as stream:
        stream.write(package.encoded(inputs))
    print(package.encoded({'status': 'prepared-not-assembled', 'inputs_sha256': package.sha(output)}).decode(), end='')


if __name__ == '__main__':
    main()
