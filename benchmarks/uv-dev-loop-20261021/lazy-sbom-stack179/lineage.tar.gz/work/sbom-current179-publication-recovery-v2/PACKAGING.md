This is source-only publication preparation. Native validation is pending. Neither helper may run on real inputs until both fixed native workflows are terminal, both independent raw audits pass, root accepts that exact review, and neither workflow establishes a native regression. No helper publishes, starts a process, contacts a host or recomputes statistics.

The draft is `PR.md`. `existing-inputs.json` is an immutable index of the current source, accepted IR, retained original archives and local failure/source lineage. Historical PR175 archives have a separate namespace and cannot satisfy any current179 gate. Original archives are copied exactly; any archive exceeding 90 MB is split losslessly into ordered byte chunks, with its original hash retained. No profiles are omitted to meet the Git blob limit.

After terminal native acceptance, root supplies a `reviewed-complete` native lineage inventory. It must bind every local native control, preparation, stage, launch, collection, review and failed-attempt record, with SHA256, size and mode. It must include `phase: native-confirmation`, the exact `review_sha256`, `native_acceptance_sha256`, `all_native_attempts_retained: true`, and coverage entries `source_controls`, `preparation`, `stage`, `launch`, `collection`, `review`, `failed_admission`. The known first native admission's failed status, SHA `653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2`, must appear in that final inventory. Its original capture and occupancy/log/history bytes are already indexed under `work/sbom-current179-native-failed-launch01`; any recovery must add its reviewed source and complete receipts without replacing those inputs.

The native acceptance uses `valid: true`, `authorized_operation: accept-current179-native-review-for-publication`, exact `accepted_native_review_sha256`, `accepted_ir_review_sha256`, `native_transfer_manifest_sha256`, `candidate_commit`, `candidate_tree`, plus `both_native_raw_audits_passed: true` and `no_established_native_regression: true`. These declarations accompany the actual sealed reviews and full capture; they do not replace their verification.

Prepare the final inputs only after those conditions, using workspace-relative paths:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-publication-recovery-v2/prepare_evidence_inputs.py \
  --source-freeze-sha256 REVIEWED_PACKAGING_FREEZE \
  --native-controls work/sbom-current179-ir-continuation \
  --native-review ACCEPTED_NATIVE_REVIEW_DIRECTORY \
  --native-review-sha256 ACCEPTED_NATIVE_REVIEW_SHA \
  --native-acceptance ROOT_NATIVE_ACCEPTANCE_PATH \
  --native-acceptance-sha256 ROOT_NATIVE_ACCEPTANCE_SHA \
  --native-lineage-inventory REVIEWED_NATIVE_LINEAGE_INDEX \
  --native-lineage-inventory-sha256 REVIEWED_NATIVE_LINEAGE_INDEX_SHA
```

Independently review the newly created `final-inputs/inputs.json` before assembly:

```
taskset -c 8 /usr/bin/python3 -I -B work/sbom-current179-publication-recovery-v2/assemble_evidence.py \
  --inputs work/sbom-current179-publication-recovery-v2/final-inputs/inputs.json \
  --inputs-sha256 REVIEWED_FINAL_INPUT_SHA
```

The initially absent output is `work/pr-evidence/lazy-sbom-stack179`, with an adjacent file manifest suitable for the existing private evidence publisher. Final assembly validates both complete captured file sets and original archive members, all accepted review seals, fixed counts/seeds and raw-table joins, unchanged IR bytes through native validation, exact source/CI and matched production identities. It creates final native text from the accepted summaries without recalculating statistics. It rehashes every copied input and checks its lossless archives before sealing the output. Failed assembly outputs remain present for diagnosis.

Root must review the completed package, update the local PR draft's native paragraph and immutable evidence link, then perform any publication. These helpers have no Git, network or PR operations. The archived build executables/runtime payloads are not duplicated; their hashes, full build/strip records and reproducible source inputs are retained.

This successor preserves the original source freeze `000ae22abdd25f1d13d8d831290903b62642a688671a74457e7c49cca5b34297` and its immutable 788-file catalog. Original source/CI records still resolve to `work/sbom-current179-publication`; the new helper does not publish or change them. The original archive, raw-review, effect-gate and summary logic is unchanged.

The final lineage inventory must additionally have a `recovery_bindings` object with exactly six keys, each containing a workspace-relative `path` and exact `sha256`:

- `lineage_review`: `work/sbom-current179-ir-continuation/independent-native-recovery-lineage-v2/review.json`.
- `root_acceptance_bridge`: `work/sbom-current179-ir-continuation/native-recovery-root-acceptance.json`.
- `lineage_execution_approval`: the actual root approval for the frozen v2 lineage checker.
- `raw_execution_approval`: the actual root approval named by the acceptance bridge.
- `lineage_execution_receipt`: `work/sbom-current179-ir-continuation/native-lineage-execution/receipt.json`.
- `raw_execution_receipt`: `work/sbom-current179-ir-continuation/native-raw-execution/receipt.json`.

All referenced files, the sealed lineage `local-inputs.json` and `seal.json`, every file indexed in that local input map, v2 source/frozen external inputs, the root source review, and the complete recovery/replay/execution directories must appear in the final lineage inventory's `files`. The assembler checks actual hashes, sizes, modes and exact ordinary file paths. It separately requires the retained extra quiet rejection, SHA `a1ad5f6ab1f0c4e4f53f7f31ec9051f13347dc91ee9d81dfafa59f6304d674ec`. No coverage label substitutes for those files.

The accepted v2 lineage source freeze is `1782c13172607d9dbd50baab7cb56e17a0ec668a138530a60e8b1298643e43ba`; root source review is `3a9b09c71a3a960d49cc24f67af6482bad594420bbd94d56a6666ae5ac38ccec`. Its report must bind the terminal native collection, the original 11 failed-admission files, all 20 retention files, 119 preserved originals, 101 byte-identical replay files, the exact recovery/copy receipts and successful replay approval `9522fac4...`. It does not substitute for the unchanged independent raw/statistical review.

The bridge uses the agreed root schema: `status: passed`, timezone-aware `accepted_at`, `phase: native-confirmation`, exact lineage source/root-source-review/review/seal/execution-approval hashes, absolute lineage directory, terminal collection receipt hash, full accepted IR hash, original raw reviewer freeze, absolute raw output and execution approval path/hash, `accepted_before_raw_review: true`, and `native_effects_inspected_or_computed: false`. The raw execution approval must also bind `accepted_native_recovery_lineage_review_sha256`. The original raw reviewer ignores that extra field; this packaging validator enforces it together with the bridge and actual execution receipt.

Both execution receipts use `returncode`, `started_at`, `finished_at`, `argv`, `approval_sha256`, `stdout_path`/`stdout_sha256`, and `stderr_path`/`stderr_sha256`. The raw receipt additionally has `bridge_sha256`. Streams are the sibling `stdout` and `stderr` files, with absolute paths in the receipt. The checker requires each exact original Python command (optionally prefixed by `taskset -c 8` or `/usr/bin/taskset -c 8`), successful return, and lineage execution/review completion before bridge acceptance before raw execution/review. Use absolute command arguments; the raw reviewer retains `-B` without `-I`, while the lineage checker retains `-I -B`. Clear inherited Python path/home/safe-path variables in the outer launch environment as reviewed.

Final input preparation and assembly remain held until root accepts the completed native raw review. The source-only synthetic checks create no real native input manifest, package, benchmark or effects. Their original 15 checks plus 17 recovery boundary checks pass on CPU 8.
