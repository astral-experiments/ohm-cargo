#!/usr/bin/env python3
"""Seal only publication-control source and synthetic tests, never native data."""
import ast
import copy
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
OLD = HERE.with_name('sbom-current179-publication')
REVIEW = HERE.parent / 'cargo-audit/sbom-publication-recovery-review'


def record(path):
    info = path.lstat()
    assert path.resolve() == path and stat.S_ISREG(info.st_mode)
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': info.st_size,
            'mode': stat.S_IMODE(info.st_mode)}


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def dump(node):
    return ast.dump(node, include_attributes=False)


def main():
    assert sorted(os.sched_getaffinity(0)) == [8]
    assert not (HERE / 'source-freeze.json').exists()
    protected = read(REVIEW / 'protected-inputs-before.json')
    assert protected == {name: record(WORKSPACE / name) for name in protected}
    write(REVIEW / 'protected-inputs-after.json', protected)
    old, new = [ast.parse((directory / 'assemble_evidence.py').read_text()) for directory in (OLD, HERE)]
    functions = [{node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)} for tree in (old, new)]
    changed = {'frozen_source', 'source_and_acceptance', 'main'}
    unchanged = sorted(set(functions[0]) - changed)
    assert set(functions[1]) - set(functions[0]) == {'validate_recovery_lineage'}
    assert all(dump(functions[0][name]) == dump(functions[1][name]) for name in unchanged)
    # The existing gates and matched-source checks are identical after relocating
    # only the two original source/CI input roots.
    source = copy.deepcopy(functions[1]['source_and_acceptance'])
    class OriginalSource(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='HERE', ctx=node.ctx), node) if node.id == 'PUBLICATION_SOURCE' else node
    assert dump(functions[0]['source_and_acceptance']) == dump(OriginalSource().visit(source))
    entry = copy.deepcopy(functions[1]['main'])
    added = [node for node in entry.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
             and isinstance(node.value.func, ast.Name) and node.value.func.id == 'validate_recovery_lineage']
    assert len(added) == 1
    entry.body.remove(added[0])
    assert dump(functions[0]['main']) == dump(entry)
    frozen = copy.deepcopy(functions[1]['frozen_source'])
    assert isinstance(frozen.body[-1], ast.For) and "external_files" in dump(frozen.body[-1])
    frozen.body.pop()
    assert dump(functions[0]['frozen_source']) == dump(frozen)
    old_assignments = {dump(n.targets[0]): dump(n.value) for n in old.body if isinstance(n, ast.Assign)}
    new_assignments = {dump(n.targets[0]): dump(n.value) for n in new.body if isinstance(n, ast.Assign)}
    assert all(new_assignments[name] == value for name, value in old_assignments.items())
    assert (HERE / 'test_assemble_evidence.py').read_bytes() == (OLD / 'test_assemble_evidence.py').read_bytes()
    assert (HERE / 'existing-inputs.json').read_bytes() == (OLD / 'existing-inputs.json').read_bytes()
    assert (HERE / 'snapshot_evidence_inputs.py').read_bytes() == (OLD / 'snapshot_evidence_inputs.py').read_bytes()
    tests = read(HERE / 'pure-checks.json')
    assert tests['valid'] and tests['tests'] == 32 and tests['errors'] == tests['failures'] == 0
    for name, expected in tests['source_sha256'].items():
        assert record(HERE / name)['sha256'] == expected
    deltas = []
    for name in ('assemble_evidence.py', 'prepare_evidence_inputs.py', 'run_packaging_checks.py',
                 'recovery_binding.py', 'test_recovery_binding.py', 'PACKAGING.md', 'EVIDENCE.md', 'VALIDATION.md'):
        prior = (OLD / name).read_text().splitlines(True) if (OLD / name).exists() else []
        deltas.extend(difflib.unified_diff(prior, (HERE / name).read_text().splitlines(True),
                                         fromfile='original/' + name, tofile='successor/' + name))
    with (HERE / 'source-delta.diff').open('x') as stream:
        stream.writelines(deltas)
    external = dict(protected)
    lineage = HERE.parent / 'sbom-current179-native-admission-review-v2'
    freeze = read(lineage / 'source-freeze.json')
    for path in [lineage / 'source-freeze.json', lineage / 'root-source-review.json'] + [lineage / name for name in freeze['files']]:
        external[str(path.relative_to(WORKSPACE))] = record(path)
    for name, expected in freeze['external_inputs'].items():
        path = Path(name)
        assert record(path) == expected
        external[str(path.relative_to(WORKSPACE))] = expected
    for name in ('review.json', 'seal.json'):
        path = HERE.parent / 'cargo-audit/sbom-native-admission-v2-review' / name
        external[str(path.relative_to(WORKSPACE))] = record(path)
    assertions = {'status': 'source-successor-ready-for-review', 'original_freeze_sha256': record(OLD / 'source-freeze.json')['sha256'],
        'original_protected_files_unchanged': len(protected), 'original_catalog_entries_unchanged': len(read(HERE / 'existing-inputs.json')['files']),
        'original_archives_unchanged': len(read(HERE / 'existing-inputs.json')['archives']),
        'exact_unchanged_assembler_functions': unchanged, 'all_original_constants_unchanged': True,
        'main_only_adds_recovery_validation': True, 'existing_source_and_ci_checks_only_relocate_original_input_root': True,
        'original_15_synthetic_tests_byte_identical': True, 'pure_tests_passed': 32,
        'new_tests_use_synthetic_documents_and_hash_standins_only': True,
        'source_delta_sha256': record(HERE / 'source-delta.diff')['sha256'],
        'real_native_collection_or_effects_inspected': False, 'real_preparation_or_assembly_executed': False,
        'host_or_publication_operations': False, 'statistical_or_runtime_changes': False}
    write(HERE / 'source-review.json', assertions)
    files = {str(path.relative_to(HERE)): record(path) for path in sorted(HERE.rglob('*')) if path.is_file()}
    result = {'status': 'source-only-native-pending', 'created_at': datetime.now(timezone.utc).isoformat(),
        'files': files, 'external_files': external, 'predecessor_source_freeze_sha256': assertions['original_freeze_sha256'],
        'existing_indexed_inputs': 788, 'existing_original_archives': 17, 'tests': 32,
        'scope': 'Require the accepted v2 native admission lineage and actual root bridge before unchanged raw-review publication gates.',
        'real_packaging_executed': False, 'statistics_recomputed': False, 'host_operations': False, 'publication_operations': False}
    write(HERE / 'source-freeze.json', result)
    assert protected == {name: record(WORKSPACE / name) for name in protected}
    print(json.dumps({'source_freeze_sha256': record(HERE / 'source-freeze.json')['sha256'],
                      'files': len(files), 'external_files': len(external), 'pure_tests': 32}, sort_keys=True))


if __name__ == '__main__':
    main()
