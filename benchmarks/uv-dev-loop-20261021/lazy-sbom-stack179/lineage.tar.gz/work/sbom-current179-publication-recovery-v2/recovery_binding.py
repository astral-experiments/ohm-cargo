"""Join the accepted admission proof to the unchanged native raw review.

This module only reads final local evidence. It never runs the lineage checker,
raw reviewer, a workload, or statistical code.
"""
from datetime import datetime
from pathlib import Path

CONTROLS = 'work/sbom-current179-ir-continuation'
LINEAGE_SOURCE = 'work/sbom-current179-native-admission-review-v2'
LINEAGE_DIRECTORY = CONTROLS + '/independent-native-recovery-lineage-v2'
RAW_DIRECTORY = CONTROLS + '/independent-native-review-profiler-alias-v2'
BRIDGE_PATH = CONTROLS + '/native-recovery-root-acceptance.json'
LINEAGE_EXECUTION = CONTROLS + '/native-lineage-execution/receipt.json'
RAW_EXECUTION = CONTROLS + '/native-raw-execution/receipt.json'
LINEAGE_FREEZE = '1782c13172607d9dbd50baab7cb56e17a0ec668a138530a60e8b1298643e43ba'
SOURCE_REVIEW = '3a9b09c71a3a960d49cc24f67af6482bad594420bbd94d56a6666ae5ac38ccec'
RAW_FREEZE = '97cdbcc36928777579b1b3c6e5b8adf7bdae37d97a2b0f2200a57cdd0ec4f067'
IR_REVIEW = '242bc12bdd883f25a56baf59f5e6a16666e8f8f8b7d5819dbcaa21ad8e907d17'
RECOVERY_FREEZE = 'fed0cb323383c6188aa1693289dbe0d18fd5dd05ecfa28d1224387b8ec0fbe49'
CONTROLS_FREEZE = 'af6c551f3ddd21562dd7859d67ec885d24507a256fabecccd653459df78ebf67'
PREREQUISITE = 'b24ace5a04c82adde807489b4d28a8a1a4e708430f9d73f9ad0e81d17c470b48'
CONTROLLER = 'd1f05e3909e83fccb93c4d1c8b6445921333a68cddc275f888198121dc5177fb'
RECOVERY_RECEIPT = '1555558513978b704f712042865da24e9abf51275c5e385a863397a658a526bf'
COPY_RECEIPT = 'ab6ae081747d1ae39a8f19ff9f9371fe32569c0357dc58e04b36e0f9590a4a6d'
LAUNCH_APPROVAL = '9522fac4b0dd275e7ae50b33e03597c48975fbe77f66916370ce395c51f1b20b'
QUIET_STDERR = 'a1ad5f6ab1f0c4e4f53f7f31ec9051f13347dc91ee9d81dfafa59f6304d674ec'


def instant(value, need):
    moment = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(moment.tzinfo is not None, 'execution/acceptance timestamp lacks timezone')
    return moment


def validate(document, inputs, workspace, item, read, need, relative):
    """Every consumed input must be retained in both final file inventories."""
    files = inputs['files']

    def bound(name, expected=None):
        name = str(relative(name))
        need(name in files and document['files'].get(name) == files[name],
             'recovery prerequisite omitted from final lineage: ' + name)
        need(item(workspace / name) == files[name], 'recovery prerequisite changed: ' + name)
        if expected is not None:
            need(files[name]['sha256'] == expected, 'recovery prerequisite hash differs: ' + name)
        return files[name]

    def load(name, expected=None):
        bound(name, expected)
        return read(workspace / name)

    def local(value):
        path = Path(value)
        need(path.is_absolute() and path.is_relative_to(workspace / 'work'), 'input outside owned work directory')
        return str(path.relative_to(workspace))

    def reference(key, fixed=None):
        row = document['recovery_bindings'][key]
        need(set(row) == {'path', 'sha256'} and (fixed is None or row['path'] == fixed),
             'recovery binding shape/path differs: ' + key)
        return row['path'], load(row['path'], row['sha256'])

    def retain_tree(prefix):
        root = workspace / prefix
        need(root.is_dir() and root.resolve() == root, 'required local lineage root absent')
        for path in root.rglob('*'):
            need(not path.is_symlink() and (path.is_file() or path.is_dir()), 'special local lineage member')
            if path.is_file():
                bound(str(path.relative_to(workspace)))

    lineage_path, lineage = reference('lineage_review', LINEAGE_DIRECTORY + '/review.json')
    bridge_path, bridge = reference('root_acceptance_bridge', BRIDGE_PATH)
    lineage_approval_path, lineage_approval = reference('lineage_execution_approval')
    raw_approval_path, raw_approval = reference('raw_execution_approval')
    lineage_execution_path, lineage_execution = reference('lineage_execution_receipt', LINEAGE_EXECUTION)
    raw_execution_path, raw_execution = reference('raw_execution_receipt', RAW_EXECUTION)
    need(set(document['recovery_bindings']) == {
        'lineage_review', 'root_acceptance_bridge', 'lineage_execution_approval',
        'raw_execution_approval', 'lineage_execution_receipt', 'raw_execution_receipt'},
        'unknown or missing recovery binding')
    source_review = load(LINEAGE_SOURCE + '/root-source-review.json', SOURCE_REVIEW)
    need(source_review['status'] == 'passed' and source_review['source_freeze_sha256'] == LINEAGE_FREEZE,
         'lineage source not accepted')
    freeze = load(LINEAGE_SOURCE + '/source-freeze.json', LINEAGE_FREEZE)
    for name, row in freeze['files'].items():
        need(bound(LINEAGE_SOURCE + '/' + str(relative(name))) == row, 'lineage source file omitted/changed')
    for name, row in freeze['external_inputs'].items():
        need(bound(local(name)) == row, 'lineage source external input omitted/changed')
    seal = load(LINEAGE_DIRECTORY + '/seal.json')
    need(set(seal) == {'review.json', 'local-inputs.json'}, 'lineage review seal differs')
    for name, row in seal.items():
        need(bound(LINEAGE_DIRECTORY + '/' + name) == row, 'lineage sealed output differs')
    index = load(LINEAGE_DIRECTORY + '/local-inputs.json', lineage['local_inputs_sha256'])
    for name, row in index['files'].items():
        need(bound(local(name)) == row, 'reviewed recovery input omitted/changed')
    capture = inputs['captures']['native']
    collection_sha = capture['receipt_record']['sha256']
    transfer_sha = capture['manifest_record']['sha256']
    need(index['native_transfer_manifest_sha256'] == transfer_sha, 'lineage local index uses another collection')
    expected = {
        'valid': True, 'phase': 'native-confirmation', 'source_freeze_sha256': LINEAGE_FREEZE,
        'original_reviewer_source_freeze_sha256': RAW_FREEZE, 'accepted_ir_review_sha256': IR_REVIEW,
        'original_controls_source_freeze_sha256': CONTROLS_FREEZE, 'recovery_source_freeze_sha256': RECOVERY_FREEZE,
        'prerequisite_manifest_sha256': PREREQUISITE, 'original_native_controller_sha256': CONTROLLER,
        'retained_failure_files': 11, 'retention_files': 20, 'original_local_files_preserved': 119,
        'byte_identical_replay_files': 101, 'both_fixed_native_workflows_terminal': True,
        'native_pairs_per_workflow': 30, 'native_warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
        'native_effects_inspected_or_computed': False, 'original_both_workflow_raw_and_statistical_review_required': True,
        'final_rehash': 'passed', 'collection_receipt_sha256': collection_sha,
        'transfer_manifest_sha256': transfer_sha, 'approval_sha256': files[lineage_approval_path]['sha256'],
        'recovery_receipt_sha256': RECOVERY_RECEIPT, 'replay_copy_receipt_sha256': COPY_RECEIPT,
        'launch_approval_sha256': LAUNCH_APPROVAL,
    }
    need(all(type(lineage.get(key)) is type(value) and lineage[key] == value for key, value in expected.items()),
         'accepted recovery proof identity/scope differs')
    need(lineage_approval['valid'] is True
         and lineage_approval['authorized_operation'] == 'review-zero-work-native-recovery-lineage'
         and lineage_approval['source_freeze_sha256'] == LINEAGE_FREEZE
         and lineage_approval['output'] == str(workspace / LINEAGE_DIRECTORY)
         and lineage_approval['collection_receipt_sha256'] == collection_sha
         and lineage_approval['recovery_receipt_sha256'] == RECOVERY_RECEIPT
         and lineage_approval['replay_copy_receipt_sha256'] == COPY_RECEIPT
         and lineage_approval['launch_approval_sha256'] == LAUNCH_APPROVAL, 'lineage execution approval differs')
    expected_bridge = {
        'status': 'passed', 'phase': 'native-confirmation', 'lineage_source_freeze_sha256': LINEAGE_FREEZE,
        'lineage_source_review_sha256': SOURCE_REVIEW, 'lineage_review_directory': str(workspace / LINEAGE_DIRECTORY),
        'lineage_review_sha256': files[lineage_path]['sha256'],
        'lineage_seal_sha256': files[LINEAGE_DIRECTORY + '/seal.json']['sha256'],
        'lineage_execution_approval_sha256': files[lineage_approval_path]['sha256'],
        'collection_receipt_sha256': collection_sha, 'accepted_ir_review_sha256': IR_REVIEW,
        'original_raw_reviewer_source_freeze_sha256': RAW_FREEZE,
        'raw_review_output': str(workspace / RAW_DIRECTORY),
        'raw_review_execution_approval_path': str(workspace / raw_approval_path),
        'raw_review_execution_approval_sha256': files[raw_approval_path]['sha256'],
        'accepted_before_raw_review': True, 'native_effects_inspected_or_computed': False,
    }
    need(all(type(bridge.get(key)) is type(value) and bridge[key] == value for key, value in expected_bridge.items()),
         'root acceptance bridge does not bind this lineage and raw approval')
    need(raw_approval['valid'] is True and raw_approval['phase'] == 'native-confirmation'
         and raw_approval['source_freeze_sha256'] == RAW_FREEZE
         and raw_approval['output'] == str(workspace / RAW_DIRECTORY)
         and raw_approval['collection_receipt_sha256'] == collection_sha
         and raw_approval['accepted_ir_review_sha256'] == IR_REVIEW
         and raw_approval['accepted_native_recovery_lineage_review_sha256'] == files[lineage_path]['sha256'],
         'raw execution approval lacks exact accepted lineage')
    need(inputs['reviews']['native']['directory'] == RAW_DIRECTORY, 'unexpected native raw review output')
    raw_review = load(RAW_DIRECTORY + '/review.json', inputs['reviews']['native']['review_sha256'])
    need(raw_review['approval_sha256'] == files[raw_approval_path]['sha256']
         and raw_review['source_freeze_sha256'] == RAW_FREEZE
         and raw_review['collection_receipt_sha256'] == collection_sha
         and raw_review['transfer_manifest_sha256'] == transfer_sha, 'raw result/approval/collection join differs')

    def execution(value, path, approval_path, argv):
        need(type(value['returncode']) is int and value['returncode'] == 0
             and value['approval_sha256'] == files[approval_path]['sha256'], 'review execution failed or used another approval')
        need(value['argv'] in (argv, ['taskset', '-c', '8'] + argv, ['/usr/bin/taskset', '-c', '8'] + argv),
             'review command differs from unchanged approved invocation')
        for stream in ('stdout', 'stderr'):
            name = local(value[stream + '_path'])
            need(name == str(Path(path).parent / stream), 'review stream path differs')
            bound(name, value[stream + '_sha256'])
        need(instant(value['started_at'], need) <= instant(value['finished_at'], need), 'review execution chronology differs')

    lineage_argv = ['/usr/bin/python3', '-I', '-B', str(workspace / LINEAGE_SOURCE / 'review_recovery.py'),
                    '--source-freeze-sha256', LINEAGE_FREEZE, '--approval', str(workspace / lineage_approval_path),
                    '--approval-sha256', files[lineage_approval_path]['sha256'], '--output', str(workspace / LINEAGE_DIRECTORY)]
    raw_argv = ['/usr/bin/python3', '-B', str(workspace / 'work/sbom-current179-ir-reviewer-profiler-alias-v2/review.py'),
                'native-confirmation', '--controls', str(workspace / CONTROLS), '--approval', str(workspace / raw_approval_path),
                '--output', str(workspace / RAW_DIRECTORY), '--accepted-ir',
                str(workspace / CONTROLS / 'independent-ir-review-profiler-alias-v2')]
    execution(lineage_execution, lineage_execution_path, lineage_approval_path, lineage_argv)
    execution(raw_execution, raw_execution_path, raw_approval_path, raw_argv)
    need(raw_execution['bridge_sha256'] == files[bridge_path]['sha256'], 'raw execution ignored accepted bridge')
    need(instant(lineage_execution['started_at'], need) <= instant(lineage['reviewed_at'], need)
         <= instant(lineage_execution['finished_at'], need) <= instant(bridge['accepted_at'], need)
         <= instant(raw_execution['started_at'], need) <= instant(raw_review['reviewed_at'], need)
         <= instant(raw_execution['finished_at'], need), 'lineage/bridge/raw chronology differs')
    for prefix in ('work/sbom-current179-native-admission-recovery', 'work/sbom-current179-native-launch-replay02',
                   LINEAGE_DIRECTORY, str(Path(LINEAGE_EXECUTION).parent), str(Path(RAW_EXECUTION).parent)):
        retain_tree(prefix)
    bound('work/sbom-current179-native-admission-recovery/launch-quiet.stderr', QUIET_STDERR)
    bound('work/sbom-current179-native-admission-recovery/launch-quiet.stdout')
