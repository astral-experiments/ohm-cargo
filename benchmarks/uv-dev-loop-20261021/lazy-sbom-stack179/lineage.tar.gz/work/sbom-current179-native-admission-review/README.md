# Native collection after the zero-work admission failure

This is a local, metadata-only join before the existing raw/statistical review. It does not collect remotely, run Cargo, inspect native effects, retry a phase, or change the original collector or reviewer. Its process audit hook forbids subprocesses and sockets.

The original fixed native protocol is **30 pairs plus two warmup pairs, one invocation per variant**, first dirty `cargo test --no-run` and then dirty `cargo check`, seeds **20261021103 / 20261021104**. This is not the eight-call warm-loop protocol used for other candidates. The expected dirty compilation is intentional; the unchanged raw reviewer checks the exact source/rlink compiler inventory and absence of test execution.

## Terminal collection

The root agent owns all remote operations. Wait until the actual `ohm-sbom179-native-confirmation-01` session has ended and the terminal phase status is complete with both workflows. A failed or partial phase is retained as a separate failure capture; it must not be passed to a successful-completion review or retried automatically.

Use the **unchanged** collector, once, into its previously absent native destination:

```sh
taskset -c 8 /usr/bin/python3 -I -B \
  work/sbom-current179-ir-continuation/collect.py \
  --finalized-sha256 f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad \
  --capsule-manifest-sha256 16d2816d9fdbfe54d383acb524815c22692714948aab00ca79677116f7eb11cc \
  native-confirmation
```

This creates `work/sbom-current179-ir-continuation/evidence/native-confirmation`, the adjacent `native-confirmation-evidence.tar.gz`, collection receipt, and transport stderr. The collector requires the complete fixed phase and both batch manifests/seals. Its recursive `continuations/` selection already includes the 20-file retention directory, the 11 relocated failed-admission files, and the new canonical launch and actual-entry receipts. No collector source adaptation is needed. Preserve the original archive and receipt rather than extracting and repacking them for publication.

## Recovery lineage before effects

Root reviews this source freeze, then writes a new execution approval containing:

```json
{
  "valid": true,
  "authorized_operation": "review-zero-work-native-recovery-lineage",
  "source_freeze_sha256": "<this directory's reviewed source-freeze SHA256>",
  "output": "<absolute new lineage-review directory>",
  "collection_receipt_sha256": "<completed native collection receipt SHA256>",
  "recovery_receipt_sha256": "1555558513978b704f712042865da24e9abf51275c5e385a863397a658a526bf",
  "replay_copy_receipt_sha256": "ab6ae081747d1ae39a8f19ff9f9371fe32569c0357dc58e04b36e0f9590a4a6d",
  "launch_approval_sha256": "<actual successful replay root approval SHA256>"
}
```

Then run locally:

```sh
taskset -c 8 /usr/bin/python3 -I -B \
  work/sbom-current179-native-admission-review/review_recovery.py \
  --source-freeze-sha256 <reviewed-freeze-sha256> \
  --approval <absolute-root-lineage-execution-approval.json> \
  --approval-sha256 <approval-sha256> \
  --output <absolute-new-lineage-review-directory>
```

The checker authenticates the original collector output using the unchanged evidence reader. It requires complete manifests for both fixed native workflows before returning a lineage proof. It then joins:

- The exact failed status `653300…`, original captured 11 files, five metadata rename units, preserved occupancy output, recovery request/source/approval, full origin/hash/mode map, retention seal and independent root acceptance.
- All 119 original local files at their original paths and the 101 byte-identical, independently allocated replay files, including the old preparation/stage evidence. The first `launch-attempt01` remains in the original directory; the new launch is in the sibling replay directory.
- The copy approval/execution/receipt, actual new local and remote launch receipts, the root launch approval's recovery/copy joins, unchanged prerequisite manifest `b24ace…`, and the actual child environment/entry receipt.
- The original controller `d1f05e…`, source freeze `af6c55…`, protocol and configs, inherited build environment, machine identity, and entry-before-phase chronology.

It records every actual local recovery and replay file, including supplemental quiet-guard failures and transport streams, and rehashes them before sealing `review.json`, `local-inputs.json`, and `seal.json`. The earlier failed extra quiet check is an admission record, not a native observation. A transport error, missing receipt, changed file, or incomplete workflow stops this procedure; no inference is made that a failed transport implies an unstarted remote process.

This lineage proof **does not claim that the raw samples or statistical gates passed**. The original raw reviewer remains mandatory.

## Unchanged raw/statistical review

After accepting the lineage proof, root creates a separate execution approval for the existing reviewer. Include its existing required fields:

```json
{
  "valid": true,
  "source_freeze_sha256": "97cdbcc36928777579b1b3c6e5b8adf7bdae37d97a2b0f2200a57cdd0ec4f067",
  "phase": "native-confirmation",
  "output": "<absolute new raw-review directory>",
  "collection_receipt_sha256": "<same completed native receipt SHA256>",
  "accepted_ir_review_sha256": "242bc12bdd883f25a56baf59f5e6a16666e8f8b7d5819dbcaa21ad8e907d17",
  "accepted_native_recovery_lineage_review_sha256": "<accepted lineage review SHA256>"
}
```

The last field is a root acceptance join. The unchanged raw reviewer does not interpret it; root's separate acceptance record must bind the exact lineage proof, collection receipt, and raw-review execution approval **before** invoking the reviewer. Do not mistake an ignored extra field for an enforced guard.

```sh
taskset -c 8 /usr/bin/python3 -B \
  work/sbom-current179-ir-reviewer-profiler-alias-v2/review.py \
  native-confirmation \
  --controls work/sbom-current179-ir-continuation \
  --approval <absolute-root-native-raw-review-approval.json> \
  --output <absolute-new-native-raw-review-directory> \
  --accepted-ir work/sbom-current179-ir-continuation/independent-ir-review-profiler-alias-v2
```

The unchanged reviewer audits **both** raw workflows before computing any native effects. It recomputes the fixed plans, every JSON/JSONL/CSV and compiler-execution join, the 30-pair statistics, bootstrap 99% intervals with 20,000 resamples and seed 1701, sign and order gates, and no-established-regression decisions. It must not pool other binaries, phases, or attempts. An incomplete second workflow never unlocks analysis of the first.

The direct raw-reviewer invocation intentionally omits Python `-I`: its unchanged sibling imports require the script directory on `sys.path`. Clear inherited `PYTHONPATH`, `PYTHONHOME`, and `PYTHONSAFEPATH` before this existing command. The new lineage checker and original collector support `-I`.

## Publication inputs

Add this source freeze, its independent source review, both root execution/acceptance approvals, the completed lineage proof and input index, the unchanged raw reviewer and its final proof, all original/replay/recovery inputs indexed here, and all native collection outputs to the final native lineage inventory consumed by `work/sbom-current179-publication`. Preserve the original 11-file capture and the 20-file retention capture separately. The existing publication assembler remains conditional on both native raw audits and no established native regression. It must report the secondary check IR result below the 1% threshold and must not turn a lineage-only pass into a performance claim.
