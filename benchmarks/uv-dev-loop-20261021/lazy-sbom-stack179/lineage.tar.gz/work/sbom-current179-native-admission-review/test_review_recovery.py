"""Pure/small retained-metadata tests; never construct a native Collection."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('admission_lineage_under_test', HERE / 'review_recovery.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def read(path):
    return json.loads(path.read_bytes())


class RecoveryLineageTests(unittest.TestCase):
    def setUp(self):
        self.capture = read(m.WORK / 'sbom-current179-native-failed-launch01/capture.json')
        self.receipt = read(m.RECOVERY / 'retention-attempt01/remote-receipt.json')
        self.plan = copy.deepcopy(self.receipt['retained_files'])
        self.index = read(m.RECOVERY / 'replay-copy-inputs.json')
        self.copied = read(m.RECOVERY / 'replay-copy-receipt.json')

    def terminal(self):
        protocol = read(m.REVIEWER / 'reference/protocol.json')
        hashes = {'test-native-confirmation': 'test-config', 'check-native-confirmation': 'check-config'}
        manifests = {}
        for phase in protocol['phases']:
            if phase['metric'] != 'native_wall_seconds':
                continue
            manifests[phase['workload']] = {
                'state': 'complete', 'phase': 'confirmation', 'pairs': 30, 'warmup_pairs': 2,
                'seed': phase['seed'], 'sample_count': 64,
                'plans': {'warmup': phase['warmup_plan'], 'measurement': phase['measurement_plan']},
                'configuration_sha256': hashes[phase['workload'] + '-native-confirmation'],
            }
        state = {'state': 'complete', 'group': 'native-confirmation',
                 'completed_workloads': ['test', 'check'], 'source_restored': True}
        return state, manifests, protocol['phases'], hashes

    def test_retained_11_file_metadata_corpus(self):
        m.check_retention_map(self.capture, self.receipt, self.plan)

    def test_retention_rejects_missing_file(self):
        self.plan.pop(next(iter(self.plan)))
        with self.assertRaises(ValueError):
            m.check_retention_map(self.capture, self.receipt, self.plan)

    def test_retention_rejects_wrong_origin_hash_and_mode(self):
        for field, wrong in [('origin', '/tmp/another-source'), ('sha256', '0' * 64), ('mode', 0)]:
            with self.subTest(field=field):
                plan = copy.deepcopy(self.plan)
                plan[next(iter(plan))][field] = wrong
                receipt = {**self.receipt, 'retained_files': plan}
                with self.assertRaises(ValueError):
                    m.check_retention_map(self.capture, receipt, plan)

    def test_retention_cannot_authorize_measurements(self):
        for key in ('native_workload_or_analysis_executed', 'replay_authorized_by_this_receipt'):
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.check_retention_map(self.capture, {**self.receipt, key: True}, self.plan)

    def test_actual_101_file_copy_metadata(self):
        m.check_copy(self.copied, self.index, self.copied['recovery_receipt_sha256'])

    def test_copy_requires_exact_119_and_101_maps(self):
        for key in ('protected_original_files', 'copied_files'):
            index = copy.deepcopy(self.index)
            index[key].pop(next(iter(index[key])))
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.check_copy(self.copied, index, self.copied['recovery_receipt_sha256'])

    def test_copy_requires_recovery_identity_and_preservation(self):
        with self.assertRaises(ValueError):
            m.check_copy(self.copied, self.index, '0' * 64)
        with self.assertRaises(ValueError):
            m.check_copy({**self.copied, 'all_original_local_paths_unchanged': False}, self.index,
                         self.copied['recovery_receipt_sha256'])

    def test_both_complete_fixed_native_plans(self):
        m.terminal_metadata(*self.terminal())

    def test_incomplete_second_workflow_blocks(self):
        for change in ('state', 'manifest'):
            state, manifests, phases, hashes = self.terminal()
            if change == 'state':
                state['completed_workloads'] = ['test']
            else:
                manifests['check']['state'] = 'running'
            with self.subTest(change=change), self.assertRaises(ValueError):
                m.terminal_metadata(state, manifests, phases, hashes)

    def test_wrong_counts_seed_or_plan_block(self):
        for field, wrong in [('pairs', 31), ('warmup_pairs', 3), ('sample_count', 66), ('seed', 20261021105)]:
            args = self.terminal()
            args[1]['test'][field] = wrong
            with self.subTest(field=field), self.assertRaises(ValueError):
                m.terminal_metadata(*args)
        args = self.terminal()
        args[1]['test']['plans'] = {'warmup': [], 'measurement': []}
        with self.assertRaises(ValueError):
            m.terminal_metadata(*args)

    def test_eight_call_protocol_is_not_accepted(self):
        args = self.terminal()
        next(p for p in args[2] if p['metric'] == 'native_wall_seconds')['invocations_per_variant_per_pair'] = 8
        with self.assertRaises(ValueError):
            m.terminal_metadata(*args)

    def test_unsafe_paths_and_symlinks_rejected(self):
        for name in ('../escape', '/absolute', 'a/../b', 'a\\b', '.', '', None):
            with self.subTest(name=name), self.assertRaises(ValueError):
                m.relative(name)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            (root / 'ordinary').write_text('metadata')
            (root / 'alias').symlink_to('ordinary')
            self.assertEqual(m.record(root / 'ordinary')['bytes'], 8)
            with self.assertRaises(ValueError):
                m.record(root / 'alias')

    def test_execution_and_network_audit_guard(self):
        for event in ('subprocess.Popen', 'socket.connect', 'socket.getaddrinfo', 'os.exec',
                      'os.spawn', 'os.posix_spawn', 'os.system', 'pty.spawn'):
            with self.subTest(event=event), self.assertRaises(ValueError):
                m.no_execution(event, ())
        m.no_execution('open', ())
        m.no_execution('import', ())

    def test_checker_never_imports_statistics_or_reads_native_analysis(self):
        tree = ast.parse((HERE / 'review_recovery.py').read_text())
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names.update(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                names.add(node.module)
        self.assertFalse(names & {'statistics', 'statistics_review', 'subprocess', 'socket', 'raw', 'review'})
        self.assertFalse(any(isinstance(node, ast.Constant) and isinstance(node.value, str)
                             and '/analysis.json' in node.value for node in ast.walk(tree)))
        source = (HERE / 'review_recovery.py').read_text()
        self.assertLess(source.index('terminal_metadata(phase_state'), source.index('recovery_sha = retention('))

    def test_unchanged_interfaces_match_documented_commands_and_scope(self):
        collector = (m.CONTROLS / 'collect.py').read_text()
        reviewer = (m.REVIEWER / 'review.py').read_text()
        self.assertIn("'continuations'", collector)
        self.assertIn('--finalized-sha256', collector)
        self.assertIn('--capsule-manifest-sha256', collector)
        self.assertIn("'--accepted-ir'", reviewer)
        self.assertLess(reviewer.index('raw[workload] = audit_workload'), reviewer.index("effects = {'phase': collection.phase"))
        paired = (m.REVIEWER / 'reference/paired.py').read_text()
        self.assertIn('"inherited_build_environment": build_environment_metadata()', paired)


if __name__ == '__main__':
    unittest.main(verbosity=2)
