"""Build inspectable path-only adaptations from already reviewed frozen sources."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import stat

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
OLD = WORK / 'dirty-sbom-current179'
FAILED = OLD / 'evidence/ir-failed-before-check'
REMOTE = '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179'
NEW = REMOTE + '/results/ir-completion-01'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def substitute(source, old, new, count=1):
    assert source.count(old) == count, (old, source.count(old))
    return source.replace(old, new)


def module_source(nodes):
    return ast.unparse(ast.Module(body=nodes, type_ignores=[])) + '\n'


def main():
    copies = {
        'original/run_group.py': FAILED / 'work/benchmark/run_group.py',
        'original/paired.py': FAILED / 'work/benchmark/paired.py',
        'original/collector.py': OLD / 'collect_completed_group.py',
        'boundary.py': OLD / 'failed-phase-preservation/boundary.py',
        'failed/transfer-manifest.json': FAILED / 'transfer-manifest.json',
        'failed/failure-boundary.json': FAILED / 'failure-boundary.json',
        'failed/status.json': FAILED / 'results/ir-confirmation.json',
        'failed/check-journal.jsonl': FAILED / 'fixtures/check-ir-confirmation/journal.jsonl',
        'failed/receipt.json': OLD / 'ir-failed-before-check-collection-receipt.json',
        'failed/root-review.json': OLD / 'root-ir-failure-preservation-review.json',
        'failed/launch-ir-confirmation-attempt01.json': OLD / 'launch-ir-confirmation-attempt01.json',
        'failed/terminal.json': OLD / 'ir-terminal-161149471831.json',
    }
    for name, source in copies.items():
        target = HERE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o644)
    original = (HERE / 'original/run_group.py').read_text()
    tree = ast.parse(original)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    attempt = next(node for node in function.body if isinstance(node, ast.Try))
    loop_index = next(index for index, node in enumerate(attempt.body)
                      if isinstance(node, ast.For) and ast.unparse(node.target) == 'workload')
    loop = module_source([attempt.body[loop_index]])
    transformed = substitute(loop, "for workload in ('test', 'check'):", "for workload in ('check',):")
    transformed = substitute(transformed, "result = ROOT / 'results' / name", f"result = Path({NEW + '/check'!r})")
    transformed = substitute(transformed, "ROOT / 'metadata' / f'{name}-occupancy.txt'", f"Path({NEW + '/check-occupancy.txt'!r})")
    for suffix in ('stdout', 'stderr'):
        transformed = substitute(transformed, "ROOT / 'logs' / f'{name}.run." + suffix + "'",
                                 f"Path({NEW + '/check.run.' + suffix!r})")
    (HERE / 'check-loop.py').write_text(transformed)
    tail = module_source(attempt.body[loop_index + 1:])
    transformed_tail = tail
    for suffix in ('stdout', 'stderr'):
        transformed_tail = substitute(transformed_tail,
            "ROOT / 'logs' / f'{workload}-{args.group}.analysis." + suffix + "'",
            f"Path({NEW + '/analysis-logs'!r}) / f'{{workload}}-{{args.group}}.analysis.{suffix}'")
    (HERE / 'analysis-tail.py').write_text(transformed_tail)
    native = substitute(original, "ROOT / 'results' / f'{previous}.json'", f"Path({NEW + '/status.json'!r})")
    (HERE / 'native-original-controller.py').write_text(native)
    boundary = ast.parse((HERE / 'boundary.py').read_text())
    verifier = next(node for node in boundary.body if isinstance(node, ast.FunctionDef) and node.name == 'verify_boundary')
    begin = next(index for index, node in enumerate(verifier.body) if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == 'final' for target in node.targets))
    pure = ast.Module(body=verifier.body[begin:-1], type_ignores=[])
    identities = {'original_controller_sha256': sha(HERE / 'original/run_group.py'),
                  'check_loop_sha256': sha(HERE / 'check-loop.py'),
                  'analysis_tail_sha256': sha(HERE / 'analysis-tail.py'),
                  'native_controller_sha256': sha(HERE / 'native-original-controller.py'),
                  'pure_test_audit_ast_sha256': hashlib.sha256(ast.dump(pure, include_attributes=False).encode()).hexdigest(),
                  'check_loop_changes': ['limit original workload tuple to check', 'new result directory',
                                         'new occupancy path', 'new stdout path', 'new stderr path'],
                  'analysis_tail_changes': ['new stdout path', 'new stderr path'],
                  'native_controller_changes': ['lookup completed continuation status instead of retained failed status']}
    write(HERE / 'adaptation-identities.json', identities)
    diffs = []
    for before, after, name in ((loop, transformed, 'check-loop'), (tail, transformed_tail, 'analysis-tail'),
                               (original, native, 'native-original-controller')):
        diffs.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                         fromfile='frozen/' + name, tofile='continued/' + name))
    (HERE / 'controller-adaptations.diff').write_text(''.join(diffs))
    print(json.dumps({'valid': True, 'identities': identities}, indent=2))


if __name__ == '__main__':
    main()
