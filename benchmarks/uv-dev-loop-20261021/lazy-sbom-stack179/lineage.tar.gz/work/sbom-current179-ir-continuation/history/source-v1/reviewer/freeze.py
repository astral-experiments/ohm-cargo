"""Freeze source/checks after preparation; never inspect comparative outcomes."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = ROOT / 'source-freeze.json'
    if destination.exists():
        raise ValueError('preserve the existing source freeze')
    checks = json.loads((ROOT / 'pure-checks.json').read_text())
    if checks['returncode'] != 0 or checks['valid'] is not True or checks['tests'] != 23:
        raise ValueError('pure checks did not pass')
    for name, expected in checks['source_sha256'].items():
        if sha(ROOT / name) != expected:
            raise ValueError('source changed after pure checks: ' + name)
    for suffix in ('stdout', 'stderr'):
        if sha(ROOT / ('pure-checks.' + suffix)) != checks[suffix + '_sha256']:
            raise ValueError('pure-check transcript changed')
    files = {}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.name == 'source-freeze.json':
            continue
        if path.is_symlink() or '__pycache__' in path.parts:
            raise ValueError('unexpected source-package file')
        if path.suffix == '.py':
            ast.parse(path.read_text(), filename=str(path))
        files[str(path.relative_to(ROOT))] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    record = {'created_at': datetime.now(timezone.utc).isoformat(), 'files': files,
              'pure_tests_passed': 23, 'comparative_effects_inspected': False,
              'host_actions_performed': False, 'measurement_or_compiler_execution_performed': False,
              'scope': 'Source-only independent current179 SBOM reviewer; root source/terminal-collection approval required before use.'}
    with destination.open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'files': len(files), 'source_freeze_sha256': sha(destination)}))


if __name__ == '__main__':
    main()
