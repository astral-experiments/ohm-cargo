# Independent current179 SBOM review

This package reviews already-collected evidence locally. It does not contact a
host, invoke Cargo, alter uv, rerun a sample, select exclusions, or modify a
measurement package. No comparative effects were inspected while preparing it.
The 23 pure checks use synthetic batches, including complete 12-pair instruction
and 30-pair native schemas for both workloads. The earlier 22-check pass is kept
under `history/`; the subsequent change permits a controller on CPU8 while the
unchanged timed command explicitly selects CPUs0–7.

`source-freeze.json` binds the reviewer, checks and exact references. The compiler
parser is the actual amended current179 source (`afd0daa…`), not the older copy
in the initial staging directory. Only its `option`, `parse_run` and
`trace_executables` function definitions, plus the fixture's pure
`compile_packages`, are evaluated. Controller imports and mutation functions are
not evaluated. Target namespaces, strict `v2-` contexts and unit hashes remain
literal. The independently written statistics module is byte-identical to the
previously reviewed inheritance statistics implementation; synthetic parity
checks cover the frozen paired core's calculations.

The reviewer first checks the transfer receipt, every payload's bytes/mode, the
exact archive member set, original diagnostic history, cohort/final controls,
matched binary identities and result seals. For both workflows it independently
joins the fixed randomized plan with every JSON/JSONL/CSV observation, exact
command/environment, installed executable, alias-resolved input hashes, raw
compiler signatures, fixture journal and restoration. Check preparation must
contain exactly three successful native BEFORE calls; the final raw trace must
contain only taskset and Cargo, and every reported artifact must be fresh. Each
AFTER edit is reconstructed byte-for-byte, differs from BEFORE at equal length,
is identical within a pair and unique across pairs. Every timed call must compile
the prescribed uv units. The measured Cargo commands include `--no-run` for
test builds and their verbose executions contain only the frozen compiler; the
prior 16 execve diagnostics are retained and byte-bound. There is no per-sample
timed execve trace, so the review states that distinction explicitly.

Instruction records must join the exact Callgrind3.22 Cargo command, one Ir
summary, profile-file hash, sample metric and CSV cell. Native observations have
no profiler metrics and are exactly 30 single-call pairs plus two warmup pairs;
they are not repeated groups. Controller affinity is recorded separately from
the immutable `taskset -c 0-7` timed-child command.

Both raw workload audits must finish before `raw-integrity.json` is written and
before any effect calculation or `analysis.json` parsing. The second pass
independently recomputes all reported wall/CPU/Ir analyses with 99% confidence,
20,000 resamples and seed1701, then checks the unchanged 1%/positive-interval/
sign-p≤0.01/both-order gates. Instrumented elapsed is never treated as native
time. It rehashes all collected files and its own frozen source before writing a
sealed review. Native review additionally requires a root-bound prior independent
IR review whose primary gate passed and verifies that every accepted IR result,
fixture and phase-status byte is unchanged in the later native collection.

After the phase is terminal, the reviewed collector must first produce its
ordinary `evidence/<phase>/`, archive and receipt. Root then supplies a new local
approval JSON with `valid: true`, `source_freeze_sha256`, `phase`,
`collection_receipt_sha256` and the absolute new `output` directory. For native,
also set `accepted_ir_review_sha256` and provide `--accepted-ir` pointing to the
previous independent IR review directory. That approval binds an actual terminal
collection; it cannot be prepared by guessing future receipt hashes.

Run on CPU8 with a clean system-Python environment, using an absolute script path:

```sh
env -u PYTHONPATH -u PYTHONHOME -u PYTHONSAFEPATH PYTHONDONTWRITEBYTECODE=1 \
  taskset -c 8 /usr/bin/python3 -B /ABS/work/sbom-current179-raw-review/review.py \
  ir-confirmation --controls /ABS/work/dirty-sbom-current179 \
  --approval /ABS/APPROVAL.json --output /ABS/NEW-REVIEW-DIRECTORY
```

The executable entry point refuses an existing output directory. Preserve any
failed review attempt and diagnose it before an amendment or new attempt. A
review failure does not authorize additional measurements or a different gate.
The package intentionally requires the reviewed complete-phase collector and
ordinary complete phase schema; any operational closure must receive an explicit
separately reviewed adaptation before use.
