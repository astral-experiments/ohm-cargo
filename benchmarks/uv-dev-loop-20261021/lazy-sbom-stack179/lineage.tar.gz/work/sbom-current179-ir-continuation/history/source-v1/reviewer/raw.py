import lineage
"""Independent fixed-sample integrity, without effect calculations."""
import csv
import json
import math
import random
import shlex

from evidence import BINARIES, CSV_FIELDS, FINAL, ORIGINAL, REFERENCE, REMOTE, need, read, sha
from preparation import fixture, instant, objects

RUN_FIELDS = ['returncode', 'wall_ns', 'user_seconds', 'system_seconds', 'minor_faults', 'major_faults',
              'voluntary_context_switches', 'involuntary_context_switches', 'stdout', 'stderr']


def plan(count, seed):
    need(count in (2, 12, 30), 'unplanned pair count')
    rows = [['baseline', 'candidate'] for _ in range(count // 2)]
    rows += [['candidate', 'baseline'] for _ in range(count // 2)]
    random.Random(seed).shuffle(rows)
    return rows


def substitute(value, context):
    for name, replacement in context.items():
        value = value.replace('{' + name + '}', str(replacement))
    return value


def outcome(row):
    need(type(row['returncode']) is int and row['returncode'] == 0
         and type(row['wall_ns']) is int and row['wall_ns'] > 0, 'unsuccessful/nonpositive observation')
    for name in ('user_seconds', 'system_seconds'):
        need(type(row[name]) in (float, int) and math.isfinite(row[name]) and row[name] >= 0,
             'invalid CPU observation')
    for name in ('minor_faults', 'major_faults', 'voluntary_context_switches', 'involuntary_context_switches'):
        need(type(row[name]) is int and row[name] >= 0, 'invalid resource counter')


def tables(directory, samples, instruction):
    lines = (directory / 'samples.jsonl').read_text()
    need(lines.endswith('\n') and [json.loads(line) for line in lines.splitlines()] == samples,
         'JSON/JSONL sample tables differ')
    with (directory / 'samples.csv').open(newline='') as stream:
        reader = csv.DictReader(stream)
        expected_fields = CSV_FIELDS + (['metric_cargo_ir'] if instruction else [])
        need(reader.fieldnames == expected_fields, 'CSV column schema differs')
        observed = list(reader)
    need(len(observed) == len(samples), 'CSV sample count differs')
    for serialized, sample in zip(observed, samples):
        need(serialized == {name: str(sample[name]) for name in expected_fields}, 'CSV sample fields differ')


def profile(path, expected_command):
    events, summaries, commands, creators = [], [], [], []
    with path.open() as stream:
        for line in stream:
            if line.startswith('events:'):
                events.append(line.partition(':')[2].split())
            elif line.startswith('summary:'):
                summaries.append(line.partition(':')[2].split())
            elif line.startswith('cmd:'):
                commands.append(shlex.split(line.partition(':')[2]))
            elif line.startswith('creator:'):
                creators.append(line.partition(':')[2].strip())
    need(events == [['Ir']] and len(summaries) == 1 and len(summaries[0]) == 1,
         'Callgrind event or summary schema differs')
    need(commands == [expected_command] and creators == ['callgrind-3.22.0'],
         'profile belongs to another executable/command or profiler version')
    text = summaries[0][0]
    need(text.isascii() and text.isdecimal(), 'instruction summary is not a nonnegative integer')
    value = int(text)
    need(value > 0, 'instruction count is zero')
    return value


def recorded_files(configuration, final, catalog):
    aliases = {row['path']: row['resolved'] for row in catalog['snapshot']['tools'].values()}
    aliases.update({path: row['resolved'] for path, row in catalog['snapshot']['configs'].items()
                    if row.get('exists')})
    result = {}
    need(len(set(configuration['record_files'])) == len(configuration['record_files']), 'duplicate frozen record path')
    for path in configuration['record_files']:
        expected = final['asset_sha256'][path]
        canonical = aliases.get(path, path)
        need(canonical not in result or result[canonical] == expected, 'conflicting recorded path aliases')
        result[canonical] = expected
    return result


def compiler_report(collection, sample, parser, expectation, workload):
    report = parser.parse_run(collection.path(sample['stdout']).read_text(),
                              collection.path(sample['stderr']).read_text(),
                              sample['configured_environment']['CARGO_TARGET_DIR'])
    frozen = expectation['workloads'][workload]['targets'][report['target_dir']]
    for key in ('target_dir', 'workspace_namespaces', 'compiler_signatures', 'compiled_targets', 'compiled_artifacts'):
        need(report[key] == frozen[key], 'compiler work differs from exact target-bound diagnostic: ' + key)
    need(report['progress_packages'] == ['uv'] and report['compiled_packages'] == [expectation['uv_package']],
         'dirty call became fresh or compiled another package')
    expected_stages = {'source': 2, 'rlink': 4} if workload == 'test' else {'source': 1}
    need(report['compiler_stage_counts'] == expected_stages and not report['other_commands'],
         'compiler stage count changed, or build-script/test execution appeared')
    need(len(report['compiler_commands']) == sum(expected_stages.values()) and all(
        row['executable'] == expectation['rustc'] for row in report['compiler_commands']),
        'unexpected compiler executable or count')
    need(all((row['input_kind'] == 'source' and row['source'].startswith('crates/uv/'))
             or (row['input_kind'] == 'rlink' and row['source'].startswith('@target/debug/build/workspaces/'))
             for row in report['compiler_commands']), 'unexpected compiler source/input')
    need(not set(report['test_executables']).intersection(row['executable'] for row in report['compiler_commands']),
         'a test executable appeared as a measured command')
    return report


def audit_workload(collection, workload, protocol, final, phase_state, parser):
    group = collection.phase
    instruction = group == 'ir-confirmation'
    name = workload + '-' + group
    result_name = lineage.result_name(workload, group)
    analysis_name = lineage.analysis_name(workload, group)
    directory = collection.path(result_name + '/samples.json').parent
    result_root = REMOTE + '/' + result_name
    configuration = collection.json('configs/' + name + '.json')
    manifest = collection.json(result_name + '/manifest.json')
    phase = next(row for row in protocol['phases'] if row['workload'] == workload
                 and row['metric'] == ('cargo_ir' if instruction else 'native_wall_seconds'))
    count = 12 if instruction else 30
    seed = {('test', True): 20261021101, ('check', True): 20261021102,
            ('test', False): 20261021103, ('check', False): 20261021104}[(workload, instruction)]
    expected_plans = {'warmup': plan(2, seed ^ 0x5A17), 'measurement': plan(count, seed)}
    need(phase['pairs'] == count and phase['warmup_pairs'] == 2 and phase['seed'] == seed
         and phase['phase'] == 'confirmation' and phase['invocations_per_variant_per_pair'] == 1
         and phase['warmup_plan'] == expected_plans['warmup'] and phase['measurement_plan'] == expected_plans['measurement']
         and phase['target_assignment'] == {'baseline': 'cand', 'candidate': 'base'}, 'prospective plan differs')
    need(manifest['state'] == 'complete' and manifest['phase'] == 'confirmation'
         and manifest['seed'] == seed and manifest['pairs'] == count and manifest['warmup_pairs'] == 2
         and manifest['plans'] == expected_plans, 'manifest plan/state differs')
    need(manifest['configuration'] == configuration
         and manifest['configuration_path'] == REMOTE + '/configs/' + name + '.json'
         and manifest['configuration_sha256'] == final['config_sha256'][name]
         and sha(collection.path('configs/' + name + '.json')) == final['config_sha256'][name],
         'manifest configuration differs from final frozen config')
    need(manifest['variant_sha256'] == manifest['variant_sha256_after'] == BINARIES
         and manifest['variant_paths'] == configuration['variants']
         and manifest['canonical_executable'] == configuration['canonical_executable'], 'binary/canonical path mismatch')
    recorded = recorded_files(configuration, final, collection.json('metadata/input-catalog.json'))
    need(manifest['recorded_file_sha256'] == manifest['recorded_file_sha256_after'] == recorded,
         'before/after input hashes differ from frozen controls')
    machine = manifest['machine']
    need(machine['uid'] == machine['effective_uid'] == 1000 and machine['root_directory_owner_uid'] == 0
         and machine['uname'][0] == 'Linux' and machine['uname'][4] == 'x86_64'
         and isinstance(machine['affinity'], list) and machine['affinity']
         and all(type(cpu) is int and cpu >= 0 for cpu in machine['affinity']),
         'unexpected host ownership/architecture/controller affinity')
    need(instant(phase_state['started_at']) <= instant(manifest['started_at'])
         < instant(manifest['finished_at']) <= instant(phase_state['finished_at']), 'batch chronology outside phase')
    seal_sha = collection.verify_seal(result_name)
    status_row = phase_state['results'][workload]
    need(status_row['primary'] is (workload == 'test')
         and status_row['analysis_sha256'] == sha(collection.path(analysis_name + '/analysis.json'))
         and status_row['compiler_audit_sha256'] == sha(collection.path(result_name + '/compiler-audit.json')),
         'phase status does not bind result analyses/audits')
    samples = collection.json(result_name + '/samples.json')
    need(len(samples) == manifest['sample_count'] == 2 * (count + 2), 'fixed sample count mismatch')
    tables(directory, samples, instruction)
    expected_rows = [(stage, pair, 'AB' if order[0] == 'baseline' else 'BA', position, variant)
                     for stage, orders in expected_plans.items() for pair, order in enumerate(orders)
                     for position, variant in enumerate(order)]
    observed_rows = [(row['stage'], row['pair'], row['order'], row['position'], row['variant']) for row in samples]
    need(observed_rows == expected_rows, 'sample order/count differs from randomized paired plan')
    expectation = collection.json('metadata/diagnostic-expectations.json')
    guard = collection.json('work/benchmark/source-guard.json')
    compiler_rows, pairs, cpu_pairs, metric_pairs, profile_paths = [], {}, {}, {}, []
    sample_keys = set(CSV_FIELDS) | {'command', 'configured_environment', 'installed_sha256',
        'load_average_before', 'load_average_after', 'prepare', 'executable_unchanged', 'metrics', 'metric_files'}
    if instruction:
        sample_keys.add('metric_cargo_ir')
        need(configuration['command'].count('--trace-children=no') == 1
             and configuration['metric_files'] == {'cargo_ir': {'format': 'callgrind', 'event': 'Ir',
                  'path': '{output}/callgrind-{stage}-{pair}-{variant}.out'}}, 'instruction scope/output config changed')
    else:
        need(not configuration.get('metric_files'), 'native run is instrumented')
    previous_end = instant(manifest['started_at'])
    for sample in samples:
        need(set(sample) == sample_keys and type(sample['pair']) is int and type(sample['position']) is int,
             'sample schema differs or includes aggregated/repeated observations')
        outcome(sample)
        need(sample['executable_unchanged'] is True and sample['installed_sha256'] == BINARIES[sample['variant']],
             'timed executable changed')
        context = {'cargo': configuration['canonical_executable'], 'variant': sample['variant'],
                   'pair': sample['pair'], 'stage': sample['stage'], 'phase': 'confirmation',
                   'output': result_root, 'position': sample['position']}
        expected_command = [substitute(value, context) for value in configuration['command']]
        need(sample['command'] == expected_command, 'timed command differs from exact frozen argv')
        base_command = guard['commands'][workload]
        if instruction:
            cargo_index = expected_command.index(configuration['canonical_executable'])
            need(expected_command[cargo_index:] == base_command[3:], 'instrumented Cargo arguments changed')
        else:
            need(expected_command == base_command, 'native command is not one frozen invocation')
        need((workload != 'test' or '--no-run' in expected_command)
             and '--locked' in expected_command and '--offline' in expected_command, 'build-only/offline command changed')
        expected_environment = dict(configuration['env'])
        expected_environment.update(configuration['variant_env'][sample['variant']])
        expected_environment = {key: None if value is None else substitute(str(value), context)
                                for key, value in expected_environment.items()}
        need(sample['configured_environment'] == expected_environment, 'sample environment differs from config')
        label = f"{sample['stage']}-{sample['pair']:04d}-{sample['position']}-{sample['variant']}"
        for suffix in ('stdout', 'stderr'):
            need(sample[suffix] == result_root + '/logs/' + label + '.' + suffix,
                 'sample log path does not match its identity')
            need(sample['prepare'][suffix] == result_root + '/logs/' + label + '.prepare.' + suffix,
                 'preparation log path does not match its identity')
            collection.path(sample[suffix])
            collection.path(sample['prepare'][suffix])
        need(set(sample['prepare']) == set(RUN_FIELDS), 'preparation outcome schema changed')
        outcome(sample['prepare'])
        start = instant(sample['started_at'])
        need(previous_end <= start, 'samples overlap or precede the batch')
        previous_end = start + sample['wall_ns'] / 1e9
        need(previous_end <= instant(manifest['finished_at']), 'sample ends after batch completion')
        report = compiler_report(collection, sample, parser, expectation, workload)
        compiler_rows.append({'stage': sample['stage'], 'pair': sample['pair'], 'variant': sample['variant'],
                              'stdout_sha256': sha(collection.path(sample['stdout'])),
                              'stderr_sha256': sha(collection.path(sample['stderr'])), **report})
        if instruction:
            path = result_root + f"/callgrind-{sample['stage']}-{sample['pair']}-{sample['variant']}.out"
            need(sample['metric_files'] == {'cargo_ir': {'path': path, 'sha256': sha(collection.path(path))}},
                 'raw profiler path/hash differs')
            count_value = profile(collection.path(path), expected_command[cargo_index:])
            need(type(sample['metric_cargo_ir']) is int and sample['metrics'] == {'cargo_ir': count_value}
                 and sample['metric_cargo_ir'] == count_value, 'profile event count differs from sample tables')
            profile_paths.append(path.removeprefix(REMOTE + '/'))
        else:
            need(sample['metrics'] == sample['metric_files'] == {}, 'native observation includes profiler metrics')
        if sample['stage'] == 'measurement':
            key = sample['pair']
            for mapping, value in [(pairs, sample['wall_ns'] / 1e9),
                                    (cpu_pairs, sample['user_seconds'] + sample['system_seconds'])]:
                mapping.setdefault(key, {'order': sample['order']})[sample['variant']] = value
            if instruction:
                metric_pairs.setdefault(key, {'order': sample['order']})[sample['variant']] = count_value
    profile_members = {name for name in collection.files if name.startswith(result_name + '/callgrind-')}
    need(profile_members == set(profile_paths), 'extra/missing per-process profiler files')
    audited = {'valid': True, 'source_restored': True, 'source_identity': guard['source_identity'],
               'fixture_validation_valid': True, 'expectations_sha256': sha(collection.path('metadata/diagnostic-expectations.json')),
               'samples': compiler_rows}
    need(collection.json(result_name + '/compiler-audit.json') == audited,
         'stored compiler audit differs from pure parser replay')
    prepared = fixture(collection, workload, group, samples, configuration, guard, parser)
    need(previous_end <= instant(prepared['restored_at']) <= instant(manifest['finished_at']),
         'source restoration precedes final measured work or follows completion')
    need(set(manifest['cleanup']) == set(RUN_FIELDS), 'cleanup outcome schema changed')
    outcome(manifest['cleanup'])
    for suffix in ('stdout', 'stderr'):
        need(manifest['cleanup'][suffix] == result_root + '/logs/cleanup.' + suffix, 'cleanup log path changed')
        collection.path(manifest['cleanup'][suffix])
    need(objects(collection.path(manifest['cleanup']['stdout']).read_text()) == [{
        'operation': 'restore', 'source': guard['source'], 'sha256': ORIGINAL}], 'cleanup did not restore original source')
    raw_summary = {'valid': True, 'workload': workload, 'samples': len(samples), 'measurement_pairs': count,
                   'warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
                   'compiler_invocations_per_sample': 6 if workload == 'test' else 1,
                   'expected_stage_counts': {'source': 2, 'rlink': 4} if workload == 'test' else {'source': 1},
                   'native_test_executions': 0,
                   'test_nonexecution_evidence': 'Every measured Running command is the frozen rustc; test argv has --no-run; all16 prior execve diagnostics are retained and byte-bound.',
                   'result_seal_sha256': seal_sha, 'samples_sha256': sha(collection.path(result_name + '/samples.json')),
                   'manifest_sha256': sha(collection.path(result_name + '/manifest.json')),
                   'configuration_sha256': manifest['configuration_sha256'], 'preparation': prepared,
                   'started_at': manifest['started_at'], 'finished_at': manifest['finished_at']}
    return {'raw': raw_summary, 'wall_pairs': list(pairs.values()), 'cpu_pairs': list(cpu_pairs.values()),
            'instruction_pairs': list(metric_pairs.values()), 'analysis_path': collection.path(analysis_name + '/analysis.json'),
            'phase_result': status_row, 'manifest': manifest}
