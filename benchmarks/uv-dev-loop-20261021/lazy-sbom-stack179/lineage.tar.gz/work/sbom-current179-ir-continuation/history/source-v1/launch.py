#!/usr/bin/env python3
"""Launch the reviewed fixed check continuation once, preserving its own launch receipt."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from stage import HERE, SSH, sha, verify_approval

REMOTE = r'''
from pathlib import Path
import hashlib, json, shlex, subprocess, sys
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
capsule = root / 'continuations/ir-check-01'
manifest = capsule / 'capsule-manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == sys.argv[1]
files = json.loads(manifest.read_text())['files']
for name, row in files.items():
    path = capsule / name
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
assert not (root / 'results/ir-completion-01').exists()
session = 'ohm-sbom179-ir-completion-01'
assert subprocess.run(['tmux', 'has-session', '-t', session], capture_output=True).returncode == 1
for suffix in ('stdout', 'stderr'):
    path = root / 'logs' / ('ir-completion-01.controller.' + suffix)
    assert not path.exists() and not path.is_symlink()
command = ['env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME', '-u', 'PYTHONSAFEPATH',
           'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-B', str(capsule / 'complete_ir.py'),
           '--capsule-manifest-sha256', sys.argv[1]]
shell = 'set -C; exec ' + shlex.join(command) + ' > ' + shlex.quote(str(root / 'logs/ir-completion-01.controller.stdout')) + ' 2> ' + shlex.quote(str(root / 'logs/ir-completion-01.controller.stderr'))
subprocess.run(['tmux', 'new-session', '-d', '-s', session, '/bin/sh', '-c', shell], check=True)
print(json.dumps({'launched': True, 'session': session, 'command': command, 'capsule_manifest_sha256': sys.argv[1],
                  'original_failed_status_preserved': True, 'fixed_check_pairs': 12, 'warmup_pairs': 2,
                  'seed': 20261021102, 'test_samples_to_rerun': 0}, sort_keys=True))
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approval', required=True)
    args = parser.parse_args()
    verify_approval(args.approval, 'launch-fixed-check')
    stage = json.loads((HERE / 'stage-receipt.json').read_text())
    assert stage['returncode'] == 0 and stage['remote']['valid'] is True
    assert stage['capsule_manifest_sha256'] == sha(HERE / 'capsule-manifest.json')
    assert not (HERE / 'launch-receipt.json').exists()
    process = subprocess.run([SSH, 'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
        '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-B', '-c', REMOTE,
        sha(HERE / 'capsule-manifest.json')], capture_output=True)
    for suffix, payload in (('stdout', process.stdout), ('stderr', process.stderr)):
        with (HERE / ('launch.' + suffix)).open('xb') as stream:
            stream.write(payload)
    receipt = {'returncode': process.returncode, 'approval_sha256': sha(Path(args.approval)),
               'stage_receipt_sha256': sha(HERE / 'stage-receipt.json'),
               'source_freeze_sha256': sha(HERE / 'source-freeze.json'),
               'capsule_manifest_sha256': sha(HERE / 'capsule-manifest.json'),
               'stdout_sha256': sha(HERE / 'launch.stdout'), 'stderr_sha256': sha(HERE / 'launch.stderr')}
    if process.returncode == 0:
        receipt['remote'] = json.loads(process.stdout)
    with (HERE / 'launch-receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(receipt, sort_keys=True))
    raise SystemExit(process.returncode)


if __name__ == '__main__':
    main()
