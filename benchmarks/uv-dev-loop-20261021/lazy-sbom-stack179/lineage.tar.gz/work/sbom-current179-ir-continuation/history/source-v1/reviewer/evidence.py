import lineage
"""Read-only collected-byte validation; no remote tools or measurement imports."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile

HERE = Path(__file__).resolve().parent
REFERENCE = HERE / 'reference'
REMOTE = '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179'
COHORT = 'f3fbfa9830933ad0be5860422363aeecb89e30e6e0388172771e664987f70736'
FINAL = 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad'
PROTOCOL = '47330c842872b309dd187203c679cfdeb0b94f18e6f29c3a27e8a1d938e1335f'
COLLECTOR = '0d600a074f5a8bcf188fa61e68b6377fbc4085cce8ca5c9e3c21c6ccdd047df0'
ORIGINAL = 'ad097b233b93d8e6fcf67aa1657fa103ca79e1227781b3989d0e83dfa2a59e81'
UV = '3d82a6ad5a7eab8c68236553b7846517767c4b61'
BINARIES = {
    'baseline': 'a25d7c3e1678a4076b7006b1ca3880da116de8ba43b93f5b1c45c8fc260c8e47',
    'candidate': '060043e733873dfd9a27e29cdb526713479cc90079609b23df92ff088d469e90',
}
CSV_FIELDS = ['stage', 'pair', 'order', 'position', 'variant', 'started_at', 'returncode',
              'wall_ns', 'user_seconds', 'system_seconds', 'minor_faults', 'major_faults',
              'voluntary_context_switches', 'involuntary_context_switches', 'stdout', 'stderr']


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def relative(name):
    path = PurePosixPath(name)
    need(isinstance(name, str) and name and not path.is_absolute() and '..' not in path.parts
         and str(path) == name and name != '.', 'unsafe or noncanonical payload path')
    return path


def remote_relative(name):
    path = PurePosixPath(name)
    need(str(path) == name and '..' not in path.parts, 'noncanonical remote path')
    try:
        return relative(str(path.relative_to(REMOTE)))
    except ValueError as error:
        raise ValueError('remote path is outside the frozen task root') from error


def freeze_check():
    path = HERE / 'source-freeze.json'
    document = read(path)
    for name, row in document['files'].items():
        member = HERE / relative(name)
        need(member.is_file() and not member.is_symlink() and member.resolve() == member,
             'review source is not an ordinary local file')
        need(sha(member) == row['sha256'] and member.stat().st_size == row['bytes'],
             'review source changed: ' + name)
    for name, expected in [('protocol.json', PROTOCOL), ('configs-finalized.json', FINAL),
                           ('frozen-cohort.json', COHORT), ('collect_completed_group.py', COLLECTOR)]:
        need(sha(REFERENCE / name) == expected, 'reference identity changed: ' + name)
    return sha(path)


class Collection:
    def __init__(self, controls, phase):
        need(phase in ('ir-confirmation', 'native-confirmation'), 'unknown review phase')
        self.phase = phase
        self.controls = Path(controls).absolute()
        self.root = self.controls / 'evidence' / phase
        need(self.root.resolve() == self.root and self.root.is_dir(), 'unsafe collection directory')
        self.receipt_path = self.controls / (phase + '-collection-receipt.json')
        self.archive_path = self.controls / (phase + '-evidence.tar.gz')
        self.receipt = read(self.receipt_path)
        self.transfer = read(self.root / 'transfer-manifest.json')
        self.files = self.transfer['files']
        need(self.receipt['valid'] is True and self.receipt['phase'] == phase
             and self.receipt['collector_sha256'] == sha(REFERENCE / 'continuation/collect.py'), 'collection receipt is not the reviewed collector')
        need(self.receipt['cohort_sha256'] == COHORT and self.receipt['files'] == len(self.files),
             'collection receipt count/cohort mismatch')
        need(sha(self.root / 'transfer-manifest.json') == self.receipt['transfer_manifest_sha256']
             and sha(self.archive_path) == self.receipt['archive_sha256'], 'collection archive/manifest mismatch')
        need(self.receipt['continuation_capsule_sha256'] == sha(REFERENCE / 'continuation/capsule-manifest.json'),
             'collection belongs to another continuation capsule')
        self.verify_files()
        self.verify_archive()

    def path(self, name):
        if name.startswith('/'):
            name = str(remote_relative(name))
        path = self.root / relative(name)
        need(name in self.files and path.is_file() and not path.is_symlink()
             and path.resolve() == path, 'unbound or unsafe collected file: ' + name)
        return path

    def json(self, name):
        return read(self.path(name))

    def verify_files(self):
        observed = set()
        for path in self.root.rglob('*'):
            need(not path.is_symlink(), 'collection contains a symlink')
            if path.is_file():
                observed.add(str(path.relative_to(self.root)))
            else:
                need(path.is_dir(), 'collection contains a special file')
        need(observed == set(self.files) | {'transfer-manifest.json'}, 'collection member set changed')
        for name, row in self.files.items():
            path = self.path(name)
            need(set(row) == {'sha256', 'bytes', 'mode'}, 'unexpected transfer row fields')
            info = path.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_size == row['bytes']
                 and stat.S_IMODE(info.st_mode) == row['mode'] and sha(path) == row['sha256'],
                 'collected bytes or mode changed: ' + name)

    def verify_archive(self):
        seen = set()
        with tarfile.open(self.archive_path, mode='r|gz') as archive:
            for member in archive:
                relative(member.name)
                need(member.isfile() and member.name not in seen, 'unsafe/duplicate archive member')
                seen.add(member.name)
                with archive.extractfile(member) as stream:
                    actual = hashlib.file_digest(stream, 'sha256').hexdigest()
                if member.name == 'transfer-manifest.json':
                    need(actual == self.receipt['transfer_manifest_sha256'], 'archived manifest differs')
                else:
                    need(member.name in self.files, 'unlisted archive member')
                    row = self.files[member.name]
                    need(actual == row['sha256'] and member.size == row['bytes']
                         and member.mode == row['mode'], 'archive/payload mismatch: ' + member.name)
        need(seen == set(self.files) | {'transfer-manifest.json'}, 'incomplete archive')

    def verify_seal(self, directory):
        if self.phase == 'ir-confirmation' and directory in ('results/test-ir-confirmation', 'results/ir-completion-01/check'):
            return lineage.raw_seal(self, directory)
        seal = self.json(directory + '/seal.json')
        prefix = directory + '/'
        observed = {name[len(prefix):] for name in self.files if name.startswith(prefix)} - {'seal.json'}
        need(set(seal) == observed, 'result seal member set mismatch: ' + directory)
        for name, expected in seal.items():
            relative(name)
            need(self.files[prefix + name]['sha256'] == expected, 'result seal hash mismatch')
        return digest(self.path(directory + '/seal.json').read_bytes())


def collection_inputs(collection):
    """Verify immutable diagnostic controls before reading any sample effects."""
    aliases = {
        'work/benchmark/protocol.json': 'protocol.json', 'configs-finalized.json': 'configs-finalized.json',
        'metadata/frozen-cohort.json': 'frozen-cohort.json',
        'metadata/diagnostic-expectations.json': 'diagnostic-expectations.json',
        'metadata/input-catalog.json': 'input-catalog.json',
        'work/benchmark/source-guard.json': 'source-guard.json', 'matched-pair.json': 'matched-pair.json',
    }
    for name in ('dirty_audit_v2.py', 'dirty_fixture.py', 'check_convergence.py', 'paired.py', 'run_group.py'):
        aliases['work/benchmark/' + name] = name
    for workload in ('test', 'check'):
        for metric in ('ir', 'native'):
            name = workload + '-' + metric + '-confirmation.json'
            aliases['configs/' + name] = name
    for name, reference in aliases.items():
        need(sha(collection.path(name)) == sha(REFERENCE / reference), 'frozen control changed: ' + name)
    original = read(REFERENCE / 'diagnostic-transfer-manifest.json')['files']
    changed = {'collection-identity.json'}
    groups = ('ir-confirmation',) if collection.phase == 'ir-confirmation' else ('ir-confirmation', 'native-confirmation')
    for group in groups:
        for workload in ('test', 'check'):
            for name in ('state.json', 'journal.jsonl'):
                changed.add(f'fixtures/{workload}-{group}/{name}')
    for name, row in original.items():
        need(name in collection.files, 'diagnostic history was dropped: ' + name)
        if name not in changed:
            need(collection.files[name] == row, 'original diagnostic/control bytes changed: ' + name)
    identity = collection.json('collection-identity.json')
    need(identity['root'] == REMOTE and identity['uid'] == 1000 and identity['uv_head'] == UV
         and identity['uv_status'] == '' and identity['source_sha256'] == ORIGINAL,
         'collection host/source identity changed')
    need(identity['cohort_sha256'] == COHORT and identity['finalized_sha256'] == FINAL
         and identity['all_cohort_assets_verified'] is True and identity['diagnostics_complete'] is True
         and identity['accepted_diagnostics'] == 16 and identity['comparative_samples_exist'] is True
         and identity['completed_phase'] == collection.phase and identity['variant_sha256'] == BINARIES,
         'collection terminal identity mismatch')
    final = collection.json('configs-finalized.json')
    need(final['variant_sha256'] == BINARIES and final['protocol_sha256'] == PROTOCOL
         and final['source_restored'] is True, 'final input/variant seal mismatch')
    for path, expected in final['asset_sha256'].items():
        if path.startswith(REMOTE + '/') and str(remote_relative(path)) in collection.files:
            need(sha(collection.path(path)) == expected, 'collected frozen asset changed: ' + path)
    runtime = identity['dynamic_libraries']
    need(runtime['baseline']['files'] == runtime['candidate']['files']
         and len(runtime['baseline']['files']) == 4, 'runtime library pair differs')
    for path, expected in runtime['baseline']['files'].items():
        need(final['asset_sha256'][path] == expected, 'runtime library differs from final seal')
    lineage.verify(collection)
    state = collection.json(lineage.status_name(collection.phase))
    need(state['state'] == 'complete' and state['group'] == collection.phase
         and state['completed_workloads'] == ['test', 'check'] and state['source_restored'] is True
         and state['protocol_sha256'] == PROTOCOL and state['config_manifest_sha256'] == FINAL,
         'phase is incomplete or uses other controls')
    need(identity['phase_state_sha256'] == sha(collection.path(lineage.status_name(collection.phase))),
         'phase status and collection identity differ')
    return final, state
