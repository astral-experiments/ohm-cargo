"""Freeze source-only controls; this script never connects to a host or reads effects."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent


def record(path, mode=False):
    row = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
    if mode:
        row['mode'] = 0o644
    return row


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    assert not (HERE / 'source-freeze.json').exists(), 'preserve an existing freeze before making a successor'
    for script in ('derive.py', 'derive_collector.py'):
        subprocess.run(['/usr/bin/python3', '-B', str(HERE / script)], check=True)
    write(HERE / 'ownership.json', {'root': '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/continuations/ir-check-01',
        'parent': '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179', 'uid': 1000,
        'purpose': 'one fixed original check IR continuation; preserve completed test and failed status'})
    names = {'contract.py', 'complete_ir.py', 'native_entry.py', 'boundary.py', 'check-loop.py', 'analysis-tail.py',
             'native-original-controller.py', 'adaptation-identities.json', 'amendment.md', 'ownership.json',
             'original/run_group.py', 'original/paired.py'}
    names |= {str(path.relative_to(HERE)) for path in (HERE / 'failed').rglob('*') if path.is_file()}
    for name in names:
        (HERE / name).chmod(0o644)
    capsule = {'operation': 'complete-original-fixed-check-ir-only',
               'failed_capture_sha256': 'd20d773a4f8c5016fbe6f20efc67cec9089832e53b886a767e5de2a1f0b6a109',
               'original_finalized_sha256': 'f95f68347284b265f3dbbcf7d93c30905be921ee1f98cab8e67db551efca16ad',
               'files': {name: record(HERE / name, mode=True) for name in sorted(names)}}
    write(HERE / 'capsule-manifest.json', capsule)
    subprocess.run(['/usr/bin/python3', '-B', str(HERE / 'derive_reviewer.py')], check=True)
    review_files = {str(path.relative_to(HERE / 'reviewer')): record(path)
                    for path in sorted((HERE / 'reviewer').rglob('*'))
                    if path.is_file() and path.name != 'source-freeze.json'}
    write(HERE / 'reviewer/source-freeze.json', {'scope': 'Path/lineage adaptation of the accepted independent reviewer; unchanged pure parser and statistics.',
        'created_at': datetime.now(timezone.utc).isoformat(), 'files': review_files,
        'comparative_effects_inspected': False, 'host_actions_performed': False,
        'measurement_or_compiler_execution_performed': False})
    process = subprocess.run(['/usr/bin/python3', '-B', str(HERE / 'test_continuation.py')], capture_output=True)
    (HERE / 'pure-checks.stdout').write_bytes(process.stdout)
    (HERE / 'pure-checks.stderr').write_bytes(process.stderr)
    assert process.returncode == 0, process.stderr.decode()
    write(HERE / 'pure-checks.json', {'valid': True, 'returncode': 0,
        'stdout': record(HERE / 'pure-checks.stdout'), 'stderr': record(HERE / 'pure-checks.stderr'),
        'no_hosts_or_workloads': True, 'no_comparative_effects': True})
    files = {str(path.relative_to(HERE)): record(path) for path in sorted(HERE.rglob('*'))
             if path.is_file() and path.name != 'source-freeze.json'}
    # The independent reviewer's own source seal is part of the outer package.
    files['reviewer/source-freeze.json'] = record(HERE / 'reviewer/source-freeze.json')
    write(HERE / 'source-freeze.json', {'created_at': datetime.now(timezone.utc).isoformat(),
        'scope': 'Only the original unstarted fixed check IR batch, retained original test/failure, original analyses and independent reviewer; source-only.',
        'capsule_manifest_sha256': record(HERE / 'capsule-manifest.json')['sha256'],
        'reviewer_source_freeze_sha256': record(HERE / 'reviewer/source-freeze.json')['sha256'],
        'host_actions_performed': False, 'comparative_effects_inspected': False,
        'measurement_or_compiler_execution_performed': False, 'files': files})
    print(json.dumps({'source_freeze': record(HERE / 'source-freeze.json'),
                      'capsule_manifest': record(HERE / 'capsule-manifest.json'), 'files': len(files)}, indent=2))


if __name__ == '__main__':
    main()
