"""Load only exact pure function definitions from the pinned compiler parser."""
import ast
from collections import Counter
import json
from pathlib import Path
import re
import shlex
from types import SimpleNamespace

from evidence import REFERENCE, need, sha

PARSER = 'afd0daaaffc4baaa97a2bc3d046805464974c542abb1e48476a764e61ae8a943'
FIXTURE = 'a89570fa6080462a772ebdbc73ab4471e0b968f7c357c23b197409fb12f282ad'


def selected_functions(path, expected, names, namespace):
    need(sha(path) == expected, 'pure parser source hash changed')
    tree = ast.parse(path.read_text(), filename=str(path))
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    need({node.name for node in nodes} == set(names) and len(nodes) == len(names), 'pure parser function set differs')
    need(all(not node.decorator_list and not node.args.defaults and not node.args.kw_defaults
             for node in nodes if node.name == 'compile_packages'), 'unexpected parser definition side effects')
    # All selected definitions are byte-bound above. Module imports, main(),
    # controller and source mutation functions are never evaluated or imported.
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)


def load():
    namespace = {'Counter': Counter, 'json': json, 'Path': Path, 're': re, 'shlex': shlex}
    selected_functions(REFERENCE / 'dirty_fixture.py', FIXTURE, ['compile_packages'], namespace)
    namespace['dirty_fixture'] = SimpleNamespace(compile_packages=namespace['compile_packages'])
    selected_functions(REFERENCE / 'dirty_audit_v2.py', PARSER,
                       ['option', 'parse_run', 'trace_executables'], namespace)
    return SimpleNamespace(parse_run=namespace['parse_run'], trace_executables=namespace['trace_executables'])
