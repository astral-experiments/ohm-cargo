#!/usr/bin/env python3
"""Source-frozen independent review of one completed current179 SBOM group."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from evidence import (BINARIES, COHORT, FINAL, ORIGINAL, PROTOCOL, REFERENCE, Collection,
                      collection_inputs, freeze_check, need, read, sha)
from parser import load
from preparation import instant
from raw import audit_workload
import statistics_review as statistics

SCREEN_NOTE = ('This screens one workload only. Require an independently run confirmation batch, correctness validation, '
               'and regression checks before a PR performance claim. Repeated candidate selection invalidates treating '
               'exploratory p-values as confirmatory evidence.')
METRIC_SCOPE = ('Instrumented Cargo process only; child rustc, linker, build-script, and test processes are excluded '
                '(--trace-children=no).')
INSTRUMENT_NOTE = (' Callgrind elapsed times are instrumented costs, not native dev-loop timings; this screen cannot '
                   'establish a native wall-time improvement.')


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def analysis_for(raw, instruction):
    """Independent recomputation, called only after both raw audits finish."""
    result = statistics.paired(raw['wall_pairs'])
    result['child_cpu_seconds'] = (statistics.paired(raw['cpu_pairs'])
        if all(row[variant] > 0 for row in raw['cpu_pairs'] for variant in ('baseline', 'candidate'))
        else {'note': 'At least one sample has zero recorded child CPU time; ratio statistics omitted.'})
    result['phase'] = 'confirmation'
    result['variant_sha256'] = BINARIES
    if instruction:
        result['metrics'] = {'cargo_ir': {'format': 'callgrind', 'event': 'Ir', 'scope': METRIC_SCOPE,
            'statistics': statistics.counts(raw['instruction_pairs']),
            'acceptance': 'No acceptance decision. Instruction comparisons screen candidates; confirm native wall time and correctness independently.'}}
    count = 12 if instruction else 30
    result['screen'] = {
        'minimum_pairs': count, 'minimum_time_reduction': 0.01, 'alpha': 1 - 0.99,
        'passes': (result['pairs'] >= count and result['bootstrap_speedup_interval'][0] > 1
                   and result['exact_two_sided_sign_p'] <= 1 - 0.99
                   and result['paired_geometric_mean_time_reduction'] >= 0.01
                   and all(row['geometric_mean_speedup'] > 1 for row in result['order'].values())),
        'note': SCREEN_NOTE,
    }
    if instruction:
        result['screen'].update(measurement_kind='instrumented wall time', note=SCREEN_NOTE + INSTRUMENT_NOTE)
    return result


def accepted_ir(collection, directory, approval, source_freeze):
    """Bind native eligibility to the exact previously accepted IR bytes."""
    need(directory is not None, 'native review requires the accepted independent IR review')
    directory = Path(directory).absolute()
    need(directory.resolve() == directory, 'accepted IR review directory is not canonical')
    seal = read(directory / 'seal.json')
    need(set(seal) == {'raw-integrity.json', 'effects.json', 'review.json'}, 'accepted IR review seal changed')
    for name, expected in seal.items():
        path = directory / name
        need(path.is_file() and not path.is_symlink() and sha(path) == expected, 'accepted IR review bytes changed')
    review = read(directory / 'review.json')
    need(sha(directory / 'review.json') == approval['accepted_ir_review_sha256']
         and review['valid'] is True and review['phase'] == 'ir-confirmation'
         and review['source_freeze_sha256'] == source_freeze and review['raw_integrity_before_effects'] is True
         and review['primary_passes'] is True, 'IR prerequisite was not independently accepted with this reviewer')
    effects = read(directory / 'effects.json')
    need(effects['workloads']['test']['gate']['passes_gate'] is True, 'accepted IR primary gate did not pass')
    transfer_path = collection.controls / 'evidence/ir-confirmation/transfer-manifest.json'
    receipt_path = collection.controls / 'ir-confirmation-collection-receipt.json'
    need(sha(transfer_path) == review['transfer_manifest_sha256']
         and sha(receipt_path) == review['collection_receipt_sha256'], 'accepted IR collection binding changed')
    original = read(transfer_path)['files']
    native_mutable = {'collection-identity.json'} | {
        f'fixtures/{workload}-native-confirmation/{name}' for workload in ('test', 'check')
        for name in ('state.json', 'journal.jsonl')}
    names = set(original) - native_mutable
    need({'results/ir-confirmation.json', 'results/ir-completion-01/status.json',
          'continuations/ir-check-01/capsule-manifest.json'} <= names,
         'accepted IR continuation/failure payload set is incomplete')
    for name in names:
        need(collection.files.get(name) == original[name], 'native collection changed accepted IR bytes: ' + name)
    return {'review_sha256': sha(directory / 'review.json'), 'review_seal_sha256': sha(directory / 'seal.json'),
            'transfer_manifest_sha256': review['transfer_manifest_sha256'], 'unchanged_ir_payloads': len(names)}


def review_group(collection, output, source_freeze, approval, accepted_directory=None):
    final, phase_state = collection_inputs(collection)
    protocol = read(REFERENCE / 'protocol.json')
    need(protocol['acceptance'] == {
        'minimum_geometric_reduction': 0.01, 'confidence': 0.99, 'bootstrap_resamples': 20000,
        'bootstrap_seed': 1701, 'bootstrap_speedup_lower_bound_greater_than': 1,
        'exact_two_sided_sign_p_maximum': 0.01, 'both_order_geometric_speedups_greater_than': 1},
        'fixed acceptance method changed')
    instruction = collection.phase == 'ir-confirmation'
    prior = None if instruction else accepted_ir(collection, accepted_directory, approval, source_freeze)
    parser = load()
    raw = {}
    # Deliberate two-pass boundary: no statistics, analysis.json parsing or
    # effect gates are evaluated while either workload's raw audit is pending.
    for workload in ('test', 'check'):
        raw[workload] = audit_workload(collection, workload, protocol, final, phase_state, parser)
    need(instant(raw['test']['raw']['finished_at']) <= instant(raw['check']['raw']['started_at']),
         'fixed workloads overlapped or ran in reverse order')
    for name in ('inherited_build_environment',):
        need(raw['test']['manifest'][name] == raw['check']['manifest'][name], 'workflow inherited environment differs')
    for name in ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid'):
        need(raw['test']['manifest']['machine'][name] == raw['check']['manifest']['machine'][name],
             'workflow machine identity differs: ' + name)
    raw_record = {'valid': True, 'phase': collection.phase, 'completed_at': datetime.now(timezone.utc).isoformat(),
                  'both_workflows_complete_before_effects': True, 'source_freeze_sha256': source_freeze,
                  'transfer_manifest_sha256': collection.receipt['transfer_manifest_sha256'],
                  'workloads': {workload: row['raw'] for workload, row in raw.items()}, 'accepted_ir': prior}
    write(output / 'raw-integrity.json', raw_record)
    effects = {'phase': collection.phase, 'workloads': {}, 'native_wall_time_claim_allowed': not instruction,
               'fixed_method': {'confidence': 0.99, 'bootstrap_resamples': 20000, 'bootstrap_seed': 1701,
                                'minimum_reduction': 0.01, 'maximum_sign_p': 0.01}}
    for workload in ('test', 'check'):
        rebuilt = analysis_for(raw[workload], instruction)
        observed = read(raw[workload]['analysis_path'])
        statistics.equal(observed, rebuilt, workload + '.analysis')
        selected = rebuilt['metrics']['cargo_ir']['statistics'] if instruction else rebuilt
        statistics.equal(raw[workload]['phase_result']['statistics'], selected, workload + '.phase_statistics')
        gate = statistics.gate('ir' if instruction else 'native', selected)
        need(raw[workload]['phase_result']['passes'] is gate['passes_gate'], 'reported gate differs from recomputation')
        effects['workloads'][workload] = {'statistics': selected, 'gate': gate,
                                         'analysis_sha256': sha(raw[workload]['analysis_path'])}
    primary = effects['workloads']['test']['gate']['passes_gate']
    secondary = effects['workloads']['check']['gate']['passes_gate']
    need(phase_state['primary_passes'] is primary and phase_state['secondary_passes'] is secondary,
         'phase-level selection gates differ')
    collection.verify_files()
    need(freeze_check() == source_freeze, 'reviewer source changed during review')
    write(output / 'effects.json', effects)
    result = {'valid': True, 'phase': collection.phase, 'reviewed_at': datetime.now(timezone.utc).isoformat(),
              'source_freeze_sha256': source_freeze, 'approval_sha256': approval['_sha256'],
              'collection_receipt_sha256': sha(collection.receipt_path),
              'transfer_manifest_sha256': collection.receipt['transfer_manifest_sha256'],
              'archive_sha256': collection.receipt['archive_sha256'],
              'raw_integrity_before_effects': True, 'raw_integrity_sha256': sha(output / 'raw-integrity.json'),
              'effects_sha256': sha(output / 'effects.json'), 'primary_passes': primary,
              'secondary_passes': secondary, 'cohort_sha256': COHORT, 'finalized_sha256': FINAL,
              'protocol_sha256': PROTOCOL, 'variant_sha256': BINARIES, 'original_source_sha256': ORIGINAL,
              'accepted_ir': prior, 'no_host_or_workload_execution': True,
              'scope': 'Current179 dirty uv build-only calls. Both fixed workflows and every warmup retained; no pooling or exclusions. Ir excludes compiler children; instrumented elapsed is never native time.'}
    write(output / 'review.json', result)
    write(output / 'seal.json', {path.name: sha(path) for path in sorted(output.iterdir()) if path.is_file()})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('ir-confirmation', 'native-confirmation'))
    parser.add_argument('--controls', required=True)
    parser.add_argument('--approval', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--accepted-ir')
    args = parser.parse_args()
    frozen = freeze_check()
    approval = read(args.approval)
    output = Path(args.output).absolute()
    need(output.resolve() == output and not output.exists(), 'review output must be a new canonical directory')
    need(approval['valid'] is True and approval['source_freeze_sha256'] == frozen
         and approval['phase'] == args.phase and approval['output'] == str(output),
         'root approval does not bind this source, phase and new output')
    receipt = Path(args.controls) / (args.phase + '-collection-receipt.json')
    need(approval['collection_receipt_sha256'] == sha(receipt), 'root approval names another terminal collection')
    approval['_sha256'] = sha(args.approval)
    collection = Collection(args.controls, args.phase)
    output.mkdir(parents=True, exist_ok=False)
    result = review_group(collection, output, frozen, approval, args.accepted_ir)
    print(json.dumps({'valid': result['valid'], 'phase': result['phase'],
                      'primary_passes': result['primary_passes'], 'secondary_passes': result['secondary_passes'],
                      'review_sha256': sha(output / 'review.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
