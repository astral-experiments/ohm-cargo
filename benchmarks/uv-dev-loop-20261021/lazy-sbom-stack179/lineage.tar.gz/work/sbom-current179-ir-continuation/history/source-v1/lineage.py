"""Read-only evidence path/lineage adapter; statistics and sample parsing are unchanged."""
from pathlib import Path

NEW = 'results/ir-completion-01'
CAPSULE = 'continuations/ir-check-01'
FAILED_STATUS = '3b71370c8e07057ae8a345470d0e583e4ac13e5cb72662968a08faf1169e0ac1'
FAILED_CAPTURE = 'd20d773a4f8c5016fbe6f20efc67cec9089832e53b886a767e5de2a1f0b6a109'


def result_name(workload, phase):
    return NEW + '/check' if (workload, phase) == ('check', 'ir-confirmation') else 'results/' + workload + '-' + phase


def analysis_name(workload, phase):
    return NEW + '/' + workload + '-analysis' if phase == 'ir-confirmation' else result_name(workload, phase)


def status_name(phase):
    return NEW + '/status.json' if phase == 'ir-confirmation' else 'results/' + phase + '.json'


def raw_seal(collection, directory):
    from evidence import need, sha
    workload = 'test' if directory == 'results/test-ir-confirmation' else 'check'
    need(directory == result_name(workload, 'ir-confirmation'), 'unexpected continued raw directory')
    sealed = collection.json(NEW + '/raw-seals.json')[workload]
    prefix = directory + '/'
    need(set(sealed) == {name[len(prefix):] for name in collection.files if name.startswith(prefix)},
         'continued raw seal member set differs')
    for name, digest in sealed.items():
        need(collection.files[prefix + name]['sha256'] == digest, 'continued raw sample bytes changed')
    return sha(collection.path(NEW + '/raw-seals.json'))


def verify(collection):
    from evidence import FINAL, PROTOCOL, REFERENCE, need, read, sha
    reference = REFERENCE / 'continuation'
    expected = sha(reference / 'capsule-manifest.json')
    need(sha(collection.path(CAPSULE + '/capsule-manifest.json')) == expected, 'continuation capsule differs')
    capsule = read(reference / 'capsule-manifest.json')
    for name, row in capsule['files'].items():
        need(collection.files.get(CAPSULE + '/' + name) == row, 'continuation source/input payload differs: ' + name)
    failure = collection.json(CAPSULE + '/failed/transfer-manifest.json')['files']
    need(sha(collection.path(CAPSULE + '/failed/transfer-manifest.json')) == FAILED_CAPTURE
         and len(failure) == 768 and sha(collection.path('results/ir-confirmation.json')) == FAILED_STATUS,
         'original failed capture/status changed')
    changed = {'collection-identity.json', 'failure-boundary.json',
               'fixtures/check-ir-confirmation/state.json', 'fixtures/check-ir-confirmation/journal.jsonl'}
    if collection.phase == 'native-confirmation':
        changed |= {f'fixtures/{workload}-native-confirmation/{name}' for workload in ('test', 'check')
                    for name in ('state.json', 'journal.jsonl')}
    for name, row in failure.items():
        if name not in changed:
            need(collection.files.get(name) == row, 'failed-run retained byte/mode changed: ' + name)
    need(collection.path('fixtures/check-ir-confirmation/journal.jsonl').read_bytes().startswith(
         collection.path(CAPSULE + '/failed/check-journal.jsonl').read_bytes()), 'check diagnostic journal prefix changed')
    state = collection.json(NEW + '/status.json')
    old = collection.json('results/ir-confirmation.json')
    need(old['state'] == 'failed' and old['completed_workloads'] == ['test']
         and state['state'] == 'complete' and state['group'] == 'ir-confirmation'
         and state['kind'] == 'continuation-of-unstarted-fixed-check'
         and state['completed_workloads'] == ['test', 'check'] and state['source_restored'] is True
         and state['started_at'] == old['started_at']
         and state['capsule_manifest_sha256'] == expected
         and state['failed_capture_sha256'] == FAILED_CAPTURE and state['failed_status_sha256'] == FAILED_STATUS
         and state['protocol_sha256'] == PROTOCOL and state['config_manifest_sha256'] == FINAL,
         'continued phase identity or original chronology changed')
    from preparation import instant
    test = collection.json('results/test-ir-confirmation/manifest.json')
    check = collection.json(NEW + '/check/manifest.json')
    raw = collection.json(NEW + '/raw-integrity.json')
    need(instant(test['finished_at']) <= instant(old['finished_at']) < instant(state['continuation_started_at'])
         <= instant(check['started_at']) < instant(check['finished_at']) <= instant(raw['completed_at'])
         <= instant(state['finished_at']), 'continued raw/phase chronology differs')
    need(raw['both_workflows_complete_before_effects'] is True
         and raw['test']['valid'] is raw['check']['valid'] is True
         and raw['test']['samples'] == raw['check']['samples'] == 28
         and state['raw_integrity_sha256'] == sha(collection.path(NEW + '/raw-integrity.json')),
         'both raw audits were not complete before analysis')
    collection.verify_seal(NEW)
    copies = collection.json(NEW + '/analysis-input-copies.json')
    for workload in ('test', 'check'):
        directory, analysis = result_name(workload, 'ir-confirmation'), analysis_name(workload, 'ir-confirmation')
        raw_seal(collection, directory)
        collection.verify_seal(analysis)
        need(set(copies[workload]) == {'manifest.json', 'samples.json', 'compiler-audit.json'},
             'unexpected analysis input copies')
        for name, digest in copies[workload].items():
            need(sha(collection.path(directory + '/' + name)) == digest
                 == sha(collection.path(analysis + '/' + name)), 'analysis used modified raw input')
        need(state['results'][workload]['analysis_sha256'] == sha(collection.path(analysis + '/analysis.json')),
             'continued status analysis binding differs')
    return {'valid': True, 'failed_capture_sha256': FAILED_CAPTURE, 'failed_status_sha256': FAILED_STATUS,
            'capsule_manifest_sha256': expected, 'original_test_samples_preserved': 28,
            'new_fixed_check_samples': 28, 'statistical_settings_unchanged': True}
