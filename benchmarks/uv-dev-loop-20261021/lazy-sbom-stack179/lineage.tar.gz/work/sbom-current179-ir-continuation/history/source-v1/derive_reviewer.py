"""Apply only collection/path/lineage adaptations to the accepted independent reviewer."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / 'sbom-current179-raw-review'
DEST = HERE / 'reviewer'


def substitute(source, old, new, count=1):
    assert source.count(old) == count, (old, source.count(old))
    return source.replace(old, new)


def main():
    original_freeze = json.loads((ORIGINAL / 'source-freeze.json').read_text())
    for name, row in original_freeze['files'].items():
        path = ORIGINAL / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        target = DEST / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    shutil.copyfile(HERE / 'lineage.py', DEST / 'lineage.py')
    reference = DEST / 'reference/continuation'
    reference.mkdir(parents=True, exist_ok=True)
    for name in ('capsule-manifest.json', 'collect.py', 'adaptation-identities.json'):
        shutil.copyfile(HERE / name, reference / name)
    shutil.copyfile(ORIGINAL / 'source-freeze.json', reference / 'original-reviewer-freeze.json')
    shutil.copyfile(ORIGINAL / 'root-source-review.json', reference / 'original-root-review.json')
    diffs = []
    for name in ('evidence.py', 'raw.py', 'preparation.py', 'review.py'):
        original = (DEST / name).read_text()
        source = original
        if name in ('evidence.py', 'raw.py', 'preparation.py'):
            source = 'import lineage\n' + source
        if name == 'evidence.py':
            source = substitute(source, "self.receipt['collector_sha256'] == COLLECTOR",
                "self.receipt['collector_sha256'] == sha(REFERENCE / 'continuation/collect.py')")
            source = substitute(source, "        self.verify_files()\n        self.verify_archive()",
                """        need(self.receipt['continuation_capsule_sha256'] == sha(REFERENCE / 'continuation/capsule-manifest.json'),
             'collection belongs to another continuation capsule')
        self.verify_files()
        self.verify_archive()""")
            source = substitute(source, "    def verify_seal(self, directory):\n        seal =",
                """    def verify_seal(self, directory):
        if self.phase == 'ir-confirmation' and directory in ('results/test-ir-confirmation', 'results/ir-completion-01/check'):
            return lineage.raw_seal(self, directory)
        seal =""")
            source = substitute(source, "    state = collection.json('results/' + collection.phase + '.json')",
                "    lineage.verify(collection)\n    state = collection.json(lineage.status_name(collection.phase))")
            source = substitute(source, "sha(collection.path('results/' + collection.phase + '.json'))",
                "sha(collection.path(lineage.status_name(collection.phase)))")
        elif name == 'raw.py':
            source = substitute(source, "    result_name = 'results/' + name",
                "    result_name = lineage.result_name(workload, group)\n    analysis_name = lineage.analysis_name(workload, group)")
            source = substitute(source, "collection.path(result_name + '/analysis.json')",
                "collection.path(analysis_name + '/analysis.json')", count=2)
        elif name == 'preparation.py':
            source = substitute(source, "    result_path = REMOTE + '/results/' + name",
                "    result_path = REMOTE + '/' + lineage.result_name(workload, group)")
            source = substitute(source, "collection.json('results/' + name + '/fixture-validation.json')",
                "collection.json(result_path + '/fixture-validation.json')")
        else:
            before = """    prefixes = ('results/test-ir-confirmation/', 'results/check-ir-confirmation/',
                'fixtures/test-ir-confirmation/', 'fixtures/check-ir-confirmation/')
    names = {name for name in original if name.startswith(prefixes)
             or name == 'results/ir-confirmation.json'
             or name.startswith(('logs/test-ir-confirmation.', 'logs/check-ir-confirmation.'))}
    need(names and 'results/ir-confirmation.json' in names, 'accepted IR payload set is incomplete')"""
            after = """    native_mutable = {'collection-identity.json'} | {
        f'fixtures/{workload}-native-confirmation/{name}' for workload in ('test', 'check')
        for name in ('state.json', 'journal.jsonl')}
    names = set(original) - native_mutable
    need({'results/ir-confirmation.json', 'results/ir-completion-01/status.json',
          'continuations/ir-check-01/capsule-manifest.json'} <= names,
         'accepted IR continuation/failure payload set is incomplete')"""
            source = substitute(source, before, after)
        compile(source, name, 'exec')
        (DEST / name).write_text(source)
        diffs.extend(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                                         fromfile='accepted/' + name, tofile='continued/' + name))
    (HERE / 'reviewer-adaptations.diff').write_text(''.join(diffs))
    for name in ('statistics_review.py', 'parser.py'):
        assert (ORIGINAL / name).read_bytes() == (DEST / name).read_bytes()
    print('Derived independent reviewer; pure parser and statistics remain byte-identical.')


if __name__ == '__main__':
    main()
