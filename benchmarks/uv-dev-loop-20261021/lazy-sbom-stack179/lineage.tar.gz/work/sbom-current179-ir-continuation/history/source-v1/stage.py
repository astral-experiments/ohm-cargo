#!/usr/bin/env python3
"""Stage only an absent frozen continuation capsule; never launch a workload."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
SSH = '/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_approval(path, operation):
    freeze = json.loads((HERE / 'source-freeze.json').read_text())
    for name, row in freeze['files'].items():
        item = HERE / name
        assert item.is_file() and not item.is_symlink() and item.resolve() == item
        assert sha(item) == row['sha256'] and item.stat().st_size == row['bytes'], name
    approval = json.loads(Path(path).read_text())
    assert approval['valid'] is True and operation in approval['approved_operations']
    assert approval['source_freeze_sha256'] == sha(HERE / 'source-freeze.json')
    assert approval['capsule_manifest_sha256'] == sha(HERE / 'capsule-manifest.json')
    return approval


REMOTE = r'''
from pathlib import Path, PurePosixPath
import fcntl, hashlib, io, json, os, stat, sys, tarfile
root = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')
capsule = root / 'continuations/ir-check-01'
assert root.resolve() == root and root.stat().st_uid == os.getuid() == 1000
assert Path('/').stat().st_uid == 0
ownership = json.loads((root / 'ownership.json').read_text())
assert ownership['root'] == str(root) and ownership['uid'] == os.getuid()
assert not capsule.exists() and not capsule.is_symlink()
assert not (root / 'results/ir-completion-01').exists()
lock = (root / 'experiment.lock').open('rb')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
data = sys.stdin.buffer.read()
assert hashlib.sha256(data).hexdigest() == sys.argv[1]
with tarfile.open(fileobj=io.BytesIO(data), mode='r:') as archive:
    members = archive.getmembers()
    assert len({member.name for member in members}) == len(members)
    payload = {}
    for member in members:
        name = PurePosixPath(member.name)
        assert member.isfile() and str(name) == member.name and not name.is_absolute()
        assert '..' not in name.parts and member.name not in ('', '.')
        assert member.mode == 0o644
        payload[member.name] = archive.extractfile(member).read()
    manifest_bytes = payload['capsule-manifest.json']
    assert hashlib.sha256(manifest_bytes).hexdigest() == sys.argv[2]
    manifest = json.loads(manifest_bytes)
    assert set(payload) == set(manifest['files']) | {'capsule-manifest.json'}
    for name, row in manifest['files'].items():
        assert row['mode'] == 0o644 and len(payload[name]) == row['bytes']
        assert hashlib.sha256(payload[name]).hexdigest() == row['sha256']
parent = capsule.parent
if not parent.exists():
    parent.mkdir()
assert parent.resolve() == parent and parent.is_dir() and parent.stat().st_uid == os.getuid()
capsule.mkdir()
for name, data in sorted(payload.items()):
    path = capsule / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(0o644)
sys.path.insert(0, str(capsule))
import contract
contract.verify_capsule(capsule, sys.argv[2])
contract.inputs(root)
retained = contract.preserved(root, capsule)
assert not (root / 'results/ir-completion-01').exists()
print(json.dumps({'valid': True, 'operation': 'stage-only', 'root': str(root), 'capsule': str(capsule),
                  'uid': os.getuid(), 'capsule_manifest_sha256': sys.argv[2],
                  'files': len(payload), 'retained_failed_payloads': len(retained),
                  'source_sha256': contract.sha(root / 'uv/crates/uv/src/lib.rs'),
                  'no_cargo_or_comparison_executed': True}, sort_keys=True))
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approval', required=True)
    args = parser.parse_args()
    verify_approval(args.approval, 'stage')
    assert not (HERE / 'stage-receipt.json').exists()
    manifest = json.loads((HERE / 'capsule-manifest.json').read_text())
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:') as archive:
        for name in sorted(set(manifest['files']) | {'capsule-manifest.json'}):
            data = (HERE / name).read_bytes()
            entry = tarfile.TarInfo(name); entry.mode = 0o644; entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    process = subprocess.run([SSH, 'charlie-oss-4', '--', 'env', '-u', 'PYTHONPATH', '-u', 'PYTHONHOME',
        '-u', 'PYTHONSAFEPATH', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3', '-B', '-c', REMOTE,
        hashlib.sha256(data).hexdigest(), sha(HERE / 'capsule-manifest.json')], input=data, capture_output=True)
    for suffix, payload in (('stdout', process.stdout), ('stderr', process.stderr)):
        with (HERE / ('stage.' + suffix)).open('xb') as stream:
            stream.write(payload)
    receipt = {'returncode': process.returncode, 'approval_sha256': sha(Path(args.approval)),
               'source_freeze_sha256': sha(HERE / 'source-freeze.json'),
               'capsule_manifest_sha256': sha(HERE / 'capsule-manifest.json'),
               'stdout_sha256': sha(HERE / 'stage.stdout'), 'stderr_sha256': sha(HERE / 'stage.stderr')}
    if process.returncode == 0:
        receipt['remote'] = json.loads(process.stdout)
    with (HERE / 'stage-receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(receipt, sort_keys=True))
    raise SystemExit(process.returncode)


if __name__ == '__main__':
    main()
