import lineage
"""Independent joins for deterministic edits, restoration and check convergence."""
from datetime import datetime
import json
import re

from evidence import ORIGINAL, REMOTE, digest, need, sha


def instant(value):
    result = datetime.fromisoformat(value)
    need(result.tzinfo is not None, 'timestamp lacks timezone')
    return result.timestamp()


def edited(original, batch, stage, pair, position):
    need(stage in ('warmup', 'measurement') and type(pair) is int and 0 <= pair <= 99999999,
         'invalid deterministic edit identity')
    need(position in ('before', 'after_'), 'unknown edit state')
    batch_hash = digest(batch.encode())[:16]
    stage_tag = {'warmup': 'warm', 'measurement': 'meas'}[stage]
    separator = b'\n' if original.endswith(b'\n') else b'\n\n'
    return original + separator + (
        f'// ohm-dev-loop-fixture batch={batch_hash} stage={stage_tag} pair={pair:08d} state={position}\n'
    ).encode()


def objects(text):
    """Cargo JSON messages followed by one pretty-printed guard receipt."""
    decoder, values, offset = json.JSONDecoder(), [], 0
    while offset < len(text):
        while offset < len(text) and text[offset].isspace():
            offset += 1
        if offset == len(text):
            break
        value, offset = decoder.raw_decode(text, offset)
        need(isinstance(value, dict), 'nonobject preparation output')
        values.append(value)
    return values


def successful_json_build(text, require_fresh=False):
    messages = [json.loads(line) for line in text.splitlines()]
    need(messages and all(isinstance(row, dict) for row in messages), 'empty/nonobject Cargo JSON build')
    finished = [row for row in messages if row.get('reason') == 'build-finished']
    need(finished == [{'reason': 'build-finished', 'success': True}] and messages[-1] == finished[0],
         'native preparation did not end in one successful build')
    artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact']
    need(artifacts, 'native preparation has no compiler-artifact records')
    if require_fresh:
        need(all(row.get('fresh') is True for row in artifacts), 'final BEFORE call is not fully fresh')
    return artifacts


def convergence(collection, entry, source, mode, parser):
    identity = {key: entry[key] for key in ('batch', 'stage', 'pair', 'variant')}
    directory = (identity['batch'] + '/check-preparation/'
                 + f"{identity['stage']}-{identity['pair']:08d}-{identity['variant']}")
    path = directory + '/manifest.json'
    need(entry.get('preparation_proof') == {'path': path, 'sha256': sha(collection.path(path))},
         'check proof is not bound to this exact sample')
    record = collection.json(path)
    need(record['state'] == 'complete' and record['identity'] == identity
         and record['fixed_native_calls'] == 3 and record['command'] == entry['warm_command'],
         'check proof call count/identity/command mismatch')
    need(record['target'] == entry['target'] and record['shared_build_dir'] == entry['shared_build_dir'],
         'check proof target/shared path changed')
    before = record['source']
    need(before['path'] == source and before['sha256'] == entry['before_sha256']
         and before['bytes'] == entry['before_bytes'] and before['mode'] == mode
         and type(before['mtime_ns']) is int and 0 < before['mtime_ns'] < entry['source_mtime_ns'],
         'check proof does not bind the exact BEFORE bytes/mode and subsequent edit')
    need(re.fullmatch('[0-9a-f]{64}', record['environment_sha256']) is not None,
         'missing check preparation environment fingerprint')
    need([(row['number'], row['returncode']) for row in record['calls']] == [(1, 0), (2, 0), (3, 0)],
         'check preparation is not exactly three successful calls')
    for row in record['calls']:
        number = row['number']
        suffixes = ('stdout', 'stderr', 'execve') if number == 3 else ('stdout', 'stderr')
        need(set(row) == {'number', 'returncode'} | {suffix + '_sha256' for suffix in suffixes},
             'unexpected check preparation call fields')
        for suffix in suffixes:
            need(sha(collection.path(directory + f'/call-{number}.{suffix}')) == row[suffix + '_sha256'],
                 'check preparation raw log hash mismatch')
        successful_json_build(collection.path(directory + f'/call-{number}.stdout').read_text(), number == 3)
    allowed = ['/usr/bin/taskset', entry['warm_command'][3]]
    need(record['allowed_final_executables'] == allowed, 'check proof executable allowlist changed')
    stdout = collection.path(directory + '/call-3.stdout').read_text()
    stderr = collection.path(directory + '/call-3.stderr').read_text()
    trace = collection.path(directory + '/call-3.execve').read_text()
    executions = parser.trace_executables(trace)
    need(executions == allowed and re.search(r'^\s*Running `', stderr, re.MULTILINE) is None,
         'final BEFORE call executed compiler/build-script/test work')
    artifacts = successful_json_build(stdout, True)
    freshness = {'artifact_records': len(artifacts), 'all_artifacts_fresh': True,
                 'successful_execve_paths': executions, 'compiler_build_script_test_executions': 0}
    need(record['final_freshness'] == freshness, 'recorded freshness does not match raw replay')
    return {'proof_sha256': sha(collection.path(path)), 'fixed_native_calls': 3,
            'before_mtime_ns': before['mtime_ns'], 'after_mtime_ns': entry['source_mtime_ns'], **freshness}


def fixture(collection, workload, group, samples, configuration, guard, parser):
    name = workload + '-' + group
    state_path = REMOTE + '/fixtures/' + name
    result_path = REMOTE + '/' + lineage.result_name(workload, group)
    manifest = collection.json(state_path + '/manifest.json')
    state = collection.json(state_path + '/state.json')
    original = collection.path(state_path + '/original.bin').read_bytes()
    need(digest(original) == ORIGINAL and manifest['source_sha256'] == ORIGINAL
         and manifest['source'] == guard['source'] and manifest['workspace'] == configuration['cwd']
         and manifest['source_mode'] == guard['source_mode'], 'fixture original source identity changed')
    need(collection.path('uv/crates/uv/src/lib.rs').read_bytes() == original
         and collection.files['uv/crates/uv/src/lib.rs']['mode'] == manifest['source_mode'],
         'final uv source bytes/mode were not restored')
    targets = {variant: configuration['variant_env'][variant]['CARGO_TARGET_DIR']
               for variant in ('baseline', 'candidate')}
    shared = configuration['env']['CARGO_BUILD_BUILD_DIR']
    need(manifest['targets'] == targets and manifest['shared_build_dir'] == shared
         and guard['states'][state_path] == {'targets': targets, 'shared_build_dir': shared, 'workload': workload},
         'fixture target assignment or shared path differs from frozen guard')
    need(state['current_sha256'] == ORIGINAL and state['restored'] is True and 'pending_sha256' not in state,
         'fixture retained a pending or unrestored source edit')
    journal_path = collection.path(state_path + '/journal.jsonl')
    journal = [json.loads(line) for line in journal_path.read_text().splitlines()]
    need(journal and journal[0]['operation'] == 'initialize' and journal[0]['source_sha256'] == ORIGINAL,
         'fixture initialization journal missing')
    need(sum(row['operation'] == 'initialize' for row in journal) == 1, 'fixture was reinitialized')
    need(all(row['operation'] in ('initialize', 'prepare', 'warm-failed', 'restore') for row in journal),
         'unexpected fixture journal operation')
    need(all(instant(a['at']) <= instant(b['at']) for a, b in zip(journal, journal[1:])),
         'fixture journal timestamps are out of order')
    indexed = [(index, row) for index, row in enumerate(journal) if row.get('batch') == result_path]
    need(len(indexed) == len(samples) and all(row['operation'] == 'prepare' for _, row in indexed),
         'missing/extra/failed preparation for the measured batch')
    first = indexed[0][0]
    need([index for index, _ in indexed] == list(range(first, first + len(samples)))
         and len(journal) == first + len(samples) + 1, 'preparation journal interleaves or adds measured work')
    last = journal[-1]
    need({key: value for key, value in last.items() if key != 'at'} == {
        'operation': 'restore', 'source': guard['source'], 'sha256': ORIGINAL}, 'final restoration journal differs')
    seen, paired_edits, rows, proofs = set(), {}, [], []
    for sample, (_, entry) in zip(samples, indexed):
        key = (sample['stage'], sample['pair'], sample['variant'])
        need(key == (entry['stage'], entry['pair'], entry['variant']) and key not in seen,
             'preparation journal and ordered sample identities differ')
        seen.add(key)
        before = edited(original, result_path, key[0], key[1], 'before')
        after = edited(original, result_path, key[0], key[1], 'after_')
        need(before != after and len(before) == len(after) and entry['before_sha256'] == digest(before)
             and entry['after_sha256'] == digest(after) and entry['before_bytes'] == len(before)
             and entry['after_bytes'] == len(after), 'source edit bytes/token differ from deterministic protocol')
        need(entry['target'] == targets[key[2]] and entry['shared_build_dir'] == shared
             and entry['warm_command'] == guard['commands'][workload], 'native preparation command/path mismatch')
        need(type(entry['source_mtime_ns']) is int and entry['source_mtime_ns'] > 0
             and type(entry['warm_wall_ns']) is int and 0 < entry['warm_wall_ns'] <= sample['prepare']['wall_ns'],
             'invalid preparation timing or source timestamp')
        need(instant(entry['at']) <= instant(sample['started_at']), 'edit was recorded after timed work began')
        output = objects(collection.path(sample['prepare']['stdout']).read_text())
        need(output and output[-1] == {key: value for key, value in entry.items() if key != 'at'},
             'preparation stdout and source journal differ')
        if workload == 'check':
            need(len(output) == 1, 'check preparation bypassed captured three-call logs')
            proofs.append(convergence(collection, entry, guard['source'], guard['source_mode'], parser))
        else:
            need('preparation_proof' not in entry, 'unexpected test preparation convergence hook')
            messages = output[:-1]
            need(messages and messages[-1] == {'reason': 'build-finished', 'success': True}
                 and [row for row in messages if row.get('reason') == 'build-finished'] == [messages[-1]],
                 'test prerequisite build did not finish exactly once')
        paired_edits.setdefault(key[:2], []).append((entry['before_sha256'], entry['after_sha256']))
        rows.append({'stage': key[0], 'pair': key[1], 'variant': key[2], 'compiled_packages': ['uv'],
                     'before_sha256': entry['before_sha256'], 'after_sha256': entry['after_sha256'],
                     'target': entry['target']})
    need(all(len(values) == 2 and values[0] == values[1] for values in paired_edits.values()),
         'paired variants did not receive identical source edits')
    need(len({values[0][1] for values in paired_edits.values()}) == len(paired_edits),
         'source AFTER token was reused across fixed pairs')
    for variant in ('baseline', 'candidate'):
        entry = next(row for _, row in reversed(indexed) if row['variant'] == variant)
        need(state['last_tokens'][variant] == entry['after_sha256'], 'final fixture token differs from final sample')
    need(set(state['last_tokens']) == {'baseline', 'candidate'}, 'unexpected fixture variant token')
    validation = {'valid': True, 'expected_compiled_packages': ['uv'], 'source_restored': True,
                  'samples': rows, 'errors': []}
    need(collection.json(result_path + '/fixture-validation.json') == validation,
         'stored fixture validation does not match independent journal replay')
    return {'journal_sha256': sha(journal_path), 'preparations': len(rows), 'restored_at': last['at'],
            'unique_pair_edits': len(paired_edits), 'check_convergence': proofs}
