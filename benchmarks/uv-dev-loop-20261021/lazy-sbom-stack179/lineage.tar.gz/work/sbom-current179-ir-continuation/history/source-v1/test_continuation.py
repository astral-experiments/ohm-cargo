"""Pure source, preservation and retained-raw checks. No host or workload execution."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import contract
sys.path.insert(0, str(HERE / 'reviewer'))
import lineage

FAILED = HERE.parent / 'dirty-sbom-current179/evidence/ir-failed-before-check'
REMOTE = Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179')


def tree(source):
    return ast.dump(ast.parse(source), include_attributes=False)


def original_parts():
    source = (HERE / 'original/run_group.py').read_text()
    main = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    attempt = next(node for node in main.body if isinstance(node, ast.Try))
    index = next(index for index, node in enumerate(attempt.body)
                 if isinstance(node, ast.For) and ast.unparse(node.target) == 'workload')
    return source, ast.unparse(ast.Module(body=[attempt.body[index]], type_ignores=[])), ast.unparse(ast.Module(body=attempt.body[index + 1:], type_ignores=[]))


class ContinuationTests(unittest.TestCase):
    def test_check_loop_has_exact_five_adaptations(self):
        _, expected, _ = original_parts()
        actual = (HERE / 'check-loop.py').read_text()
        actual = actual.replace("for workload in ('check',):", "for workload in ('test', 'check'):")
        actual = actual.replace("Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check')", "ROOT / 'results' / name")
        actual = actual.replace("Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check-occupancy.txt')", "ROOT / 'metadata' / f'{name}-occupancy.txt'")
        for suffix in ('stdout', 'stderr'):
            actual = actual.replace("Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/check.run." + suffix + "')", "ROOT / 'logs' / f'{name}.run." + suffix + "'")
        self.assertEqual(tree(actual), tree(expected))

    def test_analysis_tail_has_only_log_redirections(self):
        _, _, expected = original_parts()
        actual = (HERE / 'analysis-tail.py').read_text()
        actual = actual.replace("Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/analysis-logs')", "ROOT / 'logs'")
        self.assertEqual(tree(actual), tree(expected))

    def test_native_controller_has_only_prior_status_lookup(self):
        expected, _, _ = original_parts()
        actual = (HERE / 'native-original-controller.py').read_text().replace(
            "Path('/tmp/ohm-hillclimb-20261021/lazy-sbom-current179/results/ir-completion-01/status.json')",
            "ROOT / 'results' / f'{previous}.json'")
        self.assertEqual(tree(actual), tree(expected))

    def test_core_parser_and_statistics_remain_identical(self):
        self.assertEqual(contract.sha(HERE / 'original/paired.py'), contract.CORE)
        for name in ('parser.py', 'statistics_review.py'):
            self.assertEqual((HERE / 'reviewer' / name).read_bytes(),
                             (HERE.parent / 'sbom-current179-raw-review' / name).read_bytes())

    def test_fixed_check_protocol(self):
        protocol = contract.read(FAILED / 'work/benchmark/protocol.json')
        phase = next(row for row in protocol['phases'] if row['workload'] == 'check' and row['metric'] == 'cargo_ir')
        self.assertEqual((phase['pairs'], phase['warmup_pairs'], phase['seed']), (12, 2, 20261021102))
        self.assertEqual(phase['target_assignment'], {'baseline': 'cand', 'candidate': 'base'})
        self.assertEqual(phase['invocations_per_variant_per_pair'], 1)

    def test_fixed_native_protocol(self):
        protocol = contract.read(FAILED / 'work/benchmark/protocol.json')
        for workload, seed in (('test', 20261021103), ('check', 20261021104)):
            phase = next(row for row in protocol['phases'] if row['workload'] == workload and row['metric'] == 'native_wall_seconds')
            self.assertEqual((phase['pairs'], phase['warmup_pairs'], phase['seed']), (30, 2, seed))
            self.assertEqual(phase['invocations_per_variant_per_pair'], 1)

    def test_both_raw_audits_precede_original_analysis(self):
        source = (HERE / 'complete_ir.py').read_text()
        self.assertLess(source.index('test = contract.replay_test'), source.index("contract.write_new(output / 'raw-integrity.json'"))
        self.assertLess(source.index('boundary.validate_tables'), source.index("contract.write_new(output / 'raw-integrity.json'"))
        self.assertLess(source.index('read_callgrind_summary'), source.index("contract.write_new(output / 'raw-integrity.json'"))
        self.assertLess(source.index("contract.write_new(output / 'raw-integrity.json'"), source.index("exec(compile(tail"))
        self.assertIn("summary_path = output / 'status.json'", source)

    def test_analysis_input_copies_are_exact_and_new(self):
        source = (HERE / 'complete_ir.py').read_text()
        self.assertIn("destination = output / (workload + '-analysis')", source)
        self.assertIn("for name in ('manifest.json', 'samples.json', 'compiler-audit.json'):", source)
        self.assertIn("contract.sha(destination / name) == contract.sha(directory / name)", source)

    def test_no_loop_or_seed_changes_in_native(self):
        source = (HERE / 'native-original-controller.py').read_text()
        self.assertIn("for workload in ('test', 'check'):", source)
        self.assertIn("phase['pairs']", source)
        self.assertIn("phase['warmup_pairs']", source)
        self.assertIn("phase['seed']", source)
        self.assertEqual(source.count('subprocess.run(command, env=environment, stdout=out, stderr=err)'), 1)

    def test_all_python_sources_compile_without_execution(self):
        for path in HERE.rglob('*.py'):
            compile(path.read_text(), str(path), 'exec')
        for name in ('stage.py', 'launch.py', 'collect.py'):
            module = ast.parse((HERE / name).read_text())
            remote = next(ast.literal_eval(node.value) for node in module.body if isinstance(node, ast.Assign)
                          and any(isinstance(target, ast.Name) and target.id == 'REMOTE' for target in node.targets))
            compile(remote, name + ':REMOTE', 'exec')

    def test_rejects_unsafe_relative_names(self):
        for name in ('', '.', '../a', 'a/../b', '/tmp/a', 'a//b', 'a\\b'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                contract.relative(name)
        self.assertEqual(str(contract.relative('valid/file.json')), 'valid/file.json')

    def make_capsule(self, root):
        manifest = contract.read(HERE / 'capsule-manifest.json')
        for name in set(manifest['files']) | {'capsule-manifest.json'}:
            target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HERE / name, target); target.chmod(0o644)
        return contract.sha(root / 'capsule-manifest.json')

    def test_capsule_exact_member_hash_and_mode_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); expected = self.make_capsule(root)
            self.assertEqual(contract.verify_capsule(root, expected)['operation'], 'complete-original-fixed-check-ir-only')
            (root / 'unexpected').write_text('extra')
            with self.assertRaises(ValueError):
                contract.verify_capsule(root, expected)

    def test_capsule_rejects_changed_source(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); expected = self.make_capsule(root)
            with (root / 'check-loop.py').open('a') as stream:
                stream.write('\n# changed\n')
            with self.assertRaises(ValueError):
                contract.verify_capsule(root, expected)

    def test_capsule_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); expected = self.make_capsule(root)
            (root / 'check-loop.py').unlink()
            (root / 'check-loop.py').symlink_to(HERE / 'check-loop.py')
            with self.assertRaises(ValueError):
                contract.verify_capsule(root, expected)

    def test_failed_status_and_root_review_are_exact(self):
        self.assertEqual(contract.sha(HERE / 'failed/status.json'), contract.FAILED_STATUS)
        self.assertEqual(contract.sha(HERE / 'failed/transfer-manifest.json'), contract.FAILED_CAPTURE)
        self.assertEqual(contract.sha(HERE / 'failed/root-review.json'),
                         'e12f288103a2a6d533b2f365ca61358d3f4929be7de5bc34e5bca79b835246d9')
        status = contract.read(HERE / 'failed/status.json')
        self.assertEqual(status['completed_workloads'], ['test'])
        self.assertEqual(status['state'], 'failed')

    def test_historical_test_pure_replay_without_effects(self):
        boundary = contract.load('historical_test_boundary', HERE / 'boundary.py')
        ordinary = boundary.regular
        def collected_path(root, path):
            path = Path(path)
            if path.is_relative_to(REMOTE):
                path = FAILED.absolute() / path.relative_to(REMOTE)
            return ordinary(root, path)
        boundary.regular = collected_path
        with patch.object(contract, 'load', return_value=boundary):
            result = contract.replay_test(FAILED.absolute(), HERE)
        self.assertTrue(result['valid'])
        self.assertEqual(result['samples'], 28)
        self.assertEqual(result['compiler_invocations_per_sample'], 6)

    def test_retained_profiler_summaries_join_without_comparing_variants(self):
        source = ast.parse((HERE / 'original/paired.py').read_text())
        node = next(node for node in source.body if isinstance(node, ast.FunctionDef) and node.name == 'read_callgrind_summary')
        namespace = {'Path': Path}
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<frozen-summary-reader>', 'exec'), namespace)
        samples = contract.read(FAILED / 'results/test-ir-confirmation/samples.json')
        self.assertEqual(len(samples), 28)
        for sample in samples:
            row = sample['metric_files']['cargo_ir']
            path = FAILED / Path(row['path']).relative_to(REMOTE)
            self.assertEqual(contract.sha(path), row['sha256'])
            self.assertEqual(namespace['read_callgrind_summary'](path, 'Ir'), sample['metric_cargo_ir'])

    def test_lineage_maps_only_continued_ir_paths(self):
        self.assertEqual(lineage.result_name('test', 'ir-confirmation'), 'results/test-ir-confirmation')
        self.assertEqual(lineage.result_name('check', 'ir-confirmation'), 'results/ir-completion-01/check')
        for workload in ('test', 'check'):
            self.assertEqual(lineage.result_name(workload, 'native-confirmation'), f'results/{workload}-native-confirmation')
            self.assertEqual(lineage.analysis_name(workload, 'ir-confirmation'), f'results/ir-completion-01/{workload}-analysis')
        self.assertEqual(lineage.status_name('native-confirmation'), 'results/native-confirmation.json')

    def test_native_requires_separate_independent_acceptance(self):
        source = (HERE / 'native_entry.py').read_text()
        for field in ('accepted_ir_review_sha256', 'reviewer_source_freeze_sha256', 'raw_integrity_before_effects',
                      'primary_passes', 'continuation_status_sha256', 'transfer_manifest_sha256'):
            self.assertIn(field, source)
        self.assertLess(source.index("approval['valid']"), source.index('module.main()'))

    def test_collector_keeps_diagnostic_and_runtime_guards(self):
        source = (HERE / 'collector-remote.py').read_text()
        for fragment in ("len(complete['runs']) == 16", "runtime['baseline']['files'] == runtime['candidate']['files']",
                         "git('status', '--porcelain=v1') == ''", "for path, digest in final['asset_sha256'].items():",
                         "for name, expected in validated_result_files.items():"):
            self.assertIn(fragment, source)
        self.assertEqual(source.count('contract.verify_complete('), 2)
        self.assertNotIn("'analyze'", source)
        self.assertNotIn("'cargo'", source)

    def test_original_parser_and_statistics_source_freeze_still_valid(self):
        original = HERE.parent / 'sbom-current179-raw-review'
        freeze = contract.read(original / 'source-freeze.json')
        for name, row in freeze['files'].items():
            self.assertEqual(contract.sha(original / name), row['sha256'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
