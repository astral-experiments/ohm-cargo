"""Derive a completed-phase collector with explicit retained-failure lineage."""
import ast
import difflib
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent


def substitute(source, old, new, count=1):
    assert source.count(old) == count, (old, source.count(old))
    return source.replace(old, new)


def main():
    original = (HERE / 'original/collector.py').read_text()
    tree = ast.parse(original)
    remote_node = next(node for node in tree.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'REMOTE' for target in node.targets))
    remote = ast.literal_eval(remote_node.value)
    old_remote = remote
    contract_sha = hashlib.sha256((HERE / 'contract.py').read_bytes()).hexdigest()
    anchor = "ownership = json.loads((root / 'ownership.json').read_text())"
    remote = substitute(remote, anchor, f"""import fcntl
capsule = root / 'continuations/ir-check-01'
assert sha(capsule / 'contract.py') == {contract_sha!r}
sys.path.insert(0, str(capsule))
import contract
lock = (root / 'experiment.lock').open('rb')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
contract.verify_complete(root, capsule, sys.argv[3], native=sys.argv[2] == 'native-confirmation')
continuation_seal_path = root / 'results/ir-completion-01/seal.json'
continuation_seal_bytes = continuation_seal_path.read_bytes()
continuation_seal = json.loads(continuation_seal_bytes)
{anchor}""")
    remote = substitute(remote, "phase_status_path = root / 'results' / (phase + '.json')",
        "phase_status_path = (root / 'results/ir-completion-01/status.json' if phase == 'ir-confirmation' else root / 'results' / (phase + '.json'))")
    remote = substitute(remote,
        "validated_result_files = {str(phase_status_path.relative_to(root)): hashlib.sha256(phase_status_bytes).hexdigest()}",
        """validated_result_files = {str(phase_status_path.relative_to(root)): hashlib.sha256(phase_status_bytes).hexdigest()}
validated_result_files['results/ir-completion-01/seal.json'] = hashlib.sha256(continuation_seal_bytes).hexdigest()
for name, digest in continuation_seal.items():
    path = root / 'results/ir-completion-01' / name
    assert path.resolve() == path and path.is_relative_to(root / 'results/ir-completion-01') and not path.is_symlink()
    assert sha(path) == digest
    validated_result_files[str(path.relative_to(root))] = digest""")
    remote = substitute(remote, "'ohm-sbom179-' + phase", "('ohm-sbom179-ir-completion-01' if phase == 'ir-confirmation' else 'ohm-sbom179-' + phase)")
    remote = substitute(remote, "    result = root / 'results' / name",
        """    result = (root / 'results/ir-completion-01/check' if (workload, phase) == ('check', 'ir-confirmation') else root / 'results' / name)
    analysis = (root / 'results/ir-completion-01' / (workload + '-analysis') if phase == 'ir-confirmation' else result)""")
    remote = substitute(remote,
        "    seal_bytes = (result / 'seal.json').read_bytes()\n    sealed = json.loads(seal_bytes)\n    validated_result_files[str((result / 'seal.json').relative_to(root))] = hashlib.sha256(seal_bytes).hexdigest()",
        """    result_seal_path = (root / 'results/ir-completion-01/raw-seals.json' if phase == 'ir-confirmation' else result / 'seal.json')
    seal_bytes = result_seal_path.read_bytes()
    sealed = json.loads(seal_bytes)
    if phase == 'ir-confirmation':
        sealed = sealed[workload]
    validated_result_files[str(result_seal_path.relative_to(root))] = hashlib.sha256(seal_bytes).hexdigest()""")
    remote = substitute(remote, "sha(result / 'analysis.json')", "sha(analysis / 'analysis.json')")
    remote = substitute(remote, "'logs', 'build', 'results'):", "'logs', 'build', 'results', 'continuations'):")
    remote = substitute(remote, "'phase_state_sha256': sha(root / 'results' / (phase + '.json'))",
        "'phase_state_sha256': sha(phase_status_path), 'continuation_capsule_sha256': sys.argv[3], 'retained_failed_status_sha256': contract.FAILED_STATUS, 'retained_failed_capture_sha256': contract.FAILED_CAPTURE")
    remote = substitute(remote, "payload['collection-identity.json'] =",
        "contract.verify_complete(root, capsule, sys.argv[3], native=phase == 'native-confirmation')\npayload['collection-identity.json'] =")
    # Keep every unchanged source/diagnostic/input/runtime and archive check.
    source = original[:remote_node.value.col_offset] if False else original
    start, end = remote_node.value.lineno - 1, remote_node.value.end_lineno
    lines = original.splitlines(True)
    # The assignment occupies complete source lines in the reviewed collector.
    assert lines[start].startswith("REMOTE = r'''") and lines[end - 1].strip() == "'''"
    source = ''.join(lines[:start]) + 'REMOTE = ' + repr(remote) + '\n' + ''.join(lines[end:])
    source = substitute(source, 'parser.add_argument("--finalized-sha256", required=True)',
        'parser.add_argument("--finalized-sha256", required=True)\nparser.add_argument("--capsule-manifest-sha256", required=True)')
    source = substitute(source, 'assert not DEST.exists(), DEST',
        'assert hashlib.sha256((LOCAL / "capsule-manifest.json").read_bytes()).hexdigest() == args.capsule_manifest_sha256\nassert not DEST.exists(), DEST')
    source = substitute(source, 'REMOTE, args.finalized_sha256, args.phase,',
        'REMOTE, args.finalized_sha256, args.phase, args.capsule_manifest_sha256,')
    source = substitute(source, 'receipt["phase"] = args.phase',
        'receipt["phase"] = args.phase\nreceipt["continuation_capsule_sha256"] = args.capsule_manifest_sha256')
    (HERE / 'collect.py').write_text(source)
    (HERE / 'collector-remote.py').write_text(remote)
    (HERE / 'collector-remote.diff').write_text(''.join(difflib.unified_diff(
        old_remote.splitlines(True), remote.splitlines(True), fromfile='original/remote', tofile='continuation/remote')))
    local_old = original[:original.index("REMOTE = r'''")] + 'REMOTE = <reviewed remote source>\n' + ''.join(lines[end:])
    transformed_tree = ast.parse(source)
    assignment = next(node for node in transformed_tree.body if isinstance(node, ast.Assign)
                      and any(isinstance(target, ast.Name) and target.id == 'REMOTE' for target in node.targets))
    new_lines = source.splitlines(True)
    local_new = ''.join(new_lines[:assignment.lineno - 1]) + 'REMOTE = <reviewed remote source>\n' + ''.join(new_lines[assignment.end_lineno:])
    (HERE / 'collector-local.diff').write_text(''.join(difflib.unified_diff(
        local_old.splitlines(True), local_new.splitlines(True), fromfile='original/local', tofile='continuation/local')))
    compile(source, 'collect.py', 'exec'); compile(remote, 'collector-remote.py', 'exec')
    print('Derived completed-phase collector; no host action.')


if __name__ == '__main__':
    main()
