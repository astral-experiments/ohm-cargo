"""Pure/small retained-metadata tests; never construct a native Collection."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import re
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('admission_lineage_under_test', HERE / 'review_recovery.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
SCHEMA_COVERAGE = {}


def read(path):
    return json.loads(path.read_bytes())


class RecoveryLineageTests(unittest.TestCase):
    def setUp(self):
        self.capture = read(m.WORK / 'sbom-current179-native-failed-launch01/capture.json')
        self.receipt = read(m.RECOVERY / 'retention-attempt01/remote-receipt.json')
        self.plan = copy.deepcopy(self.receipt['retained_files'])
        self.index = read(m.RECOVERY / 'replay-copy-inputs.json')
        self.copied = read(m.RECOVERY / 'replay-copy-receipt.json')

    def terminal(self):
        protocol = read(m.REVIEWER / 'reference/protocol.json')
        hashes = {'test-native-confirmation': 'test-config', 'check-native-confirmation': 'check-config'}
        manifests = {}
        for phase in protocol['phases']:
            if phase['metric'] != 'native_wall_seconds':
                continue
            manifests[phase['workload']] = {
                'state': 'complete', 'phase': 'confirmation', 'pairs': 30, 'warmup_pairs': 2,
                'seed': phase['seed'], 'sample_count': 64,
                'plans': {'warmup': phase['warmup_plan'], 'measurement': phase['measurement_plan']},
                'configuration_sha256': hashes[phase['workload'] + '-native-confirmation'],
            }
        state = {'state': 'complete', 'group': 'native-confirmation',
                 'completed_workloads': ['test', 'check'], 'source_restored': True}
        return state, manifests, protocol['phases'], hashes

    def test_retained_11_file_metadata_corpus(self):
        m.check_retention_map(self.capture, self.receipt, self.plan)

    def test_retention_rejects_missing_file(self):
        self.plan.pop(next(iter(self.plan)))
        with self.assertRaises(ValueError):
            m.check_retention_map(self.capture, self.receipt, self.plan)

    def test_retention_rejects_wrong_origin_hash_and_mode(self):
        for field, wrong in [('origin', '/tmp/another-source'), ('sha256', '0' * 64), ('mode', 0)]:
            with self.subTest(field=field):
                plan = copy.deepcopy(self.plan)
                plan[next(iter(plan))][field] = wrong
                receipt = {**self.receipt, 'retained_files': plan}
                with self.assertRaises(ValueError):
                    m.check_retention_map(self.capture, receipt, plan)

    def test_retention_cannot_authorize_measurements(self):
        for key in ('native_workload_or_analysis_executed', 'replay_authorized_by_this_receipt'):
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.check_retention_map(self.capture, {**self.receipt, key: True}, self.plan)

    def test_actual_101_file_copy_metadata(self):
        m.check_copy(self.copied, self.index, self.copied['recovery_receipt_sha256'])

    def test_copy_requires_exact_119_and_101_maps(self):
        for key in ('protected_original_files', 'copied_files'):
            index = copy.deepcopy(self.index)
            index[key].pop(next(iter(index[key])))
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.check_copy(self.copied, index, self.copied['recovery_receipt_sha256'])

    def test_copy_requires_recovery_identity_and_preservation(self):
        with self.assertRaises(ValueError):
            m.check_copy(self.copied, self.index, '0' * 64)
        with self.assertRaises(ValueError):
            m.check_copy({**self.copied, 'all_original_local_paths_unchanged': False}, self.index,
                         self.copied['recovery_receipt_sha256'])

    def test_both_complete_fixed_native_plans(self):
        m.terminal_metadata(*self.terminal())

    def test_incomplete_second_workflow_blocks(self):
        for change in ('state', 'manifest'):
            state, manifests, phases, hashes = self.terminal()
            if change == 'state':
                state['completed_workloads'] = ['test']
            else:
                manifests['check']['state'] = 'running'
            with self.subTest(change=change), self.assertRaises(ValueError):
                m.terminal_metadata(state, manifests, phases, hashes)

    def test_wrong_counts_seed_or_plan_block(self):
        for field, wrong in [('pairs', 31), ('warmup_pairs', 3), ('sample_count', 66), ('seed', 20261021105)]:
            args = self.terminal()
            args[1]['test'][field] = wrong
            with self.subTest(field=field), self.assertRaises(ValueError):
                m.terminal_metadata(*args)
        args = self.terminal()
        args[1]['test']['plans'] = {'warmup': [], 'measurement': []}
        with self.assertRaises(ValueError):
            m.terminal_metadata(*args)

    def test_eight_call_protocol_is_not_accepted(self):
        args = self.terminal()
        next(p for p in args[2] if p['metric'] == 'native_wall_seconds')['invocations_per_variant_per_pair'] = 8
        with self.assertRaises(ValueError):
            m.terminal_metadata(*args)

    def test_unsafe_paths_and_symlinks_rejected(self):
        for name in ('../escape', '/absolute', 'a/../b', 'a\\b', '.', '', None):
            with self.subTest(name=name), self.assertRaises(ValueError):
                m.relative(name)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            (root / 'ordinary').write_text('metadata')
            (root / 'alias').symlink_to('ordinary')
            self.assertEqual(m.record(root / 'ordinary')['bytes'], 8)
            with self.assertRaises(ValueError):
                m.record(root / 'alias')

    def test_execution_and_network_audit_guard(self):
        for event in ('subprocess.Popen', 'socket.connect', 'socket.getaddrinfo', 'os.exec',
                      'os.spawn', 'os.posix_spawn', 'os.system', 'pty.spawn'):
            with self.subTest(event=event), self.assertRaises(ValueError):
                m.no_execution(event, ())
        m.no_execution('open', ())
        m.no_execution('import', ())

    def test_checker_never_imports_statistics_or_reads_native_analysis(self):
        tree = ast.parse((HERE / 'review_recovery.py').read_text())
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names.update(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                names.add(node.module)
        self.assertFalse(names & {'statistics', 'statistics_review', 'subprocess', 'socket', 'raw', 'review'})
        self.assertFalse(any(isinstance(node, ast.Constant) and isinstance(node.value, str)
                             and '/analysis.json' in node.value for node in ast.walk(tree)))
        source = (HERE / 'review_recovery.py').read_text()
        self.assertLess(source.index('terminal_metadata(phase_state'), source.index('recovery_sha = retention('))

    def test_unchanged_interfaces_match_documented_commands_and_scope(self):
        collector = (m.CONTROLS / 'collect.py').read_text()
        reviewer = (m.REVIEWER / 'review.py').read_text()
        self.assertIn("'continuations'", collector)
        self.assertIn('--finalized-sha256', collector)
        self.assertIn('--capsule-manifest-sha256', collector)
        self.assertIn("'--accepted-ir'", reviewer)
        self.assertLess(reviewer.index('raw[workload] = audit_workload'), reviewer.index("effects = {'phase': collection.phase"))
        paired = (m.REVIEWER / 'reference/paired.py').read_text()
        self.assertIn('"inherited_build_environment": build_environment_metadata()', paired)

    def test_sha256_constants_and_readme_have_full_hashes(self):
        for name in ('PREDECESSOR_FREEZE', 'RECOVERY_FREEZE', 'CONTROLS_FREEZE', 'REVIEWER_FREEZE',
                     'PREREQUISITE', 'CAPTURE', 'FAILED_STATUS', 'CONTROLLER', 'IR_REVIEW'):
            with self.subTest(name=name):
                self.assertTrue(m.is_sha256(getattr(m, name)))
        for token in re.findall(r'\b[0-9a-f]{40,80}\b', (HERE / 'README.md').read_text()):
            self.assertTrue(m.is_sha256(token), token)
        self.assertIn(m.IR_REVIEW, (HERE / 'README.md').read_text())
        for malformed in ('0' * 62, '0' * 63, '0' * 65, 'g' * 64, 'A' * 64, None):
            self.assertFalse(m.is_sha256(malformed))

    def test_actual_accepted_ir_review_identity(self):
        actual = m.record(m.CONTROLS / 'independent-ir-review-profiler-alias-v2/review.json')['sha256']
        self.assertEqual(m.IR_REVIEW, actual)
        manifest = read(m.ORIGINAL / 'prepared/manifest.json')
        self.assertEqual(manifest['files']['review/review.json']['sha256'], actual)

    def test_all_four_real_freeze_schemas_and_external_coverage(self):
        cases = [('lineage', m.PREDECESSOR, m.PREDECESSOR_FREEZE, (8, 14)),
                 ('recovery', m.RECOVERY, m.RECOVERY_FREEZE, (12, 139)),
                 ('launch', m.ORIGINAL, m.CONTROLS_FREEZE, (40, 352)),
                 ('raw_reviewer', m.REVIEWER, m.REVIEWER_FREEZE, (75, 0))]
        for role, directory, expected, counts in cases:
            with self.subTest(role=role):
                inputs = m.Inputs()
                freeze = m.verify_freeze(inputs, directory, expected)
                schema, actual_counts = m.validate_freeze_schema(freeze, role)
                self.assertEqual(actual_counts, counts)
                required = {str(directory / 'source-freeze.json')}
                required.update(str(directory / name) for name in freeze['files'])
                for field in schema['external']:
                    required.update(freeze[field])
                self.assertEqual(set(inputs.files), required)
                inputs.verify()
                SCHEMA_COVERAGE[role] = {'source_freeze_sha256': expected, 'internal_files': counts[0],
                                        'external_files': counts[1], 'external_fields': schema['external'],
                                        'all_declared_paths_hashed': True}

    def test_missing_unexpected_or_renamed_external_fields_rejected(self):
        for role, directory, field in [('lineage', m.PREDECESSOR, 'external_inputs'),
                                       ('recovery', m.RECOVERY, 'external_files'),
                                       ('launch', m.ORIGINAL, 'external_files')]:
            original = read(directory / 'source-freeze.json')
            for change in ('missing', 'renamed', 'additional'):
                freeze = copy.deepcopy(original)
                if change == 'missing':
                    freeze.pop(field)
                elif change == 'renamed':
                    freeze['external_filez'] = freeze.pop(field)
                else:
                    freeze['external_inputs' if field == 'external_files' else 'external_files'] = freeze[field]
                with self.subTest(role=role, change=change), self.assertRaises(ValueError):
                    m.validate_freeze_schema(freeze, role)
        raw = read(m.REVIEWER / 'source-freeze.json')
        raw['external_files'] = {}
        with self.assertRaises(ValueError):
            m.validate_freeze_schema(raw, 'raw_reviewer')

    def test_malformed_hashes_and_record_schemas_rejected(self):
        for change in ('short_hash', 'unknown_row_field', 'missing_mode', 'boolean_bytes'):
            freeze = read(m.RECOVERY / 'source-freeze.json')
            row = next(iter(freeze['external_files'].values()))
            if change == 'short_hash':
                row['sha256'] = '0' * 62
            elif change == 'unknown_row_field':
                row['extra'] = True
            elif change == 'missing_mode':
                row.pop('mode')
            else:
                row['bytes'] = True
            with self.subTest(change=change), self.assertRaises(ValueError):
                m.validate_freeze_schema(freeze, 'recovery')

    def test_each_real_external_map_is_actually_verified(self):
        for directory, expected, field in [(m.PREDECESSOR, m.PREDECESSOR_FREEZE, 'external_inputs'),
                                           (m.RECOVERY, m.RECOVERY_FREEZE, 'external_files'),
                                           (m.ORIGINAL, m.CONTROLS_FREEZE, 'external_files')]:
            target = Path(next(iter(read(directory / 'source-freeze.json')[field])))
            original_record = m.record
            def changed_record(path):
                result = original_record(path)
                return {**result, 'sha256': '0' * 64} if Path(path).absolute() == target else result
            try:
                m.record = changed_record
                with self.subTest(directory=directory.name), self.assertRaises(ValueError):
                    m.verify_freeze(m.Inputs(), directory, expected)
            finally:
                m.record = original_record

    def test_v1_preserved_byte_for_byte(self):
        inventory = read(HERE / 'predecessor-inventory.json')
        self.assertEqual(inventory['directory'], str(m.PREDECESSOR))
        self.assertEqual(len(inventory['files']), 9)
        for name, row in inventory['files'].items():
            self.assertEqual(m.record(m.PREDECESSOR / name), row)


if __name__ == '__main__':
    unittest.main(verbosity=2)
