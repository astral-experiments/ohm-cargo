#!/usr/bin/env python3
"""Run only synthetic and retained small metadata tests; no collection or effects."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('admission_lineage_tests', HERE / 'test_review_recovery.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
sys.addaudithook(module.m.no_execution)
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
stdout = b''
stderr = stream.getvalue().encode()
report = {'passed': result.wasSuccessful(), 'tests': result.testsRun, 'failures': len(result.failures),
          'errors': len(result.errors), 'checked_at': datetime.now(timezone.utc).isoformat(),
          'host_operations': False, 'native_collection_or_real_review_executed': False,
          'native_effects_inspected_or_computed': False,
          'freeze_schema_corpus': module.SCHEMA_COVERAGE,
          'source_sha256': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                            for name in ('review_recovery.py', 'test_review_recovery.py', 'run_pure_checks.py')}}
for name, data in [('pure-checks.stdout', stdout), ('pure-checks.stderr', stderr),
                   ('pure-checks.json', (json.dumps(report, indent=2, sort_keys=True) + '\n').encode())]:
    with (HERE / name).open('xb') as output:
        output.write(data)
print(json.dumps(report, sort_keys=True))
raise SystemExit(0 if result.wasSuccessful() else 1)
