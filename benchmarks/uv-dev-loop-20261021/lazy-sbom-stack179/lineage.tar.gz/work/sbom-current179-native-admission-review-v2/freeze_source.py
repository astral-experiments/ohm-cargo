#!/usr/bin/env python3
"""Seal this source-only procedure and its already-retained metadata references."""
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('lineage_freeze_helpers', HERE / 'review_recovery.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
sys.addaudithook(m.no_execution)
tests = json.loads((HERE / 'pure-checks.json').read_bytes())
m.need(tests['passed'] is True and tests['tests'] == 22 and tests['failures'] == tests['errors'] == 0,
       'pure checks have not passed')
for name, expected in tests['source_sha256'].items():
    m.need(m.record(HERE / name)['sha256'] == expected, 'checked source changed')
sources = ('README.md', 'review_recovery.py', 'test_review_recovery.py', 'run_pure_checks.py',
           'freeze_source.py', 'pure-checks.json', 'pure-checks.stdout', 'pure-checks.stderr',
           'predecessor-inventory.json', 'source-delta.diff')
external = [m.RECOVERY / 'source-freeze.json', m.ORIGINAL / 'source-freeze.json', m.REVIEWER / 'source-freeze.json',
            m.CONTROLS / 'collect.py', m.REVIEWER / 'review.py', m.REVIEWER / 'evidence.py',
            m.RECOVERY / 'root-source-review.json', m.RECOVERY / 'root-retention-review.json',
            m.RECOVERY / 'root-replay-copy-approval.json', m.RECOVERY / 'replay-copy-inputs.json',
            m.RECOVERY / 'replay-copy-receipt.json', m.RECOVERY / 'retention-attempt01/remote-receipt.json',
            m.RECOVERY / 'launch-quiet.stdout', m.RECOVERY / 'launch-quiet.stderr',
            m.PREDECESSOR / 'source-freeze.json',
            m.CONTROLS / 'independent-ir-review-profiler-alias-v2/review.json']
for path, expected in [(m.RECOVERY / 'source-freeze.json', m.RECOVERY_FREEZE),
                       (m.ORIGINAL / 'source-freeze.json', m.CONTROLS_FREEZE),
                       (m.REVIEWER / 'source-freeze.json', m.REVIEWER_FREEZE)]:
    m.need(m.record(path)['sha256'] == expected, 'original frozen reference changed')
inventory = json.loads((HERE / 'predecessor-inventory.json').read_bytes())
for name, row in inventory['files'].items():
    m.need(m.record(m.PREDECESSOR / name) == row, 'v1 predecessor changed')
m.need(m.record(m.CONTROLS / 'independent-ir-review-profiler-alias-v2/review.json')['sha256'] == m.IR_REVIEW,
       'actual accepted IR review differs')
report = {'status': 'source-only-awaiting-independent-review', 'created_at': datetime.now(timezone.utc).isoformat(),
          'scope': 'Terminal collection procedure and local recovery-lineage joins; original collector/raw/statistical reviewer unchanged.',
          'files': {name: m.record(HERE / name) for name in sources},
          'external_inputs': {str(path): m.record(path) for path in external},
          'tests': 22, 'host_operations': False, 'native_collection_or_real_review_executed': False,
          'native_effects_inspected_or_computed': False,
          'original_reviewer_source_freeze_sha256': m.REVIEWER_FREEZE,
          'recovery_source_freeze_sha256': m.RECOVERY_FREEZE,
          'original_launch_controls_source_freeze_sha256': m.CONTROLS_FREEZE}
m.validate_freeze_schema(report, 'lineage')
with (HERE / 'source-freeze.json').open('xb') as stream:
    stream.write(m.encoded(report))
print(json.dumps({'source_freeze_sha256': m.record(HERE / 'source-freeze.json')['sha256'],
                  'source_files': len(sources), 'external_inputs': len(external), 'tests': 22}, sort_keys=True))
