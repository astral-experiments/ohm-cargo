#!/usr/bin/env python3
"""Local metadata-only admission lineage check, before the unchanged raw reviewer."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import stat
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
RECOVERY = WORK / 'sbom-current179-native-admission-recovery'
ORIGINAL = WORK / 'sbom-current179-native-launch-controls-alias-v2'
REPLAY = WORK / 'sbom-current179-native-launch-replay02'
REVIEWER = WORK / 'sbom-current179-ir-reviewer-profiler-alias-v2'
CONTROLS = WORK / 'sbom-current179-ir-continuation'
PREDECESSOR = WORK / 'sbom-current179-native-admission-review'
PREDECESSOR_FREEZE = '25400c7827490904e3ede8be0916dd6a32d0260c4397b1858f923ab0dda9aa95'
REMOTE = '/tmp/ohm-hillclimb-20261021/lazy-sbom-current179'
RETENTION = 'continuations/native-admission-history/attempt-01'
HISTORY = 'continuations/native-prerequisite-launch-01'
BINDING = 'continuations/native-prerequisite-01'
RECOVERY_FREEZE = 'fed0cb323383c6188aa1693289dbe0d18fd5dd05ecfa28d1224387b8ec0fbe49'
CONTROLS_FREEZE = 'af6c551f3ddd21562dd7859d67ec885d24507a256fabecccd653459df78ebf67'
REVIEWER_FREEZE = '97cdbcc36928777579b1b3c6e5b8adf7bdae37d97a2b0f2200a57cdd0ec4f067'
PREREQUISITE = 'b24ace5a04c82adde807489b4d28a8a1a4e708430f9d73f9ad0e81d17c470b48'
CAPTURE = '069cf4e62ef50e28414f644794c3e2f16f0b37cfd968b6e72d421210226f0127'
FAILED_STATUS = '653300896d3f674590a25368590afd96cb7d8350d9cb4daaee2a020a9cf468e2'
CONTROLLER = 'd1f05e3909e83fccb93c4d1c8b6445921333a68cddc275f888198121dc5177fb'
IR_REVIEW = '242bc12bdd883f25a56baf59f5e6a16666e8f8f8b7d5819dbcaa21ad8e907d17'
LOCAL_LAUNCH_NAMES = {'before.json', 'request.json', 'receipt.json', 'seal.json', 'stdout', 'stderr'}
REMOTE_LAUNCH_NAMES = {'before.json', 'request.json', 'root-approval.json', 'remote.py',
                       'receipt.json', 'seal.json', 'entry-receipt.json'}
FREEZE_SCHEMAS = {
    'lineage': {
        'strings': 'created_at original_launch_controls_source_freeze_sha256 original_reviewer_source_freeze_sha256 recovery_source_freeze_sha256 scope status'.split(),
        'booleans': 'host_operations native_collection_or_real_review_executed native_effects_inspected_or_computed'.split(),
        'integers': ['tests'], 'external': ['external_inputs'], 'row_fields': {'sha256', 'bytes', 'mode'}, 'counts': None,
    },
    'recovery': {
        'strings': 'created_at original_controls_source_freeze_sha256 original_native_controller_sha256 scope status'.split(),
        'booleans': 'effects_recomputed host_operations metadata_recovery_executed real_replay_copy_prepared workload_operations'.split(),
        'integers': ['tests'], 'external': ['external_files'], 'row_fields': {'sha256', 'bytes', 'mode'}, 'counts': (12, 139),
    },
    'launch': {
        'strings': 'accepted_raw_reviewer_sha256 created_at original_capsule_manifest_sha256 previous_controls_source_freeze_sha256 scope source_audit_sha256 strict_wrapper_sha256'.split(),
        'booleans': 'effects_inspected host_actions_performed real_preparation_performed'.split(),
        'integers': ['original_frozen_inputs', 'pure_tests'], 'external': ['external_files'],
        'row_fields': {'sha256', 'bytes', 'mode'}, 'counts': (40, 352),
    },
    'raw_reviewer': {
        'strings': 'created_at scope supersedes_unmodified_reviewer'.split(),
        'booleans': 'comparative_effects_inspected host_actions_performed measurement_or_compiler_execution_performed'.split(),
        'integers': ['pure_tests_passed'], 'external': [], 'row_fields': {'sha256', 'bytes'}, 'counts': (75, 0),
    },
}


def need(value, message):
    if not value:
        raise ValueError(message)


def no_execution(event, args):
    need(not (event.startswith(('subprocess.', 'socket.', 'os.exec', 'os.spawn', 'os.posix_spawn'))
              or event in ('os.system', 'pty.spawn')), 'lineage checker cannot execute or contact a host')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def relative(name):
    need(isinstance(name, str), 'non-string relative input')
    path = PurePosixPath(name)
    need(name and str(path) == name and not path.is_absolute()
         and '..' not in path.parts and '\\' not in name and name != '.', 'unsafe relative input')
    return path


def record(path):
    path = Path(path).absolute()
    info = path.lstat()
    need(path.resolve() == path and stat.S_ISREG(info.st_mode), 'input is not a canonical ordinary file')
    with path.open('rb') as stream:
        return {'sha256': hashlib.file_digest(stream, 'sha256').hexdigest(),
                'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}


class Inputs:
    def __init__(self):
        self.files = {}
        self.trees = {}

    def path(self, path):
        path = Path(path).absolute()
        need(path.is_relative_to(WORK), 'local input outside this task work directory')
        actual = record(path)
        need(str(path) not in self.files or self.files[str(path)] == actual, 'input changed during review')
        self.files[str(path)] = actual
        return path

    def read(self, path):
        return json.loads(self.path(path).read_bytes())

    def sha(self, path):
        return self.files[str(self.path(path))]['sha256']

    def tree(self, root):
        root = Path(root).absolute()
        names = set()
        for path in root.rglob('*'):
            need(not path.is_symlink() and (path.is_file() or path.is_dir()), 'unexpected local tree member')
            if path.is_file():
                self.path(path)
                names.add(str(path.relative_to(root)))
        self.trees[str(root)] = names

    def verify(self):
        for name, expected in self.files.items():
            need(record(name) == expected, 'local input changed: ' + name)
        for root, expected in self.trees.items():
            observed = {str(p.relative_to(root)) for p in Path(root).rglob('*') if p.is_file()}
            need(observed == expected and all(not p.is_symlink() for p in Path(root).rglob('*')),
                 'local lineage tree changed during review')


def is_sha256(value):
    return isinstance(value, str) and len(value) == 64 and all(character in '0123456789abcdef' for character in value)


def validate_freeze_schema(freeze, role):
    need(role in FREEZE_SCHEMAS, 'unrecognized freeze role')
    schema = FREEZE_SCHEMAS[role]
    maps = ['files', *schema['external']]
    expected = set(maps) | set(schema['strings']) | set(schema['booleans']) | set(schema['integers'])
    need(type(freeze) is dict and set(freeze) == expected, 'missing or unexpected freeze schema fields: ' + role)
    for group, kind in [('strings', str), ('booleans', bool), ('integers', int)]:
        for name in schema[group]:
            need(type(freeze[name]) is kind, 'unexpected freeze metadata type: ' + name)
            if name.endswith('_sha256') or name == 'supersedes_unmodified_reviewer':
                need(is_sha256(freeze[name]), 'malformed frozen SHA256: ' + name)
    for name in maps:
        rows = freeze[name]
        need(type(rows) is dict and rows, 'required freeze file map is absent or empty: ' + name)
        for path, row in rows.items():
            if name == 'files':
                relative(path)
            else:
                need(isinstance(path, str) and Path(path).is_absolute() and str(Path(path)) == path,
                     'external freeze path is not absolute/canonical')
            need(type(row) is dict and set(row) == schema['row_fields'], 'unexpected freeze file-record schema')
            need(is_sha256(row['sha256']) and type(row['bytes']) is int and row['bytes'] >= 0,
                 'malformed frozen file identity')
            if 'mode' in row:
                need(type(row['mode']) is int and 0 <= row['mode'] <= 0o7777, 'malformed frozen file mode')
    counts = (len(freeze['files']), sum(len(freeze[name]) for name in schema['external']))
    need(schema['counts'] is None or counts == schema['counts'], 'frozen file-map counts differ')
    return schema, counts


def verify_freeze(inputs, directory, expected):
    roles = {HERE: 'lineage', PREDECESSOR: 'lineage', RECOVERY: 'recovery', ORIGINAL: 'launch', REVIEWER: 'raw_reviewer'}
    need(directory in roles and is_sha256(expected), 'unknown freeze directory or malformed expected SHA256')
    path = directory / 'source-freeze.json'
    need(inputs.sha(path) == expected, 'source freeze differs: ' + str(directory))
    freeze = inputs.read(path)
    schema, _ = validate_freeze_schema(freeze, roles[directory])
    for name, row in freeze['files'].items():
        actual = record(inputs.path(directory / relative(name)))
        need(all(actual[key] == value for key, value in row.items()), 'frozen source changed: ' + name)
    for field in schema['external']:
        for name, row in freeze[field].items():
            actual = record(inputs.path(name))
            need(all(actual[key] == value for key, value in row.items()), 'frozen external input changed: ' + name)
    return freeze


def load_source(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_retention_map(capture, receipt, plan):
    need(len(capture['files']) == 11 and receipt['retained_files'] == plan
         and set(plan) == set(capture['files']), 'failure retention lost or added a file')
    for name, row in capture['files'].items():
        relative(name)
        expected = {'origin': REMOTE + '/' + name,
                    'retained': REMOTE + '/' + RETENTION + '/retained/' + name, **row}
        need(plan[name] == expected, 'retention origin/hash/mode mapping differs')
    need(receipt['valid'] is True and receipt['operation'] == 'retain-zero-work-native-admission-01'
         and receipt['capture_sha256'] == CAPTURE and receipt['failed_status_sha256'] == FAILED_STATUS
         and receipt['source_freeze_sha256'] == RECOVERY_FREEZE
         and receipt['prerequisite_manifest_sha256'] == PREREQUISITE
         and receipt['controls_source_freeze_sha256'] == CONTROLS_FREEZE
         and receipt['retention_root'] == REMOTE + '/' + RETENTION
         and receipt['all_accepted_ir_bytes_and_native_fixtures_unchanged'] is True
         and receipt['all_original_metadata_preserved'] is True
         and receipt['native_workload_or_analysis_executed'] is False
         and receipt['replay_authorized_by_this_receipt'] is False, 'retention scope differs')


def check_copy(receipt, index, recovery_sha):
    need(len(index['protected_original_files']) == 119 and len(index['copied_files']) == 101,
         'copy input set differs')
    need(receipt['valid'] is True and receipt['operation'] == 'prepare-byte-identical-native-replay02'
         and receipt['source_freeze_sha256'] == RECOVERY_FREEZE
         and receipt['recovery_receipt_sha256'] == recovery_sha
         and receipt['original_directory'] == str(ORIGINAL) and receipt['replay_directory'] == str(REPLAY)
         and receipt['copied_files'] == index['copied_files']
         and receipt['all_original_local_paths_unchanged'] is True
         and receipt['unchanged_original_source_and_prepared_guards_passed'] is True
         and receipt['launch_attempt_absent'] is True and receipt['host_or_workload_operations'] is False,
         'copy receipt does not bind the unchanged controls and retained failure')


def terminal_metadata(state, manifests, phases, configuration_hashes):
    need(state['state'] == 'complete' and state['group'] == 'native-confirmation'
         and state['completed_workloads'] == ['test', 'check'] and state['source_restored'] is True,
         'both original native workflows must be complete before lineage review')
    for workload, seed in (('test', 20261021103), ('check', 20261021104)):
        phase = next(row for row in phases if row['workload'] == workload and row['metric'] == 'native_wall_seconds')
        manifest = manifests[workload]
        need((phase['pairs'], phase['warmup_pairs'], phase['invocations_per_variant_per_pair'], phase['seed'])
             == (30, 2, 1, seed), 'original native phase differs')
        need(manifest['state'] == 'complete' and manifest['phase'] == 'confirmation'
             and manifest['pairs'] == 30 and manifest['warmup_pairs'] == 2 and manifest['seed'] == seed
             and manifest['sample_count'] == 64
             and manifest['plans'] == {'warmup': phase['warmup_plan'], 'measurement': phase['measurement_plan']}
             and manifest['configuration_sha256'] == configuration_hashes[workload + '-native-confirmation'],
             'native workflow is incomplete or uses another fixed plan')


def retention(collection, inputs, recovery):
    prefix = RETENTION + '/'
    seal = collection.json(prefix + 'seal.json')
    observed = {name[len(prefix):]: row for name, row in collection.files.items()
                if name.startswith(prefix) and name != prefix + 'seal.json'}
    need(seal == observed and len(seal) == 19, 'retention seal/member set differs')
    capture = collection.json(prefix + 'capture.json')
    receipt = collection.json(prefix + 'receipt.json')
    plan = collection.json(prefix + 'move-plan.json')
    need(collection.files[prefix + 'capture.json']['sha256'] == CAPTURE
         and collection.files[prefix + 'source-freeze.json']['sha256'] == RECOVERY_FREEZE,
         'retained failure/source identity differs')
    check_retention_map(capture, receipt, plan)
    need(receipt['rename_units'] == list(recovery.MOVES), 'metadata rename units differ')
    recovery.retained_files(collection.path(prefix + 'retained/results/native-confirmation.json').parents[1], capture)
    recovery.validate_failed(collection.json(prefix + 'retained/results/native-confirmation.json'), capture)
    need(recovery.guard_clear(collection.path(prefix + 'occupancy-before.txt').read_text()),
         'retention bypassed the original occupancy predicate')
    request = collection.json(prefix + 'request.json')
    approval = collection.json(prefix + 'root-approval.json')
    for field, name in [('approval_base64', 'root-approval.json'), ('capture_base64', 'capture.json'),
                        ('source_base64', 'recover_remote.py'), ('source_freeze_base64', 'source-freeze.json')]:
        need(base64.b64decode(request[field], validate=True) == collection.path(prefix + name).read_bytes(),
             'retention request payload differs')
    need(receipt['request_sha256'] == collection.files[prefix + 'request.json']['sha256']
         and receipt['approval_sha256'] == request['approval_sha256'] == collection.files[prefix + 'root-approval.json']['sha256']
         and receipt['recovery_source_sha256'] == inputs.sha(RECOVERY / 'recover_remote.py')
         == collection.files[prefix + 'recover_remote.py']['sha256']
         and request['source_freeze_sha256'] == RECOVERY_FREEZE
         and approval['valid'] is True and approval['authorized_operation'] == receipt['operation']
         and approval['source_freeze_sha256'] == RECOVERY_FREEZE, 'retention request/approval/source joins differ')
    for local, remote_name in [('retention-attempt01/request.json', 'request.json'),
                               ('root-retention-approval.json', 'root-approval.json'),
                               ('retention-attempt01/remote-receipt.json', 'receipt.json')]:
        need(inputs.sha(RECOVERY / local) == collection.files[prefix + remote_name]['sha256'],
             'local and collected retention bytes differ')
    wrapper = inputs.read(RECOVERY / 'retention-attempt01/stdout')
    execution = inputs.read(RECOVERY / 'retention-attempt01/execution.json')
    need(wrapper['receipt'] == receipt and wrapper['receipt_sha256'] == collection.files[prefix + 'receipt.json']['sha256']
         and wrapper['seal_sha256'] == collection.files[prefix + 'seal.json']['sha256']
         and execution['returncode'] == 0 and execution['request_sha256'] == receipt['request_sha256']
         and execution['approval_sha256'] == receipt['approval_sha256']
         and execution['source_freeze_sha256'] == RECOVERY_FREEZE
         and all(execution[suffix + '_sha256'] == inputs.sha(RECOVERY / 'retention-attempt01' / suffix)
                 for suffix in ('stdout', 'stderr')), 'retention transport receipt differs')
    root_review = inputs.read(RECOVERY / 'root-retention-review.json')
    expected = {name[len(prefix):]: row for name, row in collection.files.items() if name.startswith(prefix)}
    need(root_review['status'] == 'passed' and root_review['all_11_original_files_exact'] is True
         and root_review['all_20_retention_files_collected_and_verified'] is True
         and root_review['files'] == expected and root_review['retention_receipt_sha256'] == wrapper['receipt_sha256']
         and root_review['retention_seal_sha256'] == wrapper['seal_sha256'], 'independent retention acceptance differs')
    for name, row in expected.items():
        need(record(inputs.path(RECOVERY / 'retention-attempt01/collected' / relative(name))) == row,
             'earlier retained capture differs from final collection')
    return collection.files[prefix + 'receipt.json']['sha256']


def copy_and_launch(collection, inputs, validator, recovery_sha, execution_approval):
    index = inputs.read(RECOVERY / 'replay-copy-inputs.json')
    copied = inputs.read(RECOVERY / 'replay-copy-receipt.json')
    copy_sha = inputs.sha(RECOVERY / 'replay-copy-receipt.json')
    check_copy(copied, index, recovery_sha)
    copy_approval = inputs.read(RECOVERY / 'root-replay-copy-approval.json')
    copy_execution = inputs.read(RECOVERY / 'replay-copy-execution.json')
    copy_stdout = inputs.read(RECOVERY / 'replay-copy.stdout')
    need(copied['approval_sha256'] == inputs.sha(RECOVERY / 'root-replay-copy-approval.json')
         and copy_approval['valid'] is True and copy_approval['authorized_operation'] == copied['operation']
         and copy_approval['source_freeze_sha256'] == RECOVERY_FREEZE
         and copy_approval['recovery_receipt_sha256'] == recovery_sha
         and copy_approval['root_retention_review_sha256'] == inputs.sha(RECOVERY / 'root-retention-review.json')
         and copy_execution['returncode'] == 0 and copy_stdout['valid'] is True
         and copy_stdout['receipt_sha256'] == copy_sha and copy_stdout['files'] == 101
         and all(copy_execution[suffix + '_sha256'] == inputs.sha(RECOVERY / ('replay-copy.' + suffix))
                 for suffix in ('stdout', 'stderr')), 'copy execution/approval/retention acceptance differs')
    for name, row in index['protected_original_files'].items():
        need(record(inputs.path(ORIGINAL / relative(name))) == row, 'original local controls/failure changed')
    for name, row in index['copied_files'].items():
        source, target = inputs.path(ORIGINAL / relative(name)), inputs.path(REPLAY / relative(name))
        need(record(target) == row and (source.stat().st_dev, source.stat().st_ino)
             != (target.stat().st_dev, target.stat().st_ino), 'replay source differs or shares a mutable inode')
    manifest = inputs.read(REPLAY / 'prepared/manifest.json')
    need(inputs.sha(REPLAY / 'prepared/manifest.json') == PREREQUISITE
         == collection.files[BINDING + '/manifest.json']['sha256'], 'native prerequisites changed')
    contents = {}
    for name, row in manifest['files'].items():
        need(collection.files.get(BINDING + '/' + name) == row
             and record(inputs.path(REPLAY / 'prepared' / relative(name))) == row,
             'collected native prerequisite bytes differ')
        contents[name] = collection.path(BINDING + '/' + name).read_bytes()
    need(manifest['files']['review/review.json']['sha256'] == IR_REVIEW
         == inputs.sha(CONTROLS / 'independent-ir-review-profiler-alias-v2/review.json'),
         'actual accepted IR review differs from the explicit binding')
    validator.validate_bindings(manifest, contents)  # Existing pure prerequisite validator; accepted IR only.
    local = REPLAY / 'launch-attempt01'
    need({p.name for p in local.iterdir()} == LOCAL_LAUNCH_NAMES, 'unexpected local launch receipt set')
    seal = inputs.read(local / 'seal.json')
    need(set(seal) == LOCAL_LAUNCH_NAMES - {'seal.json'}
         and all(inputs.sha(local / name) == value for name, value in seal.items()), 'local launch seal differs')
    request, receipt, before = (inputs.read(local / name) for name in ('request.json', 'receipt.json', 'before.json'))
    need(receipt['operation'] == 'launch' and receipt['returncode'] == 0
         and receipt['transport_exception'] is None and receipt['remote_success_validated'] is True,
         'launch transport has an unresolved failure; stop for a separate reviewed resolution')
    for suffix in ('stdout', 'stderr'):
        need(receipt[suffix + '_sha256'] == inputs.sha(local / suffix), 'launch transport stream differs')
    need(inputs.read(local / 'stdout') == receipt['remote'], 'launch stdout/receipt differ')
    prefix = HISTORY + '/'
    observed = {name[len(prefix):] for name in collection.files if name.startswith(prefix)}
    need(observed == REMOTE_LAUNCH_NAMES, 'actual replay history member set differs')
    remote_seal = collection.json(prefix + 'seal.json')
    need(set(remote_seal) == REMOTE_LAUNCH_NAMES - {'seal.json', 'entry-receipt.json'}
         and all(collection.files[prefix + name]['sha256'] == value for name, value in remote_seal.items()),
         'actual replay history seal differs')
    for name in ('request.json',):
        need(inputs.sha(local / name) == collection.files[prefix + name]['sha256'], 'local/remote replay request differs')
    remote_receipt = collection.json(prefix + 'receipt.json')
    launch_approval = collection.json(prefix + 'root-approval.json')
    need(receipt['remote']['receipt'] == remote_receipt
         and receipt['remote']['remote_receipt_sha256'] == collection.files[prefix + 'receipt.json']['sha256']
         and receipt['remote']['history_seal_sha256'] == collection.files[prefix + 'seal.json']['sha256'],
         'launch transport does not bind the collected history')
    request_sha = collection.files[prefix + 'request.json']['sha256']
    approval_sha = collection.files[prefix + 'root-approval.json']['sha256']
    need(request['remote_source_text'].encode() == collection.path(prefix + 'remote.py').read_bytes()
         and collection.files[prefix + 'remote.py']['sha256'] == inputs.sha(ORIGINAL / 'remote.py')
         and base64.b64decode(request['approval_base64'], validate=True) == collection.path(prefix + 'root-approval.json').read_bytes(),
         'actual launch source/approval differs')
    for row in (before, receipt, remote_receipt):
        need(row['request_sha256'] == request_sha and row['approval_sha256'] == approval_sha
             and row['prerequisite_manifest_sha256'] == PREREQUISITE, 'launch request/approval binding differs')
    need(request['operation'] == 'launch' and request['controls_source_freeze_sha256'] == CONTROLS_FREEZE
         and receipt['source_freeze_sha256'] == before['source_freeze_sha256'] == CONTROLS_FREEZE
         and remote_receipt['controls_source_freeze_sha256'] == CONTROLS_FREEZE
         and remote_receipt['payloads'] == manifest['files'] and remote_receipt['launched'] is True
         and remote_receipt['command'] == validator.controller_command(PREREQUISITE)
         and remote_receipt['session'] == validator.SESSION
         and launch_approval['valid'] is True and launch_approval['authorized_operation'] == 'launch-fixed-native-prerequisites'
         and launch_approval['recovery_receipt_sha256'] == recovery_sha
         and launch_approval['recovery_source_freeze_sha256'] == RECOVERY_FREEZE
         and launch_approval['recovery_review_sha256'] == inputs.sha(RECOVERY / 'root-retention-review.json')
         and launch_approval['replay_copy_receipt_sha256'] == copy_sha
         and execution_approval['launch_approval_sha256'] == approval_sha
         and execution_approval['recovery_receipt_sha256'] == recovery_sha
         and execution_approval['replay_copy_receipt_sha256'] == copy_sha, 'new launch lacks exact recovery/copy/root approval')
    stage = inputs.read(REPLAY / 'stage-attempt01/receipt.json')
    need(launch_approval['stage_receipt_sha256'] == inputs.sha(REPLAY / 'stage-attempt01/receipt.json')
         and launch_approval['remote_stage_receipt_sha256'] == stage['remote']['remote_receipt_sha256'],
         'replay launch does not use the original staged prerequisites')
    entry = collection.json(prefix + 'entry-receipt.json')
    remote_before = collection.json(prefix + 'before.json')
    expected_machine = collection.json('results/test-ir-confirmation/manifest.json')['machine']
    keys = ('uname', 'platform', 'cpu_count', 'affinity', 'uid', 'effective_uid', 'root_directory_owner_uid')
    command = ['/usr/bin/python3', '-B', REMOTE + '/' + BINDING + '/strict_native_entry.py',
               '--capsule-manifest-sha256', validator.CAPSULE_SHA, '--prerequisite-sha256', PREREQUISITE]
    need(entry['valid'] is True and entry['prerequisite_manifest_sha256'] == PREREQUISITE
         and entry['actual_inherited_build_environment'] == manifest['retained_inherited_build_environment']
         and entry['machine'] == {key: expected_machine[key] for key in keys}
         and entry['launch_request_sha256'] == request_sha
         and entry['before_sha256'] == collection.files[prefix + 'before.json']['sha256']
         and entry['environment_entry_sha256'] == manifest['files']['controls/environment_entry.py']['sha256']
         and entry['strict_native_entry_sha256'] == validator.WRAPPER_SHA
         and entry['command'] == command and entry['original_controller_not_yet_executed'] is True
         and remote_before['request_sha256'] == request_sha and remote_before['approval_sha256'] == approval_sha
         and remote_before['command'] == validator.controller_command(PREREQUISITE), 'actual native entry proof differs')
    need(datetime.fromisoformat(collection.json(RETENTION + '/receipt.json')['completed_at'])
         <= datetime.fromisoformat(remote_receipt['verified_at'])
         <= datetime.fromisoformat(entry['verified_at']), 'retention/replay/entry chronology differs')
    state = collection.json('results/native-confirmation.json')
    need(datetime.fromisoformat(entry['verified_at']) <= datetime.fromisoformat(state['started_at']),
         'native phase began before the approved replay entry')
    for workload in ('test', 'check'):
        observed = collection.json('results/' + workload + '-native-confirmation/manifest.json')
        need(observed['inherited_build_environment'] == entry['actual_inherited_build_environment']
             and {key: observed['machine'][key] for key in keys} == entry['machine'],
             'actual native workload environment/machine differs from the approved entry')
    return {'recovery_receipt_sha256': recovery_sha, 'replay_copy_receipt_sha256': copy_sha,
            'launch_approval_sha256': approval_sha, 'local_launch_receipt_sha256': inputs.sha(local / 'receipt.json'),
            'remote_launch_receipt_sha256': collection.files[prefix + 'receipt.json']['sha256'],
            'entry_receipt_sha256': collection.files[prefix + 'entry-receipt.json']['sha256']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--approval', required=True)
    parser.add_argument('--approval-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    sys.addaudithook(no_execution)
    inputs = Inputs()
    verify_freeze(inputs, HERE, args.source_freeze_sha256)
    verify_freeze(inputs, PREDECESSOR, PREDECESSOR_FREEZE)
    verify_freeze(inputs, RECOVERY, RECOVERY_FREEZE)
    verify_freeze(inputs, ORIGINAL, CONTROLS_FREEZE)
    verify_freeze(inputs, REVIEWER, REVIEWER_FREEZE)
    output = Path(args.output).absolute()
    need(output.is_relative_to(WORK) and output.parent.resolve() == output.parent
         and not output.exists() and not output.is_symlink(), 'review output must be a new owned directory')
    approval = inputs.read(args.approval)
    need(inputs.sha(args.approval) == args.approval_sha256 and approval['valid'] is True
         and approval['authorized_operation'] == 'review-zero-work-native-recovery-lineage'
         and approval['source_freeze_sha256'] == args.source_freeze_sha256 and approval['output'] == str(output),
         'lineage execution lacks exact root approval')
    need('evidence' not in sys.modules and 'lineage' not in sys.modules, 'review module namespace already occupied')
    sys.path.insert(0, str(REVIEWER))
    evidence = importlib.import_module('evidence')
    need(Path(evidence.__file__) == REVIEWER / 'evidence.py' and evidence.freeze_check() == REVIEWER_FREEZE,
         'original evidence reader source differs')
    collection = evidence.Collection(CONTROLS, 'native-confirmation')
    need(approval['collection_receipt_sha256'] == inputs.sha(collection.receipt_path), 'wrong terminal native collection')
    inputs.path(collection.archive_path)
    inputs.path(collection.root / 'transfer-manifest.json')
    final, phase_state = evidence.collection_inputs(collection)
    protocol = collection.json('work/benchmark/protocol.json')
    manifests = {name: collection.json('results/' + name + '-native-confirmation/manifest.json') for name in ('test', 'check')}
    terminal_metadata(phase_state, manifests, protocol['phases'], final['config_sha256'])
    need(collection.files['continuations/ir-check-01/native-original-controller.py']['sha256'] == CONTROLLER,
         'original native controller changed')
    recovery = load_source('reviewed_admission_retention', RECOVERY / 'recover_remote.py')
    validator = load_source('reviewed_native_bindings', ORIGINAL / 'remote.py')
    recovery_sha = retention(collection, inputs, recovery)
    joins = copy_and_launch(collection, inputs, validator, recovery_sha, approval)
    # Preserve all actual local recovery/copy/launch streams and root reviews,
    # including extras beyond the original 119 and exactly copied 101 controls.
    inputs.tree(RECOVERY)
    inputs.tree(REPLAY)
    collection.verify_files()
    inputs.verify()
    local_index = {'files': inputs.files, 'native_transfer_manifest_sha256': collection.receipt['transfer_manifest_sha256']}
    report = {'valid': True, 'reviewed_at': datetime.now(timezone.utc).isoformat(),
              'source_freeze_sha256': args.source_freeze_sha256, 'approval_sha256': args.approval_sha256,
              'phase': 'native-confirmation', 'collection_receipt_sha256': inputs.sha(collection.receipt_path),
              'transfer_manifest_sha256': collection.receipt['transfer_manifest_sha256'],
              'original_reviewer_source_freeze_sha256': REVIEWER_FREEZE, 'accepted_ir_review_sha256': IR_REVIEW,
              'original_controls_source_freeze_sha256': CONTROLS_FREEZE, 'recovery_source_freeze_sha256': RECOVERY_FREEZE,
              'prerequisite_manifest_sha256': PREREQUISITE, 'original_native_controller_sha256': CONTROLLER,
              'retained_failure_files': 11, 'retention_files': 20, 'original_local_files_preserved': 119,
              'byte_identical_replay_files': 101, 'both_fixed_native_workflows_terminal': True,
              'native_pairs_per_workflow': 30, 'native_warmup_pairs': 2, 'invocations_per_variant_per_pair': 1,
              'native_effects_inspected_or_computed': False, 'original_both_workflow_raw_and_statistical_review_required': True,
              'local_inputs_sha256': digest(encoded(local_index)), 'final_rehash': 'passed', **joins}
    output.mkdir()
    for name, value in [('local-inputs.json', local_index), ('review.json', report)]:
        with (output / name).open('xb') as stream:
            stream.write(encoded(value))
    with (output / 'seal.json').open('xb') as stream:
        stream.write(encoded({name: record(output / name) for name in ('local-inputs.json', 'review.json')}))
    print(json.dumps({'valid': True, 'review_sha256': record(output / 'review.json')['sha256'],
                      'native_effects_inspected_or_computed': False, 'original_raw_review_still_required': True}, sort_keys=True))


if __name__ == '__main__':
    main()
