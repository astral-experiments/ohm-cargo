
fn main() {
    let output = std::path::PathBuf::from(std::env::var_os("CARGO_SSL_ENV_CAPTURE").unwrap());
    std::fs::create_dir_all(&output).unwrap();
    for key in ["SSL_CERT_FILE", "SSL_CERT_DIR"] {
        match std::env::var_os(key) {
            Some(value) => std::fs::write(output.join(key), value.as_encoded_bytes()).unwrap(),
            None => std::fs::write(output.join(format!("{key}.unset")), b"").unwrap(),
        }
    }
    println!("cargo::rerun-if-env-changed=CARGO_SSL_ENV_CAPTURE");
}
