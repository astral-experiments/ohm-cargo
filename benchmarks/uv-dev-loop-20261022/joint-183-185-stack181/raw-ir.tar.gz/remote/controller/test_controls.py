#!/usr/bin/env python3
"""Pure/source and temporary-fixture checks; subprocess/network execution is blocked."""
import argparse
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import common as c
import bind_inputs
import capture
import driver
import fixture
import prepare_host
import production
import remote
import transport
sys.path.insert(0, str(HERE / 'reviewer'))
import review

REFERENCE = HERE.parent / 'parser-allocations-measurement-controls-host4-v1'


def nodes(path):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef)}


def blocked(*args, **kwargs):
    raise AssertionError('external execution is forbidden by the synthetic test guard')


def production_fixture():
    hashes = {name: hashlib.sha256(name.encode()).hexdigest() for name in production.ROLES}
    hashes.update(manifest=c.PRODUCTION_MANIFEST_SHA, controls_freeze=c.PRODUCTION_CONTROLS_SHA)
    variants = {'baseline': 'a' * 64, 'candidate': 'b' * 64}
    names = {c.VARIANTS[k]: v for k, v in variants.items()}
    trees = {c.VARIANTS[k]: v for k, v in c.TREES.items()}
    common = 'c' * 64
    settings = {target: {'codegen': ['opt-level=3', 'codegen-units=1', 'debuginfo=1', lto],
                         'cfg': ['feature="all-static"', 'feature="ohm-defaults"'], 'direct_dependency_names': ['anyhow']}
                for target, lto in [('src/lib.rs', 'linker-plugin-lto'), ('src/bin/cargo/main.rs', 'lto=thin')]}
    records = [{'variant': name, 'source_tree': trees[name], 'stripped_sha256': names[name],
                'original_linker_output_sha256': 'd' * 64, 'verified_allocated_sections': 31,
                'actual_rustc_settings': copy.deepcopy(settings), 'version': 'cargo pinned 5e5', 'dynamic_libraries': []}
               for name in c.VARIANTS.values()]
    d = {name: None for name in production.ROLES}
    d['audit'] = {'state': 'passed', 'binaries': names, 'records': records,
                  'bindings': {'controls_sha256': hashes['controls_freeze']}, 'common_build_inputs_sha256': common,
                  **{field: hashes[role] for field, role in [('production_manifest_sha256', 'manifest'),
                      ('production_driver_sha256', 'driver'), ('provenance_sha256', 'provenance'),
                      ('build_result_sha256', 'build_result'), ('terminal_status_sha256', 'terminal_status')]}}
    d['root_review'] = {'status': 'passed', 'scope': 'joint-stack181-local-production-pair',
                        'binaries': names, 'source_trees': trees, 'checks': {'accepted': True},
                        'audit_sha256': hashes['audit'], 'controls_source_freeze_sha256': hashes['controls_freeze'],
                        'production_manifest_sha256': hashes['manifest'], 'common_build_inputs_sha256': common}
    d['provenance'] = {'host': 'charlie-oss', 'cohort': 'local-joint-stack181', 'source_tree': 'initial-pinned-f359',
                       'source': str(c.PRODUCTION_ROOT / 'source'), 'target': str(c.PRODUCTION_ROOT / 'target'),
                       'expected_variant_source_trees': trees, 'common_build_inputs_sha256': common}
    d['build_result'] = {'state': 'complete', 'returncode': 0, 'producer_started': True,
                         'terminal_status_sha256': hashes['terminal_status']}
    d['terminal_status'] = {'state': 'complete', 'completed_variants': list(c.VARIANTS.values())}
    d['binary_manifest'], d['manifest'] = {}, {'expected_variants': {}}
    for key, name in c.VARIANTS.items():
        d['manifest']['expected_variants'][name] = {'tree': c.TREES[key], 'canonical_diff_sha256': hashes[key + '_patch']}
        d['binary_manifest']['cargo-' + name] = {'variant': name, 'path': str(c.PRODUCTION_ROOT / 'binaries' / ('cargo-' + name)),
            'observed_source_tree': c.TREES[key], 'expected_source_tree_from_patches': c.TREES[key],
            'original_linker_output_sha256': 'd' * 64, 'common_build_inputs_sha256': common,
            'observed_diff_sha256': hashes[key + '_patch']}
        d[key + '_strip'] = {'stripped_sha256': variants[key], 'source_sha256': 'd' * 64,
                             'original_linker_output_sha256': 'd' * 64, 'allocated_sections': list(range(31))}
    return d, hashes, variants


def metric():
    return {'pairs': 12, 'paired_geometric_mean_count_reduction': .02,
            'bootstrap_count_reduction_interval': [.015, .025], 'exact_two_sided_sign_p': .00048828125,
            'order': {'AB': {'geometric_mean_ratio': 1.02}, 'BA': {'geometric_mean_ratio': 1.02}}}


class Checks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='joint-controls-pure-')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_unchanged_protocol_runner_guard_statistics(self):
        for path, expected in [(HERE / 'protocol.json', c.PROTOCOL_SHA), (HERE / 'frozen/paired.py', c.PAIRED_SHA),
                               (HERE / 'occupancy.py', c.OCCUPANCY_SHA),
                               (HERE / 'reviewer/statistics_review.py', 'b62c8e99643f6b3615d0306b96426ece2cf1aa2039b1c77104db5b21a6903688')]:
            with self.subTest(path=str(path)):
                self.assertEqual(c.sha(path), expected)

    def test_unchanged_fixture_and_raw_function_asts(self):
        groups = [(HERE / 'fixture.py', REFERENCE / 'collections/ir/remote/controller/reference-native-controller.py',
                   ['uv_identity', 'allocator_guard', 'configuration_presence', 'fresh', 'preflight']),
                  (HERE / 'driver.py', REFERENCE / 'driver.py', ['phase_status', 'audit_sample_tables', 'audit_ir']),
                  (HERE / 'reviewer/review.py', REFERENCE / 'reviewer/review.py',
                   ['timestamp', 'machine', 'plan', 'substitute', 'fresh', 'success', 'tables', 'profile_count', 'preflight', 'immutable_inputs', 'raw_workflow', 'analyze']),
                  (HERE / 'prepare_host.py', REFERENCE / 'cohort_binding.py', ['runtime_aliases'])]
        for current, original, names in groups:
            a, b = nodes(current), nodes(original)
            for name in names:
                with self.subTest(name=name, file=str(current)):
                    self.assertEqual(a[name], b[name])

    def test_actual_ci_record_and_negative_jobs(self):
        original = c.read(HERE.parent / 'combined-warm-loop-source-ci/combined-ci-complete.json')
        self.assertEqual(c.sha(HERE.parent / 'combined-warm-loop-source-ci/combined-ci-complete.json'), c.CI_SHA)
        production.validate_ci(original)
        for label, mutate in [
            ('head', lambda v: v.update(head_sha='0' * 40)),
            ('tree', lambda v: v.update(head_tree='0' * 40)),
            ('pending', lambda v: v.update(run_status='in_progress')),
            ('failed_job', lambda v: v['required_jobs'][0].update(conclusion='failure')),
            ('missing_job', lambda v: v['required_jobs'].pop()),
            ('raw_job', lambda v: v['raw_jobs']['jobs'][0].update(conclusion='failure')),
            ('unexpected_raw_schema', lambda v: v['raw_jobs'].update(total_count=9))]:
            value = copy.deepcopy(original); mutate(value)
            with self.subTest(label=label), self.assertRaises((AssertionError, KeyError)):
                production.validate_ci(value)

    def test_actual_producer_contract_and_negative_joins(self):
        d, h, v = production_fixture()
        production.validate_documents(d, h, v)
        contract = c.read(HERE.parent / 'production-build/local-joint-stack181/controls/pair-review-contract.json')
        self.assertEqual(set(contract['required']['binaries']), set(c.VARIANTS.values()))
        self.assertEqual(contract['required']['source_trees'], {c.VARIANTS[k]: t for k, t in c.TREES.items()})
        cases = [
            ('audit_failed', lambda x: x['audit'].update(state='failed')),
            ('legacy_wrong_key', lambda x: x['root_review'].update(variants=x['root_review'].pop('binaries'))),
            ('empty_root_checks', lambda x: x['root_review'].update(checks={})),
            ('false_root_check', lambda x: x['root_review'].update(checks={'bad': False})),
            ('wrong_tree', lambda x: x['audit']['records'][1].update(source_tree='0' * 40)),
            ('wrong_section_count', lambda x: x['audit']['records'][0].update(verified_allocated_sections=30)),
            ('wrong_strip', lambda x: x['candidate_strip'].update(stripped_sha256='f' * 64)),
            ('incomplete_build', lambda x: x['build_result'].update(state='running')),
            ('wrong_build_order', lambda x: x['terminal_status']['completed_variants'].reverse()),
            ('root_audit_join', lambda x: x['root_review'].update(audit_sha256='0' * 64)),
            ('build_status_join', lambda x: x['build_result'].update(terminal_status_sha256='0' * 64)),
            ('actual_flags', lambda x: x['audit']['records'][0]['actual_rustc_settings']['src/lib.rs']['codegen'].append('profile-use=x')),
            ('wrong_patch', lambda x: x['binary_manifest']['cargo-' + c.VARIANTS['candidate']].update(observed_diff_sha256='0' * 64)),
            ('different_target', lambda x: x['provenance'].update(target='/tmp/other'))]
        for label, mutate in cases:
            changed = copy.deepcopy(d); mutate(changed)
            with self.subTest(label=label), self.assertRaises((AssertionError, KeyError)):
                production.validate_documents(changed, h, v)

    def test_unbound_input_fails_before_files_or_execution(self):
        with self.assertRaisesRegex(AssertionError, 'UNBOUND'):
            bind_inputs.validate_input({'schema': 1, 'state': 'unbound'})

    def test_actual_seal_writes_both_configs_before_any_warming(self):
        # Replay the setup directory declaration, then the actual sealing entrypoint.
        tree = ast.parse((HERE / 'prepare_host.py').read_text())
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'prepare')
        directories = next(ast.literal_eval(n.iter) for n in function.body
                           if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'directory')
        for directory in directories: (self.root / directory).mkdir(parents=True, exist_ok=False)
        controller = self.root / 'controller'
        assets_path, seal = controller / 'assets.json', controller / 'measurement-seal.json'
        for name in ('source-freeze.json', 'input-binding.json'): (controller / name).write_text('{}')
        assets = {'variants': {'baseline': 'a' * 64, 'candidate': 'b' * 64}, 'file_sha256': {}, 'uv': {}, 'configuration_presence': {}}
        assets_path.write_text(json.dumps(assets))
        for workflow, _ in c.PLAN:
            template = (HERE / 'templates' / ('ir-' + workflow + '.json')).read_text().replace(str(c.ROOT), str(self.root))
            (controller / 'base-configs' / ('ir-' + workflow + '.json')).write_text(template)
        with patch.object(c, 'ROOT', self.root), patch.object(c, 'HERE', controller), patch.object(driver, 'ROOT', self.root),\
             patch.object(driver, 'ASSETS', assets_path), patch.object(driver, 'SEAL', seal),\
             patch.object(driver, 'verify_assets', return_value=assets), patch.object(driver, 'quiet'),\
             patch.object(c, 'runtime_identity', return_value={}), patch.object(fixture, 'uv_identity', return_value={}),\
             patch.object(fixture, 'configuration_presence', return_value={}), patch.object(fixture, 'allocator_guard'),\
             patch.dict(os.environ, {}, clear=True):
            driver.prepare()
            sealed = c.read(seal)
            self.assertEqual(len(sealed['configs']), 2)
            self.assertEqual(sealed['state'], 'sealed-before-warming')
            for workflow, _ in c.PLAN:
                config = c.read(c.paths('ir', workflow)['config'])
                self.assertEqual(set(sealed['configs']), {str(c.paths('ir', w)['config']) for w, _ in c.PLAN})
                self.assertFalse(Path(config['env']['CARGO_TARGET_DIR']).exists())
                self.assertFalse(Path(config['env']['CARGO_BUILD_BUILD_DIR']).exists())
                self.assertFalse(c.paths('ir', workflow)['preflight'].exists())
                self.assertFalse(c.paths('ir', workflow)['output'].exists())

    def test_templates_only_change_paths_variants_and_evidence(self):
        for workflow, _ in c.PLAN:
            original = c.read(REFERENCE / 'collections/ir/remote/benchmark' / ('ir-' + workflow + '.json'))
            old = original['cwd'].removesuffix('/uv')
            def rewrite(value):
                if isinstance(value, str): return value.replace(old, str(c.ROOT))
                if isinstance(value, list): return [rewrite(x) for x in value]
                if isinstance(value, dict): return {k: rewrite(v) for k, v in value.items()}
                return value
            expected = rewrite(original)
            expected.update(record_files=[], variants={k: str(c.binary_path(k)) for k in c.VARIANTS})
            actual = c.read(HERE / 'templates' / ('ir-' + workflow + '.json'))
            self.assertEqual(actual, expected)
            self.assertEqual(actual['env']['CARGO_TARGET_DIR'], str(c.ROOT / 'targets' / ('ir-' + workflow)))
            self.assertEqual(actual['env']['CARGO_BUILD_BUILD_DIR'], str(c.ROOT / 'shared-cache' / ('ir-' + workflow)))
            self.assertIn('--trace-children=no', actual['command'])
            if workflow == 'test': self.assertIn('--no-run', actual['prepare_command'])

    def test_fixed_plans_and_instruction_gate(self):
        self.assertEqual(c.PLAN, [('check', 20261022151), ('test', 20261022152)])
        self.assertEqual(set(c.STAGES), {'ir'})
        for workflow, seed in c.PLAN:
            self.assertEqual(review.plan(12, seed).count(['baseline', 'candidate']), 6)
            self.assertEqual(len(review.plan(2, seed ^ 0x5A17)), 2)
        for key, replacement in [('pairs', 11), ('paired_geometric_mean_count_reduction', .009),
                                 ('bootstrap_count_reduction_interval', [0, .025]),
                                 ('exact_two_sided_sign_p', .011), ('order', {'AB': {'geometric_mean_ratio': 1.02}})]:
            value = metric(); value[key] = replacement
            actual = {'confidence': .99, 'bootstrap_resamples': 20000, 'bootstrap_seed': 1701, 'metrics': {'cargo_ir': {'statistics': value}}}
            with self.subTest(key=key), patch.object(driver, 'read', return_value=actual):
                self.assertEqual(driver.gate(self.root), review.gate('ir', value))
                self.assertFalse(driver.gate(self.root)['passes_gate'])
        self.assertTrue(review.gate('ir', metric())['passes_gate'])
        self.assertEqual(review.gate('ir', metric())['native_speed_and_regressions'], 'unverified')

    def test_profile_event_index_and_missing_result(self):
        path = self.root / 'profile'
        for text, expected in [('events: Dr Ir Dw\nsummary: 4 123 6\n', 123), ('events: Ir\nsummary: 456\n', 456)]:
            path.write_text(text); self.assertEqual(review.profile_count(path), expected)
        for text in ['events: Dr\nsummary: 4\n', 'events: Ir\n', 'events: Ir\nsummary: 1\nsummary: 2\n']:
            path.write_text(text)
            with self.subTest(text=text), self.assertRaises(AssertionError): review.profile_count(path)

    def test_actual_preflight_wiring_and_child_rejection(self):
        for extra_child in (False, True):
            root = self.root / ('bad' if extra_child else 'good'); root.mkdir()
            p = {'config': root / 'config.json', 'preflight': root / 'preflight'}
            canonical = root / 'active/bin/cargo'
            variants = {k: root / (k + '.binary') for k in c.VARIANTS}
            for k, path in variants.items(): path.write_bytes(k.encode())
            config = {'env': {'CARGO_TARGET_DIR': str(root / 'target-fixture'), 'CARGO_BUILD_BUILD_DIR': str(root / 'shared-fixture')},
                      'canonical_executable': str(canonical), 'variants': {k: str(v) for k, v in variants.items()},
                      'prepare_command': ['/usr/bin/taskset', '-c', '0-7', '{cargo}', 'check'], 'cwd': str(root)}
            p['config'].write_text(json.dumps(config))
            calls = []
            def run_command(argv, cwd, environment, out, err):
                calls.append(argv)
                Path(out).write_text(''); Path(err).write_text('Finished dev profile\n')
                if '-o' in argv:
                    trace = Path(argv[argv.index('-o') + 1])
                    text = '1 execve("/usr/bin/taskset", [], []) = 0\n2 execve("' + str(canonical) + '", [], []) = 0\n'
                    if extra_child: text += '3 execve("/tmp/rustc", [], []) = 0\n'
                    trace.write_text(text)
                return {'returncode': 0, 'stdout': str(out), 'stderr': str(err)}
            def install(source, destination): destination.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, destination)
            core = SimpleNamespace(run_command=run_command, install_variant=install, atomic_json=c.write_once,
                                   utc_now=c.now, machine_metadata=lambda: {})
            with patch.object(fixture, 'paths', return_value=p), patch.object(fixture, 'EXPECTED', {k: c.sha(v) for k, v in variants.items()}),\
                 patch.object(fixture, 'uv_identity', return_value={}), patch.object(fixture, 'allocator_guard'),\
                 patch.object(fixture, 'quiet'), patch.object(fixture.shutil, 'which', side_effect=lambda x: '/usr/bin/' + x):
                if extra_child:
                    with self.assertRaises(AssertionError): fixture.preflight(core, 'check')
                else:
                    fixture.preflight(core, 'check')
                    report = c.read(p['preflight'] / 'report.json')
                    self.assertEqual([len(r['warming_runs']) for r in report['records']], [3, 3])
                    self.assertEqual(len(report['cross_switch']), 2)
                    self.assertEqual(len(calls), 10)

    def test_actual_driver_both_raw_before_effects_and_interruption(self):
        for fail_second in (False, True):
            root = self.root / ('interrupted' if fail_second else 'complete'); root.mkdir()
            (root / 'results').mkdir(); (root / 'logs').mkdir()
            events = []
            def atomic(path, value): Path(path).write_text(json.dumps(value))
            core = SimpleNamespace(atomic_json=atomic)
            def invocation(argv, **kwargs):
                if 'run' in argv:
                    out = Path(argv[argv.index('--output') + 1]); out.mkdir()
                    events.append(('sample', out.name, argv))
                else:
                    events.append(('effect', argv[5]))
                return SimpleNamespace(returncode=0)
            def raw(core, workflow, seed):
                events.append(('raw', workflow))
                if fail_second and workflow == 'test': raise AssertionError('synthetic incomplete test raw')
                return {'state': 'passed'}
            ref = SimpleNamespace(preflight=lambda core, w: events.append(('preflight', w)))
            with patch.object(c, 'ROOT', root), patch.object(driver, 'ROOT', root), patch.object(driver, 'load_core', return_value=core),\
                 patch.object(driver, 'verify_assets'), patch.object(driver, 'verify_seal'), patch.object(driver, 'quiet'),\
                 patch.object(driver, 'reference', return_value=ref), patch.object(driver, 'audit_ir', side_effect=raw),\
                 patch.object(driver, 'gate', return_value={'passes_gate': True}), patch.object(fixture, 'uv_identity', return_value={}),\
                 patch.object(driver.subprocess, 'run', side_effect=invocation):
                if fail_second:
                    with self.assertRaises(AssertionError): driver.run_ir('e' * 64)
                    self.assertFalse(any(e[0] == 'effect' for e in events))
                else:
                    driver.run_ir('e' * 64)
                    last_raw = max(i for i, e in enumerate(events) if e[0] == 'raw')
                    self.assertTrue(all(i > last_raw for i, e in enumerate(events) if e[0] == 'effect'))
                samples = [e for e in events if e[0] == 'sample']
                self.assertEqual([e[1] for e in samples], ['ir-check', 'ir-test'])
                for e, (_, seed) in zip(samples, c.PLAN):
                    argv = e[2]
                    self.assertEqual(argv[argv.index('--pairs') + 1], '12')
                    self.assertEqual(argv[argv.index('--warmup-pairs') + 1], '2')
                    self.assertEqual(argv[argv.index('--seed') + 1], str(seed))

    def test_deployment_archive_rejects_bad_members(self):
        def archive(extra=None, link=False):
            files = {'controller/a': b'a'}
            manifest = {'root': str(remote.ROOT), 'host': remote.HOST, 'state': 'bound',
                        'controls_source_freeze_sha256': '1' * 64,
                        'files': {k: {'bytes': len(v), 'sha256': hashlib.sha256(v).hexdigest()} for k, v in files.items()}}
            mb = c.encoded(manifest); stream = io.BytesIO()
            with tarfile.open(fileobj=stream, mode='w') as out:
                for name, data in [('delivery.json', mb), *files.items(), *([] if extra is None else [(extra, b'x')])]:
                    info = tarfile.TarInfo(name); info.mode = 0o644; info.size = len(data)
                    if link and name == 'controller/a': info.type = tarfile.SYMTYPE; info.linkname = '/tmp/x'; info.size = 0
                    out.addfile(info, io.BytesIO(data))
            data = stream.getvalue()
            return data, {'archive_sha256': hashlib.sha256(data).hexdigest(), 'manifest_sha256': hashlib.sha256(mb).hexdigest(), 'source_freeze_sha256': '1' * 64}
        data, request = archive(); remote.inspect_archive(data, request)
        for extra, link in [('../escape', False), ('controller/a', False), ('unexpected', False), (None, True)]:
            data, request = archive(extra, link)
            with self.subTest(extra=extra, link=link), self.assertRaises(AssertionError): remote.inspect_archive(data, request)

    def test_strict_guard_and_parent_identity_are_not_relaxed(self):
        self.assertIs(fixture.quiet, driver.quiet)
        self.assertEqual(remote.GUARD, c.OCCUPANCY_SHA)
        self.assertEqual(remote.HOST, 'charlie-oss-2')
        self.assertEqual(remote.ROOT, c.ROOT)
        self.assertNotIn('native', transport.OPERATIONS)
        self.assertEqual(transport.OPERATIONS, {'admit', 'setup', 'ir', 'collect-setup', 'collect-ir'})

    def test_actual_remote_entry_guard_and_ir_exec_wiring(self):
        class ExecIntercept(BaseException): pass
        root = self.root / 'remote'
        calls = []
        request = {'operation': 'setup', 'host': c.HOST, 'root': str(root),
                   'occupancy_source': (HERE / 'occupancy.py').read_text()}
        def guarded_exec(code, scope):
            self.assertEqual(code.co_filename, '<authenticated-occupancy>')
            scope['require_quiet'] = lambda: (_ for _ in ()).throw(AssertionError('synthetic busy host'))
        with patch.object(remote, 'ROOT', root), patch.object(remote, 'identity'),\
             patch.object(remote, 'exec', side_effect=guarded_exec, create=True):
            with self.assertRaisesRegex(AssertionError, 'synthetic busy host'): remote.main(request)
        self.assertFalse(root.exists())
        (root / 'controller').mkdir(parents=True); (root / 'metadata').mkdir(); (root / 'results').mkdir()
        (root / 'controller/driver.py').write_text('pass\n')
        freeze = {'files': {'driver.py': c.record(root / 'controller/driver.py')}}
        (root / 'controller/source-freeze.json').write_text(json.dumps(freeze))
        (root / 'delivery.json').write_text('{}')
        (root / 'controller/measurement-seal.json').write_text('{}')
        sealed = c.sha(root / 'controller/measurement-seal.json')
        (root / 'metadata/setup-complete.json').write_text(json.dumps({'state': 'complete', 'measurement_seal_sha256': sealed}))
        request.update(operation='ir', manifest_sha256=c.sha(root / 'delivery.json'), measurement_seal_sha256=sealed,
                       source_freeze_sha256=c.sha(root / 'controller/source-freeze.json'))
        def quiet_exec(code, scope): scope['require_quiet'] = lambda: calls.append('quiet')
        def execv(executable, argv): calls.append((executable, argv)); raise ExecIntercept()
        with patch.object(remote, 'ROOT', root), patch.object(remote, 'identity'),\
             patch.object(remote, 'exec', side_effect=quiet_exec, create=True), patch.object(remote.os, 'execv', side_effect=execv):
            with self.assertRaises(ExecIntercept): remote.main(request)
            self.assertEqual(calls, ['quiet', ('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B',
                str(root / 'controller/driver.py'), '--run-ir', '--sealed-inputs-sha256', sealed])])
            (root / 'results/ir-status.json').write_text('{}')
            with self.assertRaisesRegex(AssertionError, 'IR already attempted'): remote.main(request)
            self.assertEqual(len(calls), 2)

    def test_actual_transport_entry_inherits_path_and_is_one_use(self):
        for name in ('source-freeze.json', 'host-assignment.json'): (self.root / name).write_text('{}')
        for name in ('remote.py', 'occupancy.py'): shutil.copyfile(HERE / name, self.root / name)
        approval = {'schema': 1, 'status': 'approved', 'scope': 'joint-183-185-operation', 'operation': 'admit',
                    'host': c.HOST, 'root': str(c.ROOT), 'source_freeze_sha256': c.sha(self.root / 'source-freeze.json'),
                    'assignment_sha256': c.sha(self.root / 'host-assignment.json'), 'protocol_sha256': c.PROTOCOL_SHA,
                    'output': str(self.root / 'executions/synthetic-admit')}
        path = self.root / 'synthetic-approval.json'; path.write_text(json.dumps(approval))
        seen = []
        def call(argv, **kwargs):
            self.assertNotIn('env', kwargs)
            self.assertEqual(argv[:3], [str(transport.SSH), c.HOST, '--'])
            self.assertIn('/usr/bin/python3', argv)
            self.assertEqual(os.environ['PATH'], 'SYNTHETIC-INHERITED-LOCAL-PATH')
            kwargs['stdout'].write(b'{"state":"passed"}\n')
            seen.append(argv)
            return SimpleNamespace(returncode=0)
        with patch.object(c, 'HERE', self.root), patch.object(c, 'verify_source'),\
             patch.object(transport.subprocess, 'run', side_effect=call), patch.dict(os.environ, {'PATH': 'SYNTHETIC-INHERITED-LOCAL-PATH'}):
            transport.run(path, c.sha(path))
            with self.assertRaisesRegex(AssertionError, 'exclusive operation output'): transport.run(path, c.sha(path))
        self.assertEqual(len(seen), 1)
        receipt = c.read(self.root / 'executions/synthetic-admit/receipt.json')
        self.assertEqual((receipt['state'], receipt['returncode']), ('complete', 0))

    def test_failed_capture_keeps_opaque_bytes_without_effects(self):
        root = self.root / 'cohort'; (root / 'controller').mkdir(parents=True); (root / 'results/ir-check').mkdir(parents=True)
        for name in ('controller/source-freeze.json', 'delivery.json'): (root / name).write_text('{}')
        (root / 'results/ir-status.json').write_text(json.dumps({'state': 'failed', 'workflow': 'test', 'integrity_complete': ['check']}))
        opaque = b'\xffThis intentionally is not parseable sample/analysis JSON.\x00'
        (root / 'results/ir-check/samples.json').write_bytes(opaque)
        (root / 'results/ir-check/analysis.json').write_bytes(opaque)
        stdout = io.BytesIO()
        with patch.object(c, 'ROOT', root), patch.object(c, 'HERE', root / 'controller'),\
             patch.object(c, 'runtime_identity'), patch.object(c, 'verify_source'), patch.object(capture, 'require_quiet'),\
             patch.object(capture.sys, 'stdout', SimpleNamespace(buffer=stdout)):
            capture.capture('ir', 'absent', c.sha(root / 'controller/source-freeze.json'), c.sha(root / 'delivery.json'))
        archive = self.root / 'opaque.tar'; archive.write_bytes(stdout.getvalue())
        output = self.root / 'received'; output.mkdir()
        request = {'operation': 'collect-ir', 'source_freeze_sha256': c.sha(root / 'controller/source-freeze.json'),
                   'manifest_sha256': c.sha(root / 'delivery.json')}
        with patch.object(c, 'ROOT', root): proof = transport.receive_archive(archive, output, request)
        self.assertEqual(proof['boundary']['state'], 'failed')
        self.assertEqual(proof['qualification'], 'not-evaluated')
        self.assertEqual((output / 'collection/remote/results/ir-check/samples.json').read_bytes(), opaque)
        self.assertEqual((output / 'collection/remote/results/ir-check/analysis.json').read_bytes(), opaque)

    def test_retargeted_alias_with_equal_bytes_blocks_driver_and_capture(self):
        root = self.root / 'aliases'; controller = root / 'controller'; controller.mkdir(parents=True)
        (root / 'metadata').mkdir(); (root / 'ohm/lib').mkdir(parents=True); (controller / 'provenance').mkdir()
        first, second, link = (root / 'ohm/lib' / name for name in ('first', 'second', 'alias'))
        first.write_bytes(b'identical-runtime-bytes'); second.write_bytes(first.read_bytes()); link.symlink_to('first')
        initial = prepare_host.runtime_aliases(root)
        setup_path = root / 'metadata/setup.json'; setup_path.write_text(json.dumps({'runtime_aliases': initial}))
        (controller / 'source-freeze.json').write_text('{}'); (controller / 'provenance/ci.json').write_text('{}')
        variants = {}
        with patch.object(c, 'ROOT', root):
            for variant in c.VARIANTS:
                binary = c.binary_path(variant); binary.parent.mkdir(parents=True, exist_ok=True); binary.write_bytes(variant.encode())
                variants[variant] = c.sha(binary)
        (controller / 'input-binding.json').write_text(json.dumps({'state': 'bound', 'production': {}, 'variants': variants,
            'controls_source_freeze_sha256': c.sha(controller / 'source-freeze.json')}))
        files = {str(p): c.sha(p) for p in (first, second, setup_path)}
        assets_path = controller / 'assets.json'
        assets_path.write_text(json.dumps({'variants': variants, 'trees': c.TREES, 'file_sha256': files, 'uv': {}, 'configuration_presence': {}}))
        seal = controller / 'measurement-seal.json'; seal.write_text(json.dumps({'file_sha256': files}))
        with patch.object(c, 'ROOT', root), patch.object(c, 'HERE', controller), patch.object(c, 'runtime_identity'),\
             patch.object(c, 'verify_source'), patch.object(driver, 'ROOT', root), patch.object(driver, 'ASSETS', assets_path),\
             patch.object(production, 'validate_documents'), patch.object(production, 'validate_ci'),\
             patch.object(fixture, 'uv_identity', return_value={}), patch.object(fixture, 'configuration_presence', return_value={}),\
             patch.object(fixture, 'allocator_guard'):
            driver.verify_assets()
            clean = capture.immutable(c.sha(seal)); self.assertEqual(clean['state'], 'passed')
            self.assertEqual(clean['runtime_aliases'], initial)
            link.unlink(); link.symlink_to('second')
            self.assertEqual({str(p): c.sha(p) for p in (first, second, setup_path)}, files)
            with self.assertRaisesRegex(AssertionError, 'runtime alias catalog changed'): driver.verify_assets()
            changed = capture.immutable(c.sha(seal))
            self.assertEqual(changed['state'], 'failed')
            self.assertEqual(changed['file_sha256'], files)
            self.assertEqual(changed['mismatches'], ['runtime-alias-catalog'])
        # Exercise the exact independent review predicate with the observed catalog.
        tree = ast.parse((HERE / 'reviewer/evidence.py').read_text())
        calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and len(n.args) == 2
                 and isinstance(n.args[1], ast.Constant)
                 and n.args[1].value == 'captured runtime aliases differ from the sealed setup catalog']
        self.assertEqual(len(calls), 1)
        predicate = compile(ast.Expression(calls[0].args[0]), '<independent-alias-join>', 'eval')
        self.assertTrue(eval(predicate, {}, {'t': {'immutable_inputs': clean}, 'setup': {'runtime_aliases': initial}}))
        self.assertFalse(eval(predicate, {}, {'t': {'immutable_inputs': changed}, 'setup': {'runtime_aliases': initial}}))
        self.assertFalse(eval(predicate, {}, {'t': {'immutable_inputs': dict(clean, runtime_alias_error='unreadable')}, 'setup': {'runtime_aliases': initial}}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists(): raise SystemExit('new pure-check report required')
    stream = io.StringIO()
    with patch.object(subprocess, 'Popen', side_effect=blocked), patch.object(subprocess, 'run', side_effect=blocked),\
         patch.object(subprocess, 'check_output', side_effect=blocked), patch.object(socket.socket, 'connect', side_effect=blocked),\
         patch.object(os, 'execv', side_effect=blocked):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'details': stream.getvalue(),
              'source_sha256': {str(p.relative_to(HERE)): c.sha(p) for p in sorted(HERE.rglob('*.py'))},
              'no_host_network_compiler_or_measurement_execution': True}
    c.write_once(output, report)
    print(json.dumps({k: v for k, v in report.items() if k not in ('source_sha256', 'details')}, sort_keys=True))
    if not result.wasSuccessful(): print(stream.getvalue(), file=sys.stderr)
    raise SystemExit(0 if result.wasSuccessful() else 1)
