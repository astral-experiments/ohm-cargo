"""One bounded remote operation; source is sent by the reviewed local transport."""
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

ROOT = Path('/tmp/ohm-hillclimb-20261022-joint-183-185-stack181-host2')
HOST = 'charlie-oss-2'
PATH = str(ROOT / 'active/bin') + ':' + str(ROOT / 'ohm/bin') + ':/usr/bin:/bin'
GUARD = '098f4e4df9f4a9c334659a7b10d9c88b07c0213d58522040102dc003da53c4dd'


def need(value, message):
    if not value:
        raise AssertionError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe(name):
    need(name and not name.startswith('/') and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe archive member')


def identity():
    need(os.getuid() == os.geteuid() == 1000 and Path('/').stat().st_uid == 0, 'normal UID required')
    need(os.uname().nodename == HOST and set(os.sched_getaffinity(0)) == {8} and os.environ.get('PATH') == PATH, 'wrong host/affinity/PATH')
    need(ROOT.parent == Path('/tmp') and ROOT.parent.resolve() == ROOT.parent and
         ROOT.parent.stat().st_uid == 0 and stat.S_IMODE(ROOT.parent.stat().st_mode) == 0o1777, 'unexpected staging parent')


def inspect_archive(data, request):
    need(hashlib.sha256(data).hexdigest() == request['archive_sha256'], 'delivery archive changed')
    source = tarfile.open(fileobj=io.BytesIO(data), mode='r:')
    members = source.getmembers()
    need(members and members[0].name == 'delivery.json', 'manifest must be first')
    seen = set()
    for member in members:
        safe(member.name)
        need(member.isfile() and member.name not in seen, 'nonregular/duplicate member')
        need(member.mode == (0o755 if member.name.startswith('controller/binaries/') else 0o644), 'unexpected deployment mode')
        seen.add(member.name)
    manifest_bytes = source.extractfile(members[0]).read()
    need(hashlib.sha256(manifest_bytes).hexdigest() == request['manifest_sha256'], 'delivery manifest changed')
    manifest = json.loads(manifest_bytes)
    need(manifest['root'] == str(ROOT) and manifest['host'] == HOST and manifest['state'] == 'bound', 'wrong/unbound delivery')
    need(manifest['controls_source_freeze_sha256'] == request['source_freeze_sha256'], 'wrong control freeze')
    need(seen == {'delivery.json', *manifest['files']}, 'delivery membership differs')
    for member in members[1:]:
        actual = {'bytes': member.size, 'sha256': hashlib.file_digest(source.extractfile(member), 'sha256').hexdigest()}
        need(actual == manifest['files'][member.name], 'delivery payload differs: ' + member.name)
    return source, members, manifest


def main(request):
    identity()
    need(request['host'] == HOST and request['root'] == str(ROOT), 'wrong request destination')
    guard = request['occupancy_source']
    need(hashlib.sha256(guard.encode()).hexdigest() == GUARD, 'occupancy source changed')
    scope = {'__name__': 'occupancy_definitions_only'}
    exec(compile(guard, '<authenticated-occupancy>', 'exec'), scope)
    quiet = scope['require_quiet']
    operation = request['operation']
    need(operation in ('admit', 'setup', 'ir', 'collect-setup', 'collect-ir'), 'unplanned operation')
    if operation == 'admit':
        need(not os.path.lexists(ROOT), 'cohort root already exists')
        occupancy = quiet()
        print(json.dumps({'state': 'passed', 'host': HOST, 'root': str(ROOT), 'root_absent': True,
                          'uid': os.getuid(), 'affinity': sorted(os.sched_getaffinity(0)), 'occupancy': occupancy}, sort_keys=True))
        return
    if operation == 'setup':
        need(not os.path.lexists(ROOT), 'fresh cohort root is required')
        quiet()
        data = sys.stdin.buffer.read()
        source, members, manifest = inspect_archive(data, request)
        occupancy = quiet()
        need(not os.path.lexists(ROOT), 'cohort appeared during input verification')
        ROOT.mkdir(mode=0o700)
        # Each regular member is installed once; no extraction links or overwrites.
        for member in members:
            destination = ROOT / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as output:
                stream = source.extractfile(member)
                while chunk := stream.read(1024 * 1024):
                    output.write(chunk)
            destination.chmod(member.mode)
        for name, expected in manifest['files'].items():
            path = ROOT / name
            need(sha(path) == expected['sha256'] and path.stat().st_size == expected['bytes'], 'installed delivery differs')
        for name, value in [('ownership.json', {'host': HOST, 'root': str(ROOT), 'uid': os.getuid(),
                             'delivery_sha256': request['manifest_sha256'], 'approval_sha256': request['approval_sha256']}),
                            ('delivery-occupancy.json', occupancy)]:
            with (ROOT / name).open('x') as stream:
                json.dump(value, stream, indent=2, sort_keys=True)
                stream.write('\n')
        os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(ROOT / 'controller/prepare_host.py')])
    need(ROOT.is_dir() and not ROOT.is_symlink() and ROOT.stat().st_uid == 1000, 'unowned cohort root')
    need(sha(ROOT / 'delivery.json') == request['manifest_sha256'], 'deployed delivery changed')
    need(sha(ROOT / 'controller/source-freeze.json') == request['source_freeze_sha256'], 'deployed controls changed')
    freeze = json.loads((ROOT / 'controller/source-freeze.json').read_text())
    for name, expected in freeze['files'].items():
        safe(name)
        path = ROOT / 'controller' / name
        need(path.is_file() and not path.is_symlink() and sha(path) == expected['sha256'] and path.stat().st_size == expected['bytes'], 'runtime source changed')
    if operation == 'ir':
        need(sha(ROOT / 'controller/measurement-seal.json') == request['measurement_seal_sha256'], 'setup seal changed')
        setup = json.loads((ROOT / 'metadata/setup-complete.json').read_text())
        need(setup['state'] == 'complete' and setup['measurement_seal_sha256'] == request['measurement_seal_sha256'], 'setup not complete')
        need(not os.path.lexists(ROOT / 'results/ir-status.json'), 'IR already attempted')
        quiet()
        os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(ROOT / 'controller/driver.py'),
                  '--run-ir', '--sealed-inputs-sha256', request['measurement_seal_sha256']])
    quiet()
    os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(ROOT / 'controller/capture.py'),
              '--phase', operation.removeprefix('collect-'), '--seal-sha256', request.get('measurement_seal_sha256') or 'absent',
              '--source-freeze-sha256', request['source_freeze_sha256'], '--delivery-sha256', request['manifest_sha256']])


if __name__ == '__main__':
    main(json.loads(sys.argv[1]))
