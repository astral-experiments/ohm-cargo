#!/usr/bin/env python3
"""Read-only terminal capture; complete and failed phases retain opaque raw bytes."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c
from occupancy import require_quiet
from prepare_host import runtime_aliases


def selected():
    files = {}
    for prefix in ('controller', 'benchmark', 'metadata', 'logs', 'results'):
        top = c.ROOT / prefix
        if not top.exists():
            continue
        for path in sorted(top.rglob('*')):
            relative = str(path.relative_to(c.ROOT))
            if relative == 'controller/binaries' or relative.startswith('controller/binaries/'):
                continue
            c.need(not path.is_symlink(), 'unexpected collection symlink: ' + relative)
            if path.is_dir():
                continue
            c.regular(path)
            files[relative] = path
    for name in ('delivery.json', 'ownership.json', 'delivery-occupancy.json'):
        path = c.ROOT / name
        if path.exists():
            files[name] = c.regular(path)
    return files


def boundary(phase):
    status_path = c.ROOT / ('results/ir-status.json' if phase == 'ir' else 'metadata/setup-complete.json')
    if not status_path.exists():
        if phase == 'setup' and (c.ROOT / 'metadata/setup-failed.json').exists():
            return {'state': 'failed', 'workflow': None, 'integrity_complete': []}
        return {'state': 'absent', 'workflow': None, 'integrity_complete': []}
    value = c.read(status_path)
    c.need(value['state'] in ('complete', 'failed'), 'phase is active, not terminal')
    return {'state': value['state'], 'workflow': value.get('workflow'), 'integrity_complete': value.get('integrity_complete', [])}


def footprint():
    names = ['results/ir-status.json'] + [prefix + '/ir-' + workflow + suffix
            for workflow, _ in c.PLAN for prefix, suffix in
            [('targets', ''), ('shared-cache', ''), ('metadata', '-preflight'), ('results', '')]]
    return {name: {'lexists': os.path.lexists(c.ROOT / name),
                   'directory': (c.ROOT / name).is_dir(), 'symlink': (c.ROOT / name).is_symlink()}
            for name in names}


def immutable(seal_sha):
    path = c.ROOT / 'controller/measurement-seal.json'
    if not path.exists():
        return {'state': 'absent', 'file_sha256': {}, 'mismatches': []}
    if c.sha(path) != seal_sha:
        return {'state': 'seal-differs', 'file_sha256': {}, 'mismatches': ['controller/measurement-seal.json']}
    seal = c.read(path)
    actual = {name: c.sha(name) if Path(name).is_file() else None for name in seal['file_sha256']}
    mismatches = [name for name, value in actual.items() if value != seal['file_sha256'][name]]
    expected_aliases = c.read(c.ROOT / 'metadata/setup.json')['runtime_aliases']
    try:
        observed_aliases = runtime_aliases(c.ROOT)
        alias_error = None
    except Exception as error:
        observed_aliases, alias_error = None, repr(error)
    if observed_aliases != expected_aliases:
        mismatches.append('runtime-alias-catalog')
    return {'state': 'passed' if not mismatches else 'failed', 'file_sha256': actual, 'mismatches': mismatches,
            'runtime_aliases': observed_aliases, 'runtime_alias_error': alias_error}


def add_bytes(archive, name, data):
    info = tarfile.TarInfo(name)
    info.mode = 0o644
    info.size = len(data)
    archive.addfile(info, io.BytesIO(data))


def capture(phase, seal_sha, source_sha, delivery_sha):
    c.runtime_identity()
    c.need(c.sha(c.HERE / 'source-freeze.json') == source_sha and c.sha(c.ROOT / 'delivery.json') == delivery_sha, 'capture identity differs')
    c.verify_source(local=False)
    require_quiet()
    state = boundary(phase)
    files = selected()
    before = {name: c.record(path) for name, path in files.items()}
    frozen = immutable(seal_sha)
    paths_before = footprint()
    # Hashes and names only: samples, profiles and analysis contents are not decoded.
    manifest = {'schema': 1, 'state': 'terminal-bytes-retained-not-qualified', 'phase': phase,
                'host': c.HOST, 'root': str(c.ROOT), 'captured_at': c.now(), 'boundary': state,
                'controls_source_freeze_sha256': source_sha, 'delivery_sha256': delivery_sha,
                'measurement_seal_sha256': seal_sha, 'files': before, 'immutable_inputs': frozen,
                'workflow_footprint': paths_before,
                'no_analysis_or_workload_execution': True,
                'excluded_payloads': ['controller/binaries', 'assets', 'ohm', 'profiling-tools', 'uv', 'cargo-home', 'targets', 'shared-cache', 'tmp']}
    manifest_bytes = c.encoded(manifest)
    with tarfile.open(fileobj=sys.stdout.buffer, mode='w|') as archive:
        add_bytes(archive, 'transfer-manifest.json', manifest_bytes)
        for name, path in files.items():
            info = tarfile.TarInfo('remote/' + name)
            info.mode = 0o644
            info.size = before[name]['bytes']
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        c.need(set(selected()) == set(files), 'collection membership changed')
        c.need({name: c.record(path) for name, path in files.items()} == before, 'raw collection changed while streaming')
        c.need(boundary(phase) == state and immutable(seal_sha) == frozen and footprint() == paths_before, 'terminal state, footprint or input hashes changed')
        completion = {'state': 'complete', 'completed_at': c.now(),
                      'transfer_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                      'files_verified_before_and_after': len(files), 'boundary': state,
                      'qualification': 'not-evaluated'}
        add_bytes(archive, 'collection-complete.json', c.encoded(completion))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('setup', 'ir'), required=True)
    parser.add_argument('--seal-sha256', required=True)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--delivery-sha256', required=True)
    a = parser.parse_args()
    capture(a.phase, a.seal_sha256, a.source_freeze_sha256, a.delivery_sha256)
