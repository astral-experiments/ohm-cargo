#!/usr/bin/env python3
"""Fresh joint cohort: setup seal and exactly two fixed Cargo-Ir endpoints."""
import argparse
import csv
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c
from common import ROOT, PLAN, STAGES, read, sha, paths
from occupancy import require_quiet as quiet
import fixture
import production
from prepare_host import runtime_aliases

ASSETS = ROOT / 'controller/assets.json'
SEAL = ROOT / 'controller/measurement-seal.json'
SAMPLE_FIELDS = ('stage','pair','order','position','variant','started_at','returncode','wall_ns','user_seconds','system_seconds','minor_faults','major_faults','voluntary_context_switches','involuntary_context_switches','stdout','stderr')

def reference(phase):
    assert phase == 'ir'
    fixture.EXPECTED = read(ASSETS)['variants']
    return fixture

def load_core():
    path = c.core_path()
    c.need(sha(path) == c.PAIRED_SHA, 'paired runner changed')
    spec = importlib.util.spec_from_file_location('joint_paired', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def phase_status(phase):
    return ROOT / 'results' / (phase + '-status.json')

def audit_sample_tables(output, samples, phase):
    assert samples == [json.loads(line) for line in (output / 'samples.jsonl').read_text().splitlines()]
    with (output / 'samples.csv').open(newline='') as stream:
        reader = csv.DictReader(stream)
        fields = SAMPLE_FIELDS + (('metric_cargo_ir',) if phase == 'ir' else ())
        assert tuple(reader.fieldnames) == fields
        rows = list(reader)
    assert len(rows) == len(samples)
    for csv_row, sample in zip(rows, samples):
        assert all(csv_row[key] == str(sample[key]) for key in fields)

def audit_ir(core, workflow, seed):
    output = paths('ir', workflow)['output']
    manifest, samples = read(output / 'manifest.json'), read(output / 'samples.json')
    expected = read(ASSETS)['variants']
    assert manifest['state'] == 'complete' and manifest['phase'] == 'confirmation'
    assert (manifest['pairs'], manifest['warmup_pairs'], manifest['seed']) == (12, 2, seed)
    assert manifest['variant_sha256'] == manifest['variant_sha256_after'] == expected
    assert manifest['recorded_file_sha256'] == manifest['recorded_file_sha256_after']
    assert manifest['configuration'] == read(paths('ir', workflow)['config'])
    assert sha(paths('ir', workflow)['config']) == manifest['configuration_sha256']
    for path, digest in manifest['recorded_file_sha256'].items():
        assert sha(path) == digest, path
    plans = {'warmup': [list(order) for order in core.make_plan(2, seed ^ 0x5A17)],
             'measurement': [list(order) for order in core.make_plan(12, seed)]}
    assert manifest['plans'] == plans
    identities = [(stage, pair, position, variant, 'AB' if order[0] == 'baseline' else 'BA')
                  for stage, plan in plans.items() for pair, order in enumerate(plan)
                  for position, variant in enumerate(order)]
    assert [(row['stage'], row['pair'], row['position'], row['variant'], row['order']) for row in samples] == identities
    assert len(samples) == 28 and plans['measurement'].count(['baseline', 'candidate']) == 6
    audit_sample_tables(output, samples, 'ir')
    ref = reference('ir')
    for row in samples:
        assert row['returncode'] == 0 and row['executable_unchanged']
        assert row['installed_sha256'] == expected[row['variant']]
        assert row['prepare']['returncode'] == 0 and '--trace-children=no' in row['command']
        if workflow == 'test':
            assert '--no-run' in row['command']
        ref.fresh(row['stderr'])
        ref.fresh(row['prepare']['stderr'])
        assert set(row['metric_files']) == set(row['metrics']) == {'cargo_ir'}
        metric = row['metric_files']['cargo_ir']
        assert sha(metric['path']) == metric['sha256']
        assert core.read_callgrind_summary(metric['path'], 'Ir') == row['metrics']['cargo_ir'] == row['metric_cargo_ir']
        assert row['metrics']['cargo_ir'] > 0
    return {'state': 'passed', 'completed_at': core.utc_now(), 'pairs': 12, 'warmup_pairs': 2,
            'invocations_verified': 28, 'profile_hashes_verified': 28, 'uv_after': ref.uv_identity()}


def verify_assets():
    c.runtime_identity()
    c.verify_source(local=False)
    binding = read(ROOT / 'controller/input-binding.json')
    c.need(binding['state'] == 'bound' and binding['controls_source_freeze_sha256'] == sha(c.HERE / 'source-freeze.json'), 'inputs are unbound')
    documents, hashes = {}, {}
    for role, reference in binding['production'].items():
        path = ROOT / 'controller/provenance' / (role + '.data')
        c.need(sha(path) == reference['sha256'], 'production provenance changed')
        hashes[role] = sha(path)
        documents[role] = read(path) if role not in {'driver', 'baseline_patch', 'candidate_patch'} else None
    production.validate_documents(documents, hashes, binding['variants'])
    production.validate_ci(read(ROOT / 'controller/provenance/ci.json'))
    assets = read(ASSETS)
    c.need(assets['variants'] == binding['variants'] and assets['trees'] == c.TREES, 'actual pair differs')
    for variant, expected in assets['variants'].items():
        c.need(sha(c.binary_path(variant)) == expected, 'variant binary changed')
    for name, expected in assets['file_sha256'].items():
        c.need(sha(name) == expected, 'sealed setup input changed: ' + name)
    setup = read(ROOT / 'metadata/setup.json')
    c.need(setup['runtime_aliases'] == runtime_aliases(ROOT), 'runtime alias catalog changed')
    c.need(fixture.uv_identity() == assets['uv'], 'uv changed')
    c.need(fixture.configuration_presence() == assets['configuration_presence'], 'Cargo configuration presence changed')
    fixture.allocator_guard()
    return assets


def derive(workflow, assets):
    config = read(ROOT / 'controller/base-configs' / ('ir-' + workflow + '.json'))
    config['record_files'] = sorted(set(assets['file_sha256']) | {
        str(ASSETS), str(SEAL),
        *(str(paths('ir', w)['config']) for w, _ in PLAN),
        str(paths('ir', workflow)['preflight'] / 'report.json')})
    return config


def prepare():
    assets = verify_assets()
    quiet()
    c.need(not SEAL.exists() and not SEAL.is_symlink(), 'seal already exists')
    configs = {}
    for workflow, _ in PLAN:
        p = paths('ir', workflow)
        c.need(not any(path.exists() or path.is_symlink() for path in p.values()), 'existing workflow state')
        config = derive(workflow, assets)
        for name in ('CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR'):
            c.need(not os.path.lexists(config['env'][name]), 'fixture is not fresh')
        configs[str(p['config'])] = c.encoded(config)
    # Both configurations are materialized before the seal, and no Cargo is run here.
    for path, data in configs.items():
        with Path(path).open('xb') as stream:
            stream.write(data)
    files = dict(assets['file_sha256']) | {str(ASSETS): sha(ASSETS)} | {p: sha(p) for p in configs}
    seal = {'schema': 1, 'state': 'sealed-before-warming', 'created_at': c.now(),
            'host': c.HOST, 'root': str(ROOT), 'stages': json.loads(json.dumps(STAGES)),
            'variants': assets['variants'], 'trees': c.TREES, 'uv': assets['uv'],
            'protocol_sha256': c.PROTOCOL_SHA, 'controls_source_freeze_sha256': sha(c.HERE / 'source-freeze.json'),
            'input_binding_sha256': sha(c.HERE / 'input-binding.json'),
            'configs': {p: sha(p) for p in configs}, 'file_sha256': files,
            'future_reports': [str(paths('ir', w)['preflight'] / 'report.json') for w, _ in PLAN],
            'configuration_presence': assets['configuration_presence'],
            'native_phase_planned': False, 'native_speed_and_regressions': 'unverified'}
    c.write_once(SEAL, seal)
    verify_seal(sha(SEAL))
    c.write_once(ROOT / 'metadata/setup-complete.json', {'state': 'complete', 'completed_at': c.now(),
                 'measurement_seal_sha256': sha(SEAL), 'configs': seal['configs'],
                 'no_workflow_warming_or_measurement': True, 'identity': c.runtime_identity()})
    print(json.dumps({'state': 'complete', 'measurement_seal_sha256': sha(SEAL), 'configs': seal['configs']}, sort_keys=True))


def verify_seal(expected):
    c.need(sha(SEAL) == c.digest(expected), 'measurement seal changed')
    seal = read(SEAL)
    assets = read(ASSETS)
    c.need(seal['state'] == 'sealed-before-warming' and seal['stages'] == json.loads(json.dumps(STAGES)), 'fixed plan differs')
    c.need(seal['variants'] == assets['variants'] and seal['trees'] == c.TREES and seal['uv'] == fixture.uv_identity(), 'source/binary identities differ')
    c.need(seal['configs'] == {str(paths('ir', w)['config']): sha(paths('ir', w)['config']) for w, _ in PLAN}, 'configuration membership/bytes differ')
    for path, expected_sha in seal['file_sha256'].items():
        c.need(sha(path) == expected_sha, 'immutable input changed: ' + path)
    for workflow, _ in PLAN:
        config = read(paths('ir', workflow)['config'])
        c.need(config == derive(workflow, assets), 'derived workload configuration differs')
        unknown = sorted(name for name in os.environ if (name.startswith(c.ENV_PREFIXES) or name in c.ENV_NAMES) and name not in config['env'])
        c.need(not unknown, 'unsealed inherited build environment names: ' + str(unknown))
    c.need(fixture.configuration_presence() == seal['configuration_presence'], 'Cargo config presence differs')
    fixture.allocator_guard()
    return seal


def gate(output):
    analysis = read(output / 'analysis.json')
    c.need((analysis['confidence'], analysis['bootstrap_resamples'], analysis['bootstrap_seed']) == (0.99, 20000, 1701), 'statistics settings differ')
    stats = analysis['metrics']['cargo_ir']['statistics']
    reduction, interval = stats['paired_geometric_mean_count_reduction'], stats['bootstrap_count_reduction_interval']
    checks = {'fixed_pairs': stats['pairs'] == 12, 'at_least_one_percent': reduction >= 0.01,
              'positive_99_percent_lower_bound': interval[0] > 0,
              'two_sided_sign_p_at_most_0_01': stats['exact_two_sided_sign_p'] <= 0.01,
              'both_orders_positive': set(stats['order']) == {'AB', 'BA'} and all(row['geometric_mean_ratio'] > 1 for row in stats['order'].values())}
    return {'passes_gate': all(checks.values()), 'checks': checks, 'reduction': reduction,
            'interval_99': interval, 'sign_p': stats['exact_two_sided_sign_p'],
            'native_speed_and_regressions': 'unverified',
            'scope': 'Fixed independent pairs; no exclusions, extensions, pooling or interim effect inspection.'}


def run_ir(seal_sha):
    status_path = phase_status('ir')
    c.need(not os.path.lexists(status_path), 'IR was already attempted; automatic retries are forbidden')
    status = {'state': 'starting', 'phase': 'ir', 'started_at': c.now(), 'workflow': None,
              'integrity_complete': [], 'completed': [], 'measurement_seal_sha256': seal_sha}
    core = load_core()
    try:
        verify_assets()
        verify_seal(seal_sha)
        quiet()
        core.atomic_json(status_path, status)
        for workflow, seed in PLAN:
            verify_seal(seal_sha)
            quiet()
            status.update(state='preflight', workflow=workflow)
            core.atomic_json(status_path, status)
            reference('ir').preflight(core, workflow)
            verify_seal(seal_sha)
            p = paths('ir', workflow)
            c.need(not p['output'].exists(), 'measurement directory already exists')
            quiet()
            status['state'] = 'running'
            core.atomic_json(status_path, status)
            command = ['/usr/bin/python3', '-I', '-B', str(c.core_path()), 'run', '--config', str(p['config']),
                       '--output', str(p['output']), '--phase', 'confirmation', '--pairs', '12',
                       '--warmup-pairs', '2', '--seed', str(seed)]
            with p['log'].open('xb') as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
            c.need(result.returncode == 0, 'fixed batch failed: ' + workflow)
            shutil.copyfile(p['log'], p['output'] / 'runner.log')
            integrity = audit_ir(core, workflow, seed)
            core.atomic_json(p['output'] / 'integrity.json', integrity)
            verify_seal(seal_sha)
            status['integrity_complete'].append(workflow)
            core.atomic_json(status_path, status)
        c.need(status['integrity_complete'] == ['check', 'test'], 'both raw workflows must pass before effects')
        quiet()
        status.update(state='both-integrities-passed-before-analysis', workflow=None, raw_audits_completed_at=c.now())
        core.atomic_json(status_path, status)
        for workflow, _ in PLAN:
            p = paths('ir', workflow)
            command = ['/usr/bin/python3', '-I', '-B', str(c.core_path()), 'analyze', str(p['output']),
                       '--confidence', '0.99', '--resamples', '20000', '--seed', '1701', '--minimum-pairs', '12']
            with (p['output'] / 'analysis-stdout.json').open('xb') as stream:
                result = subprocess.run(command, stdout=stream, check=False)
            c.need(result.returncode == 0, 'analysis failed')
            decision = gate(p['output'])
            core.atomic_json(p['output'] / 'gate.json', decision)
            status['completed'].append({'workflow': workflow, 'directory': str(p['output']), **decision})
            core.atomic_json(status_path, status)
        verify_assets()
        verify_seal(seal_sha)
        quiet()
        status.update(state='complete', finished_at=c.now(), uv_after=fixture.uv_identity(),
                      qualifies_instruction_only=all(row['passes_gate'] for row in status['completed']),
                      native_speed_and_regressions='unverified')
        core.atomic_json(status_path, status)
        print(json.dumps({'state': 'complete', 'status': str(status_path)}, sort_keys=True))
        return 0
    except BaseException as error:
        status.update(state='failed', failed_at=c.now(), error=repr(error), traceback=traceback.format_exc())
        core.atomic_json(status_path, status)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare', action='store_true')
    group.add_argument('--run-ir', action='store_true')
    parser.add_argument('--sealed-inputs-sha256')
    args = parser.parse_args()
    if args.prepare:
        c.need(args.sealed_inputs_sha256 is None, 'unexpected preexisting seal')
        prepare()
    else:
        c.need(args.sealed_inputs_sha256 is not None, 'a bound setup seal is required')
        raise SystemExit(run_ir(args.sealed_inputs_sha256))
