"""Resolve only authenticated collected bytes; never import a measurement driver."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import common as c
import production

need, read, sha = c.need, c.read, c.sha


class Evidence:
    def __init__(self, directory, phase, expected_seal):
        self.directory = Path(directory).resolve()
        c.verify_source()
        self.transfer = read(self.directory / 'transfer-manifest.json')
        t = self.transfer
        need(t['schema'] == 1 and t['phase'] == phase and t['host'] == c.HOST and t['root'] == str(c.ROOT), 'wrong collection')
        need(t['controls_source_freeze_sha256'] == sha(c.HERE / 'source-freeze.json')
             and t['delivery_sha256'] == sha(c.HERE / 'delivery/manifest.json')
             and t['measurement_seal_sha256'] == expected_seal, 'collection/seal binding differs')
        self.files = {name: row['sha256'] for name, row in t['files'].items()}
        for name, row in t['files'].items():
            c.check_record(self.directory / 'remote' / c.safe_relative(name), row)
        actual = {str(path.relative_to(self.directory / 'remote')) for path in (self.directory / 'remote').rglob('*') if path.is_file()}
        need(actual == set(self.files) and not any(path.is_symlink() for path in (self.directory / 'remote').rglob('*')), 'collection has extra/missing/linked files')
        completion = read(self.directory / 'collection-complete.json')
        need(completion['state'] == 'complete' and completion['transfer_manifest_sha256'] == sha(self.directory / 'transfer-manifest.json')
             and completion['files_verified_before_and_after'] == len(self.files) and completion['boundary'] == t['boundary'], 'collection completion differs')
        receipt = read(self.directory.parent / 'receipt.json')
        command = read(self.directory.parent / 'command.json')
        need(receipt['state'] == 'complete' and receipt['returncode'] == 0 and receipt['operation'] == 'collect-' + phase, 'transport did not finish successfully')
        need(receipt['command_sha256'] == sha(self.directory.parent / 'command.json') and
             receipt['approval_sha256'] == command['approval_sha256'] == sha(command['approval_path']), 'transport approval/command binding differs')
        approval = read(command['approval_path'])
        need(approval['status'] == 'approved' and approval['operation'] == 'collect-' + phase
             and approval['source_freeze_sha256'] == t['controls_source_freeze_sha256']
             and approval['manifest_sha256'] == t['delivery_sha256'] and approval['output'] == str(self.directory.parent), 'actual collection approval differs')
        archive = self.directory.parent / 'stdout.tar'
        need(sha(archive) == receipt['stdout_sha256'] == receipt['collection']['archive_sha256'] and
             sha(self.directory / 'transfer-manifest.json') == receipt['collection']['manifest_sha256'], 'transport archive/manifest differs')
        self.verify_archive(archive)
        self.complete = t['boundary']['state'] == 'complete' and t['immutable_inputs']['state'] == 'passed'
        if not self.complete:
            # Failed captures remain fully byte-audited and never enter statistics.
            return
        delivery = read(self.file(str(c.ROOT / 'delivery.json')))
        need(delivery == read(c.HERE / 'delivery/manifest.json'), 'deployed original delivery differs')
        for name, row in delivery['files'].items():
            if name.startswith(('assets/', 'profiling-tools/', 'controller/binaries/')):
                continue
            c.check_record(self.file(str(c.ROOT / name)), row)
        binding = read(self.file(str(c.ROOT / 'controller/input-binding.json')))
        need(binding['state'] == 'bound' and binding['controls_source_freeze_sha256'] == t['controls_source_freeze_sha256'], 'actual inputs unbound')
        self.variants = binding['variants']
        documents, hashes = {}, {}
        for role, reference in binding['production'].items():
            path = self.file(str(c.ROOT / 'controller/provenance' / (role + '.data')))
            need(sha(path) == reference['sha256'], 'production provenance join differs')
            hashes[role] = sha(path)
            documents[role] = read(path) if role not in {'driver', 'baseline_patch', 'candidate_patch'} else None
        production.validate_documents(documents, hashes, self.variants)
        ci = self.file(str(c.ROOT / 'controller/provenance/ci.json'))
        need(sha(ci) == binding['ci']['sha256'] == c.CI_SHA, 'actual green CI binding differs')
        production.validate_ci(read(ci))
        seal_path = self.file(str(c.ROOT / 'controller/measurement-seal.json'))
        need(sha(seal_path) == expected_seal, 'actual setup seal differs')
        self.seal = read(seal_path)
        need(self.seal['state'] == 'sealed-before-warming' and self.seal['variants'] == self.variants
             and self.seal['trees'] == c.TREES and self.seal['protocol_sha256'] == c.PROTOCOL_SHA
             and self.seal['stages'] == json.loads(json.dumps(c.STAGES)), 'sealed plan/source/pair differs')
        need(t['immutable_inputs']['state'] == 'passed' and not t['immutable_inputs']['mismatches']
             and t['immutable_inputs']['file_sha256'] == self.seal['file_sha256'], 'capture input integrity failed')
        setup = read(self.file(str(c.ROOT / 'metadata/setup.json')))
        need(t['immutable_inputs']['runtime_alias_error'] is None
             and t['immutable_inputs']['runtime_aliases'] == setup['runtime_aliases'],
             'captured runtime aliases differ from the sealed setup catalog')
        self.assets = read(self.file(str(c.ROOT / 'controller/assets.json')))
        need(self.assets['variants'] == self.variants and self.assets['trees'] == c.TREES and self.assets['uv'] == self.seal['uv'], 'asset/source joins differ')
        for name, digest in self.seal['file_sha256'].items():
            if name.startswith(str(c.ROOT) + '/') and name[len(str(c.ROOT)) + 1:] in self.files:
                need(sha(self.file(name)) == digest, 'collected immutable input differs')
        need(self.seal['configs'] == {str(c.paths('ir', w)['config']): sha(self.file(str(c.paths('ir', w)['config']))) for w, _ in c.PLAN}, 'both configuration hashes differ')
        for workflow, _ in c.PLAN:
            self.config('ir', workflow)

    def file(self, path):
        prefix = str(c.ROOT) + '/'
        need(isinstance(path, str) and path.startswith(prefix), 'reference outside collected cohort: ' + str(path))
        relative = path[len(prefix):]
        c.safe_relative(relative)
        need(relative in self.files, 'uncollected evidence: ' + relative)
        result = self.directory / 'remote' / relative
        need(sha(c.regular(result)) == self.files[relative], 'evidence changed after verification')
        return result

    def config(self, phase, workflow):
        need(phase == 'ir' and workflow in ('check', 'test'), 'unplanned workflow')
        from prepare_host import validate_template
        template = read(c.HERE / 'templates' / ('ir-' + workflow + '.json'))
        base = read(self.file(str(c.ROOT / 'controller/base-configs' / ('ir-' + workflow + '.json'))))
        validate_template(base, template)
        expected = {**base, 'record_files': sorted(set(self.assets['file_sha256']) | {
            str(c.ROOT / 'controller/assets.json'), str(c.ROOT / 'controller/measurement-seal.json'),
            *(str(c.paths('ir', w)['config']) for w, _ in c.PLAN),
            str(c.paths('ir', workflow)['preflight'] / 'report.json')})}
        actual = read(self.file(str(c.paths(phase, workflow)['config'])))
        need(actual == expected, 'derived final workload differs')
        return actual

    def verify_archive(self, archive):
        expected = {'remote/' + name: row for name, row in self.transfer['files'].items()}
        expected |= {name: c.record(self.directory / name) for name in ('transfer-manifest.json', 'collection-complete.json')}
        seen = set()
        with tarfile.open(archive) as source:
            for member in source:
                c.safe_relative(member.name)
                need(member.isfile() and member.name not in seen and member.name in expected, 'unsafe/extra archive member')
                seen.add(member.name)
                need({'bytes': member.size, 'sha256': hashlib.file_digest(source.extractfile(member), 'sha256').hexdigest()} == expected[member.name], 'archive/file byte mismatch')
        need(seen == set(expected), 'archive is incomplete')
