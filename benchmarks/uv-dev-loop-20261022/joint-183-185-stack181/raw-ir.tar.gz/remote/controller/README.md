# Joint PR183–185 instruction confirmation

This package prepares one fresh comparison of PR181 `d81a093becb4321a975522624c2a383970f0d164` against the exact three-change composition `0116a6d29f506f425d837348b26d40d6a668027d` (tree `86a812c401f6a8966e5d9f428775f280c19b7b90`). PR182 is excluded. The combined effect is measured directly; individual PR percentages are never added or pooled.

The prospective protocol remains byte-identical to the frozen plan (`78f34e14…`). `host-assignment.json` separately binds `charlie-oss-2` and the fresh root `/tmp/ohm-hillclimb-20261022-joint-183-185-stack181-host2`. Host3 is not addressed by these controls. This source package contains no actual execution approval or accepted production binary identities.

This is a fresh v4 placement on host2 after the host8 occupancy guard rejected both IR and collector entry before dispatch. Those failed transports and the staged host8 root remain untouched; the conditional host8 recovery plan was not exercised. The earlier incomplete host4 cohort remains unqualified, and its effects were not decoded by root or the independent reviewer. `prospective-decision.json` selects fresh host2 roots before any setup or workload operation and schedules this joint study after the separate library-search study. All source, binary, runtime, uv, count, seed, gate, occupancy and alias controls remain unchanged. Only declared host/root literals differ in runtime modules. Both workflows require fresh targets and caches, all operation approvals remain unbound, and the host3 exclusion remains in force. No operational directory, target/cache state or measured sample is copied.

## What qualifies

Both unchanged warm workflows are required primary endpoints, in fixed check → test order. Test uses `cargo test --no-run`; no uv test executes. Each endpoint has 12 measured pairs and two warmup pairs, using seeds `20261022151` and `20261022152`, respectively. Measured orders are balanced six AB/six BA. The unchanged runner uses the paired geometric mean, 20,000 bootstrap resamples, seed 1701, a 99% interval, and the exact two-sided paired sign test.

Each endpoint must have at least 1% Cargo instruction reduction, a strictly positive lower 99% reduction bound, sign-test p ≤ .01, and a positive mean ratio in both orders. Both complete raw audits precede any effect calculation. A failed, incomplete or interrupted endpoint cannot qualify through the other endpoint. There are no exclusions, extensions, pooled samples or automatic retries.

This is **prospectively instruction-only**. The Callgrind event is `Ir`, with `--trace-children=no`; it describes the Cargo process, not total compiler/linker/build-script work. Native wall-time effects and native regressions remain **unverified**. No native phase is required, implemented or planned for this cohort. Instrumented wall/CPU observations remain diagnostic. The byte-identical generic runner retains its historical advisory text about native confirmation; the explicit prospective protocol and `gate.json` govern this cohort's instruction-only qualification, and no native claim follows from those generic fields.

## Source and input boundaries

- `frozen/paired.py`, `occupancy.py` and `reviewer/statistics_review.py` are exact authenticated copies. The profiler shim binary/source are pinned and copied only when actual inputs are bound.
- `fixture.py` retains the authenticated preflight function bodies; `driver.py` retains the exact raw-table/Ir audit bodies. `reviewer/review.py` retains the independent preflight/raw/statistics function bodies. `reuse-proof-final.json` records exact AST equality and the new wiring. Some unreachable native helper branches remain solely to preserve those function bodies; the public interfaces admit only setup and IR.
- `production.py` implements the actual fresh producer contract: full variant names under `binaries`/`source_trees`, exact per-variant source trees, actual rustc settings, matching common inputs, the section-preserving strip records, and root acceptance. The initial producer provenance tree is not mistaken for either variant's tree.
- Exact combined CI run 39696693562 is already green for the measured source: eight required jobs succeeded and optional APFS replay was skipped. The accepted raw run/jobs receipt is pinned as `e74e9b45…`.
- Only current source/plan/CI/build receipts are bound directly. Existing experiments and failure histories remain in their original directories. No old operational directory is copied into this cohort.

`inputs-template.json` deliberately has `state: unbound` and null production hashes. It is not executable approval. After the fresh pair's completed production audit and root acceptance exist, root fills a **new** input file with `state: approved-for-input-binding`, actual hashes, and the exact source/assignment digests. `bind_inputs.py` rejects missing, failed, wrong-schema or mismatched inputs before creating the delivery directory. It validates and rehashes inputs again after packaging.

## Execution interfaces

All real commands run as normal UID1000 with system Python `-I -B` on CPU8. Every managed SSH invocation must use the application's **`require_escalated` execution mode**; this is required for the managed SSH authentication/log paths. The local PATH is inherited. The fixed remote PATH is set only in the remote command. No global settings, security controls or services are changed.

These are command templates, not launch authority. Substitute actual accepted paths and SHA256 values. Each operation requires one ordinary root approval, described by `approval-contract.json`; there are no nested recovery wrappers or reusable consumed claims. Each approval binds an exclusive new `executions/<label>` directory. Failure preserves its command, stdout, stderr and terminal receipt, then stops.

```sh
C='/home/dev-user/Documents/Codex/2026-10-20/i-want-you-to-hillclimb-on/work/joint-183-185-measurement-controls-host2-v4'
/usr/bin/taskset -c 8 /usr/bin/python3 -I -B "$C/bind_inputs.py" \
  --inputs /absolute/path/to/actual-inputs.json --inputs-sha256 ACTUAL_INPUT_SHA256
/usr/bin/taskset -c 8 /usr/bin/python3 -I -B "$C/transport.py" \
  --approval /absolute/path/to/actual-operation.json --approval-sha256 ACTUAL_APPROVAL_SHA256
```

The transport supports `admit`, `setup`, `collect-setup`, `ir`, and `collect-ir` only. Root separately reviews and authorizes each bounded step:

1. **admit** checks the assigned host/UID/CPU/path and the unchanged strict occupancy guard, and requires the root to be absent. It performs no writes there.
2. **setup** rechecks quietness, verifies every exact regular archive member before creating the new owned root, installs the frozen sources/accepted pair, and prepares public runtime/source/dependency inputs. It may clone the pinned uv commit, extract pinned toolchain/profiler packages, copy public registry archives/indexes into a private Cargo home, and run locked dependency fetch. It performs no workload warming, compilation benchmark or uv test execution. Both IR configurations are sealed before warming.
3. **collect-setup** obtains a read-only opaque metadata archive. The independent setup reviewer must pass, and root accepts that exact setup seal before an IR approval can validate.
4. **ir** runs the one fixed cohort. Each workflow starts with distinct fresh target and shared-cache paths; both variants share those paths and `active/bin/cargo`. The original three untimed warming calls per variant, traced zero-child checks, untraced cross-switch freshness checks and strict occupancy guards remain intact. Only initial untimed warming may compile. Every preparation/timed sample must remain fresh. Source/configuration/input hashes are rechecked throughout.
5. **collect-ir** is read-only and waits for a terminal state. It retains every selected raw table/profile/log/status/config/source/proof file. It copies no generated targets, caches or binary payloads. Failed/incomplete phases are collectable and explicitly cannot qualify. Collection never parses sample metrics or analysis values.

The setup paths are `targets/ir-check`, `shared-cache/ir-check`, `targets/ir-test`, and `shared-cache/ir-test`; neither workflow can consume the other's warmed artifacts. The canonical Cargo path is identical for both variants within and across the workflows. Source paths and uv contents remain unchanged throughout. On another workspace prefix, a new prospective placement/config/input seal is required; changing the canonical executable or fixture paths between paired variants is forbidden.

## Local independent review

The receiver verifies the safe tar envelope, exact regular membership, SHA256/size records, and final collection footer. `reviewer/evidence.py` joins those bytes to the actual transport approval/receipt, local delivery, production pair, current CI and setup seal. The independent reviewer imports no measurement driver and invokes no Cargo or host commands.

```sh
/usr/bin/taskset -c 8 /usr/bin/python3 -I -B "$C/reviewer/review.py" \
  --collection "$C/executions/collect-setup-01/collection" --phase setup \
  --sealed-inputs-sha256 ACTUAL_MEASUREMENT_SEAL --output /absolute/new/setup-review
/usr/bin/taskset -c 8 /usr/bin/python3 -I -B "$C/reviewer/review.py" \
  --collection "$C/executions/collect-ir-01/collection" --phase ir \
  --sealed-inputs-sha256 ACTUAL_MEASUREMENT_SEAL --output /absolute/new/ir-review \
  --analyze-after-terminal
```

Both raw workflows, including all 56 profiles, exact plans/counts, CSV/JSON/JSONL joins, installed binary hashes, preparation/stderr freshness, trace/cross-switch proof and immutable inputs must pass before the reviewer computes either effect. It independently reproduces both statistics and compares the saved original analyses and gates. A failed capture may be byte-audited without `--analyze-after-terminal`; it returns `retained-not-qualified`. Never use an unsupported successful-phase contract to label partial data complete.

Raw operational records can contain host process metadata. They are retained privately for integrity; any later publication needs its own explicit privacy review and omitted-file inventory. These controls publish nothing.

## Local source checks and limitations

```sh
/usr/bin/taskset -c 8 /usr/bin/python3 -I -B "$C/test_controls.py" \
  --output /absolute/new/pure-checks.json
```

`pure-checks-v4-final.json` records 17 passing grouped tests with external execution blocked, including real function/entrypoint interception, actual CI shape, producer contract negatives, fixed-plan/gate checks, zero-child rejection, both raw audits before effects, immutable workload derivation, safe archive rejection, opaque failed collection, and changed-alias/same-content rejection. The temporary test directories and mock approvals do not refer to any real host execution. V1's earlier source-preparation reports remain intact in its sibling directory; they include the guarded incomplete-mock failure and the successful original check passes.

Actual production pair binding, host availability, setup sealing and both fixed measurements are still pending. Pure checks do not establish host/runtime compatibility or performance.
