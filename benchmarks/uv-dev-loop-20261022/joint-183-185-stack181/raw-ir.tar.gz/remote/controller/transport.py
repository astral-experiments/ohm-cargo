#!/usr/bin/env python3
"""One explicitly approved admit/setup/IR/capture operation, with exclusive receipts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c

SSH = Path('/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh')
OPERATIONS = {'admit', 'setup', 'ir', 'collect-setup', 'collect-ir'}


def validate_approval(value, approval_sha):
    c.need(value['schema'] == 1 and value['status'] == 'approved' and value['scope'] == 'joint-183-185-operation', 'actual operation approval required')
    operation = value['operation']
    c.need(operation in OPERATIONS and value['host'] == c.HOST and value['root'] == str(c.ROOT), 'operation/destination differs')
    c.need(value['source_freeze_sha256'] == c.sha(c.HERE / 'source-freeze.json') and
           value['assignment_sha256'] == c.sha(c.HERE / 'host-assignment.json') and
           value['protocol_sha256'] == c.PROTOCOL_SHA, 'approval does not bind frozen controls/plan')
    output = Path(value['output'])
    c.need(output.is_absolute() and output.parent == c.HERE / 'executions' and not os.path.lexists(output), 'exclusive operation output required')
    if operation != 'admit':
        delivery = c.read(c.HERE / 'delivery/manifest.json')
        receipt = c.read(c.HERE / 'delivery/receipt.json')
        c.need(receipt['state'] == 'complete' and delivery['state'] == 'bound', 'delivery is unbound')
        c.need(value['manifest_sha256'] == receipt['manifest_sha256'] == c.sha(c.HERE / 'delivery/manifest.json'), 'delivery manifest differs')
        c.need(value['delivery_receipt_sha256'] == c.sha(c.HERE / 'delivery/receipt.json'), 'delivery receipt differs')
        c.need(delivery['controls_source_freeze_sha256'] == value['source_freeze_sha256'], 'delivery used other controls')
        if operation == 'setup':
            c.need(value['archive_sha256'] == receipt['archive_sha256'] == c.sha(c.HERE / 'delivery/payload.tar'), 'delivery archive differs')
        if operation == 'ir':
            review = c.load_record(value['setup_review'])
            c.need(review['status'] == 'passed' and review['scope'] == 'joint-183-185-setup-acceptance'
                   and review['measurement_seal_sha256'] == value['measurement_seal_sha256']
                   and review['delivery_sha256'] == value['manifest_sha256']
                   and review['controls_source_freeze_sha256'] == value['source_freeze_sha256'], 'setup was not accepted for this exact cohort')
            independent = c.load_record(review['independent_review'])
            c.need(independent['status'] == 'passed' and independent['phase'] == 'setup'
                   and independent['measurement_seal_sha256'] == value['measurement_seal_sha256'], 'independent setup proof differs')
        if operation == 'ir' or value.get('measurement_seal_sha256') is not None:
            c.digest(value['measurement_seal_sha256'])
    return operation, output


def receive_archive(archive, output, request):
    destination = output / 'collection'
    destination.mkdir(exist_ok=False)
    with tarfile.open(archive, 'r:') as source:
        members = source.getmembers()
        c.need(members and members[0].name == 'transfer-manifest.json' and members[-1].name == 'collection-complete.json', 'incomplete transfer envelope')
        seen = set()
        for member in members:
            c.safe_relative(member.name)
            c.need(member.isfile() and member.name not in seen, 'unsafe/duplicate transfer member')
            seen.add(member.name)
        manifest_bytes = source.extractfile(members[0]).read()
        manifest = json.loads(manifest_bytes)
        c.need(manifest['host'] == c.HOST and manifest['root'] == str(c.ROOT)
               and manifest['phase'] == request['operation'].removeprefix('collect-')
               and manifest['controls_source_freeze_sha256'] == request['source_freeze_sha256']
               and manifest['delivery_sha256'] == request['manifest_sha256'], 'collection identity differs')
        expected = {'remote/' + name: row for name, row in manifest['files'].items()}
        c.need(seen == set(expected) | {'transfer-manifest.json', 'collection-complete.json'}, 'transfer membership differs')
        completion = json.loads(source.extractfile(members[-1]).read())
        c.need(completion['state'] == 'complete' and completion['transfer_manifest_sha256'] == hashlib.sha256(manifest_bytes).hexdigest()
               and completion['files_verified_before_and_after'] == len(expected) and completion['boundary'] == manifest['boundary'], 'completion envelope differs')
        for member in members:
            data = source.extractfile(member).read()
            if member.name in expected:
                c.need({'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)} == expected[member.name], 'transferred bytes differ')
            path = destination / member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(data)
    return {'archive_sha256': c.sha(archive), 'manifest_sha256': c.sha(destination / 'transfer-manifest.json'),
            'completion_sha256': c.sha(destination / 'collection-complete.json'), 'regular_members': len(seen),
            'boundary': manifest['boundary'], 'qualification': 'not-evaluated'}


def run(path, expected_sha):
    c.need(os.getuid() == os.geteuid() == 1000 and set(os.sched_getaffinity(0)) == {8}, 'normal UID/CPU8 required')
    c.verify_source()
    c.need(c.sha(c.regular(path)) == c.digest(expected_sha), 'actual approval bytes changed')
    approval = c.read(path)
    operation, output = validate_approval(approval, expected_sha)
    request = {k: approval[k] for k in ('operation', 'host', 'root', 'source_freeze_sha256')}
    request.update(approval_sha256=expected_sha, occupancy_source=(c.HERE / 'occupancy.py').read_text())
    for key in ('manifest_sha256', 'archive_sha256', 'measurement_seal_sha256'):
        if key in approval:
            request[key] = approval[key]
    remote = (c.HERE / 'remote.py').read_text()
    argv = [str(SSH), c.HOST, '--', '/usr/bin/env', '-u', 'PYTHONHOME', '-u', 'PYTHONPATH',
            '-u', 'PYTHONSTARTUP', '-u', 'PYTHONINSPECT', 'PATH=' + c.CONTROLLER_PATH,
            '/usr/bin/taskset', '-c', '8', '/usr/bin/python3', '-I', '-B', '-c', remote, json.dumps(request, sort_keys=True)]
    output.parent.mkdir(exist_ok=True)
    output.mkdir(exist_ok=False)
    c.write_once(output / 'command.json', {'argv': argv, 'approval_path': str(Path(path).resolve()),
                 'approval_sha256': expected_sha, 'remote_source_sha256': c.sha(c.HERE / 'remote.py'),
                 'local_path_inherited': True, 'requires_escalated_host_execution': True})
    receipt = {'state': 'running', 'operation': operation, 'started_at': c.now(), 'approval_sha256': expected_sha,
               'source_freeze_sha256': approval['source_freeze_sha256'], 'command_sha256': c.sha(output / 'command.json')}
    stdout = output / ('stdout.tar' if operation.startswith('collect-') else 'stdout')
    stderr = output / 'stderr'
    try:
        # The local PATH is deliberately inherited for managed devbox authentication.
        with stdout.open('xb') as out, stderr.open('xb') as err:
            if operation == 'setup':
                with (c.HERE / 'delivery/payload.tar').open('rb') as data:
                    result = subprocess.run(argv, stdin=data, stdout=out, stderr=err, check=False)
            else:
                result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err, check=False)
        receipt['returncode'] = result.returncode
        c.need(result.returncode == 0, 'remote operation failed; preserve and stop, no automatic retry')
        if operation.startswith('collect-'):
            receipt['collection'] = receive_archive(stdout, output, request)
        c.verify_source()
        receipt['state'] = 'complete'
    except BaseException as error:
        receipt.update(state='failed', error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        receipt.update(finished_at=c.now(), stdout_sha256=c.sha(stdout) if stdout.exists() else None,
                       stderr_sha256=c.sha(stderr) if stderr.exists() else None)
        c.write_once(output / 'receipt.json', receipt)
    print(json.dumps({'state': 'complete', 'operation': operation, 'receipt': str(output / 'receipt.json'),
                      'receipt_sha256': c.sha(output / 'receipt.json')}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approval', required=True)
    parser.add_argument('--approval-sha256', required=True)
    a = parser.parse_args()
    run(a.approval, a.approval_sha256)
