"""Small shared identity and serialization helpers; importing performs no I/O."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat

HERE = Path(__file__).resolve().parent
ROOT = Path('/tmp/ohm-hillclimb-20261022-joint-183-185-stack181-host2')
HOST = 'charlie-oss-2'
CONTROLLER_PATH = str(ROOT / 'active/bin') + ':' + str(ROOT / 'ohm/bin') + ':/usr/bin:/bin'
PRODUCTION_ROOT = Path('/tmp/ohm-hillclimb-20261022-joint-stack181-production')
BASE_COMMIT = 'd81a093becb4321a975522624c2a383970f0d164'
COMBINED_COMMIT = '0116a6d29f506f425d837348b26d40d6a668027d'
TREES = {'baseline': 'c4178b67e0b3a64a12b9b58f84b97323b99d734e',
         'candidate': '86a812c401f6a8966e5d9f428775f280c19b7b90'}
VARIANTS = {'baseline': 'joint-stack181-baseline', 'candidate': 'joint-stack181-combined'}
UV_COMMIT = '3d82a6ad5a7eab8c68236553b7846517767c4b61'
UV_LOCK = '747296375bb1889689f3bbb1e0303bddd071d6a65117c00be50856448260d014'
PLAN_FREEZE = '1f73953edd6eb8083eeb34d32377ca31aea41566cd329f7a361ddf60776c212a'
PROTOCOL_SHA = '78f34e146b0da9a25f0d6f74bd5d339107c0c7df2aad6b4c6a606159d441936e'
PAIRED_SHA = '50d0cb2d4f595ccfa72d463fedb3ff4dadf9dfc1446c749d482d9ede8418c7cf'
OCCUPANCY_SHA = '098f4e4df9f4a9c334659a7b10d9c88b07c0213d58522040102dc003da53c4dd'
SHIM_SHA = '42f912fe052732ef964681579a3bc1acbc50966f04babb5a452f25dfe4825973'
PRODUCTION_CONTROLS_SHA = '65a2974511a52d9c36bd8031d3eea26537164d403d201ac4e1d8fcb7a274fa92'
PRODUCTION_MANIFEST_SHA = '5f3d8e9ce3ab832bc35c34d92fbc8d331abb403ff551bbb82cb5ccf65f815df6'
CI_SHA = 'e74e9b45a1494da5a9953f41835367f7949059712ae0031bb9248158c7730ee2'
PLAN = [('check', 20261022151), ('test', 20261022152)]
STAGES = {'ir': {'pairs': 12, 'plan': PLAN}}
ENV_PREFIXES = ('CARGO_', 'RUST', '__CARGO_', 'LD_', 'DYLD_', 'MALLOC', '_RJEM_', 'JEMALLOC',
                'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'PKG_CONFIG')
ENV_NAMES = {'GLIBC_TUNABLES', 'CC', 'CXX', 'AR', 'RANLIB', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS'}
RUNTIME_HASHES = {
    'ohm/bin/rustc': '6109cff145371a50c4f62b61908d2ffbf6d259b180c8effde07baa426aab682a',
    'ohm/bin/rustdoc': '0b7d9ded49eb9ecc73097a7bb3bb286e1722ac7143d7ca7d2d7c524c55d5684e',
    'ohm/lib/librustc_driver-b03bf00bec23bb9a.so': 'a3a5d8cc86af464504170220d142c4ea1129434e2d5e741755feec6f9f35a436',
}
ROOT_CONFIG_SHA = '24095bd6315880162c8f660917100ac36638cb73778dd9ec6f1c9026ea87b178'


def need(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(value):
    need(isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'invalid SHA256')
    return value


def write_once(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encoded(value))


def safe_relative(name):
    p = Path(name)
    need(isinstance(name, str) and name and not p.is_absolute() and
         all(part not in ('', '.', '..') for part in name.split('/')), 'unsafe relative path: ' + str(name))
    return p


def regular(path):
    p = Path(path)
    need(stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink(), 'expected regular file: ' + str(p))
    return p


def record(path):
    p = regular(path)
    return {'sha256': sha(p), 'bytes': p.stat().st_size}


def check_record(path, expected):
    need(record(path) == expected, 'file identity differs: ' + str(path))


def load_record(reference):
    need(set(reference) == {'path', 'sha256'}, 'unexpected file-reference schema')
    p = regular(reference['path'])
    need(p.is_absolute() and sha(p) == digest(reference['sha256']), 'bound file differs: ' + str(p))
    return read(p)


def verify_source(local=True):
    freeze = read(HERE / 'source-freeze.json')
    need(freeze['schema'] == 1 and freeze['scope'] == 'joint-183-185-instruction-only-controls', 'wrong source freeze')
    need(set(freeze) == {'schema', 'scope', 'created_at', 'files', 'external_inputs', 'external_aliases',
                         'source_identity', 'reuse_checks_sha256'}, 'unexpected source-freeze schema')
    for name, expected in freeze['files'].items():
        check_record(HERE / safe_relative(name), expected)
    if local:
        for path, expected in freeze['external_inputs'].items():
            check_record(path, expected)
        for path, expected in freeze['external_aliases'].items():
            p = Path(path)
            need({'resolved': str(p.resolve()), 'symlink': os.readlink(p) if p.is_symlink() else None,
                  'sha256': sha(p)} == expected, 'managed helper alias changed')
    need(sha(HERE / 'protocol.json') == PROTOCOL_SHA, 'frozen protocol changed')
    assignment = read(HERE / 'host-assignment.json')
    need(assignment['root'] == str(ROOT) and assignment['host'] == HOST and
         assignment['protocol_sha256'] == PROTOCOL_SHA and assignment['plan_source_freeze_sha256'] == PLAN_FREEZE,
         'stage-specific assignment differs')
    need(sha(HERE / 'occupancy.py') == OCCUPANCY_SHA, 'occupancy guard changed')
    return freeze


def runtime_identity():
    need(os.getuid() == os.geteuid() == 1000 and os.stat('/').st_uid == 0, 'normal host UID is required')
    need(os.uname().nodename == HOST and set(os.sched_getaffinity(0)) == {8}, 'host/affinity differs')
    need(os.environ.get('PATH') == CONTROLLER_PATH, 'controller PATH differs')
    need(ROOT.is_dir() and not ROOT.is_symlink() and ROOT.stat().st_uid == 1000, 'unowned cohort root')
    return {'host': HOST, 'uid': os.getuid(), 'effective_uid': os.geteuid(),
            'root_directory_owner_uid': os.stat('/').st_uid, 'affinity': sorted(os.sched_getaffinity(0))}


def binary_path(variant):
    return ROOT / 'controller/binaries' / ('cargo-' + VARIANTS[variant])


def core_path():
    return ROOT / 'controller/frozen/paired.py'


def paths(phase, workflow):
    label = phase + '-' + workflow
    return {'config': ROOT / 'benchmark' / (label + '.json'),
            'preflight': ROOT / 'metadata' / (label + '-preflight'),
            'output': ROOT / 'results' / label,
            'log': ROOT / 'logs' / (label + '-runner.log')}


def deployment_files():
    """Every source file deploys verbatim below controller; external references do not."""
    freeze = read(HERE / 'source-freeze.json')
    return {'controller/' + name: HERE / name for name in freeze['files']} | {
        'controller/source-freeze.json': HERE / 'source-freeze.json'}
