"""Authenticated fixture functions; only global path/identity wiring is new."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

from common import ROOT, UV_COMMIT, read, sha, paths as _paths
from occupancy import require_quiet as quiet

FORBIDDEN_PREFIXES = ('LD_', 'DYLD_', 'MALLOC', '_RJEM_', 'JEMALLOC')

SYSTEM_ALLOCATOR_CONFIGS = ('/etc/_rjem_malloc.conf', '/etc/malloc.conf')

EXPECTED = None

def stage():
    return {"warming_order": ["baseline", "candidate"]}

def paths(workflow):
    return _paths("ir", workflow)

def uv_identity():
    head = subprocess.check_output(['git', '-C', str(ROOT / 'uv'), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(ROOT / 'uv'), 'status', '--porcelain'], text=True)
    assert head == UV_COMMIT and not status
    return {'commit': head, 'status': status, 'lock_sha256': sha(ROOT / 'uv/Cargo.lock')}

def allocator_guard():
    forbidden = sorted(name for name in os.environ
                       if name.startswith(FORBIDDEN_PREFIXES) or name == 'GLIBC_TUNABLES')
    assert not forbidden, forbidden
    for name in SYSTEM_ALLOCATOR_CONFIGS:
        assert not os.path.lexists(name), name
    return {'forbidden_environment_names': forbidden,
            'absent_system_configurations': list(SYSTEM_ALLOCATOR_CONFIGS)}

def configuration_presence():
    candidates = {ROOT / 'cargo-home' / name for name in ('config', 'config.toml')}
    for parent in (ROOT / 'uv', *(ROOT / 'uv').parents):
        candidates.update(parent / '.cargo' / name for name in ('config', 'config.toml'))
    return {str(path): {'lexists': os.path.lexists(path),
                       'sha256': sha(path) if path.is_file() else None,
                       'symlink': os.readlink(path) if path.is_symlink() else None}
            for path in sorted(candidates)}

def fresh(path):
    text = Path(path).read_text()
    assert 'Finished' in text and not re.search(r'^\s*(?:Compiling|Checking|Running)\s|^error:', text, re.M), path

def preflight(core, workflow):
    destination = paths(workflow)
    output = destination['preflight']
    output.mkdir(exist_ok=False)
    config = read(destination['config'])
    environment = os.environ.copy()
    for key, value in config['env'].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = str(value)
    records = []
    before = uv_identity()
    for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR'):
        fixture = Path(config['env'][key])
        assert not fixture.exists() and not fixture.is_symlink(), str(fixture)
    allocator_guard()
    for variant in stage()['warming_order']:
        quiet()
        canonical = Path(config['canonical_executable'])
        core.install_variant(Path(config['variants'][variant]), canonical)
        assert sha(canonical) == EXPECTED[variant]
        command = [part.replace('{cargo}', str(canonical)) for part in config['prepare_command']]
        warming_runs = []
        for warm_index in range(1, 4):
            label = variant + '.warm-' + str(warm_index)
            warm = core.run_command(command, config['cwd'], environment, output / (label + '.stdout'), output / (label + '.stderr'))
            assert warm['returncode'] == 0
            warming_runs.append(warm)
        trace_path = output / (variant + '.execve.log')
        traced = [shutil.which('strace'), '-f', '-qq', '-e', 'trace=execve,execveat', '-s', '4096', '-o', str(trace_path), '--', *command]
        trace = core.run_command(traced, config['cwd'], environment, output / (variant + '.trace.stdout'), output / (variant + '.trace.stderr'))
        assert trace['returncode'] == 0
        fresh(trace['stderr'])
        successes = [line for line in trace_path.read_text().splitlines() if re.search(r'= 0\s*$', line)]
        executable_paths = []
        for line in successes:
            match = re.search(r'execve\("([^"]+)"', line) or re.search(r'execveat\([^,]+, "([^"]+)"', line)
            assert match, line
            executable_paths.append(match[1])
        assert executable_paths == [str(Path(shutil.which('taskset')).resolve()), str(canonical)], executable_paths
        assert sha(canonical) == EXPECTED[variant]
        quiet()
        records.append({'variant': variant, 'binary_sha256': EXPECTED[variant], 'warm': warm, 'warming_runs': warming_runs, 'trace': trace,
                        'trace_path': str(trace_path), 'trace_sha256': sha(trace_path), 'successful_execve_paths': executable_paths})
    cross_switch = []
    for variant in stage()['warming_order']:
        canonical = Path(config['canonical_executable'])
        core.install_variant(Path(config['variants'][variant]), canonical)
        command = [part.replace('{cargo}', str(canonical)) for part in config['prepare_command']]
        result = core.run_command(command, config['cwd'], environment, output / (variant + '.cross-switch.stdout'), output / (variant + '.cross-switch.stderr'))
        assert result['returncode'] == 0 and sha(canonical) == EXPECTED[variant]
        fresh(result['stderr'])
        cross_switch.append({'variant': variant, **result})
    quiet()
    core.atomic_json(output / 'report.json', {'state': 'passed', 'completed_at': core.utc_now(), 'records': records, 'cross_switch': cross_switch,
                                             'uv_before': before, 'uv_after': uv_identity(), 'machine': core.machine_metadata()})
