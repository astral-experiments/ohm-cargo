"""Validate the actual fresh producer contract, never inferred legacy proof keys."""
from pathlib import Path
import common as c

ROLES = {'audit', 'root_review', 'provenance', 'manifest', 'controls_freeze', 'driver',
         'build_result', 'terminal_status', 'binary_manifest', 'baseline_strip', 'candidate_strip',
         'baseline_patch', 'candidate_patch'}


def validate_documents(documents, hashes, variants):
    c.need(set(documents) == ROLES and set(hashes) == ROLES, 'missing/extra production provenance')
    a, r, p = (documents[name] for name in ('audit', 'root_review', 'provenance'))
    expected_names = set(c.VARIANTS.values())
    full_binaries = {c.VARIANTS[k]: c.digest(v) for k, v in variants.items()}
    full_trees = {c.VARIANTS[k]: v for k, v in c.TREES.items()}
    c.need(set(variants) == {'baseline', 'candidate'} and len(set(variants.values())) == 2, 'unbound or identical binary pair')
    c.need(a['state'] == 'passed' and a['binaries'] == full_binaries, 'producer audit did not pass for this pair')
    c.need(r['status'] == 'passed' and r['scope'] == 'joint-stack181-local-production-pair', 'root pair review missing')
    c.need(r['binaries'] == full_binaries and r['source_trees'] == full_trees, 'root pair source/binary joins differ')
    c.need(isinstance(r['checks'], dict) and r['checks'] and all(v is True for v in r['checks'].values()), 'root checks incomplete')
    c.need(r['audit_sha256'] == hashes['audit'], 'root audit binding differs')
    c.need(r['controls_source_freeze_sha256'] == hashes['controls_freeze'] == c.PRODUCTION_CONTROLS_SHA == a['bindings']['controls_sha256'], 'production control freeze differs')
    c.need(r['production_manifest_sha256'] == a['production_manifest_sha256'] == hashes['manifest'] == c.PRODUCTION_MANIFEST_SHA, 'production manifest differs')
    for field, role in [('production_driver_sha256', 'driver'), ('provenance_sha256', 'provenance'),
                        ('build_result_sha256', 'build_result'), ('terminal_status_sha256', 'terminal_status')]:
        c.need(a[field] == hashes[role], 'audit receipt join differs: ' + role)
    common = c.digest(a['common_build_inputs_sha256'])
    c.need(r['common_build_inputs_sha256'] == p['common_build_inputs_sha256'] == common, 'common build inputs differ')
    c.need(p['host'] == 'charlie-oss' and p['cohort'] == 'local-joint-stack181', 'producer host/cohort differs')
    c.need(p['source'] == str(c.PRODUCTION_ROOT / 'source') and p['target'] == str(c.PRODUCTION_ROOT / 'target'), 'production canonical paths differ')
    c.need(p['expected_variant_source_trees'] == full_trees, 'provenance variants differ')
    launch, terminal = documents['build_result'], documents['terminal_status']
    c.need(launch['state'] == terminal['state'] == 'complete' and launch['returncode'] == 0 and launch['producer_started'] is True, 'producer is not terminal successful')
    c.need(launch['terminal_status_sha256'] == hashes['terminal_status'] and terminal['completed_variants'] == list(c.VARIANTS.values()), 'producer status/order differs')
    rows = {row['variant']: row for row in a['records']}
    c.need(set(rows) == expected_names and len(a['records']) == 2, 'wrong audited variants')
    builds, manifest = documents['binary_manifest'], documents['manifest']
    c.need(set(builds) == {'cargo-' + name for name in expected_names}, 'wrong build records')
    c.need(set(manifest['expected_variants']) == expected_names, 'wrong frozen variants')
    for key, name in c.VARIANTS.items():
        row, build, proof = rows[name], builds['cargo-' + name], documents[key + '_strip']
        expected = manifest['expected_variants'][name]
        c.need(row['source_tree'] == build['observed_source_tree'] == build['expected_source_tree_from_patches'] == expected['tree'] == c.TREES[key], 'actual source tree differs')
        c.need(row['stripped_sha256'] == proof['stripped_sha256'] == variants[key], 'stripped identity differs')
        c.need(row['original_linker_output_sha256'] == proof['source_sha256'] == proof['original_linker_output_sha256'] == build['original_linker_output_sha256'], 'linker output identity differs')
        c.need(row['verified_allocated_sections'] == len(proof['allocated_sections']) == 31, 'ELF section proof incomplete')
        c.need(build['variant'] == name and build['path'] == str(c.PRODUCTION_ROOT / 'binaries' / ('cargo-' + name)), 'build path/variant differs')
        c.need(build['common_build_inputs_sha256'] == common and build['observed_diff_sha256'] == hashes[key + '_patch'] == expected['canonical_diff_sha256'], 'source patch/common inputs differ')
        settings = row['actual_rustc_settings']
        c.need(set(settings) == {'src/lib.rs', 'src/bin/cargo/main.rs'}, 'actual rustc calls missing')
        for target, value in settings.items():
            cg, cfg = set(value['codegen']), set(value['cfg'])
            c.need({'opt-level=3', 'codegen-units=1', 'debuginfo=1'} <= cg and
                   {'feature="all-static"', 'feature="ohm-defaults"'} <= cfg, 'production settings differ')
            c.need(('lto=thin' if target.endswith('main.rs') else 'linker-plugin-lto') in cg and
                   not any('profile-' in v or 'incremental' in v for v in cg), 'LTO/PGO/incremental differs')
    first, second = (rows[name] for name in c.VARIANTS.values())
    c.need(first['actual_rustc_settings'] == second['actual_rustc_settings'] and first['version'] == second['version'], 'matched settings/version differ')
    return {'variants': variants, 'trees': c.TREES, 'common_build_inputs_sha256': common}


def load_production(references, variants):
    c.need(set(references) == ROLES, 'production binding is incomplete')
    documents, hashes = {}, {}
    for role, reference in references.items():
        c.need(set(reference) == {'path', 'sha256'}, 'bad production reference')
        path = c.regular(reference['path'])
        c.need(path.is_absolute() and c.sha(path) == c.digest(reference['sha256']), 'production bytes changed: ' + role)
        hashes[role] = reference['sha256']
        documents[role] = c.read(path) if role not in {'driver', 'baseline_patch', 'candidate_patch'} else None
    return validate_documents(documents, hashes, variants)


def validate_ci(value):
    c.need(value['status'] == 'passed' and value['scope'] == 'combined-pr183-pr184-pr185-source-ci'
           and value['head_sha'] == c.COMBINED_COMMIT and value['head_tree'] == c.TREES['candidate']
           and value['parent'] == c.BASE_COMMIT, 'exact combined CI is unbound or not green')
    c.need(value['run_id'] == 39696693562 and value['run_status'] == 'completed' and value['conclusion'] == 'success', 'combined source CI not complete/successful')
    names = {'Clippy (depot-macos-15)', 'Resolver tests', 'Cargo tests (depot-ubuntu-24.04-16)',
             'Schema tests', 'Workspace tests', 'Rustfmt', 'Clippy (depot-ubuntu-24.04-8)', 'Cargo tests (depot-macos-15)'}
    c.need(set(value['required_job_names']) == names and len(value['required_job_names']) == 8, 'required CI names differ')
    jobs = value['required_jobs']
    c.need(len(jobs) == 8 and {row['name'] for row in jobs} == names and len({row['id'] for row in jobs}) == 8
           and all(row['run_id'] == value['run_id'] and row['status'] == 'completed' and row['conclusion'] == 'success' for row in jobs), 'required CI jobs not all green')
    run = value['raw_run']
    c.need(run['id'] == value['run_id'] and run['head_sha'] == c.COMBINED_COMMIT and
           run['head_commit']['tree_id'] == c.TREES['candidate'] and run['status'] == 'completed' and
           run['conclusion'] == 'success' and run['repository']['full_name'] == 'astral-sh/ohm-cargo', 'raw CI run differs')
    raw = value['raw_jobs']['jobs']
    c.need(set(value['raw_jobs']) == {'jobs'} and len(raw) == 9 and len({row['id'] for row in raw}) == 9, 'raw CI jobs incomplete')
    by_id = {row['id']: row for row in raw}
    c.need(all(all(by_id[row['id']][key] == row[key] for key in ('id', 'name', 'run_id', 'status', 'conclusion')) for row in jobs), 'required/raw CI join differs')
    optional = [row for row in raw if row['name'] not in names]
    c.need(len(optional) == 1 and optional[0]['name'] == 'Clippy APFS replay' and optional[0]['conclusion'] == 'skipped', 'unexpected optional CI outcome')
    return value
