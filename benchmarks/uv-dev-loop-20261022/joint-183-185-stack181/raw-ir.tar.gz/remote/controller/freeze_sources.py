#!/usr/bin/env python3
"""One-time local source seal; no asset packaging, host, build, or measurement calls."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c
import production


def main():
    c.need(not (c.HERE / 'source-freeze.json').exists(), 'source freeze is already sealed')
    work = c.HERE.parent
    plan = work / 'joint-183-185-measurement-plan'
    producer = work / 'production-build/local-joint-stack181'
    ref = work / 'parser-allocations-measurement-controls-host4-v1'
    report = c.read(c.HERE / 'pure-checks-v4-final.json')
    c.need(report['status'] == 'passed' and report['tests'] == 17 and not report['failures'] and not report['errors'], 'pure checks incomplete')
    for name, digest in report['source_sha256'].items():
        c.need(c.sha(c.HERE / name) == digest, 'tested runtime source changed: ' + name)
    roles = {
        'audit': c.PRODUCTION_ROOT / 'execution/audit.json', 'root_review': None,
        'provenance': c.PRODUCTION_ROOT / 'provenance-local-joint-stack181.json',
        'manifest': producer / 'proposal/frozen/manifest.json', 'controls_freeze': producer / 'controls/source-freeze.json',
        'driver': producer / 'proposal/frozen/build_driver_local_joint_stack181.py',
        'build_result': c.PRODUCTION_ROOT / 'execution/build-result.json',
        'terminal_status': c.PRODUCTION_ROOT / 'status-local-joint-stack181.json',
        'binary_manifest': c.PRODUCTION_ROOT / 'binaries/manifest.json',
        **{key + '_strip': c.PRODUCTION_ROOT / 'binaries/stripped' / ('cargo-' + name + '.json') for key, name in c.VARIANTS.items()},
        **{key + '_patch': c.PRODUCTION_ROOT / 'logs' / (name + '.source.patch') for key, name in c.VARIANTS.items()},
    }
    c.need(set(roles) == production.ROLES, 'template producer contract differs')
    # No future build output is read and no binary identity is invented here.
    static = {'manifest', 'controls_freeze', 'driver'}
    template = {'schema': 1, 'state': 'unbound', 'controls_source_freeze_sha256': None,
                'assignment_sha256': c.sha(c.HERE / 'host-assignment.json'),
                'variants': {'baseline': None, 'candidate': None},
                'binary_files': {key: {'path': str(c.PRODUCTION_ROOT / 'binaries/stripped' / ('cargo-' + name)), 'sha256': None}
                                 for key, name in c.VARIANTS.items()},
                'production': {key: {'path': str(path) if path else None, 'sha256': c.sha(path) if key in static else None}
                               for key, path in sorted(roles.items())},
                'ci': {'path': str(work / 'combined-warm-loop-source-ci/combined-ci-complete.json'), 'sha256': c.CI_SHA}}
    c.write_once(c.HERE / 'inputs-template.json', template)
    common = {'schema': 1, 'status': 'unbound', 'scope': 'joint-183-185-operation',
              'operation': None, 'host': c.HOST, 'root': str(c.ROOT),
              'source_freeze_sha256': None, 'assignment_sha256': c.sha(c.HERE / 'host-assignment.json'),
              'protocol_sha256': c.PROTOCOL_SHA, 'output': str(c.HERE / 'executions' / '<unique-label>')}
    contract = {'schema': 1, 'scope': 'Template contracts only; no operation is approved',
                'common_operation_template': common,
                'non_admission_fields': ['manifest_sha256', 'delivery_receipt_sha256'],
                'additional_fields': {'admit': [], 'setup': ['archive_sha256'],
                     'collect-setup': ['measurement_seal_sha256'], 'ir': ['measurement_seal_sha256', 'setup_review'],
                     'collect-ir': ['measurement_seal_sha256']},
                'file_reference_schema': {'path': 'absolute regular file', 'sha256': 'actual 64-character SHA256'},
                'setup_review_contract': {'status': 'passed', 'scope': 'joint-183-185-setup-acceptance',
                     'measurement_seal_sha256': 'actual seal', 'delivery_sha256': 'actual delivery manifest hash',
                     'controls_source_freeze_sha256': 'actual source freeze',
                     'independent_review': {'path': 'actual setup independent review.json', 'sha256': 'actual review hash'}},
                'collect_failed_setup_without_seal': 'Use measurement_seal_sha256:null; remote capture records absent and cannot qualify.',
                'execution': {'uid': 1000, 'affinity': [8], 'python': '/usr/bin/python3', 'flags': ['-I', '-B'],
                     'managed_ssh_requires_escalated': True, 'local_PATH': 'inherited', 'automatic_retries': False}}
    c.write_once(c.HERE / 'approval-contract.json', contract)
    groups = [(c.HERE / 'fixture.py', ref / 'collections/ir/remote/controller/reference-native-controller.py',
               ['uv_identity', 'allocator_guard', 'configuration_presence', 'fresh', 'preflight']),
              (c.HERE / 'driver.py', ref / 'driver.py', ['phase_status', 'audit_sample_tables', 'audit_ir']),
              (c.HERE / 'reviewer/review.py', ref / 'reviewer/review.py',
               ['timestamp', 'machine', 'plan', 'substitute', 'fresh', 'success', 'tables', 'profile_count', 'preflight', 'immutable_inputs', 'raw_workflow', 'analyze']),
              (c.HERE / 'prepare_host.py', ref / 'cohort_binding.py', ['runtime_aliases'])]
    reuse = []
    for target, source, names in groups:
        def functions(path):
            return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(path.read_text()).body if isinstance(node, ast.FunctionDef)}
        a, b = functions(target), functions(source)
        c.need(all(a[name] == b[name] for name in names), 'reused function changed')
        reuse.append({'target': str(target.relative_to(c.HERE)), 'target_sha256': c.sha(target),
                      'source': str(source), 'source_sha256': c.sha(source), 'functions': names,
                      'equal_AST_sha256': {name: hashlib.sha256(a[name].encode()).hexdigest() for name in names}})
    reuse_report = {'schema': 1, 'status': 'passed', 'function_AST_groups': reuse,
        'byte_identical': {name: c.sha(c.HERE / name) for name in ('protocol.json', 'occupancy.py', 'frozen/paired.py', 'reviewer/statistics_review.py')},
        'pure_checks': {'path': 'pure-checks-v4-final.json', 'sha256': c.sha(c.HERE / 'pure-checks-v4-final.json')},
        'runtime_differences': ['Fresh host/root and exact combined source/CI/accepted producer contract bindings.',
            'IR-only entrypoints; fixed check then test with seeds 151/152; both raw audits before any effects.',
            'Direct source extraction with the unchanged strict occupancy guard; no old controller imports or operational histories.',
            'One setup seal for both distinct fresh workflow target/cache pairs; canonical active/bin/cargo shared within every pair.',
            'Fresh flat input/delivery/operation joins and opaque terminal collection; no automatic retry or native phase.',
            'Instruction-only AND qualification; native effects/regressions explicitly unverified.',
            'V2 restores runtime-alias catalog equality in driver, opaque collector and independent evidence join.',
            'V3 changes only the host/root runtime literals and corresponding source-placement metadata.',
            'V4 places the unchanged controls on host2, serially after the separate library-search study.'],
        'source_preparation_notes': ['Actual accepted CI raw_jobs has only a jobs key; validated directly before freezing.',
            'The fresh benchmark directory is explicitly created before sealing; temporary-fixture entrypoint test covers it.',
            'V1 preparation reports and all original frozen bytes remain in the predecessor directory unchanged.'],
        'execution_authority': 'None; source preparation only; actual pair, setup and operation approvals remain unbound.'}
    c.write_once(c.HERE / 'reuse-proof-final.json', reuse_report)
    external = [plan / name for name in ('source-freeze.json', 'protocol.json', 'controls-proposal.json', 'reuse-inputs.json', 'check_plan.py')]
    external += [work / 'combined-warm-loop-stack181-source' / name for name in ('source.json', 'manifest.json', 'source.bundle', 'combined.patch')]
    external += [work / 'combined-warm-loop-source-ci' / name for name in ('root-source-review.json', 'combined-ci-complete.json')]
    external += [work / 'cargo-audit' / directory / name
                 for directory in ('combined-183-184-185-source-review', 'joint-183-185-plan-scope-review', 'joint-local-production-source-review')
                 for name in ('review.json', 'seal.json')]
    external += [producer / name for name in ('source-freeze.json', 'proposal/source-freeze.json', 'controls/source-freeze.json',
                 'controls/pair-review-contract.json', 'proposal/frozen/manifest.json', 'proposal/frozen/build_driver_local_joint_stack181.py')]
    external += [source for _, source, _ in groups]
    external += [ref / name for name in ('occupancy.py', 'reviewer/statistics_review.py', 'prepare_host.py',
                 'collections/ir/remote/benchmark/frozen/paired.py', 'collections/ir/remote/benchmark/ir-check.json',
                 'collections/ir/remote/benchmark/ir-test.json')]
    external += [work / 'profiling-tools' / name for name in ('ohm-valgrind-env.c', 'ohm-valgrind-env.so')]
    predecessor = work / 'joint-183-185-measurement-controls'
    external += [predecessor / 'source-freeze.json', work / 'cargo-audit/joint-measurement-controls-source-review-v1/checks.json']
    external += [work / 'joint-183-185-measurement-controls-v2' / name
                 for name in ('source-freeze.json', 'root-source-acceptance.json', 'root-ir01-failure-closure.json')]
    external += [work / 'cargo-audit/joint-measurement-controls-source-review-v2/review.json']
    external += [work / name for name in ['joint-183-185-measurement-controls-host8-v3/source-freeze.json', 'joint-183-185-measurement-controls-host8-v3/root-source-acceptance.json', 'joint-183-185-measurement-controls-host8-v3/root-setup-acceptance.json', 'joint-183-185-measurement-controls-host8-v3/root-ir01-entry-failure-acceptance.json', 'joint-183-185-measurement-controls-host8-v3/prospective-entry-recovery-decision.json', 'cargo-audit/joint-measurement-controls-host8-v3-source-review/review.json', 'cargo-audit/joint-measurement-controls-host8-v3-source-review/review-seal.json', 'cargo-audit/joint-183-185-host8-ir01-transport-failure-review/review.json', 'cargo-audit/joint-183-185-host8-ir01-transport-failure-review/review-seal.json', 'cargo-audit/joint-183-185-host8-entry-recovery-protocol-review/review.json', 'cargo-audit/joint-183-185-host8-entry-recovery-protocol-review/review-seal.json', 'coordination/host2-placement-decision-20261022.json', 'coordination/host2-occupancy-20261022-01.json', 'coordination/observe-host2-occupancy.py', 'joint-183-185-host2-v4-preparation.py']]
    helper = Path('/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh')
    c.need(c.sha(helper) == '35f604e530c9270abd1de269af0a02351019e1ed959f2fea3bfc31d0aa3f4f7d', 'managed SSH helper changed')
    external.append(helper.resolve())
    aliases = {str(helper): {'resolved': str(helper.resolve()), 'symlink': os.readlink(helper) if helper.is_symlink() else None,
                             'sha256': c.sha(helper)}}
    freeze = {'schema': 1, 'scope': 'joint-183-185-instruction-only-controls', 'created_at': c.now(),
              'files': {str(path.relative_to(c.HERE)): c.record(path) for path in sorted(c.HERE.rglob('*')) if path.is_file()},
              'external_inputs': {str(path): c.record(path) for path in sorted(set(external))}, 'external_aliases': aliases,
              'source_identity': {'base_commit': c.BASE_COMMIT, 'combined_commit': c.COMBINED_COMMIT, 'trees': c.TREES,
                                  'PRs': [183, 184, 185], 'PR182_excluded': True},
              'reuse_checks_sha256': c.sha(c.HERE / 'reuse-proof-final.json')}
    c.write_once(c.HERE / 'source-freeze.json', freeze)
    c.verify_source()
    print(json.dumps({'state': 'source-frozen-inputs-unbound', 'source_freeze_sha256': c.sha(c.HERE / 'source-freeze.json'),
                      'files': len(freeze['files']), 'external_inputs': len(freeze['external_inputs']),
                      'external_aliases': len(aliases), 'reuse_proof_sha256': freeze['reuse_checks_sha256']}, sort_keys=True))


if __name__ == '__main__':
    main()
