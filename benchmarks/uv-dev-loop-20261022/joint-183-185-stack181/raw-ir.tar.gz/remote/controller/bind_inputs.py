#!/usr/bin/env python3
"""Locally bind accepted current inputs and create one lossless deployment archive."""
import argparse
import io
import json
import os
from pathlib import Path
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c
import production

WORK = c.HERE.parent
ASSETS = {
    'assets/ohm-1.99.0-6-x86_64-unknown-linux-gnu.tar.gz': (WORK / 'ohm-1.99.0-6-x86_64-unknown-linux-gnu.tar.gz', '98a4f4f99ea1ff36e10209258724426496afbbcab14d746294fe53a2fedad37c'),
    'assets/valgrind_1%3a3.22.0-0ubuntu3_amd64.deb': (WORK / 'profiling-tools/valgrind_1%3a3.22.0-0ubuntu3_amd64.deb', '744e081e5cf3d5c598b499dbb7d2250ea3f2869dde4a4d7b231fe6114f347d7d'),
    'assets/libc6-dbg_2.39-0ubuntu8.9_amd64.deb': (WORK / 'profiling-tools/libc6-dbg_2.39-0ubuntu8.9_amd64.deb', 'c4b086cef3a6bbb6a90299969b3c0bf3867f40cb8e9bbbb0edfe5ae23f2c04f0'),
    'profiling-tools/ohm-valgrind-env.so': (WORK / 'profiling-tools/ohm-valgrind-env.so', c.SHIM_SHA),
    'profiling-tools/ohm-valgrind-env.c': (WORK / 'profiling-tools/ohm-valgrind-env.c', '503c8612d9972ed2ce4ef7b4431e569a8c98d0d5f0d1149dd0fff364513e691b'),
}


def validate_input(value):
    c.need(value['schema'] == 1 and value['state'] == 'approved-for-input-binding', 'UNBOUND: actual accepted production pair is required')
    c.need(value['controls_source_freeze_sha256'] == c.sha(c.HERE / 'source-freeze.json') and
           value['assignment_sha256'] == c.sha(c.HERE / 'host-assignment.json'), 'source/assignment approval differs')
    c.need(set(value['variants']) == set(value['binary_files']) == {'baseline', 'candidate'}, 'UNBOUND: actual binary pair is required')
    production.load_production(value['production'], value['variants'])
    c.need(value['ci']['sha256'] == c.CI_SHA, 'actual root CI receipt differs')
    production.validate_ci(c.load_record(value['ci']))
    for variant, reference in value['binary_files'].items():
        expected = c.PRODUCTION_ROOT / 'binaries/stripped' / ('cargo-' + c.VARIANTS[variant])
        c.need(reference == {'path': str(expected), 'sha256': value['variants'][variant]}, 'wrong producer binary path/hash')
        c.need(c.sha(c.regular(expected)) == c.digest(reference['sha256']), 'binary bytes differ')


def bind(path, expected_sha):
    c.need(os.getuid() == os.geteuid() == 1000 and set(os.sched_getaffinity(0)) == {8}, 'normal UID/CPU8 required')
    c.verify_source()
    c.need(c.sha(c.regular(path)) == c.digest(expected_sha), 'actual input approval changed')
    value = c.read(path)
    validate_input(value)
    files = c.deployment_files()
    for name, (source, expected) in ASSETS.items():
        c.need(c.sha(c.regular(source)) == expected, 'common asset differs: ' + name)
        files[name] = source
    for variant, reference in value['binary_files'].items():
        files[str(c.binary_path(variant).relative_to(c.ROOT))] = Path(reference['path'])
    for role, reference in value['production'].items():
        files['controller/provenance/' + role + '.data'] = Path(reference['path'])
    files['controller/provenance/ci.json'] = Path(value['ci']['path'])
    output = c.HERE / 'delivery'
    output.mkdir(exist_ok=False)
    binding = {**value, 'state': 'bound', 'created_at': c.now(), 'input_approval_sha256': expected_sha,
               'host': c.HOST, 'root': str(c.ROOT), 'protocol_sha256': c.PROTOCOL_SHA}
    c.write_once(output / 'input-binding.json', binding)
    files['controller/input-binding.json'] = output / 'input-binding.json'
    rows = {name: c.record(source) for name, source in sorted(files.items())}
    manifest = {'schema': 1, 'state': 'bound', 'root': str(c.ROOT), 'host': c.HOST, 'created_at': c.now(),
                'controls_source_freeze_sha256': c.sha(c.HERE / 'source-freeze.json'),
                'input_binding_sha256': c.sha(output / 'input-binding.json'), 'variants': value['variants'],
                'source_trees': c.TREES, 'files': rows}
    c.write_once(output / 'manifest.json', manifest)
    archive = output / 'payload.tar'
    with tarfile.open(archive, 'x') as target:
        for name, source in [('delivery.json', output / 'manifest.json'), *sorted(files.items())]:
            info = tarfile.TarInfo(name)
            info.size = source.stat().st_size
            info.mode = 0o755 if name.startswith('controller/binaries/') else 0o644
            with source.open('rb') as stream:
                target.addfile(info, stream)
    # Verify exact regular membership and every payload again before issuing a receipt.
    expected = {'delivery.json': c.record(output / 'manifest.json'), **rows}
    seen = set()
    with tarfile.open(archive) as source:
        import hashlib
        for member in source:
            c.safe_relative(member.name)
            c.need(member.isfile() and member.name not in seen and member.name in expected, 'unsafe/unexpected delivery member')
            seen.add(member.name)
            stream = source.extractfile(member)
            c.need({'sha256': hashlib.file_digest(stream, 'sha256').hexdigest(), 'bytes': member.size} == expected[member.name], 'archive member differs')
    c.need(seen == set(expected), 'incomplete delivery archive')
    for name, source in files.items():
        c.check_record(source, rows[name])
    c.verify_source()
    validate_input(value)
    receipt = {'state': 'complete', 'created_at': c.now(), 'input_approval_sha256': expected_sha,
               'manifest_sha256': c.sha(output / 'manifest.json'), 'archive_sha256': c.sha(archive),
               'archive_bytes': archive.stat().st_size, 'exact_regular_members': len(seen),
               'input_binding_sha256': c.sha(output / 'input-binding.json'),
               'no_host_or_cargo_execution': True}
    c.write_once(output / 'receipt.json', receipt)
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True)
    parser.add_argument('--inputs-sha256', required=True)
    args = parser.parse_args()
    bind(args.inputs, args.inputs_sha256)
